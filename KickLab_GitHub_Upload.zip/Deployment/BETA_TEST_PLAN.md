# KickLab — first iPhone beta test plan

For the first TestFlight build (version 0.1.0) on a real iPhone. Mark each item **Pass**,
**Fail** or **Not tested**. Record every failure with the report template at the end.

Passing CI proves the code builds and the logic tests pass. It says **nothing** about how
accurate the measurements are on real kicking video. This beta is where that is found out.

**Before you start:**
- Note the iPhone model, iOS version and KickLab build number (TestFlight shows it).
- Have 3–5 real kicking videos ready, filmed from the side with the kicker's whole body in
  frame, ideally on a tripod, plus one from behind. Use your own footage; never use
  broadcast footage.

## A. Installation
- [ ] A1. TestFlight is installed from the App Store.
- [ ] A2. The KickLab invitation was accepted (email or TestFlight app).
- [ ] A3. KickLab installs from TestFlight.
- [ ] A4. KickLab launches and shows the welcome screen. Note how many seconds the first
      launch takes.
- [ ] A5. The icon (provisional goalpost) and the name "KickLab" look right on the Home
      Screen.

## B. Athlete setup
- [ ] B1. Create an athlete with a name, kicking foot and level.
- [ ] B2. Edit the athlete; the changes stick.
- [ ] B3. Force-quit KickLab (swipe up) and reopen it. The athlete is still there and still
      selected.
- [ ] B4. Optional: add a second athlete and switch between the two.

## C. Kick logging
- [ ] C1. Create a field-goal session (Kicks → Add → New Session).
- [ ] C2. Log at least 3 makes and 2 misses, with distance and hash.
- [ ] C3. Use the goalpost pad on a miss ("Wide left…" text appears).
- [ ] C4. Check that "Save & Add Another" keeps the distance and hash.
- [ ] C5. Stats tab: the field-goal numbers match what you logged (made, attempts, by
      distance, by hash).
- [ ] C6. Home: total kicks and field-goal % are right.

## D. Video
- [ ] D1. Import a real kicking video from Photos into one of the kicks.
- [ ] D2. Choose the correct camera angle (Side) during import.
- [ ] D3. The thumbnail appears, and the video shows as Primary.
- [ ] D4. Play the video. Does it play, upright and smoothly?
- [ ] D5. Import a second video (e.g., from behind) and make it primary, then switch back.
- [ ] D6. Force-quit and reopen. The videos are still there and still play.
- [ ] D7. Optional: import a **slow-motion** video and note the frame rate KickLab shows.
- [ ] D8. Optional: import from the Files app.

## E. Analysis
- [ ] E1. Analyze tab → choose the kick → Start Analysis. Progress moves, the screen stays
      responsive, and the screen doesn't sleep.
- [ ] E2. Note how long it takes and the video length.
- [ ] E3. The kicker is found automatically, or "More than one possible kicker" appears and
      tapping the kicker works.
- [ ] E4. Results: overall score, the five categories, confidence. Do they appear?
- [ ] E5. Review video → phase buttons (Approach, Plant, Estimated Contact,
      Follow-Through). Does each jump land at a sensible moment?
- [ ] E6. Detailed metrics: are values plausible? Write down any that look clearly wrong.
- [ ] E7. Metrics that couldn't be measured say "Not measured", and the confidence
      wording makes sense.
- [ ] E8. Coach section: the cues relate to what is visible in the video.
- [ ] E9. Analyze a video with no person (e.g., an empty field). KickLab should say it
      found no kicker, not invent results.

## F. Personalized coaching
- [ ] F1. Analyze at least 3, ideally 8 or more, comparable kicks: same type, foot and
      camera angle.
- [ ] F2. With fewer than 8, the Coach section says "KickLab is still learning your
      mechanics. Record N more comparable kicks…"
- [ ] F3. No "your best kicks" comparison appears until enough made kicks are analyzed.
- [ ] F4. Log makes and misses honestly. Check that a coaching point never praises
      something that only appears on misses.
- [ ] F5. Tap **Why?** on a coaching point. Are the evidence and numbers understandable?
- [ ] F6. Analyze one kick filmed from behind. Check that side-view comparisons aren't
      mixed in (look for the camera-angle note).

## G. Stability
- [ ] G1. Start an analysis, then tap **Cancel**. It stops promptly and says "Analysis
      cancelled".
- [ ] G2. Start an analysis and press the Home button / swipe home. When you return, it
      says "Analysis was paused"; **Try Again** works.
- [ ] G3. Retry a failed analysis; it completes.
- [ ] G4. Force-quit and reopen. Kicks, videos, analyses and history are all still there.
- [ ] G5. Analyze another kick. History (Kick → all analyses) shows each run, with one
      current.
- [ ] G6. Optional: import a video longer than 60 seconds. Analysis says "Video is too
      long" instead of running for minutes.
- [ ] G7. Optional: with storage nearly full, import a video. A clear "not enough free
      space" message appears.

## What this beta must establish (record observations, don't guess)

| Question | How to look | Your observation |
|---|---|---|
| Does Vision reliably find a real football kicker? | E3 across 5+ videos; note any misses | |
| Are contact-timing estimates plausible? | E5: the "Estimated Contact" jump vs the actual foot-ball contact | |
| Are metrics stable across similar kicks? | Analyze 3 similar kicks; compare plant timing, torso lean, knee angle | |
| Does camera angle change the results? | The same kick type from side vs behind | |
| Are the scoring bands reasonable? | Do good-looking kicks score higher than poor ones? | |
| Are coaching cues relevant to the footage? | E8 | |
| Is personalization conservative? | F2–F6 | |
| Speed and memory | E2 time; any crash or slowdown on long or slow-motion clips | |
| Video formats | HDR/HEVC (iPhone default), slow motion, landscape vs portrait | |

## Failure report template

Copy this for each problem:

```
Title:            (short, e.g. "Analysis fails on slow-motion video")
Build:            0.1.0 (build N)        iPhone / iOS: (e.g. iPhone 16, iOS 26.5)
Test item:        (e.g. E3)
Steps:            1. …  2. …  3. …
Expected:         …
Actual:           … (exact message on screen)
Happens:          every time / sometimes (N of M tries)
Video details:    length, slow-motion?, filmed from (side/behind), portrait/landscape
Screenshot:       (attach) — TestFlight → KickLab → Send Beta Feedback also works
```

Crashes are reported to App Store Connect automatically when the tester allows it. In
TestFlight you can also take a screenshot and use "Send Beta Feedback".
