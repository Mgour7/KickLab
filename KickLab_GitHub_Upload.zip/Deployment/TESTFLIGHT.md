# KickLab — TestFlight setup (Step 11)

This guide gets the first KickLab beta onto a real iPhone through TestFlight, working
only from an iPhone and github.com. Do the parts marked **⏳ after approval** once Apple
approves the Apple Developer Program membership.

Contents:
1. Status and what's waiting on Apple
2. App identity
3. How signing works
4. One-time setup on github.com (now)
5. Apple Developer setup (⏳ after approval)
6. App Store Connect setup (⏳ after approval)
7. GitHub settings: exact names
8. Uploading a build to TestFlight
9. Installing the beta
10. Manual signing (fallback)
11. App privacy and export compliance
12. Troubleshooting

---

## 1. Status and what's waiting on Apple

| Ready now | Waiting on Apple membership approval |
|---|---|
| App identity, version and build numbering | Registering the bundle identifier |
| App icon (provisional), privacy manifest, export-compliance key | Team ID |
| `ios-testflight.yml` deployment workflow and its scripts | App Store Connect API access and key |
| Configuration checks that name any missing setting | The app record in App Store Connect |
| Tests for all of the above | A signed build, the upload, and installing it |

Until approval, the deployment workflow can be installed and run; it will stop at the
first step and list the settings that are still missing. That's expected and proves
the workflow is installed correctly. **It can't produce a signed build until the
membership is approved.**

## 2. App identity

| Setting | Value | Where it's set |
|---|---|---|
| Display name | KickLab | `project.yml` (`INFOPLIST_KEY_CFBundleDisplayName`) |
| Bundle identifier | `com.kicklab.app` (if available) | `project.yml` (`PRODUCT_BUNDLE_IDENTIFIER`) |
| Version | 0.1.0 | `project.yml` (`MARKETING_VERSION`) |
| Build number | Increases with every upload (GitHub run number) | Set by the workflow |
| Minimum iOS | 18.0 (SwiftData features KickLab uses need iOS 18) | `project.yml` |
| Devices | iPhone only | `project.yml` (`TARGETED_DEVICE_FAMILY: "1"`) |
| Category | Sports | App Store Connect, plus `LSApplicationCategoryType` |

**The bundle identifier is permanent.** Once a build is uploaded with it, App Store
Connect ties the app record, TestFlight history and future App Store listing to it. A
different identifier is a different app: new record, new testers, and nothing carries
over, including data on testers' phones. If `com.kicklab.app` is already taken when you
register it (identifiers are unique across all developers), pick one such as
`com.<yourname>.kicklab` **before the first upload**. Then tell Claude, so `project.yml`
and the two tests that check the identifier are updated together.

## 3. How signing works

The project stays unsigned for ordinary builds, so `ios-tests.yml` keeps working without
any credentials.

The deployment workflow:
1. archives KickLab for iPhones without signing;
2. signs during export with Apple's **cloud signing** (automatic mode);
3. uploads with Apple's own `xcrun altool`, signed in with the App Store Connect API key
   (no Apple ID password).

With cloud signing, Xcode creates the App Store provisioning profile and uses a
**cloud-managed Apple Distribution certificate** that stays at Apple. No certificate file,
`.p12` or Mac is needed.

The trade-off: cloud signing needs an App Store Connect **team API key with the Admin
role**. Treat that key like a master password:
- keep it only in GitHub secrets;
- revoke it in App Store Connect if it might have leaked.

There is no official Apple-made GitHub Action for TestFlight; the popular
`apple-actions/upload-testflight-build` is a community project. KickLab uses Apple's own
command-line tools, which Apple lists as a supported upload method.

**Individual account notes:**
- API access for an Individual membership is requested by the Account Holder (you) and
  approved by Apple case by case.
- If the API isn't approved, or cloud signing is refused, use the manual signing fallback
  in section 10. It needs a Mac once to create the certificate.

## 4. One-time setup on github.com (now)

This works from Safari on your iPhone.

1. **Upload this ZIP's contents** to the repository as usual. The reference copy of the
   workflow is `Deployment/ios-testflight.yml`.
2. **Install the workflow.** Uploaded files can't create `.github/` from a ZIP, so create
   the file directly:
   1. Open the delivered `ios-testflight.yml` on your iPhone (Files, or the chat), then tap
      in the text → **Select All** → **Copy**.
   2. In Safari, open your repository on github.com → **Add file** → **Create new file**.
   3. In the name box type exactly: `.github/workflows/ios-testflight.yml`. Typing `/`
      creates the folders.
   4. Paste the copied text into the editor.
   5. Tap **Commit changes…** → **Commit changes**.
   6. Check: the **Actions** tab now lists **TestFlight deployment** next to
      **iOS build and tests**.
3. Don't edit or delete `.github/workflows/ios-tests.yml`.
4. Optional check: **Actions** → **TestFlight deployment** → **Run workflow** → **Run workflow**.
   Before approval it fails at **Check TestFlight settings** and lists the missing names.
   That's the expected result.

## 5. Apple Developer setup (⏳ after approval)

Use developer.apple.com/account in Safari.

1. **Agreements.** Accept any agreement shown on the account page, and in App Store
   Connect → **Business** if anything is pending. Exports and uploads fail while an
   agreement is waiting.
2. **Team ID.** Account → **Membership details** → **Team ID** (10 letters/digits). This
   becomes the `APPLE_TEAM_ID` variable.
3. **Register the bundle identifier.** **Certificates, IDs & Profiles** → **Identifiers** →
   **+** → **App IDs** → **App** → Continue:
   - Description: `KickLab`
   - Bundle ID: **Explicit**, `com.kicklab.app` (or your fallback; see section 2)
   - Capabilities: leave everything off (KickLab uses none)
   - **Continue** → **Register**
4. **Certificates and profiles:** nothing to create in automatic mode. Cloud signing makes
   them during the first export.

## 6. App Store Connect setup (⏳ after approval)

Use appstoreconnect.apple.com in Safari.

**A. Request API access** (Account Holder only):
1. **Users and Access** → **Integrations** → **App Store Connect API** → **Request Access**.
2. Agree to the terms and submit. Apple reviews these requests, so wait for approval.

**B. Create the API key:**
1. **Integrations** → **Team Keys** → **Generate API Key** (or **+**).
2. Name: `KickLab GitHub`. Access: **Admin** (needed for cloud signing) → **Generate**.
3. Note the **Issuer ID** (top of the page) and the key's **Key ID**.
4. Tap **Download API Key**. This works **only once**. Safari saves `AuthKey_<KEYID>.p8`
   to Files → Downloads.
5. Keep a private backup (for example, a secure note in your password manager). Never
   paste it into a chat, email or the repository.

**C. Create the app record:**
1. **Apps** → **+** → **New App**:
   - Platforms: **iOS**
   - Name: `KickLab` (App Store names are unique; if it's taken, use e.g. `KickLab Kicking`.
     The name under the icon on the phone stays "KickLab")
   - Primary Language: English (U.S.)
   - Bundle ID: choose `com.kicklab.app` (it appears after step 5.3)
   - SKU: `KICKLAB-001` (private to you; any unique text)
   - User Access: Full Access
   - **Create**
2. **App Information** → Category: **Sports** (Primary) → **Save**.
3. You don't need to fill in the App Store version page (screenshots, description,
   pricing) for internal TestFlight. Nothing is submitted for App Store review.

**D. Internal testing group:**
1. **TestFlight** tab → **Internal Testing** → **+** → name `KickLab Internal` → turn on
   automatic distribution.
2. Add testers. They must be users of your App Store Connect account; for now that's just
   you. Up to 100 internal testers; no beta review is needed.
3. Don't create an external group or "Submit for Review" unless you decide to. External
   testing needs Apple's beta review, a privacy policy URL and full test information.

**E. Export compliance** is answered by the app itself (`ITSAppUsesNonExemptEncryption = NO`;
see section 11), so builds shouldn't show "Missing Compliance".

## 7. GitHub settings: exact names

Add these in Safari: repository → **Settings** → **Secrets and variables** → **Actions**.
If **Settings** is hidden, use Safari's **aA** menu → **Request Desktop Website**.

- **Variables tab** → **New repository variable**: these aren't credentials, just
  identifiers. Storing them as secrets instead also works.
- **Secrets tab** → **New repository secret**: GitHub hides secrets and masks them in logs.

| Name | Type | Required | Value and where to get it | Base64? |
|---|---|---|---|---|
| `APPLE_TEAM_ID` | Variable | Yes | Team ID from developer.apple.com → Membership details | No |
| `ASC_KEY_ID` | Variable | Yes | Key ID of the team API key (App Store Connect → Integrations → Team Keys) | No |
| `ASC_ISSUER_ID` | Variable | Yes | Issuer ID shown above the key list | No |
| `ASC_API_PRIVATE_KEY` | **Secret** | Yes | The whole `AuthKey_<KEYID>.p8` file, including the BEGIN/END lines (see below) | No (base64 also accepted) |
| `KICKLAB_SIGNING_MODE` | Variable | No | `automatic` (default) or `manual` | No |
| `KICKLAB_BUILD_NUMBER_OFFSET` | Variable | No | Added to the run number. Only needed if the workflow is ever recreated: set it above the last uploaded build | No |
| `KICKLAB_BUNDLE_ID` | Variable | No | The bundle ID registered in App Store Connect; the workflow stops if `project.yml` differs | No |
| `IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64` | **Secret** | Manual mode only | Apple Distribution certificate + private key exported as `.p12` | **Yes** |
| `IOS_DISTRIBUTION_CERTIFICATE_PASSWORD` | **Secret** | Manual mode only | The password chosen when exporting the `.p12` | No |
| `IOS_APPSTORE_PROFILE_BASE64` | **Secret** | Manual mode only | "App Store Connect" provisioning profile (`.mobileprovision`) | **Yes** |

**Copying the `.p8` on an iPhone:**
1. In **Files** → Downloads, long-press `AuthKey_<KEYID>.p8` → **Rename** → change the
   ending to `.txt`.
2. Tap it to preview → tap in the text → **Select All** → **Copy**.
3. In GitHub: **Secrets** → **New repository secret** → Name `ASC_API_PRIVATE_KEY` → paste →
   **Add secret**.
4. Afterwards, delete the file from Downloads, keeping only your private backup.

If the line breaks get lost while pasting, the workflow repairs them. It reports a broken
key by name and never prints it.

## 8. Uploading a build to TestFlight

1. Make sure the latest ZIP is uploaded and **iOS build and tests** passed.
2. **Actions** → **TestFlight deployment** → **Run workflow**:
   - Branch: `main`
   - **Upload to TestFlight**: on. Turn it off to only build and sign as a dry run.
   - **Build number**: leave empty
   - Tap **Run workflow**.
3. The run takes about 10–25 minutes. Its steps:
   1. check settings
   2. select Xcode 26+
   3. generate the project
   4. check the app identity
   5. install signing material temporarily
   6. archive
   7. export the signed `.ipa`
   8. verify it
   9. validate and upload with App Store Connect
   10. clean up
4. The run page shows a **summary** (version, build number, upload result) and keeps
   **kicklab-testflight-logs-N** for 14 days.
5. In App Store Connect → KickLab → **TestFlight**, the build appears as *Processing*, then
   becomes available to the internal group, usually within 5–30 minutes.

Each run uses a new, higher build number, so re-uploading is never rejected as a
duplicate. The version stays 0.1.0 until you decide to change it in `project.yml`.

## 9. Installing the beta

1. Install **TestFlight** from the App Store on the iPhone.
2. Open the TestFlight invitation email, or open TestFlight signed in with the same Apple
   Account you use for App Store Connect.
3. Open **KickLab** → **Install**.
4. Launch KickLab and follow `Deployment/BETA_TEST_PLAN.md`.

TestFlight builds expire after 90 days; upload a new build to keep testing.

## 10. Manual signing (fallback)

Use this only if automatic mode fails, for example because API access was refused or
cloud signing gives a permission error.

**What it needs:**
1. An **Apple Distribution** certificate with its private key, as a `.p12`. Creating one
   needs a certificate signing request, which normally needs a Mac (Keychain Access) or a
   computer with OpenSSL. It can't be done from an iPhone alone.
2. An **App Store Connect** provisioning profile for `com.kicklab.app` that uses that
   certificate: Profiles → **+** → Distribution → **App Store Connect**.
3. An API key for the upload. The App Manager role is enough in manual mode.

**Settings:** set `KICKLAB_SIGNING_MODE` = `manual` and add the three manual-mode secrets
from section 7, base64-encoded.

**During the run:**
- the certificate goes into a temporary keychain with a random password;
- the profile is checked against the team and bundle identifier, and must be an App Store
  profile;
- both are deleted when the run ends.

## 11. App privacy and export compliance

**What KickLab does:**
- Videos, kicks and analyses stay on the iPhone.
- Pose analysis runs on the device with Apple Vision.
- There is no network code, no uploads, no external AI, and no face or identity
  recognition.

**What reaches Apple:** TestFlight receives the uploaded app and the normal testing
information. That includes tester details, crash reports, and feedback or screenshots
testers choose to send, handled under Apple's TestFlight terms. The developer can see
these in App Store Connect.

**Privacy manifest** (`KickLab/Resources/PrivacyInfo.xcprivacy`):
- no tracking and no data collected;
- required-reason API use declared for:
  - UserDefaults (CA92.1): remembering the selected athlete and settings
  - file timestamps in the app's own container (C617.1): cleaning up old temporary files
  - free disk space (E174.1): checking before copying a video

**Permissions:** none. Videos are chosen with the system Photos picker and Files browser,
which need no permission. There's no camera capture or audio recording.

**App Privacy questionnaire** in App Store Connect (needed before external testing or the
App Store, not for internal testing): answer **"No, we do not collect data from this
app."** That is accurate for KickLab's own code. Revisit it if a future step adds any
network feature.

**Export compliance:** `ITSAppUsesNonExemptEncryption = NO`, because KickLab uses no
encryption of its own. If a future step adds networking or encryption, revisit this.

## 12. Troubleshooting

| Message in the run | Fix |
|---|---|
| "✗ NAME — missing" | Add that exact name in Settings → Secrets and variables → Actions (section 7) |
| "Cloud signing permission error" | The API key isn't **Admin**, or API access isn't approved. Create an Admin team key, or use manual mode |
| "…agreement…" during export or upload | Accept the pending agreements (section 5.1) |
| "No profile/App ID for com.kicklab.app" | Register the bundle identifier (section 5.3) and create the app record (6C) |
| Upload: "bundle version must be higher" | Run again (the build number increases), or set `KICKLAB_BUILD_NUMBER_OFFSET` above the last build |
| Upload: "No suitable application records" | Create the app record with the same bundle ID (section 6C) |
| "requires Xcode 26 or later" | GitHub's runner image changed. Re-run later, or tell Claude to pin a runner |
| Build stuck in "Processing" for hours | Wait. If it disappears, check the email App Store Connect sends about the build |

Log files are in the run's **kicklab-testflight-logs-N** artifact:
`archive.log`, `export.log`, `validate.log` and `upload.log`. None of them contains
credentials.
