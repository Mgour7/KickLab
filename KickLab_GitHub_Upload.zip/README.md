# KickLab — Steps 1–11 (data foundation, services, media, statistics, pose, biomechanics, app UI, personal coach, TestFlight)

Steps 1–4: project setup, persisted enums, the eight SwiftData models (versioned schema),
and the typed outcome / draft / validation layer.
Step 5: the authoritative service layer — KickService, KickingSessionService,
AthleteService, AnalysisService.
Step 6: `VideoStorageService` + `ManagedMediaStore` (video files under
`Application Support/KickLab/Media/`, analysis artifacts under `.../Analysis/`, never in
SwiftData), `StatisticsService` (real statistics from stored kicks), the
`VideoAnalysisService` contract with an `UnavailableVideoAnalysisService`, and the
`AppServices` composition root.
Step 7: the on-device pose and kick-phase foundation (see "Pose analysis" below).
Step 8: biomechanics metrics, category scores and rule-based coaching (see "Biomechanics" below).
Step 9: the first complete app interface (see "App interface" below).
Step 10: the personalized learning coach (see "Personal coach" below).
Step 11: iPhone beta deployment through TestFlight (see "TestFlight beta" below).
Step 12A: analysis diagnostics for real-device failures (see "Analysis diagnostics" below).
Step 12B: real-world plant and follow-through detection (see "Phase detection on real video" below).
Step 12C: evidence-based contact estimation, pose validation player and contact validation (see "Contact estimation and validation" below).
Step 12D: kick windows, contact regression fix, user-assisted recovery and recording guidance (see "Kick windows and assisted recovery" below).

## Build and test in the cloud (no Mac needed)

GitHub Actions builds KickLab on a GitHub-hosted Mac with Apple's real Xcode and SDKs,
boots an iPhone Simulator, and runs every test, including the SwiftData tests. You never
need a physical Mac for this.

What runs: `.github/workflows/ios-tests.yml` → `Scripts/test-ios.sh`, which generates
`KickLab.xcodeproj` from `project.yml` with XcodeGen, builds, and runs `KickLabTests`.
The `.xcodeproj` is generated on every run and is not stored in the repository.

### A. Create a GitHub repository
1. Sign in at github.com → **+** (top right) → **New repository**.
2. Name it `KickLab`. Choose **Public** (macOS runner minutes are free for public
   repositories) or **Private** (macOS minutes count against your plan at a higher rate).
3. Leave "Add a README" unchecked → **Create repository**.

### B. Upload the files
Upload the **contents** of this folder so they sit at the top of the repository:

```
.github/workflows/ios-tests.yml
.gitignore
KickLab/            (all app sources)
KickLabTests/       (all tests)
Scripts/test-ios.sh
project.yml
README.md
```

On the new repository's page choose **uploading an existing file**, drag those items in,
and **Commit changes**. Afterwards check that `.github/workflows/ios-tests.yml` appears in
the file list: some computers hide folders whose names start with a dot. If it's missing,
use **Add file → Create new file**, type `.github/workflows/ios-tests.yml` as the name,
paste the file's contents and commit. (GitHub Desktop or `git push` work too.)

### C. See the result
Open the repository's **Actions** tab. Every push to `main` starts **iOS build and tests**;
you can also start it with **Run workflow**. A green check means the app built and every
test passed; a red X means something failed. The run page shows a short summary (Xcode
version, simulator, warning count, tests passed/failed).

### D. Download failure logs
On the run page, scroll to **Artifacts** and download `kicklab-test-logs-<number>`. It contains:
- `logs/build.log` and `logs/test.log`: full xcodebuild output
- `logs/warnings.txt`: every unique compiler warning
- `logs/summary.md`: the summary shown on the run page
- `KickLab.xcresult`: Xcode's result bundle (only useful if you later have a Mac)

The raw step output is also available from the run page's **⋯ → Download log archive**.

### E. No physical Mac required
Everything above runs on GitHub's hosted macOS machines. On any Mac with Xcode you can run
the same thing locally with `bash Scripts/test-ios.sh`.

## Data semantics (summary)

- **Field position** (`spotDistanceToTargetGoalLine`, 0–100): yards from the goal line the
  kick travels toward — Opp 30 = 30, midfield = 50, own 40 = 60, own 20 = 80, kickoff teed
  at own 35 = 65. Never shown raw: `FieldGeometry.footballNotation(...)` gives "Opp 30",
  "50", "Own 40". `landingYardLine` uses the same reference; negative = in the end zone.
- **Distance**: FG/PAT = actual hold-to-goal-plane distance (Opp 30 ≈ 40 yards);
  kickoff = ball travel; punt = punt distance. The spot never overwrites distance;
  `FieldGeometry.estimatedFieldGoalDistance` is a display helper only.
  Display example: "Hold: Opp 30 · Distance: 40 yd".
- **Accuracy** (normalized, never pixels; kicker's perspective): x −1 = left upright,
  0 = center, +1 = right upright, beyond ±1 = outside. y uses the same unit, 0 = crossbar,
  positive = above, `nil` when unknown.
- **Provenance**: distance, accuracy, landing and hang time each store a source
  (`OutcomeMeasurementSource`) and optional 0...1 confidence. Manual entries carry no confidence.
  `primaryVideo` / `secondaryVideo` / `multiVideo` describe the *kind* of provenance, not the
  exact `VideoAsset`; exact source-video links are added when video analysis begins.

## Pose analysis (Step 7 foundation)

Everything runs on the device. Video is never uploaded. KickLab tracks **body pose only**:
no face recognition, identity recognition or biometric identification.

Pipeline (`Services/Pose/`):
1. `VideoFrameReader` (AVFoundation) streams frames with true timestamps;
   `FrameSampler` keeps every frame, a target rate (default 60 fps) or a time range.
2. `VisionPoseSequenceExtractor` runs Apple Vision body-pose detection (19 joints, several
   people, per-joint confidence) and converts to app coordinates (upright, top-left origin,
   0…1; see `PoseModel.swift`).
3. `PoseTracker` follows people frame to frame and selects the kicker. A manual
   `KickerSeed` always wins; otherwise ambiguous cases report "multiple possible kickers"
   and select nobody.
4. `PoseTimelineProcessor`: confidence threshold → leg-label repair (Step 12B) →
   short-gap interpolation only → light smoothing; every point is `measured`,
   `interpolated` or `unavailable`.
5. `PoseSignalExtractor` derives speeds (body lengths/s), angles and lean, using the
   athlete's kicking foot (no right-foot assumption).
6. `KickPhaseDetector` finds setup, approach, plant, contact and follow-through.
   Without ball tracking, contact is always `estimated`. FG/PAT and kickoff are fully
   supported; punts are limited (contact and follow-through only).
7. Versioned JSON artifacts are written to `Analysis/<analysis-id>/`
   (`manifest.json`, `pose-v1.json`, `signals-v1.json`, `phases-v1.json`).

`PoseVideoAnalysisService` is the real `VideoAnalysisService`; `KickAnalysisRunner`
records a run through `AnalysisService`.

## Biomechanics (Step 8)

Pure Swift in `Services/Biomechanics/`, fully tested on Linux:

- `KickMetricCatalog`: 17 metrics (approach, plant, swing, body position at contact,
  follow-through). Sizes are in **body lengths** (torso length) and speeds in body lengths
  per second; no mph, m/s, yards, force, ball speed or launch angle is ever reported.
- `KickMetricExtractor`: reads Step 7 phases; a metric whose phase is missing is
  `unavailable` (never zero, never a substitute timestamp); ambiguous phases lower confidence.
- `MetricConfidenceModel`: confidence = joint quality × phase factor × sample factor ×
  frame-rate factor × camera factor, with every factor stored for explanation.
- `KickScorer`: explicit 0–100 bands per metric and confidence-weighted category scores;
  hidden joints lower confidence, not the score.
- `CoachingEngine`: rule-based IMPROVE + CUE and KEEP observations, issued only with enough
  confidence, ranked deterministically and capped (3 IMPROVE, 2 KEEP).
- `MetricComparison`: kick-vs-kick, athlete baseline and trend foundations.
- `BiomechanicsProfile`: every threshold, per kick type, ready for later tuning by level,
  baseline or camera angle.

Results are stored through `AnalysisService.recordResults` (one validated save), the
analysis is completed and promoted to current, and `biomechanics-v1.json` is added to the
artifact set (manifest format v2; v1 manifests remain readable).


## App interface (Step 9)

Five tabs: **Home, Kicks, Analyze, Stats, Profile**, each with its own navigation stack.
Several athletes can be stored; the switcher at the top of each tab changes the selected
athlete, which is remembered between launches.

Layers (screens never touch the database or files directly):
- `Presentation/` — pure Swift, tested on Linux: display formatting, results and coaching
  presentation, dashboard aggregation, the manual kick-entry form, the analysis state
  machine, statistics sections and the rule-based personal insights.
- `ViewModels/` — `@Observable` main-actor view models that call the Step 5–8 services
  through `AppServices` and turn stored records into presentation values.
- `UI/` — thin SwiftUI views.

Personalization is rule-based and replaceable (`PersonalInsightsProviding`). With fewer
than 3 analyzed kicks of a type KickLab says "More kicks are needed before KickLab can build
your personal baseline." and draws no personal conclusions. Video import (Photos or Files)
always goes through `VideoStorageService`; Photos originals are never changed. Camera
capture is not built yet (`VideoSourceType.captured` is ready for it).

## Personal coach (Step 10)

`Services/Personalization/` learns each athlete's mechanical fingerprint with transparent,
deterministic statistics on their own stored kicks — not machine learning, nothing leaves
the phone. It sits on top of the Step 8 rules and never replaces them.

- **Profiles** per kick type and kicking foot (camera angle, field-goal distance bucket and
  baseline epoch when relevant): mean, median, SD, robust spread, quartiles, recent and
  recency-weighted baselines, the successful-kick pattern, consistency and trends.
- **Eligibility**: completed analyses only; metric confidence ≥ 0.5; same kick type, foot,
  definition version and (for angle-dependent metrics) camera angle. Missing is never zero.
- **Maturity**: < 3 kicks insufficient, 3–7 emerging, 8–19 established, 20+ strong.
- **Coach**: combines Step 8 findings with personal evidence (successful pattern, makes vs
  misses, normal, consistency, trend), resolves conflicts explicitly, ranks with a capped
  priority score, and keeps every Step 8 observation (re-ranked with its reason).
- **Storage**: profiles are rebuilt on demand from the stored analyses (no learned state).
  Each completed analysis gets `personalization-v1.json`: what KickLab knew at that moment.
- Every threshold is in `PersonalizationConfiguration`.

## TestFlight beta (Step 11)

`Deployment/TESTFLIGHT.md` is the complete setup guide (Apple Developer, App Store Connect,
GitHub secrets, uploading, installing). `Deployment/BETA_TEST_PLAN.md` is the first-device
test plan.

- **Two workflows.** `ios-tests.yml` builds and tests without credentials, unchanged.
  `ios-testflight.yml` (reference copy in `Deployment/`, installed as
  `.github/workflows/ios-testflight.yml`) runs only when started by hand.
- **What the deployment does:** checks settings → Xcode 26+ → XcodeGen → unsigned
  archive → signed export (cloud signing, or manual) → verify → `altool` validate and
  upload → clean up.
- **Scripts:** `Scripts/testflight/` holds the steps. `bash Scripts/testflight/selftest.sh`
  tests them without any Apple account.
- **Identity:** `com.kicklab.app`, version 0.1.0; the build number is the run number.
  iPhone only, iOS 18+, category Sports.
- **No credentials in the repository.** Settings live in GitHub Actions secrets and
  variables, and signing material exists only during a run.

## Analysis diagnostics (Step 12A)

**Turning it on:** Profile → Developer → **Analysis diagnostics**. A **Diagnostics** screen
then appears:
- on every analysis result (toolbar)
- under a failed analysis on the Analyze screen

**What it shows:**
- frames sampled, Vision failures, frames with a person, and frames with the kicker
- manual or automatic kicker selection
- hip, knee and ankle detection counts and confidence
- the camera angle and kicking foot used
- each phase's status
- why every metric was or wasn't available, with its confidence factors
- each category's score or the reason it wasn't scored
- the diagnosed cause

**Privacy and sharing:** the report is built on the iPhone from the stored analysis files.
It holds no images, body coordinates or names. **Share or Save** / **Copy** exports it as
text plus JSON (Files, Notes, Mail, AirDrop); nothing is uploaded otherwise.

**Specific failure causes** (`AnalysisFailureCause`), each with its own message, replace
the old catch-all "Not enough of the kick was visible":
- kicker tracked too briefly
- plant or contact not found
- camera angle limits measurement
- low pose confidence
- legs not visible
- partial measurements only

## Phase detection on real video (Step 12B)

A real 30 fps side-view kick was tracked in every frame, yet plant and follow-through came
back unavailable. Synthetic reproductions showed two causes, both now handled:

- **Leg-label errors at contact.** As the kicking leg swings past the plant leg, Vision
  can swap the left/right knee and ankle labels, or put both ankles on one leg, for a
  frame or two. The planted foot then appears to jump, and the kicking foot shows a false,
  late speed peak that is taken as contact, so the follow-through "ends" too soon.
  `PoseLegRepair` swaps labels back only when that continues both legs' motion far better,
  and rejects one- or two-frame knee/ankle jumps (refilled only as `interpolated`).
- **A one-sample plant check.** Plant used to require the plant ankle to be still in the
  single frame at the speed peak. A foot that rolls or hops through the strike failed it.
  The plant is now the foot **coming to rest** before contact (median-filtered speed,
  at least 0.05 s still). Whether it **stayed still through contact** is reported
  separately: an unstable plant is an `estimated` plant with lower confidence, and
  plant-foot drift measures the instability. A one-frame stop with a sharp slow-down is a
  low-confidence estimated plant. No stop at all leaves the plant unavailable.
- **Adaptive still threshold.** The plant-still threshold rises above 1.0 body length/s
  only when the athlete's own standing-still jitter demands it (3 × noise floor), and
  never above 1.5.
- **Follow-through** ends when the kicking-foot speed has fallen to 25% of its peak and
  stays there for a second sample. It never depends on the plant.
- **Contact** is still an estimate (peak kicking-foot speed). It is checked against an
  independent cue — when the kicking foot passes the plant foot — and its confidence drops
  when the two disagree by more than 0.2 s.

Diagnostics additions (format 2):
- **Current detector on stored pose** re-runs the current build's processing, phases and
  scores on the pose data stored with any analysis, so older analyses can be compared
  without re-running Vision.
- **Detection evidence** shows peak speed, the foot-passing time, plant touchdown,
  plant speed at contact, the still threshold and noise floor, and follow-through length.
- **Share Phase Signals (CSV)** exports per-frame plant-ankle speed, kicking-ankle speed,
  hip speed and forward velocity, the kicking-foot offset from the plant foot, repair
  flags, and candidate events. Speeds are in body lengths/s, with no coordinates.
- **Contact check:** enter the strike time you see in the video. KickLab stores it on
  the video (for checking only; analysis never reads it) and shows the estimate's error
  in seconds and frames. `ContactTimingSummary` is the matching validation harness.

The engine version is now `pose-biomechanics-2.1.0`. When a result scores only some areas,
the results screen says which were not scored and that they are not rated good or bad.

## Contact estimation and validation (Step 12C)

On the real 30 fps clip, the highest kicking-foot speed came 0.167 s (five frames) before the
strike seen in the video. Plant and follow-through are searched relative to contact, so they
were searched in the wrong place.

**Contact (`ContactEstimator`, algorithm `contact-candidates-1`).** Every local peak of
kicking-ankle speed is a candidate. Each candidate is scored on separate lines of evidence:

| Line | What it checks | Weight |
|---|---|---|
| K: kicking-foot motion | relative speed | 0.25 |
| K | a supported swing, not a one-sample spike | 0.10 |
| K | forward direction | 0.10 |
| K | the foot keeps travelling forward afterwards | 0.10 |
| P: plant foot | at rest just before the candidate (a different joint) | 0.20 |
| H: hips | slowing into the candidate | 0.10 |
| G: geometry | timing against the kicking foot passing the plant foot | 0.15 |

The four K checks come from the same ankle, so they count as **one** independent line.
G also uses the kicking ankle, so it counts as **half** a line. Evidence that can't be
observed counts as neutral (half its weight).

Hard rejections:
- isolated spikes (both neighbours below 30% of the peak);
- backward motion (forward cosine below −0.2);
- no net forward travel (under 30% of the path between −0.1 and +0.2 s).

Candidates are ranked by score, then speed, then time, so the result is deterministic.

Contact is **unavailable** when the best score is below 0.35. It is **ambiguous** when a
rival at least 0.25 s away scores within 0.08.

Confidence = 0.30 + 0.17 × (independent lines − 1), capped at 0.90. It is then reduced:
- × 0.6 below 15 analyzed fps;
- × 0.4 when ambiguous;
- × local coverage.

Uncertainty is ±1 analyzed frame, plus 0.05 s when the foot-passing cue disagrees. When
contact is ambiguous, it becomes the distance to the rival.

Every candidate, its evidence, its supporting signals and its rejection reasons are stored
and shown in Diagnostics. Contact is always `estimated`, never measured.

**Plant.** A still run of the plant foot, ending closest to contact. It has four outcomes:
- `touchdownDetected`;
- `estimated` (the run was clipped or interrupted, or the foot was more than 0.5 body
  lengths behind the hip);
- `unstableAfterTouchdown`;
- `notDetected`.

Rejected still runs are listed. A rest that begins *after* the estimate is flagged with
"the contact estimate may be early".

**Follow-through** ends at the later of:
- a sustained slow-down (≤ 25% of peak speed for two samples);
- the swing apex (the foot's furthest point ahead of the hip).

A slow-down within 0.1 s of contact means the follow-through is unavailable.

**Pose Validation** (Diagnostics → Pose Validation, or from results and failed analyses
when diagnostics are on):
- The stored video, with the pose drawn over an aspect-fit `AVPlayerLayer`. The overlay
  uses the same aspect-fit rectangle. Pose coordinates are already upright and mirrored to
  match the displayed video.
- Choice of pose: raw Vision, as analyzed, or the current build's repair.
- Leg colors, measured or filled-in dots, confidence opacity, and repair rings.
- Frame stepping on the stored analyzed timestamps (no drift), slow motion, and jumps to
  every marker and candidate.
- Mark contact on the current frame.

**Annotations** are evaluation data only. They are stored on the video as a `.manual`
contact time, never given to the engine (`VideoAnalysisRequest.make` drops them), and never
change an estimate or a score.

**Validation harness.** `ContactTimingSummary` reports:
- signed and absolute error, in milliseconds and in analyzed frames;
- MAE, median, 90th percentile;
- the share within 1, 2 and 3 frames;
- unavailable estimates;
- confidence calibration.

Real annotated clips go in `KickLabTests/ValidationLibrary/` (see its README). No real
athlete data is included or validated yet.

**Scoring presentation.** Grades with low confidence read "· tentative". "No corrections
flagged" says when areas were unmeasured.

The engine version is `pose-biomechanics-2.2.0`.

## Kick windows and assisted recovery (Step 12D)

Engine `pose-biomechanics-2.3.0`, detector `contact-window-2`.

**The regression.** On the real reference clip, engine 2.2.0 ranked every kicking-foot
speed peak in the whole video. A calm movement at 6.04 s won with a score of 0.71: the
athlete was standing, so "plant at rest" and "foot passing" were trivially true. It beat the
kick at about 2.3–2.5 s (score 0.62, foot speed 18.8 vs 4.4 body lengths/s). A regression test
reproduces that ranking exactly from the exported evidence
(`KickLabTests/RealReferenceClip220.swift`, values copied verbatim).

**Kick window (`KickWindowDetector`).** The kick is located from the hips first, a different
body part from the kicking foot:
- An approach is a stretch where forward hip speed is at least 40% of the clip's highest.
- Braking ends when forward hip speed falls back below 30% of that approach's peak.
- The strike interval runs from 0.25 s before the approach ends to 0.35 s after braking ends.

Contact candidates outside the window are preparation, walking or recovery. They are kept
in diagnostics but never chosen.

Two windows with real approaches and swings are "several kicks", and the user chooses one.
With no approach at all, the fastest swing defines a low-confidence window. The video is
never trimmed.

**Contact inside the window:**
- **Direction.** It is measured relative to the hips, so camera panning and body travel
  cancel out. A foot moving mostly upward or backward (cosine below 0.3) is not a strike.
- **Weak swings.** Swings under 50% of the strongest valid swing are follow-through or
  recovery.
- **Plant evidence.** It needs the foot to have arrived from a step (≥ 1.5 × the still
  threshold).
- **Passing evidence.** It needs the kicking foot to come from at least 0.3 body lengths
  behind.
- **Chronology.** Contact can't precede the plant landing or the foot reaching the plant
  foot. When the measured speed peak comes earlier (a fast foot blurring at 30 fps), contact
  is timed from those events. Timing basis `plantAndFootPassing` comes with lower confidence,
  and kicking-foot speed at contact is not reported.

**Plant** is found from the window, before contact is chosen. It is the first rest of the
plant foot where the approach brakes. A one-frame stop counts only if the foot stays slower
afterwards.

**Follow-through** is unavailable, rather than invented, when the kicking ankle merges with
the plant ankle after contact. Camera panning after the kick is detected and reported.

**User-assisted analysis.** When contact is uncertain or there are several kicks, the Analyze
and Results screens offer:
- **Select the Strike Frame**, with frame-by-frame controls and "Use This Frame";
- **Choose the Kick**, a window picker with adjustable start and end.

Either one runs a **new** analysis:
- It is versioned `…+assisted` and labeled "User-assisted analysis".
- It records exactly what the user supplied, in the manifest and the phases file.
- It is excluded from accuracy statistics.
- It never changes earlier analyses or the video.

**Recording suitability (`RecordingSuitability`).** Checks:
- no person detected (with behind-goal guidance);
- several people;
- kicker too small (torso under 5% of frame height) or small (under 8%);
- joint coverage;
- body leaving the frame;
- too few frames;
- frame rate;
- camera angle;
- camera moving;
- kicking foot lost after contact.

**Failure causes** now separate phase problems from visibility problems:
- no kick found;
- several kicks;
- strike uncertain;
- plant or follow-through not found;
- kicker too small.

**Pose Validation** adds:
- a phase timeline (kick window, phases by status, recovery, candidate ticks with evidence);
- a kick-window picker (display only);
- source-frame stepping.

Diagnostics (format 3) export every non-coordinate signal, so a detection can be replayed
exactly.

## Reanalysis and manual-contact isolation (build 8 fix)

Three separate operations, never mixed:

| Operation | What it does | Creates an analysis? |
|---|---|---|
| **Replay Diagnostics** | Re-reads an analysis' stored pose with the current detector (Diagnostics screen). For a user-assisted analysis it shows both the replay with the user's recorded input and an **automatic replay** without it. | No |
| **Reanalyze Automatically** | Runs the current engine on the kick's original video with no manual contact or kick interval. "Try Again" is the same. | Yes, `pose-biomechanics-2.3.0` |
| **Reanalyze With Manual Contact** | Runs with the frame the user positioned on the manual-contact screen, for that run only. | Yes, `…+assisted` |

- A manual contact is held only by the run it was chosen for (`AnalysisRunMode`) and recorded in that analysis' files. It is never stored on the video or kick and never reused.
- The manual-contact screen opens at the automatic estimate but cannot submit until the user moves the video (`ManualContactSelection`).
- Evidence: `contactTimingBasis` is `automatic` or `user`; `contactTimingMethod` is `speedPeak`, `plantAndFootPassing` or `user`. Earlier 2.3.0 files that stored the method in `contactTimingBasis` are read correctly.
- **Delete Analysis** (results screen) removes the record, its results and its artifact folder (including any recorded manual contact). The video, the Photos original and other analyses stay. If it was current, the newest completed automatic analysis becomes current; an assisted one is never promoted implicitly.
- The Analyze screen forgets a finished run when its analysis is deleted or the kick's videos change, and always offers both reanalysis actions.
- Results and Diagnostics show the analysis mode, contact timing basis and engine version.

## Camera-aware analysis: rear, front and diagonal views (engine 2.4.0)

Before 2.4.0 the camera angle was used only to lower metric confidence. Every movement calculation assumed the kicker runs **across** the image, so a video filmed from behind always failed:

- no run-up was found from horizontal hip motion;
- the side-view leg repair deleted the backswing as a "jump";
- every surviving sagittal metric was halved in confidence.

Now:

- **Perspective** (`CameraPerspective.swift`) comes from the selected angle, checked against the movement. A side clip set to "rear" is analyzed as a side view and flagged; an unknown angle uses the movement.
- **Left/right labels** are checked against the facing direction (behind, in front, mirrored) and swapped back when the detector labeled the body as if it faced the other way.
- **Depth views** use their own signals and detector (`DepthViewPhaseDetection.swift`):
  - the run-up is a perspective approach rate (apparent size change, never a speed);
  - lengths are measured in each frame's own torso length;
  - contact is the bottom of the kicking foot's vertical swing after the backswing;
  - the plant is the plant foot at rest, timed from the run-up braking;
  - the follow-through is the foot's rise after contact.
- **Metrics** are limited to what the perspective shows (`PerspectiveMetricSupport`):
  - from behind or in front: plant→contact, follow-through duration, sideways trunk lean and plant-foot width;
  - diagonal: timings and speed ratios;
  - everything else is `cameraAngleUnsupported`.
- A depth or diagonal view with the kick found and at least 2 trustworthy measurements completes as **measurements only**, with no score. Side views still need a scored category.
- **Gates** (`AnalysisGates.swift`) record every checkpoint. They are shown in Diagnostics, stored in the manifest and written to the device log (subsystem `com.kicklab.app`, category `analysis`).

## Rear-view detection, outcomes, replay and drills (Step 12E, engine 2.5.0)

Engine `pose-biomechanics-2.5.0`; depth detector `depth-view-2`. Analyses from earlier engines are kept as they were and are only updated when you choose to reanalyze.

**Why the rear clip failed under 2.4.0.** Contact required one clean "bottom" of the foot's vertical swing. In the real exported rear clip the only candidate swing dropped 0.45 torso lengths after smoothing, just under the 0.5 requirement, so contact was ambiguous. Plant and follow-through were then searched relative to contact, and both failed too. The thresholds were **not** lowered.

**What depth-view-2 does instead.**

- **Plant** is found on its own: the plant leg's last swing must stop (speed drops to ≤ 35% of its peak and stays low), and the run-up braking is checked as a second cue. A chosen contact time never sets the plant; it only limits the search to before it. The plant is always labelled *estimated*.
- **Contact** uses five independent cues, scored per frame: the foot is at its lowest, a heel-high backswing just happened, the knee has just extended, the foot keeps moving, and the foot was dropping into the frame. Contact is the centre of the best full-scoring run. Two separate competing runs mean *not established*. The confidence is capped at 0.6, and every candidate is stored in diagnostics.
- **Follow-through** ends when the kicking foot's speed settles after its post-contact peak. The foot does not need to rise, so a rear view is no longer penalised for low leg travel.

**Outcome classes.** Every analysis now says which of these it is:

- full analysis;
- partial measurements;
- kick detected, timing uncertain;
- insufficient evidence;
- no kick detected;
- technical failure.

The class is shown in the results header and Diagnostics. Stored analyses get a class from their saved status, with no reanalysis.

**Replay.** The player has play/pause, ½× and ¼× speed, and single-frame steps (the video's own frames). The phase bar jumps to each marker and shows its source: detected, estimated, ambiguous, or *Your Contact*.

**Metric provenance.** Each metric row says one of:

- Measured from video;
- Estimated from video;
- Uses the contact you chose;
- Unavailable.

**Drill library.** There are 11 general drills across 11 focus areas. The results screen links up to 3 drills to the flagged mechanics areas. Every drill says it is general, not individually prescribed, and that you shouldn't train through pain.

**Validation status.** Tests replay the exported signals of the real rear clip, and the automatic plant, contact and follow-through are now found. This is evidence from exported signals only. It needs confirming on the device with the video itself.

## Contact intelligence, ball-aware groundwork, profiles, results and progress (Step 12F, engine 2.6.0)

Engine `pose-biomechanics-2.6.0`. Rear/front contact detector `contact-intelligence-3` (`ContactIntelligence.swift`). The side-view detector is unchanged (`contact-window-2`). Older analyses keep their engine version and results until you reanalyze.

**The rear-view contact error.** On the real rear clip, engine 2.5.0 put contact at 4.033 s. Stepping through the video, the user found the first foot–ball touch at 3.867 s, five frames earlier. 2.5.0's five "independent" cues were really one line of evidence counted several times:

- three of them (foot at its lowest, knee straight, foot dropping) describe the leg *finishing* its extension;
- that happens after the ball is struck.

**contact-intelligence-3** separates three events:

- **Strike approach**: the knee starts its fast extension.
- **First contact**: inside that drive, before the leg has straightened.
- **Post-contact swing**: the knee fully extended and the foot at its lowest.

How it works:

- **Two independent evidence groups.** The kicking leg's drive is one; the trunk's sideways lean peak (shoulders vs hips) is the other. They must overlap; if they disagree, contact is **not established**.
- **Confidence** follows the number of independent groups that agree (one: 0.35, two: 0.5), never the number of correlated cues. Without the ball it never exceeds 0.6.
- **Candidates and rejections** are recorded, including the 2.5.0 frame, marked "post-contact swing".
- **Plant** is still found on its own. **Follow-through** is measured from the new contact, so plant→contact and follow-through duration are recalculated.
- **Calibration caveat.** The design was prompted by this one clip, whose answer was known. Its rules come from kicking mechanics, not from the clip's numbers, but it needs more human-reviewed clips before anyone can call it validated.

**Ball-aware verification (groundwork).** `BallContactFusion` compares a football track with the pose interval:

- the ball's last resting frame and first moved frame;
- foot proximity;
- one-frame misdetections and occlusion.

The result is ball-aware, pose-only or a conflict, and a conflict marks contact uncertain. **The app has no football-recognition model**, so the tracker is `UnavailableBallTrackingService`. Every analysis records `ballEvidence = detectorUnavailable` and contact stays pose-only. Fusion is exercised only with clearly test-only observations.

**Verify Contact.** Step through the original video one real source frame at a time:

- frame numbers come from the video's own presentation timestamps (`SourceFrameTable`), including variable-frame-rate video;
- mark the first frame with visible contact, or **I can't tell**;
- see the difference from the automatic estimate in seconds and frames;
- correct or clear your answer.

Your answer is stored on the video as a reference (`contactTimeSource = manual` or `cannotTell`). It never changes an analysis and is never counted as automatic accuracy.

**Athlete profiles (schema V2).** New optional fields:

- nickname;
- photo (downscaled, stored on device);
- birth year;
- role (kicker / punter / both);
- experience;
- goals;
- preferred football.

Graduation year and team/school are now editable too. Athletes can be archived and restored, keeping all history.

**Results tracking (schema V2).** New optional entered fields on kicks:

- ball type;
- setup (tee, block, holder, ground, drop);
- wind/weather note;
- kickoff/punt direction;
- punt result and inside-20.

Field goals also gain a **Missed (other)** result. Sessions show statistics from their own kicks, with field goals, PATs, kickoffs and punts kept separate. Nothing is measured from video.

**Progress dashboard** (Stats → Progress Dashboard) has 30-day, 90-day and all-time views. Every figure comes from saved kicks:

- make % always shows attempts, with a small-sample note under 10;
- make % by distance band;
- longest make and personal bests;
- kickoff, punt and hang-time trends (Swift Charts);
- recent sessions and videos;
- training consistency.

Analysis trends only compare the same kick type, camera view and engine version. A new engine version starts a new line, and user-assisted runs are excluded.

**Coaching report.** The results screen opens with numbered sections:

1. what was analyzed;
2. whether a kick was found;
3. camera limits;
4. contact timing (automatic interval, provenance, your verification);
5. phase timeline;
6. measurements from this angle;
7. observed patterns;
8. areas worth reviewing;
9. drills;
10. previous comparable kicks.

Contact-specific advice is withheld when contact timing is uncertain. Informational metrics are labelled **Not validated**.

**Capture guide** (Profile → How to Film a Kick, and from every report) covers field goal, kickoff and punt × side, behind and in front. It shows each recent video's real recorded frame rate. No numeric camera distances are given, because there is no evidence for one.

**Diagnostics format 5.** The summary has a contact block:

- detector;
- interval and uncertainty;
- evidence groups;
- ball detector status and frames examined;
- provenance;
- the human-reviewed frame and its difference;
- plant and follow-through times;
- perspective and tracking;
- excluded metrics;
- outcome class.

**Share Summary** leaves out the per-frame arrays; **Share Full Diagnostics** includes them.

## Real-video contact accuracy and rear-view plant recovery (Step 12G, engine 2.7.0)

Engine `pose-biomechanics-2.7.0`. Rear/front contact detector `contact-intelligence-4`. The side view is unchanged. Schema V3 adds one optional column.

**Second real failure (IMG_1709).**
- **On the phone:** engine 2.6.0 confidently said contact was at 7.835 s. In that frame the foot is still swinging down to the ball.
- **In the real frames:** the foot is just behind the ball at 7.902 s and over the ball at 7.935 s. By 7.968 s the ball is in the air. You reviewed it as roughly 7.967–8.000 s.
- **Why:** 2.6.0 treated the start of the knee's fastest extension, and the trunk's sideways-lean peak, as first contact. On this clip both came about 3 frames before impact.

**contact-intelligence-4.**
- **Body pose finds a strike window**, not a contact time: from the start of the knee's drive to the frame where the leg has straightened.
- **Contact is only estimated** when that window is within ±0.05 s (the existing contact tolerance). Otherwise the analysis says **"Strike window identified — contact timing uncertain"**, nothing timed from contact is measured, and Verify Contact is offered.
- **Trunk lean** is recorded as a clue only. It never moves or narrows contact.

**Plant recovery.**
- **Why 2.6.0 missed it:** on the phone the run-up wasn't found, because the strike search began at the end of the run-up, which from behind comes *after* the kick. With no run-up, the plant search was skipped entirely.
- **Now, from behind:** the strike search starts no later than the run-up's peak.
- **When the run-up gives no plant**, the plant is searched in the 0.6 s before the knee drive, still from the plant foot's own swing and stop. It is never contact minus a fixed number of frames.

**Ball movement from the frames.**
- **What it does (engine 2.7.0):** Apple's frameworks have no football-recognition model, and 2.7.0 bundled none, so it didn't recognize the ball by itself (engine 2.8.0 adds a detector — next section). Instead, you mark the ball once in Verify Contact. KickLab then compares that spot frame by frame in the video and finds the last frame the ball was untouched and the first frame it was disturbed.
- **How it checks itself:**
  - it only looks near the ball you marked, so spare balls elsewhere are ignored;
  - it allows for slow camera drift;
  - the ball must stay gone (a passing foot or a one-frame glitch doesn't count);
  - a ball that never moves gives no contact.
- **Tested on IMG_1709's real frames:** untouched through 7.902 s, disturbed at 7.935 s.

**Verify Contact.**
- Steps through the video's real frames, with the times taken from the video itself.
- Shows full-resolution close-ups of the ball and foot, plus a strip of neighbouring frames.
- Marks first contact, the first frame the ball moves, and the plant frame (or "can't tell"), each compared with the automatic estimate in frames and milliseconds.
- Marks the ball and measures its movement.
- **Reanalyze With Verified Frames** creates a new analysis labelled user-assisted. Your marks are stored on the video (`VideoAsset.verificationData`) and never change an existing analysis or count as automatic accuracy.

**Results wording.** Results now distinguish:
- ball contact visually verified;
- contact estimated from body pose;
- strike window identified, contact timing uncertain;
- plant estimated, chosen by you, or not established;
- partial measurements;
- insufficient evidence.

Rear views still never get a score.

## Computer vision rebuild: automatic football detection (Step 12G, engine 2.8.0)

Engine `pose-biomechanics-2.8.0`. Pose (Apple Vision), the side view, scores and stored data are unchanged.

**A real football detector is now in the app.**
- `KickLab/Resources/Models/YOLOXSportsBall.mlpackage`: YOLOX-S (Megvii, Apache-2.0, trained on COCO), converted to Core ML by `Scripts/cv/convert_yolox_to_coreml.py`. COCO has no American-football class; its "sports ball" class is used. Details, licensing and limits: `Docs/FOOTBALL_DETECTOR_MODEL_CARD.md`, `THIRD_PARTY_NOTICES.md`, and Profile → Acknowledgements in the app.
- On the real IMG_1709 frames it finds the ball on the holder on every sampled frame from 2.6 s, the kicked ball in the air on the next frames, and the spare footballs on the left. That is one development clip, not a validation.

**How a video is analyzed (two passes).**
1. Body pose as before; the pose pipeline finds the strike.
2. Broad scan: a frame every 0.2 s through the detector. Footballs that rest in one place are grouped; the kicked ball is the one that is there before the strike, gone after it, and that the kicking foot reaches. Spare balls are rejected with the reason.
3. Precision pass: every frame around the strike — the detector on a crop around that ball, the ball's appearance, and the background (camera movement).
4. The pipeline runs again with the ball's evidence.

**What the ball can tell, and what it can't.** The last frame the ball is clearly at rest and the first frame it is seen moving away *constrain* contact: contact happened after the first and no later than the second. A box that jumps for a frame, a ball that comes back, a spare ball, or a detector that just stops firing is not movement. No speed, distance or hang time is derived from 2D video.

**Contact answers** (`ContactOutcome`, shown in results, diagnostics and the coaching report): ball-verified contact (one frame interval), ball-narrowed contact interval, pose-estimated contact, strike window only, contact uncertain, contact not found, contact chosen by you. A human-selected contact is always labelled as such and never counts as automatic.

**IMG_1709 now:** ball clearly at rest through 7.902 s, hidden under the foot at 7.935 s (no box is invented), seen moving at 7.968 s → contact narrowed to the frames 7.935–7.968 s (shown at 7.935 s), consistent with the body-pose strike; timing measurements are no longer withheld. Your review (7.967–8.000 s) begins at the interval's last frame (7.968 s), one frame after the frame shown; both human references are kept unchanged.

**Video Intelligence debugger** (Pose Validation): football boxes per examined frame (green at rest, yellow dashed obscured / appearance only, orange moving, grey another ball), the resting spot, the moving ball's detected positions only, "Ball last at rest" / "Ball first moved" markers, 1×/2×/3× zoom on the ball, plus the existing slow playback and frame stepping. Wrong ball? Verify Contact's ball marking is the user-initialized tracker and stays separate (labelled user-assisted).

**Evaluation tooling:** `Scripts/cv/annotation_schema.json`, `Scripts/cv/evaluate.py`, `Scripts/cv/run_detector.py`, `Datasets/annotations/` (both existing clips are development-only), `Docs/DATASET_PLAN.md`. No accuracy percentage is reported until held-out clips exist.

**Tests:** `FootballVisionTests` (Linux and Xcode; real detector output on real frames, plus labelled synthetic rules) and `FootballDetectorAppleTests` (Xcode only: the bundled Core ML model on two real ball crops vs the reference model, and the full video decode path).

## Contact reliability and the evidence system (build 15, engine 2.8.2)

- **Fixes from the build-14 device runs:** the ball-departure search skips frames that only look like movement; kicks at the very start of a clip are found from the ball when pose sees no run-up (and such clips no longer crash the kick-window search); plants after the ball left or long before it are rejected; on side views the ball narrows contact when ball and pose agree.
- **Evidence bundle** (Diagnostics → Evidence bundle): a ZIP with the analysis files, raw football detections, the recorded outcome and your marks (separately). No video or images unless you allow ball crops. Format: `Docs/EVIDENCE_BUNDLE_FORMAT.md`.
- **Replay:** `bash Scripts/evidence/replay.sh bundle.zip` re-runs the app's own analysis code on the bundle and reports any difference from what the phone recorded (`--baseline` compares engine versions). Sample: `Datasets/evidence/`.
- **Evidence timeline** in Pose Validation: ball state per frame, kicking-ankle speed, knee angle, plant candidates, kick window, pose strike window, ball-contact interval and the fusion verdict, with 2 s / 0.5 s zoom.
- **Verify Contact:** contact range, which football was kicked, and an automatic-vs-your-marks comparison. Your marks never change automatic results unless you reanalyze in assisted mode.

## Performance Report 2.0 and Contact Intelligence 2.9 (build 16, engine 2.9.0)

- **Kick Report (new default results screen):**
  - the technique score (provisional, whole numbers) only when the analysis supports one;
  - five areas with personal ranks and measurement quality;
  - up to 3 strengths and 3 issues, each issue with a cue;
  - 1–2 drills, or "record a clearer clip" when the analysis is limited;
  - your entered result, shown separately.
- **Detailed Analysis** is one tap away. Developer Diagnostics stay behind the diagnostics setting. See `Docs/PERFORMANCE_REPORT.md`.
- **Personal rankings** compare only your own kicks of the same type, filmed from the same view, scored by the same scoring model. No percentiles or benchmarks. See `Docs/PERFORMANCE_REPORT.md` for the rules.
- **Scoring audit:** what each score measures and its limits. See `Docs/SCORING_AUDIT.md`.
- **Contact Intelligence 2.9:**
  - every credible knee drive is compared with the ball's departure. A faster drive that started after the ball left is treated as follow-through, not the strike;
  - the acceptance rule is reported;
  - the ball's departure is classified (seen leaving / spot emptied / hidden / unclear);
  - contact confidence is split into separate rule-based measures (none is a probability).

## Biomechanics Intelligence 3.0 and Athlete Report 3.0 (build 18, engine 3.0.0)

- **Kick Report 3.0:**
  - your recorded result first;
  - a provisional technique score only when it's defensible — otherwise "Limited Technique Analysis" with the measurements that were established;
  - rated areas first, with limited-confidence areas clearly marked;
  - at most 2 strengths (each with a reason), 2 evidence-backed improvements and ONE training focus;
  - unavailable areas collapsed with reasons.
- **Detailed Analysis** is organized by phase in expandable sections. See `Docs/PERFORMANCE_REPORT.md`.
- **Rear/front views** measure where the plant foot lands beside the ball and how much it slides sideways. These are descriptive and compared with your own kicks; they are not scored.
- **Plant timing** is shown but no longer scored or coached: no validated criterion says which interval is better.
- **Contact confidence** separates whether contact happened from how precisely it is timed. A narrow interval alone never makes it "high".
- **Coaching insights** carry their evidence: supporting measurement, quality (confirmed / provisional), kick types, views, cue, and the metric to watch.
- **Diagnostics** add a frame-by-frame kicking-ankle report: measured, inferred, overlapping or unavailable.
- **Audits:**
  - `Docs/BIOMECHANICS_AUDIT.md` (every metric);
  - `Docs/SCORING_AUDIT.md` (scoring and confidence).

## Biomechanics Reliability 3.1 and Athlete Report 4.0 (build 19, engine 3.1.0)

- **Kicking-leg identity:** when Apple Vision puts both ankle labels on the plant foot (an abrupt stop level with the plant ankle that persists), the kicking ankle is marked lost from that frame. Kicking-ankle values at contact are withheld if it was lost at or before contact. Found on the real side reference clip (lost 2.367 s, contact 2.467 s unchanged).
- **Follow-through** is ankle-based only, with a state: observed / partly observed / inferred from the knee (limited) / not observed. The knee's own timing is the new descriptive "Knee swing after contact".
- **Camera motion:** background translation measured by the football stage is removed from plant-foot movement, sideways slide, body speed and body travel when it covers every sample used; otherwise those metrics are withheld when the camera moved.
- **Athlete Report 4.0:** torso-length units, clearer sideways names with the side in words, a context line per measurement, a measurement inspector over the contact frame, evidence and "what to watch" for every improvement, "For a better analysis" for recording advice, a note that the contact area is posture, and a bottom bar that no longer hides content.
- **History quality control:** cropped and blocking recordings are left out of measurement history; "Your usual" shows its count and SD; "improving" needs 6 eligible values and a meaningful change.
- **App icon:** the approved black-and-white placekicker icon replaces `AppIcon-1024.png` in the asset catalog.
- Scoring bands and thresholds unchanged (`provisional-bands-2`). See `Docs/RELEASE_NOTES_BUILD19.md`.

## Performance Intelligence 4.0 and Kick Comparison 1.0 (build 20, engine 3.1.0)

- **Three separate evaluations, never combined:**
  - **Technique** — provisional score, or "Not graded" with why;
  - **Consistency** — your own repeatability, or "Building baseline";
  - **Results** — what you entered.
- **Rear-view kicks are now useful without a grade:** every measurement shows your usual value (n, SD), the difference, and whether it is beyond measurement precision and your normal variation. Nothing is called better or worse.
- **Athlete Report 5.0:**
  - result and contact quality first;
  - a one-sentence headline;
  - up to three key findings;
  - coaching labelled by kind;
  - a measurable goal when there is nothing to correct.
- **Compare Kicks:**
  - two analyzed kicks side by side, synchronized at contact (precision shown, manual nudge for this comparison only);
  - frame stepping;
  - overlays (measured vs filled-in joints drawn differently);
  - a compatible-measurements table.
- **Personal Reference Kick** (your choice, one per kick type) and mechanics consistency on Progress.
- No score, band, weight or gate changed; no schema migration. See:
  - `Docs/GRADING_AUDIT.md`;
  - `Docs/CONSISTENCY_MODEL.md`;
  - `Docs/COMPARISON_FEATURE.md`;
  - `Docs/ANALYTICS_LIMITATIONS.md`;
  - `Docs/RELEASE_NOTES_BUILD20.md`.


## Training Sessions 1.0, two-camera foundation and Compare 1.1 (build 21, engine 3.1.0)

- **In-app camera:** *Record Single Kick* and *Start Training Session* on the Analyze tab
  (rear camera; 1080p60 default, 1080p120/4K where supported; it says before recording if it
  must use something else, and never records at a different frame rate than shown).
  Recordings stay on the iPhone. Sound and "save to Photos" are opt-in.
- **Training sessions:** one continuous recording of a practice; kick type, distance and hash
  can change between kicks; *Mark Kick* while recording. Kicks are found **after** recording
  (Stage A scan → Stage B = the existing analysis on a short clip of each kick). Every kick
  becomes a normal Kick with the normal report.
- **Session Review:** counts, one-tap results, corrections (add, not a kick, practice swing,
  clip start/end, contact, split, merge, reanalyze), results by distance and hash, and
  descriptive first/second-half trends (no fatigue claims).
- **Two cameras:** import a second recording, mark one shared event to synchronize, kicks are
  paired and counted once; watch both angles side by side. Only camera A is analyzed.
- **Ball flight (experimental):** image-space only, off by default, never scored.
- **Compare 1.1:** clean videos by default; overlays behind *Advanced Analysis* (all off);
  zoom to athlete with pinch/drag; tab bar no longer covers the controls.
- **Permissions:** camera; microphone only with *Record sound*; Photos add-only. No schema
  migration (SwiftData V3); session files live in `Application Support/KickLab/Sessions/`.
- **Not verified on an iPhone yet.** See:
  - `Docs/TRAINING_SESSIONS.md`;
  - `Docs/MULTI_KICK_DETECTION.md`;
  - `Docs/MULTICAMERA_FOUNDATION.md`;
  - `Docs/BALL_FLIGHT_LIMITATIONS.md`;
  - `Docs/RELEASE_NOTES_BUILD21.md`.

### Build 21 hotfixes

- **Hotfix 1:**
  - Watch Full Recording and Watch Clip;
  - clearer session status;
  - recordings made on this iPhone count as one camera.
- **Hotfix 2:**
  - Edit Contact and Save & Reanalyze on every session kick (a real user-assisted analysis;
    the automatic one is kept);
  - Session Diagnostics export;
  - measured clip timing;
  - camera view defaults to "not set";
  - net-practice setting;
  - Add Kick Here.

See `Docs/CONTACT_CORRECTION.md`, `Docs/SESSION_DIAGNOSTICS.md`, `Docs/NET_PRACTICE.md`.

## Build 25: Remote Cameras setup

- A tripod phone can go straight to camera mode without adding an athlete.
- Quality per camera, with a sideways check (banner on the camera, a warning and a confirmation before recording on the controller).
- Framing advice on each camera's screen. See `Docs/RELEASE_NOTES_BUILD25.md`.

## Build 24: Remote Cameras

- **Remote Cameras**: up to three tripod iPhones run KickLab as cameras, controlled from one iPhone. One Record / Stop for all of them, and Mark Kick reaches every recording. Videos go straight from phone to phone over Wi-Fi (no internet) and join the training session already synchronized: each camera's first frame is measured on the controller's clock.
- Three cameras in one session: a kick seen by side, rear and a third angle counts once, with its angles attached.
- Transport: Network framework (Bonjour, peer-to-peer Wi-Fi), with frames encrypted with Apple CryptoKit under a key from a six-digit pairing code. Info.plist adds the local-network purpose string and `NSBonjourServices`.
- Tested with synthetic clocks only; not yet on iPhones. See `Docs/REMOTE_CAMERAS_BUILD24.md`.

## Build 23: design refresh and Metric Tracker

- New look across Home, Kicks, the Kick Report and Progress: one KickLab palette, shared cards, tiles and section headers.
- **Metric Tracker**: every measurement kick by kick against its provisional target, grouped by kick type and camera view, with trends that need 4 consistent kicks. See `Docs/DESIGN_REFRESH_BUILD23.md`.

## Build 22: competitor validation

- Kicking-foot extremes (follow-through height, backswing depth, peak foot speed) are no longer reported when the foot touched the frame edge or was hidden where the extreme could be. Engine `pose-biomechanics-3.2.0`.
- Target ranges are labelled **provisional, not elite benchmarks**. See `Docs/BENCHMARK_AUDIT_BUILD22.md`.
- **Ball recognition without tapping** (strike-site change at the kicker's feet) and rear-view run-up discovery: `Docs/BALL_RECOGNITION_BUILD22.md`.
- **Kick Breakdown**: phase-by-phase grade, one priority fix and per-phase cards with frame, skeleton and target bars: `Docs/KICK_BREAKDOWN_BUILD22.md`. Scoring model `provisional-bands-3` (approach measured, not graded).
- Real-video validation against a frame-level ground truth: `Docs/COMPETITOR_VALIDATION_BUILD22.md` and `Datasets/reference/IMG_4541_IMG_6269_reference.json`. The emulation tooling is in `Scripts/realvideo/`.
