# KickLab — Steps 1–5 (data foundation + service layer)

Steps 1–4 contain project setup, the persisted enums, the eight SwiftData models with a
versioned schema and container, and the typed outcome / draft / validation layer.
Step 5 adds the authoritative service layer (`Services/`): KickService,
KickingSessionService, AthleteService and AnalysisService. There are no screens yet.

## Build and test in the cloud (no Mac needed)

GitHub Actions builds KickLab on a GitHub-hosted Mac with Apple's real Xcode and SDKs,
boots an iPhone Simulator, and runs every test, including the SwiftData tests. You never
need a physical Mac for this.

What runs: `.github/workflows/ios-tests.yml` → `Scripts/test-ios.sh`, which generates
`KickLab.xcodeproj` from `project.yml` with XcodeGen, builds, and runs `KickLabTests`.
The `.xcodeproj` is generated on every run and is not stored in the repository.

### A. Create a GitHub repository
1. Sign in at github.com → **+** (top right) → **New repository**.
2. Name it `KickLab`. Choose **Public** (macOS runner minutes are free for public
   repositories) or **Private** (macOS minutes count against your plan at a higher rate).
3. Leave "Add a README" unchecked → **Create repository**.

### B. Upload the files
Upload the **contents** of this folder so they sit at the top of the repository:

```
.github/workflows/ios-tests.yml
.gitignore
KickLab/            (all app sources)
KickLabTests/       (all tests)
Scripts/test-ios.sh
project.yml
README.md
```

On the new repository's page choose **uploading an existing file**, drag those items in,
and **Commit changes**. Afterwards check that `.github/workflows/ios-tests.yml` appears in
the file list: some computers hide folders whose names start with a dot. If it's missing,
use **Add file → Create new file**, type `.github/workflows/ios-tests.yml` as the name,
paste the file's contents and commit. (GitHub Desktop or `git push` work too.)

### C. See the result
Open the repository's **Actions** tab. Every push to `main` starts **iOS build and tests**;
you can also start it with **Run workflow**. A green check means the app built and every
test passed; a red X means something failed. The run page shows a short summary (Xcode
version, simulator, warning count, tests passed/failed).

### D. Download failure logs
On the run page, scroll to **Artifacts** and download `kicklab-test-logs-<number>`. It contains:
- `logs/build.log` and `logs/test.log`: full xcodebuild output
- `logs/warnings.txt`: every unique compiler warning
- `logs/summary.md`: the summary shown on the run page
- `KickLab.xcresult`: Xcode's result bundle (only useful if you later have a Mac)

The raw step output is also available from the run page's **⋯ → Download log archive**.

### E. No physical Mac required
Everything above runs on GitHub's hosted macOS machines. On any Mac with Xcode you can run
the same thing locally with `bash Scripts/test-ios.sh`.

## Data semantics (summary)

- **Field position** (`spotDistanceToTargetGoalLine`, 0–100): yards from the goal line the
  kick travels toward — Opp 30 = 30, midfield = 50, own 40 = 60, own 20 = 80, kickoff teed
  at own 35 = 65. Never shown raw: `FieldGeometry.footballNotation(...)` gives "Opp 30",
  "50", "Own 40". `landingYardLine` uses the same reference; negative = in the end zone.
- **Distance**: FG/PAT = actual hold-to-goal-plane distance (Opp 30 ≈ 40 yards);
  kickoff = ball travel; punt = punt distance. The spot never overwrites distance;
  `FieldGeometry.estimatedFieldGoalDistance` is a display helper only.
  Display example: "Hold: Opp 30 · Distance: 40 yd".
- **Accuracy** (normalized, never pixels; kicker's perspective): x −1 = left upright,
  0 = center, +1 = right upright, beyond ±1 = outside. y uses the same unit, 0 = crossbar,
  positive = above, `nil` when unknown.
- **Provenance**: distance, accuracy, landing and hang time each store a source
  (`OutcomeMeasurementSource`) and optional 0...1 confidence. Manual entries carry no confidence.
  `primaryVideo` / `secondaryVideo` / `multiVideo` describe the *kind* of provenance, not the
  exact `VideoAsset`; exact source-video links are added when video analysis begins.
