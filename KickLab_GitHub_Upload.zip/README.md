# KickLab — Steps 1–11 (data foundation, services, media, statistics, pose, biomechanics, app UI, personal coach, TestFlight)

Steps 1–4: project setup, persisted enums, the eight SwiftData models (versioned schema),
and the typed outcome / draft / validation layer.
Step 5: the authoritative service layer — KickService, KickingSessionService,
AthleteService, AnalysisService.
Step 6: `VideoStorageService` + `ManagedMediaStore` (video files under
`Application Support/KickLab/Media/`, analysis artifacts under `.../Analysis/`, never in
SwiftData), `StatisticsService` (real statistics from stored kicks), the
`VideoAnalysisService` contract with an `UnavailableVideoAnalysisService`, and the
`AppServices` composition root.
Step 7: the on-device pose and kick-phase foundation (see "Pose analysis" below).
Step 8: biomechanics metrics, category scores and rule-based coaching (see "Biomechanics" below).
Step 9: the first complete app interface (see "App interface" below).
Step 10: the personalized learning coach (see "Personal coach" below).
Step 11: iPhone beta deployment through TestFlight (see "TestFlight beta" below).
Step 12A: analysis diagnostics for real-device failures (see "Analysis diagnostics" below).

## Build and test in the cloud (no Mac needed)

GitHub Actions builds KickLab on a GitHub-hosted Mac with Apple's real Xcode and SDKs,
boots an iPhone Simulator, and runs every test, including the SwiftData tests. You never
need a physical Mac for this.

What runs: `.github/workflows/ios-tests.yml` → `Scripts/test-ios.sh`, which generates
`KickLab.xcodeproj` from `project.yml` with XcodeGen, builds, and runs `KickLabTests`.
The `.xcodeproj` is generated on every run and is not stored in the repository.

### A. Create a GitHub repository
1. Sign in at github.com → **+** (top right) → **New repository**.
2. Name it `KickLab`. Choose **Public** (macOS runner minutes are free for public
   repositories) or **Private** (macOS minutes count against your plan at a higher rate).
3. Leave "Add a README" unchecked → **Create repository**.

### B. Upload the files
Upload the **contents** of this folder so they sit at the top of the repository:

```
.github/workflows/ios-tests.yml
.gitignore
KickLab/            (all app sources)
KickLabTests/       (all tests)
Scripts/test-ios.sh
project.yml
README.md
```

On the new repository's page choose **uploading an existing file**, drag those items in,
and **Commit changes**. Afterwards check that `.github/workflows/ios-tests.yml` appears in
the file list: some computers hide folders whose names start with a dot. If it's missing,
use **Add file → Create new file**, type `.github/workflows/ios-tests.yml` as the name,
paste the file's contents and commit. (GitHub Desktop or `git push` work too.)

### C. See the result
Open the repository's **Actions** tab. Every push to `main` starts **iOS build and tests**;
you can also start it with **Run workflow**. A green check means the app built and every
test passed; a red X means something failed. The run page shows a short summary (Xcode
version, simulator, warning count, tests passed/failed).

### D. Download failure logs
On the run page, scroll to **Artifacts** and download `kicklab-test-logs-<number>`. It contains:
- `logs/build.log` and `logs/test.log`: full xcodebuild output
- `logs/warnings.txt`: every unique compiler warning
- `logs/summary.md`: the summary shown on the run page
- `KickLab.xcresult`: Xcode's result bundle (only useful if you later have a Mac)

The raw step output is also available from the run page's **⋯ → Download log archive**.

### E. No physical Mac required
Everything above runs on GitHub's hosted macOS machines. On any Mac with Xcode you can run
the same thing locally with `bash Scripts/test-ios.sh`.

## Data semantics (summary)

- **Field position** (`spotDistanceToTargetGoalLine`, 0–100): yards from the goal line the
  kick travels toward — Opp 30 = 30, midfield = 50, own 40 = 60, own 20 = 80, kickoff teed
  at own 35 = 65. Never shown raw: `FieldGeometry.footballNotation(...)` gives "Opp 30",
  "50", "Own 40". `landingYardLine` uses the same reference; negative = in the end zone.
- **Distance**: FG/PAT = actual hold-to-goal-plane distance (Opp 30 ≈ 40 yards);
  kickoff = ball travel; punt = punt distance. The spot never overwrites distance;
  `FieldGeometry.estimatedFieldGoalDistance` is a display helper only.
  Display example: "Hold: Opp 30 · Distance: 40 yd".
- **Accuracy** (normalized, never pixels; kicker's perspective): x −1 = left upright,
  0 = center, +1 = right upright, beyond ±1 = outside. y uses the same unit, 0 = crossbar,
  positive = above, `nil` when unknown.
- **Provenance**: distance, accuracy, landing and hang time each store a source
  (`OutcomeMeasurementSource`) and optional 0...1 confidence. Manual entries carry no confidence.
  `primaryVideo` / `secondaryVideo` / `multiVideo` describe the *kind* of provenance, not the
  exact `VideoAsset`; exact source-video links are added when video analysis begins.

## Pose analysis (Step 7 foundation)

Everything runs on the device. Video is never uploaded. KickLab tracks **body pose only**:
no face recognition, identity recognition or biometric identification.

Pipeline (`Services/Pose/`):
1. `VideoFrameReader` (AVFoundation) streams frames with true timestamps;
   `FrameSampler` keeps every frame, a target rate (default 60 fps) or a time range.
2. `VisionPoseSequenceExtractor` runs Apple Vision body-pose detection (19 joints, several
   people, per-joint confidence) and converts to app coordinates (upright, top-left origin,
   0…1; see `PoseModel.swift`).
3. `PoseTracker` follows people frame to frame and selects the kicker. A manual
   `KickerSeed` always wins; otherwise ambiguous cases report "multiple possible kickers"
   and select nobody.
4. `PoseTimelineProcessor`: confidence threshold → short-gap interpolation only →
   light smoothing; every point is `measured`, `interpolated` or `unavailable`.
5. `PoseSignalExtractor` derives speeds (body lengths/s), angles and lean, using the
   athlete's kicking foot (no right-foot assumption).
6. `KickPhaseDetector` finds setup, approach, plant, contact and follow-through.
   Without ball tracking, contact is always `estimated`. FG/PAT and kickoff are fully
   supported; punts are limited (contact and follow-through only).
7. Versioned JSON artifacts are written to `Analysis/<analysis-id>/`
   (`manifest.json`, `pose-v1.json`, `signals-v1.json`, `phases-v1.json`).

`PoseVideoAnalysisService` is the real `VideoAnalysisService`; `KickAnalysisRunner`
records a run through `AnalysisService`.

## Biomechanics (Step 8)

Pure Swift in `Services/Biomechanics/`, fully tested on Linux:

- `KickMetricCatalog`: 17 metrics (approach, plant, swing, body position at contact,
  follow-through). Sizes are in **body lengths** (torso length) and speeds in body lengths
  per second; no mph, m/s, yards, force, ball speed or launch angle is ever reported.
- `KickMetricExtractor`: reads Step 7 phases; a metric whose phase is missing is
  `unavailable` (never zero, never a substitute timestamp); ambiguous phases lower confidence.
- `MetricConfidenceModel`: confidence = joint quality × phase factor × sample factor ×
  frame-rate factor × camera factor, with every factor stored for explanation.
- `KickScorer`: explicit 0–100 bands per metric and confidence-weighted category scores;
  hidden joints lower confidence, not the score.
- `CoachingEngine`: rule-based IMPROVE + CUE and KEEP observations, issued only with enough
  confidence, ranked deterministically and capped (3 IMPROVE, 2 KEEP).
- `MetricComparison`: kick-vs-kick, athlete baseline and trend foundations.
- `BiomechanicsProfile`: every threshold, per kick type, ready for later tuning by level,
  baseline or camera angle.

Results are stored through `AnalysisService.recordResults` (one validated save), the
analysis is completed and promoted to current, and `biomechanics-v1.json` is added to the
artifact set (manifest format v2; v1 manifests remain readable).


## App interface (Step 9)

Five tabs: **Home, Kicks, Analyze, Stats, Profile**, each with its own navigation stack.
Several athletes can be stored; the switcher at the top of each tab changes the selected
athlete, which is remembered between launches.

Layers (screens never touch the database or files directly):
- `Presentation/` — pure Swift, tested on Linux: display formatting, results and coaching
  presentation, dashboard aggregation, the manual kick-entry form, the analysis state
  machine, statistics sections and the rule-based personal insights.
- `ViewModels/` — `@Observable` main-actor view models that call the Step 5–8 services
  through `AppServices` and turn stored records into presentation values.
- `UI/` — thin SwiftUI views.

Personalization is rule-based and replaceable (`PersonalInsightsProviding`). With fewer
than 3 analyzed kicks of a type KickLab says "More kicks are needed before KickLab can build
your personal baseline." and draws no personal conclusions. Video import (Photos or Files)
always goes through `VideoStorageService`; Photos originals are never changed. Camera
capture is not built yet (`VideoSourceType.captured` is ready for it).

## Personal coach (Step 10)

`Services/Personalization/` learns each athlete's mechanical fingerprint with transparent,
deterministic statistics on their own stored kicks — not machine learning, nothing leaves
the phone. It sits on top of the Step 8 rules and never replaces them.

- **Profiles** per kick type and kicking foot (camera angle, field-goal distance bucket and
  baseline epoch when relevant): mean, median, SD, robust spread, quartiles, recent and
  recency-weighted baselines, the successful-kick pattern, consistency and trends.
- **Eligibility**: completed analyses only; metric confidence ≥ 0.5; same kick type, foot,
  definition version and (for angle-dependent metrics) camera angle. Missing is never zero.
- **Maturity**: < 3 kicks insufficient, 3–7 emerging, 8–19 established, 20+ strong.
- **Coach**: combines Step 8 findings with personal evidence (successful pattern, makes vs
  misses, normal, consistency, trend), resolves conflicts explicitly, ranks with a capped
  priority score, and keeps every Step 8 observation (re-ranked with its reason).
- **Storage**: profiles are rebuilt on demand from the stored analyses (no learned state).
  Each completed analysis gets `personalization-v1.json`: what KickLab knew at that moment.
- Every threshold is in `PersonalizationConfiguration`.

## TestFlight beta (Step 11)

`Deployment/TESTFLIGHT.md` is the complete setup guide (Apple Developer, App Store Connect,
GitHub secrets, uploading, installing). `Deployment/BETA_TEST_PLAN.md` is the first-device
test plan.

- **Two workflows.** `ios-tests.yml` builds and tests without credentials, unchanged.
  `ios-testflight.yml` (reference copy in `Deployment/`, installed as
  `.github/workflows/ios-testflight.yml`) runs only when started by hand.
- **What the deployment does:** checks settings → Xcode 26+ → XcodeGen → unsigned
  archive → signed export (cloud signing, or manual) → verify → `altool` validate and
  upload → clean up.
- **Scripts:** `Scripts/testflight/` holds the steps. `bash Scripts/testflight/selftest.sh`
  tests them without any Apple account.
- **Identity:** `com.kicklab.app`, version 0.1.0; the build number is the run number.
  iPhone only, iOS 18+, category Sports.
- **No credentials in the repository.** Settings live in GitHub Actions secrets and
  variables, and signing material exists only during a run.

## Analysis diagnostics (Step 12A)

**Turning it on:** Profile → Developer → **Analysis diagnostics**. A **Diagnostics** screen
then appears:
- on every analysis result (toolbar)
- under a failed analysis on the Analyze screen

**What it shows:**
- frames sampled, Vision failures, frames with a person, and frames with the kicker
- manual or automatic kicker selection
- hip, knee and ankle detection counts and confidence
- the camera angle and kicking foot used
- each phase's status
- why every metric was or wasn't available, with its confidence factors
- each category's score or the reason it wasn't scored
- the diagnosed cause

**Privacy and sharing:** the report is built on the iPhone from the stored analysis files.
It holds no images, body coordinates or names. **Share or Save** / **Copy** exports it as
text plus JSON (Files, Notes, Mail, AirDrop); nothing is uploaded otherwise.

**Specific failure causes** (`AnalysisFailureCause`), each with its own message, replace
the old catch-all "Not enough of the kick was visible":
- kicker tracked too briefly
- plant or contact not found
- camera angle limits measurement
- low pose confidence
- legs not visible
- partial measurements only
