# KickGuru — Step 12G release notes (engine 2.7.0)

## Fixed
- **Rear-view contact no longer confidently wrong.** Body pose now reports a strike window. Contact is only called when the window is within ±0.05 s; otherwise the analysis says contact timing is uncertain. On IMG_1709 this replaces the false 7.835 s.
- **Rear-view plant found without a detected run-up** (it was missing on IMG_1709).
- **Rear-view run-up found** even when the kicker keeps travelling through the kick.

## New
- **Ball movement from the video's frames:** you mark the ball once, and KickLab finds the frame the ball is first disturbed.
- **Verify Contact:** close-ups, a strip of neighbouring frames, and marks for contact, first ball movement and plant, each compared with the automatic estimate in frames and milliseconds. **Reanalyze With Verified Frames** runs a user-assisted analysis from them.
- **Clearer contact and plant status** in results and diagnostics.

## Not included
- **Automatic football recognition.** No suitable model is available in Apple's frameworks or in the project, so none is claimed.

## Data
- **Schema V3** adds one optional column (`VideoAsset.verificationData`), with a lightweight migration from V2. Nothing is deleted.
