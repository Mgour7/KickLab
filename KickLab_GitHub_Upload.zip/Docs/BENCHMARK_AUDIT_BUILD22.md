# Benchmark and score audit (Build 22)

## Build 22 change: the approach is measured, not graded (`provisional-bands-3`)

The three approach measurements have weight 0 for every kick type (kickoff included), so the
approach no longer contributes to an area score or the technique score. Reasons:

- none of the three bands has a source;
- on the IMG_4541 side-view kicks, speed variation scored a normal acceleration from a standing
  start as a fault (validation §6.6), and from a low or diagonal camera the approach runs partly
  along the line of sight, so its image speed is not a body speed;
- the approach-rhythm coaching rule is off unless a profile sets
  `CoachingThresholds.approachRhythmCoaching = true`.

The app still shows the approach values ("Measured, not graded: compared with your own kicks").
Stored analyses keep the scores they were given; area and overall comparisons across the change
are limited by `ScoringModel` (`changedInBands3 = [.approach, .overall]`), so an old overall
score is never ranked against a new one.

## Sources of the ranges

**KickLab has no sourced benchmark.** Every "ideal" band in `BiomechanicsProfile.placeKickScoring` (scoring model `provisional-bands-3` from Build 22; `provisional-bands-2` before) is an *initial, provisional value*. Each band was chosen for a single-camera 2D pose in torso-length units so that a score can be explained. None is derived from:

- measured college or NFL kickers;
- published biomechanics data;
- validated outcome data.

Build 22 relabels them in the app:

| Where | Before | After |
|---|---|---|
| Per-metric reference row | "General technique target" | "Provisional target (not an elite benchmark)" |
| Coaching cards | "General Target" | "Provisional Target" |
| Coaching text | "general target range" | "provisional target range" |
| Code comment | "expert-defined ideal band" | corrected |

| Metric (field goal) | Ideal band | Zero-score limits | Weight | Source |
|---|---|---|---|---|
| Approach speed (torso lengths/s) | 2.5–7 | 0.5 / 12 | **0** (bands-3; was 1) | none (provisional) — measured, not graded |
| Approach speed variation (%) | 0–20 | — / 60 | **0** (bands-3; was 1) | none. Penalised the normal acceleration from a standing start (see validation §6.6) — measured, not graded |
| Late approach speed change (%) | −15 to 25 | −60 / 80 | **0** (bands-3; was 1) | none — measured, not graded |
| Plant foot drift (torso lengths) | 0–0.1 | — / 0.6 | 1.5 | none |
| Plant knee angle at contact (°, 2D) | 135–170 | 95 / 200 | 1 | none. Side view only. |
| Kicking knee angle at contact (°, 2D) | 145–180 | 90 / — | 1.5 | none. Side view only. |
| Kicking hip angle at contact (°, 2D) | 130–180 | 80 / — | 0.5 | none. Side view only. |
| Backswing depth (torso lengths) | 0.8–2.5 | 0 / 4 | 1 | none |
| Peak foot speed (torso lengths/s) | ≥ 20 | 4 / — | 1 | none |
| Torso lean at contact (°) | −15 to 5 | −40 / 30 | 1.5 | none |
| Torso lean range (°) | 0–15 | — / 45 | 1 | none |
| Body forward speed at contact | 0.5–4 | −1 / 10 | 1 | none |
| Follow-through duration (s) | 0.15–0.5 | 0.05 / 1.0 | 1 | none |
| Follow-through foot height (torso lengths) | 0.5–3 | −1 / 5 | 1 | none |
| Follow-through body travel | 0.1–1.5 | −0.3 / 3 | 1 | none |

Not scored: plant-to-contact time (descriptive only since Build 18), the frontal-plane rear-view metrics, and foot speed at contact (weight 0).

## How the score is calculated

1. **Metric score (0–100).** It is 100 inside the band and falls linearly to 0 at the zero limits. A metric enters scoring only if its confidence is at least 0.35 and the camera perspective supports it.
2. **Category score.**
   - It is Σ(weight × confidence × metric score) ÷ Σ(weight × confidence).
   - It is computed only when at least 50 % of the category's weight is available and the category confidence is at least 0.35.
3. **Overall.** The unweighted mean of the available category scores, with at least 3 categories required. Its confidence is reduced by coverage.

## Limitations

- The score measures agreement with provisional 2D bands. It is **not** a measure of:
  - kicking distance;
  - accuracy;
  - make probability;
  - recruiting level;
  - NFL readiness.
- It is not a percentile.
- Scores from different camera views measure different subsets of the kick and are not comparable.
- A category can be scored from a subset of its measurements, shown as "Based on n of m".

## Kicker AI's "Elite" ranges

The screenshots give no source and no angle convention for 141–170°, 70–90°, 20–30° or 60–80°. They are treated as **unverified claims**. KickLab does not adopt them.

## What a real benchmark would need

1. Reference kicks of documented-level kickers recorded in the same view, at 60+ fps.
2. Identical metric definitions.
3. Per-view distributions.
4. A check that the measured differences relate to outcomes.

Until then, KickLab compares a kick with the athlete's own kicks and with provisional bands only.
