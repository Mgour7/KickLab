# Multi-Kick Detection (Build 21)

> **Status.** Stage A's logic is tested on **synthetic** scan data only (Linux). The
> thresholds below are reasoned starting values, **not tuned on real practice footage**.
> The Core ML / Vision scanner compiles against stand-ins and has an Apple-runtime test on
> a blank generated video (nothing to find); it has not been run on a real session. Expect
> missed and false candidates until real sessions are reviewed. Everything Stage A finds can
> be corrected by hand.

## Why two stages

KickLab's contact detector (engine pose-biomechanics-3.1.0) assumes **one kick per clip**.
It is never run over a whole session. Instead:

1. **Stage A — discovery** scans the whole recording cheaply and proposes candidate
   moments.
2. **Stage B — verification** cuts a short clip around each candidate and runs the
   **existing, unchanged** analysis on it. Scores, gates, bands and contact rules are the
   same as for an imported single kick.

## Stage A — discovery (`KickDiscovery`)

One decode pass at about **5 frames per second** (`SessionScanSettings.framesPerSecond`).
Per frame: YOLOX-S football boxes (full frame) and one Vision body pose (the largest person:
ankles, hip centre, torso length). Frames are released as they're read, so memory stays
flat for a 30-minute recording. Results are cached in `scan/<source>.json`, so corrections
and reanalysis never rescan.

A kick's signature is **a ball at rest that leaves its spot quickly while a foot moves fast
next to it**:

| Step | Rule (provisional values) |
|---|---|
| Ball boxes | score ≥ 0.3 |
| Ball at rest | stays within 0.6 ball widths of its median position for ≥ 0.6 s |
| Ball left | not seen within 2 ball widths of the spot during the next 1 s (a ball seen there again — e.g. a leg hid it — **didn't** leave) |
| Handled / rolled | seen moving away slower than 6 ball widths/s → "placed, picked up or rolled" |
| Swing | ankle speed ≥ 5 torso lengths/s between scan frames, within ±0.5 s of the departure, ankle within 1.5 torso lengths of the spot |
| Approach | hips travelled ≥ 0.5 torso lengths in the 5 s before |
| Separation | candidates closer than 4 s are one kick (the stronger is kept) |

**Evidence score:** ball departed +2; swing at the ball +2 (a fast swing elsewhere +1);
approach seen +1; a manual mark within 3 s +1.

- **Score ≥ 4 with departure + swing at the ball** → `pending` (verified automatically).
- **Score 2–3** → `needsReview` (listed, not analyzed until the athlete taps *It's a Kick*).
- **Below 2** → not listed.
- **Handled/rolled ball with no swing at it** → dropped. Walking and retrieving the ball
  produce no fast ankle swing at the spot, so they don't qualify.
- **Fast swing with no ball departure** → `needsReview` with "possibly a practice swing, or
  the ball wasn't visible". The athlete can mark it **Practice Swing**.
- **Manual marks** strengthen a nearby candidate; a mark alone is never counted as a kick.
  Unmatched marks are offered in Session Review (**Find Kick** / **Dismiss**).

## Clip boundaries (`ClipBoundaryPolicy`)

| | Before contact | After contact |
|---|---|---|
| Preferred | 4 s (earlier if the approach started earlier) | 3 s |
| Range | 3–5 s | 2–4 s |
| Never cut inside | 1.5 s (plant and strike) | 1.0 s (strike and ball departure) |

- Clips stay 1 s clear of the previous kick's contact, **unless** that would cut into the
  protected window — the protected window always wins (clips may overlap).
- Clips are limited by the start/end of the recording.
- A clip with less than 3 s before or 2 s after is flagged **approach incomplete** /
  **follow-through incomplete** and shown on the kick row.
- Clips are cut by passthrough (`AVAssetExportSession`, no re-encoding), so frames are the
  original frames. AVFoundation writes an edit list so the clip's time 0 is the requested
  start; the exported duration is read back and recorded. The exact frame alignment of
  passthrough trims on iPhone HEVC recordings is **unverified on a device** (checklist item).

## Stage B — verification (`CandidateVerification`)

The clip becomes a normal Kick (`KickService.createKick`, `VideoStorageService.importVideo`)
and `analysisRunner.run` analyses it. The analysis's contact (clip time) is mapped back to
the source: `source = clipStart + clipTime`.

| Analysis contact | Candidate becomes |
|---|---|
| Ball-verified or ball-constrained | **confirmed** |
| Pose-estimated, or chosen by the athlete | **probable** |
| None / failed | **needs review** |

A contact the athlete confirmed by hand is never overwritten by reanalysis. Detection
confidence shown on the row is the Stage A evidence plus this classification — it is not a
probability.

## Corrections (all non-destructive; provenance kept)

| Action | Effect |
|---|---|
| Add Missed Kick | pick the contact frame (frame stepping) → manual candidate, provenance "user" |
| It's a Kick | a needs-review candidate is accepted and queued |
| Not a Kick / Practice Swing | candidate marked; the recording is untouched; its Kick (if any) is removed after confirmation unless another active kick shares it |
| Clip start / end | re-cut on next analysis (validated: contact stays inside, protected windows respected) |
| Confirm contact | the athlete's frame; provenance "user"; status "probable" or better |
| Split | one candidate → two (only before it was analyzed) |
| Merge with next | two candidates → one (validated before anything changes) |
| Reanalyze | reuses the same Kick and clip — never a duplicate |

Every change is written to the manifest's log with a time.

## Queue (`SessionProcessingQueue`)

- Bounded: **one kick at a time**, foreground only, persisted in the manifest.
- **Pause / Resume.** Pausing is also the cancel: the current step is cancelled where it
  can be, nothing further runs until Resume, and nothing already done is undone. (There is
  no separate "Cancel" button.)
- A failure is retried once; after 2 attempts the kick is *failed* (and needs review).
- **Recovery:** at launch, anything *running* goes back to *queued*, an interrupted scan
  restarts, and recordings that were still being written are kept as *recovered*.
- **iOS suspension:** processing stops when KickLab goes to the background (iOS would
  suspend it anyway) and resumes when the athlete returns to the session.
- A second camera's candidates wait until that camera is synchronized or set to "keep
  separate" (see `MULTICAMERA_FOUNDATION.md`).

## Known gaps

- No live (during-recording) detection; the count fills in after Stop.
- Thresholds unvalidated on real footage. Partially visible balls, crowded fields, several
  kickers, holders' hands and very far cameras are the likely failure cases.
- Only the largest person is read per frame; with several athletes, swings by others may
  be missed or misattributed.
- Kickoffs off a tee and punts (no ball at rest on the ground, or ball dropped from hands)
  are weakly supported by the rest/departure rule; punts will mostly need manual marks.
