# Release notes — Build 19 (engine pose-biomechanics-3.1.0)

**Biomechanics Reliability 3.1 + Athlete Experience 4.0 + app icon.** Bundle ID `com.kicklab.app`, SwiftData V3 (no migration), both GitHub workflows, the TestFlight process, the YOLOX-S model and its notices, Evidence Bundle v1 and developer diagnostics are unchanged.

## Measurement
- **Kicking-ankle identity** (`KickingAnkleIdentity`): an abrupt stop (≥ 50% → ≤ 35% of the strike peak within two frames) level with the plant ankle that persists (≥ 60% of 0.2 s) marks the kicking-ankle label as lost. Root cause found on the real side clip's Apple Vision series: lost at 2.367 s, before contact at 2.467 s.
- Kicking knee angle and kicking-foot speed at contact are withheld when the identity was lost at or before contact.
- **Follow-through** is ankle-only. States: observed / partly observed / inferred from the knee (limited) / not observed. A lost foot that reappears still moving (≥ 50% of the peak) within 0.5 s of contact gives a partly observed follow-through; nothing is interpolated through the overlap and no timeout is used as an end.
- **New descriptive metric:** "Knee swing after contact" (`followThrough.kneeSwingDuration`), side view only, never scored.
- **Camera compensation** (`CameraShiftSeries`): measured background translation (from the football stage) is removed from plant-foot movement, plant-foot sideways slide, body speed through the ball and body travel when it covers every sample used (gaps ≤ 0.07 s). Camera moved but not covered, or zoom suspected → `cameraMoving`. No camera data → behaviour unchanged.
- **Kicking-leg diagnostics:** per frame measured / inferred / occluded / ambiguous / unavailable, original vs processed position, shank ratio (outside 0.6–1.4 → ambiguous), label swaps repaired, cause and phase effects.
- Contact detection unchanged; the five reference contacts are regression-tested (see the engineering report for which are real).

## Athlete Report 4.0
- "Torso lengths" everywhere; clearer names; side in words for sideways values.
- A context line on every measured row; a tappable measurement inspector for the two sideways plant measurements.
- Improvements show evidence, quality, why, cue and what to watch.
- "For a better analysis" for recording advice; "Next training focus" only for measured coaching.
- Contact area note: posture, not foot-to-ball impact.
- Bottom actions in a safe-area inset (no overlap with the tab bar).

## Personal history
- Cropped (contact ≤ 0.6 s) and blocking-quality recordings are excluded, with counts.
- "Your usual" from ≥ 3 earlier eligible recordings, with n and SD; "improving" needs ≥ 6 values and the metric's minimum meaningful difference.

## App icon
- `KickLab/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png` replaced with the approved design (white placekicker and football on black, 1024 × 1024, opaque). The asset catalog entry and `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon` are unchanged, so Xcode generates every home-screen size from it and the TestFlight build carries it.

## Scoring
- Unchanged bands, weights and thresholds (`provisional-bands-2`, mapped for 3.1). Scores remain comparable with 3.0.
