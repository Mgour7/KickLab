# Release notes: Build 22 (engine pose-biomechanics-3.2.0)

This is a focused build arising from the competitor validation (`Docs/COMPETITOR_VALIDATION_BUILD22.md`).

## Changed

### Kicking-foot extremes are withheld when the video didn't show them

Three measurements take an extreme of the kicking foot's path:
- follow-through foot height;
- backswing depth;
- peak foot speed.

Each is now "Not measured" (reason `kickingFootNotFullyVisible`) in either case:
- the kicking ankle touched the frame edge (2 % margin) in the measurement window;
- for height and depth, the extreme sat next to frames where the foot was missing or gap-filled.

On real practice footage, the foot left the frame above the hip and the old value read up to 0.87 torso lengths *below* the hip.

### Benchmarks are labelled as provisional

The target ranges now read "Provisional target (not an elite benchmark)" and "Provisional Target".

### Engine version and scoring model

- The engine version is 3.2.0.
- The scoring model is unchanged (`provisional-bands-2`). Engine 3.2 is mapped to it, so scores stay comparable with 3.0 and 3.1.

## Unchanged

- Bundle ID `com.kicklab.app`, signing, workflows.
- SwiftData schema V3, stored data.
- Scoring bands, weights and thresholds.
- Contact detection and Stage A discovery.
- The IMG_1709 evidence replay is identical.

## Verification

| Check | Result |
|---|---|
| Linux `swift test` | 815/815 pass (5 new: `FootVisibilityBuild22Tests`) |
| Model, UI and Apple-framework stand-in typechecks | build |
| Real-video emulation (MediaPipe + ONNX YOLOX-S, not the app) on IMG_4541 | the 4 negative follow-through heights become unavailable |
| Xcode build, Apple-runtime tests (182), device | **not run** |

## Developer tooling

`Scripts/realvideo/` is a real-video emulation harness. `Datasets/reference/IMG_4541_IMG_6269_reference.json` is a frame-level ground truth: no video, no images.
