# Release notes: Build 22 (engine pose-biomechanics-3.2.0)

This build arises from the competitor validation (`Docs/COMPETITOR_VALIDATION_BUILD22.md`) and Matt's direction: recognize the ball without tapping, and grade and coach kicks better than Kicker AI.

## New

### The ball is recognized without tapping
Strike-site recognition finds the kicked ball from the image change at the kicker's feet when the detector can't, and times contact from it. Session discovery also finds run-ups filmed from behind. See `Docs/BALL_RECOGNITION_BUILD22.md` (emulated on real footage: ball found on 9/9 kicks, contact within 1 frame on 8/9, 15/15 non-kicks rejected).

### The Kick Breakdown
The Kick Report now opens on a grade with what it rests on, a phase strip, the coach's read, one priority fix (or why there is none), and a card per phase with the real frame, skeleton, status, measurement against its provisional target and a bar. See `Docs/KICK_BREAKDOWN_BUILD22.md`. One color palette now serves every grade and status (`UI/KickTheme.swift`).


## Changed

### Kicking-foot extremes are withheld when the video didn't show them

Three measurements take an extreme of the kicking foot's path:
- follow-through foot height;
- backswing depth;
- peak foot speed.

Each is now "Not measured" (reason `kickingFootNotFullyVisible`) in either case:
- the kicking ankle touched the frame edge (2 % margin) in the measurement window;
- for height and depth, the extreme sat next to frames where the foot was missing or gap-filled.

On real practice footage, the foot left the frame above the hip and the old value read up to 0.87 torso lengths *below* the hip.

### Benchmarks are labelled as provisional

The target ranges now read "Provisional target (not an elite benchmark)" and "Provisional Target".

### Engine version and scoring model

- The engine version is 3.2.0.
- The scoring model is `provisional-bands-3`: the approach is measured but not graded (weights 0; the rhythm coaching rule is off by default). Approach and overall scores are not ranked against earlier models; plant, swing, contact and follow-through still compare. See `Docs/BENCHMARK_AUDIT_BUILD22.md`.
- Follow-through foot height now records the time of its highest point (the breakdown shows that frame). Its value is unchanged.

### From the first device diagnostics (App 0.1.0 (24), side view, 30 fps)
- Contact was timed from the ball by the detector (2.467–2.500 s) and agreed with the hand-marked contact within one frame.
- The kicking-ankle label collapsed onto the plant foot 0.1 s before contact (motion blur at 30 fps), so only the contact area could be graded. Two fixes:
  - **peak kicking-foot speed** is now withheld (`kickingLegNotTracked`) when the label collapsed at or before contact — the 18.8 reported was the speed before the foot was lost, not its peak;
  - the breakdown's "Not graded" reason no longer counts a low-confidence measurement as reliable ("1 of 2 … was reliable — not usable: plant-foot movement (low confidence)").

## Unchanged

- Bundle ID `com.kicklab.app`, signing, workflows.
- SwiftData schema V3, stored data.
- Scoring bands and thresholds (only the approach weights changed).
- The detector path for contact. The IMG_1709 evidence replay is identical.

## Verification

| Check | Result |
|---|---|
| Linux `swift test` | 846/846 pass (new: `FootVisibilityBuild22Tests`, `StrikeSiteBallTests`, `RunUpDiscoveryTests`, `KickBreakdownTests`, `KickBreakdownFramesTests`) |
| Model and UI stand-in typechecks | build |
| Apple-framework stand-in typecheck | built earlier in this build for the strike-site decoding; not re-run after the last changes (no Apple-only file changed since) |
| XcodeGen project generation, TestFlight self-test (46/46), IMG_1709 replay | pass / identical |
| Real-video emulation (MediaPipe + ONNX YOLOX-S, not the app) on IMG_4541 | the 4 negative follow-through heights become unavailable |
| Real-video emulation of ball recognition and the breakdown | see `Docs/BALL_RECOGNITION_BUILD22.md` |
| Xcode build, Apple-runtime tests, device | **not run** |

## Developer tooling

`Scripts/realvideo/` is a real-video emulation harness. `Datasets/reference/IMG_4541_IMG_6269_reference.json` and `Datasets/reference/kicker_ai_reel_reference.json` are frame-level ground truths: no video, no images.
