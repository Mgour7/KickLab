# Release notes: Build 22 (engine pose-biomechanics-3.2.0)

This build arises from the competitor validation (`Docs/COMPETITOR_VALIDATION_BUILD22.md`) and Matt's direction: recognize the ball without tapping, and grade and coach kicks better than Kicker AI.

## New

### The ball is recognized without tapping
Strike-site recognition finds the kicked ball from the image change at the kicker's feet when the detector can't, and times contact from it. Session discovery also finds run-ups filmed from behind. See `Docs/BALL_RECOGNITION_BUILD22.md` (emulated on real footage: ball found on 9/9 kicks, contact within 1 frame on 8/9, 15/15 non-kicks rejected).

### The Kick Breakdown
The Kick Report now opens on a grade with what it rests on, a phase strip, the coach's read, one priority fix (or why there is none), and a card per phase with the real frame, skeleton, status, measurement against its provisional target and a bar. See `Docs/KICK_BREAKDOWN_BUILD22.md`. One color palette now serves every grade and status (`UI/KickTheme.swift`).


## Changed

### Kicking-foot extremes are withheld when the video didn't show them

Three measurements take an extreme of the kicking foot's path:
- follow-through foot height;
- backswing depth;
- peak foot speed.

Each is now "Not measured" (reason `kickingFootNotFullyVisible`) in either case:
- the kicking ankle touched the frame edge (2 % margin) in the measurement window;
- for height and depth, the extreme sat next to frames where the foot was missing or gap-filled.

On real practice footage, the foot left the frame above the hip and the old value read up to 0.87 torso lengths *below* the hip.

### Benchmarks are labelled as provisional

The target ranges now read "Provisional target (not an elite benchmark)" and "Provisional Target".

### Engine version and scoring model

- The engine version is 3.2.0.
- The scoring model is `provisional-bands-3`: the approach is measured but not graded (weights 0; the rhythm coaching rule is off by default). Approach and overall scores are not ranked against earlier models; plant, swing, contact and follow-through still compare. See `Docs/BENCHMARK_AUDIT_BUILD22.md`.
- Follow-through foot height now records the time of its highest point (the breakdown shows that frame). Its value is unchanged.

### From the first device diagnostics (App 0.1.0 (24), side view, 30 fps)
- Contact was timed from the ball by the detector (2.467–2.500 s) and agreed with the hand-marked contact within one frame.
- The kicking-ankle label collapsed onto the plant foot 0.1 s before contact (motion blur at 30 fps), so only the contact area could be graded. Two fixes:
  - **peak kicking-foot speed** is now withheld (`kickingLegNotTracked`) when the label collapsed at or before contact — the 18.8 reported was the speed before the foot was lost, not its peak;
  - the breakdown's "Not graded" reason no longer counts a low-confidence measurement as reliable ("1 of 2 … was reliable — not usable: plant-foot movement (low confidence)").

### From the second device diagnostics (App 0.1.0 (25), from behind, 30 fps)
- The detector found the ball on every examined frame and placed contact between 4.735 and 4.835 s; the rear-view report measured 6 values and graded nothing, as designed for this view.
- Both device kicks reported **plant to contact 0.033 s** — one frame. The hand-checked reference kick (IMG_4541/IMG_6269 K2) is 0.167 s. A plant found one analyzed frame or less before contact now reads "Not measured" (`plantTimingUnresolved`) instead of a number the frame rate can't support.

### From the third device diagnostics and its video (App 0.1.0 (25), from behind, 30 fps, 6.43 s)
- Ground truth from the video, frame by frame: the foot meets the ball on frame 97 (3.23 s); the ball is displaced on frame 98.
- On the phone, the detector didn't find the (dark, small) ball and the image-change search didn't produce a result, so contact came from pose alone at **3.428 s — six frames late**: the fastest knee extension (607°/s) was the follow-through; an earlier drive (410°/s, 3.26 s) was the strike.
- **Contact from behind, pose only:** an earlier knee drive 0.6–0.8× as fast as the fastest, within 0.35 s before it, is now the strike, and the faster one is reported as the follow-through extension (`ContactIntelligence.strikeDriveRatio`). It matches both rear-view device kicks (this one, and the 9.068 s kick whose ball showed the same pattern). Tuned on those two kicks; equal drives (≥ 0.8×) stay ambiguous as before, and a much faster later drive (< 0.6×) still wins on pose alone.
- **The image-change search now explains itself** in the diagnostics ("Image-change check at the strike spot: … none passed the kick check (best: gone at … s, fastest foot … — 10 needed — …)"), so the next device run shows why it found nothing.
- In emulation on this video (MediaPipe pose, not Apple Vision), the image-change search finds the ball and places contact at 3.193–3.227 s (within one frame of the touch). Why it failed on the phone is not known yet: the evidence bundle of this kick would show it.

## Unchanged

- Bundle ID `com.kicklab.app`, signing, workflows.
- SwiftData schema V3, stored data.
- Scoring bands and thresholds (only the approach weights changed).
- The detector path for contact. The IMG_1709 evidence replay is identical.

## Verification

| Check | Result |
|---|---|
| Linux `swift test` | 849/849 pass (new: `FootVisibilityBuild22Tests`, `StrikeSiteBallTests`, `RunUpDiscoveryTests`, `KickBreakdownTests`, `KickBreakdownFramesTests`) |
| Model and UI stand-in typechecks | build |
| Apple-framework stand-in typecheck | built earlier in this build for the strike-site decoding; not re-run after the last changes (no Apple-only file changed since) |
| XcodeGen project generation, TestFlight self-test (46/46), IMG_1709 replay | pass / identical |
| Real-video emulation (MediaPipe + ONNX YOLOX-S, not the app) on IMG_4541 | the 4 negative follow-through heights become unavailable |
| Real-video emulation of ball recognition and the breakdown | see `Docs/BALL_RECOGNITION_BUILD22.md` |
| Xcode build, Apple-runtime tests, device | **not run** |

## Developer tooling

`Scripts/realvideo/` is a real-video emulation harness. `Datasets/reference/IMG_4541_IMG_6269_reference.json` and `Datasets/reference/kicker_ai_reel_reference.json` are frame-level ground truths: no video, no images.
