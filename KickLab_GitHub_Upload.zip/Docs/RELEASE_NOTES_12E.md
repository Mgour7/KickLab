# KickGuru — Step 12E release notes (engine 2.5.0)

## Fixed
- **Rear-view kicks:** the depth-view detector was rewritten (`depth-view-2`).
  - Plant, contact and follow-through are each found from their own evidence.
  - On the exported signals of the real rear clip that failed in build 10, all three are now found. This still needs confirming on the device.
- **Assisted analysis:** when you choose the contact, the plant and follow-through are now still searched for independently. Previously only the contact came back.

## New
- **Outcome class** on every analysis:
  - full;
  - partial measurements;
  - kick detected, timing uncertain;
  - insufficient evidence;
  - no kick;
  - technical failure.
- **Replay:** ½× and ¼× speed, play/pause, single-frame stepping, and phase markers that show their source.
- **Metric provenance:** measured, estimated, from your contact, or unavailable.
- **Drill library:** 11 general drills; up to 3 are linked from analysis results.

## Unchanged
- Bundle ID, scoring bands, weights and thresholds, and the side-view detector.
- The data model, the workflows, and the export privacy defaults.
- Automatic and manual analyses stay separate.

## Not in this release
- Choosing the plant frame yourself.
- Extended athlete-profile fields.
- Hash, miss-direction and kickoff/punt result fields.
- A progress dashboard.
- Side-by-side comparison.
- Baseline marking.
- A capture assistant.
- Ball and contact recognition (Core ML).
