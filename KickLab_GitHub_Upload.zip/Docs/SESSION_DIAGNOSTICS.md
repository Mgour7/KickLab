# Session Diagnostics Export (Build 21 Hotfix 2)

Format **`kicklab-session-diagnostics` v1**. It is separate from Evidence Bundle v1, which is
unchanged and is embedded per analysis.

> **Status.**
> - The builder (JSON content, privacy and scan CSV) is tested on Linux with synthetic sessions.
> - The media-timing inspector and video-sharing copier have Apple-runtime tests on generated
>   videos (in `ios-tests`). They have not been run by me.
> - The export screen has not been used on an iPhone yet.

## How to export (no Mac needed)

1. Go to **Session Review** and tap the **share icon (Export Diagnostics)** at the top right.
2. Choose video, if any (default **No video**):
   - one kick's clip;
   - all kick clips;
   - the original recordings.
3. Choose **Include sound** if you want it. It is off by default, and only shown when video is chosen.
4. Tap **Prepare Export**, then **Share Diagnostics** to send the files through the iOS share sheet
   (Mail, Files, AirDrop…).

KickLab sends nothing by itself. The recordings in KickLab are not changed. Shared videos are
**copies**:
- picture track only, unless sound is on;
- passthrough, not re-encoded;
- identifying metadata (location, device) removed with `AVMetadataItemFilter.forSharing()`;
- each track's timeline kept as it is.

## ZIP contents

| File | What |
|---|---|
| `session.json` | Everything below in one file |
| `README.txt` | Short description |
| `scan/cameraN-recordingM.csv` | The cached Stage A scan, one row per sampled frame (≈5/s). Columns: time, number of balls, the most confident ball (cx, cy, w, h, score), the selected person's ankles, hip centre and torso length (normalized display coordinates) |
| `evidence/analysisK.zip` | Evidence Bundle v1 of **every** analysis of every session kick: automatic, and user-assisted after a contact correction. Each contains pose for every analyzed frame, football detections, phases, gates and metrics. Replayable with `Scripts/evidence/replay.sh` |

Videos chosen for sharing are separate files next to the ZIP. They are not inside it.

## `session.json`

- **`exportID`** — random, made for each export. Session, athlete, kick and analysis IDs, names
  and locations are **never** written. References are export-local: `camera1-recording2`,
  `candidate3`, `analysis4`.
- **`app`** — app version and build, iOS version, engine version.
- **`manifestVersion`, `recordingContext`** (`openField` / `net` / `unknown`), **`status`**
  (the Session Review headline), **`statusDetails`**, **`queue`**, **`queuePaused`**.
- **`recordings[]`**, for each recording:
  - role (camera view), origin, status, duration, frame rate, capture format, sync;
  - **`media`**, measured with AVFoundation on the real file: duration, width and height,
    preferred transform, display orientation, nominal frame rate, minimum frame duration,
    codec (`hvc1`/`avc1`), track time range, **edit-list segments**, the **first frame time as
    the analysis' own reader returns it**, whether audio exists, and metadata key names (never values);
  - **`scan`** coverage: sampled frames, frames with a ball, with a person, with both ankles,
    and the effective sampling rate.
- **`candidates[]`**, for each candidate:
  - discovery (automatic/manual/edited), hypothesis, status, the plain-English status line;
  - Stage A evidence and score;
  - interval and approach/follow-through flags;
  - contact time, uncertainty and provenance;
  - **`automaticContact`** (kept after any correction) and **`userContact`** (the athlete's
    frame, the timeline it was chosen in, its uncertainty, reanalysis times and result);
  - `clipStartInSource`, `contactInClip`, and **`clipTiming`** (requested vs exported clip,
    measured first-frame time, edit segments, plus a warning when they disagree);
  - analysis status, attempts, last error, contact outcome, and pairing;
  - **`kick`**: the clip's measured media, video angle, the **entered result** (reported
    separately; never evidence of contact), and every analysis with its engine version,
    status, current flag, user-assisted flag, failure reason and evidence file.
- **`discoveryTrace`**, per recording — every raw Stage A event, re-derived from the cached
  scan with this build's thresholds:
  - `origin`: `ballDeparture` or `swingWithoutDeparture`;
  - `evidence` and `score`;
  - `outcome`, one of:

    | Outcome | Meaning |
    |---|---|
    | `keptAutoVerify` | listed and analyzed automatically |
    | `keptForReview` | listed, waits for the athlete |
    | `mergedAsDuplicate` | merged into the stronger event at `mergedInto` (within 4 s) |
    | `droppedHandledBall` | the ball moved off slowly with no swing at it |
    | `droppedLowScore` | evidence score below 2 |
    | `droppedBallStayed` | the ball was seen at its spot again within 1 s |

## What it lets us answer for the three-kick net session

- **Which candidates were duplicates:** `mergedAsDuplicate` events, and listed candidates less
  than about 4 s apart.
- **Practice swings and repositioning:** `swingWithoutDeparture` events, the ankle columns, and
  `droppedHandledBall` / `droppedBallStayed` events.
- **Why a real kick was missed:**
  - was the ball detected at rest (`ball_*` columns);
  - did it leave (trace outcome);
  - was a swing seen at 5 frames/s (ankle columns);
  - was the person found at all (`framesWithPerson`)?
- **Why contact wasn't found:**
  - the clip's measured timing (`clipTiming`, `media.firstFrameTime`, edit segments);
  - orientation (`displayOrientation`, `transform`);
  - the declared view (`role`, `kick.videoAngle`) against the perspective the engine used
    (inside the evidence bundle's phases);
  - the football track and gates (evidence bundle).

## Privacy

Pose coordinates and timing can still be personal data. Share the export only with people
you trust. Video is opt-in for every export.
