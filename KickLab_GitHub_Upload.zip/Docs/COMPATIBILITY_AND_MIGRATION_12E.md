# Step 12E — compatibility and migration

## SwiftData
- **No schema change.** No model, property or relationship was added, removed or renamed, so no migration stage is needed.
- Existing kicks, sessions, analyses, manual contacts and history open unchanged.
- The outcome class is computed when a result is shown, from the stored status and failure cause. It is not stored.

## Engine versions
- New analyses record `pose-biomechanics-2.5.0`. Older analyses keep their own engine version and results.
- "Reanalyze Automatically" runs 2.5.0 and replaces only the automatic analysis.
- Assisted analyses carry the `+assisted` suffix. A saved manual contact is never applied implicitly.

## Feature compatibility

| Area | Side view | Oblique | Rear / front |
|---|---|---|---|
| Kick window | contact-window-2 (unchanged) | contact-window-2 | depth-view-2 (new) |
| Plant / contact / follow-through | yes | yes | yes, estimated; contact confidence ≤ 0.6 |
| Scored categories | yes | no (measurements only) | no (measurements only) |
| Metrics | all sagittal | timings and ratios | plant→contact, follow-through, lateral lean, plant width |
| Replay speeds / frame step | yes | yes | yes |
| Drills | linked to flagged areas | linked | linked |

## Deployment
- Bundle ID: `com.kicklab.app` (unchanged).
- `.github/workflows/ios-tests.yml` and `ios-testflight.yml` were not modified.
- No credentials or signing material are in the repository or the ZIP.
