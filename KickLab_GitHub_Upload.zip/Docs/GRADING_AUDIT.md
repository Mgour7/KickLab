# Grading audit (Build 20, engine pose-biomechanics-3.1.0, scoring model provisional-bands-2)

**Build 20 changes no score, band, weight, gate or label.** It separates three evaluations (technique, consistency, results) and documents why technique grades are so often unavailable. Every number here comes from `BiomechanicsConfiguration.swift`, `KickScoring.swift` and `PerspectiveMetricSupport.swift`. `ReferenceRegression20Tests.techniqueScoringIsUnchanged` guards that nothing changed.

## 1. How a technique grade is produced today

| Step | Rule | Value |
|---|---|---|
| Metric enters scoring | Available and confidence ≥ `minimumScoringConfidence` | 0.35 |
| Component score | Trapezoid band: 100 inside the ideal range, falling linearly to 0 at the zero edges | Provisional, expert-set |
| Area score | Σ(weight × confidence × component) ÷ Σ(weight × confidence) | — |
| Area rated only if | Available weight ≥ `minimumCategoryWeightFraction` of the area's weight **and** area confidence (Σ weight × confidence ÷ total weight) ≥ `minimumCategoryConfidence` | 0.5 and 0.35 |
| Overall score | Unweighted mean of rated areas, when ≥ `minimumCategoriesForOverall` areas are rated | 3 |
| Report shows a technique score | Analysis completed, ≥ 3 rated areas, analysis quality ≥ Fair | — |
| Labels | Excellent ≥ 85 · Good 70–84 · Developing 50–69 · Needs Work < 50 (rounded score) | Provisional |

**Area weights (field goal / PAT):**

| Area | Weights |
|---|---|
| Approach | speed 1 · speed variation 1 · late speed change 1 |
| Plant | plant-foot movement 1.5 · plant knee 1 |
| Swing | kicking knee 1.5 · kicking hip 0.5 · backswing 1 · peak foot speed 1 · foot speed at contact 0 |
| Body Position at Contact | torso lean 1.5 · torso movement 1 · body speed 1 |
| Follow-Through | duration 1 · leg height 1 · body travel 1 |

Plant-to-contact time and every rear-view (frontal-plane) metric have no scoring weight.

## 2. Is grading structurally possible for each camera view?

Derived from which scored metrics each view can measure at all (`ComparableView.supports`, `PerspectiveMetricSupport`). The available-weight fraction shown is the best case, when every measurable metric is available.

| Area | Side | Rear/front (depth) | Diagonal |
|---|---|---|---|
| Approach | 3/3 | 0 → **impossible** | 2/3 (speed variation and late change, as ratios) |
| Plant | 2.5/2.5 | 0 → **impossible** | 0 → **impossible** |
| Swing | 4/4 | 0 → **impossible** | 0 → **impossible** |
| Body Position at Contact | 3.5/3.5 | 0 → **impossible** | 0 → **impossible** |
| Follow-Through | 3/3 | 1/3 (duration only) < 0.5 → **impossible** | 1/3 → **impossible** |
| Overall (3 areas needed) | Possible | **Impossible** | **Impossible** (at most 1 area) |

**Finding G1 — scoring-policy limitation, caused by a camera limitation.** A rear or front recording can never receive a technique grade. This is correct as policy: the scored measurements run along the line of sight from behind, and no frontal-plane technique rule has been validated. Four of the five reference recordings are rear views, so they show "Not graded". Build 20 does **not** add a rear-view technique grade. It adds the consistency layer and rear-view interpretation instead (`Docs/CONSISTENCY_MODEL.md`).

**Finding G2 — Plant area: a scoring-policy limitation that is only possible from the side.** With plant-foot movement missing or below 0.35 confidence, the plant knee alone is 1 ÷ 2.5 = 40% < 50%, so Plant is unrated. Plant-foot movement is often below 0.35 at 30 fps (0.328 on the side clip). The rule is internally consistent; relaxing it would grade the plant from one 2D knee angle. **Not changed.**

**Finding G3 — Swing and Follow-Through depend on one tracking chain.**
- **Swing:** three of the four weighted metrics need the kicking ankle at or near contact.
- **Follow-Through:** all three weighted metrics need the follow-through end.
- **Effect:** a single tracking failure, such as the side clip's ankle-label collapse at 2.367 s (Build 19), removes both areas together. This is a tracking limitation, not a weighting error.

**Finding G4 — the overall score is out of reach for typical side recordings at 30 fps.** The side reference clip rates 2 areas (Approach 77, Body Position at Contact 97), and 3 are needed. Lowering the minimum would produce a "technique score" from posture plus run-up alone. **Not changed.**

## 3. Internal inconsistencies found

| # | Finding | Class | Action in Build 20 |
|---|---|---|---|
| I1 | The Step 10 minimum meaningful difference for plant-to-contact (0.03 s) and follow-through (0.04 s) is near or below one analyzed frame at 30 fps (0.033 s): a "meaningful" change could be pure frame quantization. | Insufficient validation | The consistency model uses one frame as the resolution and two frames as the meaningful change for every timing metric. The Step 10 values are left in place for the legacy personal coach. |
| I2 | Area confidence = Σ(weight × confidence) ÷ total weight blends tracking quality with coverage. A 97 can carry confidence 0.489, so a high score can be shown with "limited confidence". | Scoring-policy limitation | Unchanged. The report labels it "Limited confidence" and the contact area carries "Posture and body movement at contact — not how the foot struck the ball." |
| I3 | Peak foot speed's band is open-ended (ideal from 20 torso lengths/s upward). At 30 fps the measured peak depends on where frames fall (frame-rate factor 0.7), so the component partly rewards sampling luck. | Insufficient validation | Unchanged. Its confidence is reduced at 30 fps, and it was below 0.35 on the side clip, so it didn't count. |
| I4 | Kicking-foot speed at contact has a band but weight 0. | Inert by design | None. It is informational only. |
| I5 | Bands and labels are expert-set and provisional. No dataset of graded kicks validates them. | Insufficient validation | Unchanged. Always labelled provisional. The technique tile says "Provisional". |
| I6 | Confidence never becomes performance: confidence weights the mix of components but never scales a component's value. A missing metric is excluded, never scored as 0. | Checked — consistent | None. |

## 4. Proposed improvements (not implemented; each needs evidence first)

1. **Rear-view technique rules** (plant-foot sideways placement, trunk tilt): only with a labelled dataset showing that a value relates to an outcome or to coach ratings. Until then, rear views get consistency and results, not grades.
2. **Plant area from the plant knee alone:** only if plant-knee angle at contact is shown to be repeatable within ~3° on real side recordings, which needs repeated kicks.
3. **Frame-rate-aware gates:** at 60 fps, plant-foot movement and peak foot speed would clear 0.35 more often. A recording change, not a rule change.
4. **Validation set:** see `Docs/DATASET_PLAN.md`. Coach-rated side-view kicks are needed before any band or weight is revised.

## 5. What each number on the report means

| Shown | Meaning | Not |
|---|---|---|
| Technique "80 · Good" | Provisional mean of ≥ 3 rated areas from 2D pose, against expert-set bands | A percentage, percentile, probability, or prediction of a make |
| Area "97 · Excellent, limited confidence" | Every measured component was inside its provisional range; evidence was thin | 97% accuracy; how the foot struck the ball |
| "Not graded" | Fewer than 3 areas could be rated (or a rear/front/diagonal view) | A low score; a penalty |
| Consistency "Repeatable on 3 of 4 measurements · 5 comparable kicks" | Spread of each measurement across your own eligible kicks, against its measurement precision | Good technique; a grade |
| "Within your usual range" / "Outside your usual range" | Difference from your earlier eligible kicks, beyond both measurement precision and 2× your usual spread | Better or worse |
| Results "Made · 40 yd · this session 3 of 4 made" | What you entered | Inferred from video; caused by any measurement |
