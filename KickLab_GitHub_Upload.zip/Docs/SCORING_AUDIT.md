# KickLab scoring and confidence audit (Build 18, engine pose-biomechanics-3.0.0)

## 0. Build 18 changes (scoring model `provisional-bands-2`)

### Plant to contact
- **No longer scored, and no longer coached.** It had a band of 0.08–0.25 s, weight 1, and rules for a "late" or "early" plant.
- **Why:**
  - No validated criterion says which interval is better.
  - The value rests on two estimated events.
- **What remains:**
  - It is still measured, shown, and compared with the athlete's own kicks (no better direction).
  - The Step 10 personal coach gives it no fix or cue either.
- **Effect:** only the Plant area's rules changed (drift w1.5 + plant knee w1).

### Comparability
- Approach, Swing, Body Position at Contact and Follow-Through are unchanged since 2.8.0. Their scores are still compared across 2.8–3.0.
- Plant and the overall score are compared only within the same model.
- See `ScoringModel.version(of:engine:)`.

### Contact confidence (side clip)
- **Problem:** Build 16 showed "final contact strong" for the side clip. Its ball was `restSiteVacated` (tracking moderate) and its pose timing score was 0.225.
- **Fix:** final contact is now the weaker of:
  - **contact event** — basis, agreement and ball tracking;
  - **time precision** — the interval width.
- **Result:** the side clip is now **moderate**. A narrow interval never raises confidence on its own.

### Confidence measures, now separate

| Measure | Meaning |
|---|---|
| Contact event | Did contact happen there? |
| Time precision | How narrow the interval is. |
| Pose tracking | Joint confidence (diagnostics). |
| Measurement confidence | Per metric. |
| Area quality | Per category. |
| Analysis completeness | Shown as the number of established measurements and rated areas. |

No calibration data exists, so every level is a rule-based estimate and is never presented as a probability.

### Rear/front views
- Two new descriptive plant measurements.
- Still no rear area scores: no validated ranges exist, and none were invented.

### Coaching
- Every insight must pass its rule's evidence contract (`CoachingInsightBuilder.catalog`):
  - supporting metric;
  - kick types;
  - camera views;
  - quality — confirmed ≥ 0.75, provisional 0.5–0.75, otherwise not shown.
- Place-kick torso-lean rules are not applied to punts.

---

*The Build 16 audit follows. Its findings still apply except where §0 changes them.*

# KickLab scoring integrity audit (Build 16, engine pose-biomechanics-2.9.0)

## 1. Verdict

KickLab's scores are **retained, but only as provisional technique indicators**:
- they are clearly labelled as provisional;
- they are shown as whole numbers;
- they are kept apart from the kick's result.

They are **not**:
- validated performance measures;
- probabilities;
- percentiles;
- predictions of whether a kick is made or how far it goes.

No change to any band, weight or gate was made in Build 16. What changed is how the scores are presented and compared.

## 2. What a score is

| Level | How it is computed (`KickScorer`, `BiomechanicsConfiguration`) |
|---|---|
| Metric component | A piecewise-linear `ScoreBand`: 100 inside an "ideal" range, falling linearly to 0 at a "zero" limit (one-sided bands have no limit on one side). |
| Category score | The confidence-weighted mean of its components: Σ(weight × confidence × component) ÷ Σ(weight × confidence). |
| Overall score | The mean of the category scores. It requires at least **3** scored categories. |

**Gates** (unchanged):
- metric reported at confidence ≥ 0.25;
- metric scored at confidence ≥ 0.35;
- a category needs ≥ 50% of its weight available and confidence ≥ 0.35;
- overall needs ≥ 3 categories;
- IMPROVE findings need confidence ≥ 0.5; KEEP findings need ≥ 0.7.

**Where the thresholds come from:**
- The bands are the engine's own "initial, provisional values" (code comment, `BiomechanicsConfiguration`).
- They were chosen from general kicking-coaching heuristics and synthetic tuning.
- **No labelled dataset, published norm or measured outcome relationship backs any band.**

## 3. Category by category

Values are for place kicks; the kickoff and punt profiles adjust a few bands and drop unsupported metrics.

| Category | What it measures (2D pose, body lengths) | Components (band ideal, weight) | Defensible as | Main weaknesses |
|---|---|---|---|---|
| Approach | Run-up speed and its steadiness | approach speed 2.5–7 bl/s (w1); speed variation 0–20% (w1); late speed change −15…+25% (w1) | A rough description of the run-up's rhythm | Hip tracking noise inflates "variation"; camera panning affects speed. |
| Plant | Plant timing, foot stability and knee bend | plant-to-contact 0.08–0.25 s (w1); plant-foot drift 0–0.1 bl (w1.5); plant knee 135–170° (w1) | Plausible ranges | Depends on contact timing (±1 frame = 0.033 s at 30 fps). Drift is sensitive to the plant being found late. |
| Swing | Kicking-leg geometry and speed | kicking knee ≥ 145° at contact (w1.5); hip 130–180° (w0.5); backswing 0.8–2.5 bl (w1); peak foot speed ≥ 20 bl/s (w1) | Partly | Foot speed at 30 fps is aliased. 2D knee angles depend on the camera angle. |
| **Body Position at Contact** ("Contact") | **Trunk posture and body speed at the contact frame — NOT foot-to-ball contact quality** | torso lean −15…+5° (w1.5); torso lean range 0–15° (w1); body forward speed 0.5–4 bl/s (w1) | Posture at one frame | The name invites over-reading. It says nothing about where or how the foot struck the ball. |
| Follow-through | Finishing motion | duration 0.15–0.5 s (w1); foot height 0.5–3 bl (w1); body travel 0.1–1.5 bl (w1) | Plausible ranges | Often unavailable (foot merges with the plant ankle, or the camera moves). |

## 4. The side clip's "approach 76.9" and "contact 97.0" (Build 14 device diagnostics)

**Approach 76.9:**
- speed 2.997 bl/s → 100 (confidence 0.772);
- speed variation 46.3% → 34.3, because it is past the 20% ideal on the way to 60% (confidence 0.772);
- late change +24.4% → 100 (confidence 0.656);
- weighted mean = **76.9**.

The score is pulled down by a single noisy metric. "Variation" on a small kicker (the recording flagged *kickerSmall* and *cameraMoving*) partly reflects tracking noise, not the athlete.

**Contact 97.0:**
- torso lean −9.38° → 100 (w1.5, confidence 0.691);
- body speed 0.388 bl/s → 92.5 (w1, confidence 0.675);
- weighted mean = **97.0**.

Two further facts matter:
- The category's confidence was **0.489** — low; the report shows quality "Limited".
- The category had only 2 of its 3 components (torso range unavailable).

**What 97 means:** the trunk posture and body speed at the contact frame fell inside the provisional ideal ranges. It does **not** mean:
- 97% confidence;
- the 97th percentile;
- 97% of a good contact;
- that the foot struck the ball well.

**What changed in the report:**
- The score is shown as "97", with the word "Excellent" and a measurement-quality marker of "Limited".
- The area is titled "Body Position at Contact".
- The Quick Report never lists an area of Limited quality as a strength or as "Best".
- The overall score is "Partial Analysis — Overall Score Unavailable", because only 2 areas were rated.

## 5. Findings and actions

| # | Finding | Severity | Build 16 action |
|---|---|---|---|
| 1 | Bands are provisional; no validation data | High | Labelled "provisional" on every score; footnote on every report; no percentiles, benchmarks or targets anywhere. |
| 2 | Low-confidence components still contribute (weight × confidence) | Medium | Kept (removing them would change every stored score). Each area shows a measurement-quality indicator. Areas of Limited quality are never highlighted as strengths. |
| 3 | False precision (diagnostics showed 76.9 / 97.0) | Medium | Athlete-facing scores are whole numbers; labels are computed on the rounded value. |
| 4 | Scores from side and rear/front views measure different things | High | Rankings and history never mix views. An unknown view is never ranked. |
| 5 | Engine changes alter measurements | Medium | Comparisons only within one scoring model (`provisional-bands-1` = engines 2.8–2.9). Older analyses are counted and named, not mixed in. |
| 6 | "Contact" means posture, not ball contact | Medium | Already titled "Body Position at Contact" (since Step 12C). The audit documents it. |
| 7 | Overall averages as few as 3 of 5 areas | Medium | Kept (engine gate). The report says how many areas were rated. Unrated areas read "Not rated", never 0. |
| 8 | Result (made / missed, distance) is user-entered | — | Shown as "Result (entered by you)", separate from the technique score. It never changes the score. |
| 9 | Coaching support | — | IMPROVE / KEEP rules are unchanged (thresholds in `CoachingThresholds`). The report shows at most 3 of each, only those with a cue, and only when measured confidently. |

## 6. Label bands (documented)

**Excellent 85–100 · Good 70–84 · Developing 50–69 · Needs Work 0–49.**
- These are the same cut points KickLab has used since Step 8.
- The label is computed on the rounded score.
- The bands are provisional, like the scores.

## 7. What would make the scores defensible

1. A labelled dataset of real kicks, with:
   - both camera views;
   - frame-verified contact;
   - expert ratings;
   - outcome measurements.
2. Bands re-derived from the athletes' own distributions and expert agreement.
3. Inter-rater checks.
4. An outcome-relationship study before any score is described as predicting results.

Until then: no percentiles, no "elite" benchmarks, no targets.
