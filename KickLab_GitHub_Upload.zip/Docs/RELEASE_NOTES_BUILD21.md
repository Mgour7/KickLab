# Release notes — Build 21 (engine pose-biomechanics-3.1.0, unchanged)

**Live Training Sessions 1.0 + Two-Camera Foundation + Compare 1.1.**

> Nothing in this build has run on an iPhone. Logic is tested on Linux (synthetic data);
> camera, media and screens are compiled against stand-ins only. Apple-runtime tests must
> run in the `ios-tests` workflow; the on-device checklist is in the Build 21 report.

**Unchanged:** bundle ID `com.kicklab.app`; signing; workflows; SwiftData V3 (no migration);
engine, scores, bands, gates and contact rules; Evidence Bundle v1; diagnostics; provenance;
Athlete Report 5.0; consistency model; Personal Reference Kick; results history; YOLOX-S
and its licence notices; app icon.

## New

- **Record Single Kick** — in-app camera; the recording becomes a Kick and the normal
  analysis runs. Optional copy to Photos (add-only). A recording left behind by a closed app
  is offered back.
- **Start Training Session** / **Import Training Session Video** — continuous practice
  recording or a long imported video; defaults changeable between kicks; Mark Kick; kicks
  found after recording (two stages); queue with pause/resume and recovery after relaunch.
- **Session Review** — counts, one-tap results, corrections, marks without a kick, results
  by distance and hash, descriptive session trends, storage used.
- **Two cameras** — import a second recording, sync by one marked event, automatic and
  manual pairing (counted once), watch both angles.
- **Ball flight (experimental)** — image-space path after contact, off by default, never
  scored; never reports height, distance, launch angle or hang time.

## Changed

- **Compare 1.1** — clean videos by default; overlays moved into *Advanced Analysis*, each
  off by default every visit; zoom to athlete + pinch/drag; tab bar hidden so the controls
  aren't covered.
- **Permissions** — `NSCameraUsageDescription`, `NSMicrophoneUsageDescription` (only with
  *Record sound*), `NSPhotoLibraryAddUsageDescription` (only for "save a copy"). Still no
  photo-library read access and no location. The two permission tests were updated
  deliberately to require exactly this.
- **Privacy manifest** — comment updated (free-space check now also guards recording); no
  new required-reason API category.

## Tests

- Linux: 782 passed (747 before + 35 new in `TrainingSessions21Tests`, all synthetic).
- New Apple-only: `TrainingSessionAppleTests` (3: clip export, scanner and ball-flight
  tracker on generated blank videos) — **not run** here. Apple-only total: 178.

## Docs

`TRAINING_SESSIONS.md`, `MULTI_KICK_DETECTION.md`, `MULTICAMERA_FOUNDATION.md`,
`BALL_FLIGHT_LIMITATIONS.md`, `COMPARISON_FEATURE.md` (1.1), `Deployment/TESTFLIGHT.md`
(permissions).
