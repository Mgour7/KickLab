# Release notes — Build 21 (engine pose-biomechanics-3.1.0, unchanged)

**Live Training Sessions 1.0 + Two-Camera Foundation + Compare 1.1.**

> Nothing in this build has run on an iPhone. Logic is tested on Linux (synthetic data);
> camera, media and screens are compiled against stand-ins only. Apple-runtime tests must
> run in the `ios-tests` workflow; the on-device checklist is in the Build 21 report.

**Unchanged:** bundle ID `com.kicklab.app`; signing; workflows; SwiftData V3 (no migration);
engine, scores, bands, gates and contact rules; Evidence Bundle v1; diagnostics; provenance;
Athlete Report 5.0; consistency model; Personal Reference Kick; results history; YOLOX-S
and its licence notices; app icon.

## New

- **Record Single Kick** — in-app camera; the recording becomes a Kick and the normal
  analysis runs. Optional copy to Photos (add-only). A recording left behind by a closed app
  is offered back.
- **Start Training Session** / **Import Training Session Video** — continuous practice
  recording or a long imported video; defaults changeable between kicks; Mark Kick; kicks
  found after recording (two stages); queue with pause/resume and recovery after relaunch.
- **Session Review** — counts, one-tap results, corrections, marks without a kick, results
  by distance and hash, descriptive session trends, storage used.
- **Two cameras** — import a second recording, sync by one marked event, automatic and
  manual pairing (counted once), watch both angles.
- **Ball flight (experimental)** — image-space path after contact, off by default, never
  scored; never reports height, distance, launch angle or hang time.

## Changed

- **Compare 1.1** — clean videos by default; overlays moved into *Advanced Analysis*, each
  off by default every visit; zoom to athlete + pinch/drag; tab bar hidden so the controls
  aren't covered.
- **Permissions** — `NSCameraUsageDescription`, `NSMicrophoneUsageDescription` (only with
  *Record sound*), `NSPhotoLibraryAddUsageDescription` (only for "save a copy"). Still no
  photo-library read access and no location. The two permission tests were updated
  deliberately to require exactly this.
- **Privacy manifest** — comment updated (free-space check now also guards recording); no
  new required-reason API category.

## Tests

- Linux: 782 passed (747 before + 35 new in `TrainingSessions21Tests`, all synthetic).
- New Apple-only: `TrainingSessionAppleTests` (3: clip export, scanner and ball-flight
  tracker on generated blank videos) — **not run** here. Apple-only total: 178.

## Docs

`TRAINING_SESSIONS.md`, `MULTI_KICK_DETECTION.md`, `MULTICAMERA_FOUNDATION.md`,
`BALL_FLIGHT_LIMITATIONS.md`, `COMPARISON_FEATURE.md` (1.1), `Deployment/TESTFLIGHT.md`
(permissions).

## Build 21 hotfix 1 — session playback

Fixes from the first iPhone test (session "Test": two camera A recordings, one candidate).

- **Watch Full Recording** on every recording (Session Review → Cameras and recordings) and
  **Watch Clip** on every kick card, confirmed or not. Both play the original recording in
  the session folder (no copy) with play/pause, 0.25–1× speed, a scrubber, frame stepping,
  and contact/clip markers. A clip opens at its interval (3–5 s before contact, 2–4 s after);
  "Show the whole recording" widens it.
- **Review from the player:** set contact to this frame, set clip start/end here, Confirm
  Kick, Not a Kick, Practice Swing — manifest-only edits; the recording is never changed.
- **Session status** now separates: no recordings · recording · looking for kicks · no kicks
  detected · N possible kicks need your review · N waiting for analysis · all reviewed and
  analyzed. The processor line reads "Processing queue: nothing waiting" instead of "All
  kicks processed". The overview's first tile is "Counted kicks" (confirmed + probable).
- **Recordings on this iPhone are one camera.** A second in-app recording was treated as an
  unsynchronized second camera, so its kicks would never have been analyzed. It is now a
  later segment of camera A, on camera A's timeline from its start time ("Same camera,
  recorded later"), never paired with camera A's other recordings. Sessions saved before the
  hotfix are relabelled when read; no recording file is touched. Imported second cameras
  still need syncing as before; Add Missed Kick and Synchronize can pick the recording.
- Tests: `TrainingSessionHotfix21Tests` (11, synthetic).
