# Why so many metrics and ratings are unavailable (Build 20 engineering review)

**Classes:**
- **F** = fundamental camera limitation;
- **T** = tracking failure;
- **P** = phase-detection limitation;
- **M** = missing implementation;
- **V** = insufficient validation;
- **S** = scoring-policy limitation.

No confidence gate was lowered and no new pose model was introduced. No real-footage evidence shows another model would do better on these clips.

| # | Finding | Class | Evidence | Status |
|---|---|---|---|---|
| 1 | From behind or in front, the sagittal mechanics (knee/hip angles, forward lean, foot speed, approach speed) run along the line of sight and can't be measured | F | Geometry (`PerspectiveMetricSupport`) | Correctly unsupported |
| 2 | No technique area can be rated from a rear/front view, because no scored metric there has weight (Follow-Through: duration only, 1/3 < 0.5) | S (from F) | `Docs/GRADING_AUDIT.md` §2 | Kept. Rear views get consistency and results instead (Build 20) |
| 3 | Side clip: Vision put both ankle labels on the plant foot from 2.367 s, before contact at 2.467 s | T | Real exported Vision series (Build 19) | Detected. Kicking-ankle values at contact are withheld and never taken from the plant ankle |
| 4 | Pose tracking through the strike at 30 fps: motion blur at the swing peak causes the label collapse above and aliases peak foot speed | T / F (frame rate) | Same series; frame-rate factor 0.7 | Recording advice: 60 fps |
| 5 | Follow-through end after the collapse can't be seen; the knee's swing is reported separately as "Knee swing after contact" | T | Build 19 | Kept separate |
| 6 | Camera movement mixes into plant movement, body speed and body travel | T / M | Background translation measured by the football stage | Compensated when measured over every sample (Build 19), else withheld. Untested on real camera motion |
| 7 | Plant-foot movement < 0.35 confidence at 30 fps (side clip 0.328) | V / F | Device diagnostics | Not lowered. It blocks the Plant area (finding G2) |
| 8 | Plant phase missing on a clip that starts 0.18 s before contact (3.663 s) | F (recording) | Synthetic reconstruction | Correct. Cropped clips are excluded from baselines |
| 9 | IMG_1709 automatic plant 7.868 s vs the brief's ≈ 7.835 s (one frame) | P | Real frames, MediaPipe (not Vision) | Not changed without device evidence |
| 10 | Rear-view descriptive measurements were shown without interpretation | M | Build 19 report | **Implemented:** usual value, difference, within/outside, spread, level, headline |
| 11 | Rear-view measurements that could be added (e.g. plant-foot forward position relative to the ball) need depth along the line of sight | F | Geometry | Not added |
| 12 | Overall technique needs 3 rated areas; typical side recordings at 30 fps rate 2 | S / T | Side clip: Approach 77, Body Position 97 | Kept. "Not graded" with the reason |
| 13 | Timing "meaningful differences" from Step 10 are finer than one frame | V | `Docs/GRADING_AUDIT.md` I1 | Consistency model uses 1 and 2 frames |
| 14 | Wind/weather only as a free-text note | M | Schema V3 | Results grouped by identical notes. Structured fields would need a migration (not done) |

**New derived measurements in Build 20: none.**
- Consistency and comparison values are statistics of existing stored measurements (mean, SD, range, difference). Each has a definition, units, view eligibility and tests in `Docs/CONSISTENCY_MODEL.md`.
- Measurement precision estimates are documented with their source and limits.
