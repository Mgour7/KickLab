# Contact Correction for Session Kicks (Build 21 Hotfix 2)

> **Status.**
> - The manifest logic (selection, mapping, reanalysis queueing, recording results, status
>   lines) is tested on Linux with synthetic sessions.
> - The recording → clip mapping is checked by an Apple-runtime test on generated videos with
>   numbered frames and an edit list (in `ios-tests`), not yet run by me.
> - The screen and the reanalysis have **not** been used on the athlete's net recording yet.

## Workflow

**Training Session → kick card → Edit Contact** (or **Find Contact Manually** when contact
wasn't found) → step to the frame → **Set Contact Here** → **Save & Reanalyze**.

- These are visible buttons on every kick card. No touch-and-hold is needed.
- It works for:
  - automatically found kicks and candidates awaiting review;
  - manually added kicks;
  - kicks whose analysis completed;
  - kicks whose analysis failed;
  - kicks showing "Contact not found".
- **Controls:**
  - play/pause, scrubber, and one-frame steps (AVFoundation frame stepping on the file's own frames);
  - 0.25×, 0.5× and 1× speed;
  - the current time and frame number, plus the matching time in the original recording;
  - a **yellow marker** for the automatic contact and a **green marker** for yours, each with a jump button.

## Which video, which timeline

- **A kick that already has its clip** is reviewed **in that clip**. That is the exact file and
  presentation timeline the analysis reads, so the chosen time is handed to the engine
  unchanged (`userContact.timeline = kickClip`).
- **A kick without a clip yet** (a candidate awaiting review, or one just added) is reviewed in
  the original recording at its interval.
  - When its clip is cut, the frame is mapped with `clip = recording − clipStartInSource`.
  - `clipStartInSource` is the requested start. Passthrough export (`AVAssetExportSession`)
    writes an edit list so clip time 0 is that frame, even when it isn't a key frame.
- **Measured, not assumed:**
  - After each export, KickLab reads the clip back: duration, edit segments, and the first
    frame time as `VideoFrameReader` (the analysis' reader) returns it.
  - It stores `clipTiming`, with a **warning** when the first frame isn't at 0 (± half a frame)
    or the length differs from the request by more than 0.25 s. The warning shows in the
    contact editor and in diagnostics.
  - Apple test `ClipTimingAppleTests` (generated video, key frames every 3 s, a clip cut at
    2.0 s) checks:
    - the first analyzed frame is at clip time 0;
    - that frame is recording frame 60;
    - clip 1.0 s is recording frame 90;
    - the same at 60 fps.
- **Frame rate:**
  - The athlete picks a real source frame (60/120 fps recordings keep all their frames in the clip).
  - The engine receives the chosen time in seconds and handles it the way it already handles
    a user-assisted contact on an imported video. Its analysis frames are sampled at about 30 fps.
  - The uncertainty saved is one frame of the video it was chosen in.
- **Orientation:** the time doesn't depend on orientation. Portrait recordings keep their
  transform in the clip (passthrough) and are reported in diagnostics.

## What Save & Reanalyze does

1. The candidate is re-queued for the **same Kick**. No new Kick or attempt is created, and the
   session counts don't change.
2. The analysis runs with `PhaseDetectionAssistance(contactTime:)`. This is the same
   user-assisted path single-video kicks already use.
   - It creates a **new** analysis labelled `+assisted`, which becomes current.
   - **The automatic analysis is kept** and still in the kick's history and the diagnostics.
   - Phases, metrics, gates and scoring are recomputed from that contact by the unchanged engine.
3. The result is recorded on `userContact`:
   - `reanalyzedAt`, the analysis, and a plain result line;
   - on failure, the engine's reason.

   The human selection is never replaced silently. If the frame cannot be placed in the clip,
   the run stops with a message instead of falling back to automatic contact.
4. **Status:**
   - A kick analyzed with your contact is **probable**, never "confirmed". A chosen frame is a
     timing judgement, not evidence that the ball moved.
   - If the engine still can't establish the kick (no kicker, conflicting evidence), the card
     says so and the report explains what is limited.
5. **Persistence:** everything is saved in the session manifest (atomic, with the previous copy
   kept), survives relaunch, and can be repeated as often as needed. The latest choice is used.

## What it can't fix

- A wrong camera view setting. Set the view under **Cameras and recordings**, then Reanalyze.
- A kicker who isn't visible.
- A clip that doesn't contain the kick. Use Add Kick Here on the full recording instead.

Manual contact doesn't create pose data that isn't in the video.
