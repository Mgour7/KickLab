# Remote Cameras (Build 24)

Up to three tripod iPhones run KickLab in camera mode. One iPhone, the controller, starts and stops all of them together. When recording stops, each camera sends its video straight to the controller, which adds it to the training session already lined up with the other angles.

## How it works for the athlete

1. **On each tripod iPhone:** Analyze → **Use as Remote Camera**. The camera picture shows, along with "Looking nearby…".
2. **On the controlling iPhone:** Analyze → **Remote Cameras Session**. Set the kick details and quality, then tap Start.
   - The screen shows a six-digit pairing code.
3. **Connect each camera:** tap the controller's name on the tripod iPhone and enter the code. This is needed only once; the camera reconnects on its own afterwards.
4. **Set the views:** on the controller, set each camera to Side, Rear or Other. The camera's own screen then shows its view in large letters (SIDE VIEW), so you can tell which tripod is which.
5. **Record:** press Record once and kick. Every ready camera starts at the same moment.
   - Mark Kick leaves a hint in every camera's recording.
   - "Next kicks" changes the kick settings from that moment on.
6. **Stop:** press Stop. Each camera saves its video and sends it over a direct Wi-Fi link between the phones. No internet or Wi-Fi network is needed.
   - Progress shows per camera.
   - Each video joins the session as it arrives, and kick finding and analysis start as usual.
7. **Finish:** tap Done. Session Review shows every camera under "Cameras and recordings", with its sync line, e.g. "Synchronized automatically by the remote cameras' shared clock · ± 0.04 s".

Remote Cameras can also be opened for an existing session: Session Review → Cameras and recordings → **Remote Cameras…**. Recordings that hadn't arrived when the controller closed are collected there.

## Synchronization

Each camera's recording start is measured on the controller's clock. No event has to be marked by hand.

- **Clock exchange.**
  - Every 2 s the controller sends each camera a ping holding its own clock reading (t0).
  - The camera answers with its clock when the ping arrived (t1) and when it replied (t2). The controller notes when the answer arrived (t3).
  - offset = ((t1 − t0) + (t2 − t3)) / 2, and round trip = (t3 − t0) − (t2 − t1).
  - The exchange with the shortest round trip near the recording start is used. Exchanges within 1 ms of the shortest are averaged by median.
  - The offset can be wrong by at most half that round trip: that is the stated clock uncertainty.
  - Clocks: both phones use the host time clock, which is monotonic and is also the capture session's clock.
- **First frame.**
  - On iOS 18.2 and later, AVFoundation reports the first written frame's timestamp (`startPTS`), converted from the capture session's synchronization clock to the host clock. Uncertainty allowance: ± 0.02 s.
  - On iOS 18.0–18.1 only the moment AVFoundation reports the start is known. Uncertainty allowance: ± 0.15 s.
- **The sync.**
  - Each camera's first frame is placed on the controller's clock.
  - The first recording added to an empty session becomes the reference. In a new session the side view is added first, so it becomes Camera A.
  - Every other recording gets offset = its start − the reference start, with provenance `sharedClock`. Its uncertainty is the sum of both starts' uncertainties.
  - A reference recorded on the controller itself is on the same clock, with its usual ± 0.5 s start allowance.
- **When a start can't be measured**, the recording is added unsynchronized and Session Review says so. Examples: no clock exchange near it, or the controller was reinstalled.
  - Nothing is guessed.
  - Marking an event, as before, still synchronizes it. A manual sync always overrides the automatic one.
- **Start together.** Record asks each camera to start at the same moment on its own clock, 0.8 s ahead. Exact simultaneity is not required, because the measured starts set the offsets.

### Accuracy: what is and isn't established

- **Synthetic test (`RemoteCaptureTests.threeCamerasRecordTogetherAndLineUpOnTheSharedTimeline`).** Simulated cameras had:
  - clock offsets of −4 820 s to +91 337 s;
  - drift of ±22 ppm;
  - uneven 2–20 ms network legs.
  
  Every offset came out within its stated uncertainty and within 12 ms of the truth.
- **Not measured on iPhones.** Real accuracy depends on the Wi-Fi round trips and on how exactly `startPTS` marks the file's first frame. Neither has been checked on a phone. The stated uncertainty is what the app shows; it was not checked against a filmed event.
  - To check on device: film a clap seen by all cameras, then compare the shared-clock offset with a manual sync (Synchronize Cameras…).

## Transport and security

- **Network.** Apple's Network framework: a Bonjour service `_kicklab-cam._tcp` over TCP, with peer-to-peer Wi-Fi allowed.
  - The controller listens and the cameras connect.
  - Multipeer Connectivity was not used: Apple deprecates it from iOS 27 and points to Network (TN3213).
- **Encryption.** Every frame is encrypted and authenticated with ChaChaPoly (Apple CryptoKit).
  - The key comes from the pairing code: HKDF-SHA256 with a fixed salt.
  - Each direction has its own authenticated context, so a frame can't be reflected back to its sender.
  - A phone without the code is dropped at its first frame.
  - A six-digit code keeps nearby phones out. It is not a strong secret against someone recording the radio traffic and guessing the code offline.
- **Export compliance.** KickLab implements no encryption algorithm. It only calls the encryption built into iOS, so `ITSAppUsesNonExemptEncryption` stays false (Info.plist comment updated).
  - This is our reading of Apple's export questions, not legal advice. Confirm it in App Store Connect if asked.
- **Info.plist.**
  - `NSLocalNetworkUsageDescription` is added. iOS asks once on each phone the first time Remote Cameras is used.
  - `NSBonjourServices` = `_kicklab-cam._tcp`.
- **Files.**
  - **On the camera:** each recording's details are written before recording starts, to `Application Support/KickLab/RemoteCamera/`. A recording cut off by the app closing is still sent next time.
    - Recordings are kept until the controller confirms each one is in its session.
    - The camera screen lists what's waiting and can delete it after a confirmation.
  - **On the controller:**
    - A video arrives in the session folder (`incoming/`) in 256 KB chunks and is then moved into `sources/`.
    - A transfer cut off by a disconnection resumes from the last byte received. One cut off by the controller closing starts over.
    - The take bookkeeping is saved as `remote-takes.json` in the session folder.
  - SwiftData is not touched. The manifest gains an optional `remote` field on sources, which older manifests simply lack.
- **Concurrency.** Every Network object starts on the main queue. Each callback turns what it received into Sendable values, then enters the main actor with `MainActor.assumeIsolated`. No `@unchecked Sendable` or `nonisolated(unsafe)` was added.

## Three cameras in one session

- **Pairing.** Before, automatic pairing gave a camera A kick one partner overall. It now gives one partner per other camera.
  - A kick seen by side, rear and a third angle is one attempt with two attached angles. Session Review shows "seen by 3 cameras".
  - Two-camera behaviour is unchanged, and the existing tests pass.
- **Reference.** The kick's primary video is the reference camera's, so the side view should be Camera A.
  - Into a new session, recordings are added in the order side, other, rear. If the side camera's video is late, the others wait.
  - "Add videos that have arrived without waiting" overrides this when the side camera won't send its video.

## Limits

- **Keep KickLab open in the foreground on every phone.** iOS closes connections and the camera when an app goes to the background.
  - Cameras keep recording if the controller drops out. They save and send when it's back.
  - A camera that goes to the background finishes its file; it is sent the next time camera mode is open.
- **Transfer time.** Expect several seconds to minutes per camera, depending on length, quality and how far apart the phones are. A minute of 1080p at 60 fps is roughly 90 MB. Nothing is sent while a camera is recording.
- **Processing.** Kick finding and analysis run on the controller after each video arrives, one at a time, as for any training session.
- **Not verified on device:** discovery, connection, the iOS local-network prompt, the transfer speed, and first-frame timing.

## Code

- **Pure (Linux-tested):**
  - `Services/TrainingSession/RemoteCapture.swift`: messages, wire format, pairing codes, clock synchronization, the session sync, and `addRemoteSource`.
  - `Services/TrainingSession/RemoteRig.swift`: the controller's bookkeeping, as a reducer.
  - `Services/TrainingSession/RemoteCameraOutbox.swift`.
- **Apple:**
  - `Services/TrainingSession/Apple/RemoteCaptureNetwork.swift`: `RemoteChannel`, `RemoteListener`, `RemoteBrowser`.
  - `UI/Remote/RemoteCameraModel.swift` and `RemoteCameraView.swift`: the tripod phone.
  - `UI/Remote/RemoteControllerModel.swift` and `RemoteControlView.swift`: the controller.
- **Changed:**
  - `CameraRecorder`: `onStarted`, `startPTS`, `HostClock`.
  - `MultiCameraSync`: pairing per camera.
  - `SourceSync.Provenance.sharedClock`.
  - `SessionSource.remote`.
  - `TrainingSessionProcessor`: runs again for a recording added mid-run.
  - Entry points in Analyze and Session Review.
- **Tests:** `KickLabTests/RemoteCaptureTests.swift`, 12 synthetic tests.

## Added in Build 25

- **No athlete needed on a tripod phone.** A fresh install's Welcome screen offers "Use This iPhone as a Remote Camera" next to Add Athlete. Its videos are saved on the controlling iPhone under the session's athlete.
- **Quality per camera.** Each camera card on the controller has its own Quality menu (for example 1080p · 120 fps on the side view and 60 fps behind). "Same as all" uses the session's quality.
  - The choice is remembered for that camera on the controller and applied when it reconnects.
  - What a camera actually records still shows on its card, including any fallback.
- **Sideways check.** Each camera reports whether it is turned sideways, using AVFoundation's horizon-level capture rotation: 0°/180° sideways, 90°/270° upright.
  - An upright camera shows a large yellow "Turn this iPhone sideways" banner on its own screen.
  - Its card on the controller is marked "Upright".
  - Record asks for confirmation ("Record Anyway") while any ready camera is upright. It is a warning, not a block, because an upright phone still records.
- **Framing advice on the camera's screen**, for the view the controller gave it and the session's kick type:
  - turn the phone sideways;
  - where to stand;
  - whole body in frame;
  - ball in frame;
  - light.
  
  The text comes from the Capture Guide, and no distances are claimed. The advice can be hidden and brought back.
- **Messages.** `RemoteCameraStatus.orientation` and `RemoteControllerWelcome.kickType` are optional, so phones on Build 24 and Build 25 still understand each other.
- **Tests.** `eachCameraCanHaveItsOwnQualityAndUprightPhonesAreFlagged` (synthetic) covers:
  - per-camera quality, kept across reconnects;
  - orientation from the rotation angle;
  - upright cameras;
  - decoding messages from older phones;
  - the framing advice per view.
- **Not verified on device:** that the rotation angle on a tripod-mounted phone reads as expected. The Build 24 rotation code already records sideways video correctly.
