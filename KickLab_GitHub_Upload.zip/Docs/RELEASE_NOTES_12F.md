# KickGuru — Step 12F release notes (engine 2.6.0)

## Fixed
- **Rear-view contact timing (contact-intelligence-3).**
  - The old rule picked the leg's post-contact extension.
  - Contact is now found inside the knee drive and checked against the trunk's sideways lean.
  - On the real rear clip, the automatic contact moves from 4.033 s to 3.867 s, the frame the user identified by hand.
  - This has been checked only against the exported signals of that one clip; it still needs checking on the phone and on more clips.
- **Recalculated measurements.** Plant→contact and follow-through duration now use the new contact.

## New
- **Verify Contact.** Step through the original video frame by frame (true source timestamps) and mark first contact, or "I can't tell". The difference from the automatic estimate is shown in frames and seconds.
- **Profiles.** Nickname, photo, birth year, graduation year, team/school, role, experience, goals and preferred football; archive and restore.
- **Results.** Ball type, setup, wind/weather, kickoff/punt direction, punt result, inside-20 and "Missed (other)". Each session shows its own statistics.
- **Progress dashboard.** Charts of real saved data, with sample sizes shown.
- **Coaching report.** Numbered sections with evidence labels.
- **Capture guide.** Shows the real recorded frame rate of your recent videos.
- **Diagnostics format 5.** A readable summary, plus a separate full export.

## Groundwork (not functional computer vision)
- **Ball-aware contact fusion** is implemented and tested with test-only observations.
- **No football-recognition model is included**, so automatic ball detection is unavailable and every analysis says so.

## Unchanged
- Bundle ID, workflows, signing, scoring bands, weights and thresholds.
- The side-view detector.
- Older analyses and their engine versions.
