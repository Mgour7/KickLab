# Consistency model and results layer (Build 20)

The consistency layer judges how repeatably an athlete reproduces measurable mechanics, **against their own kicks only**. It is separate from the technique grade and from results, and never combined with them into one number.

Code:
- `Presentation/ConsistencyModel.swift` — `MeasurementPrecision`, `RepeatabilityLevel`, `ConsistencyModel`, `ProgressConsistencyGroup`;
- `Presentation/ResultsLayer.swift`.

Tests: `PerformanceIntelligence40Tests`, `ReferenceRegression20Tests`, `KickComparison10Tests` (all synthetic histories, labelled).

## 1. Eligibility (which kicks count)

A kick feeds a baseline only if **all** of these hold:

| Rule | Why |
|---|---|
| Same athlete | Personal baselines only; no population data exists |
| Same kick type | Field goal, PAT, kickoff and punt use different mechanics |
| Same camera-view group (side / rear-front / diagonal); an unrecorded view never counts | The views measure different things |
| Same analysis kind (automatic vs user-assisted) | A person-chosen contact changes timing-based values |
| Engine with a known scoring model (2.8 or later) | Older engines' metrics aren't comparable |
| Same metric definition version (`metricKey@definitionVersion`) | Definitions changed across builds |
| Analysis completed; one value per physical kick (its current analysis; repeat analyses never count twice) | Independence |
| Not cropped (contact ≤ 0.6 s into the clip) and no blocking recording-quality finding (Build 19) | No run-up or plant in the video, or too little to measure |
| Value measured with confidence ≥ 0.5; a missing value is skipped, never treated as 0 | Trustworthy values only |
| Only EARLIER kicks form "usual" | A kick is never compared with itself or with later kicks |

## 2. Measurement precision (noise) and meaningful change

Each metric has a **resolution**, the typical noise of one measurement, and a **meaningful change**, the smallest difference ever called out (≥ 2 × resolution). These are provisional engineering estimates, not coaching standards.

| Metric(s) | Resolution | Meaningful change | Source |
|---|---|---|---|
| Plant foot to ball (sideways); plant foot vs hips (sideways) | 0.03 torso lengths | 0.06 | **Real Apple Vision data:** rear 7.602 s clip, plant-ankle offset spread over contact ± 1 frame ≈ 0.03 |
| Plant-foot sideways slide | 0.03 | 0.06 | Same clip: frame-to-frame plant-ankle jitter 0.015–0.02 (a maximum displacement carries it) |
| Sideways trunk lean at contact | 1° | 3° | Same clip: ≈ 1° frame-to-frame jitter |
| Every timing (plant to contact, follow-through, knee swing) | 1 frame at 30 fps (0.033 s) | 2 frames (0.067 s) | Frame quantization |
| Side-view metrics with a Step 10 minimum meaningful difference | ½ × that value | That value | Step 10 personalization (expert-set, unvalidated) |
| Anything else | Unit default (3°, 0.05 torso lengths, 0.5 TL/s, 5%) | 2 × resolution | Conservative fallback |

**Limitation:** the rear estimates come from **one** recording on **one** device. They should be re-estimated when several recordings of the same athlete exist.

## 3. Spread and the descriptive consistency level

- **Spread** needs ≥ 4 eligible kicks including this one, over at most the last 10. It is never computed from one recording.
- **Shown:** the range ("Varied by 0.08 torso lengths across 4 comparable kicks") and the sample SD.

**Level (descriptive, not a score):**

| Level | Rule (sample SD) |
|---|---|
| As repeatable as KickLab can measure | SD ≤ resolution: the kicks can't be told apart from measurement noise |
| Repeatable | resolution < SD ≤ meaningful change |
| Variable | SD > meaningful change |

**Why no numeric consistency grade:** no dataset links a given spread to performance, so a 0–100 number would carry no defensible meaning. The level plus the actual spread and sample size are what can be defended.

**What it is not:** a repeatable habit can still be mechanically poor, and variability is not called bad.

## 4. This kick vs "your usual"

- **Usual:** the mean and SD of ≥ 3 earlier eligible values.
- **Difference** = this kick − usual mean.
- **Notable only if** |difference| > max(meaningful change, 2 × usual SD). This protects against measurement noise (the first term) and against the athlete's normal variation (the second).
- **Wording:**
  - "Within your usual range."
  - Or a direction only, e.g. "Your plant foot was farther to the side of the football than on your recent comparable kicks."
  - Never "better", "worse", "should" or "correct" (tested on every metric).

**"Steadily improving"** (unchanged from Build 19): ≥ 6 eligible values, |r| ≥ 0.7 in the metric's better direction, and a fitted change ≥ its documented minimum meaningful difference. Rear-view metrics have no better direction, so they are never called improving.

## 5. What the athlete gets, kick by kick (one kick type, one camera view)

| Eligible kicks | Feedback available |
|---|---|
| 1 | The values with measurement quality; "Building baseline · 1 of 4"; a measurable goal: "Record 3 more comparable kicks…" |
| 2–3 | The same, counting up |
| 4 (3 earlier + this) | Usual value (n, SD); difference; within/outside usual; spread and level for each measurement; key findings and headline built from them |
| 6+ | Possible "steadily improving" for side-view metrics with a better direction |

`ReferenceRegression20Tests.feedbackGrowsWithComparableKicks` demonstrates this sequence with an IMG_1709-like value (synthetic earlier kicks).

## 6. Progress screen

Groups never mix kick type or camera view. Each group is judged at its most recent eligible kick (`ProgressConsistencyGroup`) and shows:
- the spread of each measurement;
- the latest kick's notable differences;
- the baseline goal while the group is still building.

## 7. Results layer (entered results only)

`KickResultsSummary` uses only what the athlete entered:
- made / missed left / missed right / short / blocked / other;
- distance;
- session and date;
- the free-text conditions note (e.g. "windy", Step 12F `Kick.conditionsNote`).

It shows:
- this kick;
- this session ("3 of 4 made");
- all kicks of the type, with sample size ("60% · 3 of 5", "Small sample" under 10);
- success by distance band with n;
- longest recorded make;
- misses by direction;
- recent sessions;
- results grouped by identical conditions notes.

**Never:**
- inferred from pose;
- used to adjust a score;
- linked to a measurement as a cause.

**Wind/weather:** only the athlete's free-text conditions note exists. Structured wind fields would need a SwiftData schema change (V4 migration). That is not unavoidable, so it was not done.
