# Football / contact evaluation dataset plan (Step 12G)

KickLab has **two** real kick clips, both filmed from behind and both used while building the
current detectors. They are **development data** and can never count as validation:

| Clip | Annotation | Split |
|---|---|---|
| IMG_1709.mov (12.2 s, rear, holder) | `Datasets/annotations/IMG_1709.json` | development |
| Rear-view field goal, TestFlight build 10 (7.6 s) | `Datasets/annotations/RearReference_build10.json` | development |

**No accuracy figure is reported anywhere until a held-out set exists.**

## Collection plan (20–30 clips)
| Group | Clips | Why |
|---|---|---|
| Side view, holder | 6 | the main coaching view; checks side-view ball fusion |
| Rear view, holder | 5 | matches the development clips — tests generalization, not memorization |
| Front / diagonal | 4 | perspective coverage |
| Kicking tee (kickoff) | 4 | a tee changes the ball's look and the "at rest" spot |
| Punts (ball dropped) | 3 | no resting ball: the detector must abstain honestly |
| Spare balls / people walking past | 3 | distractors |
| Low light / overcast / 60 fps | 3 | lighting and frame-rate coverage |

Split: about two thirds **held-out** (never opened while changing code or thresholds) and one
third development. A clip moves to development permanently once someone looks at it while
tuning.

## Annotation (per clip)
Use `Scripts/cv/annotation_schema.json`. Step through the real frames (Verify Contact in the
app, or any frame viewer) and record: plant frame, first contact (a frame, a range, or "can't
tell"), last frame the ball is at rest, first frame it has moved, follow-through end, the number
of other balls, and — where practical — ball boxes on 10–20 frames around the strike. A second
person annotating the held-out clips gives inter-rater agreement (report it next to the errors).

## Metrics (`Scripts/cv/evaluate.py`)
- Detection: precision and recall at IoU 0.5 on annotated ball boxes (needs `run_detector.py`
  output or app boxes).
- Tracking retention: share of annotated ball frames where the tracker had the ball.
- Event timing: signed and absolute error (ms and frames) for first ball movement and first
  contact; share within one frame.
- Abstention rate: clips where the app gave no contact answer (honest "uncertain" is better
  than a wrong time).
- By perspective and setup; runtime from each analysis's diagnostics (measured on the phone).
