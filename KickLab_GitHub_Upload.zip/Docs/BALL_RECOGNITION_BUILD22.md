# Ball recognition without tapping (Build 22)

## What changed

Before Build 22, KickLab timed contact from the ball only when the YOLOX-S detector found the
kicked ball at rest and then moving. On the two practice-session recordings (IMG_4541, side;
IMG_6269, from behind) and on the Kicker AI share reel, it didn't. Contact then came from body
pose alone, or the athlete had to tap the ball.

Build 22 adds a second, detector-free way to find the ball: **strike-site recognition**
(`KickLab/Services/Football/StrikeSiteBall.swift`, version `strike-site-1`).

The idea: the ball is a small object resting by the kicker's feet that is gone once a fast foot
has reached it. For each candidate strike time, KickLab:

1. decodes a region around the feet at 60 fps, up to 480 px on the long side
   (`CoreMLFootballVideoAnalyzer.strikeSite`, only when the detector found no contact);
2. undoes small camera shifts (translation, the kicker excluded);
3. compares the scene before and after the strike, pixel by pixel, ignoring every frame where
   the kicker's padded box covers that pixel;
4. keeps a ball-sized, ball-shaped blob of change (size, extent, elongation and — new in this
   build — a long side of at least 0.15 torso lengths, measured with the kicker's size at that
   moment);
5. finds the last frame the ball was still there and the first frame it was gone;
6. accepts it only as a kick: a foot moving at least 10 torso lengths/s within 1 torso length of
   the ball at that moment, the ball present on at least half of the 0.8 s before, and the
   departure between the before and after windows.

The result goes into the football track as `automaticStrikeSite`. Contact is then
"timed from the ball" (`ballConstrainedContactInterval`) exactly as with the detector. In side
views the phase detector re-centres the kick on the ball's departure and looks for the plant in
the 0.5 s before it. In rear and front views, the ball's position is used for plant placement.

## Results on real footage (emulation, not the iPhone)

The app's code (`StrikeSiteBallFinder`, `KickAnalysisPipeline`) ran on Linux with MediaPipe
pose instead of Apple Vision, and OpenCV frames instead of AVFoundation. See
`Scripts/realvideo/strikesite/`.

| Kick | Ball found | Contact before | Contact after (vs hand-checked frame) |
|---|---|---|---|
| A K1–K3 (side) | yes | not established | exact frame |
| A K4 (side) | yes | not established | **6 frames early** (the holder's bar and the kicker behind the ball) |
| B K1–K4 (from behind) | yes | ambiguous or 1 frame late | within 1 frame |
| Kicker AI reel | yes | not established | within 1 frame |

Negatives: 15 Stage A candidates that are not kicks (walking, setting the ball, practice swings)
→ 15 rejected. **Caveat:** one of them (camera A, 127.7 s — a shoe stepping next to the tee)
was a false kick until the long-side rule above was added after seeing it; it is not a held-out
result. The 9 real balls were all unchanged by that rule.

## Finding the kicks in a session (Stage A)

From behind, the kicking leg swings mostly along the line of sight, so at the 5 fps scan rate its
image speed stayed below the swing detector (IMG_6269 K1 and K2 were missed). Build 22 adds a
**run-up detector** (`KickDiscovery.runUpStops`): the kicker's image shrinks by 1.4–3× within
2.5 s with little sideways travel, holds still, and the leg moves around 0.4 s later. Those
candidates are listed for review; Stage B (the full analysis) marks a candidate *confirmed* only when contact is timed from the ball. A candidate with no ball departure stays *probable* or *needs review*.

| Recording | Kicks found before | after | New non-kick candidates |
|---|---|---|---|
| IMG_6269 (behind) | 2 of 4 | **4 of 4** | 0 |
| IMG_4541 (side) | 4 of 4 | 4 of 4 | 1 (no ball seen leaving, so it isn't confirmed) |

Only run-ups *away* from the camera are used: on these recordings the growing ones were people
walking back (2 of 2). A front-view setup wasn't available to check.

## Not verified

- No Xcode build or iPhone run of any of this. Apple Vision's pose and AVFoundation's frames
  differ from the emulation's.
- Two recordings and one reel: thresholds are not validated on other fields, light or cameras.
