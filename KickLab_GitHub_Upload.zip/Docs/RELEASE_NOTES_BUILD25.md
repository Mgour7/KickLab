# Release notes: Build 25 (Remote Cameras setup)

Follows Matt's first install of Build 24 (TestFlight run 28) on the tripod phones. The engine (`pose-biomechanics-3.2.0`), the scoring model (`provisional-bands-3`) and SwiftData (schema V3) are unchanged.

## New
- **No athlete needed on a tripod phone:** "Use This iPhone as a Remote Camera" is on the Welcome screen of a fresh install.
- **Quality per camera:** each camera card on the controller has its own Quality menu, which overrides the session's quality. It is remembered for that camera.
- **Sideways check:**
  - The camera screen shows a big banner when the phone is upright.
  - The controller marks that camera "Upright".
  - Record asks before starting with an upright camera.
- **Framing advice on each camera's screen,** for its view and the kick type.

Details: `Docs/REMOTE_CAMERAS_BUILD24.md` ("Added in Build 25").

## Verification
- Linux unit tests pass, including the new synthetic remote-camera test.
- Stand-in type checks of the new SwiftUI, AVFoundation and Network code pass.
- Not yet run on iPhones.
