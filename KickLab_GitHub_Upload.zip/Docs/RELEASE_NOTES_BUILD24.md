# Release notes: Build 24 (Remote Cameras)

Matt now has three tripod iPhones (all able to run iOS 18) and wants to control their recording from his own phone. This build adds that to KickLab, along with automatic synchronization of the angles. The engine (`pose-biomechanics-3.2.0`) and the scoring model (`provisional-bands-3`) are unchanged.

## New

- **Use as Remote Camera** (Analyze): the iPhone becomes a tripod camera.
  - It shows its view in large letters, its connection, and what is waiting to send.
  - It records only when the controller says so.
- **Remote Cameras Session** (Analyze), or **Remote Cameras…** in Session Review: the controlling iPhone.
  - Shows the pairing code and each camera's view, battery, free space and clock match.
  - One Record / Stop for every ready camera, plus Mark Kick.
  - Kick settings can change during a recording.
  - Shows per-camera transfer progress.
  - Each video joins the session as it arrives and is synchronized automatically (`sharedClock`). Kick finding and analysis then run as usual.
- **Three-camera sessions**: a camera A kick can now be paired with one kick from EACH other camera. A kick seen by three cameras counts once, with two attached angles.

How it works, the accuracy model and the limits: `Docs/REMOTE_CAMERAS_BUILD24.md`.

## Changed

- `CameraRecorder` reports when the first frame of a file was captured.
  - On iOS 18.2+ it uses the first frame's own timestamp (`startPTS`).
  - Before 18.2, it uses the moment recording began.
  - Single-kick and training-session recording are otherwise unchanged.
- **Info.plist:**
  - adds `NSLocalNetworkUsageDescription` and `NSBonjourServices` (`_kicklab-cam._tcp`);
  - the camera purpose string now says videos stay on "your own iPhones";
  - `ITSAppUsesNonExemptEncryption` stays false. KickLab only calls the encryption built into iOS (CryptoKit); the comment explains this. This is our reading of Apple's export questions; confirm it in App Store Connect if asked.
- A training session's processing runs again when a recording is added while it is running. Before, a recording added mid-run waited for the next time Session Review opened.
- **Unchanged:** SwiftData (schema V3). The session manifest gains only optional fields, so old manifests load unchanged. Bundle ID, signing and workflows are also unchanged.

## Verification

- **Linux unit tests** pass, including 12 new synthetic remote-camera tests:
  - wire format, including streams split at awkward points;
  - pairing codes;
  - clock estimation under uneven delays;
  - a simulated three-camera recording, where every offset came out within its stated uncertainty and within 12 ms of the simulated truth;
  - reconnection and resumed transfers;
  - versions, roles and segments;
  - kick settings per take;
  - the camera outbox.
- **Stand-in type checks** of the Network/CryptoKit/AVFoundation code, against stand-ins with real signatures. Handlers were checked both as `@Sendable` and as plain closures.
- **Not yet run on iPhones:**
  - discovery and connection between phones;
  - the local-network prompt;
  - transfer speed;
  - first-frame timing accuracy.

## What to try first

1. Install this build on all four phones.
2. On each tripod phone: Analyze → Use as Remote Camera, and allow Local Network when asked.
3. On your phone: Analyze → Remote Cameras Session → Start, and allow Local Network.
4. Connect each tripod with the code, then set Side, Rear and Other.
5. Record a short clip with a clap in view of all cameras, then Stop. Wait until every camera shows "In the session".
6. In Session Review, check each camera's sync line. Optionally compare with Synchronize Cameras… by marking the clap.
7. Send the session's diagnostics (Export Diagnostics) if anything looks off.
