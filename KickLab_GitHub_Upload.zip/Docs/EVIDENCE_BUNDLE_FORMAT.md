# KickLab evidence bundle — format `kicklab.evidence`, version 1 (build 15, engine 2.8.2)

An evidence bundle is a ZIP the user exports from **Diagnostics → Evidence bundle** for one
analysis (completed, partial or failed — including failures at the kick-window gate). It holds
everything the analysis decided and the data it decided from, so the pure analysis can be
replayed without the video by `Scripts/evidence/replay.sh`.

## What can and cannot be replayed
| Stage | In the bundle as | Replayed? |
|---|---|---|
| Video decoding, Apple Vision pose | recorded pose samples (`analysis/pose.json`) | **No** — recorded output is the input |
| Core ML football detection | recorded boxes of every examined frame (`analysis/phases.json` → `football.raw`) | **No** — recorded output is the input |
| Appearance tracking, camera motion | recorded per-frame scores and shifts (`football.raw`) | No (they need pixels); recorded values are inputs |
| Kicker timeline, leg repair, signals | — | **Yes** (from the recorded pose and kicker track) |
| Football selection, states, departure | — | **Yes** (`FootballTrackAnalyzer.analyze(raw:)`, the device's own entry point) |
| Kick window, plant, contact, ball/pose fusion | — | **Yes** (`DiagnosticsReplay` → production detectors) |
| Metrics, scores, completion gates | — | **Yes** |

## Archive
- ZIP, **stored** (uncompressed) entries, UTF-8 names, fixed timestamps (byte-for-byte reproducible).
- Readers must reject: compressed or encrypted entries, absolute paths, `..`, backslashes,
  duplicates, more than 512 entries, an entry over 48 MB, contents over 96 MB, CRC mismatches.
  (`StoredZip.read` enforces all of these.) A bundle unzipped by hand can be replayed as a folder.

## Files
| Path | Kind | Content |
|---|---|---|
| `manifest.json` | `EvidenceManifest` | format, versions, app/engine/detectors, runtime, video facts, coordinate conventions, analysis status, file list with sizes and CRC-32, `unavailable` markers, privacy flags |
| `analysis/manifest.json` | `kicklab.manifest` v2 | engine, request, assistance, suitability, perspective, leg identity, **recorded gates** |
| `analysis/pose.json` | `kicklab.pose` v1 | every sampled frame: time, status (analyzed/failed), every body's joints (x, y, confidence), track IDs, selected kicker; processing configuration; processed kicker timeline (measured / interpolated / unavailable per joint) |
| `analysis/signals.json` | `kicklab.signals` v1 | derived per-sample signals (speeds, angles, approach rate, lift…) |
| `analysis/phases.json` | `kicklab.phases` v1 | phases with status and confidence; evidence: kick-window candidates, plant candidates (accepted/rejected with reasons), contact candidates, evidence groups, `ballFusion` (inputs and the exact accept/reject reason), contact outcome; `football`: detector info, resting sites with selection reasons, per-frame states, events, camera summary, runtime and **`raw`** (below) |
| `analysis/biomechanics.json` | `kicklab.biomechanics` v1 | metrics with confidence inputs, categories, scores (absent when not written — listed in `unavailable`) |
| `recorded/outcome.json` | `EvidenceOutcome` | the decisions as recorded on the device (compared by replay). Build 16 adds the optional `fusionAcceptancePath` and `ballDeparture`; they are compared only when the recording has them, so build-15 bundles still replay identically |
| `annotations/human.json` | `EvidenceAnnotations` | **human input only**: marked contact, Verify Contact marks (plant, first ball movement, contact range, ball mark, kicked-ball choice, measured ball movement), the assistance of a user-assisted run. Never an automatic input. |
| `diagnostics/summary.txt` | text | the readable diagnostics summary |
| `crops/ball-<time>.pgm` | PGM (P5) | optional grayscale crops of the ball area, **only with explicit consent** |

### `football.raw` (`FootballRawEvidence`, version 1)
| Field | Meaning |
|---|---|
| `scanTimes` | every broad-scan frame time (every frame of the first 0.5 s, then one every 0.2 s), boxes or not |
| `broadScan` | every "sports ball" box of those frames: time, box (cx, cy, w, h), score, pass |
| `precisionTimes`, `precision` | every precision-pass frame time and box (nil when no kicked ball was selected) |
| `appearanceTimes`, `appearanceScores` | appearance match with the resting ball (0…1) per frame |
| `cameraShiftTimes`, `cameraShiftX`, `cameraShiftY`, `camera` | background shift per frame and the summary |
| `strikeStart`, `strikeEnd`, `ankle` | the pose context the selection used (strike window, kicking-ankle path) |
| `aspect`, `duration` | display aspect ratio and clip duration |

## Units and coordinates
Times: seconds from the start of the video (frame presentation times). Positions: app-normalized
**displayed** coordinates — origin top-left of the upright frame, x ÷ displayed width, y ÷
displayed height; football sizes in displayed-height units. Speeds: body lengths per second.
Angles: degrees. `EvidenceBundle.validateUnits` rejects non-increasing or negative frame times,
impossible aspect ratios or frame rates, and detection scores outside 0…1.

## Versioning and compatibility
- `formatVersion` 1. A reader rejects a higher version (`unsupportedVersion`) instead of misreading it.
- Analysis files keep their own `kind` + `formatVersion` headers and are decoded by the app's
  `AnalysisArtifactCoder` (same checks as on the device).
- Analyses made before build 15 have no `football.raw`: the bundle says so in `unavailable`, and
  replay reuses the recorded football track (`footballStage: recordedTrackReused`).
- No SwiftData change: bundles are built from the files already stored next to each analysis.

## Privacy
Exported only when the user taps **Export Evidence Bundle…** and confirms the warning. Contains
pose coordinates and football tracking (sensitive), no video, frames or thumbnails, no names,
account or device identifiers (only the OS version string). Crops only when the user switches
them on. Nothing is uploaded or logged; the file goes wherever the user shares it.

## Replay
```
bash Scripts/evidence/replay.sh KickLab-evidence-xxxx.zip [--json report.json] [--baseline previous.json] [--extract folder]
```
Builds the app's platform-independent sources (Swift 6 toolchain: Xcode 16+ or Swift 6 on
Linux) and prints whether the replay is identical to the recorded outcome, field by field:
selected ball, ball events, kick-window source, proposed / rejected / used plant, contact
outcome, time, interval, confidence and method, fusion verdict, available metrics, completion
and the stopping gate. `--baseline` compares with an earlier replay report (e.g. another engine
version). Exit status: 0 identical, 1 differences, 2 rejected bundle.

`Datasets/evidence/IMG_1709_dev_sample.zip` is a development sample (MediaPipe pose of the real
frames — not Apple Vision — and the real YOLOX-S detections) with its replay report.
