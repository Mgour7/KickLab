# Two-Camera Foundation (Build 21)

> **Status.** Sync, pairing and once-only counting are tested with synthetic sessions on
> Linux. The import, sync screen and side-by-side playback compile against stand-ins only.
> Nothing here has run on an iPhone. **Only camera A's clip is analyzed**; camera B's clip
> is attached to the same kick for viewing. There is no multi-view measurement, no
> triangulation and no networking between phones in this build.

## The model

- A session can have several recordings ("sources"). Each has a **view** — *Side view
  (Camera A)*, *Rear view (Camera B)* or *not set* — chosen by the athlete. KickLab never
  guesses it.
- The first recording is the **reference**. Every source keeps its **raw timestamps**
  untouched; it maps onto the shared timeline (the reference's time) with
  `shared = sourceTime + offset`.
- Each source stores its `SourceSync`: offset, provenance and uncertainty.

| Provenance | Where the offset comes from | Uncertainty |
|---|---|---|
| `reference` | this is the reference | 0 |
| `manualEvent` | the athlete marked the **same event** in both videos | one frame of each camera (e.g. 60 + 30 fps → ±0.05 s) |
| `wallClock` | the two files' recording start times | ±2 s (phones' clocks differ); a starting point only |
| `none` | not synchronized | — |

## Synchronizing (Session Review → Cameras → *Synchronize Cameras…*)

1. In camera A's video, step to an event that both cameras see clearly — the foot touching
   the ball in the first kick is the best one — and mark it.
2. Do the same in camera B's video.
3. **Synchronize.** Offset = A's mark − B's mark. The uncertainty is shown.

Re-syncing replaces the offset; the raw times and every kick's own contact provenance are
unchanged.

**Keep separate:** if the second recording is not the same practice (or the athlete doesn't
want to sync), "Keep this recording's kicks separate" lets its kicks be analyzed on their
own. Until a second recording is synchronized **or** set to separate, its kicks are not
analyzed, so they can't be counted twice by accident.

## Pairing

- **Automatic** (after sync): camera A and camera B kicks whose contacts are within the
  tolerance on the shared timeline become one pair — one-to-one, nearest first.
  Tolerance = max(0.25 s, 3 × (sync uncertainty + both contact uncertainties)).
- **By hand:** touch and hold a camera-B kick → *Same Kick As…* (camera A kicks within 10 s,
  nearest first). *Not the Same Kick* on a pair undoes it; KickLab remembers that and
  automatic pairing won't re-create it.
- A pair whose camera-B clip is already attached to the kick stays fixed (it can't be
  silently unpaired or re-paired).
- **Counting:** a pair is **one attempt**. Camera B's clip is added to camera A's Kick as a
  second video (`VideoAsset.syncOffsetSeconds`: B clip time = A clip time − offset). Results,
  make %, distance and hash breakdowns count it once. Unpaired camera-B kicks are their own
  attempts.

## Watching both cameras

Touch and hold a paired kick → **Watch Both Cameras** opens the comparison screen in pair
mode: camera A and camera B side by side, aligned through the sync, contact marked with
"Contact from camera A + your sync" and the combined uncertainty. Only camera A's analysis
and overlays exist; camera B shows the video.

## Not implemented (by design, documented for later)

### Phone-to-phone networking
Two iPhones recording at once would need: a discovery/pairing step (e.g. MultipeerConnectivity
or Network.framework on the local network, no server), a shared start command, and a clock
offset estimated by exchanging timestamps (NTP-style round trips, typically a few ms on a good
Wi-Fi link). The data model already supports it: a networked sync would be one more
`SourceSync.provenance` with its measured uncertainty, and the recordings would still be
imported into the session the same way. Not built: it adds a local-network permission and
real-time failure modes that need device testing first.

### Two-view triangulation
Turning two 2-D views into 3-D positions needs each camera's intrinsics (focal length,
distortion) and their relative pose (extrinsics), usually from a calibration target or known
field markings seen by both cameras, plus frame-accurate sync (one frame at 60 fps ≈ 0.4 m of
ball travel at 25 m/s). With those, matched points (ankle, ball) give 3-D positions by
linear triangulation with reprojection-error checks. KickLab has none of the calibration
inputs, so it does not triangulate and reports no 3-D values.
