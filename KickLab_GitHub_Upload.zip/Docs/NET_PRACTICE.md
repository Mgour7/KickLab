# Kicking Into a Net (Build 21 Hotfix 2)

## The setting

- **Where the ball goes:** Open field / Kicking into a net / Not specified.
- You choose it at session setup and can change it in Session Review → Cameras and recordings.
- **It changes no score, gate or detection threshold in this build.** It is recorded so the
  session's diagnostics and reviews can be read correctly.

## What the code does today with net footage (synthetic tests, not real footage)

| Situation | Current behaviour |
|---|---|
| Ball disappears into the net immediately | **Found.** A departure needs the ball to stop being seen near its spot. No airborne detections are required |
| Ball rebounds onto its tee spot within about 1 s | **Still listed, but timed late.** The scan bridges short gaps, so the departure is read when the rebound leaves (≈1 s late). The swing isn't at that moment, so the kick isn't auto-verified and waits for review. The default clip (3–5 s before) still contains the real contact. Correct it with Edit Contact |
| Ball rebounds and is seen moving slowly away | Can be read as "handled". If no swing was seen at the spot, the event is dropped (`droppedHandledBall` in diagnostics) |
| A second ball near the first leaves on the same swing | Merged into one candidate (`mergedAsDuplicate`) |
| Long gaps between kicks | No effect (tested with minutes between kicks) |

## Ball vs. red holder

- YOLOX-S detects "sports ball"; a holder or tee isn't a trained class.
- Whether it separates the ball from the red holder, or from the netting, **hasn't been checked
  on the athlete's footage**.
- The diagnostics export's scan CSV (ball box and score at about 5 frames/s) and the evidence
  bundles (precision-pass detections around contact) show exactly what was detected.

## Pending (needs the real recording's diagnostics)

- Net-specific rules, such as treating a rebound onto the spot as a departure, or using the
  swing as primary evidence when the context is "net".
- Any threshold change.

None is made until the three-kick net session's diagnostics show which rule failed.
The aim is to fix the observed failure without changing open-field behaviour or the five
reference regressions.
