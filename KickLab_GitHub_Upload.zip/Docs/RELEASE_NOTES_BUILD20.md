# Release notes — Build 20 (engine pose-biomechanics-3.1.0, unchanged)

**Performance Intelligence 4.0 + Athlete Report 5.0 + Kick Comparison 1.0.**

**Unchanged:**
- bundle ID `com.kicklab.app`;
- SwiftData V3 (no migration; the existing `Kick.isReferenceKick` and `Kick.conditionsNote` columns are used);
- both workflows;
- the TestFlight process;
- the app icon;
- YOLOX-S and its notices;
- Evidence Bundle v1;
- developer diagnostics;
- provenance labels;
- contact detection;
- every score, band, weight and gate.

## New
- **Consistency layer** (`ConsistencyModel`):
  - per-metric baselines from your own eligible kicks;
  - documented measurement precision (rear values from the real 7.602 s Vision series);
  - spread and descriptive level from ≥ 4 kicks;
  - within/outside usual from ≥ 3 earlier kicks;
  - direction-only wording.
- **Results layer** (`KickResultsSummary`):
  - this kick, this session, all kicks with sample sizes;
  - distance bands, longest make, misses by direction, conditions notes, recent sessions.
- **Athlete Report 5.0:**
  - top card with contact quality and headline;
  - Technique / Consistency / Results tiles;
  - key findings;
  - measurement rows with usual and difference;
  - coaching kind labels;
  - "Next goal".
- **Compare Kicks:**
  - filters (made, missed, same distance, same session, reference, same view);
  - contact-synchronized playback;
  - manual alignment;
  - overlays;
  - measurement table.
- **Personal Reference Kick** on the kick page and in Compare Kicks.
- **Progress:** mechanics consistency per kick type and view, reference kicks, Compare entry.

## Fixed
- Editing a kick no longer clears its reference-kick flag.

## Docs
- `GRADING_AUDIT.md`;
- `CONSISTENCY_MODEL.md`;
- `COMPARISON_FEATURE.md`;
- `ANALYTICS_LIMITATIONS.md`;
- `PERFORMANCE_REPORT.md` (5.0 section).
