# Design refresh and Metric Tracker (Build 23)

Engine, scoring and stored data are unchanged (`pose-biomechanics-3.2.0`, `provisional-bands-3`,
SwiftData V3). This build changes how the app looks and adds measurement tracking.

## Look and feel
- **One palette** (`UI/KickTheme.swift`): KickLab field green as the app tint (adapts to dark
  mode), the system grouped background behind cards, one status palette for every grade.
- **Shared components** (`UI/Components.swift`): cards on the grouped surface, stat tiles with
  icons, section headers with an optional link, large action tiles, trend badges, a score
  ring that fills to the score.
- **Home**: a hero card (athlete, latest technique ring, the one thing to work on), four action
  tiles, "At a glance" tiles, **Metrics to watch** from the tracker, the 30-day trend and recent
  activity.
- **Kicks**: session and kick rows with icon badges and a colored score chip with its word.
- **Kick Report**: cards on the grouped surface, matching the rest of the app.
- **Tabs**: "Stats" is now **Progress**, opening on the Metric Tracker and the Progress
  Dashboard.

## Metric Tracker (`Presentation/MetricTracker.swift`, `UI/MetricTrackerView.swift`)
Every measurement followed kick by kick from the analyses already stored:
- grouped by kick type **and** camera view (never mixed);
- only completed analyses eligible for measurement history, values at scoring confidence and
  the current definition version (the same rules as personal rankings);
- each card: latest value, trend badge, a small chart over the shaded provisional target,
  how many kicks were inside the target;
- the detail screen: full chart, latest / recent average / target / trend tiles, every kick
  (tap to open its report);
- trends need 4 kicks moving consistently (|r| ≥ 0.7); for graded measurements "toward
  target" means the distance from the band is shrinking. Ungraded measurements (the approach)
  have no target and no good/bad direction unless the catalog defines one.

Tests: `MetricTrackerTests` (6, pure). The SwiftUI screens are typechecked against stand-ins on
Linux; **they have not been built in Xcode or seen on a device.**

## Device result, App 0.1.0 (27)
The rear-view kick that was 6 frames late now places contact at 3.262–3.295 s from the strike
knee drive; the hand-checked touch is frame 97 (≈ 3.23 s) and the ball moved on frame 98 — the
interval overlaps, one frame late at most. Plant to contact reads 0.20 s (the hand-checked
reference kick is 0.17 s), no longer the impossible 0.03 s.
