# The Kick Breakdown (Build 22)

The top of the Kick Report is now a phase-by-phase breakdown
(`Presentation/KickBreakdown.swift`, `UI/KickBreakdownView.swift`):

1. **Grade** — the technique score in a ring with its word (Excellent / Good / Developing /
   Needs work), "provisional", and what it rests on: areas graded, camera view, how contact was
   timed. It is the report's own score, so the two can't differ.
2. **Phase strip** — Setup, Approach, Plant, Swing, Contact, Finish, colored by status; tap to
   jump to the card.
3. **Coach's read** — strongest area, biggest gain (or why there is no fix), and a "watch" item:
   the graded measurement furthest outside its target in an area that is still good.
4. **One priority fix** — only an evidence-backed finding in a phase marked Work on / Priority,
   resting on a measurement shown on that card, with its cue, a drill and what to check on the
   next kick. Otherwise it says why there is none.
5. **A card per phase** — the real video frame for that phase, cropped around the kicker with
   the tracked skeleton (orange: kicking leg, blue: plant leg); the status pill (Strength 85+,
   Solid 70–84, Work on 50–69, Priority under 50, Not graded, Not measured); the measurement
   that explains the status, its provisional target and a bar that places the value; the
   phase's other measurements (opened when one is outside its target); measurement quality.
   The follow-through card shows the foot's highest point (or the end of the swing), not
   contact.

## Rules that keep it honest (tested: `KickBreakdownTests`, `KickBreakdownCheck`)

- A pill always matches its score band; a graded pill always has a score.
- The headline sentence states the headline's own value, target and verdict.
- A good status isn't explained by an out-of-target measurement (and vice versa) when another
  measurement on the card is the real reason.
- Every bar places the value on the side its verdict says.
- The priority lies in an area that needs work and rests on a measurement on that card.
- Nothing a camera view can't measure is graded; "Not measured" / "Not graded" say why in plain
  words ("The view from behind can't show the swing…", "the graded measurements … need a side
  view", "1 of 3 graded measurements was reliable…"). The approach is measured, not graded
  (`Docs/BENCHMARK_AUDIT_BUILD22.md`).

`emu engine` prints the breakdown for every real clip; all eight session kicks produce no
consistency issues.

## Design preview

The HTML preview Matt reviewed (real K3 side and K2 rear numbers from the emulation, plus a
labelled synthetic sample) mirrors this layout. The SwiftUI screen has **not** been built in
Xcode or seen on a device yet.
