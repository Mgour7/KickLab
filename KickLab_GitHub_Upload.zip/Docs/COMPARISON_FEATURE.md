# Compare Kicks 1.0 (Build 20)

Two previously analyzed kicks reviewed together.

**Code:**
- pure logic: `Presentation/KickComparison.swift`;
- picker view model and reference store: `ViewModels/CompareKicksViewModel.swift`;
- screens and the synchronized player: `UI/CompareKicksView.swift`.

**Tests:** `KickComparison10Tests` (Linux).

**Status:**
- The SwiftUI screens and AVPlayer synchronization are **typechecked only** on Linux against stand-in modules. They have **not run on an iPhone**.
- The on-device checklist (engineering report) covers them.

## Entry points

- **Kick page:** "Compare with another kick", which starts with this kick as Kick A and suggests a partner. The same page has the "Personal reference kick" switch.
- **Kick Report:** "Compare with another kick".
- **Progress:** "Compare kicks side by side" (needs ≥ 2 analyzed kicks), and the chosen reference kicks.

## Choosing kicks

- **Kick A:** any analyzed kick. Its current completed analysis is used.
- **Kick B:** a filtered list. Sorting is newest, oldest or distance.

**Filters:**

| Filter | Shows |
|---|---|
| All | Every analyzed kick |
| Made / Missed | Unknown results are neither |
| Same distance | Same distance band as Kick A (under 30 / 30–39 / 40–49 / 50+) |
| Same session | Kick A's session |
| Reference | The Personal Reference Kick |
| Same view | Kick A's camera-view group |

**Suggested partner:** the reference kick of the same type and view, else the most recent earlier kick of the same type and view.

**Personal Reference Kick:**
- Chosen by the athlete, one per kick type. Choosing another clears the previous one.
- Stored in the existing `Kick.isReferenceKick` column (SwiftData V3, no migration).
- KickLab never declares it ideal.
- Build 20 also fixes a Build 19-and-earlier bug: editing a kick reset this flag to false.

## Synchronization relative to contact

- **Relative time:** "time relative to contact" `r` maps to each video as `tA = contactA + r` and `tB = contactB + r + manualOffset`. Contact is each analysis's own stored contact time (automatic or user-assisted, labelled as such).
- **Scrubbing** is limited to the times where **both** videos have footage. A clip cropped 0.18 s before contact limits how far back both can go.
- **Frame step** = the coarser of the two frame intervals, so every press changes both videos.
- **Precision:**
  - each side's stored contact interval, or one frame when none was stored, gives an uncertainty of (widthA + widthB) ÷ 2;
  - ≤ 0.07 s → "Aligned at contact (±0.066 s)";
  - wider → "Contact timing is uncertain: the videos may be out of sync by up to ±0.17 s".
- **Missing contact:** "Contact wasn't established for Kick B, so the videos start together and are not synchronized at contact." It is never presented as synchronized.
- **Manual alignment:**
  - nudges Kick B by whole frames, within ±1 s;
  - shown as "Kick B shifted +0.067 s by you (this comparison only)";
  - never saved to either analysis and never changes provenance;
  - Reset returns to the automatic alignment.

## Playback (Apple-only; not run on Linux)

- **Two AVPlayers:**
  - `automaticallyWaitsToMinimizeStalling = false`;
  - 2 s forward buffer;
  - pause at item end.
- **Play:** both are seeked exactly (zero tolerance), then started with `setRate(_:time:atHostTime:)` at the same host time 0.15 s ahead.
- **Drift correction:** a 1/30 s periodic observer on Kick A updates the relative time and re-seeks Kick B whenever it drifts by more than half a frame.
- **Speeds:** 0.1×, 0.25× (default), 0.5×, 1×. Play / pause, scrub slider, ± one frame, "Contact".
- **Aspect ratio:** each video is aspect-fit (`.resizeAspect`), so nothing is stretched or cropped. The overlay uses the same aspect-fit rectangle.
- **Memory and performance:**
  - two players, each with a short buffer;
  - both paused, items released and the observer removed when the screen closes;
  - overlays use stored pose and football data with a nearest-sample lookup per frame;
  - no image processing during playback;
  - the pose files are read once, off the main actor, without re-running the engine.

## Overlays (toggle each)

| Overlay | Source | Measured vs inferred |
|---|---|---|
| Skeleton | Stored processed pose (what the analysis used) | Filled dot = detected; hollow dot = filled in between detections; missing joints aren't drawn |
| Plant foot | Stored plant ankle on that frame only | Filled cyan ring = detected; empty ring = filled in |
| Football | Stored detector boxes for that frame | Dashed = obscured / tracked by appearance |
| Contact moment | "Contact" badge on the frame(s) within ½ frame of the analysis's contact | — |
| Measurement lines | Rear/front views only, on the contact frame: the stored plant-to-ball sideways line (same data as the measurement inspector) | Drawn only when the ball, ankle and contact all exist |

## Measurement table

**Measurement | Kick A | Kick B | B − A**

- **Compared only when** both kicks are from the same camera-view group. Different views: "Filmed from different camera views … The videos can still be watched together." and no table.
- **Definitions:** a measurement with different definition versions is shown with "Measured with different definitions — not compared".
- **Missing values:** shown as "—" with "Not measured reliably in Kick B", never 0. Only values with confidence ≥ 0.5 are shown.
- **Small differences:** below the metric's meaningful change, a note says "Within measurement precision".
- **Area scores:** shown only where both kicks were scored with the same rules for that area. Labelled "(provisional score)".
- **Notes:** different kick types, or one user-assisted analysis.
- **Never claimed:** differences are not described as better or worse, nor as the reason a kick was made or missed.

## Limitations

- Contact alignment is only as good as each analysis's contact. Uncertain contacts are labelled, not hidden.
- Two simultaneous 4K videos may stutter on older iPhones. This is unmeasured; see the checklist.
- Kicks without a video on the device show "Video not on this device"; the table still works.
- There is no zoom in the comparison view (zoom remains in Pose Validation).
