# Biomechanics measurement audit (Build 18, engine pose-biomechanics-3.0.0)

This audit covers all 19 metrics that existed before Build 18, plus the 2 added in it.

**What the measurements rest on:**
- All of them are 2D, measured in the image.
- Sizes are in torso lengths ("body lengths"); speeds are in torso lengths per second.

**Confidence of a metric:**
- It is the product of these factors: joint quality × phase factor × sample factor × frame-rate factor × camera factor (`MetricConfidenceModel`).
- **Reporting gate:** a metric is reported at confidence ≥ 0.25 with ≥ the minimum joint coverage.
- **Scoring gate:** it is scored at ≥ 0.35.

Build 18 changed none of these thresholds.

## 1. The metrics

**Views:**
- **S** = side;
- **D** = rear/front (depth view);
- **O** = diagonal: only interval timings and percent ratios are kept, with reduced confidence.

**2D meaning:**
- **Yes** = the quantity lies in the image plane of that view.
- **Partial** = it is foreshortened by an unknown amount.

| # | Metric | Definition | Joints | Phases | Views | 2D meaning | Coaching use | Known failure cases | Status in 3.0 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Approach speed | Mean forward hip speed over the approach | Hips | Approach | S | Yes from the side | Rhythm only | Camera panning; small kicker | Scored |
| 2 | Approach speed variation | SD ÷ mean of forward hip speed | Hips | Approach | S, O | Yes (a ratio) | Consistency | Tracking noise inflates it (side clip: 46%) | Scored |
| 3 | Speed change into the plant | Last 0.2 s vs earlier approach speed, % | Hips | Approach, plant | S, O | Yes (a ratio) | Rhythm rule (> 35%) | A late plant estimate shifts the split | Scored |
| 4 | Plant to contact | Contact − plant landing (s) | Plant ankle, kicking ankle | Plant, contact | S, D, O | Yes (a timing) | **None.** No validated "good" interval | Rests on two estimated events (±1 frame each) | **Descriptive only** (no longer scored or coached) |
| 5 | Plant-foot movement | Largest plant-ankle displacement from plant to contact + 0.1 s | Plant ankle | Plant, contact | S | Yes from the side | Stability rule | Low confidence at 30 fps; landing mis-timed | Scored |
| 6 | Plant knee angle at contact | Hip–knee–ankle angle | Plant leg | Plant, contact | S | 2D projection | Not coached | Angle depends on camera angle | Scored |
| 7 | Kicking knee angle at contact | Hip–knee–ankle angle | Kicking leg | Contact | S | 2D projection | Extension rules | Kicking ankle merges with the plant ankle | Scored |
| 8 | Kicking hip angle at contact | Shoulder–hip–knee angle | Kicking chain | Contact | S | 2D projection | Not coached | Knee not tracked at contact | Scored (w 0.5) |
| 9 | Backswing depth | Ankle furthest behind the hip, plant − 0.3 s to contact | Kicking hip, kicking ankle | Plant, contact | S | Yes | Not coached | Needs plant timing | Scored |
| 10 | Peak kicking-foot speed | Fastest kicking-ankle speed, contact − 0.3…+0.1 s | Kicking ankle | Contact | S | Yes, but aliased at 30 fps | Not coached | Frame-rate factor 0.7 at 30 fps | Scored |
| 11 | Kicking-foot speed at contact | Ankle speed at the contact frame | Kicking ankle | Contact | S | Yes | Informational | Contact placed by constraints | Weight 0 |
| 12 | Torso lean at contact | Trunk angle from vertical | Shoulders, hips | Contact | S | Yes | Lean rules (place kicks only) | — | Scored |
| 13 | Torso movement through the swing | Lean range, plant → end of follow-through | Shoulders, hips | Plant, contact, follow-through | S | Yes | Not coached | Follow-through often unavailable | Scored |
| 14 | Body speed through the ball | Forward hip speed at contact | Hips | Contact | S | Yes | Not coached | Camera panning | Scored |
| 15 | Follow-through duration | Contact → foot slows to 25% of peak | Kicking ankle (or knee) | Contact, follow-through | S, D, O | Yes (a timing) | Short-finish rule | Ankle overlap after contact; camera moving | Scored |
| 16 | Follow-through leg height | Highest ankle above the hip after contact | Kicking hip, kicking ankle | Contact, follow-through | S | Yes | High-finish KEEP | Ankle merges; foot leaves the frame | Scored |
| 17 | Body travel after contact | Hip travel, contact → end of follow-through | Hips | Contact, follow-through | S | Yes | Not coached | Camera moving → unavailable | Scored |
| 18 | Sideways trunk lean at contact | Trunk tilt toward the plant side | Shoulders, hips | Contact | D | Yes (frontal plane) | Not coached | — | Descriptive |
| 19 | Plant foot width | Plant ankle sideways from the hip center at contact | Plant ankle, hips | Plant, contact | D | Yes (frontal plane) | Not coached | Plant label swaps | Descriptive |
| 20 | **Plant foot beside the ball** (new) | Plant ankle sideways from the football's center at contact, in torso lengths (median of contact ± 1 frame, local torso scale) | Plant ankle, torso; ball box | Contact | D | Yes: ball and plant foot are at nearly the same depth (≈ 5% scale error at 10 m) | Consistency only (no validated target) | No kicked ball found → unavailable | Descriptive |
| 21 | **Plant-foot sideways movement** (new) | Largest sideways plant-ankle movement, plant landing → contact + 0.1 s | Plant ankle, torso | Contact | D | Yes (sideways only; movement toward or away from the camera can't be seen) | Consistency only | Plant label swaps | Descriptive |

## 2. Why measurements were unavailable on the five reference recordings

**Sources:**
- Device diagnostics: Build 14 for the metrics, with contact from Build 17 (engine 2.9.0).
- Classes:
  1. fundamentally unavailable from this view;
  2. blocked by tracking;
  3. blocked by phase detection;
  4. available but excluded by confidence;
  5. available but excluded by category-scoring rules.

| Recording | Unavailable, by class |
|---|---|
| **Side 6.502 s** | **1:** sideways trunk lean, plant foot width and the two new metrics (frontal plane). **2:** kicking hip angle (kicking leg not tracked at contact). **3:** follow-through duration, height and body travel, and torso movement — no follow-through (the slowdown came too soon after contact; the camera moved). In 2.8.1, kicking-foot speed at contact was not timed (contact placed by constraints). **4:** plant-foot movement (0.328 < 0.35); peak foot speed (0.308, 30 fps). **5:** Plant — knee alone is 40% of the area's weight (< 50%). Swing — area confidence 0.31 < 0.35. Follow-through — nothing available. |
| **Rear 7.602 s / IMG_1709 (12.202 s)** | **1:** the 15 sagittal metrics (they run along the line of sight from behind). **5:** plant to contact, follow-through duration, sideways lean and plant width were measured, but they are descriptive or single-component, so no area can be rated. |
| **Rear 9.068 s** | Contact is now found (2.9.0, 4.768 s), so the rear measurements tied to contact can be reported. The Build 14 export predates that, so their availability on the device is **unverified**. **1** as above. **2 (likely):** follow-through — the kicking ankle overlaps the plant ankle from ≈ 4.902 s. |
| **Rear 3.663 s** | Contact 0.180 s (ball-anchored). **3:** plant (no run-up), so plant to contact and plant width are unavailable. **1** as above. |

## 3. What was recovered, and why only that

**Recovered (new, rear/front views):**
- **Plant foot beside the ball:**
  - The ball's resting box and the plant ankle at contact are both directly in the image plane of a rear view.
  - On IMG_1709 (real frames, MediaPipe pose, real YOLOX-S detections) it measures **0.57 torso lengths** to the plant side, with confidence 0.83.
- **Plant-foot sideways movement:**
  - It is measured from the plant landing.
  - IMG_1709: 0.16 torso lengths, confidence 0.65.

**Rear plant category — descriptive, not scored.** No validated ranges exist for these quantities, so inventing bands would only manufacture scores. They are compared with the athlete's own kicks (spread over ≥ 4 comparable kicks).

**Removed from scoring — plant to contact.** The brief asks that no particular interval be called good or bad without a validated criterion. Removing it means the side clip's Plant area still isn't rated (knee only). That is the honest result.

**Not recovered:**

| Measurement | Why |
|---|---|
| Sagittal metrics from rear/front views | Fundamentally foreshortened. Valid perspective restrictions were kept. |
| Side-view kicking hip | The kicking leg wasn't tracked at contact. |
| Peak foot speed | Low confidence is correct at 30 fps. |
| Side follow-through | No reliable settle point; the camera moved. |
| Rear approach alignment and kicking-leg path | Ankle identity around the strike from behind is unreliable (below). Deferred until evidence bundles from the device show it can be measured. |

**Thresholds:** the reporting threshold (0.25) and the scoring threshold (0.35) are unchanged.

## 4. Kicking-leg tracking (the "overlap from 4.902 s" case)

**New per-frame report.** Diagnostics now classify the kicking ankle on every frame from contact − 0.1 s to + 0.6 s:
- measured;
- inferred (short-gap interpolation, never shown as observed);
- overlapping (within 0.12 torso lengths of the plant ankle, so its identity is ambiguous);
- unavailable.

It also reports the left/right label swaps that `PoseLegRepair` undid, and the most likely cause.

**From behind** the kicking foot passes over the plant foot along the line of sight, so the 2D overlap is projection, not necessarily a tracker error. It can't be undone by interpolation, so it isn't.

**On IMG_1709** (MediaPipe, real frames):
- 19 measured, 3 overlapping, 0 inferred;
- overlap starts at 8.368 s, 0.433 s after contact, as the foot comes down in front of the plant foot.

**Not checked:**
- The Apple Vision behaviour on the 9.068 s clip can't be checked without its evidence bundle (which contains the pose per frame).
- Existing safeguards are unchanged: leg-swap repair, jump rejection, and interpolation only over short gaps.

**Additional pose model.** Not added. There is no evidence here that a foot/ankle model would beat Apple Vision on these clips. A model would add size, compute, licensing and privacy review. The evidence bundles from the device are the way to measure the gap first.

## 5. Performance

On the Linux build machine, the post-pose pipeline for IMG_1709 takes about 0.18 s for 366 frames:
- tracking, signals, phases, ball fusion, metrics, scoring, coaching.

Build 18 adds no video pass and no model.

Apple Vision and Core ML timings must be read on the device (Diagnostics → runtime).
