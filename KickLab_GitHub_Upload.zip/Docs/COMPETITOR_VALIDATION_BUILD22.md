# Build 22: competitor validation and real-video assessment

**Date:** 2026-10-10.
**Engine:** pose-biomechanics-3.1.0 → **3.2.0**.
**Scoring model:** provisional-bands-2 at the time of this validation; Build 22 later moved to provisional-bands-3 (approach measured, not graded — `Docs/BENCHMARK_AUDIT_BUILD22.md`).

## How to read this document

Each claim carries one of these labels:

- **[Frame]** — I inspected it in the original video frames. Frame numbers are 0-based decoded indices.
- **[Audio]** — measured from the recordings' sound tracks.
- **[Emulated]** — KickLab's own decision code, run on substitute inputs:
  - MediaPipe pose instead of Apple Vision;
  - onnxruntime YOLOX-S instead of the Core ML conversion;
  - no ball-appearance or camera-motion cues.

  It is **not** the iPhone app. See `Scripts/realvideo/README.md`.
- **[Screenshot]** — read from the Kicker AI screenshots or the share-reel notes Matt supplied.
- **[Code]** — read from the KickLab source.
- **[Linux tests]** — `swift test` on Linux (Swift 6.0.3).

Nothing in this document was run on an iPhone or in Xcode.

## 0. Material available

**Supplied**
- `IMG_4541.mov` (camera A) and `IMG_6269.mov` (camera B). Both are the same practice session.
- Six Kicker AI screenshots: the result screen and an Instagram ad.
- A handoff table describing the Kicker AI share reel.
- **The Kicker AI share reel itself.** It is H.264, 1080×1920, 145 frames over 10.77 s, with a variable frame rate: 30 fps runs separated by 0.3 s holds where a phase card is shown.

**Not supplied**
- The original recording of the reel's kick (IMG_4543 according to the brief).
- `IMG_2278`–`IMG_2284`.

**The reel's kick is not in IMG_4541 or IMG_6269** [Frame]:

| | Reel's kick | IMG_4541 / IMG_6269 |
|---|---|---|
| Field | "ACALANES HIGH SCHOOL" scoreboard, yellow posts, blue track and dummies | white posts, maroon scoreboard |
| Ball | on a stand-type holder | on a black holder |
| Camera | behind-left diagonal | front-left diagonal (A) and rear (B) |

The same-kick comparison (§3) is therefore made **on the reel's own frames**:
- The reel is the competitor's export, with its overlays drawn in, and is not the original video.
- Reel frame numbers are used throughout.
- I assume the reel's 30 fps runs and holds show consecutive source frames at 30 fps. Evidence: the ball moves smoothly across #43–#48, and the app's "Follow-Through 32/32 · Frame 79/79" matches reel #49–#80. Kicker AI's own frame *f* = reel #(f+1).

## 1. Independent ground truth (before looking at KickLab)

### 1.1 Recordings

| | Camera A: IMG_4541 | Camera B: IMG_6269 |
|---|---|---|
| Device / format | iPhone, HEVC 1920×1080, 30 fps, display rotation 180° | HEVC 1920×1080, 29.97 fps |
| Length | 163.1 s, 4894 frames | 123.3 s, 3698 frames |
| View | Ground level, **front-left diagonal** of the kicker | Ground level, **directly behind** the kicker, posts visible |
| Lighting | Hazy and backlit | Clear |
| Framing | Ball on a black holder near the right edge. **The kicking foot leaves the frame on the right during every follow-through.** | Whole kick in frame. The kicker is small (torso about 81–85 px). |

### 1.2 Event table

Kicking foot: right [Frame].

**Ball strikes.** All four are confirmed [Frame] and [Audio].

| Kick | Camera A touch / moved | Camera B touch / moved | Audio onset A / B |
|---|---|---|---|
| K1 | #2197 73.243 / #2198 73.277 | #1249 41.650 / #1250 41.685 | 73.2634 / 41.6899 |
| K2 | #2887 96.247 / #2888 96.280 | #1939 64.660 / #1940 64.693 | 96.2814 / 64.7079 |
| K3 | #3555 118.517 / #3556 118.550 | #2607 86.937 / #2608 86.970 | 118.5494 / 86.9758 |
| K4 | #4311 143.722 / #4312 143.755 | #3363 112.147 / #3364 112.180 | 143.7538 / 112.1800 |

Definitions:
- **touch:** the last frame with the foot on the ball and the ball not yet displaced.
- **moved:** the first frame with the ball displaced.
- **contact:** physical contact begins in [touch − 1 frame, touch], and the ball has left by *moved*. At 30 fps that is an interval of 33–67 ms.

Peak foot speed and maximum knee extension were **not** used to place contact.

**Practice swings:** none found.

**Setup movements and other sounds** [Frame / Audio]:
- **Camera A:**
  - ankle-speed peaks at 52.0, 58.7, 78.6, 124.7 and 161.1 s are walking, retrieving balls and setting the ball on the holder;
  - the sound at 7.6 s is camera handling.
- **Camera B:** the sound at 121.6 s is the kicker stopping the camera. Camera A shows him walking to camera B at about 153–155 s.

**Uncertain events:** none left unresolved.

### 1.3 Camera synchronization

| Basis | Offset (A − B) | Uncertainty | Notes |
|---|---|---|---|
| Audio onsets, all 4 kicks | 31.5736 s | ±0.0003 s | Very consistent, but includes an unknown sound-path difference. |
| Touch-frame pairs | 31.593, 31.587, 31.580, 31.575 | ±1 frame each | |
| **Intersection of [touch, moved] intervals** | **31.583 s** | **±0.025 s** | Used for the reference. |

**Unmatched events:**
- the A sound at 7.6 s (camera handling);
- the B sound at 121.6 s (stopping the camera).

**Not measured:** this synchronization gives a common clock, nothing more. The cameras are not calibrated, so **no 3D joint angle, foot speed or ball height follows from having two views.**

### 1.4 Reference kick K2: frame-level timeline

K2 is the clearest paired kick. The machine-readable version is in `Datasets/reference/IMG_4541_IMG_6269_reference.json`.

| Event | Camera B (rear) | Camera A (diagonal; B + 31.583) | Confidence |
|---|---|---|---|
| Hips start moving (approach) | #1910 63.69 | about 95.27 (looks later in A because the early motion is toward A) | ±0.1 s |
| Plant-foot touchdown | #1934 64.493 | #2882 96.080 | ±1 frame |
| Deepest backswing (pose) | #1936 64.560 | #2885 96.180 | ±1 frame |
| Touch (foot on ball) | #1939 64.660 | #2887 96.247 | Frame |
| Ball displaced | #1940 64.693 | #2888 96.280 | Frame |
| Ball in the air | #1941 64.727 | — | Frame |
| Kicking foot leaves the frame | — | #2892 96.413 | Frame |
| Follow-through | #1946 64.893 | #2903 96.782 | ±2 frames |

Plant to touch: **0.167 s** (5 frames) in both views.

The **visual contact sheet** (`K2_reference_contact_sheet.jpg`) is delivered separately. It contains the athlete's image, so it is not stored in the repository.

### 1.5 Technique: what the video supports

These are image-space values from MediaPipe, my own measurement and **not** KickLab. They are 2D projections.

| Measurement | Definition | Camera A, K1–K4 | Camera B, K1–K4 | Confidence |
|---|---|---|---|---|
| Plant to touch | frames from plant touchdown to touch | — | 0.13–0.27 s | High (frame-checked for K2) |
| Knee angle at touch, 2D | hip–knee–ankle angle in the image | 143–165° | 158–169° | Low: foreshortened in both views |
| Backswing knee angle, 2D | smallest knee angle before touch | 120–126° | 111 / 88 / 28* / 127° | Low. *K3 in B is a pose artifact. |
| Trunk lean at touch | image-vertical angle of the shoulder–hip line | −3.6 to +1.3° | −5.2 to −8.3° (sideways, B) | Medium |
| Peak ankle speed | image speed in torso lengths/s | 26–46 | 19–30 | Low: projection and 30 fps blur |

**Observations** [Frame]:
- The approach is consistent across kicks: stand, then about 0.65–0.85 s to contact.
- The plant foot lands about 5 frames before contact. In B it lands beside and slightly left of the ball.
- The arms open wide: the left arm is extended through contact.
- The trunk stays upright, with a slight sideways lean away from the kicking leg (B).
- In B the ball rises and travels left toward the posts. **Make or miss cannot be determined.**

**Hypotheses** (not established by this footage):
- whether the sideways lean helps or hurts;
- whether the backswing is "short";
- any hip-rotation claim.

From these camera positions:
- **rear view:** sagittal-plane knee and hip angles are along the line of sight;
- **diagonal view:** they are foreshortened by an unknown angle.

## 2. KickLab against the ground truth [Emulated]

### 2.1 Stage A: finding kicks in a whole session

| | Camera A | Camera B |
|---|---|---|
| Real kicks found | **4/4** (73.31, 96.31, 118.52, 143.72) | **2/4** (87.14, 111.95). **Missed K1 and K2.** |
| False candidates | 3 (51.9, 78.5, 160.9: walking or setup) | 7 (4.7, 11.7, 18.9, 29.9, 51.5, 73.3, 100.7) |
| Verified automatically | 0 (all "review") | 0 (all "review") |
| Ball departures seen | **0** | **0** |

Root causes:
- **Camera A:** the kicked football sits end-on to the camera on a black holder, backlit. YOLOX-S scores it **0.06**, below the 0.3 minimum. The only "ball" Stage A tracks is a spare ball lying in the background (x ≈ 0.60).
- **Camera B:** only 48 ball boxes in 617 scan frames; the ball is too small.
- **Swings:** the swing evidence comes from pose. In B, a far-away kicker gives a tiny torso length, which inflates speeds measured in torso lengths and produces false swings.

### 2.2 Contact and plant timing (automatic)

Clip times have been converted back to source time.

| Kick | KickLab contact | Truth (touch / moved) | Verdict |
|---|---|---|---|
| A K1–K4 | **contact unavailable** (all four, with Side **or** Unknown angle) | — | Fail |
| B K1 | unavailable: "two knee drives about as fast" | 41.650 / 41.685 | Fail (honest ambiguity) |
| B K2 | unavailable: same reason | 64.660 / 64.693 | Fail (honest ambiguity) |
| B K3 | 86.970 [86.970–87.003] | 86.937 / 86.970 | 1 frame late |
| B K4 | strike window [112.047–112.180] | 112.147 / 112.180 | Contains the truth (window only) |

Why camera A fails: the kick window is placed from the hips. In this diagonal view the hips keep moving through the ball, so the approach "ends" 0.35–0.45 s **after** contact. The window's strike interval then starts 0.12–0.19 s after the true contact. The correct candidate is rejected as "outside the kick window":

| Kick | Candidate | Peak foot speed | Lands on |
|---|---|---|---|
| K2 | 3.970 s clip time | 24 torso lengths/s | the *moved* frame |
| K4 | 4.035 s | 29 torso lengths/s | the *moved* frame |

**Plant timing in B:**
- K1: 41.483
- K2: 64.527 (the visual plant is 64.493, so +1 frame)
- K3: 86.67
- K4: 111.98

Where checked, this is **within 1 frame** of the visual plant.

**Perspective in A** (angle not set): diagonal for K1–K3 and side for K4. That is the same camera classified two ways (size ratio 1.21 versus 1.34–1.37).

### 2.3 Measurements with the true contact supplied

This simulates the user choosing the contact frame.

**Camera B (rear):** KickLab reports only what a rear view supports:
- plant to contact: 0.133–0.267 s;
- follow-through duration: 0.40–0.47 s;
- sideways trunk lean: 6.0–8.3°;
- plant-foot lateral offset: −0.36 to −0.43 torso lengths.

It gives **no score** and **no knee or hip angles**. This is correct behaviour, but thin.

**Camera A, angle not set** (classified diagonal for K1–K3): only approach-speed variation and follow-through duration. Correct.

**Camera A, angle "Side":** the session UI labels camera A "Side view (Camera A)". KickLab trusts that and **scores** foreshortened knee and hip angles and foot speed. Overall scores: 80 / 78 / 79 / 76.

Before Build 22 it also reported **follow-through foot height = −0.30 to −0.87 torso lengths**, i.e. "the foot never rose above the hip". The frames show the foot leaving the frame *above* hip height (contact sheet, #2892). The value is the highest point the camera *tracked*, not the highest point the foot reached.

## 3. Kicker AI on its own kick (the share reel)

### 3.1 Ground truth on the reel's frames [Frame]

| Event | Reel frame | Evidence |
|---|---|---|
| Standing set-up | #1–#20 | Feet still. MediaPipe knee angles stay at 166–180°. |
| First approach step | about #21–#24 (±2) | The first knee flexion. |
| Drive (penultimate) step | about #26–#30 | |
| **Plant-foot touchdown** | **#39 (±1)** | The left foot is down beside the ball; the right heel is rising. |
| Deepest backswing | #40 (±1) | Heel highest behind the kicker. |
| **Touch (foot on ball)** | **#43** | The foot covers the ball on the holder. |
| Ball displaced | #44–#45 | The ball is no longer on the holder. |
| Ball in the air | #46 | Right of the kicker, rising. |
| Highest follow-through | #49–#53 | The kicking leg crosses to the left at about knee-to-hip height. |
| Kicking foot back on the ground | about #57 | |
| Standing / walking | #58–#80 | |

- Plant to touch: 4 frames, about 0.13 s at 30 fps.
- In this behind-left view, vertical heights are roughly preserved, but the leg's forward and back swing runs largely along the line of sight.

### 3.2 Kicker AI's claims against the frames [Frame + Screenshot]

| Phase | Kicker AI | What the frames show | Verdict |
|---|---|---|---|
| Setup | Reel: 8° trunk lean. App: 14° torso lean, "Dialed". | Standing still, upright. | Two values for one standing posture. No definition. |
| Approach | Reel: "16° of lean into the plant". App: "50° drive foot", "Dialed". The card is shown on #10–#12. | Those frames show the kicker **still standing**. | Card frame and claim don't match. Two different metrics. |
| Drive step | App: plant knee 153°, elite 141–170°, "Dialed". Reel: support-hip flex 171° (target 135–164°), "Sharpen". The 153° label first appears on reel #28. | The plant foot lands at **#39**, 11 frames (0.37 s) later. | Not a plant-touchdown measurement. "Dialed" and "Sharpen" for the same step. |
| Backswing | App: knee cock 145°, elite 70–90°, **"Fix"**. Reel: "Behind-view reads … not scored yet". The frame label at #39 reads 137°. | The deepest backswing is #40. The swing runs toward and away from the camera. | Scored as "Fix" in the app, explicitly not scored in the reel, and the value differs from its own frame label. A 2D knee angle along the line of sight isn't the true angle. |
| Contact | Hip rotation 14° (target 20–30°), knee 158° "through contact". The 14° label appears on **#43**. The Contact card is shown on #41–#42. | The touch is at **#43**. | **The contact frame looks right**, to within 1 frame. The "hips locked open" claim rests on a 2D rotation from behind: unverifiable here. The knee labels around contact read 150°, 148°, 162°, not 158°. |
| Follow-through | Reel: finish height −60 %, target "25–105°", text "25–105 %". App: 64° flex, elite 60–80°, "Dialed". | The kicking ankle peaks at about knee-to-hip height (#49–#53). MediaPipe gives 0.7–0.9 torso lengths below the hip, at low confidence. | **Correction to the earlier draft:** −60 % is *plausible* as "ankle height relative to the hip" in 2D, not impossible. The real defects are the ° / % unit mismatch and "Dialed" next to a red value. |
| Follow-through phase | 32 frames, app 48–79 (reel #49–#80) | The last ~23 frames are landing, standing and walking. | The phase runs to the end of the clip. The final frame (172° / 162°) is standing legs. |
| Leg overlay | Leg chain only in the follow-through | From #57 it sits on the kicking leg after it lands; MediaPipe's side order agrees. | **The handoff's "jumps onto the plant leg" is not confirmed.** A planted-leg reading would come from the phase running to the clip end, not a swap. |
| Priority fix | "Finish height runs below 25–105 %" | — | Contradicts the headline (hips) and the "Dialed" follow-through. |
| Score | 7.3 "Solid" | — | No definition, source or validation. |
| "Elite" ranges | 141–170°, 70–90°, 20–30°, 60–80° | — | No source and no angle convention. **Unverified.** |

**Kicker AI got these right:**
- the contact frame (to within 1 frame);
- the overall phase order;
- a readable, immediate result with an overlay.

**These are unsupported or inconsistent:**
- backswing scored and unscored at once;
- "drive-step plant knee" measured 11 frames before the plant;
- mixed units;
- statuses that contradict their own text;
- unsourced "elite" ranges;
- rear and diagonal-view 2D angles presented as joint angles.

### 3.3 KickLab on the same kick [Emulated]

Input: the reel's frames (#2–#80, Kicker AI's own 79 frames), retimed at 30 fps. The burned-in overlays make this harder for KickLab's pose stand-in than the original would be.

| | KickLab | Truth |
|---|---|---|
| Perspective | view from behind (angle not set or Rear) | behind-left diagonal ✓ |
| Kicked ball | found as the resting ball at (0.62, 0.52), but scored 0.08–0.09 in the precision pass. A spare ball at the dummies (0.80, 0.46) dominates. Departure "not clear". | moved #44–#45 |
| Contact | **unavailable**: "The kicking knee wasn't seen extending into a strike after the plant." | #43 |
| Plant | 1.933 s (reel #60): **wrong**, the kicker is walking | #39 |
| With contact supplied (#43) | lateral trunk lean 6.4°; plant 0.61 torso lengths beside the ball; follow-through 0.53 s. No knee or hip angles and no score. | Plant foot beside and left of the ball: consistent by eye. |

**On this kick Kicker AI was more useful and was right about contact timing.** KickLab was more cautious but failed to time contact and plant.

This is the same failure pattern as on Zach's session (§2):
- the football on a holder is invisible to COCO "sports ball";
- the pose-only strike logic doesn't hold up on real 30 fps footage.

## 4. Side-by-side comparison

The rows draw on both Kicker AI's own kick (§3) and Zach's two-camera session (§2).

| Dimension | Kicker AI | KickLab (emulated) |
|---|---|---|
| Contact timing | **Correct to within 1 frame** on its kick (#43). | Failed on its kick; 2 of 8 views on the session. Says "unavailable" rather than guessing. |
| Plant timing | Its "drive step" plant-knee value is 11 frames before the plant. | Within 1 frame on the session's rear view; wrong on the reel (#60 vs #39). |
| Leg identity | No swap confirmed on its kick. | Explicit facing check, consistent in all rear views. |
| Definitions and units | None shown; ° and % mixed. | Every metric defined [Code]. |
| Camera position | Scores and "Fixes" 2D angles from behind. Its own reel contradicts that for backswing. | Refuses sagittal angles from behind. **Gap:** a diagonal camera declared Side is trusted. |
| Coaching consistency | Statuses, text and priority contradict each other. | Coaching only from metrics above confidence thresholds; none issued here. |
| Benchmarks | Unsourced "Elite". | Provisional, and now labelled so. |
| Usefulness today | High: a full story for every kick. | Low on these clips: little is said without user help. |

## 5. Implemented fix (Build 22)

### 5.1 Withhold kicking-foot extremes that the video didn't show

The defect was verified [Emulated] on all four camera A kicks with the true contact supplied. The follow-through height read −0.30 to −0.87 torso lengths although the foot rose above the hip and out of the frame.

**Change** (`KickMetricExtractor`, engine 3.2.0): three measurements take an extreme of the kicking foot's path:
- follow-through foot height (the highest point);
- backswing depth (the deepest point);
- peak foot speed (the fastest point).

Each is now reported **unavailable**, with the new reason `kickingFootNotFullyVisible`, when:
- the kicking ankle is within 2 % of a frame border in the measurement window (the same margin as the existing "body leaves the frame" recording check); or
- for the height and depth, the extreme sample or its neighbours are missing or gap-filled, so the true extreme may lie in the gap.

Never a placeholder number.

**Effect on real footage** [Emulated, contact supplied, camera A as Side]:

| | Before | After |
|---|---|---|
| Follow-through height | −0.30 to −0.87 on 4/4 | **unavailable on 4/4** |
| Peak foot speed | reported on 4/4 | unavailable on K1 and K4 (foot at the edge) |
| Other metrics | — | unchanged |

**What did not change:**
- Bands, weights and thresholds are unchanged.
- The IMG_1709 evidence bundle replays identically.

**Dependent changes:**
- The engine version moves to 3.2.0, so stored analyses show which rule applied.
- `ScoringModel` maps the "3.2" family to a named scoring model (provisional-bands-3 after the approach change), so rankings only compare like with like.

**Side effect (documented, not hidden):** a category is scored from the metrics that remain, provided at least 50 % of its weight is available. Follow-through on camera A is now scored from duration and body travel alone. The category card says "Based on 2 of 3 measurements".

### 5.2 Benchmarks labelled honestly

Changed:
- "General technique target" → **"Provisional target (not an elite benchmark)"**.
- "General Target" → **"Provisional Target"**.
- "general target range" → "provisional target range" in the coaching text.
- A code comment that called the bands "expert-defined" was corrected.

See `Docs/BENCHMARK_AUDIT_BUILD22.md`.

### 5.3 Tests

`FootVisibilityBuild22Tests` adds 5 synthetic tests (Linux):
- edge → no height (with an in-frame control that keeps −1.333);
- a hidden run at the top of a rising follow-through → no height (control measured);
- edge in the swing window → no peak speed;
- the reason's raw value is stable;
- engine 3.2 keeps the scoring model.

A mutation check confirmed the hidden-run test fails without the new rule.

Results:
- **[Linux tests] 815/815 pass** (810 before, plus 5 new).
- Model and UI stand-in typechecks build.
- The IMG_1709 replay is identical.

Apple-runtime tests (182) were **not run**.

## 6. Prioritized engineering findings (not fixed in Build 22)

1. **Kick window starts after contact in diagonal and skip-through views** (camera A 0/4).
   - A prototype that anchors the strike at the run's dominant swing fixed K2: 3.970 [3.937–4.003] contains the truth.
   - It left K4 one frame late and K1/K3 unavailable.
   - It **broke** the synthetic diagonal test (contact 0.45 s early, on a backswing).
   - **Not shipped.** It needs a second cue (plant landing, or ball evidence) to tell the strike from a fast backswing.
2. **The football on a holder is invisible to COCO "sports ball"** (score 0.06, end-on, backlit).
   - Without ball evidence, A never verifies contact and Stage A never sees a departure.
   - The options (a football-specific detector, or a user tap on the ball at the start of a session) involve a model decision that is Matt's to make; the current rules exclude new AI models.
3. **A declared Side view on a diagonal camera is trusted**, and foreshortened angles are scored (§2.3).
   - Movement cues can't separate "diagonal camera" from "angled soccer-style approach seen from the side". A swing-plane check is needed.
   - Meanwhile, the session role picker should not pre-label camera A as "Side".
4. **Stage A in rear views** is swing-only with scale noise: 7 false candidates and 2 misses in B.
5. **Rear-view contact ambiguity** (B K1/K2): honest, but it puts work on the user. Pairing with the synchronized second camera would resolve it, since A sees the strike.
6. **The approach category scores 50** on every camera A kick, because "speed variation" penalises the normal acceleration of a 3-step approach from standing. This rule needs review before any coaching uses it.

## 7. Uncertainty notes

- MediaPipe ≠ Vision. Coverage, edge behaviour and leg labels may differ on the device. Device evidence bundles of these kicks are needed to confirm §2.
- The contact intervals in §1.2 are ±1 frame at 30 fps (33 ms).
- The synchronization is ±25 ms.
- The kicker is right-footed by observation. No athlete profile was available.

## 8. Recommendation: continue, but narrow

**Evidence for KickLab:**
- When KickLab doesn't know, it says so.
- It refuses rear-view angles, which is Kicker AI's main failure.
- Plant timing is within 1 frame where checked.
- Every number has a definition.
- Sessions, correction workflows and multi-camera sync exist, and Kicker AI shows none of these.

**Evidence against KickLab** (on this real footage, emulated):
- Automatic contact succeeded on 2 of 8 views.
- The ball detector did not see the kicked ball at all.
- Session discovery found 6 of 8 kicks among 10 false candidates.
- A user who follows the "Side view (Camera A)" label gets confident angles from a diagonal camera.
- On the views it handles honestly, KickLab says little: rear view gives timing plus 3 frontal-plane values and no score.

On Kicker AI's own kick, the competitor timed contact correctly and KickLab did not.

The advantage is real only if accuracy becomes demonstrable. Kicker AI's polish without validity is beatable, but not by adding features.

**Next three steps, in order:**
1. **Device evidence bundles** of K1–K4 from both cameras. These confirm or refute §2 on Vision and Core ML.
2. **Contact timing:** a strike cue that survives skip-through approaches, plus a decision on ball detection (§6 items 1–2).
3. **A guided recording setup:** a true side view at 60 fps with the whole follow-through in frame. Stop pre-labelling camera roles.

Do **not** add elite comparisons until reference data exists (`BENCHMARK_AUDIT_BUILD22.md`).

**Pause** if device bundles show the automatic contact rate on side-view 60 fps practice clips staying below roughly 3 in 4 after step 2. The product's core promise — frame-backed coaching — would not hold.
