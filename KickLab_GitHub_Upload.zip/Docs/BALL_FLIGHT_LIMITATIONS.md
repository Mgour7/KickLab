# Ball Flight — Experimental (Build 21)

> **Status.** `BallFlightObserver` is tested on synthetic detections (Linux). The Core ML
> tracker compiles against stand-ins and has an Apple-runtime test on a blank generated
> video (it correctly reports "not tracked"); it has never followed a real kick. It is
> **off by default**, lives under Compare → Advanced Analysis → *Ball flight (experimental)*,
> and is **never scored** or used by any technique, consistency or results number.

## What it does

After contact, YOLOX-S runs on every frame of the clip for up to 2.5 s (or to the end of the clip). The
observer follows the kicked ball in **image space**:

- starts only from a box within 4 ball widths of the ball's resting spot right after
  contact; a box that stays **on** the resting spot is never taken as the flight (a second
  ball or tee);
- each next box must be inside a gate around the predicted position (3 ball widths plus a
  speed term), with score ≥ 0.25 and a size change no larger than ×1.8 between frames —
  otherwise it's a different object and is rejected (counted);
- gaps up to 0.1 s are filled in and drawn as **inferred** points (hollow); measured points
  are filled; inferred points at the end are dropped;
- fewer than 2 measured points → *not tracked*.

It always says **why tracking ended**: too small, left the picture, lost, video ended, or
not tracked.

The summary always says it is partial, e.g. "Ball followed for 0.42 s after contact (12
detections, 2 filled-in frames) — a partial flight observation, not hang time. The ball left
the picture." It is **never** called hang time.

## What it never reports (one uncalibrated camera)

| Not reported | Why |
|---|---|
| Height (feet/metres) | No scale or depth: a ball high and close looks the same as one low and far |
| Distance | Same; and the ball leaves the picture long before landing |
| Launch angle | Image angle depends on the camera's position and lens; it isn't the ball's real angle |
| Speed | No metric scale |
| Hang time | Requires the landing or catch to be seen and verified; this build has no landing/catch detector, so it's never shown |
| Make/miss, hook, slice | Not inferred from the path (results are what the athlete enters) |

## Why it's experimental

YOLOX-S was trained for a ball on the ground near a kicker; a ball in the air against sky or
crowd, motion-blurred at 60 fps, small after a few frames, is outside what it was checked
on. Expect short tracks and early "lost" endings. Nothing here is validated on real kicks.

## Two-view path (future)

With two **calibrated, synchronized** cameras (see `MULTICAMERA_FOUNDATION.md`), measured
ball points from both views could be triangulated into 3-D positions; a ballistic fit over
those would give launch angle and speed with real units and uncertainties, and hang time if
the landing is observed. None of that exists in Build 21.
