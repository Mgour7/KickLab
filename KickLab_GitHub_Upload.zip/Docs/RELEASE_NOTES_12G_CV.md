# Release notes — Step 12G: Computer Vision Intelligence Rebuild (engine 2.8.0)

## New
- **Automatic football detection** with a bundled, commercially licensed model (YOLOX-S,
  Apache-2.0, Core ML fp16, 18 MB). Runs on the iPhone; nothing leaves the device.
- **Two-stage football analysis** after pose: a broad scan finds resting footballs and picks
  the kicked one; a precision pass follows it frame by frame around the strike, with the
  ball's appearance and the camera's movement.
- **Ball-constrained contact**: the last clear resting frame and first persistent movement
  bound contact. From behind or in front, a pose-only strike window becomes a contact
  interval when the ball agrees and the interval is within ±0.05 s.
- **Contact outcome** labels everywhere (seven kinds, including "chosen by you").
- **Video Intelligence debugger**: football overlays, ball event markers, zoom.
- **Diagnostics**: a football block (method, detector and version, frames by state, sites and
  why each was or wasn't the kicked ball, times, camera, measured runtime). No coordinates.
- **Acknowledgements** screen (Apache-2.0 notice).
- **Evaluation tooling** and a 20–30 clip dataset plan.

## Changed
- Engine `pose-biomechanics-2.8.0`. Analyses made before keep their results; reanalysis runs
  the football pass.
- Analysis progress: pose 2–70 %, football 71–87 %, then phases and scoring.
- Diagnostics replay uses the stored football track, so replays match the analysis.

## Not changed
- Pose (Apple Vision), side-view phase detection, thresholds, scores, stored data, schema (V3),
  bundle identifier, signing, both GitHub workflows.

## Honest limits
- Detector validated on no held-out data; IMG_1709 is development data.
- The Core ML model has not been run on Apple hardware by the developer environment; the
  Xcode test `FootballDetectorAppleTests` does that in CI.
- No iPhone timing has been measured yet; the runtime is recorded per analysis.
- Perspective-aware automatic plant tracking is deferred to 12H (manual plant verification
  remains).

## Engine 2.8.1 (build 14) — automatic ball/pose fusion fix
- **Root cause (IMG_1709 on the iPhone):** the plant search proposed 8.302 s although the football
  left at 7.968 s. The contact search was anchored on that plant (8.335–8.752 s), pose found no
  strike there, and the ball's departure was then rejected as a "conflict" with that search range —
  so the analysis stopped at the contact gate ("Couldn't pinpoint the strike").
- **Fix:** a plant estimate at or after the ball's first movement is rejected and flagged; the plant
  is searched again only in the 0.35 s before the ball moved (left unreported if none). With no
  pose strike, the ball's departure is accepted only when the kicking foot was swinging when the
  ball left (≥ 50 % of its strike speed); otherwise it is reported as a conflict.
- **Interval kept honest:** the last frame the ball looks at rest is a possible contact frame, so
  adjacent frames give a two-frame interval (`ballConstrainedContactInterval`), never a single
  verified frame.
- **Diagnostics:** a "ball/pose fusion" block (detector ran, ball selected, ball interval, plant
  proposed / precedes ball / rejected / used, pose search and strike, overlap, kick-window check,
  kicking-foot support, accepted or the exact rejection reason) and the final contact state with the
  gate the analysis stops at.
