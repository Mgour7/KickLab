# Release notes — Step 12G: Computer Vision Intelligence Rebuild (engine 2.8.0)

## New
- **Automatic football detection** with a bundled, commercially licensed model (YOLOX-S,
  Apache-2.0, Core ML fp16, 18 MB). Runs on the iPhone; nothing leaves the device.
- **Two-stage football analysis** after pose: a broad scan finds resting footballs and picks
  the kicked one; a precision pass follows it frame by frame around the strike, with the
  ball's appearance and the camera's movement.
- **Ball-constrained contact**: the last clear resting frame and first persistent movement
  bound contact. From behind or in front, a pose-only strike window becomes a contact
  interval when the ball agrees and the interval is within ±0.05 s.
- **Contact outcome** labels everywhere (seven kinds, including "chosen by you").
- **Video Intelligence debugger**: football overlays, ball event markers, zoom.
- **Diagnostics**: a football block (method, detector and version, frames by state, sites and
  why each was or wasn't the kicked ball, times, camera, measured runtime). No coordinates.
- **Acknowledgements** screen (Apache-2.0 notice).
- **Evaluation tooling** and a 20–30 clip dataset plan.

## Changed
- Engine `pose-biomechanics-2.8.0`. Analyses made before keep their results; reanalysis runs
  the football pass.
- Analysis progress: pose 2–70 %, football 71–87 %, then phases and scoring.
- Diagnostics replay uses the stored football track, so replays match the analysis.

## Not changed
- Pose (Apple Vision), side-view phase detection, thresholds, scores, stored data, schema (V3),
  bundle identifier, signing, both GitHub workflows.

## Honest limits
- Detector validated on no held-out data; IMG_1709 is development data.
- The Core ML model has not been run on Apple hardware by the developer environment; the
  Xcode test `FootballDetectorAppleTests` does that in CI.
- No iPhone timing has been measured yet; the runtime is recorded per analysis.
- Perspective-aware automatic plant tracking is deferred to 12H (manual plant verification
  remains).
