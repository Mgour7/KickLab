# Training Sessions 1.0 (Build 21)

> **Verification status.** The session model, editing, queue, storage, sync and review logic
> are covered by 33 synthetic Linux tests. The camera, recording, clip export, scanning and
> every screen have been **compiled against stand-ins only**. None of this has run on an
> iPhone yet. Detection thresholds have **not** been tuned on real practice footage. See
> the on-device checklist in the Build 21 report.

## What it does

The Analyze tab now has four ways in:

| Button | What happens |
|---|---|
| **Record Single Kick** | In-app camera → one recording → a Kick through the normal workflow → the existing analysis |
| **Start Training Session** | Name, location and kick defaults → continuous recording → kicks found afterwards → Session Review |
| **Import Video** | Unchanged from earlier builds (one kick per video) |
| **Import Training Session Video** | Same as a session, starting from a long video from Files |

A session is one practice: one or more continuous recordings ("sources") and the kicks
found in them. Each kick becomes a normal KickLab `Kick` (in a `KickingSession`), so
reports, history, results, Compare Kicks and the consistency model all work unchanged.

## Camera

- **Rear camera**, wide lens.
- **Quality:** 1080p · 60 fps (default), 1080p · 120 fps and 4K · 30/60 fps where the
  iPhone supports them, and 720p.
- **No silent downgrade.** `CaptureConfigurationSelector` picks the closest supported
  format, stepping down resolution and frame rate in a fixed order and never going above
  the requested frame rate. If anything changes, the screen says so before recording:
  "This iPhone's camera can't record X; KickLab will record Y." After configuration the
  applied frame rate is checked (1% tolerance); if it doesn't match, recording is refused
  with a message rather than recording at a different rate than shown.
- **Settings:** continuous autofocus and auto-exposure; video stabilization **off** (it
  crops and warps, which affects measurement); HEVC; 5-second movie fragments, so an
  interrupted recording is still playable up to the last fragment.
- **Orientation:** portrait UI. Turning the phone sideways records a landscape file
  (recommended, tripod).
- **Sound:** off unless the athlete turns on *Record sound* before recording. Analysis
  never uses sound. The microphone permission is asked only then.
- **Photos:** optional *Also save a copy to Photos* (single kick), with add-only access.

## Recording states (`CaptureStateMachine`)

`idle → preparing → ready → recording → finishing → saved / failed`, plus `interrupted`.

- A recording is called **saved only after** AVFoundation reports the file finished and
  usable. Until then the UI says "Saving…".
- **Interruptions** (phone call, another app takes the camera, Control Center camera),
  **going to the background**, **critical thermal state**, **low storage** and **runtime
  errors** all stop the recording cleanly and keep what was recorded, with a reason.
- **Serious thermal state:** a warning. **Critical:** recording stops and saves.
- **Permission denied:** a message pointing to Settings; the camera never starts.
- **App terminated while recording:** at the next launch, the session's source is marked
  *recovered* and kept (fragmented movie files stay playable). A single-kick recording that
  was never turned into a Kick is offered back ("A recording from … wasn't added to
  KickLab — Use It / Discard"). Nothing is deleted automatically.
- **Control Center / Siri prompts** (app "inactive") don't stop a recording; going to the
  background does (iOS also interrupts the camera there).
- **Close / Finish** are disabled while a file is still being written, and the camera is
  released only after AVFoundation has finished the file.
- **Screen lock** is disabled only while recording.

## Storage

Estimates used for the free-time display and the start check (`CaptureStoragePolicy`;
HEVC, typical, not measured on device):

| Quality | MB per minute | 30 minutes |
|---|---|---|
| 720p · 30 | 45 | ≈ 1.3 GB |
| 1080p · 30 | 60 | ≈ 1.8 GB |
| 1080p · 60 (default) | 90 | ≈ 2.7 GB |
| 1080p · 120 | 170 | ≈ 5.1 GB |
| 4K · 30 | 170 | ≈ 5.1 GB |
| 4K · 60 | 400 | ≈ 12 GB |

- 1 GB is always left free for iOS. Recording won't start with less than 3 minutes of
  space; a warning appears below 10 minutes; recording stops and saves when space runs out.
- **One full-length copy per recording.** The source lives in the session folder. Each
  kick adds a short clip (≈ 7 s, passthrough — not re-encoded) to KickLab's media, which is
  what the analysis and report use. Reanalysis reuses the same clip; nothing is copied again.
- Example: a 30-minute 1080p60 session with 40 kicks ≈ 2.7 GB source + 40 × ≈ 10 MB clips.
- The Session Review header shows the space the session's recordings use. Deleting a source (Session Review → Cameras)
  frees it; KickLab asks first and **refuses** while kicks still depend on it.

## Files (no database migration)

```
Application Support/KickLab/Sessions/<session-id>/
    manifest.json            versioned (v1), written atomically
    manifest.previous.json   last good copy; used if manifest.json is unreadable
    sources/<source-id>.mov  the full recordings
    scan/<source-id>.json    Stage A results (so a rescan isn't needed)
```

- On iOS every file is written with `completeUntilFirstUserAuthentication` protection.
- The folder is outside `Media/` and `Analysis/`, so the existing orphan sweep never
  touches it.
- **SwiftData stays at V3.** The only SwiftData records are the existing `KickingSession`,
  `Kick` and `VideoAsset`. A second camera's clip is an extra `VideoAsset` on the same Kick
  using the existing `syncOffsetSeconds` field.
- Kick intervals are stored as times in the source recording, so edits are
  non-destructive and survive relaunch.

## During recording

The session screen shows the preview, state, elapsed time, free storage, kick type, name,
distance and hash, the number of manual marks, and processing status. **Mark Kick** drops a
marker at the current time. A mark strengthens a kick found near it; a mark alone is never
counted as a kick. Marks with no kick found nearby are listed in Session Review ("Your marks
without a kick") with **Find Kick** (pick the contact frame to add it) or **Dismiss**. The defaults (kick type, distance, hash, ball type, conditions) can be changed
between kicks; each change is time-stamped, so every kick gets the details that applied
when it happened.

**Kick detection runs after Stop, not live.** Live detection would compete with the
encoder for the camera pipeline and battery; running afterwards is predictable. The
detected-kick count therefore fills in after recording.

## Processing (iOS suspension)

- One kick at a time, in the foreground, at utility priority. **Pause / Resume** in the
  header.
- **iOS suspends apps in the background**, so processing stops when KickLab leaves the
  screen. The queue is saved; anything that was running goes back to the queue and resumes
  when the athlete returns to the session. There is no background processing and no
  background recording.
- A kick that fails twice is marked failed (and needs review); Reanalyze puts it back.

## Session Review

- **Hotfix 2:**
  - Every kick card has visible **Watch Clip**, **Edit Contact** (and **Find Contact Manually**
    when contact wasn't found), **Confirm Kick**, **Reanalyze**, **Not a Kick**, **Practice**
    and result buttons.
  - The full-recording player has **Add Kick Here**.
  - The share icon exports diagnostics (`SESSION_DIAGNOSTICS.md`).
  - Contact correction is described in `CONTACT_CORRECTION.md`.
  - The camera view defaults to "not set (detected from the movement)", and you can set "Where
    the ball goes" (`NET_PRACTICE.md`).

- **Watch Full Recording** (each recording) and **Watch Clip** (each kick, confirmed or not)
  play the original file with scrubbing, frame stepping and contact/clip markers; the clip
  player also has the review actions (contact, clip start/end, confirm, not a kick, practice
  swing). Build 21 hotfix 1.
- **Several recordings in one session** on this iPhone are one camera (camera A), shown as
  "Recording 1 of 2", etc. Later recordings continue camera A's timeline from their start
  times and need no sync.
- **Status line:** looking for kicks / no kicks detected / N need your review / N waiting for
  analysis / all reviewed and analyzed — separate from the processing-queue line.

- **Overview:** candidates, confirmed, needs review, analyzed, failed; attempts with a
  result; made / missed / short; make % (only with results); results by distance and hash.
- **Kick list:** number, thumbnail, time in the recording, distance, hash, type, result,
  status, detection confidence. Tap → the kick's report.
- **Quick results:** Made · Missed left · Missed right · Short · Unknown — one tap.
- **Corrections (all non-destructive; see `MULTI_KICK_DETECTION.md`):** add a missed kick,
  "Not a kick", practice swing, clip start/end, confirm contact, split, merge with next,
  reanalyze, compare.
- **Analytics:** results by distance and hash; consistency of measurements across the
  session; first vs second half (only with ≥ 3 kicks per half, and only called a change when
  larger than both the metric's meaningful change and twice the standard error); comparison
  with the Personal Reference Kick. No fatigue diagnosis, and no score from too little data.
  Low video quality is reported as such, not as poor performance.

## Deleting

- **Not a kick** keeps the source; the kick's clip/Kick is removed (with confirmation)
  unless another active kick shares it.
- A source can't be deleted while any kick depends on it.
- Nothing is deleted without a confirmation.

## Privacy

On-device only. No upload, no cloud, no new models. The camera is used only on the
recording screens; the microphone only with *Record sound*; Photos only add-only for an
optional copy.
