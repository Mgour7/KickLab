# Football detector — model card (Step 12G, engine 2.8.0)

## What ships

| | |
|---|---|
| Asset | `KickLab/Resources/Models/YOLOXSportsBall.mlpackage` (Core ML ML Program, fp16, 18 MB on disk) |
| Compiled in the app | `YOLOXSportsBall.mlmodelc` (Xcode compiles the package; `COREML_CODEGEN_LANGUAGE: None`, loaded by URL) |
| Source model | YOLOX-S, Megvii, release 0.1.1rc0: `https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_s.onnx` |
| Source SHA-256 | `c5c2d13e59ae883e6af3b45daea64af4833a4951c92d116ec270d9ddbe998063` |
| Conversion | `Scripts/cv/convert_yolox_to_coreml.py` (coremltools 9.0; maps the ONNX graph's 10 operator types one-to-one onto Core ML MIL; the weights are not changed, only stored in fp16) |
| Input | `images`: 1×3×640×640, B, G, R planes, 0–255, letterboxed (top-left, gray 114 padding) |
| Output | `output`: 1×8400×85 — box offsets, objectness, 80 COCO class probabilities |
| Class used | 32, "sports ball" |
| License | Apache License 2.0 (YOLOX code and released weights). Notice: `THIRD_PARTY_NOTICES.md`, and in the app under Profile → Acknowledgements |
| Training data | COCO 2017 (by Megvii, not by KickLab). COCO annotations are CC BY 4.0; the COCO images come from Flickr under their own licenses |

### Licensing assessment
- Apache-2.0 allows commercial use, modification and redistribution, with the license and
  notice included. Both are included (repository file and in-app screen).
- **Needs a decision by the app's owner / counsel before commercial launch:** whether
  distributing weights *trained on* COCO raises any obligation from the COCO images'
  Flickr licenses. Common industry practice ships COCO-trained weights under the model's
  own license, but this is not a legal opinion.
- No AGPL code or weights are used. Ultralytics YOLOv5/v8/v11 (AGPL-3.0, commercial license
  sold separately) were deliberately not used.

## How it was chosen

Candidates considered (commercial-compatible licenses only):

| Option | License | Ran here on real IMG_1709 frames? | Result |
|---|---|---|---|
| YOLOX-Nano (416) | Apache-2.0 | yes | Finds the ball weakly (0.11–0.31), misses it on several frames — not usable |
| YOLOX-Tiny (416) | Apache-2.0 | yes | Finds the resting ball (0.46–0.69) but the kicked ball only at 0.18–0.24 |
| **YOLOX-S (640)** | Apache-2.0 | **yes** | **Resting ball found on every sampled frame from 2.6 s to 7.902 s: 0.27–0.79 full frame (27 of 27 broad-scan frames from 2.6 s), 0.32–0.85 in the precision crop; kicked ball 0.93 / 0.89 / 0.51 / 0.25 on the four frames after it leaves; no box while the foot covers it (7.935 s)** |
| YOLOX-M (640) | Apache-2.0 | yes | Similar recall, 2.7× slower, 101 MB — no gain |
| EfficientDet-Lite (MediaPipe) | Apache-2.0 | no — the model download (storage.googleapis.com) is blocked from this build environment | not evaluated |
| Ultralytics YOLO | AGPL-3.0 | not used | license |
| Apple Vision built-in requests | Apple SDK | — | no ball / sports-object detector exists in Vision |

CPU timing on the Linux build machine (onnxruntime, not an iPhone): nano 0.025 s, tiny 0.053 s,
S 0.14 s, M 0.39 s per frame. **No iPhone timing has been measured**; the app records the
football pass's real duration in each analysis's diagnostics (`runtime`).

## What it can and cannot do
- COCO has **no American football class**. "Sports ball" fires on the American football in
  IMG_1709 (one rear-view clip, sunny turf, holder setup). It is **not validated** on other
  clips, lighting, kicking tees, side views or other balls. That is why KickLab never takes
  a single box as truth: the kicked ball must rest in one place before the strike, be gone
  after it, be reached by the kicking foot, and be seen moving away on consecutive frames.
- It also fires on spare footballs and, weakly, on other round things; those are rejected by
  the tracking rules (and listed in diagnostics with the reason).
- Detection quality depends on scale: a 256-pixel crop around the resting ball was missed
  (score 0.08) where 384- and 686-pixel crops found it (0.67–0.86).
- It is a 2D image detector: no distance, speed, launch angle or hang time is derived.

## Verification status
- Linux (this build): the Swift decoder reproduces onnxruntime's detections on a real frame;
  the tracking logic runs on the real detections of all 61 broad-scan and 47 precision frames.
- Apple runtime (CI simulator / device, **not run here**): `FootballDetectorAppleTests` loads
  the bundled model, runs it on two real ball crops and compares with onnxruntime, and runs
  the full decode path (H.264 → 4:2:0 → letterbox → Core ML). Until that test passes in
  GitHub Actions, the Core ML conversion is unverified on Apple hardware.
