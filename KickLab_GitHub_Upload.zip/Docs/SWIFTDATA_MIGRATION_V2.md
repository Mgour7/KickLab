# SwiftData schema V2 (Step 12F)

## What changed
`KickLabSchemaV2` (version 2.0.0) is V1 plus **optional** stored properties only:

| Model | New properties |
|---|---|
| Athlete | `nickname: String?`, `photoData: Data?` (`@Attribute(.externalStorage)`), `birthYear: Int?`, `storedPrimaryRole: String?`, `storedExperienceLevel: String?`, `goals: String?`, `storedPreferredBallType: String?` |
| Kick | `storedBallType: String?`, `storedKickSetup: String?`, `conditionsNote: String?`, `storedKickDirection: String?`, `puntInsideTwenty: Bool?`, `storedPuntResult: String?` |
| KickingSession, VideoAsset, BiomechanicsAnalysis, BiomechanicalMetric, CategoryScore, CoachingObservation | unchanged copies |

Nothing is renamed, removed or retyped. Enum columns follow the existing `PersistedStringEnum` rules: raw strings are never reused, and unknown values fall back safely.

New enum raw values that are stored without a schema change:
- `KickResult.missedOther` ("missedOther");
- `ContactTimeSource.cannotTell` ("cannotTell").

An older build reading these decodes them as `unknown`.

## How it migrates
- `KickLabMigrationPlan.schemas = [V1, V2]`.
- `stages = [.lightweight(fromVersion: V1, toVersion: V2)]`.
- SwiftData adds the new columns in place. Existing rows get `nil`, and no data is transformed or deleted.
- The V1 model definitions stay frozen in `Models/*.swift` (namespace `KickLabSchemaV1`).
- The V2 copies live in `Models/SchemaV2/*V2.swift`.
- The app uses V2 through the typealiases in `KickLabSchemaV2.swift`.
- `ModelContainerFactory` builds the container with `Schema(versionedSchema: KickLabSchemaV2.self)` and the migration plan.

## If migration ever failed
`KickLabApp` already shows a recoverable startup screen instead of crashing, and nothing deletes the store. Deleting the app is never needed to upgrade.

## Verification status
- The test `Step12FPersistenceTests.aVersion1StoreOpensAsVersion2WithEveryRecordKept` writes a real V1 store to disk and reopens it with V2 and the migration plan.
- It checks that the athlete and kick survive with their values, that the new fields are nil, and that the new fields can be written.
- It needs SwiftData, so it runs only on the macOS CI runner. In this environment it was typechecked, not run.

## Step 12G: schema V3

- **What it adds:** `KickLabSchemaV3` (3.0.0) is V2 plus `VideoAsset.verificationData: Data?`. It holds the user's verified plant frame, first ball movement, ball mark and measured ball movement, as encoded `VideoVerification` JSON.
- **Unchanged:** the other seven models are copies of V2.
- **Migration stages:** `[V1→V2 lightweight, V2→V3 lightweight]`. The app opens the store with `Schema(versionedSchema: KickLabSchemaV3.self)`.
- **Frozen definitions:** V1 is in `Models/*.swift`, V2 in `Models/SchemaV2/`, V3 in `Models/SchemaV3/`.
- **Tests, typechecked here and run only on the macOS CI runner:**
  - `Step12GPersistenceTests.aVersion2StoreOpensAsVersion3WithItsVideosKept`;
  - `Step12FPersistenceTests.aVersion1StoreOpensAsTheCurrentVersionWithEveryRecordKept`.
