# Athlete Report 3.0 (Build 18)

The results screen opens on a compact Kick Report designed to be read in about 10 seconds. It adapts to how much reliable evidence the recording gave.

## Levels

| Level | Where | Contents |
|---|---|---|
| 1 Kick Report (default) | Results | Result, summary, rated areas, measurements, coaching, one focus, "Measurements not available" (collapsed); Review Video and Detailed Analysis side by side |
| 2 Detailed Analysis | "Detailed Analysis" | By phase, in expandable sections (Approach, Plant, Swing, Body Position at Contact, Follow-through); contact and tracking quality; coaching evidence; history and consistency; how scores work; kick timeline; recording notes; personal coaching; drills; comparisons; reanalysis; delete; developer links (when diagnostics are on) |
| 3 Developer Diagnostics | Toolbar / Detailed Analysis (diagnostics on) | Unchanged, plus the kicking-leg tracking report and the contact confidence split |

The report is built read-only from saved data. If it can't be built, the classic header is shown, and nothing is written.

## Kick Report

**1. Kick result** (first):
- kick type and the athlete's recorded result ("Made · 40 yd"), marked "Entered by you", or "Outcome not recorded";
- the analysis state chip: Automatic / User-assisted / Analysis incomplete;
- the camera view.

**2. Summary:**
- **Technique score** (provisional, whole number, label, analysis quality) — only when ALL of these hold:
  - the analysis completed;
  - at least 3 areas were rated;
  - analysis quality is at least Fair.
- **Limited Technique Analysis** otherwise, with what was established.
- **"No Kick Found" / "Contact Not Found" / …** when it didn't complete.
- A comparison line when enough comparable history exists — the rank, or a metric that is steadily improving.

**3. Rated areas:**
- ordered by what matters for the kick type;
- an area below medium confidence is shown with **Limited confidence** and greyed;
- it is never called a strength.

**4. Measured:**
- up to 4 reliable measurements (confidence ≥ 0.5) that aren't part of a rated area;
- each shows "Your usual …" once 4 comparable kicks exist.

**5. Coaching:**
- **strengths (≤ 2):** KEEP insights, or Good+ areas with a reason naming the in-range measurements;
- **improvements (≤ 2):** evidence-backed insights only;
- otherwise "No reliable technique correction identified from this recording."

**6. Next training focus:** one item only:
- the top improvement's drill, cue and the measurement to watch; or
- one recording sentence (e.g. "Record from the side, with the full kicker visible and the camera steady.").

**7. Measurements not available (n):** collapsed; each with a one-line reason.

**Not shown on the Kick Report:** engine version, scoring model, disclaimers, label criteria, camera-angle rules. These are in Detailed Analysis → How scores work.

## Coaching insights (`CoachingInsightBuilder`)

Each rule records:
- the supporting measurement;
- kick types;
- camera views;
- interpretation;
- cue;
- the metric to monitor;
- impact.

Each shown insight records why it was eligible.

**Classes:**
- **confirmed observation:** supporting confidence ≥ 0.75;
- **provisional observation:** 0.5–0.75, labelled "(provisional)";
- **recording recommendation**;
- **insufficient evidence:** never shown.

| Rule | Supporting metric | Kick types | Views |
|---|---|---|---|
| Plant foot moved through the strike / Stable plant | Plant-foot movement | FG, PAT, kickoff | Side |
| Kicking knee bent at contact / Leg extended | Kicking knee angle | All | Side |
| Leaning back / forward at contact | Torso lean | FG, PAT, kickoff (not punts) | Side |
| Speed changed sharply into the plant | Speed change into the plant | FG, PAT, kickoff | Side, angled |
| Follow-through stopped early | Follow-through duration | All | All |
| High finish | Follow-through leg height | All | Side |
| ~~Plant late / early~~ | — | — | Never shown (no validated criterion), including from older analyses |

**Kick goals:**
- field goal / PAT: plant and body position first;
- kickoff: approach and swing;
- punt: swing and follow-through.

The goals order the report and the coaching. No ball flight, distance, hang time or accuracy is inferred from video.

## Rankings, history and consistency (`PersonalRanking`)

**Eligibility:** only the athlete's own earlier kicks of the same kick type and view group (side / rear-front / angled). An unknown view is never ranked. Results are only ranked against the same analysis kind (assisted vs automatic), and each kick counts once.

**Per-area scoring model:** each area is compared only with kicks scored by the same rules for that area:
- Approach, Swing, Contact and Follow-Through: 2.8–3.0;
- Plant and overall: within `provisional-bands-2` only.

**Rank:** ≥ 3 comparable kicks; ties share the better rank.

**History:** previous, best, recent average (5), change, trend (slope ±2 points per kick), and spread (SD, ≥ 4 kicks).

**Consistency:**
- the mean ± SD of every measurement the view supports (≥ 4 kicks);
- a metric is "steadily improving" only when all of these hold:
  - it has a better direction;
  - it has ≥ 5 values;
  - its correlation with kick order is ≥ 0.7 in that direction.
- Descriptive metrics are never called improving.

**Same session:** the kicks in this kick's session (≥ 3) are reported separately from long-term change.

## Accessibility and layout

- Compact cards and consistent 12 pt spacing.
- The large score uses `@ScaledMetric`; all text uses text styles.
- Rows wrap on small iPhones.
- Labels are words as well as colors.
- Each area is one VoiceOver sentence.
- System colors (dark mode).
- A 72 pt bottom spacer so the last card clears the tab bar.
