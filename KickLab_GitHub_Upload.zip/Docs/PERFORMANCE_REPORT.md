# Athlete Report 4.0 (Build 19) — changes from 3.0

The 3.0 description below still applies, except where this section overrides it.

**Units and names**
- Sizes and speeds say **torso lengths** (shoulder midpoint to hip midpoint, in the same video), never "body lengths", yards or mph.
- Renamed: "Plant foot to ball (sideways)", "Plant foot vs hips (sideways)", "Plant-foot sideways slide", and the new descriptive "Knee swing after contact".
- Sideways values show their side in words instead of a sign: "0.70 torso lengths · plant-leg side", "0.43 torso lengths · kicking-leg side", "centered".
- Rounding follows the measurement's precision (no extra decimals).

**Measured rows**
- Each row has one context line saying what the number is (e.g. "How far beside the football your plant foot was at contact (sideways only).").
- The two sideways plant measurements are tappable: **Measurement inspector** shows the contact frame with the football (or hips' center), the plant ankle and the offset line drawn from the STORED pose and football detections. It is labelled "Estimated from the video · provisional (no 'ideal' value is implied)". If the pose, ball, ankle or contact is missing it says which and draws nothing.
- "Your usual X (SD y, n earlier recordings)" — from ≥ 3 EARLIER eligible recordings; this kick is never part of its own usual.

**Rated areas**
- Body Position at Contact carries the line "Posture and body movement at contact — not how the foot struck the ball." (also read by VoiceOver).

**Coaching**
- Every improvement shows: what was measured and its value, the measurement quality (confirmed / provisional), why the rule applies to this kick type and view, the cue, and what to watch on the next kick.
- The single focus card is titled **"Next training focus"** only when it is a drill backed by a measured insight; recording advice is titled **"For a better analysis"** (e.g. "Record closer, keeping the entire kicker and football visible throughout the kick.").

**History quality control**
- Per metric: same athlete, kick type, view group, analysis kind and metric definition; confidence ≥ 0.5; missing values skipped (never zero).
- Recordings left out of measurement history: **cropped** (contact within the first 0.6 s — run-up and plant not recorded) and recordings with a **blocking** recording-quality finding. The excluded counts and reasons are shown in Detailed Analysis. A cropped/blocking current kick still shows its values but isn't added to history.
- "Steadily improving": ≥ 6 eligible values, |r| ≥ 0.7 in the better direction and a fitted change ≥ the metric's documented minimum meaningful difference. Descriptive metrics and metrics without a documented minimum are never called improving.

**Layout**
- Review Video / Detailed Analysis sit in a bottom safe-area inset above the tab bar (`.safeAreaInset(edge: .bottom)`, bar material); the hard-coded 72 pt spacers are gone, so the last card is never hidden.

**Follow-through state** (Detailed Analysis → contact and tracking): observed / partly observed / inferred from the knee (limited) / not observed.

---

# Athlete Report 3.0 (Build 18)

The results screen opens on a compact Kick Report designed to be read in about 10 seconds. It adapts to how much reliable evidence the recording gave.

## Levels

| Level | Where | Contents |
|---|---|---|
| 1 Kick Report (default) | Results | Result, summary, rated areas, measurements, coaching, one focus, "Measurements not available" (collapsed); Review Video and Detailed Analysis side by side |
| 2 Detailed Analysis | "Detailed Analysis" | By phase, in expandable sections (Approach, Plant, Swing, Body Position at Contact, Follow-through); contact and tracking quality; coaching evidence; history and consistency; how scores work; kick timeline; recording notes; personal coaching; drills; comparisons; reanalysis; delete; developer links (when diagnostics are on) |
| 3 Developer Diagnostics | Toolbar / Detailed Analysis (diagnostics on) | Unchanged, plus the kicking-leg tracking report and the contact confidence split |

The report is built read-only from saved data. If it can't be built, the classic header is shown, and nothing is written.

## Kick Report

**1. Kick result** (first):
- kick type and the athlete's recorded result ("Made · 40 yd"), marked "Entered by you", or "Outcome not recorded";
- the analysis state chip: Automatic / User-assisted / Analysis incomplete;
- the camera view.

**2. Summary:**
- **Technique score** (provisional, whole number, label, analysis quality) — only when ALL of these hold:
  - the analysis completed;
  - at least 3 areas were rated;
  - analysis quality is at least Fair.
- **Limited Technique Analysis** otherwise, with what was established.
- **"No Kick Found" / "Contact Not Found" / …** when it didn't complete.
- A comparison line when enough comparable history exists — the rank, or a metric that is steadily improving.

**3. Rated areas:**
- ordered by what matters for the kick type;
- an area below medium confidence is shown with **Limited confidence** and greyed;
- it is never called a strength.

**4. Measured:**
- up to 4 reliable measurements (confidence ≥ 0.5) that aren't part of a rated area;
- each shows "Your usual …" once enough comparable kicks exist (Build 19: 3 earlier eligible recordings).

**5. Coaching:**
- **strengths (≤ 2):** KEEP insights, or Good+ areas with a reason naming the in-range measurements;
- **improvements (≤ 2):** evidence-backed insights only;
- otherwise "No reliable technique correction identified from this recording."

**6. Next training focus:** one item only:
- the top improvement's drill, cue and the measurement to watch; or
- one recording sentence (e.g. "Record from the side, with the full kicker visible and the camera steady.").

**7. Measurements not available (n):** collapsed; each with a one-line reason.

**Not shown on the Kick Report:** engine version, scoring model, disclaimers, label criteria, camera-angle rules. These are in Detailed Analysis → How scores work.

## Coaching insights (`CoachingInsightBuilder`)

Each rule records:
- the supporting measurement;
- kick types;
- camera views;
- interpretation;
- cue;
- the metric to monitor;
- impact.

Each shown insight records why it was eligible.

**Classes:**
- **confirmed observation:** supporting confidence ≥ 0.75;
- **provisional observation:** 0.5–0.75, labelled "(provisional)";
- **recording recommendation**;
- **insufficient evidence:** never shown.

| Rule | Supporting metric | Kick types | Views |
|---|---|---|---|
| Plant foot moved through the strike / Stable plant | Plant-foot movement | FG, PAT, kickoff | Side |
| Kicking knee bent at contact / Leg extended | Kicking knee angle | All | Side |
| Leaning back / forward at contact | Torso lean | FG, PAT, kickoff (not punts) | Side |
| Speed changed sharply into the plant | Speed change into the plant | FG, PAT, kickoff | Side, angled |
| Follow-through stopped early | Follow-through duration | All | All |
| High finish | Follow-through leg height | All | Side |
| ~~Plant late / early~~ | — | — | Never shown (no validated criterion), including from older analyses |

**Kick goals:**
- field goal / PAT: plant and body position first;
- kickoff: approach and swing;
- punt: swing and follow-through.

The goals order the report and the coaching. No ball flight, distance, hang time or accuracy is inferred from video.

## Rankings, history and consistency (`PersonalRanking`)

**Eligibility:** only the athlete's own earlier kicks of the same kick type and view group (side / rear-front / angled). An unknown view is never ranked. Results are only ranked against the same analysis kind (assisted vs automatic), and each kick counts once.

**Per-area scoring model:** each area is compared only with kicks scored by the same rules for that area:
- Approach, Swing, Contact and Follow-Through: 2.8–3.0;
- Plant and overall: within `provisional-bands-2` only.

**Rank:** ≥ 3 comparable kicks; ties share the better rank.

**History:** previous, best, recent average (5), change, trend (slope ±2 points per kick), and spread (SD, ≥ 4 kicks).

**Consistency:**
- the mean ± SD of every measurement the view supports (≥ 4 kicks);
- a metric is "steadily improving" only when all of these hold:
  - it has a better direction;
  - it has ≥ 5 values;
  - its correlation with kick order is ≥ 0.7 in that direction.
- Descriptive metrics are never called improving.

**Same session:** the kicks in this kick's session (≥ 3) are reported separately from long-term change.

## Accessibility and layout

- Compact cards and consistent 12 pt spacing.
- The large score uses `@ScaledMetric`; all text uses text styles.
- Rows wrap on small iPhones.
- Labels are words as well as colors.
- Each area is one VoiceOver sentence.
- System colors (dark mode).
- (Build 18) A 72 pt bottom spacer; replaced in Build 19 by a bottom safe-area inset.
