# Performance Report 2.0 (Build 16)

The results screen now opens on a Quick Report. The goal: after a kick, the athlete can see at a glance:
- their strongest mechanic;
- their weakest mechanic;
- their personal standing;
- the single most useful thing to practice next.

None of this requires reading engineering diagnostics.

## Levels

| Level | Where | Contents |
|---|---|---|
| 1 Quick Report (default) | Results → opens here | The five sections below, plus the video, "Verify Contact" when contact needs checking, and the "Detailed Analysis" button. |
| 2 Detailed Analysis | "Detailed Analysis" button | Per-area measurements with "Not rated" items, measurement quality and rank. Also: timing, history exclusions, label criteria, and the full Step 12F coaching report (phases, coaching, drills, comparisons, all metrics, notes, reanalysis, delete). |
| 3 Developer Diagnostics | Toolbar (only when diagnostics are enabled in Profile) | Unchanged: diagnostics export, evidence bundles, Pose Validation, evidence timeline. |

**Safety of saved data:**
- The report is built read-only from saved data (`PerformanceReport.make`).
- If it can't be built, the classic header is shown instead.
- Nothing in the report writes to the analysis.

## The five Quick Report sections

### 1. Kick Performance
- Kick type, camera view and analysis quality (Good / Fair / Limited / Not available — rule-based, from the analysis confidence and blocking recording findings).
- **The overall score is shown only when all of these hold:**
  - the analysis completed;
  - the engine produced an overall score (≥ 3 rated areas);
  - analysis quality isn't "Not available".
- Otherwise it shows one of:
  - "Partial Analysis — Overall Score Unavailable";
  - "No Kick Found";
  - "Contact Not Found — No Score";
  - "Recording Too Limited — No Score";
  - "Analysis Didn't Run".
- Label: Excellent / Good / Developing / Needs Work (`Docs/SCORING_AUDIT.md` §6). The score is always labelled "Technique score · provisional".
- History strip:
  - previous, personal best, recent average, change and trend;
  - like-for-like only;
  - otherwise: "Your history will build as you analyze more kicks of this type from the same view."

### 2. Performance Rankings
Up to five areas (Approach, Plant, Swing, Body Position at Contact, Follow-Through). Each shows:
- the score (whole number) and its label;
- a quality dot;
- its personal rank, or "Not enough comparable kicks to rank";
- or "Not rated" with a short reason.

**Score, rank and percentile are distinct.** Percentiles are never shown, because no documented dataset exists.

### 3. What You Did Well
At most 3 items:
- measured KEEP findings first;
- then areas rated Good or better, with at least Fair measurement quality.

No filler. An empty section is hidden.

### 4. What Needs Work
At most 3 measured IMPROVE findings. Each has a title, the observed issue and one cue.

### 5. Next Training Focus
- **Normally:** 1–2 drills (from `DrillLibrary`), each with what to practice, why (the observed issue) and which measurement should change.
- **When the analysis is Limited, Not available or didn't complete:** "Record a clearer clip first", with the recording findings or the standard filming advice.

**Result (entered by you):**
- The made/missed result and distance the user typed in, shown separately.
- It never changes the technique score.
- It is never described as measured.

## Personal ranking eligibility (`PersonalRanking`)

A kick is compared only with the same athlete's other kicks that meet all of these:
1. Another kick: re-analyses of the same kick don't count twice. Each kick contributes its current analysis.
2. Recorded on or before this kick, so a rank never changes when later kicks are added.
3. Analysis completed.
4. Same kick type.
5. Same view group:
   - side;
   - rear/front ("depth");
   - angled (oblique / behind the goal).
   - An unrecorded view is never ranked.
6. Same scoring model: `provisional-bands-1` = engines 2.8.x–2.9.x. Kicks from older engines are counted and named ("Not compared: N scored by an older engine").
7. Same analysis kind: user-assisted results are ranked only against user-assisted results.

**Rank rules:**
- 1 + the number of comparable kicks with a strictly higher value; ties share the better rank.
- Needs at least 3 comparable kicks including this one.
- A missing score is never ranked and never counted as zero.

**History rules:**

| Item | Rule |
|---|---|
| Previous | The most recent earlier comparable overall score. |
| Best | The highest, this kick included. |
| Recent average | The last 5 earlier comparable kicks. |
| Change | Now − previous. |
| Trend | The least-squares slope over the last 5 comparable kicks (this one included). Improving above +2 points per kick, declining below −2, otherwise steady. Shown only with ≥ 3 kicks. |

## Accessibility and layout
- The large score uses `@ScaledMetric`, so it scales with Dynamic Type.
- All text uses text styles.
- Rows wrap at two lines on small iPhones.
- Labels are always words as well as colors.
- Each area row is one VoiceOver element: "Plant: 74 out of 100, Good. #2 of 5 comparable kicks. Measurement quality Fair."
- The score is announced as "Overall technique score N out of 100, label. Provisional."
- System colors are used, so dark mode works.
