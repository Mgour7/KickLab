import Foundation
import Testing
@testable import KickLab

/// Step 12D: kick windows, the contact regression on the real reference clip, phase
/// ordering, user-assisted analysis, recording suitability and failure classification.
@Suite("Step 12D kick windows, regression and recovery")
struct KickWindowAndRecoveryTests {
    typealias Script = SyntheticPose.KickScript
    typealias Real = RealReferenceClip220

    private func detect(_ timeline: KickerPoseTimeline, foot: KickingFoot = .right, kickType: KickType = .fieldGoal,
                        assistance: PhaseDetectionAssistance? = nil) -> (signals: PoseSignalSet, phases: KickPhaseDetectionResult) {
        let signals = PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(timeline), kickingFoot: foot)
        return (signals, KickPhaseDetector.detect(signals, kickType: kickType, assistance: assistance))
    }

    private func contactError(_ phases: KickPhaseDetectionResult, _ truth: Double) -> Double {
        let estimate: Double = phases.estimatedContactTime ?? .infinity
        return abs(estimate - truth)
    }

    // MARK: Milestone 1 — the real reference clip (engine 2.2.0 diagnostics, verbatim)

    @Test func engine220RankingIsReproducedExactlyFromTheExportedEvidence() {
        // Re-scoring each 2.2.0 candidate's exported evidence with the unchanged weights
        // gives the exported scores, and the late 6.035 s movement wins: the regression.
        var best: (time: Double, score: Double) = (0, -1)
        for c in Real.candidates220 {
            let score = ContactEstimator.score(relativeSpeed: c.relativeSpeed, swingSupport: c.swingSupport,
                                               forwardDirection: c.forwardDirection, plantSupport: c.plantSupport,
                                               passTiming: c.passTiming, bodyTransition: c.bodyTransition,
                                               followThrough: c.followThrough)
            if c.hardRejected { continue }
            #expect(abs(score - c.exportedScore) < 0.001, "candidate \(c.time)")
            if score > best.score { best = (c.time, score) }
        }
        #expect(abs(best.time - Real.contactSelectedBy220) < 1e-9, "engine 2.2.0 chose the recovery movement")
        #expect(Real.candidates220.first { $0.selectedBy220 }?.time == Real.contactSelectedBy220)
    }

    @Test func rankingCandidatesWithoutAKickWindowIsUnreliableOnTheRealSeries() {
        // With no kick window, even 2.3.0's per-candidate rules pick a movement outside the
        // kick (here the pre-kick stride at 1.87 s): evidence-only ranking is not enough.
        let estimate = ContactEstimator.estimate(Real.signals, profile: .placeKick)
        let chosen: Double = estimate.selected?.time ?? 0
        #expect(abs(chosen - Real.markedContact) > 0.3)
    }

    @Test func theNewDetectorDoesNotSelectTheRecoveryEventOnTheRealSeries() throws {
        let phases = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal)
        let window = try #require(phases.kickWindows?.selected)
        #expect(window.source == "approach")
        #expect(window.containsStrike(Real.markedContact), "the marked strike lies in the kick window")
        #expect(!window.containsStrike(Real.contactSelectedBy220), "the 6.035 s movement is outside it")
        #expect(phases.kickWindows?.needsSelection == false)

        let contact: Double = try #require(phases.estimatedContactTime)
        #expect(abs(contact - Real.contactSelectedBy220) > 3, "not the recovery event")
        let error: Double = contact - Real.markedContact
        #expect(abs(error) < 0.167, "closer to the marked strike than engine 2.1.0's −0.167 s")
        #expect(abs(error) <= 0.1, "within three frames of the (approximate) mark")
        #expect(contact >= (phases.plantTime ?? 0), "contact comes after the plant landing")
        let late = phases.evidence?.contactCandidates?.first { abs($0.time - Real.contactSelectedBy220) < 1e-6 }
        #expect(late?.rejectionReasons.contains { $0.contains("outside the kick window") } == true)
        #expect(phases.evidence?.contactTimingBasis == "automatic")
        #expect(phases.evidence?.contactTimingMethod == "plantAndFootPassing", "the speed peak (2.33 s) came before the plant landing")

        // Plant: a one-frame stop at the end of braking, unstable afterwards.
        #expect(phases.phase(.plant).status == .estimated)
        #expect(phases.evidence?.plantState == .unstableAfterTouchdown)
        let plant: Double = phases.plantTime ?? 0
        #expect(plant > 2.3 && plant < Real.markedContact)
        // Follow-through: honestly unavailable — the kicking ankle merges with the plant
        // ankle after contact and the camera pans.
        #expect(phases.phase(.followThrough).status == .unavailable)
        #expect(phases.evidence?.kickingAnkleMergedAfterContact == true)
        #expect(phases.evidence?.cameraMotionSuspected == true)
        #expect(phases.phase(.contact).status == .estimated, "never 'measured'")
        // The marked contact is never an input.
        #expect(phases.assistance == nil)
        #expect(KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal) == phases, "deterministic")
    }

    @Test func theRealFailureIsAPhaseProblemNotPoorBodyDetection() {
        // The 2.2.0 report's evidence: 16 scored metrics, all confidence-blocked, joints
        // detected well (mean quality 0.78) but phase factors low (mean 0.26), contact ambiguous.
        var e = AnalysisFailureEvidence(
            scoredMetricCount: 16, availableScoredMetrics: 4, blockedByMissingPhase: 0, blockedByMissingJoints: 0,
            blockedByConfidence: 16, rescuedWithoutCameraPenalty: 0, otherUnavailable: 0, kickerTrackedFraction: 1,
            missingPhases: [], cameraFactor: 1, kickingAnkleCoverage: 1
        )
        e.meanPhaseFactorOfConfidenceBlocked = 0.259
        e.meanJointQualityOfConfidenceBlocked = 0.783
        e.contactStatus = .ambiguous
        e.kickWindowCount = 1
        e.needsKickSelection = false
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .ambiguousContact)
        // Genuinely poor joints still read as low pose confidence.
        e.meanJointQualityOfConfidenceBlocked = 0.3
        e.meanPhaseFactorOfConfidenceBlocked = 0.85
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .lowPoseConfidence)
        // A tiny athlete is reported as such.
        e.torsoHeightFraction = 0.03
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .athleteTooSmall)
    }

    // MARK: Milestone 2 — kick windows

    @Test func postKickMovementIsRecoveryNotASecondKick() {
        var s = Script.realWorld30fps
        s.extraSwingStart = 4.5   // a leg swing while standing, after the kick
        let (_, phases) = detect(SyntheticPose.timeline(s))
        #expect(contactError(phases, s.expectedContact) <= 1 / s.frameRate + 1e-9)
        #expect(phases.kickWindows?.needsSelection == false)
        let later = phases.evidence?.contactCandidates?.filter { $0.time > 4 } ?? []
        #expect(!later.isEmpty)
        #expect(later.allSatisfy { $0.rejectionReasons.contains { $0.contains("outside the kick window") } })
    }

    @Test func multipleRealKicksAreDetectedAndNeedAChoice() throws {
        let timeline = SyntheticPose.concatenated([.fieldGoal, .fieldGoal])
        let (_, phases) = detect(timeline)
        let windows = try #require(phases.kickWindows)
        #expect(windows.windows.filter(\.hasSwing).count == 2)
        #expect(windows.needsSelection)
        #expect(phases.phase(.contact).status == .ambiguous, "not silently analyzing one of them")

        // The user picks the second kick: analyzed there, labeled user-assisted.
        let second = Script.fieldGoal.duration + Script.fieldGoal.expectedContact
        let (_, chosen) = detect(timeline, assistance: PhaseDetectionAssistance(windowStart: 2.2, windowEnd: 4.0))
        #expect(contactError(chosen, second) <= 1 / 60.0 + 1e-9)
        #expect(chosen.phase(.contact).status == .estimated)
        #expect(chosen.isUserAssisted)
        let (_, first) = detect(timeline, assistance: PhaseDetectionAssistance(windowStart: 0, windowEnd: 2.0))
        #expect(contactError(first, Script.fieldGoal.expectedContact) <= 1 / 60.0 + 1e-9)
    }

    @Test func twoKicksThroughThePipelineAreDiagnosedAsMultipleKicks() {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(from: SyntheticPose.concatenated([.fieldGoal, .fieldGoal])),
            kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side
        ))
        #expect(out.tracking.status == .selected)
        #expect(out.failureCause == .multipleKickWindows)
        #expect(AnalysisProblem.from(.multipleKickWindows) == .multipleKicksFound)
        let summary = PoseAnalysisSummary(primaryVideoID: UUID(), output: out)
        #expect(summary.needsKickSelection)
        #expect(summary.kickWindowCount == 2)
        // Choosing the second kick analyzes it.
        let chosen = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(from: SyntheticPose.concatenated([.fieldGoal, .fieldGoal])),
            kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side,
            assistance: PhaseDetectionAssistance(windowStart: 2.2, windowEnd: 4.0)
        ))
        #expect(chosen.failureCause == nil)
        #expect(chosen.biomechanics.availableCategoryCount > 0)
        #expect(PoseAnalysisSummary(primaryVideoID: UUID(), output: chosen).isUserAssisted)
    }

    @Test func aStandingKickWithoutApproachUsesTheSwingWithLowWindowConfidence() throws {
        var s = Script.fieldGoal
        s.approachSpeed = 0
        let (_, phases) = detect(SyntheticPose.timeline(s))
        let window = try #require(phases.kickWindows?.selected)
        #expect(window.source == "swingOnly")
        #expect(window.confidence <= 0.3)
        #expect(contactError(phases, s.expectedContact) <= 1 / s.frameRate + 1e-9)
    }

    @Test func windowsWorkForEveryFootAndDirectionAndKickType() {
        for foot in [KickingFoot.right, .left] {
            for direction in [1.0, -1.0] {
                var s = Script.realWorld30fps
                s.kickingFoot = foot
                s.direction = direction
                if direction < 0 { s.startX = 0.88 }
                let (_, phases) = detect(SyntheticPose.timeline(s), foot: foot)
                #expect(phases.kickWindows?.selected?.containsStrike(s.expectedContact) == true, "\(foot) \(direction)")
                #expect(contactError(phases, s.expectedContact) <= 1 / s.frameRate + 1e-9)
            }
        }
        let (_, kickoff) = detect(SyntheticPose.timeline(.kickoff), kickType: .kickoff)
        #expect(contactError(kickoff, Script.kickoff.expectedContact) <= 1 / 60.0 + 1e-9)
        let (_, pat) = detect(SyntheticPose.timeline(.fieldGoal), kickType: .pat)
        #expect(contactError(pat, Script.fieldGoal.expectedContact) <= 1 / 60.0 + 1e-9)
        let (_, punt) = detect(SyntheticPose.timeline(.fieldGoal), kickType: .punt)
        #expect(punt.support == .limited)
        #expect(punt.phase(.plant).status == .unavailable)
        #expect(punt.phase(.contact).isAvailable)
    }

    // MARK: Milestone 3 — plant and follow-through, chronology

    @Test func plantIsFoundFromTheWindowIndependentlyOfContact() {
        let s = Script.realWorld30fps
        let (_, phases) = detect(SyntheticPose.timeline(s))
        let prior: Double = phases.evidence?.plantPriorTime ?? 0
        #expect(abs(prior - (phases.plantTime ?? -1)) < 1e-9)
        #expect(abs(prior - s.plantTime) <= 2 / s.frameRate + 1e-9)
    }

    @Test func aSpeedPeakBeforeThePlantLandsIsTimedAfterThePlant() {
        // The kicking foot's visible speed peak comes before the plant foot lands (as on the
        // real clip): contact can't precede the plant, so it is timed after it.
        var s = Script.realWorld30fps
        s.plantTime = 2.3
        s.plantStepDuration = 0.3
        s.plantLiftAtContact = 0
        s.approachEnd = 2.3
        s.swingStart = 2.0      // speed peak at 2.2, before the plant lands at 2.3
        let (_, phases) = detect(SyntheticPose.timeline(s))
        let contact: Double = phases.estimatedContactTime ?? 0
        let plant: Double = phases.plantTime ?? 99
        #expect(contact > plant, "chronological: plant before contact")
        #expect(phases.evidence?.contactTimingBasis == "automatic")
        #expect(phases.evidence?.contactTimingMethod == "plantAndFootPassing")
        #expect(phases.notes.contains { $0.contains("before the plant landing") })
        let r = SyntheticBiomechanics.analyze(s)
        #expect(r.measurement(.footSpeedAtContact)?.unavailableReason == .kickingLegNotTracked,
                "no precise foot speed from a constraint-timed contact")
    }

    @Test func aKickingFootLostAfterContactMakesFollowThroughUnavailableNotInvented() {
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        SyntheticPose.kickingFootLost(&t, from: s.expectedContact + 0.04)
        let (_, phases) = detect(t)
        #expect(phases.evidence?.kickingAnkleMergedAfterContact == true)
        #expect(phases.phase(.followThrough).status == .unavailable)
        #expect(phases.notes.contains { $0.contains("isn't tracked separately") })
        let r = SyntheticBiomechanics.analyze(s, timeline: t)
        #expect(r.measurement(.kickingKneeAngleAtContact)?.unavailableReason == .kickingLegNotTracked)
        #expect(r.measurement(.footSpeedAtContact)?.isAvailable == false)
    }

    @Test func cameraPanningAfterTheKickIsDetected() {
        let s = Script.realWorld30fps
        // The camera follows the ball for 0.6 s after the kick, then stops.
        let t = SyntheticPose.panned(SyntheticPose.timeline(s), from: s.expectedContact + 0.05, speed: 0.3, for: 0.6)
        let (signals, phases) = detect(t)
        #expect(phases.evidence?.cameraMotionSuspected == true)
        #expect(contactError(phases, s.expectedContact) <= 1 / s.frameRate + 1e-9)
        let findings = RecordingSuitability.assess(sequence: nil, kickerTimeline: nil, signals: signals, cameraAngle: .side, phases: phases)
        #expect(findings.contains { $0.kind == .cameraMoving })
        let (_, still) = detect(SyntheticPose.timeline(s))
        #expect(still.evidence?.cameraMotionSuspected == false)
    }

    // MARK: Milestone 4 — timeline

    @Test func theTimelineShowsWindowPhasesRecoveryAndStatuses() {
        let (_, phases) = detect(SyntheticPose.timeline(.realWorld30fps))
        let segments = PhaseTimelineModel.segments(phases: phases, windows: phases.kickWindows, frame: 1 / 30.0)
        let kinds = segments.map(\.kind)
        #expect(kinds.first == .kickWindow)
        for kind in [TimelineSegment.Kind.approach, .plant, .contact, .followThrough, .recovery] { #expect(kinds.contains(kind), "\(kind)") }
        #expect(segments.allSatisfy { $0.end >= $0.start })
        #expect(segments.first { $0.kind == .contact }?.status == .estimated)
        #expect(PhaseTimelineModel.style(.detected) == "solid")
        #expect(PhaseTimelineModel.style(.estimated) == "light")
        #expect(PhaseTimelineModel.style(.ambiguous) == "dashed")
        #expect(PhaseTimelineModel.style(.unavailable) == "none")
        #expect(PhaseTimelineModel.fraction(3, duration: 6) == 0.5)
        #expect(PhaseTimelineModel.fraction(9, duration: 6) == 1)
    }

    @Test func candidateEvidenceIsExplainedOnTheTimeline() throws {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.backswingPattern), kickType: .fieldGoal, kickingFoot: .right
        ))
        let replay = DiagnosticsReplay.run(AnalysisDiagnosticsInput(output: out), kickingFoot: .right)
        let t = try #require(PoseValidationTimeline.make(
            sequence: out.sequence, storedTimeline: out.kickerTimeline, currentTimeline: replay?.timeline,
            repair: replay?.replay.repair, kickingFoot: .right, storedPhases: out.phases, currentPhases: replay?.phases,
            markedContact: nil))
        #expect(t.markers.contains { $0.kind == .contactCandidate && ($0.detail?.contains("rejected:") ?? false) })
        #expect(t.markers.first { $0.kind == .contact }?.detail?.contains("Speed") == true)
        #expect(!t.segments.isEmpty)
        #expect(t.kickWindows?.selected != nil)
    }

    // MARK: Milestone 5 — user-assisted analysis

    @Test func aUserContactFrameIsUsedAndLabeled() {
        let s = Script.realWorld30fps
        let chosen = 2.4
        let (_, phases) = detect(SyntheticPose.timeline(s), assistance: PhaseDetectionAssistance(contactTime: chosen))
        #expect(abs((phases.estimatedContactTime ?? 0) - chosen) <= 0.5 / s.frameRate + 1e-9)
        #expect(phases.isUserAssisted)
        #expect(phases.evidence?.contactTimingBasis == "user")
        #expect(phases.evidence?.userAssistedContactTime != nil)
        #expect(phases.notes.first?.contains("chosen by the user") == true)
        #expect(phases.phase(.contact).status == .estimated)
        #expect(phases.phase(.plant).isAvailable, "plant re-evaluated around the user's frame")
        // Automatic detection on the same clip is unaffected.
        let (_, automatic) = detect(SyntheticPose.timeline(s))
        #expect(!automatic.isUserAssisted)
        #expect(automatic.estimatedContactTime != phases.estimatedContactTime)
    }

    @Test func userAssistedAnalysesAreLabeledAndExcludedFromAccuracy() async throws {
        #expect(AnalysisAssistanceLabel.version("pose-biomechanics-2.3.0", assistance: nil) == "pose-biomechanics-2.3.0")
        #expect(AnalysisAssistanceLabel.version("pose-biomechanics-2.3.0", assistance: PhaseDetectionAssistance()) == "pose-biomechanics-2.3.0")
        let assisted = AnalysisAssistanceLabel.version("pose-biomechanics-2.3.0", assistance: PhaseDetectionAssistance(contactTime: 2))
        #expect(assisted == "pose-biomechanics-2.3.0+assisted")
        #expect(AnalysisAssistanceLabel.isAssisted(assisted))

        // Through the real engine: the result and the stored files carry the label and the
        // exact user input.
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        let kickID = UUID(), videoID = UUID(), analysisID = UUID()
        let path = ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: "mov")
        try temp.writeFile(path, under: store.mediaRootURL)
        let engine = PoseVideoAnalysisService(mediaStore: store, extractor: FakePoseExtractor { SyntheticPose.sequence(.realWorld30fps, videoID: $0) })
        let help = PhaseDetectionAssistance(contactTime: 2.4)
        let request = VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [
            VideoAnalysisInput(videoID: videoID, angle: .side, isPrimary: true, relativeFilePath: path, frameRate: 30,
                               durationSeconds: 6.5, syncOffsetSeconds: 0, contactTimeSeconds: nil),
        ], options: VideoAnalysisOptions(artifactsDirectoryID: analysisID, assistance: help))
        let result = try await engine.analyze(request) { _ in }
        #expect(result.engineVersion == PoseVideoAnalysisService.version + "+assisted")
        #expect(result.poseSummary?.isUserAssisted == true)
        let bundle = try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL).readBundle(in: try #require(result.artifactsRelativePath))
        #expect(bundle.manifest.assistance == help, "exactly what the user supplied")
        #expect(bundle.phases.phases.assistance == help)

        // Accuracy statistics never include user-assisted checks.
        var check = ContactTimingCheck(label: "assisted", referenceTime: 2.4, estimatedTime: 2.4, confidence: 0.6,
                                       sourceFrameRate: 30, analysisFrameRate: 30)
        check.excludedFromAccuracy = true
        let automatic = ContactTimingCheck(label: "auto", referenceTime: 2.5, estimatedTime: 2.6, confidence: 0.5,
                                           sourceFrameRate: 30, analysisFrameRate: 30)
        let summary = ContactTimingSummary([check, automatic])
        #expect(summary.count == 1)
        #expect(summary.withinToleranceFraction == 0)
    }

    @Test func recoveryIsOfferedOnlyWhenAutomaticDetectionIsUncertain() {
        let (_, clean) = detect(SyntheticPose.timeline(.realWorld30fps))
        #expect(AssistanceOffer.make(phases: clean, engineVersion: "pose-biomechanics-2.3.0") == .none)
        let (_, two) = detect(SyntheticPose.concatenated([.fieldGoal, .fieldGoal]))
        #expect(AssistanceOffer.make(phases: two, engineVersion: "pose-biomechanics-2.3.0") == .chooseKick)
        let real = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal)
        #expect(AssistanceOffer.make(phases: real, engineVersion: "pose-biomechanics-2.3.0") == .chooseContact,
                "contact timed by constraints, not a measured strike")
        #expect(AssistanceOffer.make(phases: real, engineVersion: "pose-biomechanics-2.3.0+assisted") == .none,
                "never offered again on a user-assisted result")
        #expect(AssistanceOffer.make(phases: nil, engineVersion: "x") == .none)
        #expect(AnalysisProblem.contactUncertain.offersContactSelection)
        #expect(AnalysisProblem.multipleKicksFound.offersKickSelection)
        #expect(!AnalysisProblem.athleteTooSmall.offersContactSelection)
        #expect(AnalysisProblem.contactUncertain.message.contains("Select the frame where your foot contacts the ball"))
    }

    @Test func analysisModesAreDistinguished() {
        func record(_ version: String, _ status: ProcessingStatus) -> AnalysisRecord {
            AnalysisRecord(id: UUID(), kickID: UUID(), kickType: .fieldGoal, kickDate: nil, createdAt: Date(timeIntervalSince1970: 0),
                           completedAt: nil, status: status, isCurrent: true, overallScore: nil, confidence: nil,
                           failureReason: nil, engineVersion: version, metrics: [], categories: [], observations: [])
        }
        func card(_ score: Double?) -> CategoryCardPresentation {
            CategoryCardPresentation(category: .plant, title: "Plant", score: score, scoreText: "", grade: .unavailable,
                                     confidence: nil, confidenceText: "", summary: nil, topMetrics: [], unavailableMetricNames: [])
        }
        #expect(AnalysisMode.of(record("v", .completed), categories: [card(80), card(70)]) == .automatic)
        #expect(AnalysisMode.of(record("v", .completed), categories: [card(80), card(nil)]) == .partial)
        #expect(AnalysisMode.of(record("v+assisted", .completed), categories: [card(80)]) == .userAssisted)
        #expect(AnalysisMode.of(record("v", .failed), categories: []) == .needsBetterFootage)
        #expect(AnalysisMode.userAssisted.explanation.contains("isn't counted as automatic accuracy"))
    }

    @Test func kickLevelValidationMetricsOnTheSyntheticCollection() {
        func kickCase(_ label: String, _ s: Script, kickType: KickType = .fieldGoal, hasFollow: Bool = true) -> KickDetectionCase {
            let r = SyntheticBiomechanics.analyze(s, kickType: kickType)
            let (_, phases) = detect(SyntheticPose.timeline(s), foot: s.kickingFoot, kickType: kickType)
            return KickDetectionCase(label: label, truthContact: s.expectedContact, truthHasPlant: true,
                                     truthHasFollowThrough: hasFollow, phases: phases, scoredCategories: r.availableCategoryCount)
        }
        var lefty = Script.realWorld30fps; lefty.kickingFoot = .left
        var reversed = Script.realWorld30fps; reversed.direction = -1; reversed.startX = 0.88
        var recovery = Script.realWorld30fps; recovery.extraSwingStart = 4.5
        var noKick = Script.realWorld30fps; noKick.swingDistance = 0
        var standingStill = Script.fieldGoal; standingStill.approachSpeed = 0; standingStill.swingDistance = 0
        let noKickPhases = detect(SyntheticPose.timeline(noKick)).phases
        let standingPhases = detect(SyntheticPose.timeline(standingStill)).phases
        let cases = [
            kickCase("field goal", .fieldGoal), kickCase("PAT", .fieldGoal, kickType: .pat), kickCase("kickoff", .kickoff, kickType: .kickoff),
            kickCase("realistic 30 fps", .realWorld30fps), kickCase("backswing peak", .backswingPattern),
            kickCase("left-footed", lefty), kickCase("reversed", reversed), kickCase("post-kick recovery", recovery),
            KickDetectionCase(label: "approach without a kick", truthContact: nil, phases: noKickPhases),
            KickDetectionCase(label: "standing still", truthContact: nil, phases: standingPhases),
        ]
        let summary = KickDetectionSummary(cases)
        #expect(summary.cases == 10)
        #expect(summary.correctWindowRate == 1)
        #expect(summary.falsePositiveStrikeRate == 0, "no strike reported when there was no kick")
        #expect(summary.unavailableRate == 0)
        #expect(summary.plantDetectionRate == 1)
        #expect(summary.followThroughDetectionRate == 1)
        #expect((summary.meanScoredCategories ?? 0) >= 4)
    }

    // MARK: Milestone 6 — suitability and failure classification

    @Test func aDistantKickerIsTooSmall() {
        let t = SyntheticPose.scaled(SyntheticPose.timeline(.realWorld30fps), by: 0.25)
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(from: t), kickType: .fieldGoal,
                                                                     kickingFoot: .right, cameraAngle: .behindGoal))
        #expect(out.suitability.contains { $0.kind == .kickerTooSmall && $0.severity == .blocking })
        #expect(out.suitability.contains { $0.kind == .cameraAngle })
        #expect(out.suitability.first { $0.kind == .kickerTooSmall }?.message.contains("Move closer") == true)
    }

    @Test func behindGoalFootageWithNoDetectablePersonGetsGuidance() {
        var sequence = SyntheticPose.sequence(.fieldGoal)
        for i in sequence.frames.indices { sequence.frames[i].bodies = [] }
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                                     cameraAngle: .behindGoal))
        #expect(out.tracking.status == .noCandidates)
        let finding = out.suitability.first { $0.kind == .noPersonDetected }
        #expect(finding?.severity == .blocking)
        #expect(finding?.message.contains("behind the goal") == true)
        #expect(AnalysisProblem.noKickerFound.message.contains("behind the goal"))
        #expect(AnalysisProblem.from(kickerStatus: .noCandidates, failureReason: "x") == .noKickerFound)
    }

    @Test func otherSuitabilityFindings() {
        // Rear camera, 30 fps, two people, feet leaving the frame, too few frames.
        var s = Script.realWorld30fps
        s.duration = 0.8
        var t = SyntheticPose.timeline(s)
        for i in t.samples.indices where (0.2...0.7).contains(t.samples[i].timestamp) { t.samples[i].joints[.leftAnkle] = .unavailable }
        var sequence = SyntheticPose.sequence(from: t)
        sequence.frames[0].bodies.append(SyntheticPose.holder(at: 0))
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                                     cameraAngle: .rear))
        let kinds = Set(out.suitability.map(\.kind))
        #expect(kinds.contains(.cameraAngle))
        #expect(kinds.contains(.frameRateBlursKick))
        #expect(kinds.contains(.multiplePeople))
        #expect(kinds.contains(.tooFewFrames))
        #expect(kinds.contains(.bodyLeavesFrame))
        // A clean side-view 60 fps recording has no limiting findings.
        let clean = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal,
                                                                       kickingFoot: .right, cameraAngle: .side))
        #expect(clean.suitability.allSatisfy { $0.severity == .info })
    }

    @Test func newFailureCausesHaveDistinctActionableMessages() {
        let causes: [AnalysisFailureCause] = [.noCredibleKickWindow, .multipleKickWindows, .ambiguousContact, .plantUnavailable,
                                              .followThroughUnavailable, .athleteTooSmall]
        let problems = causes.map(AnalysisProblem.from)
        #expect(Set(problems.map(\.title)).count == causes.count)
        for (cause, problem) in zip(causes, problems) {
            #expect(AnalysisProblem.from(kickerStatus: .selected, failureReason: cause.reasonText) == problem)
            #expect(problem.canRetry)
            #expect(!problem.message.lowercased().contains("visible clearly enough"), "not described as poor visibility")
        }
        // Phase causes from evidence.
        var e = AnalysisFailureEvidence(scoredMetricCount: 10, availableScoredMetrics: 0, blockedByMissingPhase: 8,
                                        blockedByMissingJoints: 0, blockedByConfidence: 2, rescuedWithoutCameraPenalty: 0,
                                        otherUnavailable: 0, kickerTrackedFraction: 1, missingPhases: [.plant],
                                        cameraFactor: 1, kickingAnkleCoverage: 1)
        e.kickWindowCount = 1
        e.contactStatus = .estimated
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .plantUnavailable)
        e.missingPhases = [.followThrough]
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .followThroughUnavailable)
        e.needsKickSelection = true
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .multipleKickWindows)
        e.needsKickSelection = false
        e.kickWindowCount = 0
        e.missingPhases = [.contact, .plant, .followThrough]
        e.contactStatus = .unavailable
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .noCredibleKickWindow)
    }

    // MARK: Milestone 7 — compatibility and exports

    @Test func olderPhaseFilesAndManifestsStillDecode() throws {
        let (_, phases) = detect(SyntheticPose.timeline(.realWorld30fps))
        var object = try #require(try JSONSerialization.jsonObject(with: JSONEncoder().encode(phases)) as? [String: Any])
        object.removeValue(forKey: "kickWindows")
        object.removeValue(forKey: "assistance")
        var evidence = try #require(object["evidence"] as? [String: Any])
        for key in ["contactTimingBasis", "contactTimingMethod", "kickingAnkleMergedAfterContact", "cameraMotionSuspected", "plantPriorTime"] {
            evidence.removeValue(forKey: key)
        }
        object["evidence"] = evidence
        let old = try JSONDecoder().decode(KickPhaseDetectionResult.self, from: JSONSerialization.data(withJSONObject: object))
        #expect(old.kickWindows == nil)
        #expect(!old.isUserAssisted)
        #expect(old.phases == phases.phases)

        let old12A = #"{"scoredMetricCount":16,"availableScoredMetrics":4,"blockedByMissingPhase":0,"blockedByMissingJoints":0,"blockedByConfidence":16,"rescuedWithoutCameraPenalty":0,"otherUnavailable":0,"kickerTrackedFraction":1,"missingPhases":[],"cameraFactor":1,"kickingAnkleCoverage":1}"#
        let e = try JSONDecoder().decode(AnalysisFailureEvidence.self, from: Data(old12A.utf8))
        #expect(e.meanPhaseFactorOfConfidenceBlocked == nil)
        #expect(AnalysisDiagnosis.cause(e, scoredCategoryCount: 0) == .lowPoseConfidence, "old evidence keeps its old reading")
    }

    @Test func diagnosticsExportEveryNonCoordinateSignalForExactReplay() throws {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(.realWorld30fps),
                                                                     kickType: .fieldGoal, kickingFoot: .right))
        let report = AnalysisDiagnosticsBuilder.build(AnalysisDiagnosticsInput(output: out), storedStatus: "completed",
                                                      storedFailureReason: nil, kickingFoot: .right, appVersion: nil,
                                                      generatedAt: Date(timeIntervalSince1970: 0))
        let series = try #require(report.timeSeries)
        let exported = Set((series.allSignals ?? [:]).keys)
        #expect(!exported.contains("bodyCenterX") && !exported.contains("bodyCenterY"), "no coordinates")
        #expect(exported.contains("kickingAnkleForwardVelocity"))
        #expect(exported.contains("kickingAnkleForwardOffset"))
        #expect(exported.count == PoseSignalKey.allCases.count - 2)
        // Re-running the detector on the export reproduces the analysis' contact exactly.
        let replayed = KickPhaseDetector.detect(series.signalSet, kickType: .fieldGoal)
        let original = KickPhaseDetector.detect(out.signals, kickType: .fieldGoal)
        let a: Double = replayed.estimatedContactTime ?? -1
        let b: Double = original.estimatedContactTime ?? -2
        #expect(abs(a - b) < 0.001, "times are exported to the millisecond")
        #expect(series.csv.contains("signal_kickingAnkleForwardVelocity"))
        #expect(report.kickWindows?.selected != nil)
        #expect(report.plainText.contains("kick windows:"))
        let json = report.json()
        for forbidden in ["\"x\"", "\"y\""] { #expect(!json.contains(forbidden)) }
    }

    @Test func reanalysisNeverChangesTheStoredResultOfTheRealClip() {
        // The replay is display-only: running the detector does not mutate its inputs.
        let signals = Real.signals
        let before = signals
        _ = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        #expect(signals == before)
    }
}
