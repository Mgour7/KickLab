import Foundation
import Testing
@testable import KickLab

/// Artifacts and the real pose engine, driven by synthetic pose data instead of Vision.
/// No SwiftData, no Apple frameworks: runs on any platform.
@Suite("Pose artifacts and engine")
struct PoseAnalysisEngineTests {
    private let kickID = UUID()
    private let primaryID = UUID()
    private let secondaryID = UUID()
    private let primaryPath: String
    private let secondaryPath: String

    init() {
        primaryPath = ManagedPath.originalVideoPath(kickID: kickID, videoID: primaryID, fileExtension: "mov")
        secondaryPath = ManagedPath.originalVideoPath(kickID: kickID, videoID: secondaryID, fileExtension: "mov")
    }

    private func makeStore(_ temp: TemporaryDirectory) throws -> ManagedMediaStore {
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        return store
    }

    private func request(options: VideoAnalysisOptions = VideoAnalysisOptions(), includeSecondary: Bool = true) -> VideoAnalysisRequest {
        var inputs = [
            VideoAnalysisInput(videoID: primaryID, angle: .side, isPrimary: true, relativeFilePath: primaryPath,
                               frameRate: 240, durationSeconds: 2, syncOffsetSeconds: 0, contactTimeSeconds: nil),
        ]
        if includeSecondary {
            inputs.append(VideoAnalysisInput(videoID: secondaryID, angle: .rear, isPrimary: false, relativeFilePath: secondaryPath,
                                             frameRate: 60, durationSeconds: 2.1, syncOffsetSeconds: 0.12, contactTimeSeconds: nil))
        }
        return VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: inputs, options: options)
    }

    private func engine(_ store: ManagedMediaStore, extractor: FakePoseExtractor? = nil) -> PoseVideoAnalysisService {
        PoseVideoAnalysisService(
            mediaStore: store,
            extractor: extractor ?? FakePoseExtractor { SyntheticPose.sequence(.fieldGoal, videoID: $0) { [SyntheticPose.holder(at: $0)] } },
            now: { Date(timeIntervalSince1970: 1_800_000_000) }
        )
    }

    // MARK: Prepare

    @Test func prepareChoosesPrimaryAndRejectsMissingFiles() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        // The secondary file is missing.

        let prepared = try await engine(store).prepare(request())
        #expect(prepared.usableVideoIDs == [primaryID])
        #expect(prepared.rejectedInputs.map(\.videoID) == [secondaryID])
        #expect(prepared.rejectedInputs.first?.reason == "The video file is missing.")
        #expect(prepared.engineVersion == PoseVideoAnalysisService.version)
        #expect(prepared.estimatedFrameCount == 120, "2 s at the 60 fps analysis rate, not 240")
    }

    @Test func prepareFallsBackWhenPrimaryIsUnusable() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(secondaryPath, under: store.mediaRootURL)
        let prepared = try await engine(store).prepare(request())
        #expect(prepared.usableVideoIDs == [secondaryID])
    }

    @Test func prepareRejectsWhenNothingIsUsable() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        await #expect(throws: VideoAnalysisError.noUsableInputs) { _ = try await engine(store).prepare(request()) }
        let empty = VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [])
        await #expect(throws: VideoAnalysisError.noInputs) { _ = try await engine(store).prepare(empty) }
        let unsafe = VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [
            VideoAnalysisInput(videoID: primaryID, angle: .side, isPrimary: true, relativeFilePath: "../escape.mov",
                               frameRate: nil, durationSeconds: nil, syncOffsetSeconds: nil, contactTimeSeconds: nil),
        ])
        await #expect(throws: VideoAnalysisError.noUsableInputs) { _ = try await engine(store).prepare(unsafe) }
    }

    @Test func unavailableExtractorMakesEngineUnavailable() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        var extractor = FakePoseExtractor { _ in throw VideoAnalysisError.failed("unused") }
        extractor.isAvailable = false
        let service = engine(store, extractor: extractor)
        #expect(!service.availability.isAvailable)
    }

    // MARK: Analyze

    @Test func analyzeReturnsBiomechanicsAndWritesVersionedArtifacts() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        try temp.writeFile(secondaryPath, under: store.mediaRootURL)
        let analysisID = UUID()
        let recorder = ProgressRecorder()

        let result = try await engine(store).analyze(request(options: VideoAnalysisOptions(artifactsDirectoryID: analysisID))) {
            recorder.record($0)
        }

        // Step 8: every metric (available or not), category scores and coaching.
        #expect(result.engineVersion == "pose-biomechanics-2.4.0")
        #expect(result.metrics.map(\.metricKey) == KickMetricKey.allCases.map(\.rawValue))
        #expect(result.metrics.first { $0.metricKey == "plant.toContactTime" }?.value == 0.2)
        #expect(result.metrics.allSatisfy { $0.sourceAngle == .side })
        #expect(result.categoryScores.map(\.category) == [.approach, .plant, .swing, .contact, .followThrough, .overall])
        #expect(result.observations.map(\.ruleKey) == ["plant.stable"])
        #expect(result.overallScore == result.categoryScores.last?.score)
        #expect(result.overallScore != nil)
        #expect(result.overallConfidence != nil)
        // Observation IDs are seeded by the analysis ID: stable across identical reruns.
        let again = try await engine(store).analyze(request(options: VideoAnalysisOptions(artifactsDirectoryID: analysisID))) { _ in }
        #expect(again.observations == result.observations)
        #expect(again.metrics == result.metrics)

        // Operational metadata.
        let summary = try #require(result.poseSummary)
        #expect(summary.primaryVideoID == primaryID)
        #expect(summary.kickerStatus == .selected)
        #expect(summary.candidateCount == 2)
        #expect(near(summary.plantTime, 1.2, 0.05))
        #expect(near(summary.estimatedContactTime, 1.4, 0.034))
        #expect(summary.analyzedFrameCount == 121)
        #expect(summary.droppedFrameCount == 0)
        // Step 12E: every metric a side view supports (not the frontal-plane ones).
        #expect(summary.availableMetricCount == KickMetricKey.allCases.count - PerspectiveMetricSupport.frontalPlaneMetrics.count)
        #expect(summary.perspective == .side)
        #expect(summary.completionBasis == .scored)
        #expect(summary.scoredCategoryCount == 5)

        // Artifacts under Analysis/<analysis id>/.
        let directory = try #require(result.artifactsRelativePath)
        #expect(directory == analysisID.uuidString.lowercased())
        let artifacts = AnalysisArtifactStore(analysisRootURL: store.analysisRootURL)
        let bundle = try artifacts.readBundle(in: directory)
        #expect(bundle.manifest.formatVersion == 2)
        #expect(bundle.manifest.biomechanicsPath == "biomechanics-v1.json")
        let biomechanics = try #require(bundle.biomechanics)
        #expect(biomechanics.formatVersion == 1)
        #expect(biomechanics.rulesVersion == 1)
        #expect(biomechanics.context.cameraAngle == .side)
        #expect(biomechanics.measurements.count == KickMetricKey.allCases.count)
        #expect(biomechanics.categories.count == 6)
        #expect(biomechanics.profile.name == "fieldGoal-v1")
        #expect(bundle.manifest.engineVersion == PoseVideoAnalysisService.version)
        #expect(bundle.manifest.kickID == kickID)
        #expect(bundle.manifest.primaryVideoID == primaryID)
        #expect(bundle.manifest.videoIDs == [primaryID, secondaryID])
        #expect(bundle.manifest.videos.last?.syncOffsetSeconds == 0.12, "sync offset preserved for future fusion")
        #expect(bundle.manifest.videos.last?.analyzed == false)
        #expect(bundle.manifest.createdAt == Date(timeIntervalSince1970: 1_800_000_000))
        #expect(bundle.pose.sequence.frames.count == 121)
        #expect(bundle.pose.tracking.status == .selected)
        #expect(bundle.signals.signals.kickingFoot == .right)
        #expect(bundle.phases.phases.plantTime == summary.plantTime)
        #expect(bundle.phases.ball.status == .unavailable)

        // Progress: in range, ends at 1, reaches pose and event stages.
        let events = recorder.events
        #expect(events.allSatisfy { (0...1).contains($0.fractionCompleted) })
        #expect(events.last?.fractionCompleted == 1)
        #expect(events.contains { $0.stage == .detectingPose })
        #expect(events.contains { $0.stage == .detectingEvents })
    }

    @Test func kickingFootOptionIsUsed() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        let leftScript: SyntheticPose.KickScript = {
            var script = SyntheticPose.KickScript.fieldGoal
            script.kickingFoot = .left
            return script
        }()
        let service = engine(store, extractor: FakePoseExtractor { SyntheticPose.sequence(leftScript, videoID: $0) })

        let result = try await service.analyze(request(options: VideoAnalysisOptions(kickingFoot: .left), includeSecondary: false)) { _ in }
        #expect(near(result.poseSummary?.plantTime, 1.2, 0.05))
    }

    @Test func noPersonIsReportedNotFaked() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        let empty = FakePoseExtractor { id in
            PoseSequence(videoID: id, durationSeconds: 1, nominalFrameRate: 30, analysisFrameRate: 30, orientation: .up,
                         isMirrored: false, displayAspectRatio: 16.0 / 9.0,
                         frames: (0..<30).map { PoseFrame(frameIndex: $0, timestamp: Double($0) / 30, bodies: []) },
                         kickerTrackID: nil)
        }
        let result = try await engine(store, extractor: empty).analyze(request(includeSecondary: false)) { _ in }
        #expect(result.poseSummary?.kickerStatus == .noCandidates)
        #expect(result.poseSummary?.plantTime == nil)
        #expect(result.poseSummary?.estimatedContactTime == nil)
        #expect(result.poseSummary?.extractionConfidence == 0)
        #expect(result.artifactsRelativePath != nil, "artifacts are still written for diagnosis")
    }

    @Test func everyFrameFailingFailsTheRun() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        let failing = FakePoseExtractor { id in
            PoseSequence(videoID: id, durationSeconds: 1, nominalFrameRate: 30, analysisFrameRate: 30, orientation: .up,
                         isMirrored: false, displayAspectRatio: 1,
                         frames: (0..<5).map { PoseFrame(frameIndex: $0, timestamp: Double($0) / 30, bodies: [], status: .failed) },
                         kickerTrackID: nil)
        }
        await #expect(throws: VideoAnalysisError.failed("Pose detection failed on every frame.")) {
            _ = try await engine(store, extractor: failing).analyze(request(includeSecondary: false)) { _ in }
        }
        #expect(fileSystemIsEmpty(store.analysisRootURL), "nothing written for a failed run")
    }

    @Test func runtimeLimitationIsTypedAndNotAGenericFailure() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        let noVision = FakePoseExtractor { _ in throw PoseDetectionError.runtimeUnavailable(environment: .simulator) }
        await #expect(throws: VideoAnalysisError.poseDetectionUnavailable(environment: .simulator)) {
            _ = try await engine(store, extractor: noVision).analyze(request(includeSecondary: false)) { _ in }
        }
        #expect(fileSystemIsEmpty(store.analysisRootURL), "no pose data or artifacts for an unavailable runtime")

        let limitation = VideoAnalysisError.poseDetectionUnavailable(environment: .simulator)
        #expect(limitation.errorDescription == "Pose detection can't run in the iOS Simulator. Analyze on an iPhone.")
        #expect(limitation.errorDescription != VideoAnalysisError.failed("x").errorDescription)
        #expect(PoseVideoAnalysisService.mapped(PoseDetectionError.runtimeUnavailable(environment: .device))
                == .poseDetectionUnavailable(environment: .device))
        #expect(PoseDetectionRuntimeStatus.available.isAvailable)
        #expect(!PoseDetectionRuntimeStatus.unavailable(environment: .simulator).isAvailable)
    }

    @Test func extractorErrorsAreTyped() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        struct DecoderBroke: Error {}
        let broken = FakePoseExtractor { _ in throw DecoderBroke() }
        await #expect(throws: VideoAnalysisError.self) {
            _ = try await engine(store, extractor: broken).analyze(request(includeSecondary: false)) { _ in }
        }
    }

    @Test func cancelledRunThrowsCancelled() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile(primaryPath, under: store.mediaRootURL)
        let service = engine(store)
        let request = self.request(includeSecondary: false)
        let error = await withTaskGroup(of: VideoAnalysisError?.self) { group in
            group.cancelAll()
            group.addTask {
                do {
                    _ = try await service.analyze(request) { _ in }
                    return nil
                } catch let error as VideoAnalysisError {
                    return error
                } catch {
                    return .failed(String(describing: error))
                }
            }
            return await group.next() ?? nil
        }
        #expect(error == .cancelled)
        #expect(fileSystemIsEmpty(store.analysisRootURL))
    }

    // MARK: Artifact format

    private func sampleBundle() -> AnalysisArtifactBundle {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal, videoID: primaryID), kickType: .fieldGoal, kickingFoot: .right
        ))
        return AnalysisArtifactBundle(
            manifest: AnalysisArtifactManifest(
                engineVersion: "test", requestID: UUID(), kickID: kickID, kickType: .fieldGoal, primaryVideoID: primaryID,
                videos: [ArtifactVideoEntry(videoID: primaryID, angle: .side, isPrimary: true, syncOffsetSeconds: nil, analyzed: true)],
                posePath: AnalysisArtifactManifest.defaultPosePath,
                signalsPath: AnalysisArtifactManifest.defaultSignalsPath,
                phasesPath: AnalysisArtifactManifest.defaultPhasesPath,
                createdAt: Date(timeIntervalSince1970: 1_800_000_000)
            ),
            pose: PoseArtifact(videoID: primaryID, sampling: .standard, trackingConfiguration: .standard,
                               processingConfiguration: .standard, sequence: output.sequence, tracking: output.tracking,
                               kickerTimeline: output.kickerTimeline),
            signals: SignalArtifact(videoID: primaryID, signals: output.signals),
            phases: PhaseArtifact(videoID: primaryID, phases: output.phases, ball: .unavailable)
        )
    }

    private func sampleBundleWithBiomechanics() -> AnalysisArtifactBundle {
        var bundle = sampleBundle()
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal, videoID: primaryID), kickType: .fieldGoal, kickingFoot: .right
        ))
        bundle.manifest.biomechanicsPath = AnalysisArtifactManifest.defaultBiomechanicsPath
        bundle.biomechanics = BiomechanicsArtifact(videoID: primaryID, result: output.biomechanics)
        return bundle
    }

    @Test func artifactsRoundTrip() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = AnalysisArtifactStore(analysisRootURL: temp.url)
        let bundle = sampleBundle()
        try store.write(bundle, to: "a1")
        for name in ["manifest.json", "pose-v1.json", "signals-v1.json", "phases-v1.json"] {
            #expect(exists(temp.url.appendingPathComponent("a1").appendingPathComponent(name)), "\(name)")
        }
        #expect(try store.readBundle(in: "a1") == bundle)
        #expect(!exists(temp.url.appendingPathComponent("a1/biomechanics-v1.json")), "no biomechanics file unless named")

        let full = sampleBundleWithBiomechanics()
        try store.write(full, to: "a2")
        #expect(exists(temp.url.appendingPathComponent("a2/biomechanics-v1.json")))
        #expect(try store.readBundle(in: "a2") == full)

        // Human-inspectable: joints are keyed by name.
        let pose = try String(contentsOf: temp.url.appendingPathComponent("a1/pose-v1.json"), encoding: .utf8)
        #expect(pose.contains("\"leftAnkle\""))
        #expect(pose.contains("\"kind\":\"kicklab.pose\""))
    }

    @Test func newerFormatVersionsAreRefused() throws {
        var manifest = sampleBundle().manifest
        manifest.formatVersion = 3
        let data = try AnalysisArtifactCoder.encode(manifest)
        #expect(throws: AnalysisArtifactError.unsupportedFormatVersion(kind: AnalysisArtifactManifest.kind, version: 3, supported: 2)) {
            _ = try AnalysisArtifactCoder.decode(AnalysisArtifactManifest.self, from: data)
        }
        var biomechanics = try #require(sampleBundleWithBiomechanics().biomechanics)
        biomechanics.formatVersion = 2
        let newer = try AnalysisArtifactCoder.encode(biomechanics)
        #expect(throws: AnalysisArtifactError.unsupportedFormatVersion(kind: BiomechanicsArtifact.kind, version: 2, supported: 1)) {
            _ = try AnalysisArtifactCoder.decode(BiomechanicsArtifact.self, from: newer)
        }
    }

    @Test func step7ManifestsStillReadWithoutBiomechanics() throws {
        // A version-1 manifest exactly as Step 7 wrote it: no biomechanicsPath key.
        let json = """
        {"createdAt":"2027-01-15T08:00:00Z","engineVersion":"pose-foundation-1.0.0","formatVersion":1,\
        "kickID":"\(kickID.uuidString)","kickType":"fieldGoal","kind":"kicklab.manifest",\
        "phasesPath":"phases-v1.json","posePath":"pose-v1.json","primaryVideoID":"\(primaryID.uuidString)",\
        "requestID":"\(UUID().uuidString)","signalsPath":"signals-v1.json",\
        "videos":[{"analyzed":true,"angle":"side","isPrimary":true,"videoID":"\(primaryID.uuidString)"}]}
        """
        let manifest = try AnalysisArtifactCoder.decode(AnalysisArtifactManifest.self, from: Data(json.utf8))
        #expect(manifest.formatVersion == 1)
        #expect(manifest.biomechanicsPath == nil)
        #expect(manifest.engineVersion == "pose-foundation-1.0.0")

        // Its files are read exactly as before; there is simply no biomechanics artifact.
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = AnalysisArtifactStore(analysisRootURL: temp.url)
        var old = sampleBundle()
        old.manifest.formatVersion = 1
        try store.write(old, to: "old")
        let read = try store.readBundle(in: "old")
        #expect(read.manifest.formatVersion == 1)
        #expect(read.biomechanics == nil)
    }

    @Test func biomechanicsPathAndArtifactMustMatch() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = AnalysisArtifactStore(analysisRootURL: temp.url)
        var bundle = sampleBundle()
        bundle.manifest.biomechanicsPath = AnalysisArtifactManifest.defaultBiomechanicsPath
        #expect(throws: AnalysisArtifactError.invalidPath("biomechanics-v1.json")) { try store.write(bundle, to: "m") }
    }

    @Test func wrongKindAndCorruptFilesAreRefused() throws {
        let signals = try AnalysisArtifactCoder.encode(sampleBundle().signals)
        #expect(throws: AnalysisArtifactError.wrongKind(expected: PoseArtifact.kind, found: SignalArtifact.kind)) {
            _ = try AnalysisArtifactCoder.decode(PoseArtifact.self, from: signals)
        }
        #expect(throws: AnalysisArtifactError.corrupt("Missing artifact header.")) {
            _ = try AnalysisArtifactCoder.decode(PoseArtifact.self, from: Data("{}".utf8))
        }
    }

    @Test func unsafeArtifactPathsAreRefused() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = AnalysisArtifactStore(analysisRootURL: temp.url)
        #expect(throws: AnalysisArtifactError.invalidPath("../outside")) { try store.write(sampleBundle(), to: "../outside") }
        var bundle = sampleBundle()
        bundle.manifest.posePath = "nested/pose.json"
        #expect(throws: AnalysisArtifactError.invalidPath("nested/pose.json")) { try store.write(bundle, to: "a2") }
        #expect(throws: AnalysisArtifactError.missing("manifest.json")) { _ = try store.readManifest(in: "never-written") }
    }
}

private func fileSystemIsEmpty(_ root: URL) -> Bool {
    LocalMediaFileSystem().regularFiles(under: root).isEmpty
}
