import Foundation
import Testing
@testable import KickLab

/// Build 21 — Live Training Sessions 1.0, multi-kick discovery, two-camera foundation,
/// Compare 1.1 framing and ball-flight observation: the PURE logic, executed on Linux.
///
/// Everything here is SYNTHETIC (hand-built scan frames, formats and detections). No camera,
/// AVFoundation, Vision or Core ML code runs in these tests; those parts are compiled
/// against stand-ins only and must be exercised on an iPhone (see the TestFlight checklist).
@Suite("Training Sessions 1.0")
struct TrainingSessions21Tests {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    // MARK: Capture configuration

    private func fmt(_ w: Int, _ h: Int, _ fps: Double, binned: Bool = false) -> CaptureFormatDescriptor {
        CaptureFormatDescriptor(width: w, height: h, maxFrameRate: fps, isBinned: binned)
    }

    @Test func theRequestedFormatIsUsedWhenTheCameraHasIt() throws {
        let formats = [fmt(1920, 1080, 30), fmt(1920, 1080, 60), fmt(1920, 1080, 120, binned: true), fmt(1920, 1080, 120), fmt(3840, 2160, 60)]
        let s = try #require(CaptureConfigurationSelector.select(CaptureRequest(resolution: .hd1080, framesPerSecond: 120), formats: formats))
        #expect(s.formatIndex == 3, "the non-binned 120 fps format")
        #expect(s.isExact && s.title == "1080p · 120 fps")
        let standard = try #require(CaptureConfigurationSelector.select(.standard, formats: formats))
        #expect(standard.framesPerSecond == 60 && standard.resolution == .hd1080 && standard.isExact)
    }

    @Test func fallbacksAreStepwiseAndNeverSilent() throws {
        // No 120 fps at 1080p on this camera.
        let formats = [fmt(1920, 1080, 60), fmt(1280, 720, 240), fmt(3840, 2160, 30)]
        let s = try #require(CaptureConfigurationSelector.select(CaptureRequest(resolution: .hd1080, framesPerSecond: 120), formats: formats))
        #expect(s.resolution == .hd1080 && s.framesPerSecond == 60, "same resolution, lower rate first")
        #expect(s.fallbackReason == "This iPhone's camera can't record 1080p · 120 fps; KickLab will record 1080p · 60 fps.")
        // 4K60 unavailable: 4K30 before dropping resolution.
        let k = try #require(CaptureConfigurationSelector.select(CaptureRequest(resolution: .uhd4K, framesPerSecond: 60), formats: formats))
        #expect(k.resolution == .uhd4K && k.framesPerSecond == 30 && k.fallbackReason != nil)
        // Never a HIGHER rate than asked.
        let low = try #require(CaptureConfigurationSelector.select(CaptureRequest(resolution: .hd720, framesPerSecond: 30), formats: formats))
        #expect(low.framesPerSecond == 30)
        #expect(CaptureConfigurationSelector.select(.standard, formats: []) == nil)
    }

    @Test func recordingNeverStartsAtAnotherFrameRateThanDisplayed() throws {
        let s = try #require(CaptureConfigurationSelector.select(.standard, formats: [fmt(1920, 1080, 60)]))
        #expect(CaptureConfigurationSelector.verify(s, appliedFramesPerSecond: 59.94) == nil, "within 1%")
        #expect(CaptureConfigurationSelector.verify(s, appliedFramesPerSecond: 30) != nil)
        #expect(CaptureConfigurationSelector.verify(s, appliedFramesPerSecond: .nan) != nil)
    }

    // MARK: Capture states

    @Test func savedIsOnlyReachedWhenTheFileIsFinalized() throws {
        let sel = try #require(CaptureConfigurationSelector.select(.standard, formats: [fmt(1920, 1080, 60)]))
        let url = URL(fileURLWithPath: "/tmp/a.mov")
        var s = CaptureState.idle
        for e: CaptureEvent in [.requestPermissions, .permissionsGranted, .configured(sel), .startRequested(at: now), .stopRequested(.userStopped)] {
            s = CaptureStateMachine.reduce(s, e)
        }
        #expect(s == .finishing(sel, reason: .userStopped), "stop requested — not saved yet")
        #expect(CaptureStateMachine.reduce(s, .fileFinished(url: url, usable: true, duration: 12)) == .saved(fileURL: url, reason: .userStopped, duration: 12))
        #expect(CaptureStateMachine.reduce(s, .fileFinished(url: url, usable: false, duration: nil)) == .failed(.writeFailed))
        // After a failed file the athlete can try again; changing settings reconfigures.
        #expect(CaptureStateMachine.reduce(.failed(.writeFailed), .configured(sel)) == .ready(sel))
        #expect(CaptureStateMachine.reduce(.ready(sel), .requestPermissions) == .requestingPermission)
        #expect(CaptureStateMachine.reduce(.recording(sel, startedAt: now), .requestPermissions) == .recording(sel, startedAt: now),
                "never reconfigured while recording")
    }

    @Test func interruptionsAndDenialsAreHandled() throws {
        let sel = try #require(CaptureConfigurationSelector.select(.standard, formats: [fmt(1920, 1080, 60)]))
        let rec = CaptureState.recording(sel, startedAt: now)
        #expect(CaptureStateMachine.reduce(rec, .interruptionBegan) == .finishing(sel, reason: .interruption), "a call finalizes the file")
        #expect(CaptureStateMachine.reduce(.ready(sel), .interruptionBegan) == .interrupted(previous: sel))
        #expect(CaptureStateMachine.reduce(.interrupted(previous: sel), .interruptionEnded) == .ready(sel))
        #expect(CaptureStateMachine.reduce(.requestingPermission, .permissionDenied(.cameraPermissionDenied)) == .failed(.cameraPermissionDenied))
        #expect(CaptureStateMachine.reduce(.idle, .startRequested(at: now)) == .idle, "can't record before the camera is ready")
        // A file finishing on its own (disk full / error) while recording is still kept if usable.
        let url = URL(fileURLWithPath: "/tmp/b.mov")
        #expect(CaptureStateMachine.reduce(rec, .fileFinished(url: url, usable: true, duration: 3)) == .saved(fileURL: url, reason: .systemError, duration: 3))
        #expect(CaptureStopReason.thermal.message?.contains("saved") == true)
    }

    // MARK: Storage and heat

    @Test func storageSafeguards() {
        let gb: Int64 = 1_000_000_000
        // 1080p60 ≈ 90 MB/min; 1 GB is reserved.
        #expect(abs(CaptureStoragePolicy.minutesAvailable(freeBytes: 10 * gb, resolution: .hd1080, fps: 60) - 100) < 0.01)
        #expect(CaptureStoragePolicy.decide(freeBytes: 10 * gb, resolution: .hd1080, fps: 60, recording: false) == .ok(minutes: 100))
        if case .warn = CaptureStoragePolicy.decide(freeBytes: gb + 500_000_000, resolution: .hd1080, fps: 60, recording: false) {} else { Issue.record("warn under 10 min") }
        if case .stop = CaptureStoragePolicy.decide(freeBytes: gb + 100_000_000, resolution: .hd1080, fps: 60, recording: false) {} else { Issue.record("no start under 3 min") }
        if case .stop = CaptureStoragePolicy.decide(freeBytes: gb, resolution: .uhd4K, fps: 60, recording: true) {} else { Issue.record("stop at the reserve") }
        #expect(CaptureStoragePolicy.decide(freeBytes: nil, resolution: .hd1080, fps: 60, recording: false) == .ok(minutes: .infinity))
        #expect(CaptureStoragePolicy.megabytesPerMinute(.uhd4K, fps: 60) > CaptureStoragePolicy.megabytesPerMinute(.hd1080, fps: 120))
    }

    @Test func heatStopsRecordingOnlyWhenCritical() {
        #expect(CaptureThermalPolicy.action(.fair, recording: true) == .none)
        if case .warn = CaptureThermalPolicy.action(.serious, recording: true) {} else { Issue.record("warn when serious") }
        #expect(CaptureThermalPolicy.action(.critical, recording: true) == .stopAndSave)
        if case .warn = CaptureThermalPolicy.action(.critical, recording: false) {} else { Issue.record("don't start when critical") }
    }

    // MARK: Session manifest and persistence

    private func session() -> (TrainingSessionManifest, UUID) {
        var m = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: UUID(), name: "Tuesday practice", location: "Field 2",
                                                  defaults: SessionKickDetails(kickType: .fieldGoal, distanceYards: 30, hash: .left), now: now)
        let src = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .recording, now: now)
        TrainingSessionEditor.finalizeSource(&m, id: src.id, duration: 600, frameRate: 60, bytes: 900_000_000, now: now)
        return (m, src.id)
    }

    @Test func sessionsPersistAtomicallyAndSurviveADamagedWrite() throws {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("kl21-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: base) }
        let store = TrainingSessionStore(baseURL: base)
        var (m, _) = session()
        try store.save(m)
        #expect(try store.load(m.id) == m)
        m.name = "Renamed"
        try store.save(m)
        // A torn current file: the previous good copy is used, nothing is deleted.
        try Data("{ not json".utf8).write(to: store.manifestURL(m.id))
        let recovered = try store.load(m.id)
        #expect(recovered.name == "Tuesday practice")
        #expect(store.loadAll().count == 1)
        #expect(store.rootURL.lastPathComponent == "Sessions", "outside Media/ and Analysis/ (never swept as orphans)")
    }

    @Test func aSessionInterruptedMidRecordingIsRecoveredAtLaunch() throws {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("kl21-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: base) }
        let store = TrainingSessionStore(baseURL: base)
        var m = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "S", location: nil, defaults: SessionKickDetails(), now: now)
        let kept = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .recording, now: now)
        let lost = TrainingSessionEditor.addSource(&m, id: UUID(), role: .rear, origin: .inAppRecording, fileExtension: "mov", status: .recording, now: now)
        try store.save(m)
        try Data(repeating: 1, count: 4096).write(to: store.url(session: m.id, relativePath: kept.relativePath))
        #expect(store.recoverAfterLaunch() == [m.id])
        let after = try store.load(m.id)
        #expect(after.source(kept.id)?.status == .recovered && after.source(kept.id)?.byteCount == 4096)
        #expect(after.source(lost.id)?.status == .missing)
        #expect(after.log.last?.text.contains("Recovered") == true)
    }

    @Test func defaultsChangeBetweenKicksWithoutRewritingEarlierOnes() {
        var (m, src) = session()
        TrainingSessionEditor.changeDefaults(&m, to: SessionKickDetails(kickType: .fieldGoal, distanceYards: 40, hash: .right), sourceID: src, atSourceTime: 300, now: now)
        #expect(m.details(sourceID: src, at: 100).distanceYards == 30)
        #expect(m.details(sourceID: src, at: 300).distanceYards == 40)
        #expect(m.details(sourceID: src, at: 500).hash == .right)
    }

    // MARK: Stage A discovery (synthetic scan frames, 5 per second)

    private let rest = ScanBall(cx: 0.5, cy: 0.8, w: 0.03, h: 0.02, score: 0.8)

    /// A kicker standing, approaching and kicking a ball at `kick`; the ball rests from
    /// `kick − 8` s and is gone after contact.
    private func scan(duration: Double, kicks: [Double], walkOnly: [Double] = [], handled: [Double] = [], practice: [Double] = [],
                      occludeAt: [Double] = []) -> [SessionScanSample] {
        stride(from: 0.0, through: duration, by: 0.2).map { t in
            var balls: [ScanBall] = []
            for k in kicks where t >= k - 8 && t <= k + 1e-9 && !occludeAt.contains(where: { abs($0 - t) < 0.01 }) { balls.append(rest) }
            for h in handled {
                if t >= h - 8 && t <= h + 1e-9 { balls.append(rest) }
                // Picked up and carried away slowly.
                if t > h && t <= h + 1.0 { var b = rest; b.cx += (t - h) * 0.05; b.cy -= (t - h) * 0.05; balls.append(b) }
            }
            var person = ScanPerson(leftAnkle: NormalizedPoint(x: 0.3, y: 0.85), rightAnkle: NormalizedPoint(x: 0.32, y: 0.85),
                                    hipCenter: NormalizedPoint(x: 0.3, y: 0.6), torsoLength: 0.1)
            for k in kicks + practice {
                // Approach: the hips move toward the ball over the 2 s before contact.
                if t >= k - 2 && t <= k { person.hipCenter = NormalizedPoint(x: 0.3 + (t - (k - 2)) * 0.08, y: 0.6) }
                // Swing: the kicking ankle travels 0.3 in 0.2 s at the ball (15 torso lengths/s).
                if abs(t - k) < 0.01 { person.rightAnkle = NormalizedPoint(x: 0.5, y: 0.8) }
                if abs(t - (k - 0.2)) < 0.01 { person.rightAnkle = NormalizedPoint(x: 0.2, y: 0.8) }
            }
            for w in walkOnly where abs(t - w) < 0.5 {
                // Walking: ankles move ~0.03 per 0.2 s (1.5 torso lengths/s).
                person.rightAnkle = NormalizedPoint(x: 0.32 + (t - w) * 0.15, y: 0.85)
            }
            return SessionScanSample(time: t, balls: balls, person: person)
        }
    }

    @Test func eachRealKickIsFoundOnceWithStrongEvidence() throws {
        let found = KickDiscovery.discover(scan(duration: 120, kicks: [20, 50, 95]))
        #expect(found.count == 3)
        for (k, expected) in zip(found, [20.0, 50, 95]) {
            #expect(abs(k.contactTime - expected) <= 0.2, "\(k.contactTime)")
            #expect(k.autoVerify, "ball left + fast foot at the ball")
            #expect(k.evidence.ballDeparted && k.evidence.swingNearBall && k.evidence.approachSeen)
        }
    }

    @Test func walkingRetrievingAndPlacingAreNotKicks() {
        let found = KickDiscovery.discover(scan(duration: 60, kicks: [], walkOnly: [10, 30], handled: [45]))
        #expect(found.isEmpty, "\(found.map(\.contactTime))")
    }

    @Test func aPracticeSwingIsListedForReviewNeverConfirmed() throws {
        let found = KickDiscovery.discover(scan(duration: 40, kicks: [], practice: [20]))
        let k = try #require(found.first)
        #expect(found.count == 1 && !k.autoVerify)
        #expect(k.evidence.notes.contains { $0.contains("practice swing") })
    }

    @Test func aMomentaryOcclusionOfTheBallIsNotADeparture() {
        // A leg hides the ball for 3 frames 3 s before the kick.
        let found = KickDiscovery.discover(scan(duration: 40, kicks: [20], occludeAt: [16.8, 17.0, 17.2]))
        #expect(found.count == 1 && abs((found.first?.contactTime ?? 0) - 20) <= 0.2)
    }

    @Test func manualMarksStrengthenButNeverCreateKicks() {
        #expect(KickDiscovery.discover(scan(duration: 30, kicks: []), marks: [10, 20]).isEmpty)
        let k = KickDiscovery.discover(scan(duration: 40, kicks: [20]), marks: [19.5])
        #expect(k.first?.evidence.manualMarkNearby == true)
    }

    @Test func marksWithoutAKickAreOfferedForReviewAfterTheScan() throws {
        var (m, src) = session()
        TrainingSessionEditor.addMark(&m, sourceID: src, at: 42, now: now)
        TrainingSessionEditor.addMark(&m, sourceID: src, at: 121, now: now)
        #expect(m.unmatchedMarks.isEmpty, "not offered before the recording is scanned")
        m.processing.scan[src.uuidString] = .done
        TrainingSessionEditor.applyDiscovery(&m, sourceID: src, found: KickDiscovery.discover(scan(duration: 140, kicks: [40]), marks: [42, 121]), now: now)
        #expect(m.unmatchedMarks.map(\.sourceTime) == [121], "the mark 2 s after a found kick belongs to it")
        // The athlete adds the kick by hand → the mark is matched; nothing is counted from a mark alone.
        _ = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 119.6, now: now)
        #expect(m.unmatchedMarks.isEmpty)
        TrainingSessionEditor.addMark(&m, sourceID: src, at: 300, now: now)
        let mark = try #require(m.unmatchedMarks.first)
        TrainingSessionEditor.removeMark(&m, markID: mark.id, now: now)
        #expect(m.unmatchedMarks.isEmpty && m.marks.count == 2)
    }

    @Test func closeCandidatesAreDeduplicated() {
        func k(_ t: Double, _ score: Bool) -> DiscoveredKick {
            DiscoveredKick(contactTime: t, contactUncertainty: 0.2,
                           evidence: CandidateEvidence(ballDeparted: score, swingSpeed: 9, swingNearBall: score), autoVerify: score)
        }
        let d = KickDiscovery.deduplicate([k(10, false), k(11.5, true), k(20, true)])
        #expect(d.map(\.contactTime) == [11.5, 20], "within 4 s: the stronger one is kept")
    }

    // MARK: Clip boundaries

    @Test func boundariesKeepTheApproachAndNeverCutThePlantOrStrike() {
        let b = ClipBoundaryPolicy.boundaries(contact: 20, sourceDuration: 600)
        #expect(b.start == 16 && b.end == 23 && !b.approachIncomplete)
        let a = ClipBoundaryPolicy.boundaries(contact: 20, approachStart: 15.8, sourceDuration: 600)
        #expect(a.start == 15.3, "adapted to a long approach (≤ 5 s)")
        let early = ClipBoundaryPolicy.boundaries(contact: 0.18, sourceDuration: 600)
        #expect(early.start == 0 && early.approachIncomplete, "the 3.663 s-style clip: approach missing, said so")
        let crowded = ClipBoundaryPolicy.boundaries(contact: 20, sourceDuration: 600, previousContact: 18.0, nextContact: 21.0)
        #expect(crowded.start == 18.5, "never closer than 1.5 s before contact, even with a kick just before")
        #expect(crowded.end == 21.0 && crowded.followThroughIncomplete, "never closer than 1 s after contact")
        let atEnd = ClipBoundaryPolicy.boundaries(contact: 599.5, sourceDuration: 600)
        #expect(atEnd.end == 600 && atEnd.followThroughIncomplete)
    }

    // MARK: Corrections

    @Test func manualCorrectionsArePreservedAndNeverTouchTheRecording() throws {
        var (m, src) = session()
        TrainingSessionEditor.applyDiscovery(&m, sourceID: src, found: KickDiscovery.discover(scan(duration: 120, kicks: [20, 50])), now: now)
        #expect(m.candidates.count == 2 && m.candidates.allSatisfy { $0.status == .pending && $0.details.distanceYards == 30 })
        // Add a missed kick, adjust a boundary, confirm a contact, reject a false one.
        let added = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 80, now: now)
        #expect(added.discovery == .manual && added.contactProvenance == .user)
        let first = m.candidates[0].id
        try TrainingSessionEditor.adjustBoundaries(&m, candidateID: first, start: 15.5, end: 23.5, now: now)
        #expect(throws: TrainingSessionEditor.EditError.self) { try TrainingSessionEditor.adjustBoundaries(&m, candidateID: first, start: 19.5, end: 23.5, now: now) }
        try TrainingSessionEditor.confirmContact(&m, candidateID: first, at: 20.05, now: now)
        #expect(m.candidate(first)?.contactProvenance == .user)
        try TrainingSessionEditor.reject(&m, candidateID: m.candidates[1].id, practiceSwing: true, now: now)
        #expect(m.candidates[1].status == .practiceSwing)
        #expect(m.sources.count == 1, "no edit removes footage")
        // Re-running discovery keeps the athlete's work and doesn't resurrect the rejected one.
        TrainingSessionEditor.applyDiscovery(&m, sourceID: src, found: KickDiscovery.discover(scan(duration: 120, kicks: [20, 50])), now: now)
        #expect(m.candidates.filter(\.status.isActive).count == 2, "kick at 20 (edited) and 80 (manual)")
        #expect(m.candidate(first)?.boundariesEditedByUser == true)
    }

    @Test func splitAndMerge() throws {
        var (m, src) = session()
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 30, now: now)
        let ids = try TrainingSessionEditor.split(&m, candidateID: c.id, firstContact: 30, secondContact: 36, now: now)
        #expect(ids.count == 2 && m.candidate(c.id)?.status == .rejected)
        #expect(m.candidate(ids[0])?.endTime ?? 99 <= 36 - ClipBoundaryPolicy.protectedBefore)
        let merged = try TrainingSessionEditor.merge(&m, ids[0], ids[1], now: now)
        #expect(m.candidates.filter(\.status.isActive).map(\.id) == [merged])
        #expect(throws: TrainingSessionEditor.EditError.self) { _ = try TrainingSessionEditor.split(&m, candidateID: merged, firstContact: 30, secondContact: 30.5, now: now) }
    }

    @Test func clipTimeMapsBackToTheOriginalRecording() {
        #expect(ClipTimeMapping.sourceTime(clipTime: 4.0, clipStartInSource: 316.25) == 320.25)
        #expect(ClipTimeMapping.clipTime(sourceTime: 320.25, clipStartInSource: 316.25) == 4.0)
    }

    @Test func aSourceCantBeDeletedWhileUnanalyzedKicksNeedIt() throws {
        var (m, src) = session()
        _ = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 30, now: now)
        #expect(throws: TrainingSessionEditor.EditError.sourceInUse(1)) { try TrainingSessionEditor.removeSource(&m, sourceID: src, now: now) }
        SessionProcessingQueue.recordMaterialized(&m, m.candidates[0].id, kickID: UUID(), clipStartInSource: 26)
        try TrainingSessionEditor.removeSource(&m, sourceID: src, now: now)
        #expect(m.sources.isEmpty, "the analyzed kick has its own clip")
    }

    // MARK: Analysis queue

    @Test func theQueueRunsOneAtATimeAndSurvivesARelaunch() throws {
        var (m, src) = session()
        TrainingSessionEditor.applyDiscovery(&m, sourceID: src, found: KickDiscovery.discover(scan(duration: 120, kicks: [20, 50, 95])), now: now)
        SessionProcessingQueue.enqueueReady(&m)
        let first = try #require(SessionProcessingQueue.next(m))
        #expect(abs((first.contactTime ?? 0) - 20) < 0.3, "in recording order")
        SessionProcessingQueue.markRunning(&m, first.id)
        #expect(SessionProcessingQueue.next(m) == nil, "bounded: one at a time")
        // iOS terminated KickLab mid-analysis.
        SessionProcessingQueue.recoverAfterRelaunch(&m)
        #expect(m.candidate(first.id)?.analysis.status == .queued)
        #expect(SessionProcessingQueue.next(m)?.id == first.id)
        // Pause.
        m.processing.paused = true
        #expect(SessionProcessingQueue.next(m) == nil)
        m.processing.paused = false
        // Materialize once; analysis decides the status; reanalysis reuses the same Kick.
        let kick = UUID()
        SessionProcessingQueue.markRunning(&m, first.id)
        SessionProcessingQueue.recordMaterialized(&m, first.id, kickID: kick, clipStartInSource: 16.1)
        SessionProcessingQueue.recordAnalysis(&m, first.id, analysisID: UUID(), completed: true, contactOutcome: .ballConstrainedContactInterval,
                                             clipContact: 3.867, contactUncertainty: 0.033, now: now)
        let done = try #require(m.candidate(first.id))
        #expect(done.status == .confirmed && done.analysis.status == .done)
        #expect(abs((done.contactTime ?? 0) - 19.967) < 1e-9, "clip contact mapped back to the recording")
        #expect(done.contactProvenance == .analysis)
        SessionProcessingQueue.requeue(&m, candidateID: first.id)
        #expect(m.candidate(first.id)?.kickID == kick, "reanalysis never creates a second Kick")
        // Failures retry once, then wait for the athlete.
        m.candidates[m.candidates.firstIndex { $0.id == first.id }!].analysis.status = .done
        let second = try #require(SessionProcessingQueue.next(m))
        #expect(second.id != first.id)
        SessionProcessingQueue.markRunning(&m, second.id)
        SessionProcessingQueue.recordFailure(&m, second.id, error: "Video unreadable", now: now)
        #expect(m.candidate(second.id)?.analysis.status == .queued)
        SessionProcessingQueue.markRunning(&m, second.id)
        SessionProcessingQueue.recordFailure(&m, second.id, error: "Video unreadable", now: now)
        #expect(m.candidate(second.id)?.analysis.status == .failed && m.candidate(second.id)?.status == .needsReview)
    }

    @Test func stageBClassificationFollowsTheContactEvidence() {
        #expect(CandidateVerification.status(analysisCompleted: true, contactOutcome: .ballVerifiedContact) == .confirmed)
        #expect(CandidateVerification.status(analysisCompleted: true, contactOutcome: .poseEstimatedContact) == .probable)
        #expect(CandidateVerification.status(analysisCompleted: true, contactOutcome: .contactUncertain) == .needsReview)
        #expect(CandidateVerification.status(analysisCompleted: false, contactOutcome: nil) == .needsReview)
    }

    // MARK: Two cameras

    private func twoCameraSession() -> (TrainingSessionManifest, UUID, UUID) {
        var (m, side) = session()
        let rear = TrainingSessionEditor.addSource(&m, id: UUID(), role: .rear, origin: .imported, fileExtension: "mov", status: .finalized, now: now)
        // The rear phone started recording 12.4 s after the side phone.
        for t in [20.0, 50, 95] { _ = try? TrainingSessionEditor.addManualKick(&m, sourceID: side, contact: t, now: now) }
        for t in [7.62, 37.58, 82.65, 110.0] { _ = try? TrainingSessionEditor.addManualKick(&m, sourceID: rear.id, contact: t, now: now) }
        for i in m.candidates.indices { m.candidates[i].status = .confirmed }
        return (m, side, rear.id)
    }

    @Test func manualSyncKeepsRawTimesAndItsProvenance() {
        let s = MultiCameraSync.manualSync(referenceMark: 20.0, sourceMark: 7.6, referenceFrameRate: 60, sourceFrameRate: 30, now: now)
        #expect(abs(s.offsetSeconds - 12.4) < 1e-9 && s.provenance == .manualEvent)
        let expectedU: Double = 1.0 / 60 + 1.0 / 30
        let u: Double = s.uncertaintySeconds ?? 0
        #expect(abs(u - expectedU) < 1e-9, "one frame of each camera")
        #expect(abs(MultiCameraSync.sharedTime(7.6, sync: s) - 20) < 1e-9)
        #expect(abs(MultiCameraSync.partnerTime(of: 20, from: .reference, to: s) - 7.6) < 1e-9)
        let clock = MultiCameraSync.wallClockSync(referenceStart: now, sourceStart: now.addingTimeInterval(12), now: now)
        #expect(clock.provenance == .wallClock && clock.uncertaintySeconds == 2, "device clocks: rough only")
        #expect(MultiCameraSync.alignmentUncertainty(.reference, .unsynchronized) == nil)
    }

    @Test func unsynchronizedCamerasAreNeverPairedAutomatically() {
        var (m, side, rear) = twoCameraSession()
        #expect(MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now) == 0)
    }

    @Test func pairedKicksCountOnceAndUnmatchedOnesStaySeparate() throws {
        var (m, side, rear) = twoCameraSession()
        MultiCameraSync.setSync(&m, sourceID: rear, sync: MultiCameraSync.manualSync(referenceMark: 20, sourceMark: 7.6, referenceFrameRate: 60, sourceFrameRate: 30, now: now), now: now)
        #expect(m.source(rear)?.sync.provenance == .manualEvent)
        let n = MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now)
        #expect(n == 3, "20↔7.62, 50↔37.58, 95↔82.65; 110 (shared 122.4) has no partner")
        #expect(m.pairs.allSatisfy { ($0.contactDifference ?? 1) < 0.1 })
        #expect(m.attempts.count == 4, "3 paired kicks once each + the rear-only kick")
        // Pairs never change raw source times.
        #expect(m.candidates.filter { $0.sourceID == rear }.compactMap(\.contactTime).contains(7.62))
        // Manual pairing replaces; unpairing restores both as separate attempts.
        let rearOnly = try #require(m.candidates.first { $0.sourceID == rear && $0.contactTime == 110 })
        try MultiCameraSync.pairManually(&m, primary: m.candidates.first { $0.contactTime == 95 }!.id, secondary: rearOnly.id, now: now)
        #expect(m.attempts.count == 4)
        MultiCameraSync.unpair(&m, pairID: m.pairs.last!.id, now: now)
        #expect(m.attempts.count == 5)
    }

    @Test func automaticPairingRespectsTheAthleteAndAttachedClips() throws {
        var (m, side, rear) = twoCameraSession()
        MultiCameraSync.setSync(&m, sourceID: rear, sync: MultiCameraSync.manualSync(referenceMark: 20, sourceMark: 7.6, referenceFrameRate: 60, sourceFrameRate: 30, now: now), now: now)
        _ = MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now)
        // "Not the same kick" is remembered: re-pairing doesn't bring it back.
        let first = try #require(m.pairs.first { m.candidate($0.primaryCandidateID)?.contactTime == 20 })
        MultiCameraSync.unpair(&m, pairID: first.id, now: now)
        _ = MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now)
        #expect(!m.pairs.contains { $0.primaryCandidateID == first.primaryCandidateID && $0.secondaryCandidateID == first.secondaryCandidateID })
        #expect(m.attempts.count == 5)
        // A second-camera clip already attached to a Kick keeps its pair through re-pairing
        // and can't be unpaired or re-paired silently (it would be counted twice).
        let kept = try #require(m.pairs.first { m.candidate($0.primaryCandidateID)?.contactTime == 50 })
        let i = try #require(m.candidates.firstIndex { $0.id == kept.secondaryCandidateID })
        m.candidates[i].kickID = UUID()
        _ = MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now)
        #expect(m.pairs.contains { $0.id == kept.id })
        MultiCameraSync.unpair(&m, pairID: kept.id, now: now)
        #expect(m.pairs.contains { $0.id == kept.id })
        let other = try #require(m.candidates.first { $0.sourceID == side && $0.contactTime == 95 })
        #expect(throws: TrainingSessionEditor.EditError.self) {
            try MultiCameraSync.pairManually(&m, primary: other.id, secondary: kept.secondaryCandidateID, now: now)
        }
        // Manual pairing choices only come from a synchronized second camera.
        let rearKick = try #require(m.candidates.first { $0.sourceID == rear && $0.contactTime == 82.65 })
        #expect(MultiCameraSync.pairingChoices(m, for: rearKick.id).map(\.contactTime) == [95], "nearest camera A kick within 10 s")
        let rearOnly = try #require(m.candidates.first { $0.sourceID == rear && $0.contactTime == 110 })
        #expect(MultiCameraSync.pairingChoices(m, for: rearOnly.id).isEmpty, "nothing within 10 s of shared 122.4")
    }

    // MARK: Session review

    @Test func sessionResultsCountAttemptsOnce() {
        var (m, side, rear) = twoCameraSession()
        MultiCameraSync.setSync(&m, sourceID: rear, sync: MultiCameraSync.manualSync(referenceMark: 20, sourceMark: 7.6, referenceFrameRate: 60, sourceFrameRate: 30, now: now), now: now)
        _ = MultiCameraSync.pairAutomatically(&m, primarySourceID: side, secondarySourceID: rear, now: now)
        var results: [UUID: KickStatRecord] = [:]
        let attempts = m.attempts
        for (i, a) in attempts.enumerated() {
            var r = KickStatRecord()
            r.result = [KickResult.made, .missedLeft, .made, .unknown][i]
            r.distanceYards = [32, 38, 45, 45][i]
            r.hashLocation = [HashLocation.left, .left, .right, .center][i]
            results[a.id] = r
        }
        let s = SessionReviewSummary.make(m, results: results)
        #expect(s.attempts == 4 && s.resultsEntered == 3 && s.made == 2 && s.missedLeft == 1)
        #expect(s.makeRate == RateSummary(successes: 2, attempts: 3))
        #expect(s.byDistance.map(\.bucket) == [.from30To39, .from40To49])
        #expect(s.byHash.first { $0.hash == .left }?.rate == RateSummary(successes: 1, attempts: 2))
        #expect(s.confirmed == 7, "candidates per camera are still listed for review")
    }

    @Test func firstVersusSecondHalfIsDescriptiveAndNeedsEnoughKicks() throws {
        func e(_ v: Double, _ n: Int) -> RankingEntry {
            var x = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: Double(n)), kickType: .fieldGoal, view: .depth,
                                 engineVersion: PoseVideoAnalysisService.version, completed: true, overallScore: nil, categoryScores: [:])
            x.metrics[RankingEntry.metricKey(.plantLateralMovement)] = v
            return x
        }
        let values = [0.04, 0.05, 0.04, 0.05, 0.12, 0.13, 0.12, 0.14]
        let t = try #require(SessionAnalytics.trends(values.enumerated().map { e($1, $0) }, view: .depth).first { $0.key == .plantLateralMovement })
        #expect(t.halvesCount == (4, 4))
        #expect(t.halvesText?.hasPrefix("Plant-foot sideways slide was higher in the second half") == true)
        #expect(t.halvesText?.contains("doesn't show fatigue") == true)
        let few = SessionAnalytics.trends([0.04, 0.05, 0.12, 0.13].enumerated().map { e($1, $0) }, view: .depth)
        #expect(few.first?.halvesText == nil, "fewer than 3 kicks per half: no comparison")
        let flat = SessionAnalytics.trends([0.05, 0.06, 0.05, 0.06, 0.06, 0.05].enumerated().map { e($1, $0) }, view: .depth)
        #expect(flat.first?.halvesText == nil, "within measurement precision")
    }

    // MARK: Compare 1.1 — framing

    @Test func zoomToAthleteKeepsAspectAndTheWholeAthlete() throws {
        var timeline = SyntheticPose.timeline(SyntheticPose.KickScript.realWorld30fps)
        timeline = PoseTimelineProcessor.process(timeline)
        let box = try #require(AthleteFraming.athleteBox(timeline, window: 0...10))
        let content = OverlayRect(x: 0, y: 40, width: 180, height: 320)
        let t = AthleteFraming.transform(box: box, content: content, containerWidth: 180, containerHeight: 400)
        #expect(t.scale >= 1 && t.scale <= AthleteFraming.maximumScale)
        // Every corner of the athlete's box stays on screen.
        for (x, y) in [(box.cx - box.w / 2, box.cy - box.h / 2), (box.cx + box.w / 2, box.cy + box.h / 2)] {
            let p = t.apply(x: content.x + x * content.width, y: content.y + y * content.height)
            #expect(p.x >= -1e-6 && p.x <= 180 + 1e-6 && p.y >= -1e-6 && p.y <= 400 + 1e-6, "\(p)")
        }
        #expect(AthleteFraming.athleteBox(nil, window: 0...1) == nil, "no tracked athlete: no zoom")
    }

    @Test func manualZoomIsClampedToTheVideo() {
        let content = OverlayRect(x: 0, y: 0, width: 200, height: 300)
        let wild = ZoomTransform(scale: 9, offsetX: 500, offsetY: -5000)
        let c = AthleteFraming.clamp(wild, content: content, containerWidth: 200, containerHeight: 300)
        #expect(c.scale == AthleteFraming.maximumScale)
        #expect(c.offsetX == 0 && c.offsetY == 300 - 4 * 300, "pinned to the video's edges, never beyond")
        #expect(AthleteFraming.clamp(.identity, content: content, containerWidth: 200, containerHeight: 300) == .identity)
    }

    @Test func compareOpensCleanEveryTime() {
        let o = CompareOverlaySettings()
        #expect(!o.skeleton && !o.plantFoot && !o.football && !o.measurementLines && !o.ballFlight && !o.contactBadge)
        #expect(!o.anyVisible)
        #expect(!o.zoomToAthlete)
    }

    // MARK: Ball flight (experimental)

    private func det(_ t: Double, _ x: Double, _ y: Double, _ w: Double = 0.03, score: Double = 0.7) -> FootballDetection {
        FootballDetection(time: t, box: NormalizedBox(cx: x, cy: y, w: w, h: w * 0.7), score: score, pass: .precision)
    }

    @Test func theKickedBallIsFollowedWithMeasuredAndFilledInPointsApart() throws {
        let restBox = NormalizedBox(cx: 0.5, cy: 0.8, w: 0.03, h: 0.02)
        var frames: [(time: Double, boxes: [FootballDetection])] = []
        for i in 1...12 {
            let t = 2.0 + Double(i) / 60
            let x = 0.5 + Double(i) * 0.01, y = 0.8 - Double(i) * 0.02, w = 0.03 - Double(i) * 0.0015
            var boxes = [det(t, x, y, w)]
            if i == 5 || i == 6 { boxes = [] }                   // missed for two frames
            if i == 3 { boxes.append(det(t, 0.1, 0.2)) }         // a second ball far away
            boxes.append(det(t, 0.5, 0.8))                        // another ball still on the tee
            frames.append((t, boxes))
        }
        let o = BallFlightObserver.observe(contactTime: 2.0, rest: restBox, detections: frames, windowEnd: 2.2)
        #expect(o.measuredCount == 10 && o.inferredCount == 2, "the gap is filled and marked")
        #expect(o.points.filter { !$0.measured }.map(\.time) == [frames[4].time, frames[5].time])
        #expect(o.rejectedDetections >= 13, "the far ball and the ball on the tee are rejected")
        #expect(o.end == .windowEnded)
        #expect(o.summary.contains("partial flight observation, not hang time"))
    }

    @Test func ballFlightEndsHonestly() {
        let restBox = NormalizedBox(cx: 0.5, cy: 0.8, w: 0.03, h: 0.02)
        var shrinking: [(time: Double, boxes: [FootballDetection])] = []
        for i in 1...10 {
            let d = Double(i)
            let t: Double = 2.0 + d / 60
            let y: Double = 0.8 - d * 0.03
            let w: Double = max(0.004, 0.03 - d * 0.003)
            shrinking.append((t, [det(t, 0.5, y, w)]))
        }
        #expect(BallFlightObserver.observe(contactTime: 2, rest: restBox, detections: shrinking, windowEnd: 3).end == .tooSmall)
        let lost = [(time: 2.0167, boxes: [det(2.0167, 0.51, 0.78)]), (time: 2.0333, boxes: [det(2.0333, 0.52, 0.76)]),
                    (time: 2.3, boxes: [det(2.3, 0.6, 0.5)])]
        #expect(BallFlightObserver.observe(contactTime: 2, rest: restBox, detections: lost, windowEnd: 3).end == .lost)
        let nothing = BallFlightObserver.observe(contactTime: 2, rest: restBox, detections: [(time: 2.1, boxes: [det(2.1, 0.5, 0.8)])], windowEnd: 3)
        #expect(nothing.end == .notTracked && nothing.observedSeconds == nil)
        #expect(nothing.summary.hasPrefix("Ball flight not observed."))
    }
}
