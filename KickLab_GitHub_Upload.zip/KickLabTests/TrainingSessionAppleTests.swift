#if canImport(AVFoundation) && canImport(Vision) && canImport(CoreML)
import AVFoundation
import Foundation
import Testing
@testable import KickLab

/// Build 21 — the Apple-only pieces of training sessions, run against generated gray test
/// videos (no people, no football, no real footage). These exercise the real
/// AVFoundation / Core ML / Vision code paths; they say nothing about detection accuracy
/// on real practice footage, which needs device testing.
@Suite("Build 21 training sessions on Apple frameworks", .serialized)
struct TrainingSessionAppleTests {
    private func grayVideo(seconds: Int, fps: Int32 = 30) async throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("session-\(UUID().uuidString).mov")
        try await FixtureVideo.writeGrayVideo(to: url, frameCount: seconds * Int(fps), framesPerSecond: fps)
        return url
    }

    @Test func clipExporterCutsARangeWithoutReencoding() async throws {
        let source = try await grayVideo(seconds: 6)
        defer { try? FileManager.default.removeItem(at: source) }
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent("clip-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: destination) }
        let clip = try await AVClipExporter().exportClip(from: source, start: 2.0, end: 4.0, to: destination)
        #expect(FileManager.default.fileExists(atPath: destination.path))
        #expect(clip.startInSource == 2.0)
        // Passthrough can snap to sync samples, so allow some slack around the 2 s request.
        #expect(clip.duration > 1.0 && clip.duration < 3.0, "exported \(clip.duration) s")
        // The source is never modified.
        let sourceDuration = try await AVURLAsset(url: source).load(.duration).seconds
        #expect(abs(sourceDuration - 6.0) < 0.1)
    }

    @Test func sessionScannerFindsNothingInAnEmptyVideo() async throws {
        let scanner = CoreMLSessionScanner(personDetector: VisionScanPerson.detector())
        try #require(scanner.isAvailable, "YOLOX-S must be bundled")
        let source = try await grayVideo(seconds: 4)
        defer { try? FileManager.default.removeItem(at: source) }
        let samples = try await scanner.scan(videoURL: source, framesPerSecond: SessionScanSettings.framesPerSecond) { _ in }
        // About 5 frames per second of a 4 s video.
        #expect(samples.count >= 12 && samples.count <= 28, "\(samples.count) samples")
        #expect(samples.allSatisfy { $0.balls.isEmpty && $0.person == nil })
        #expect(KickDiscovery.discover(samples).isEmpty, "no ball, no person → no candidate")
    }

    @Test func ballFlightTrackerReportsNotTrackedWithoutABall() async throws {
        let tracker = CoreMLBallFlightTracker()
        try #require(tracker.isAvailable)
        let source = try await grayVideo(seconds: 3)
        defer { try? FileManager.default.removeItem(at: source) }
        let observation = try await tracker.observe(videoURL: source, contactTime: 1.0,
                                                    rest: NormalizedBox(cx: 0.5, cy: 0.8, w: 0.03, h: 0.03), seconds: 1.0)
        #expect(observation.end == .notTracked)
        #expect(observation.measuredCount == 0)
    }
}
#endif
