#if canImport(AVFoundation) && canImport(Vision) && canImport(CoreML)
import AVFoundation
import Foundation
import Testing
@testable import KickLab

/// Build 21 — the Apple-only pieces of training sessions, run against generated gray test
/// videos (no people, no football, no real footage). These exercise the real
/// AVFoundation / Core ML / Vision code paths; they say nothing about detection accuracy
/// on real practice footage, which needs device testing.
@Suite("Build 21 training sessions on Apple frameworks", .serialized)
struct TrainingSessionAppleTests {
    private func grayVideo(seconds: Int, fps: Int32 = 30) async throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("session-\(UUID().uuidString).mov")
        try await FixtureVideo.writeGrayVideo(to: url, frameCount: seconds * Int(fps), framesPerSecond: fps)
        return url
    }

    @Test func clipExporterCutsARangeWithoutReencoding() async throws {
        let source = try await grayVideo(seconds: 6)
        defer { try? FileManager.default.removeItem(at: source) }
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent("clip-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: destination) }
        let clip = try await AVClipExporter().exportClip(from: source, start: 2.0, end: 4.0, to: destination)
        #expect(FileManager.default.fileExists(atPath: destination.path))
        #expect(clip.startInSource == 2.0)
        // Passthrough can snap to sync samples, so allow some slack around the 2 s request.
        #expect(clip.duration > 1.0 && clip.duration < 3.0, "exported \(clip.duration) s")
        // The source is never modified.
        let sourceDuration = try await AVURLAsset(url: source).load(.duration).seconds
        #expect(abs(sourceDuration - 6.0) < 0.1)
    }

    @Test func sessionScannerFindsNothingInAnEmptyVideo() async throws {
        let scanner = CoreMLSessionScanner(personDetector: VisionScanPerson.detector())
        try #require(scanner.isAvailable, "YOLOX-S must be bundled")
        let source = try await grayVideo(seconds: 4)
        defer { try? FileManager.default.removeItem(at: source) }
        let samples = try await scanner.scan(videoURL: source, framesPerSecond: SessionScanSettings.framesPerSecond) { _ in }
        // About 5 frames per second of a 4 s video.
        #expect(samples.count >= 12 && samples.count <= 28, "\(samples.count) samples")
        #expect(samples.allSatisfy { $0.balls.isEmpty && $0.person == nil })
        #expect(KickDiscovery.discover(samples).isEmpty, "no ball, no person → no candidate")
    }

    @Test func ballFlightTrackerReportsNotTrackedWithoutABall() async throws {
        let tracker = CoreMLBallFlightTracker()
        try #require(tracker.isAvailable)
        let source = try await grayVideo(seconds: 3)
        defer { try? FileManager.default.removeItem(at: source) }
        let observation = try await tracker.observe(videoURL: source, contactTime: 1.0,
                                                    rest: NormalizedBox(cx: 0.5, cy: 0.8, w: 0.03, h: 0.03), seconds: 1.0)
        #expect(observation.end == .notTracked)
        #expect(observation.measuredCount == 0)
    }
}
#endif

#if canImport(AVFoundation) && canImport(Vision) && canImport(CoreML)
/// Build 21 Hotfix 2 — recording → clip timing on REAL AVFoundation (generated video whose
/// frames encode their own index in their brightness; long key-frame interval so the
/// passthrough clip needs an edit list). Not the athlete's footage.
@Suite("Hotfix 2: clip timing on Apple frameworks", .serialized)
struct ClipTimingAppleTests {
    /// Frame i has luma ≈ 30 + 3·(i mod 60).
    static func numberedVideo(seconds: Int, fps: Int32, transform: CGAffineTransform = .identity) async throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("numbered-\(UUID().uuidString).mov")
        let width = 160, height = 120
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: width, AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [AVVideoMaxKeyFrameIntervalKey: Int(fps) * 3, AVVideoAllowFrameReorderingKey: false],
        ])
        input.expectsMediaDataInRealTime = false
        input.transform = transform
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width, kCVPixelBufferHeightKey as String: height,
        ])
        writer.add(input)
        guard writer.startWriting() else { throw FixtureVideo.WriteError(message: "can't start") }
        writer.startSession(atSourceTime: .zero)
        for index in 0..<(seconds * Int(fps)) {
            while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 2_000_000) }
            var buffer: CVPixelBuffer?
            CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, nil, &buffer)
            guard let buffer else { throw FixtureVideo.WriteError(message: "no buffer") }
            CVPixelBufferLockBaseAddress(buffer, [])
            if let base = CVPixelBufferGetBaseAddress(buffer) { memset(base, Int32(30 + 3 * (index % 60)), CVPixelBufferGetDataSize(buffer)) }
            CVPixelBufferUnlockBaseAddress(buffer, [])
            guard adaptor.append(buffer, withPresentationTime: CMTime(value: Int64(index), timescale: fps)) else {
                throw FixtureVideo.WriteError(message: "append failed")
            }
        }
        input.markAsFinished()
        await writer.finishWriting()
        guard writer.status == .completed else { throw FixtureVideo.WriteError(message: writer.error?.localizedDescription ?? "finish failed") }
        return url
    }

    /// (time, index mod 60) of every frame the ANALYSIS reader returns.
    static func decodedFrames(_ url: URL) async throws -> [(time: Double, index: Int)] {
        var out: [(Double, Int)] = []
        _ = try await VideoFrameReader.read(url: url, plan: FrameSamplingPlan(rate: .everyFrame)) { _, time, buffer in
            CVPixelBufferLockBaseAddress(buffer, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
            guard let base = CVPixelBufferGetBaseAddressOfPlane(buffer, 0) else { return }
            let row = CVPixelBufferGetBytesPerRowOfPlane(buffer, 0)
            let h = CVPixelBufferGetHeightOfPlane(buffer, 0), w = CVPixelBufferGetWidthOfPlane(buffer, 0)
            let y = Double(base.load(fromByteOffset: (h / 2) * row + w / 2, as: UInt8.self))
            out.append((time, Int(((y - 30) / 3).rounded())))
        }
        return out
    }

    @Test func clipTimeZeroIsTheRequestedRecordingFrameEvenWithAnEditList() async throws {
        let source = try await Self.numberedVideo(seconds: 6, fps: 30)
        defer { try? FileManager.default.removeItem(at: source) }
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent("clip-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: dest) }
        // 2.0 s is not a key frame (key frames every 3 s), so the passthrough clip carries an edit list.
        let clip = try await AVClipExporter().exportClip(from: source, start: 2.0, end: 4.0, to: dest)
        let frames = try await Self.decodedFrames(dest)
        let first = try #require(frames.first)
        #expect(abs(first.time) < 0.5 / 30, "first analyzed frame at clip time 0 (got \(first.time))")
        #expect(abs(first.index - 60 % 60) <= 1, "clip time 0 shows recording frame 60 (2.0 s); decoded \(first.index)")
        // A later frame: clip 1.0 s = recording 3.0 s = frame 90 (≡ 30).
        let oneSecond = try #require(frames.min { abs($0.time - 1.0) < abs($1.time - 1.0) })
        #expect(abs(oneSecond.index - 30) <= 1, "clip 1.0 s ↔ recording 3.0 s; decoded \(oneSecond.index)")
        #expect(abs(ClipTimeMapping.sourceTime(clipTime: oneSecond.time, clipStartInSource: clip.startInSource) - 3.0) < 0.5 / 30)
        // The inspector reports the same first-frame time; the record carries no warning.
        let info = await AVMediaTimingInspector().timing(of: dest)
        let timing = ClipTimingRecord.make(requestedStart: 2.0, requestedDuration: 2.0, exportedDuration: clip.duration, info: info)
        #expect(timing.warning == nil, "\(timing.warning ?? "")")
    }

    @Test func sixtyFrameRecordingsMapFrameAccurately() async throws {
        let source = try await Self.numberedVideo(seconds: 4, fps: 60)
        defer { try? FileManager.default.removeItem(at: source) }
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent("clip60-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: dest) }
        _ = try await AVClipExporter().exportClip(from: source, start: 1.5, end: 3.0, to: dest)
        let first = try #require(try await Self.decodedFrames(dest).first)
        #expect(abs(first.index - 90 % 60) <= 1, "clip 0 = recording frame 90 at 60 fps; decoded \(first.index)")
    }

    @Test func portraitRecordingsAreReportedAsPortrait() async throws {
        // A landscape-encoded buffer with a 90° transform, like an iPhone held upright.
        let url = try await Self.numberedVideo(seconds: 1, fps: 30, transform: CGAffineTransform(a: 0, b: 1, c: -1, d: 0, tx: 120, ty: 0))
        defer { try? FileManager.default.removeItem(at: url) }
        let info = try #require(await AVMediaTimingInspector().timing(of: url))
        #expect(info.displayOrientation == "portrait")
        #expect(info.width == 160 && info.height == 120)
        #expect(info.codec == "avc1")
    }

    @Test func sharedVideoCopiesDropSoundAndKeepTheOriginal() async throws {
        let source = try await Self.numberedVideo(seconds: 2, fps: 30)
        defer { try? FileManager.default.removeItem(at: source) }
        let before = try Data(contentsOf: source)
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent("share-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: dest) }
        try await AVSharingVideoExporter().exportForSharing(source: source, includeAudio: false, to: dest)
        #expect(FileManager.default.fileExists(atPath: dest.path))
        #expect(try Data(contentsOf: source) == before, "the original is untouched")
        let info = try #require(await AVMediaTimingInspector().timing(of: dest))
        #expect(info.hasAudio == false)
    }
}
#endif
