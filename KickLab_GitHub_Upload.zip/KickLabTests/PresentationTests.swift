import Foundation
import Testing
@testable import KickLab

@Suite("Step 9 formatting and results presentation")
struct PresentationTests {
    // MARK: Formatting

    @Test func formattingIsDeterministic() {
        #expect(DisplayFormat.score(82.4) == "82")
        #expect(DisplayFormat.score(nil) == "—")
        #expect(DisplayFormat.percent(fraction: 0.768) == "77%")
        #expect(DisplayFormat.percentage(66.666) == "66.7%")
        #expect(DisplayFormat.percentage(50) == "50%")
        #expect(DisplayFormat.metricValue(0.2, unit: .seconds) == "0.20 s")
        #expect(DisplayFormat.metricValue(-35, unit: .degrees) == "-35°")
        #expect(DisplayFormat.metricValue(1.637, unit: .bodyLengthsPerSecond) == "1.6 body lengths/s")
        #expect(DisplayFormat.metricValue(0.458, unit: .bodyLengths) == "0.46 body lengths")
        #expect(DisplayFormat.metricValue(nil, unit: .seconds) == "—")
        #expect(DisplayFormat.number(-0.001, digits: 2) == "0.00", "no negative zero")
        #expect(DisplayFormat.yards(40) == "40 yd")
        #expect(DisplayFormat.confidence(0.768) == "High confidence · 77%")
        #expect(DisplayFormat.confidence(0.536) == "Medium confidence · 54%")
        #expect(DisplayFormat.confidence(nil) == "Not enough data")
        #expect(DisplayFormat.isoDay(Date(timeIntervalSince1970: 0)) == "1970-01-01")
    }

    @Test func gradesAreWordsNotJustColors() {
        #expect(ScoreGrade(score: 90) == .excellent)
        #expect(ScoreGrade(score: 70) == .good)
        #expect(ScoreGrade(score: 69.9) == .fair)
        #expect(ScoreGrade(score: 10) == .needsWork)
        #expect(ScoreGrade(score: nil) == .unavailable)
        for grade in [ScoreGrade.excellent, .good, .fair, .needsWork, .unavailable] {
            #expect(!grade.label.isEmpty)
        }
        #expect(AnalysisCategory.contact.presentationTitle == "Body Position at Contact")
        #expect(AnalysisCategory.followThrough.presentationTitle == "Follow-Through")
    }

    // MARK: Results

    /// A stored-looking record made from a real Step 8 result.
    static func record(_ script: SyntheticPose.KickScript = .fieldGoal, isCurrent: Bool = true,
                       status: ProcessingStatus = .completed) -> AnalysisRecord {
        let r = SyntheticBiomechanics.analyze(script)
        return AnalysisRecord(
            id: UUID(), kickID: UUID(), kickType: .fieldGoal, kickDate: Date(timeIntervalSince1970: 1_800_000_000),
            createdAt: Date(timeIntervalSince1970: 1_800_000_000), completedAt: Date(timeIntervalSince1970: 1_800_000_100),
            status: status, isCurrent: isCurrent, overallScore: r.overallScore, confidence: r.overallConfidence,
            failureReason: status == .failed ? "Not enough of the kick was visible to measure its mechanics." : nil,
            engineVersion: PoseVideoAnalysisService.version,
            metrics: r.metricDrafts.map {
                StoredMetricRecord(key: $0.metricKey, value: $0.value, unit: $0.unit, confidence: $0.confidence,
                                   status: $0.measurementStatus, phase: $0.phase)
            },
            categories: r.scoreDrafts.map {
                StoredCategoryRecord(category: $0.category, score: $0.score, confidence: $0.confidence,
                                     status: $0.measurementStatus, summary: $0.summary)
            },
            observations: r.observationDrafts.map {
                StoredObservationRecord(id: $0.id, kind: $0.kind, category: $0.category, message: $0.message,
                                        severity: $0.severity, confidence: $0.confidence, priority: $0.priority,
                                        ruleKey: $0.ruleKey, relatedObservationID: $0.relatedObservationID,
                                        evidenceMetricKeys: $0.evidenceMetricKeys)
            }
        )
    }

    @Test func resultsShowTheStep8Analysis() {
        var script = SyntheticPose.KickScript.fieldGoal
        script.plantSlip = 0.075
        let p = AnalysisPresentationBuilder.make(Self.record(script))
        #expect(p.header.kickTypeText == "Field Goal")
        #expect(p.header.statusText == "Current analysis")
        #expect(p.header.overallScoreText == DisplayFormat.score(p.header.overallScore))
        #expect(p.problem == nil)
        #expect(p.categories.map(\.title) == ["Approach", "Plant", "Swing", "Body Position at Contact", "Follow-Through"])
        #expect(p.categories.allSatisfy { $0.topMetrics.count <= 3 })
        #expect(p.metrics.count == KickMetricKey.allCases.count)
        #expect(p.metrics.allSatisfy { !$0.name.contains(".") }, "no internal metric IDs shown")
        let ptc = p.metrics.first { $0.key == .plantToContactTime }
        #expect(ptc?.name == "Plant to contact")
        #expect(ptc?.valueText == "0.20 s")
        #expect(ptc?.statusText == "Estimated")
        #expect(p.hasMechanics)
        #expect(p.notes.contains(AnalysisPresentationBuilder.contactNote))

        // Coaching: the IMPROVE is split into what/why and paired with its CUE.
        let priority = try? #require(p.priorities.first)
        #expect(priority?.observed == "Plant foot moved 0.46 body lengths around estimated contact.")
        #expect(priority?.whyItMatters == "A plant foot that slides or rolls shifts the hips and makes contact harder to repeat.")
        #expect(priority?.cue == "Drive the plant foot into the ground and keep it still through the ball.")
        #expect(priority?.severityText == "Medium priority")
        #expect(p.strengths.isEmpty)
    }

    @Test func strengthsAreSeparateFromPriorities() {
        let p = AnalysisPresentationBuilder.make(Self.record())
        #expect(p.priorities.isEmpty)
        #expect(p.strengths.map(\.observed) == ["Plant foot stayed stable through contact (0.00 body lengths of movement)."])
        #expect(p.strengths.first?.severityText == nil)
        #expect(p.strengths.first?.cue == nil)
    }

    @Test func unavailableMetricsAreNeutralNotFailures() {
        var record = Self.record()
        record.metrics = record.metrics.map { m in
            guard m.key == KickMetricKey.torsoLeanAtContact.rawValue else { return m }
            return StoredMetricRecord(key: m.key, value: nil, unit: m.unit, confidence: nil, status: .unavailable, phase: m.phase)
        }
        record.metrics.append(StoredMetricRecord(key: "other.engine.metric", value: 3, unit: .degrees, confidence: 0.9,
                                                 status: .measured, phase: .contact))
        let p = AnalysisPresentationBuilder.make(record)
        let lean = p.metrics.first { $0.key == .torsoLeanAtContact }
        #expect(lean?.valueText == "Not measured")
        #expect(lean?.statusText == "Not available")
        #expect(lean?.confidenceText == "Not enough data")
        #expect(p.metrics.count == KickMetricKey.allCases.count, "unknown keys are not shown")
        let contact = p.categories.first { $0.category == .contact }
        #expect(contact?.unavailableMetricNames == ["Torso lean at contact"])
        #expect(contact?.topMetrics.allSatisfy { $0.key != .torsoLeanAtContact } == true)
    }

    @Test func unscoredCategoriesSayNotScored() {
        var record = Self.record()
        record.categories = record.categories.map {
            $0.category == .plant ? StoredCategoryRecord(category: .plant, score: nil, confidence: nil, status: .unavailable, summary: "x") : $0
        }
        let plant = AnalysisPresentationBuilder.make(record).categories.first { $0.category == .plant }
        #expect(plant?.scoreText == "—")
        #expect(plant?.grade == .unavailable)
        #expect(plant?.confidenceText == "Not scored this time")
        #expect(plant?.isScored == false)
    }

    @Test func failedAndOlderAnalysesAreLabeled() {
        #expect(AnalysisPresentationBuilder.make(Self.record(isCurrent: false)).header.statusText == "Earlier analysis")
        let failed = AnalysisPresentationBuilder.make(Self.record(isCurrent: false, status: .failed))
        #expect(failed.header.statusText == "Didn't finish")
        #expect(failed.problem == "Not enough of the kick was visible to measure its mechanics.")
    }

    @Test func messageSplittingHandlesDecimals() {
        let split = AnalysisPresentationBuilder.splitMessage("Plant foot landed 0.40 s before estimated contact. A long pause costs momentum.")
        #expect(split.observed == "Plant foot landed 0.40 s before estimated contact.")
        #expect(split.why == "A long pause costs momentum.")
        let single = AnalysisPresentationBuilder.splitMessage("Stay tall.")
        #expect(single.observed == "Stay tall.")
        #expect(single.why == nil)
    }

    // MARK: Small presentation helpers

    @Test func videoRowsExplainStatus() {
        let local = VideoRowPresentation.make(id: UUID(), angle: .side, isPrimary: true, status: .local, durationSeconds: 3.2, frameRate: 240)
        #expect(local.angleText == "Side view")
        #expect(local.isPlayable)
        #expect(local.durationText == "3.2 s")
        #expect(local.frameRateText == "240 fps")
        let missing = VideoRowPresentation.make(id: UUID(), angle: .unknown, isPrimary: false, status: .missing, durationSeconds: nil, frameRate: nil)
        #expect(missing.angleText == "Angle not set")
        #expect(!missing.isPlayable)
        #expect(missing.statusText.contains("missing"))
        #expect(VideoRowPresentation.statusText(.offloaded) == "Offloaded")
    }

    @Test func phaseMarkersComeFromDetectedPhases() {
        let signals = SyntheticPose.signals(.fieldGoal)
        let phases = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        let markers = PhaseMarker.markers(from: phases)
        #expect(markers.map(\.title) == ["Setup", "Approach", "Plant", "Estimated Contact", "Follow-Through"])
        let contact = markers.first { $0.phase == .contact }
        #expect(near(contact?.time, 1.4, 0.034))
        #expect(contact?.isEstimated == true)
        let plant = markers.first { $0.phase == .plant }
        #expect(near(plant?.time, 1.2, 0.05))
        #expect(PhaseMarker.markers(from: .unavailable(kickType: .fieldGoal, support: .full, coverage: 0, notes: [])).isEmpty)
    }

    @Test func goalpostPadMapsBothWays() {
        let center = GoalpostPadGeometry.coordinate(x: 100, y: 50, width: 200, height: 150)
        #expect(center.x == 0)
        #expect(center.y == 1)
        let leftUpright = GoalpostPadGeometry.coordinate(x: 50, y: 100, width: 200, height: 150)
        #expect(leftUpright.x == -1)
        #expect(leftUpright.y == 0)
        let back = GoalpostPadGeometry.point(for: AccuracyCoordinate(x: 1, y: 0), width: 200, height: 150)
        #expect(near(back.x, 150, 1e-9))
        #expect(near(back.y, 100, 1e-9))
        #expect(GoalpostPadGeometry.describe(AccuracyCoordinate(x: -1.4, y: 0.5)) == "Wide left, over the crossbar")
        #expect(GoalpostPadGeometry.describe(AccuracyCoordinate(x: 0.1, y: nil)) == "Down the middle")
        #expect(GoalpostPadGeometry.describe(nil) == "Tap where the ball crossed (optional).")
    }

    @Test func errorsNeverShowRawText() {
        struct Internal: Error {}
        #expect(UserFacingError.message(for: Internal()) == "Something went wrong. Please try again.")
        #expect(UserFacingError.message(for: VideoAnalysisError.noUsableInputs) == AnalysisProblem.videoMissing.message)
        let validation = KickValidationError(issues: [.touchbackAndOutOfBounds])
        #expect(UserFacingError.message(for: validation) == "A kickoff cannot be both a touchback and out of bounds.")
    }

    @Test func loadStateExposesItsValue() {
        #expect(LoadState<Int>.loaded(3).value == 3)
        #expect(LoadState<Int>.loading.value == nil)
        #expect(LoadState<Int>.failed("x").value == nil)
    }
}
