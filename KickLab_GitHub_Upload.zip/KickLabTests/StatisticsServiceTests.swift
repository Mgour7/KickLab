import Foundation
import Testing
@testable import KickLab

/// Statistics over known datasets with exact expected results. Uses the in-memory
/// source, so it runs on any platform; the SwiftData source is checked separately.
@Suite("Statistics")
struct StatisticsServiceTests {
    private static let athlete = UUID()
    private static let otherAthlete = UUID()
    private static let session = UUID()
    /// 2026-01-01T00:00:00Z
    private static let t0 = Date(timeIntervalSince1970: 1_767_225_600)

    private static func day(_ n: Int) -> Date { t0.addingTimeInterval(Double(n) * 86_400) }

    private static func fg(
        _ result: KickResult,
        _ distance: Double?,
        _ hash: HashLocation,
        _ context: KickContext,
        x: Double? = nil,
        y: Double? = nil,
        accuracySource: OutcomeMeasurementSource? = nil,
        day d: Int = 0,
        type: KickType = .fieldGoal,
        athlete: UUID = StatisticsServiceTests.athlete
    ) -> KickStatRecord {
        KickStatRecord(
            athleteID: athlete,
            timestamp: day(d),
            kickType: type,
            context: context,
            hashLocation: hash,
            result: result,
            distanceYards: distance,
            distanceSource: distance == nil ? nil : .manual,
            accuracyX: x,
            accuracyY: y,
            accuracySource: x == nil ? nil : accuracySource
        )
    }

    private static func kickoff(
        touchback: Bool?,
        outOfBounds: Bool? = false,
        distance: Double? = nil,
        distanceSource: OutcomeMeasurementSource? = nil,
        hang: Double? = nil,
        hangSource: OutcomeMeasurementSource? = nil,
        landing: Double? = nil,
        landingSource: OutcomeMeasurementSource? = nil,
        zone: LandingZone? = nil,
        context: KickContext = .training,
        day d: Int = 0
    ) -> KickStatRecord {
        KickStatRecord(
            athleteID: athlete,
            timestamp: day(d),
            kickType: .kickoff,
            context: context,
            touchback: touchback,
            outOfBounds: outOfBounds,
            landingYardLine: landing,
            landingZone: zone,
            landingSource: landingSource,
            hangTimeSeconds: hang,
            hangTimeSource: hangSource
        ).with(distance: distance, source: distanceSource)
    }

    /// 9 field goals (8 decided, 4 made), 3 PATs, 4 kickoffs, 2 punts for the athlete,
    /// plus one field goal for another athlete that must never be counted.
    private static let dataset: [KickStatRecord] = [
        fg(.made, 25, .left, .training, x: 0.25, accuracySource: .manual, day: 1),
        fg(.made, 35, .center, .game, x: -0.5, y: 0.5, accuracySource: .primaryVideo, day: 2),
        fg(.missedLeft, 42, .right, .training, x: -1.5, accuracySource: .manual, day: 3),
        fg(.missedRight, 47, .left, .game, x: 1.25, accuracySource: .multiVideo, day: 4),
        fg(.short, 52, .center, .training, day: 5),
        fg(.blocked, 38, .right, .game, day: 6),
        fg(.unknown, 44, .left, .training, day: 7),
        fg(.made, 55, .center, .camp, x: 0, y: 0.25, accuracySource: .manual, day: 8),
        fg(.made, nil, .center, .training, day: 9),
        fg(.made, 20, .center, .training, day: 10, type: .pat),
        fg(.made, 20, .center, .game, day: 11, type: .pat),
        fg(.unknown, 20, .center, .game, day: 12, type: .pat),
        kickoff(touchback: true, distance: 64, distanceSource: .primaryVideo, hang: 4.0, hangSource: .manual,
                landing: -2, landingSource: .multiVideo, zone: .middle, day: 13),
        kickoff(touchback: false, outOfBounds: true, distance: 60, distanceSource: .manual, hang: 3.5, hangSource: .primaryVideo,
                landing: 5, landingSource: .manual, zone: .left, context: .game, day: 14),
        kickoff(touchback: true, distance: 68, distanceSource: .manual, zone: .right, day: 15),
        kickoff(touchback: nil, outOfBounds: nil, hang: 4.5, hangSource: .secondaryVideo, day: 16),
        KickStatRecord(athleteID: athlete, timestamp: day(17), kickType: .punt,
                       distanceYards: 40, distanceSource: .manual, hangTimeSeconds: 4.25, hangTimeSource: .manual),
        KickStatRecord(athleteID: athlete, timestamp: day(18), kickType: .punt,
                       distanceYards: 46, distanceSource: .primaryVideo, hangTimeSeconds: 4.75, hangTimeSource: .primaryVideo),
        fg(.made, 30, .left, .training, day: 5, athlete: otherAthlete),
    ]

    private let service = StatisticsService(source: InMemoryKickStatisticsSource(StatisticsServiceTests.dataset))
    private let all = StatisticsFilter(athleteID: StatisticsServiceTests.athlete)

    // MARK: General

    @Test func generalCounts() throws {
        #expect(try service.totalKickCount(all) == 18)
        #expect(try service.kickCountsByType(all) == [
            KickTypeCount(kickType: .fieldGoal, count: 9),
            KickTypeCount(kickType: .pat, count: 3),
            KickTypeCount(kickType: .kickoff, count: 4),
            KickTypeCount(kickType: .punt, count: 2),
        ])
        let byContext = try service.kickCountsByContext(all)
        #expect(byContext.first { $0.context == .training }?.count == 11)
        #expect(byContext.first { $0.context == .game }?.count == 6)
        #expect(byContext.first { $0.context == .camp }?.count == 1)
        #expect(byContext.first { $0.context == .warmup }?.count == 0)
    }

    @Test func contextFilterZeroesExcludedContexts() throws {
        let gameOnly = StatisticsFilter(athleteID: Self.athlete, contexts: [.game])
        let byContext = try service.kickCountsByContext(gameOnly)
        #expect(byContext.first { $0.context == .game }?.count == 6)
        #expect(byContext.first { $0.context == .training }?.count == 0)
    }

    @Test func dateRangeAndRecentKicks() throws {
        #expect(try service.kickCount(in: Self.day(1)...Self.day(3), all) == 3)
        let recent = try service.recentKicks(limit: 3, all)
        #expect(recent.map(\.timestamp) == [Self.day(18), Self.day(17), Self.day(16)])
        #expect(try service.recentKicks(limit: 100, all).count == 18)
    }

    @Test func sessionKickCount() throws {
        var a = KickStatRecord(athleteID: Self.athlete)
        a.sessionID = Self.session
        var b = KickStatRecord(athleteID: Self.athlete)
        b.sessionID = Self.session
        let source = InMemoryKickStatisticsSource([a, b, KickStatRecord(athleteID: Self.athlete)])
        #expect(try StatisticsService(source: source).sessionKickCount(sessionID: Self.session) == 2)
    }

    // MARK: Field goals

    @Test func fieldGoalAttemptsMakesAndPercentageExcludeUnknown() throws {
        let stats = try service.fieldGoalStatistics(all)
        #expect(stats.kickCount == 9)
        #expect(stats.makeRate == RateStatistic(attempts: 8, successes: 4))
        #expect(stats.makeRate.percentage == 50)
        #expect(stats.results == ResultBreakdown(made: 4, missedLeft: 1, missedRight: 1, short: 1, blocked: 1, unknown: 1))
        #expect(stats.results.decided == 8)
    }

    @Test func distanceBuckets() throws {
        let stats = try service.fieldGoalStatistics(all)
        let rates = Dictionary(uniqueKeysWithValues: stats.byDistance.map { ($0.bucket, $0.makeRate) })
        #expect(rates[.under30] == RateStatistic(attempts: 1, successes: 1))
        #expect(rates[.from30To39] == RateStatistic(attempts: 2, successes: 1))
        #expect(rates[.from40To49] == RateStatistic(attempts: 2, successes: 0), "the unknown 44-yarder is not an attempt")
        #expect(rates[.fiftyPlus] == RateStatistic(attempts: 2, successes: 1))
        #expect(stats.decidedAttemptsWithoutDistance == 1)
        #expect(stats.byDistance.map(\.bucket) == DistanceBucket.allCases)
    }

    @Test(arguments: [
        (29.9, DistanceBucket.under30), (30.0, .from30To39), (39.99, .from30To39),
        (40.0, .from40To49), (49.5, .from40To49), (50.0, .fiftyPlus), (63.0, .fiftyPlus),
    ])
    func bucketBoundaries(yards: Double, expected: DistanceBucket) {
        #expect(DistanceBucket.bucket(forYards: yards) == expected)
    }

    @Test func hashBreakdown() throws {
        let stats = try service.fieldGoalStatistics(all)
        #expect(stats.byHash == [
            HashStatistics(hash: .left, makeRate: RateStatistic(attempts: 2, successes: 1)),
            HashStatistics(hash: .center, makeRate: RateStatistic(attempts: 4, successes: 3)),
            HashStatistics(hash: .right, makeRate: RateStatistic(attempts: 2, successes: 0)),
        ])
    }

    @Test func contextBreakdownTrainingVersusGame() throws {
        let stats = try service.fieldGoalStatistics(all)
        let byContext = Dictionary(uniqueKeysWithValues: stats.byContext.map { ($0.context, $0.makeRate) })
        #expect(byContext[.training] == RateStatistic(attempts: 4, successes: 2))
        #expect(byContext[.game] == RateStatistic(attempts: 3, successes: 1))
        #expect(byContext[.camp] == RateStatistic(attempts: 1, successes: 1))
        #expect(byContext[.competition] == .empty)
        #expect(byContext[.competition]?.rate == nil)

        let gameOnly = try service.fieldGoalStatistics(StatisticsFilter(athleteID: Self.athlete, contexts: [.game]))
        #expect(gameOnly.makeRate == RateStatistic(attempts: 3, successes: 1))
    }

    @Test func accuracyAveragesAndDistribution() throws {
        let accuracy = try service.fieldGoalStatistics(all).accuracy
        #expect(accuracy.sampleCount == 5)
        #expect(accuracy.averageX == -0.1)                 // (0.25 − 0.5 − 1.5 + 1.25 + 0) / 5
        #expect(accuracy.averageAbsoluteDeviation == 0.7)  // 3.5 / 5
        #expect(accuracy.verticalSampleCount == 2, "vertical is averaged only where y was recorded")
        #expect(accuracy.averageY == 0.375)
        #expect(accuracy.allDistribution == [
            BandCount(band: .outsideLeft, count: 1),
            BandCount(band: .left, count: 1),
            BandCount(band: .center, count: 2),
            BandCount(band: .right, count: 0),
            BandCount(band: .outsideRight, count: 1),
        ])
        #expect(accuracy.madeDistribution.map(\.count) == [0, 1, 2, 0, 0])
    }

    @Test func accuracyRespectsProvenanceFilter() throws {
        let manual = try service.fieldGoalStatistics(StatisticsFilter(athleteID: Self.athlete, measurementSource: .manualOnly)).accuracy
        #expect(manual.sampleCount == 3)
        #expect(approximately(manual.averageAbsoluteDeviation, 1.75 / 3))
        #expect(manual.verticalSampleCount == 1)

        let video = try service.fieldGoalStatistics(StatisticsFilter(athleteID: Self.athlete, measurementSource: .videoDerivedOnly)).accuracy
        #expect(video.sampleCount == 2)
        #expect(video.averageX == 0.375)   // (−0.5 + 1.25) / 2
    }

    @Test func patStatisticsAreSeparate() throws {
        let pat = try service.fieldGoalStatistics(all, kickType: .pat)
        #expect(pat.kickType == .pat)
        #expect(pat.makeRate == RateStatistic(attempts: 2, successes: 2))
        #expect(pat.results.unknown == 1)
    }

    // MARK: Kickoffs

    @Test func kickoffStatistics() throws {
        let stats = try service.kickoffStatistics(all)
        #expect(stats.kickoffCount == 4)
        #expect(stats.touchbackRate == RateStatistic(attempts: 3, successes: 2), "an unrecorded touchback is not a 'no'")
        #expect(approximately(stats.touchbackRate.percentage, 200.0 / 3))
        #expect(stats.outOfBoundsCount == 1)
        #expect(stats.distance.sampleCount == 3)
        #expect(stats.distance.average == 64)
        #expect(stats.distance.maximum == 68)
        #expect(stats.distance.sources == [SourceCount(source: .manual, count: 2), SourceCount(source: .primaryVideo, count: 1)])
        #expect(stats.hangTime.average == 4.0)
        #expect(stats.hangTime.maximum == 4.5)
        #expect(stats.landingYardLine.average == 1.5)
        #expect(stats.landingZones == [
            ZoneCount(zone: .left, count: 1),
            ZoneCount(zone: .middle, count: 1),
            ZoneCount(zone: .right, count: 1),
            ZoneCount(zone: .unknown, count: 0),
        ])
    }

    @Test func kickoffProvenanceFilters() throws {
        let manual = try service.kickoffStatistics(StatisticsFilter(athleteID: Self.athlete, measurementSource: .manualOnly))
        #expect(manual.distance.sampleCount == 2)
        #expect(manual.distance.average == 64)        // (60 + 68) / 2
        #expect(manual.hangTime.average == 4.0)
        #expect(manual.kickoffCount == 4, "provenance filters measurements, not which kicks count")

        let video = try service.kickoffStatistics(StatisticsFilter(athleteID: Self.athlete, measurementSource: .videoDerivedOnly))
        #expect(video.distance.average == 64)
        #expect(video.distance.sampleCount == 1)
        #expect(video.hangTime.average == 4.0)        // (3.5 + 4.5) / 2
        #expect(video.hangTime.sampleCount == 2)

        let onlySecondary = try service.kickoffStatistics(StatisticsFilter(athleteID: Self.athlete, measurementSource: .only([.secondaryVideo])))
        #expect(onlySecondary.hangTime.average == 4.5)
        #expect(onlySecondary.distance == .empty)
    }

    @Test func kickoffDateAndContextFilters() throws {
        let gameOnly = try service.kickoffStatistics(StatisticsFilter(athleteID: Self.athlete, contexts: [.game]))
        #expect(gameOnly.kickoffCount == 1)
        #expect(gameOnly.touchbackRate == RateStatistic(attempts: 1, successes: 0))

        let lateOnly = try service.kickoffStatistics(StatisticsFilter(athleteID: Self.athlete, dateRange: Self.day(15)...Self.day(16)))
        #expect(lateOnly.kickoffCount == 2)
        #expect(lateOnly.distance.average == 68)
    }

    // MARK: Punts

    @Test func puntStatistics() throws {
        let stats = try service.puntStatistics(all)
        #expect(stats.puntCount == 2)
        #expect(stats.distance.average == 43)
        #expect(stats.distance.maximum == 46)
        #expect(stats.hangTime.average == 4.5)
        #expect(stats.hangTime.maximum == 4.75)
    }

    // MARK: Edge cases

    @Test func emptyDatasetGivesZerosAndNilRates() throws {
        let empty = StatisticsService(source: InMemoryKickStatisticsSource([]))
        #expect(try empty.totalKickCount(all) == 0)
        let fg = try empty.fieldGoalStatistics(all)
        #expect(fg.makeRate == .empty)
        #expect(fg.makeRate.percentage == nil)
        #expect(fg.accuracy.averageX == nil)
        #expect(fg.accuracy.allDistribution.allSatisfy { $0.count == 0 })
        let ko = try empty.kickoffStatistics(all)
        #expect(ko.touchbackRate.percentage == nil)
        #expect(ko.distance == .empty)
        #expect(try empty.puntStatistics(all).hangTime.maximum == nil)
        #expect(try empty.recentKicks(limit: 5, all).isEmpty)
    }

    @Test func otherAthletesAreNeverCounted() throws {
        let other = try service.fieldGoalStatistics(StatisticsFilter(athleteID: Self.otherAthlete))
        #expect(other.kickCount == 1)
        #expect(try service.totalKickCount(StatisticsFilter(athleteID: UUID())) == 0)
    }

    @Test func oneKickEdgeCases() throws {
        let single = StatisticsService(source: InMemoryKickStatisticsSource([
            Self.fg(.made, 41, .right, .game, x: 0.5, accuracySource: .manual),
            Self.kickoff(touchback: false, distance: 61, distanceSource: .manual),
        ]))
        let fg = try single.fieldGoalStatistics(all)
        #expect(fg.makeRate.percentage == 100)
        #expect(fg.byDistance.first { $0.bucket == .from40To49 }?.makeRate == RateStatistic(attempts: 1, successes: 1))
        #expect(fg.byDistance.filter { $0.makeRate.attempts == 0 }.count == 3)
        #expect(fg.accuracy.averageX == 0.5)
        #expect(fg.accuracy.averageY == nil)
        let ko = try single.kickoffStatistics(all)
        #expect(ko.touchbackRate.percentage == 0)
        #expect(ko.distance.average == 61)
        #expect(ko.distance.maximum == 61)
        #expect(ko.hangTime == .empty)
    }

    // MARK: Trends

    @Test func trendComparesTwoPeriods() throws {
        let now = Self.day(60)
        let current = StatisticsPeriod.last(days: 30, endingAt: now)
        let previous = StatisticsPeriod.previous(to: current)
        #expect(previous.upperBound < current.lowerBound)

        let records = [
            // Current period (days 31–60): FG 3 of 4, kickoffs 2/2 touchbacks, 66 & 70 yd, 4.0 & 4.5 s.
            Self.fg(.made, 40, .center, .training, day: 40),
            Self.fg(.made, 45, .center, .training, day: 45),
            Self.fg(.made, 30, .center, .training, day: 50),
            Self.fg(.missedLeft, 52, .left, .training, day: 55),
            Self.kickoff(touchback: true, distance: 66, distanceSource: .manual, hang: 4.0, hangSource: .manual, day: 41),
            Self.kickoff(touchback: true, distance: 70, distanceSource: .manual, hang: 4.5, hangSource: .manual, day: 42),
            // Previous period (days 1–30): FG 1 of 2, one kickoff without touchback, 60 yd, 3.5 s.
            Self.fg(.made, 35, .center, .training, day: 10),
            Self.fg(.short, 50, .center, .training, day: 20),
            Self.kickoff(touchback: false, distance: 60, distanceSource: .manual, hang: 3.5, hangSource: .manual, day: 15),
        ]
        let trend = try StatisticsService(source: InMemoryKickStatisticsSource(records))
            .trendForLast(days: 30, endingAt: now, all)

        #expect(trend.fieldGoalPercentage == MetricTrend(current: 75, previous: 50, currentSampleCount: 4, previousSampleCount: 2))
        #expect(trend.fieldGoalPercentage.change == 25)
        #expect(trend.touchbackPercentage.current == 100)
        #expect(trend.touchbackPercentage.previous == 0)
        #expect(trend.averageKickoffDistance.change == 8)     // 68 − 60
        #expect(trend.averageKickoffHangTime.current == 4.25)
        #expect(trend.averageKickoffHangTime.previous == 3.5)
    }

    @Test func trendWithEmptyPeriodHasNoChange() throws {
        let trend = try service.trend(current: Self.day(100)...Self.day(130), previous: Self.day(1)...Self.day(30), all)
        #expect(trend.fieldGoalPercentage.current == nil)
        #expect(trend.fieldGoalPercentage.change == nil)
        #expect(trend.fieldGoalPercentage.previousSampleCount == 8)
    }
}

private extension KickStatRecord {
    func with(distance: Double?, source: OutcomeMeasurementSource?) -> KickStatRecord {
        var copy = self
        copy.distanceYards = distance
        copy.distanceSource = source
        return copy
    }
}
