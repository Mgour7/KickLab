import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: the SwiftData statistics source (#Predicate, fetchCount, sorting)
/// against kicks created through the real services.
@MainActor
@Suite("SwiftData statistics source")
struct SwiftDataStatisticsSourceTests {
    let f: ServiceFixture
    let athlete: Athlete
    let other: Athlete
    let session: KickingSession
    let statistics: StatisticsService
    let t0 = Date(timeIntervalSince1970: 1_767_225_600)

    init() throws {
        f = try ServiceFixture()
        athlete = try f.makeAthlete("Sam")
        other = try f.makeAthlete("Alex")
        session = try f.makeSession(for: athlete, type: .game)
        statistics = StatisticsService(source: SwiftDataKickStatisticsSource(context: f.context))

        func draft(_ outcome: KickOutcome, day: Int, context: KickContext? = nil, hash: HashLocation = .center) -> KickDraft {
            KickDraft(timestamp: t0.addingTimeInterval(Double(day) * 86_400), outcome: outcome, context: context, hashLocation: hash)
        }
        // Sam: 3 field goals (one unknown), 1 kickoff, 1 punt. Two kicks in the game session.
        try f.kicks.createKick(for: athlete, in: session, draft: draft(.fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(42))), day: 1))
        try f.kicks.createKick(for: athlete, in: session, draft: draft(.fieldGoal(FieldGoalOutcome(result: .missedLeft, distance: .manual(51))), day: 2, hash: .left))
        try f.kicks.createKick(for: athlete, draft: draft(.fieldGoal(FieldGoalOutcome(result: .unknown, distance: .manual(30))), day: 3))
        try f.kicks.createKick(for: athlete, draft: draft(.kickoff(KickoffOutcome(
            distance: .measured(65.5, from: .primaryVideo, confidence: 0.9),
            touchback: true,
            hangTime: .manual(4.0)
        )), day: 4))
        try f.kicks.createKick(for: athlete, draft: draft(.punt(PuntOutcome(distance: .manual(44))), day: 5, context: .warmup))
        // Alex: must never appear in Sam's statistics.
        try f.kicks.createKick(for: other, draft: draft(.fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(20))), day: 1))
    }

    private var sam: StatisticsFilter { StatisticsFilter(athleteID: athlete.id) }

    @Test func countsUseThePredicate() throws {
        #expect(try statistics.totalKickCount(sam) == 5)
        #expect(try statistics.kickCountsByType(sam).map(\.count) == [3, 0, 1, 1])
        let byContext = try statistics.kickCountsByContext(sam)
        #expect(byContext.first { $0.context == .game }?.count == 2)      // from the session type
        #expect(byContext.first { $0.context == .training }?.count == 2)
        #expect(byContext.first { $0.context == .warmup }?.count == 1)
        #expect(try statistics.totalKickCount(StatisticsFilter(athleteID: other.id)) == 1)
    }

    @Test func dateRangeIsInclusive() throws {
        let range = t0.addingTimeInterval(86_400)...t0.addingTimeInterval(3 * 86_400)
        #expect(try statistics.kickCount(in: range, sam) == 3)
    }

    @Test func recentKicksAreNewestFirstAndLimited() throws {
        let recent = try statistics.recentKicks(limit: 2, sam)
        #expect(recent.map(\.kickType) == [.punt, .kickoff])
        #expect(recent.allSatisfy { $0.athleteID == athlete.id })
    }

    @Test func sessionKickCount() throws {
        #expect(try statistics.sessionKickCount(sessionID: session.id) == 2)
        #expect(try statistics.sessionKickCount(sessionID: UUID()) == 0)
    }

    @Test func perTypeStatisticsMatchStoredValuesAndProvenance() throws {
        let fg = try statistics.fieldGoalStatistics(sam)
        #expect(fg.kickCount == 3)
        #expect(fg.makeRate == RateStatistic(attempts: 2, successes: 1))
        #expect(fg.results.unknown == 1)
        #expect(fg.byDistance.first { $0.bucket == .fiftyPlus }?.makeRate == RateStatistic(attempts: 1, successes: 0))

        let ko = try statistics.kickoffStatistics(sam)
        #expect(ko.touchbackRate == RateStatistic(attempts: 1, successes: 1))
        #expect(ko.distance.average == 65.5)
        #expect(ko.distance.sources == [SourceCount(source: .primaryVideo, count: 1)])
        #expect(try statistics.kickoffStatistics(StatisticsFilter(athleteID: athlete.id, measurementSource: .manualOnly)).distance == .empty)

        #expect(try statistics.puntStatistics(sam).distance.average == 44)
    }

    @Test func swiftDataAndInMemorySourcesAgree() throws {
        let kicks = try f.context.fetch(FetchDescriptor<Kick>())
        let reference = StatisticsService(source: InMemoryKickStatisticsSource(kicks.map(KickStatRecord.init(kick:))))
        #expect(try statistics.fieldGoalStatistics(sam) == reference.fieldGoalStatistics(sam))
        #expect(try statistics.kickoffStatistics(sam) == reference.kickoffStatistics(sam))
        #expect(try statistics.kickCountsByContext(sam) == reference.kickCountsByContext(sam))
    }
}
