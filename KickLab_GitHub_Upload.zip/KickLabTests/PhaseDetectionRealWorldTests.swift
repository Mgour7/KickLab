import Foundation
import Testing
@testable import KickLab

/// Step 12B: regression tests for the real-device failure pattern (30 fps side view,
/// kicker tracked in every frame, yet plant and follow-through unavailable).
@Suite("Step 12B real-world phase detection")
struct PhaseDetectionRealWorldTests {
    typealias Script = SyntheticPose.KickScript

    private func detect(_ timeline: KickerPoseTimeline, repair: Bool = true, foot: KickingFoot = .right)
        -> (signals: PoseSignalSet, phases: KickPhaseDetectionResult, repair: PoseRepairReport) {
        let config = PoseProcessingConfiguration(repairsLegLabels: repair)
        let (processed, report) = PoseTimelineProcessor.processWithReport(timeline, configuration: config)
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: foot)
        return (signals, KickPhaseDetector.detect(signals, kickType: .fieldGoal), report)
    }

    private func index(_ signals: PoseSignalSet, _ t: Double?) -> Int? {
        guard let t else { return nil }
        return signals.timestamps.firstIndex { abs($0 - t) < 1e-6 }
    }

    private var real: Script { Script.realWorld30fps }

    // MARK: Leg repair

    @Test func cleanKicksAreNeverRepaired() {
        var leftward = Script.fieldGoal
        leftward.startX = 0.7
        leftward.direction = -1
        var leftFooted = Script.fieldGoal
        leftFooted.kickingFoot = .left
        var noisy = Script.realWorld30fps
        noisy.noise = 0.012
        var slowMotion = Script.fieldGoal
        slowMotion.frameRate = 240
        for script in [Script.fieldGoal, Script.kickoff, real, leftward, leftFooted, noisy, slowMotion] {
            let (_, report) = PoseTimelineProcessor.processWithReport(SyntheticPose.timeline(script))
            #expect(!report.changedAnything, "no repair on a clean kick: \(report)")
        }
    }

    @Test func swappedLegLabelsAreSwappedBack() {
        let s = real
        let clean = PoseTimelineProcessor.process(SyntheticPose.timeline(s))
        for times in [[2.433], [2.367, 2.4]] {
            var t = SyntheticPose.timeline(s)
            let swapped = times.map { SyntheticPose.sampleTime(s, near: $0) }
            SyntheticPose.swapLegs(&t, at: swapped)
            let (processed, report) = PoseTimelineProcessor.processWithReport(t)
            let expected = swapped.compactMap { time in t.samples.firstIndex { abs($0.timestamp - time) < 1e-6 } }
            #expect(report.legSwapSamples == expected)
            #expect(report.outlierPoints == 0)
            #expect(processed == clean, "identical to the unswapped kick")
        }
    }

    @Test func aCollapsedAnkleIsRejectedAndRefilledAsInterpolated() {
        let s = real
        var t = SyntheticPose.timeline(s)
        let times = [2.367, 2.4].map { SyntheticPose.sampleTime(s, near: $0) }
        SyntheticPose.collapseLegs(&t, onto: .right, at: times)
        let (processed, report) = PoseTimelineProcessor.processWithReport(t)
        let indices = times.compactMap { time in t.samples.firstIndex { abs($0.timestamp - time) < 1e-6 } }
        #expect(report.outlierSamples == indices)
        #expect(report.outlierPoints == 2, "the left ankle, two frames (the knees are closer together than a jump)")
        for i in indices {
            #expect(processed.samples[i].joints[.leftAnkle]?.status == .interpolated, "refilled, and marked as such")
            #expect(processed.samples[i].joints[.rightAnkle]?.status == .measured, "the real ankle is kept")
        }
    }

    @Test func repairIsOffForFilesWrittenBeforeStep12B() throws {
        let old = #"{"minimumJointConfidence":0.3,"maximumInterpolationGapSeconds":0.1,"smoothingRadius":1}"#
        let decoded = try JSONDecoder().decode(PoseProcessingConfiguration.self, from: Data(old.utf8))
        #expect(decoded.repairsLegLabels == false, "stored analyses keep their meaning")
        let current = PoseProcessingConfiguration.standard
        #expect(current.repairsLegLabels)
        let roundTrip = try JSONDecoder().decode(PoseProcessingConfiguration.self, from: JSONEncoder().encode(current))
        #expect(roundTrip == current)
    }

    // MARK: The real-device pattern

    @Test func aLegSwapAtContactIsHandledByRepairAndByTheContactEstimator() {
        // Step 12B reproduced the real failure with a one-frame swap and fixed it with leg
        // repair. Step 12C's contact estimator is a second, independent safeguard: even
        // with repair OFF, the swap's false late peak is ranked below the real strike.
        let s = real
        var t = SyntheticPose.timeline(s)
        SyntheticPose.swapLegs(&t, at: [SyntheticPose.sampleTime(s, near: 2.433)])
        let unrepaired = detect(t, repair: false)
        let candidates = unrepaired.phases.evidence?.contactCandidates ?? []
        let fastest = candidates.max { $0.peakSpeed < $1.peakSpeed }
        #expect(fastest?.selected == false, "the swap's speed spike is the fastest motion, and is not chosen")
        #expect((fastest?.time ?? 0) - s.expectedContact > 0.08, "it is a false, late peak")
        #expect(abs((unrepaired.phases.estimatedContactTime ?? 0) - s.expectedContact) <= 1 / s.frameRate + 1e-9)
        #expect(unrepaired.phases.phase(.followThrough).status == .detected)
        #expect(unrepaired.phases.notes.contains { $0.contains("fastest foot motion") }, "the conflict is exposed")

        let fixed = detect(t)
        #expect(fixed.repair.legSwapSamples.count == 1)
        for phase in KickPhase.allCases { #expect(fixed.phases.phase(phase).isAvailable, "\(phase)") }
        #expect(fixed.phases.phase(.plant).status == .detected)
        #expect(fixed.phases.phase(.followThrough).status == .detected)
        #expect(abs((fixed.phases.estimatedContactTime ?? 0) - s.expectedContact) <= 1 / s.frameRate + 1e-9)
    }

    @Test func aPlantFootRollingAtContactIsStillAPlant() {
        let s = real
        let (signals, phases, _) = detect(SyntheticPose.timeline(s))
        let peak = index(signals, phases.estimatedContactTime)
        let atContact = peak.flatMap { signals.values(.plantAnkleSpeed)[$0] } ?? 0
        #expect(atContact > KickPhaseProfile.placeKick.plantStillSpeedThreshold,
                "the Step 7 rule (one sample at the speed peak must be still) would have rejected this plant")
        #expect(phases.phase(.plant).status == .detected)
        #expect(abs((phases.plantTime ?? 0) - s.plantTime) <= 2 / s.frameRate + 1e-9)
        #expect(phases.evidence?.plantStillThroughContact == true, "within the tolerance before the anchor")
        #expect(phases.phase(.approach).status == .detected)
        #expect(phases.phase(.setup).isAvailable)
    }

    @Test func anUnstablePlantIsReportedAsAnEstimatedPlantNotAMissingOne() {
        var s = real
        s.plantLiftLead = 0.06
        s.plantLiftAtContact = 0.04
        let (_, phases, _) = detect(SyntheticPose.timeline(s))
        let plant = phases.phase(.plant)
        #expect(plant.status == .estimated)
        #expect(plant.confidence < 0.5, "weak evidence, low confidence")
        #expect(abs((phases.plantTime ?? 0) - s.plantTime) <= 2 / s.frameRate + 1e-9)
        #expect(phases.evidence?.plantStillThroughContact == false)
        #expect(phases.notes.contains { $0.contains("unstable plant") })

        // Plant-foot drift then measures the instability instead of hiding it.
        let unstable = SyntheticBiomechanics.analyze(s)
        let steady = SyntheticBiomechanics.analyze(real)
        let drift = unstable.measurements.first { $0.key == .plantFootDrift }
        let steadyDrift = steady.measurements.first { $0.key == .plantFootDrift }
        #expect(drift?.isAvailable == true)
        let driftValue: Double = drift?.value ?? 0
        let steadyValue: Double = steadyDrift?.value ?? 0
        let driftConfidence: Double = drift?.confidence ?? 1
        let steadyConfidence: Double = steadyDrift?.confidence ?? 0
        #expect(driftValue > steadyValue)
        #expect(driftConfidence < steadyConfidence, "estimated plant lowers confidence")
    }

    @Test func aPlantThatNeverHappenedIsNotInvented() {
        var s = real
        s.plantLiftAtContact = 0
        s.plantTime = s.expectedContact + 0.2   // the plant foot is still stepping at contact
        let (_, phases, _) = detect(SyntheticPose.timeline(s))
        #expect(phases.phase(.plant).status == .unavailable)
        #expect(phases.plantTime == nil)
        #expect(phases.evidence?.plantTouchdownTime == nil)
        #expect(phases.notes.contains { $0.contains("never came to rest") })
        #expect(phases.phase(.followThrough).status == .detected, "follow-through doesn't depend on the plant")
        #expect(phases.phase(.contact).isAvailable)

        let result = SyntheticBiomechanics.analyze(s)
        for key in [KickMetricKey.plantToContactTime, .plantFootDrift] {
            let m = result.measurements.first { $0.key == key }
            #expect(m?.isAvailable == false)
            #expect(m?.unavailableReason == .phaseUnavailable)
            #expect(m?.missingPhase == .plant)
        }
        #expect(result.categories.first { $0.category == .plant }?.score == nil, "no plant score without a plant")
    }

    @Test func jitterRaisesTheStillThresholdOnlyAsFarAsTheCeiling() {
        let clean = detect(SyntheticPose.timeline(real)).phases.evidence
        #expect(clean?.plantStillThreshold == KickPhaseProfile.placeKick.plantStillSpeedThreshold)
        #expect(clean?.plantNoiseFloor != nil)

        var noisy = real
        noisy.noise = 0.02
        let (_, phases, _) = detect(SyntheticPose.timeline(noisy))
        let threshold = phases.evidence?.plantStillThreshold ?? 0
        #expect(threshold > KickPhaseProfile.placeKick.plantStillSpeedThreshold)
        #expect(threshold <= KickPhaseDetector.plantStillSpeedCeiling)
        #expect(phases.notes.contains { $0.contains("Pose jitter") })
        #expect(phases.phase(.plant).isAvailable)
    }

    @Test func aStillFootWithoutAStepIsNotMistakenForStillness() {
        // A plant foot still stepping through contact, under heavy jitter, is never
        // reported as a confident plant. (Step 12D: the earlier version of this scenario
        // used a foot that did come to rest when the body stopped, so a plant there is real.)
        var s = Script.realWorld30fps
        s.plantLiftAtContact = 0
        s.plantTime = s.expectedContact + 0.2
        s.noise = 0.02
        let (_, phases, _) = detect(SyntheticPose.timeline(s))
        #expect(phases.phase(.plant).status != .detected)
        #expect(phases.evidence?.plantState != .touchdownDetected)
    }

    // MARK: Follow-through

    /// Hand-built signals: 30 fps, a kicking-ankle speed curve, plant foot still.
    private func signals(kicking: [Double]) -> PoseSignalSet {
        let times = kicking.indices.map { Double($0) / 30 }
        return PoseSignalSet(
            timestamps: times,
            series: [
                .kickingAnkleSpeed: kicking.map { Optional($0) },
                .plantAnkleSpeed: kicking.map { _ in Optional(0.1) },
                .bodyCenterSpeed: kicking.map { _ in Optional(0.1) },
            ],
            bodyScale: 0.15, travelDirection: 1
        )
    }

    @Test func aSingleSlowSampleDoesNotEndTheFollowThrough() {
        //                 0    1    2    3    4     5    6    7    8    9    10   11   12   13
        let speed: [Double] = [0, 0, 1, 4, 10, 1.5, 8, 6, 4, 2, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]
        let phases = KickPhaseDetector.detect(signals(kicking: speed), kickType: .fieldGoal)
        let follow = phases.phase(.followThrough)
        #expect(follow.status == .detected)
        let end: Double = follow.endTime ?? 0
        let seconds: Double = phases.evidence?.followThroughSeconds ?? 0
        let expectedEnd: Double = 9.0 / 30
        let expectedSeconds: Double = 5.0 / 30
        #expect(abs(end - expectedEnd) < 1e-9, "ends where the slow-down is sustained, not at the dip")
        #expect(abs(seconds - expectedSeconds) < 1e-9)
    }

    @Test func aFollowThroughThatEndsTooSoonIsExplained() {
        let speed: [Double] = [0, 0, 1, 4, 10, 2, 0.5, 0.2, 0.1, 0.1, 0.1, 0.1]
        let phases = KickPhaseDetector.detect(signals(kicking: speed), kickType: .fieldGoal)
        #expect(phases.phase(.followThrough).status == .unavailable)
        #expect(phases.notes.contains { $0.contains("too soon for a follow-through") })
        #expect(phases.phase(.contact).isAvailable, "contact is still estimated")
    }

    // MARK: Contact

    @Test func contactEvidenceIsRecorded() throws {
        let s = real
        let (_, phases, _) = detect(SyntheticPose.timeline(s))
        let e = try #require(phases.evidence)
        #expect(e.contactPeakTime == phases.estimatedContactTime)
        let refined: Double = e.refinedContactTime ?? 0
        let peakTime: Double = e.contactPeakTime ?? 0
        let halfFrame: Double = 0.5 / s.frameRate + 1e-9
        #expect(abs(refined - peakTime) <= halfFrame)
        let pass = e.anklePassTime ?? 0
        #expect(pass > s.swingStart && pass < s.expectedContact, "the kicking foot passes the plant foot during the swing")
        #expect(abs(e.contactCueOffset ?? 1) < KickPhaseDetector.contactCueToleranceSeconds)
        #expect(!phases.notes.contains { $0.contains("passes the plant foot") })
    }

    @Test func aSpeedPeakFarFromTheFootPassingIsFlaggedAsUncertain() {
        // The foot passes the plant foot at ≈0.15 s; the speed peaks at sample 15 (0.5 s).
        let n = 22
        let speed: [Double] = (0..<n).map { i in i == 15 ? 10 : (i == 14 || i == 16 ? 6 : (i > 16 ? 0.2 : 1)) }
        var set = signals(kicking: speed)
        set.series[.kickingAnkleAheadOfPlant] = (0..<n).map { Optional(Double($0) - 4.5) }
        let flagged = KickPhaseDetector.detect(set, kickType: .fieldGoal)
        #expect(flagged.notes.contains { $0.contains("passes the plant foot") })
        set.series[.kickingAnkleAheadOfPlant] = (0..<n).map { Optional(Double($0) - 14.5) }
        let agreeing = KickPhaseDetector.detect(set, kickType: .fieldGoal)
        #expect(flagged.phase(.contact).confidence < agreeing.phase(.contact).confidence)
        #expect(flagged.phase(.contact).status == .estimated, "still an estimate, never fabricated as measured")
    }

    @Test func detectorHelpers() {
        // Parabolic peak: symmetric → on the sample; skewed → toward the larger neighbor.
        let t = [0.0, 0.1, 0.2]
        #expect(KickPhaseDetector.refinedPeakTime([1, 2, 1], t, 1) == 0.1)
        #expect(KickPhaseDetector.refinedPeakTime([1, 2, 1.5], t, 1) > 0.1)
        #expect(KickPhaseDetector.refinedPeakTime([nil, 2, 1], t, 1) == 0.1)
        // Ankle pass: linear interpolation of the zero crossing.
        let pass = KickPhaseDetector.anklePassTime([-1, -0.5, 0.5, 1], [0, 0.1, 0.2, 0.3], near: 0.2)
        #expect(abs((pass ?? 0) - 0.15) < 1e-9)
        #expect(KickPhaseDetector.anklePassTime([1, 1, 1], [0, 0.1, 0.2], near: 0.1) == nil)
        // Median filter: removes a two-sample burst, keeps a step, keeps gaps.
        let filtered = KickPhaseDetector.medianFilter([0, 0, 5, 5, 0, 0, 0], radius: 2)
        #expect(filtered.compactMap { $0 }.allSatisfy { $0 == 0 })
        let step = KickPhaseDetector.medianFilter([3, 3, 3, 0, 0, 0], radius: 2)
        let stepValues: [Double] = step.map { $0 ?? -1 }
        let expectedStep: [Double] = [3, 3, 3, 0, 0, 0]
        #expect(stepValues == expectedStep)
        #expect(KickPhaseDetector.medianFilter([1, nil, 1], radius: 2)[1] == nil)
        #expect(KickPhaseDetector.framesPerSecond([0, 0.5, 1]) == 2)
    }

    // MARK: Contact validation harness

    @Test func contactEstimatesAgreeWithAnnotatedContactAcrossFrameRatesFeetAndDirections() {
        var checks: [ContactTimingCheck] = []
        for fps in [30.0, 60, 120, 240] {
            for foot in [KickingFoot.right, .left] {
                for direction in [1.0, -1.0] {
                    var s = real
                    s.frameRate = fps
                    // The app analyzes at most 60 frames per second (FrameSamplingPlan.standard).
                    // Independent per-frame jitter at 120–240 fps would be unrealistically
                    // fast noise, so those rates are checked without jitter.
                    if fps > 60 { s.noise = 0 }
                    s.kickingFoot = foot
                    s.direction = direction
                    if direction < 0 { s.startX = 0.88 }
                    let (_, phases, _) = detect(SyntheticPose.timeline(s), foot: foot)
                    checks.append(ContactTimingCheck(referenceTime: s.expectedContact,
                                                     estimatedTime: phases.estimatedContactTime, framesPerSecond: fps))
                }
            }
        }
        let summary = ContactTimingSummary(checks)
        #expect(summary.count == 16)
        #expect(summary.missing == 0)
        #expect(summary.withinToleranceFraction == 1, "\(checks.enumerated().filter { !$0.element.withinTolerance }.map { "\($0.offset): \($0.element)" })")
        #expect((summary.maximumAbsoluteError ?? 1) <= ContactTimingCheck.toleranceSeconds + 1e-9)
        let meanError: Double = summary.meanAbsoluteError ?? 1
        let halfFrameAt30: Double = 0.5 / 30
        #expect(meanError <= halfFrameAt30, "half a 30 fps frame on average")
    }

    @Test func theHarnessReportsDisagreementInsteadOfHidingIt() {
        let late = ContactTimingCheck(referenceTime: 2.25, estimatedTime: 2.367, framesPerSecond: 30)
        #expect(!late.withinTolerance)
        #expect(late.errorSeconds == 0.117)
        #expect(late.errorFrames == 3.51)
        let missing = ContactTimingCheck(referenceTime: 2.25, estimatedTime: nil, framesPerSecond: 30)
        #expect(!missing.withinTolerance)
        #expect(missing.errorSeconds == nil)
        let summary = ContactTimingSummary([late, missing, ContactTimingCheck(referenceTime: 1, estimatedTime: 1.02, framesPerSecond: 30)])
        #expect(summary.missing == 1)
        #expect(abs(summary.withinToleranceFraction - 1.0 / 3) < 1e-9)
        #expect((summary.bias ?? 0) > 0, "estimates late on average")
    }

    // MARK: End to end

    @Test func theRealWorldPatternIsFullyAnalyzedEndToEnd() {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(real), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side
        ))
        #expect(out.tracking.status == .selected)
        #expect(out.failureCause == nil)
        #expect(!out.repair.changedAnything)
        for phase in KickPhase.allCases { #expect(out.phases.phase(phase).isAvailable, "\(phase)") }
        #expect(out.biomechanics.availableCategoryCount == 4, "Build 22: the approach is measured, not graded")
        #expect(out.biomechanics.overallScore != nil)
    }

    @Test func partialResultsSayWhatWasNotScored() {
        var s = real
        s.plantLiftAtContact = 0
        s.plantTime = s.expectedContact + 0.2
        let result = SyntheticBiomechanics.analyze(s)
        let cards = KickMetricCatalog.scoredCategories.map { category in
            CategoryCardPresentation(category: category, title: category.presentationTitle,
                                     score: result.categories.first { $0.category == category }?.score,
                                     scoreText: "", grade: .unavailable, confidence: nil, confidenceText: "",
                                     summary: nil, topMetrics: [], unavailableMetricNames: [])
        }
        let note = AnalysisPresentationBuilder.partialNote(categories: cards, overallScore: result.overallScore)
        #expect(note?.contains(AnalysisCategory.plant.presentationTitle) == true)
        #expect(note?.contains("not rated good or bad") == (result.overallScore != nil))
        let full = cards.map { var c = $0; c.score = 80; return c }
        #expect(AnalysisPresentationBuilder.partialNote(categories: full, overallScore: 80) == nil)
    }

    // MARK: Diagnostics

    @Test func diagnosticsExportTheTimeSeriesAndReplay() throws {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(real), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side
        ))
        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: out), storedStatus: "completed", storedFailureReason: nil,
            kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0), referenceContactTime: 2.35
        )
        let series = try #require(report.timeSeries)
        #expect(series.source == "replay")
        #expect(series.time.count == out.signals.timestamps.count)
        #expect(series.plantAnkleSpeed.count == series.time.count)
        #expect(series.events.contains { $0.name == "candidate_plant_touchdown" })
        #expect(series.events.contains { $0.name == "candidate_kicking_foot_passes_plant_foot" })
        #expect(series.csv.hasPrefix("time_s,plant_ankle_speed_bl_s,kicking_ankle_speed_bl_s"))
        #expect(series.csv.components(separatedBy: "\n").count > series.time.count)
        let replay = try #require(report.replay)
        #expect(!replay.differsFromStored, "a current analysis replays identically")
        #expect(replay.scoredCategoryCount == out.biomechanics.availableCategoryCount)
        #expect(report.detectionEvidence == out.phases.evidence)
        let check = try #require(report.contactCheck)
        #expect(check.withinTolerance)
        #expect(report.plainText.contains("Replay Diagnostics — current detector on the stored pose (same as stored)"))
        #expect(report.plainText.contains("plant: touchdown"))
        let json = report.json()
        for forbidden in ["\"x\"", "\"y\""] { #expect(!json.contains(forbidden)) }
    }

    @Test func replayShowsWhatTheCurrentDetectorFindsOnAnOlderAnalysis() throws {
        // An analysis stored by an older build: the same pose (with a leg swap, processed
        // without repair), but with plant and follow-through stored as unavailable — as
        // engine 2.1.0 stored the real clip — and no Step 12C evidence.
        let s = real
        var frames = SyntheticPose.frames(s)
        let swapAt = SyntheticPose.sampleTime(s, near: 2.433)
        for i in frames.indices where abs(frames[i].timestamp - swapAt) < 1e-6 {
            var body = frames[i].bodies[0]
            for (a, b) in [(PoseJoint.leftAnkle, PoseJoint.rightAnkle), (.leftKnee, .rightKnee)] {
                let x = body.joints[a]
                body.joints[a] = body.joints[b]
                body.joints[b] = x
            }
            frames[i].bodies[0] = BodyPose(joints: body.joints, trackID: body.trackID)
        }
        var sequence = SyntheticPose.sequence(s)
        sequence.frames = frames
        var input = KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side)
        input.processing = PoseProcessingConfiguration(repairsLegLabels: false)
        var old = KickAnalysisPipeline.run(input)
        let storedPhases = old.phases.phases.map { p -> DetectedKickPhase in
            p.phase == .plant || p.phase == .followThrough ? .unavailable(p.phase) : p
        }
        old.phases = KickPhaseDetectionResult(kickType: .fieldGoal, support: .full, phases: storedPhases,
                                              overallConfidence: 0.4, dataCoverage: 1, notes: ["The plant foot was not still at contact."])
        old.biomechanics = KickBiomechanicsAnalyzer.analyze(
            timeline: old.kickerTimeline, signals: old.signals, phases: old.phases, context: old.biomechanics.context,
            idSeed: SyntheticBiomechanics.seed
        )

        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: old, processing: input.processing), storedStatus: "completed",
            storedFailureReason: nil, kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0)
        )
        #expect(report.detectionEvidence == nil, "older files have no detection evidence")
        let replay = try #require(report.replay)
        #expect(replay.differsFromStored)
        #expect(replay.repair.legSwapSamples.count == 1)
        #expect(replay.phases.allSatisfy { $0.status != .unavailable })
        #expect(replay.scoredCategoryCount > (report.scoredCategoryCount ?? 0))
        #expect(report.contributingFactors.contains { $0.hasPrefix("Leg repair:") })
        #expect(report.contributingFactors.contains { $0.contains("current detector finds different phases") })
        #expect(report.timeSeries?.legSwapRepaired.contains(true) == true)
    }

    @Test func phaseFilesWrittenBeforeStep12BStillDecode() throws {
        let phases = detect(SyntheticPose.timeline(real)).phases
        let data = try JSONEncoder().encode(phases)
        var object = try #require(try JSONSerialization.jsonObject(with: data) as? [String: Any])
        object.removeValue(forKey: "evidence")
        let old = try JSONDecoder().decode(KickPhaseDetectionResult.self, from: JSONSerialization.data(withJSONObject: object))
        #expect(old.evidence == nil)
        #expect(old.phases == phases.phases)
    }
}
