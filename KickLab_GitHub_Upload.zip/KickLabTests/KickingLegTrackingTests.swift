import Foundation
import Testing
@testable import KickLab

/// Step 12E: when is the kicking leg "not tracked" after contact, and what can still be
/// measured. (Started for the side-view follow-through investigation; side views only.)
@Suite("Kicking-leg tracking after contact")
struct KickingLegTrackingTests {
    typealias Script = SyntheticPose.KickScript

    private func detect(_ timeline: KickerPoseTimeline) -> (PoseSignalSet, KickPhaseDetectionResult) {
        let signals = PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(timeline), kickingFoot: .right)
        return (signals, KickPhaseDetector.detect(signals, kickType: .fieldGoal))
    }

    @Test func aFootRisingStraightUpBesideThePlantFootIsNotMerged() {
        // After contact the kicking ankle stays level with the plant ankle ALONG the run but
        // rises above it: the old along-travel rule called that "merged".
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        let c = s.expectedContact
        for i in t.samples.indices where t.samples[i].timestamp > c + 1e-9 && t.samples[i].timestamp <= c + 0.45 {
            guard let plant = t.samples[i].joints[.leftAnkle] else { continue }
            let rise = 0.8 * (t.samples[i].timestamp - c)
            t.samples[i].joints[.rightAnkle] = PosePoint(x: plant.x, y: plant.y - rise, confidence: 0.9)
        }
        let (signals, phases) = detect(t)
        #expect(KickPhaseDetector.kickingAnkleMerged(signals.values(.kickingAnkleAheadOfPlant), signals.timestamps, after: phases.estimatedContactTime ?? c),
                "the Step 12D rule would have called this merged")
        #expect(phases.evidence?.kickingAnkleTrackingRule == "separation2D")
        #expect(phases.evidence?.kickingAnkleMergedAfterContact == false)
    }

    @Test func onlyTheAnkleLostKeepsKneeAndHipMeasurements() {
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        for i in t.samples.indices where t.samples[i].timestamp >= s.expectedContact + 0.04 - 1e-9 {
            t.samples[i].joints[.rightAnkle] = t.samples[i].joints[.leftAnkle]
        }
        let (_, phases) = detect(t)
        #expect(phases.evidence?.kickingAnkleMergedAfterContact == true)
        #expect(phases.evidence?.kickingAnkleTrackingRule == "separation2D")
        let r = SyntheticBiomechanics.analyze(s, timeline: t)
        // Shoulder–hip–knee needs no ankle.
        #expect(r.measurement(.kickingHipAngleAtContact)?.unavailableReason != .kickingLegNotTracked)
        // The foot's height after contact needs the ankle: never taken from a merged label.
        #expect(r.measurement(.followThroughFootHeight)?.isAvailable == false)
        if phases.evidence?.followThroughBasis == "kickingKnee" {
            #expect(phases.phase(.followThrough).status == .estimated)
            #expect(r.measurement(.followThroughFootHeight)?.unavailableReason == .kickingLegNotTracked)
        }
    }

    @Test func bothKickingLegJointsLostLeaveTheFollowThroughUnavailable() {
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        SyntheticPose.kickingFootLost(&t, from: s.expectedContact + 0.04)
        let (_, phases) = detect(t)
        #expect(phases.evidence?.kickingAnkleMergedAfterContact == true)
        #expect(phases.phase(.followThrough).status == .unavailable, "the knee sits on the plant knee too: nothing to time it from")
    }

    @Test func contactIntervalNeverStartsBeforeThePlant() {
        let phases = KickPhaseDetector.detect(RealReferenceClip220.signals, kickType: .fieldGoal)
        let e = phases.evidence
        #expect(e?.contactTimingMethod == "plantAndFootPassing")
        // Timed from the plant landing: the earliest possible contact is the estimate itself.
        #expect(e?.contactEarliestTime == phases.estimatedContactTime.map(ContactEstimator.round3))
        #expect((e?.contactLatestTime ?? 0) > (phases.estimatedContactTime ?? 9))
        #expect((e?.contactEarliestTime ?? 0) >= (phases.plantTime ?? 9))
    }

    @Test func aConstraintTimedContactIsNotAMeasuredStrike() {
        let r = SyntheticBiomechanics.analyze(Script.realWorld30fps)
        if r.measurement(.footSpeedAtContact)?.isAvailable == false {
            #expect([MetricUnavailableReason.contactNotMeasured, .kickingLegNotTracked].contains(r.measurement(.footSpeedAtContact)?.unavailableReason ?? .noKicker))
        }
    }
}
