import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("KickingSessionService")
struct KickingSessionServiceTests {
    let f: ServiceFixture

    init() throws {
        f = try ServiceFixture()
    }

    @Test func createsValidSession() throws {
        let athlete = try f.makeAthlete()
        let date = Date(timeIntervalSince1970: 1_790_000_000)
        let session = try f.sessions.createSession(
            for: athlete, name: "  Tuesday practice ", date: date, sessionType: .camp, location: " ", notes: "Windy"
        )

        #expect(session.name == "Tuesday practice")
        #expect(session.date == date)
        #expect(session.sessionType == .camp)
        #expect(session.location == nil)
        #expect(session.notes == "Windy")
        #expect(session.athlete?.id == athlete.id)
        #expect(!f.context.hasChanges)
    }

    @Test func emptyNameIsRejected() throws {
        let athlete = try f.makeAthlete()
        #expect(throws: KickingSessionServiceError.invalidEdit([.emptyName])) {
            try f.sessions.createSession(for: athlete, name: "   ")
        }
        #expect(try f.count(KickingSession.self) == 0)
    }

    @Test func updateSessionEditsFields() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        session.updatedAt = .distantPast

        try f.sessions.updateSession(session, with: KickingSessionEdit(name: "Game day", sessionType: .game, location: "Home"))

        #expect(session.name == "Game day")
        #expect(session.sessionType == .game)
        #expect(session.location == "Home")
        #expect(session.updatedAt > .distantPast)
    }

    @Test func deletingSessionPreservesKicksAndLeavesThemUnassigned() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        let k1 = try f.makeKick(for: athlete, in: session)
        let k2 = try f.makeKick(for: athlete, in: session)

        let summary = f.sessions.deletionSummary(for: session)
        #expect(summary.kickCount == 2)
        #expect(summary.confirmationMessage == "2 kicks will be kept as unassigned.")

        try f.sessions.deleteSession(session)

        #expect(try f.count(KickingSession.self) == 0)
        #expect(try f.count(Kick.self) == 2)
        #expect(k1.session == nil)
        #expect(k2.session == nil)
        #expect(k1.athlete?.id == athlete.id)
    }

    @Test func changingSessionTypeDoesNotRewriteKickContext() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete, type: .training)
        let kick = try f.makeKick(for: athlete, in: session)
        #expect(kick.context == .training)

        try f.sessions.updateSession(session, with: KickingSessionEdit(name: session.name, date: session.date, sessionType: .game))

        #expect(session.sessionType == .game)
        #expect(kick.context == .training)
    }

    @Test func assignDelegatesToKickServiceRules() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let sessionOfA = try f.makeSession(for: a)
        let sessionOfB = try f.makeSession(for: b)
        let kick = try f.makeKick(for: a)

        try f.sessions.assign(kick, to: sessionOfA)
        #expect(kick.session?.id == sessionOfA.id)

        #expect(throws: KickServiceError.sessionBelongsToDifferentAthlete(sessionID: sessionOfB.id, sessionAthleteID: b.id, athleteID: a.id)) {
            try f.sessions.assign(kick, to: sessionOfB)
        }
        #expect(kick.session?.id == sessionOfA.id)
    }
}
