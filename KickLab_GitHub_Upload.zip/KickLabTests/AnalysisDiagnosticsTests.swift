import Foundation
import Testing
@testable import KickLab

/// Step 12A: why an analysis fails, reported precisely. Synthetic pose only (no Vision).
@Suite("Step 12A analysis diagnostics")
struct AnalysisDiagnosticsTests {
    typealias Script = SyntheticPose.KickScript

    private func run(_ sequence: PoseSequence, camera: VideoAngleType = .side, seed: KickerSeed? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                           kickerSeed: seed, cameraAngle: camera))
    }

    private func report(_ output: KickAnalysisPipelineOutput, reason: String? = nil) -> AnalysisDiagnosticsReport {
        AnalysisDiagnosticsBuilder.build(AnalysisDiagnosticsInput(output: output, sampling: .standard), storedStatus: "failed",
                                         storedFailureReason: reason, kickingFoot: .right, appVersion: "0.1.0 (7)",
                                         generatedAt: Date(timeIntervalSince1970: 1_800_000_000))
    }

    /// Removes joints from every body (as if Vision never reported them).
    private func without(_ joints: [PoseJoint], in sequence: PoseSequence) -> PoseSequence {
        var s = sequence
        s.frames = s.frames.map { frame in
            var f = frame
            f.bodies = f.bodies.map { body in
                var j = body.joints
                for joint in joints { j[joint] = .unavailable }
                return BodyPose(joints: j)
            }
            return f
        }
        return s
    }

    private func script(confidence: Double = 0.9) -> Script {
        var s = Script.fieldGoal
        s.confidence = confidence
        return s
    }

    // MARK: Detection failures

    @Test func noPersonDetected() {
        var empty = SyntheticPose.sequence(.fieldGoal)
        empty.frames = empty.frames.map { var f = $0; f.bodies = []; return f }
        let out = run(empty)
        #expect(out.tracking.status == .noCandidates)
        #expect(out.failureCause == nil, "kicker selection problems keep their own messages")
        let r = report(out)
        #expect(r.framesSampled == empty.frames.count)
        #expect(r.framesWithPerson == 0)
        #expect(r.framesWithKicker == 0)
        #expect(r.kickerStatus == .noCandidates)
        #expect(r.contributingFactors.contains("Kicker selection: noCandidates."))
        #expect(AnalysisProblem.from(kickerStatus: .noCandidates, failureReason: "x") == .noKickerFound)
    }

    @Test func visionFailuresAreCounted() {
        var seq = SyntheticPose.sequence(.fieldGoal)
        for i in stride(from: 0, to: seq.frames.count, by: 10) {
            seq.frames[i].status = .failed
            seq.frames[i].bodies = []
        }
        let r = report(run(seq))
        #expect(r.framesVisionFailed == (seq.frames.count + 9) / 10)
        let failed: Int = r.framesVisionFailed ?? 0
        let expectedWithPerson: Int = seq.frames.count - failed
        #expect(r.framesWithPerson == expectedWithPerson)
    }

    @Test func legsNeverDetectedSaysLegsNotVisible() {
        let out = run(without([.leftKnee, .rightKnee, .leftAnkle, .rightAnkle], in: SyntheticPose.sequence(.fieldGoal)))
        #expect(out.tracking.status == .selected)
        #expect(out.biomechanics.availableCategoryCount == 0)
        #expect(out.failureCause == .legJointsNotVisible)
        let r = report(out)
        let ankle = r.joints.first { $0.joint == .rightAnkle }
        #expect(ankle?.role == "kicking")
        #expect(ankle?.detectedFrames == 0)
        #expect(r.joints.first { $0.joint == .leftAnkle }?.role == "plant")
        #expect(r.joints.first { $0.joint == .rightHip }?.detectedFrames == r.framesWithKicker, "hips were seen in every tracked frame")
        #expect(AnalysisProblem.from(.legJointsNotVisible) == .notEnoughPoseData, "the old message is right only here")
    }

    // MARK: Missing phases

    @Test func noKickMeansPhasesNotFound() {
        var s = Script.fieldGoal
        s.swingDistance = 0
        let out = run(SyntheticPose.sequence(s))
        #expect(out.failureCause == .kickPhasesNotFound)
        let r = report(out)
        #expect(r.phases.first { $0.phase == .contact }?.status == .unavailable)
        #expect(r.evidence?.missingPhases.contains(.contact) == true)
        #expect(r.metrics.filter { !$0.available }.allSatisfy { $0.unavailableReason == "phaseUnavailable" || !$0.scored })
        #expect(r.contributingFactors.contains { $0.hasPrefix("Phases not found:") })
        #expect(AnalysisProblem.from(.kickPhasesNotFound) == .kickPhasesNotFound)
    }

    @Test func kickerOnlySeenLateMeansTrackTooShort() {
        var seq = SyntheticPose.sequence(.fieldGoal)
        seq.frames = seq.frames.map { var f = $0; if f.timestamp < 1.3 { f.bodies = [] }; return f }
        let out = run(seq)
        #expect(out.failureCause == .kickerTrackTooShort)
        let r = report(out)
        #expect((r.kickerTrackedFraction ?? 1) < AnalysisDiagnosis.minimumTrackedFraction)
        #expect(AnalysisProblem.from(.kickerTrackTooShort).suggestsKickerSelection)
    }

    // MARK: Insufficient confidence

    @Test func rearCameraPenaltyIsIdentifiedNotHidden() throws {
        let out = run(SyntheticPose.sequence(script(confidence: 0.55)), camera: .rear)
        #expect(out.biomechanics.availableCategoryCount == 0)
        #expect(out.failureCause == .cameraAngleLimited)
        let r = report(out)
        #expect(r.cameraAngle == .rear)
        #expect(r.evidence?.cameraFactor == 0.5)
        let evidence = try #require(r.evidence)
        #expect(evidence.rescuedWithoutCameraPenalty * 2 >= evidence.blockedByConfidence)
        #expect(r.metrics.contains { $0.limitedByCameraAngle })
        #expect(r.contributingFactors.contains { $0.contains("Camera angle 'rear'") })
        // The same video from the side scores: nothing else was wrong with it.
        #expect(run(SyntheticPose.sequence(script(confidence: 0.55)), camera: .side).biomechanics.availableCategoryCount > 0)
    }

    @Test func lowVisionConfidenceFromTheSideIsLowPoseConfidence() {
        let out = run(SyntheticPose.sequence(script(confidence: 0.32)), camera: .side)
        #expect(out.biomechanics.availableCategoryCount == 0)
        #expect(out.failureCause == .lowPoseConfidence, "the camera angle isn't to blame for a side view")
        let r = report(out)
        #expect(r.metrics.allSatisfy { !$0.limitedByCameraAngle })
        #expect(r.contributingFactors.contains { $0.hasPrefix("Mean Vision confidence of knees and ankles: 0.32") })
    }

    @Test func thirtyFramesPerSecondIsReportedAsAFactor() {
        var s = Script.fieldGoal
        s.frameRate = 30
        let r = report(run(SyntheticPose.sequence(s)))
        #expect(near(r.measuredAnalysisFrameRate, 30, 0.01))
        #expect(r.contributingFactors.contains { $0.hasPrefix("Analysis frame rate 30 fps") })
        #expect(r.metrics.first { $0.key == KickMetricKey.kickingKneeAngleAtContact.rawValue }?.frameRateFactor == 0.7)
    }

    @Test func cameraPenaltyAppliesToGeometryNotTimings() {
        let out = run(SyntheticPose.sequence(.fieldGoal), camera: .rear)
        let m = out.biomechanics.measurements
        #expect(m.first { $0.key == .plantToContactTime }?.confidenceInputs?.cameraFactor == 1)
        #expect(m.first { $0.key == .followThroughDuration }?.confidenceInputs?.cameraFactor == 1)
        #expect(m.first { $0.key == .kickingKneeAngleAtContact }?.confidenceInputs?.cameraFactor == 0.5)
        #expect(m.first { $0.key == .plantFootDrift }?.confidenceInputs?.cameraFactor == 0.5)
    }

    // MARK: Partial analysis

    @Test func clipEndingAtContactIsAPartialAnalysisNotAFailure() {
        var s = Script.fieldGoal
        s.duration = 1.45   // ends just after contact: no follow-through
        let out = run(SyntheticPose.sequence(s))
        #expect(out.phases.phase(.followThrough).status == .unavailable)
        #expect(out.biomechanics.availableCategoryCount >= 3)
        #expect(out.failureCause == nil, "something was scored, so it isn't a failure")
        let r = report(out, reason: nil)
        #expect(r.categories.first { $0.category == .followThrough }?.score == nil)
        #expect(r.categories.first { $0.category == .plant }?.score != nil)
        #expect(r.metrics.first { $0.key == KickMetricKey.followThroughDuration.rawValue }?.missingPhase == .followThrough)
    }

    @Test func notEnoughOfAnyPhaseIsItsOwnCause() {
        let evidence = AnalysisFailureEvidence(
            scoredMetricCount: 16, availableScoredMetrics: 3, blockedByMissingPhase: 0, blockedByMissingJoints: 0,
            blockedByConfidence: 0, rescuedWithoutCameraPenalty: 0, otherUnavailable: 13, kickerTrackedFraction: 1,
            missingPhases: [], cameraFactor: 1, kickingAnkleCoverage: 1
        )
        #expect(AnalysisDiagnosis.cause(evidence, scoredCategoryCount: 0) == .notEnoughScoredMetrics)
        #expect(AnalysisDiagnosis.cause(evidence, scoredCategoryCount: 1) == nil)
        #expect(AnalysisProblem.from(.notEnoughScoredMetrics) == .partialMeasurementsOnly)
    }

    // MARK: Manual kicker selection

    @Test func manualSelectionIsReported() throws {
        let seq = SyntheticPose.sequence(.fieldGoal) { [SyntheticPose.holder(at: $0)] }
        let frame = try #require(seq.frames.first { abs($0.timestamp - 1.0) < 0.01 })
        let kicker = try #require(frame.bodies.first)
        let hip = try #require(kicker.joints[.rightHip])
        let out = run(seq, seed: KickerSeed(timestamp: frame.timestamp, point: NormalizedPoint(x: hip.x, y: hip.y)))
        let r = report(out)
        #expect(r.manualKickerSelection == true)
        #expect(r.kickerSelectionMethod == .manualSeed)
        #expect(r.framesWithMultiplePeople == seq.frames.count)
        #expect(r.maximumPeopleInFrame == 2)
        #expect(report(run(seq)).manualKickerSelection == false)
    }

    // MARK: Messages

    @Test func eachCauseHasItsOwnStoredReasonAndMessage() {
        var reasons = Set<String>()
        var problems: [AnalysisProblem] = []
        for cause in AnalysisFailureCause.allCases {
            #expect(AnalysisFailureCause(reasonText: cause.reasonText) == cause, "stored reasons round-trip")
            reasons.insert(cause.reasonText)
            let problem = AnalysisProblem.from(kickerStatus: .selected, failureReason: cause.reasonText)
            #expect(problem == AnalysisProblem.from(cause))
            #expect(problem.canRetry)
            problems.append(problem)
        }
        #expect(reasons.count == AnalysisFailureCause.allCases.count)
        #expect(Set(problems.map(\.title)).count == problems.count, "no two causes share a message")
        let legsMessages = problems.filter { (p: AnalysisProblem) -> Bool in p == .notEnoughPoseData }
        #expect(legsMessages.count == 1, "'legs weren't visible' is used for one cause only")
        // Analyses stored before Step 12A keep their old meaning.
        #expect(AnalysisProblem.from(kickerStatus: .selected, failureReason: AnalysisFailureReasons.insufficientData) == .notEnoughPoseData)
        for problem in problems {
            #expect(!problem.message.isEmpty)
            #expect(!problem.message.contains("Error"))
        }
    }

    // MARK: Report content and privacy

    @Test func reportHoldsNoImagesCoordinatesOrIdentifiers() throws {
        let out = run(SyntheticPose.sequence(script(confidence: 0.55)), camera: .rear)
        let r = report(out, reason: AnalysisFailureCause.cameraAngleLimited.reasonText)
        let json = r.json()
        let object = try #require(try JSONSerialization.jsonObject(with: Data(json.utf8)) as? [String: Any])
        #expect(object["formatVersion"] as? Int == 2, "Step 12B added optional detection fields")
        for forbidden in ["\"x\"", "\"y\"", "kickID", "analysisID", "athlete", "videoID", "name\" : \"Test"] {
            #expect(!json.contains(forbidden), "\(forbidden) in diagnostics")
        }
        let text = r.plainText
        for heading in ["Outcome: failed", "Diagnosed cause: cameraAngleLimited", "Frames: sampled", "Kicker: selected",
                        "Joints (", "Phases (full)", "Metrics (", "Categories (", "Contributing factors:", "--- JSON ---"] {
            #expect(text.contains(heading), "missing \(heading)")
        }
        #expect(try JSONDecoder.iso8601.decode(AnalysisDiagnosticsReport.self, from: Data(json.utf8)) == r)
    }

    @Test func summaryOnlyWhenNoFilesWereStored() {
        let input = AnalysisDiagnosticsInput(kickType: .fieldGoal, engineVersion: "pose-biomechanics-2.0.0", cameraAngle: .side)
        let r = AnalysisDiagnosticsBuilder.build(input, storedStatus: "failed",
                                                 storedFailureReason: "The analysis failed: Pose detection failed on every frame.",
                                                 kickingFoot: .left, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0))
        #expect(!r.hasAnalysisFiles)
        #expect(r.kickingFoot == .left)
        #expect(r.failureCause == nil)
        #expect(r.contributingFactors.contains { $0.hasPrefix("No analysis files were stored") })
        #expect(r.plainText.contains("Pose detection failed on every frame."))
    }

    // MARK: Engine and stored files

    @Test func engineStoresTheCauseAndFilesRebuildTheSameReport() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        let kickID = UUID()
        let videoID = UUID()
        let path = ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: "mov")
        try temp.writeFile(path, under: store.mediaRootURL)
        let lowConfidence: Script = {
            var s = Script.fieldGoal
            s.confidence = 0.55
            return s
        }()
        let engine = PoseVideoAnalysisService(mediaStore: store,
                                              extractor: FakePoseExtractor { SyntheticPose.sequence(lowConfidence, videoID: $0) },
                                              now: { Date(timeIntervalSince1970: 1_800_000_000) })
        let request = VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [
            VideoAnalysisInput(videoID: videoID, angle: .rear, isPrimary: true, relativeFilePath: path,
                               frameRate: 30, durationSeconds: 2, syncOffsetSeconds: 0, contactTimeSeconds: nil),
        ], options: VideoAnalysisOptions(artifactsDirectoryID: UUID()))
        let result = try await engine.analyze(request) { _ in }
        #expect(result.poseSummary?.failureCause == .cameraAngleLimited)
        #expect(result.poseSummary?.scoredCategoryCount == 0)

        let directory = try #require(result.artifactsRelativePath)
        let bundle = try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL).readBundle(in: directory)
        let fromFiles = AnalysisDiagnosticsBuilder.build(AnalysisDiagnosticsInput(bundle: bundle), storedStatus: "failed",
                                                         storedFailureReason: AnalysisFailureCause.cameraAngleLimited.reasonText,
                                                         kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0))
        #expect(fromFiles.hasAnalysisFiles)
        #expect(fromFiles.failureCause == .cameraAngleLimited)
        #expect(fromFiles.cameraAngle == .rear)
        #expect(fromFiles.engineVersion == PoseVideoAnalysisService.version)
        #expect((fromFiles.framesSampled ?? 0) > 0)
        #expect(fromFiles.metrics.count == KickMetricKey.allCases.count)
        #expect(fromFiles.categories.count == KickMetricCatalog.scoredCategories.count)
        #expect(fromFiles.scoredCategoryCount == 0)
    }
}

private extension JSONDecoder {
    static var iso8601: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        decoder.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        return decoder
    }
}
