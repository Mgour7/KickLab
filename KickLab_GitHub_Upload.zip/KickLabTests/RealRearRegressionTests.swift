import Foundation
import Testing
@testable import KickLab

/// Step 12E: the REAL rear-view field goal from TestFlight build 10 (engine 2.4.0,
/// `RealReferenceClipRear`). On the device every phase after the approach was
/// unavailable and the analysis failed as `ambiguousContact`.
///
/// There is no verified contact reference for this clip. The user-assisted pick (3.867 s)
/// was made without frame-by-frame verification; it is used here only to REPORT the
/// disagreement, never to tune or score the detector.
@Suite("Real rear-view clip (build 10) regression")
struct RealRearRegressionTests {
    typealias Real = RealReferenceClipRear
    let frame = 1.0 / 30

    private func detect(_ assistance: PhaseDetectionAssistance? = nil) -> KickPhaseDetectionResult {
        KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal, assistance: assistance, perspective: .depthAway)
    }

    private func index(_ t: Double) -> Int {
        Real.time.indices.min { abs(Real.time[$0] - t) < abs(Real.time[$1] - t) }!
    }

    // MARK: The device failure, explained

    @Test func theDeviceRunFailedAsAmbiguousContact() {
        #expect(Real.storedFailureCause == "ambiguousContact")
        #expect(Real.time.count == 228)
        #expect(abs(KickPhaseDetector.framesPerSecond(Real.time) - 30) < 0.5, "exported times are rounded to 1 ms")
    }

    @Test func depthView1sSingleRuleFindsNoArcOnTheRealClip() {
        // depth-view-1: contact = the bottom of a heel arc whose apex rises ≥ 0.5 torso
        // lengths over the previous 0.4 s and drops ≥ 0.5 within 0.4 s, inside the strike
        // interval (3.417–4.05 s). On the real clip the only arc in that interval (apex
        // 3.90 s → 4.07 s) drops 0.45 after smoothing, so nothing was found.
        let lift = KickPhaseDetector.medianFilter(Real.kickingAnkleLift, radius: 1)
        let t = Real.time
        var found = false
        for i in t.indices where t[i] >= 3.4166 && t[i] <= 4.05 {
            guard let v = lift[i] else { continue }
            let before = t.indices.filter { t[$0] < t[i] && t[i] - t[$0] <= 0.4 + 1e-9 }.compactMap { lift[$0] }
            let around = t.indices.filter { abs(t[$0] - t[i]) <= 0.1 + 1e-9 }.compactMap { lift[$0] }
            guard let low = before.min(), v - low >= 0.5, v >= (around.max() ?? v) else { continue }
            let after = t.indices.filter { $0 > i && t[$0] - t[i] <= 0.4 + 1e-9 }.compactMap { lift[$0] }
            if let b = after.min(), v - b >= 0.5 { found = true }
        }
        #expect(!found)
    }

    // MARK: depth-view-2 on the real clip

    @Test func plantContactAndFollowThroughAreRecoveredAutomatically() throws {
        let p = detect()
        #expect(p.evidence?.algorithmVersion == "depth-view-2")
        // Plant: the plant leg's final swing (8.2 bl/s at 3.633 s) stops at 3.767 s, after
        // the run-up began braking — found before and independently of contact.
        let plant = p.phase(.plant)
        #expect(plant.status == .estimated)
        #expect(abs((plant.representativeTime ?? 0) - 3.767) < 0.002)
        // Contact: the only run of frames where all five cues agree is 4.000–4.067 s.
        let contact = p.phase(.contact)
        #expect(contact.status == .estimated, "never 'detected' without ball tracking")
        #expect(abs((contact.representativeTime ?? 0) - 4.033) < 0.002)
        #expect(contact.confidence <= DepthViewPhaseDetector.maximumContactConfidence)
        #expect(p.evidence?.contactTimingMethod == "multiCue")
        #expect(p.evidence?.contactTimingBasis == "automatic")
        let u = try #require(p.evidence?.contactUncertaintySeconds)
        #expect(u >= frame - 1e-9 && u <= 0.06)
        let chosen = try #require(p.evidence?.contactCandidates?.first { $0.selected })
        #expect(chosen.supportingSignals.count == DepthViewPhaseDetector.contactCueWeights.count, "all five independent cues agree")
        #expect((plant.representativeTime ?? 9) < (contact.representativeTime ?? 0))
        // Follow-through: the foot swings on (5.0 bl/s at 4.133 s) and settles at 4.300 s;
        // it does NOT need to rise (it barely does from behind).
        let follow = p.phase(.followThrough)
        #expect(follow.status == .estimated)
        #expect(abs((follow.endTime ?? 0) - 4.3) < 0.002)
        #expect(p.evidence?.followThroughBasis == "kickingAnkleSettle")
        // Approach ends at the plant.
        #expect(abs((p.phase(.approach).endTime ?? 0) - 3.767) < 0.002)
    }

    @Test func laterMovementsAreNotExtraKicks() {
        let w = detect().kickWindows
        #expect(w?.needsSelection == false)
        #expect(w?.windows.filter(\.hasSwing).count == 1)
        #expect(abs((w?.selected?.approachStart ?? 0) - 2.967) < 0.002)
    }

    @Test func theUnverifiedUserPickIsReportedNotUsed() {
        // Evaluation only: the automatic estimate and the user's pick disagree by 5 frames.
        let auto = detect().estimatedContactTime ?? 0
        let check = ContactTimingCheck(label: "user pick (unverified)", referenceTime: Real.userPickedContact, estimatedTime: auto,
                                       confidence: nil, sourceFrameRate: 30, analysisFrameRate: 30)
        #expect(!check.withinTolerance)
        #expect(abs((check.errorSeconds ?? 0) - 0.166) < 0.002)
        // At the pick the cues describe a backswing, not a strike: the heel is near its
        // highest and the knee is still bending.
        let i = index(Real.userPickedContact)
        let knee = Real.kickingKneeAngle
        #expect((knee[i] ?? 0) < (knee[index(4.033)] ?? 0) - 20)
        #expect((Real.kickingAnkleLift[i] ?? 0) > (Real.kickingAnkleLift[index(4.033)] ?? 0) + 0.3)
    }

    @Test func aUserContactStillGetsItsOwnPlantAndFollowThrough() {
        let p = detect(PhaseDetectionAssistance(contactTime: Real.userPickedContact))
        #expect(p.evidence?.contactTimingBasis == "user")
        #expect(abs((p.estimatedContactTime ?? 0) - 3.867) < 0.002)
        // Searched independently in the frames before the chosen contact.
        #expect(abs((p.plantTime ?? 0) - 3.767) < 0.002)
        #expect(p.phase(.plant).status == .estimated)
        #expect(p.phase(.followThrough).isAvailable)
        #expect(p.evidence?.contactCandidates == nil, "no automatic contact search in a user-assisted run")
    }

    @Test func withoutTheKneeCueContactIsNotEstablished() {
        // Abstention: remove one independent cue and the remaining ones (0.75) don't reach
        // the 0.85 needed — contact is reported as not established, not guessed.
        var signals = Real.signals
        signals.series[.kickingKneeAngle] = Array(repeating: nil, count: Real.time.count)
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(!p.phase(.contact).isAvailable)
        #expect(p.phase(.plant).isAvailable, "the plant doesn't depend on contact")
        #expect(p.notes.contains { $0.contains("not established") })
    }

    @Test func measurementsAvailableFromTheExportedSignals() {
        // What the metrics will read at the automatic contact (positions aren't exported,
        // so the extractor itself can't run here; these are the same signal values).
        let c = index(4.033)
        #expect(abs((Real.lateralTrunkLean[c] ?? 99) - 0.65) < 0.01)
        #expect(abs((Real.plantAnkleLateralOffset[c] ?? 99) - (-0.50)) < 0.01)
        let p = detect()
        let plantToContact = (p.estimatedContactTime ?? 0) - (p.plantTime ?? 0)
        #expect(abs(plantToContact - 0.267) < 0.002)
        #expect(abs(((p.phase(.followThrough).endTime ?? 0) - (p.estimatedContactTime ?? 0)) - 0.267) < 0.002)
    }

    @Test func theSideBenchmarkIsUnchanged() {
        let p = KickPhaseDetector.detect(RealReferenceClip220.signals, kickType: .fieldGoal)
        #expect(abs((p.estimatedContactTime ?? 0) - 2.467) < 0.002)
    }
}
