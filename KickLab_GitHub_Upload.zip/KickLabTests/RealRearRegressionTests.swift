import Foundation
import Testing
@testable import KickLab

/// Step 12E: the REAL rear-view field goal from TestFlight build 10 (engine 2.4.0,
/// `RealReferenceClipRear`). On the device every phase after the approach was
/// unavailable and the analysis failed as `ambiguousContact`.
///
/// Step 12F: the user has since reviewed the video frame by frame and confirmed the first
/// foot–ball touch at 3.867 s (`humanReferenceContact`). It is evaluation-only: no test
/// passes it to automatic detection, and the detector has no access to it.
@Suite("Real rear-view clip (build 10) regression")
struct RealRearRegressionTests {
    typealias Real = RealReferenceClipRear
    let frame = 1.0 / 30

    private func detect(_ assistance: PhaseDetectionAssistance? = nil) -> KickPhaseDetectionResult {
        KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal, assistance: assistance, perspective: .depthAway)
    }

    private func index(_ t: Double) -> Int {
        Real.time.indices.min { abs(Real.time[$0] - t) < abs(Real.time[$1] - t) }!
    }

    // MARK: The device failure, explained

    @Test func theDeviceRunFailedAsAmbiguousContact() {
        #expect(Real.storedFailureCause == "ambiguousContact")
        #expect(Real.time.count == 228)
        #expect(abs(KickPhaseDetector.framesPerSecond(Real.time) - 30) < 0.5, "exported times are rounded to 1 ms")
    }

    @Test func depthView1sSingleRuleFindsNoArcOnTheRealClip() {
        // depth-view-1: contact = the bottom of a heel arc whose apex rises ≥ 0.5 torso
        // lengths over the previous 0.4 s and drops ≥ 0.5 within 0.4 s, inside the strike
        // interval (3.417–4.05 s). On the real clip the only arc in that interval (apex
        // 3.90 s → 4.07 s) drops 0.45 after smoothing, so nothing was found.
        let lift = KickPhaseDetector.medianFilter(Real.kickingAnkleLift, radius: 1)
        let t = Real.time
        var found = false
        for i in t.indices where t[i] >= 3.4166 && t[i] <= 4.05 {
            guard let v = lift[i] else { continue }
            let before = t.indices.filter { t[$0] < t[i] && t[i] - t[$0] <= 0.4 + 1e-9 }.compactMap { lift[$0] }
            let around = t.indices.filter { abs(t[$0] - t[i]) <= 0.1 + 1e-9 }.compactMap { lift[$0] }
            guard let low = before.min(), v - low >= 0.5, v >= (around.max() ?? v) else { continue }
            let after = t.indices.filter { $0 > i && t[$0] - t[i] <= 0.4 + 1e-9 }.compactMap { lift[$0] }
            if let b = after.min(), v - b >= 0.5 { found = true }
        }
        #expect(!found)
    }

    // MARK: Root cause of the 2.5.0 error (Step 12F)

    @Test func engine250sFiveCueRulePicksThePostContactSwing() throws {
        // The legacy rule, run unchanged, still selects 4.033 s.
        let lift = KickPhaseDetector.medianFilter(Real.kickingAnkleLift, radius: 1)
        let p = detect()
        let landing = index(try #require(p.plantTime))
        let window = try #require(p.kickWindows?.selected)
        let legacy = DepthViewPhaseDetector.contactCues(Real.signals, lift, Real.time, window: window, landing: landing, frame: frame)
        guard case .established(let i, _) = legacy.decision else { Issue.record("legacy rule"); return }
        #expect(abs(Real.time[i] - Real.engine250AutomaticContact) < 0.002)
        // Three of its five cues describe the leg FINISHING its extension, which happens
        // after the human-reviewed contact: the knee is straight (within 5° of its maximum)
        // and the foot at its lowest only from 3.933 s / 4.0 s on.
        let knee = Real.kickingKneeAngle
        let ref = index(Real.humanReferenceContact)
        let straightest = (ref...index(4.2)).compactMap { knee[$0] }.max() ?? 0
        #expect((knee[ref] ?? 0) < straightest - 20, "at the reference contact the knee is still ~27° short of straight")
        #expect((knee[index(3.933)] ?? 0) >= straightest - 5, "extension complete at 3.933 s, after first contact")
        let lowest = Real.time.indices.filter { Real.time[$0] >= 3.8 && Real.time[$0] <= 4.2 }.min { (Real.kickingAnkleLift[$0] ?? 9) < (Real.kickingAnkleLift[$1] ?? 9) }!
        #expect(Real.time[lowest] > Real.humanReferenceContact + 0.1, "the foot's lowest image point is post-contact")
    }

    @Test func atTheReferenceFrameTheKneeIsDrivingFastestAndTheTrunkLeansMost() {
        let knee = Real.kickingKneeAngle
        let i = index(Real.humanReferenceContact)
        // Fastest 2D knee extension of the kick: 3.867 → 3.900 s (≈ 500°/s).
        let start = index(3.8)
        var rates: [Double] = []
        for j in start..<index(4.2) {
            let a: Double = knee[j] ?? 0
            let b: Double = knee[j + 1] ?? 0
            rates.append((b - a) / (Real.time[j + 1] - Real.time[j]))
        }
        let fastest: Int? = rates.indices.max { rates[$0] < rates[$1] }
        #expect(fastest.map { $0 + start } == i)
        // Sideways trunk lean (shoulders vs hips — independent of the leg) peaks at 3.867 s.
        let lean = (index(3.6)...index(4.2)).max { (Real.lateralTrunkLean[$0] ?? -99) < (Real.lateralTrunkLean[$1] ?? -99) }
        #expect(lean == i)
    }

    // MARK: contact-intelligence-4 on the real clip (Step 12G)

    @Test func plantContactAndFollowThroughAreRecoveredAutomatically() throws {
        let p = detect()
        #expect(p.evidence?.algorithmVersion == "contact-intelligence-4")
        // Plant: unchanged and independent of contact.
        let plant = p.phase(.plant)
        #expect(plant.status == .estimated)
        #expect(abs((plant.representativeTime ?? 0) - 3.767) < 0.002)
        // Step 12G: the strike window is the knee drive, 3.867–3.933 s (the trunk lean no
        // longer narrows it). It is within ±0.05 s, so contact is ESTIMATED at its middle,
        // 3.900 s — one frame after the human reference, which stays inside the window.
        let contact = p.phase(.contact)
        #expect(contact.status == .estimated, "never 'detected' without ball tracking")
        #expect(abs((contact.representativeTime ?? 0) - 3.9) < 0.002)
        #expect(abs((p.evidence?.contactEarliestTime ?? 0) - 3.867) < 0.002)
        #expect(abs((p.evidence?.contactLatestTime ?? 0) - 3.933) < 0.002)
        #expect(contact.confidence <= ContactIntelligence.oneGroupConfidence + 1e-9)
        #expect(p.evidence?.contactTimingMethod == "firstContactInterval")
        #expect(p.evidence?.contactTimingBasis == "automatic")
        #expect(p.evidence?.contactProvenance == "poseOnly")
        #expect(p.evidence?.ballEvidence?.outcome == .detectorUnavailable)
        let groups = try #require(p.evidence?.contactEvidenceGroups)
        #expect(groups.map(\.name) == ["kickingLegDrive", "trunkLateralLean"], "the lean is recorded as a clue")
        // Strike approach and post-contact swing are separate events.
        #expect(abs((p.evidence?.strikeApproachStartTime ?? 0) - 3.833) < 0.002)
        let markers = try #require(p.evidence?.postContactMarkers)
        #expect(markers.contains { $0.kind == "kneeExtensionComplete" && abs($0.time - 3.933) < 0.002 })
        #expect(markers.contains { $0.kind == "footLowest" && $0.time > 4.0 })
        // The 2.5.0 frame is listed as a rejected alternative, with its reason.
        let rejected = p.evidence?.contactCandidates?.filter { !$0.selected } ?? []
        #expect(rejected.contains { abs($0.time - 4.033) < 0.04 && $0.rejectionReasons.contains { $0.contains("post-contact") } })
        // Follow-through: measured from the new contact; the foot settles at 4.300 s.
        let follow = p.phase(.followThrough)
        #expect(abs((follow.endTime ?? 0) - 4.3) < 0.002)
        #expect(p.evidence?.followThroughBasis == "kickingAnkleSettle")
        #expect(abs((p.phase(.approach).endTime ?? 0) - 3.767) < 0.002)
    }

    @Test func beforeAndAfterAgainstTheHumanReference() {
        // Evaluation only: the reference is compared after detection, never passed in.
        let auto = detect().estimatedContactTime ?? 0
        let after = ContactTimingCheck(label: "human reference", referenceTime: Real.humanReferenceContact, estimatedTime: auto,
                                       confidence: nil, sourceFrameRate: 30, analysisFrameRate: 30)
        let before = ContactTimingCheck(label: "human reference", referenceTime: Real.humanReferenceContact,
                                        estimatedTime: Real.engine250AutomaticContact, confidence: nil, sourceFrameRate: 30, analysisFrameRate: 30)
        #expect(abs((before.errorSeconds ?? 0) - 0.166) < 0.002, "2.5.0: five frames late")
        #expect(abs((after.errorSeconds ?? 9) - 0.033) < 0.002, "2.7.0: one frame late, inside its 3.867–3.933 s window")
        #expect(after.withinTolerance)
    }

    @Test func laterMovementsAreNotExtraKicks() {
        let w = detect().kickWindows
        #expect(w?.needsSelection == false)
        #expect(w?.windows.filter(\.hasSwing).count == 1)
        #expect(abs((w?.selected?.approachStart ?? 0) - 2.967) < 0.002)
    }

    @Test func aUserContactStillGetsItsOwnPlantAndFollowThrough() {
        let p = detect(PhaseDetectionAssistance(contactTime: Real.userPickedContact))
        #expect(p.evidence?.contactTimingBasis == "user")
        #expect(abs((p.estimatedContactTime ?? 0) - 3.867) < 0.002)
        // Searched independently in the frames before the chosen contact.
        #expect(abs((p.plantTime ?? 0) - 3.767) < 0.002)
        #expect(p.phase(.plant).status == .estimated)
        #expect(p.phase(.followThrough).isAvailable)
        #expect(p.evidence?.contactCandidates == nil, "no automatic contact search in a user-assisted run")
    }

    @Test func withoutTheKneeContactIsNotEstablished() {
        // Abstention: no knee drive, no contact — the trunk lean alone is never enough.
        var signals = Real.signals
        signals.series[.kickingKneeAngle] = Array(repeating: nil, count: Real.time.count)
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(!p.phase(.contact).isAvailable)
        #expect(p.phase(.plant).isAvailable, "the plant doesn't depend on contact")
        #expect(p.notes.contains { $0.contains("not established") })
    }

    @Test func aDisagreeingTrunkLeanIsRecordedButNeverMovesContact() {
        // Step 12G: move the lean peak 0.3 s later. On IMG_1709 the lean peaked before the
        // strike, so the lean is a clue only: contact stays where the leg puts it.
        var signals = Real.signals
        let lean = Real.lateralTrunkLean
        signals.series[.lateralTrunkLean] = lean.indices.map { $0 >= 9 ? lean[$0 - 9] : lean[$0] }
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(abs((p.estimatedContactTime ?? 0) - 3.9) < 0.002)
        #expect(p.evidence?.contactEvidenceGroups?.first { $0.name == "trunkLateralLean" }?.agrees == false)
    }

    @Test func withoutTheTrunkTheLegAloneGivesAWiderLowerConfidenceInterval() {
        var signals = Real.signals
        signals.series[.lateralTrunkLean] = Array(repeating: nil, count: Real.time.count)
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        // The same as with the trunk: the leg alone defines the window.
        #expect(abs((p.estimatedContactTime ?? 0) - 3.9) < 0.002)
        #expect(abs((p.evidence?.contactEarliestTime ?? 0) - 3.867) < 0.002)
        #expect(abs((p.evidence?.contactLatestTime ?? 0) - 3.933) < 0.002, "leg interval only")
        #expect(p.phase(.contact).confidence <= ContactIntelligence.oneGroupConfidence + 1e-9, "one independent group")
    }

    @Test func measurementsAvailableFromTheExportedSignals() {
        // What the metrics will read at the automatic contact (positions aren't exported,
        // so the extractor itself can't run here; these are the same signal values).
        // Step 12F/12G: recalculated at the current contact (3.900 s; 3.867 s in 2.6.0).
        let c = index(3.867)
        #expect(abs((Real.lateralTrunkLean[c] ?? 99) - 9.609) < 0.01)
        #expect(abs((Real.plantAnkleLateralOffset[c] ?? 99) - (-0.533)) < 0.01)
        let p = detect()
        let plantToContact = (p.estimatedContactTime ?? 0) - (p.plantTime ?? 0)
        #expect(abs(plantToContact - 0.133) < 0.002, "0.267 s with the 2.5.0 contact, 0.100 s with 2.6.0")
        #expect(abs(((p.phase(.followThrough).endTime ?? 0) - (p.estimatedContactTime ?? 0)) - 0.4) < 0.002, "0.267 s in 2.5.0, 0.433 s in 2.6.0")
    }

    @Test func theSideBenchmarkIsUnchanged() {
        let p = KickPhaseDetector.detect(RealReferenceClip220.signals, kickType: .fieldGoal)
        #expect(abs((p.estimatedContactTime ?? 0) - 2.467) < 0.002)
    }
}
