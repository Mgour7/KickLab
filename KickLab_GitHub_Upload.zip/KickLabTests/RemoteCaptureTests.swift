import Foundation
import Testing
@testable import KickLab

/// Build 24 — remote cameras: wire format, pairing codes, clock synchronization, the
/// controller's take bookkeeping and the session sources it produces.
///
/// Everything here is SYNTHETIC: simulated clocks with chosen offsets and drift, simulated
/// network delays, no phones, no network, no camera. The real transport (Network
/// framework + CryptoKit) and the camera's first-frame timing must be checked on iPhones.
@Suite("Remote cameras")
struct RemoteCaptureTests {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    // MARK: Wire format

    @Test func messagesAndChunksSurviveTheWire() throws {
        let info = RemoteTakeInfo(takeID: UUID(), sessionID: UUID(), role: .rear, startCameraTime: 1234.5678, startUncertainty: 0.02,
                                  duration: 61.5, frameRate: 60, bytes: 123_456_789, usable: true, fileExtension: "mov", selection: nil)
        let messages: [RemoteMessage] = [
            .finished(info), .ping(id: 7, sent: 99.25), .pong(id: 7, controllerSent: 99.25, cameraReceived: 5.5, cameraSent: 5.51),
            .start(takeID: info.takeID, atCameraTime: nil), .sendFile(takeID: info.takeID, fromOffset: 1 << 33), .incompatible(version: 2),
        ]
        for m in messages {
            #expect(try RemoteWire.decode(RemoteWire.encode(.message(m))) == .message(m))
        }
        let bytes = Data((0..<1000).map { UInt8($0 % 251) })
        let chunk = RemoteWire.Payload.chunk(takeID: info.takeID, offset: 5_000_000_123, data: bytes)
        #expect(try RemoteWire.decode(RemoteWire.encode(chunk)) == chunk)
        #expect(throws: RemoteWire.WireError.self) { try RemoteWire.decode(Data([1, 2, 3])) }
        #expect(throws: RemoteWire.WireError.self) { try RemoteWire.decode(Data([9])) }
    }

    @Test func framesAreSplitWhereverTheStreamBreaks() throws {
        let bodies = [Data("first".utf8), Data(repeating: 7, count: 70_000), Data(), Data("last".utf8)]
        let stream = bodies.map(RemoteWire.frame).reduce(Data(), +)
        // Delivered in awkward pieces (1, 3, 1000, … bytes).
        var deframer = RemoteWire.Deframer()
        var out: [Data] = []
        var i = 0, step = 1
        while i < stream.count {
            let end = min(stream.count, i + step)
            out += try deframer.append(stream.subdata(in: i..<end))
            i = end
            step = step * 7 % 1009 + 1
        }
        #expect(out == bodies)
        var bad = RemoteWire.Deframer()
        #expect(throws: RemoteWire.WireError.self) { _ = try bad.append(Data([0xFF, 0xFF, 0xFF, 0xFF])) }
    }

    @Test func pairingCodesAreSixDigits() {
        var g = SeededGenerator(seed: 42)
        let code = RemotePairing.newCode(using: &g)
        #expect(code.count == 6 && code.allSatisfy(\.isNumber))
        #expect(RemotePairing.normalized("482 913") == "482913")
        #expect(RemotePairing.normalized("482-913") == "482913")
        #expect(RemotePairing.normalized("48291") == nil)
        #expect(RemotePairing.normalized("48291a") == nil)
        #expect(RemotePairing.normalized("٤٨٢٩١٣") == nil, "ASCII digits only")
        #expect(RemotePairing.display("482913") == "482 913")
    }

    // MARK: Clock synchronization

    /// One exchange between a controller and a camera whose clock reads
    /// `controller + offset`, with the given network legs (seconds).
    private func exchange(at t: Double, offset: Double, out: Double, back: Double, turnaround: Double = 0.0004) -> ClockSample {
        ClockSample(controllerSent: t, cameraReceived: t + out + offset, cameraSent: t + out + turnaround + offset,
                    controllerReceived: t + out + turnaround + back)
    }

    @Test func theShortestRoundTripGivesTheOffsetWithinItsStatedUncertainty() throws {
        let offset = -48_211.377_25
        var samples: [ClockSample] = []
        var g = SeededGenerator(seed: 7)
        for k in 0..<40 {
            // Wi-Fi peer-to-peer: mostly 3–30 ms legs, occasionally 200 ms, often uneven.
            let out = Double.random(in: 0.0015...0.015, using: &g) + (k % 9 == 0 ? 0.2 : 0)
            let back = Double.random(in: 0.0015...0.015, using: &g)
            samples.append(exchange(at: 100 + Double(k) * 2, offset: offset, out: out, back: back))
        }
        let e = try #require(ClockSync.estimate(samples, near: 140))
        #expect(abs(e.offset - offset) <= e.uncertainty, "true offset within ± half the best round trip")
        #expect(e.uncertainty < 0.016)
        // Converting back and forth is exact.
        #expect(abs(ClockSync.controllerTime(cameraTime: ClockSync.cameraTime(controllerTime: 150, e), e) - 150) < 1e-9)
    }

    @Test func badExchangesAreIgnoredAndOldOnesDontCount() {
        let good = exchange(at: 10, offset: 5, out: 0.004, back: 0.004)
        let backwards = ClockSample(controllerSent: 10, cameraReceived: 15, cameraSent: 15, controllerReceived: 9)
        let nan = ClockSample(controllerSent: .nan, cameraReceived: 1, cameraSent: 1, controllerReceived: 1)
        #expect(ClockSync.estimate([backwards, nan], near: 10) == nil)
        #expect(ClockSync.estimate([good, backwards], near: 10)?.samples == 1)
        #expect(ClockSync.estimate([good], near: 10 + RemoteCapture.clockWindow + 1) == nil, "too long ago")
    }

    // MARK: The controller's bookkeeping, end to end (simulated)

    /// A simulated camera: its clock reads `controller × (1 + drift) + offset`.
    private struct SimCamera {
        var id: String
        var role: SessionCameraRole
        var offset: Double
        var drift: Double
        var startJitter: Double
        func clock(_ t: Double) -> Double { t * (1 + drift) + offset }
        /// Controller time for a camera-clock reading.
        func controller(_ c: Double) -> Double { (c - offset) / (1 + drift) }
    }

    private let cams = [
        SimCamera(id: "cam-side", role: .side, offset: 91_337.25, drift: 18e-6, startJitter: 0.011),
        SimCamera(id: "cam-rear", role: .rear, offset: -4_820.5, drift: -22e-6, startJitter: 0.027),
        SimCamera(id: "cam-goal", role: .unspecified, offset: 12.0, drift: 5e-6, startJitter: 0.003),
    ]

    private func hello(_ c: SimCamera, pending: [RemoteTakeInfo] = []) -> RemoteCameraHello {
        RemoteCameraHello(cameraID: c.id, name: c.id, model: "iPhone11,8", version: RemoteCapture.protocolVersion, pending: pending)
    }

    private func ready(_ rig: inout RemoteRig, _ c: SimCamera, at t: Double) {
        _ = rig.receive(.status(RemoteCameraStatus(phase: .ready, elapsed: nil, selection: "1080p · 60 fps", battery: 0.8,
                                                    freeBytes: 40_000_000_000, warning: nil, pendingCount: 0, sending: false)), from: c.id, at: t)
    }

    /// Answers every ping in `actions` as camera `c` would, with network legs `out`/`back`.
    private func answerPings(_ rig: inout RemoteRig, _ actions: [RemoteRig.Action], _ c: SimCamera, out: Double, back: Double) {
        for case .send(.ping(let id, let sent), let to) in actions where to == c.id {
            let received = c.clock(sent + out)
            _ = rig.receive(.pong(id: id, controllerSent: sent, cameraReceived: received, cameraSent: received + 0.0003),
                            from: c.id, at: sent + out + 0.0003 + back)
        }
    }

    @Test func threeCamerasRecordTogetherAndLineUpOnTheSharedTimeline() throws {
        let sessionID = UUID()
        var rig = RemoteRig(sessionID: sessionID, sessionName: "Tuesday", controllerName: "Controller", request: .standard, clock: 1000, now: now)
        var t = 1000.0
        // Connect: each camera is welcomed with the next free view.
        for c in cams {
            let actions = rig.hello(hello(c), defaultRole: c.role, at: t)
            #expect(actions.contains { if case .send(.welcome(let w), let to) = $0 { return to == c.id && w.role == c.role && w.sessionID == sessionID }; return false })
        }
        // A minute of pings every 2 s, uneven legs.
        var g = SeededGenerator(seed: 3)
        while t < 1060 {
            t += 0.5
            let actions = rig.tick(at: t)
            for c in cams {
                answerPings(&rig, actions, c, out: Double.random(in: 0.002...0.02, using: &g), back: Double.random(in: 0.002...0.02, using: &g))
            }
        }
        for c in cams { ready(&rig, c, at: t) }
        #expect(rig.readyCameras.count == 3)

        // Record.
        let takeID = UUID()
        let startActions = try rig.startRecording(takeID: takeID, at: t)
        #expect(rig.isRecording)
        #expect(throws: RemoteRig.StartProblem.alreadyRecording) { _ = try rig.startRecording(takeID: UUID(), at: t) }
        let scheduled = t + RemoteCapture.scheduledStartLead
        var trueStart: [String: Double] = [:]   // controller clock
        for case .send(.start(let id, let at), let to) in startActions {
            #expect(id == takeID)
            let c = try #require(cams.first { $0.id == to })
            let cameraAt = try #require(at, "a camera with a clock estimate gets a scheduled start")
            // The camera starts at its scheduled moment plus its own start delay; it reports
            // its first frame on its own clock.
            let firstFrame = cameraAt + c.startJitter
            trueStart[c.id] = c.controller(firstFrame)
            #expect(abs(c.controller(cameraAt) - scheduled) < 0.02, "all cameras asked to start at one moment")
            _ = rig.receive(.started(takeID: takeID, cameraTime: firstFrame, uncertainty: RemoteCapture.firstFrameUncertainty), from: c.id, at: t + 0.9)
        }
        #expect(trueStart.count == 3)
        let markAt = t + 20
        rig.mark(at: markAt)
        t += 95
        let stopActions = rig.stopRecording(at: t)
        #expect(stopActions.count == 3 && !rig.isRecording)

        // Each camera finishes; its file comes across in chunks.
        var manifest = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "Tuesday", location: nil,
                                                         defaults: SessionKickDetails(), now: now)
        // The rear camera's file arrives first: it must wait for the side view (Camera A).
        for c in [cams[1], cams[0], cams[2]] {
            let info = RemoteTakeInfo(takeID: takeID, sessionID: sessionID, role: c.role, startCameraTime: nil, startUncertainty: nil,
                                      duration: 94.1, frameRate: 60, bytes: 700_000, usable: true, fileExtension: "mov", selection: nil)
            let asks = rig.receive(.finished(info), from: c.id, at: t + 1)
            #expect(asks == [.send(.sendFile(takeID: takeID, fromOffset: 0), to: c.id)])
            var offset: Int64 = 0
            while offset < info.bytes {
                let n = Int(min(Int64(RemoteCapture.fileChunkBytes), info.bytes - offset))
                #expect(rig.chunk(takeID: takeID, cameraID: c.id, offset: offset, count: n) == .write)
                offset += Int64(n)
            }
            #expect(rig.chunk(takeID: takeID, cameraID: c.id, offset: 3, count: 10) == .ignore, "stale chunk")
            _ = rig.receive(.fileEnd(takeID: takeID, bytes: info.bytes), from: c.id, at: t + 5)
            if c.role == .rear {
                #expect(rig.importable(sessionHasSources: false).isEmpty, "rear waits for the side view")
                #expect(rig.importable(sessionHasSources: false, force: true).count == 1)
            }
        }
        // Import in the order the rig allows.
        var sourceOf: [String: SessionSource] = [:]
        while let next = rig.importable(sessionHasSources: !manifest.sources.isEmpty).first {
            let tc = next.camera
            let info = try #require(tc.info)
            let remote = RemoteSourceInfo(cameraID: tc.cameraID, cameraName: tc.cameraName, takeID: next.takeID,
                                          startOnController: tc.startOnController, startUncertainty: tc.startTotalUncertainty)
            let s = TrainingSessionEditor.addRemoteSource(&manifest, id: UUID(), take: info, remote: remote, fileExtension: "mov", now: now)
            sourceOf[tc.cameraID] = s
            #expect(rig.imported(takeID: next.takeID, cameraID: tc.cameraID, sourceID: s.id) == [.send(.imported(takeID: next.takeID), to: tc.cameraID)])
        }
        #expect(rig.outstanding == 0)
        #expect(manifest.sources.count == 3)
        #expect(manifest.referenceSource?.role == .side, "the side view is Camera A")

        // Every offset matches the simulated truth within its stated uncertainty.
        let side = try #require(sourceOf["cam-side"])
        for c in cams where c.role != .side {
            let s = try #require(sourceOf[c.id])
            #expect(s.sync.provenance == .sharedClock)
            let truth = trueStart[c.id]! - trueStart["cam-side"]!
            let u = try #require(s.sync.uncertaintySeconds)
            #expect(abs(s.sync.offsetSeconds - truth) <= u, "\(c.id): \(s.sync.offsetSeconds) vs \(truth) ± \(u)")
            #expect(abs(s.sync.offsetSeconds - truth) < 0.012, "first-frame times known, clocks measured to a few ms")
            #expect(u < 0.1)
        }
        #expect(side.sync == .reference)

        // A kick at one true moment is found by all three cameras; it is ONE attempt with
        // two partner angles (Build 24: one partner per other camera).
        for i in manifest.sources.indices { manifest.processing.scan[manifest.sources[i].id.uuidString] = .done }
        for kickAt in [1080.0, 1110.0, 1140.0] {
            for c in cams {
                let s = sourceOf[c.id]!
                _ = try TrainingSessionEditor.addManualKick(&manifest, sourceID: s.id, contact: kickAt - trueStart[c.id]!, now: now)
            }
        }
        for i in manifest.candidates.indices { manifest.candidates[i].status = .confirmed }
        for c in cams where c.role != .side {
            #expect(MultiCameraSync.pairAutomatically(&manifest, primarySourceID: side.id, secondarySourceID: sourceOf[c.id]!.id, now: now) == 3)
        }
        #expect(manifest.attempts.count == 3, "three kicks, each seen by three cameras, counted once")
        #expect(manifest.pairs.count == 6)
        // The mark reaches each recording at its own time.
        let take = try #require(rig.takes.first)
        for c in cams {
            let tc = try #require(take.cameras.first { $0.cameraID == c.id })
            let marks = RemoteRig.markTimes(take, start: tc.startOnController, duration: 94.1)
            #expect(marks.count == 1)
            let expected = markAt - trueStart[c.id]!
            #expect(abs(marks[0] - expected) < 0.02)
        }
    }

    @Test func aCameraThatDropsOutIsRecoveredWhenItReturns() throws {
        let sessionID = UUID()
        var rig = RemoteRig(sessionID: sessionID, sessionName: "S", controllerName: "C", request: .standard, clock: 0, now: now)
        let c = cams[0]
        _ = rig.hello(hello(c), defaultRole: .side, at: 0)
        ready(&rig, c, at: 0)
        // No clock exchanges yet: the camera starts on receipt.
        let start = try rig.startRecording(takeID: UUID(), at: 1)
        #expect(start.count == 1)
        if case .send(.start(_, let at), _) = start[0] { #expect(at == nil) }
        let takeID = try #require(rig.currentTake?.id)
        // Silence → disconnected (the camera keeps recording on its own).
        _ = rig.tick(at: 1 + RemoteCapture.lostAfter + 1)
        #expect(rig.camera(c.id)?.connected == false)
        _ = rig.stopRecording(at: 30)
        // Back, still recording (it missed Stop): it's told to stop.
        _ = rig.hello(hello(c), defaultRole: .side, at: 40)
        let again = rig.receive(.status(RemoteCameraStatus(phase: .recording, elapsed: 39, selection: nil, battery: nil, freeBytes: nil,
                                                           warning: nil, pendingCount: 0, sending: false)), from: c.id, at: 40)
        #expect(again == [.send(.stop(takeID: takeID), to: c.id)])
        // A transfer cut off half way resumes from the last byte received.
        let info = RemoteTakeInfo(takeID: takeID, sessionID: sessionID, role: .side, startCameraTime: nil, startUncertainty: nil, duration: 39,
                                  frameRate: 60, bytes: 1000, usable: true, fileExtension: "mov", selection: nil)
        _ = rig.receive(.finished(info), from: c.id, at: 41)
        #expect(rig.chunk(takeID: takeID, cameraID: c.id, offset: 0, count: 600) == .write)
        let resume = rig.receive(.fileEnd(takeID: takeID, bytes: 1000), from: c.id, at: 42)
        #expect(resume == [.send(.sendFile(takeID: takeID, fromOffset: 600), to: c.id)])
        // The camera lists its unsent recordings when it reconnects; a recording the
        // controller already imported is confirmed again (the camera missed it).
        #expect(rig.chunk(takeID: takeID, cameraID: c.id, offset: 600, count: 400) == .write)
        _ = rig.receive(.fileEnd(takeID: takeID, bytes: 1000), from: c.id, at: 43)
        _ = rig.imported(takeID: takeID, cameraID: c.id, sourceID: UUID())
        let rehello = rig.hello(hello(c, pending: [info]), defaultRole: .side, at: 50)
        #expect(rehello.contains(.send(.imported(takeID: takeID), to: c.id)))
        // Unmeasured start: the source is honest about it.
        var m = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "S", location: nil, defaults: SessionKickDetails(), now: now)
        let ref = TrainingSessionEditor.addRemoteSource(&m, id: UUID(), take: info, remote: RemoteSourceInfo(cameraID: "x", cameraName: "x", takeID: takeID, startOnController: nil, startUncertainty: nil), fileExtension: "mov", now: now)
        #expect(ref.isReference)
        let second = TrainingSessionEditor.addRemoteSource(&m, id: UUID(), take: info, remote: RemoteSourceInfo(cameraID: "y", cameraName: "y", takeID: takeID, startOnController: nil, startUncertainty: nil), fileExtension: "mov", now: now)
        #expect(second.sync.provenance == .none, "no measured start → not synchronized, never guessed")
    }

    @Test func versionsRolesAndLaterRecordingsOfOneCamera() throws {
        let sessionID = UUID()
        var rig = RemoteRig(sessionID: sessionID, sessionName: "S", controllerName: "C", request: .standard, clock: 0, now: now)
        var old = hello(cams[0])
        old.version = RemoteCapture.protocolVersion + 1
        #expect(rig.hello(old, defaultRole: .side, at: 0) == [.send(.incompatible(version: RemoteCapture.protocolVersion), to: cams[0].id)])
        ready(&rig, cams[0], at: 0)
        #expect(rig.readyCameras.isEmpty, "an incompatible camera never records")
        #expect(throws: RemoteRig.StartProblem.noReadyCamera) { _ = try rig.startRecording(takeID: UUID(), at: 1) }
        _ = rig.hello(hello(cams[1]), defaultRole: rig.suggestedRole(), at: 0)
        #expect(rig.camera(cams[1].id)?.role == .rear, "side is taken (by the connected incompatible camera), so rear")
        _ = rig.setRole(.side, camera: cams[1].id)
        #expect(rig.duplicateRoles == [.side])
        // Two recordings of one remote camera in one view are segments of that camera.
        var m = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "S", location: nil, defaults: SessionKickDetails(), now: now)
        func add(_ cam: String, _ start: Double, role: SessionCameraRole) -> SessionSource {
            let info = RemoteTakeInfo(takeID: UUID(), sessionID: sessionID, role: role, startCameraTime: nil, startUncertainty: nil, duration: 60,
                                      frameRate: 60, bytes: 10, usable: true, fileExtension: "mov", selection: nil)
            return TrainingSessionEditor.addRemoteSource(&m, id: UUID(), take: info, remote: RemoteSourceInfo(cameraID: cam, cameraName: cam, takeID: info.takeID,
                startOnController: now.addingTimeInterval(start), startUncertainty: 0.01), fileExtension: "mov", now: now)
        }
        let a1 = add("A", 0, role: .side), b1 = add("B", 0.4, role: .rear), a2 = add("A", 300, role: .side), b2 = add("B", 300.2, role: .rear)
        #expect(m.cameraID(of: a2) == a1.id && m.cameraID(of: b2) == b1.id)
        #expect(abs((m.source(b2.id)?.sync.offsetSeconds ?? 0) - 300.2) < 1e-6, "dates: microsecond precision")
        #expect(abs((m.source(a2.id)?.sync.offsetSeconds ?? 0) - 300) < 1e-6)
        // A reference recorded on the controller itself is on the same clock.
        var local = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "L", location: nil, defaults: SessionKickDetails(), now: now)
        _ = TrainingSessionEditor.addSource(&local, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .finalized, now: now)
        let sync = RemoteCaptureSync.sync(start: now.addingTimeInterval(2.5), uncertainty: 0.02, in: local, now: now)
        #expect(sync.provenance == .sharedClock && abs(sync.offsetSeconds - 2.5) < 1e-6)
        #expect(abs((sync.uncertaintySeconds ?? 0) - (0.02 + TrainingSessionEditor.sameCameraStartUncertainty)) < 1e-9)
        // An imported reference of unknown clock: not synchronized.
        var imported = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: nil, name: "I", location: nil, defaults: SessionKickDetails(), now: now)
        _ = TrainingSessionEditor.addSource(&imported, id: UUID(), role: .side, origin: .imported, fileExtension: "mov", status: .finalized, now: now)
        #expect(RemoteCaptureSync.sync(start: now, uncertainty: 0.02, in: imported, now: now) == .unsynchronized)
    }

    @Test func persistedTakesResumeSafely() throws {
        let tc = RemoteRig.TakeCamera(cameraID: "a", cameraName: "a", role: .side, phase: .receiving, receivedBytes: 500)
        let take = RemoteRig.Take(id: UUID(), startedAt: now, stoppedAt: nil, cameras: [tc], marks: [now])
        let data = try JSONEncoder().encode([take])
        let restored = try JSONDecoder().decode([RemoteRig.Take].self, from: data)
        let rig = RemoteRig(sessionID: UUID(), sessionName: "S", controllerName: "C", request: .standard, takes: restored, clock: 0, now: now)
        #expect(rig.takes[0].cameras[0].phase == .waitingForFile && rig.takes[0].cameras[0].receivedBytes == 0, "a cut-off transfer starts over")
        #expect(!rig.isRecording, "a take open when the app closed is treated as stopped")
    }

    @Test func kickSettingsFollowEachTakeIntoEveryCamerasRecording() {
        let start = now
        var take = RemoteRig.Take(id: UUID(), startedAt: start, stoppedAt: nil, cameras: [], marks: [],
                                  details: SessionKickDetails(kickType: .fieldGoal, distanceYards: 30))
        let source = UUID()
        let defaults = SessionKickDetails(kickType: .fieldGoal, distanceYards: 30)
        #expect(RemoteRig.defaultsChanges(take, sourceID: source, start: start, sessionDefaults: defaults).isEmpty, "nothing changed")
        take.detailChanges = [RemoteRig.DetailsChange(at: start.addingTimeInterval(42), details: SessionKickDetails(kickType: .fieldGoal, distanceYards: 40))]
        // This camera's first frame came 0.5 s after the take's nominal start.
        let changes = RemoteRig.defaultsChanges(take, sourceID: source, start: start.addingTimeInterval(0.5), sessionDefaults: defaults)
        #expect(changes.map(\.atSourceTime) == [0, 41.5])
        #expect(changes.map(\.details.distanceYards) == [30, 40])
        // A take recorded with settings the session has since moved on from keeps its own.
        let later = RemoteRig.defaultsChanges(RemoteRig.Take(id: UUID(), startedAt: start, stoppedAt: start, cameras: [], marks: [], details: defaults),
                                              sourceID: source, start: start, sessionDefaults: SessionKickDetails(kickType: .kickoff))
        #expect(later.count == 1 && later[0].details == defaults)
    }

    @Test func theCameraKeepsItsRecordingsUntilTheControllerHasThem() throws {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("outbox-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: base) }
        let outbox = RemoteCameraOutbox(baseURL: base)
        try outbox.prepare()
        // Written before recording starts; the app is then closed mid-recording.
        let cut = RemoteTakeInfo(takeID: UUID(), sessionID: UUID(), role: .side, startCameraTime: 5, startUncertainty: 0.02, duration: nil,
                                 frameRate: 60, bytes: 0, usable: false, fileExtension: "mov", selection: nil)
        try outbox.save(cut)
        try Data(repeating: 1, count: 4096).write(to: outbox.videoURL(cut.takeID))
        // One that never got a byte (camera failed to start).
        var never = cut
        never.takeID = UUID()
        try outbox.save(never)
        let current = UUID()
        var recording = cut
        recording.takeID = current
        try outbox.save(recording)
        try Data(repeating: 2, count: 10).write(to: outbox.videoURL(current))
        outbox.removeEmpty(excluding: current)
        let pending = outbox.pending(excluding: current)
        #expect(pending.map(\.takeID) == [cut.takeID], "the recording in progress isn't offered; the empty one is gone")
        #expect(pending[0].bytes == 4096 && pending[0].usable, "a cut-off recording is kept up to its last fragment")
        outbox.remove(cut.takeID)
        #expect(outbox.pending(excluding: current).isEmpty)
        #expect(!FileManager.default.fileExists(atPath: outbox.videoURL(cut.takeID).path))
    }

    @Test func eachCameraCanHaveItsOwnQualityAndUprightPhonesAreFlagged() throws {
        var rig = RemoteRig(sessionID: UUID(), sessionName: "S", controllerName: "C", request: .standard, kickType: .fieldGoal, clock: 0, now: now)
        let fast = CaptureRequest(resolution: .hd1080, framesPerSecond: 120)
        // The side camera was given 120 fps before: it keeps it when it reconnects.
        let actions = rig.hello(hello(cams[0]), defaultRole: .side, defaultRequest: fast, at: 0)
        func welcomed(_ a: [RemoteRig.Action]) -> RemoteControllerWelcome? {
            for case .send(.welcome(let w), _) in a { return w }
            return nil
        }
        #expect(welcomed(actions)?.request == fast)
        #expect(welcomed(actions)?.kickType == .fieldGoal)
        _ = rig.hello(hello(cams[1]), defaultRole: .rear, at: 0)
        #expect(welcomed(rig.setRequest(nil, camera: cams[0].id))?.request == .standard, "back to the session's quality")
        #expect(welcomed(rig.setRequest(fast, camera: cams[0].id))?.request == fast)
        // The session's quality changes everyone without an override.
        let all = rig.setRequest(CaptureRequest(resolution: .hd1080, framesPerSecond: 30))
        let byCamera = Dictionary(uniqueKeysWithValues: all.compactMap { a -> (String, Int)? in
            if case .send(.welcome(let w), let to) = a { return (to, w.request.framesPerSecond) }
            return nil
        })
        #expect(byCamera == [cams[0].id: 120, cams[1].id: 30])
        #expect(rig.setKickType(.punt).count == 2, "framing advice follows the kick type")
        // Upright phones.
        #expect(RemoteCameraOrientation.from(captureRotation: 0) == .landscape)
        #expect(RemoteCameraOrientation.from(captureRotation: 180) == .landscape)
        #expect(RemoteCameraOrientation.from(captureRotation: 90) == .portrait)
        #expect(RemoteCameraOrientation.from(captureRotation: -90) == .portrait)
        #expect(RemoteCameraOrientation.from(captureRotation: .nan) == nil)
        var upright = RemoteCameraStatus(phase: .ready, elapsed: nil, selection: nil, battery: nil, freeBytes: nil, warning: nil, pendingCount: 0, sending: false)
        upright.orientation = .portrait
        _ = rig.receive(.status(upright), from: cams[1].id, at: 1)
        ready(&rig, cams[0], at: 1)
        #expect(rig.uprightCameras.map(\.id) == [cams[1].id])
        // A camera from before this field existed still reads.
        let old = Data(#"{"phase":"ready","pendingCount":0,"sending":false}"#.utf8)
        #expect(try JSONDecoder().decode(RemoteCameraStatus.self, from: old).orientation == nil)
        let oldWelcome = Data(#"{"controllerName":"C","sessionID":"\#(UUID().uuidString)","sessionName":"S","role":"side","request":{"resolution":"1080p","framesPerSecond":60,"recordsAudio":false},"version":1}"#.utf8)
        #expect(try JSONDecoder().decode(RemoteControllerWelcome.self, from: oldWelcome).kickType == nil)
        // Framing advice: sideways first, then where to stand for that view.
        let rear = RemoteFraming.advice(role: .rear, kickType: .fieldGoal)
        #expect(rear.first?.title == "Turn the phone sideways")
        #expect(rear.contains { $0.title == "Camera position" && $0.detail.hasPrefix("Stand behind the kicker") })
        #expect(RemoteFraming.advice(role: .unspecified, kickType: nil).contains { $0.detail.hasPrefix("Stand in front of the kicker") })
    }

    @Test func modelNames() {
        #expect(RemoteDeviceName.marketingName("iPhone11,8") == "iPhone XR")
        #expect(RemoteDeviceName.marketingName("iPhone99,1") == "iPhone99,1")
        #expect(RemoteDeviceName.defaultCameraName(model: "iPhone12,1", cameraID: "4f2a9c") == "iPhone 11 · 4F2A")
    }
}
