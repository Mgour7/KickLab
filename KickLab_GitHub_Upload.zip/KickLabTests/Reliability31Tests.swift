import Foundation
import Testing
@testable import KickLab

/// Build 19 — Biomechanics Reliability 3.1 (engine pose-biomechanics-3.1.0).
///
/// Evidence classes, kept apart:
/// - REAL DEVICE SERIES: `RealReferenceClip220` — the side reference clip's Apple Vision
///   signals exported from the iPhone (engine 2.2.0 export: speeds and along-run offsets,
///   no coordinates). The label-collapse root cause is reproduced on it.
/// - REAL FRAMES, OTHER POSE MODEL: IMG_1709 (MediaPipe landmarks of the real frames and
///   the real YOLOX-S detections). NOT an Apple Vision run.
/// - SYNTHETIC: `SyntheticPose` kicks and hand-built arrays, labelled as such.
@Suite("Biomechanics Reliability 3.1")
struct Reliability31Tests {
    typealias Script = SyntheticPose.KickScript

    // MARK: A — kicking-ankle identity (REAL device series)

    @Test func theSideClipsKickingAnkleLabelCollapsesOntoThePlantFootBeforeContact() throws {
        let p = KickPhaseDetector.detect(RealReferenceClip220.signals, kickType: .fieldGoal)
        // Contact invariant: unchanged.
        #expect(abs((p.estimatedContactTime ?? 0) - 2.467) < 0.002)
        let lost = try #require(p.evidence?.kickingAnkleIdentityLostTime)
        #expect(abs(lost - 2.367) < 0.002, "18.8 → 3.2 torso lengths/s within two frames, level with the plant ankle")
        #expect(lost < (p.estimatedContactTime ?? 0), "before contact")
        #expect(p.evidence?.kickingAnkleMergedAfterContact == true)
        // Follow-through: unavailable for the RIGHT reason — never "too soon, maybe not the strike".
        #expect(p.phase(.followThrough).status == .unavailable)
        #expect(p.evidence?.followThroughObservation == FollowThroughObservation.unavailable.rawValue)
        #expect(!p.notes.contains { $0.contains("too soon for a follow-through") })
        #expect(p.notes.contains { $0.contains("Vision placed both ankles on one foot") })
    }

    @Test func aNormalKickKeepsItsKickingAnkleIdentity() {
        // SYNTHETIC: the standard 30 fps side kick.
        let signals = PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(SyntheticPose.timeline(Script.realWorld30fps)), kickingFoot: .right)
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        #expect(p.evidence?.kickingAnkleIdentityLostTime == nil)
        #expect(p.evidence?.followThroughObservation == FollowThroughObservation.observed.rawValue)
    }

    @Test func collapseNeedsAnAbruptStopCoincidenceAndPersistence() {
        // SYNTHETIC arrays (30 fps). Peak 20 at frame 2.
        let t = (0..<20).map { Double($0) / 30 }
        let stop: [Double?] = [5, 15, 20, 18, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
        let together: [Double?] = Array(repeating: 0.05, count: 20)
        let apart: [Double?] = Array(repeating: 0.5, count: 20)
        let none = [Double?](repeating: nil, count: 20)
        #expect(KickingAnkleIdentity.collapseOnset(speed: stop, separation: together, ahead: none, times: t, peakIndex: 2, peak: 20) == 3)
        #expect(KickingAnkleIdentity.collapseOnset(speed: stop, separation: apart, ahead: none, times: t, peakIndex: 2, peak: 20) == nil,
                "a real slow-down away from the plant foot is not a collapse")
        let gradual: [Double?] = [5, 15, 20, 18, 16, 14, 12, 10, 9, 8, 7, 6, 5, 4, 3, 2, 2, 2, 2, 2]
        #expect(KickingAnkleIdentity.collapseOnset(speed: gradual, separation: together, ahead: none, times: t, peakIndex: 2, peak: 20) == nil,
                "a gradual slow-down beside the plant foot is not an abrupt stop")
        var brief = together
        for i in 6..<20 { brief[i] = 0.5 }
        #expect(KickingAnkleIdentity.collapseOnset(speed: stop, separation: brief, ahead: none, times: t, peakIndex: 2, peak: 20) == nil,
                "a momentary overlap (foot passing the plant foot) doesn't persist")
    }

    @Test func aPartlyObservedFollowThroughNeedsTheFootStillMovingWhenItReappears() {
        // SYNTHETIC arrays: lost frames 3–7, apart again from frame 8.
        let t = (0..<25).map { Double($0) / 30 }
        var sep: [Double?] = Array(repeating: 0.5, count: 25)
        for i in 3...7 { sep[i] = 0.05 }
        let r = KickingAnkleIdentity.reappearance(separation: sep, ahead: [], times: t, lostFrom: 3, contactTime: t[2])
        #expect(r == 8)
        let moving: [Double?] = [10, 20, 20, 2, 2, 2, 2, 2, 30, 14, 12, 8, 4, 3, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        let end = KickingAnkleIdentity.endAfterReappearance(speed: moving, times: t, reappeared: 8, peak: 20, endFraction: 0.25, contactTime: t[2])
        #expect(end == 12, "seen again still fast (14 ≥ 10), slowed to ≤ 5 at frame 12")
        let slowed: [Double?] = [10, 20, 20, 2, 2, 2, 2, 2, 30, 4, 3, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        #expect(KickingAnkleIdentity.endAfterReappearance(speed: slowed, times: t, reappeared: 8, peak: 20, endFraction: 0.25, contactTime: t[2]) == nil,
                "already slow when seen again: it may have slowed while hidden — nothing reported")
    }

    @Test func kickingLegValuesAtContactAreWithheldWhenTheLabelCollapsedBeforeContact() {
        // SYNTHETIC timeline; the evidence records a collapse just before contact.
        let s = Script.realWorld30fps
        let timeline = PoseTimelineProcessor.process(SyntheticPose.timeline(s))
        let signals = PoseSignalExtractor.extract(from: timeline, kickingFoot: .right)
        var phases = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        let contact = phases.estimatedContactTime ?? s.expectedContact
        let context = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side)
        func knee() -> KickMetricMeasurement? {
            KickMetricExtractor.extract(KickMetricInput(timeline: timeline, signals: signals, phases: phases, context: context,
                                                        profile: .standard(for: .fieldGoal))).first { $0.key == .kickingKneeAngleAtContact }
        }
        #expect(knee()?.isAvailable == true)
        phases.evidence?.kickingAnkleIdentityLostTime = contact - 0.033
        #expect(knee()?.unavailableReason == .kickingLegNotTracked, "the ankle at contact was on the plant foot")
        phases.evidence?.kickingAnkleIdentityLostTime = contact + 0.1
        #expect(knee()?.isAvailable == true, "a collapse after contact doesn't spoil the contact frame")
    }

    // MARK: B — follow-through naming (SYNTHETIC)

    @Test func aKneeTimedFollowThroughIsNeverReportedAsTheFootsFollowThrough() {
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        for i in t.samples.indices where t.samples[i].timestamp >= s.expectedContact + 0.04 - 1e-9 {
            t.samples[i].joints[.rightAnkle] = t.samples[i].joints[.leftAnkle]
        }
        let r = SyntheticBiomechanics.analyze(s, timeline: t)
        let phases = KickPhaseDetector.detect(PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(t), kickingFoot: .right), kickType: .fieldGoal)
        #expect(phases.evidence?.followThroughBasis == "kickingKnee")
        #expect(phases.evidence?.followThroughObservation == FollowThroughObservation.inferredLimited.rawValue)
        #expect(r.measurement(.followThroughDuration)?.unavailableReason == .kickingLegNotTracked, "the FOOT's follow-through wasn't seen")
        let knee = r.measurement(.kneeSwingAfterContact)
        #expect(knee?.isAvailable == true, "the knee's own measurement, under its own name")
        #expect(KickMetricKey.kneeSwingAfterContact.definition.displayName == "Knee swing after contact")
        #expect(BiomechanicsProfile.standard(for: .fieldGoal).scoring[.kneeSwingAfterContact] == nil, "descriptive, not scored")
        #expect(r.measurement(.followThroughFootHeight)?.isAvailable == false)
    }

    @Test func kneeSwingIsSideViewOnly() {
        for (angle, perspective) in [(VideoAngleType.rear, CameraPerspective.depthAway), (.oblique, .oblique)] {
            let c = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: angle, perspective: perspective)
            #expect(PerspectiveMetricSupport.support(.kneeSwingAfterContact, context: c) == .unsupported)
        }
    }

    // MARK: C — camera-motion compensation (SYNTHETIC)

    private struct Setup {
        var timeline: KickerPoseTimeline
        var signals: PoseSignalSet
        var phases: KickPhaseDetectionResult
    }

    private func setup(_ edit: (inout KickerPoseTimeline) -> Void = { _ in }) -> Setup {
        var raw = SyntheticPose.timeline(Script.realWorld30fps)
        edit(&raw)
        let timeline = PoseTimelineProcessor.process(raw)
        let signals = PoseSignalExtractor.extract(from: timeline, kickingFoot: .right)
        return Setup(timeline: timeline, signals: signals, phases: KickPhaseDetector.detect(signals, kickType: .fieldGoal))
    }

    private func measure(_ s: Setup, _ key: KickMetricKey, camera: CameraShiftSeries?, phases: KickPhaseDetectionResult? = nil) -> KickMetricMeasurement? {
        var context = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side)
        context.cameraShift = camera
        return KickMetricExtractor.extract(KickMetricInput(timeline: s.timeline, signals: s.signals, phases: phases ?? s.phases, context: context,
                                                           profile: .standard(for: .fieldGoal))).first { $0.key == key }
    }

    private func shift(_ timeline: inout KickerPoseTimeline, _ f: (Double) -> Double) {
        for i in timeline.samples.indices {
            let d = f(timeline.samples[i].timestamp)
            for (j, p) in timeline.samples[i].joints { timeline.samples[i].joints[j] = PosePoint(x: p.x + d, y: p.y, confidence: p.confidence, status: p.status) }
        }
    }

    private func series(_ f: (Double) -> Double, from a: Double, to b: Double, moved: Bool = true, zoom: Bool = false) -> CameraShiftSeries {
        let times = stride(from: a, through: b + 1e-9, by: 1.0 / 30).map { $0 }
        return CameraShiftSeries(times: times, dx: times.map(f), dy: times.map { _ in 0 }, cameraMoved: moved, zoomSuspected: zoom)
    }

    @Test func aSteadyCameraChangesNothing() {
        let base = setup()
        let c = base.phases.estimatedContactTime ?? 2.4
        let plain = measure(base, .plantFootDrift, camera: nil)
        let steady = measure(base, .plantFootDrift, camera: series({ _ in 0 }, from: c - 0.5, to: c + 0.5, moved: false))
        #expect(plain?.value == steady?.value)
    }

    @Test func aTranslatedCameraIsCompensatedFromMeasuredBackgroundMotion() throws {
        let base = setup()
        let c = try #require(base.phases.estimatedContactTime)
        // The camera slid sideways around contact (0.03 of the frame width over ≈ 0.13 s):
        // every image point moved with it. (A continuous slide: the pose timeline's own
        // smoothing would blur a one-frame jump, which is not how a held phone moves.)
        let jump = { (t: Double) in 0.03 * min(1, max(0, (t - (c - 0.05)) / 0.13)) }
        let moved = setup { shift(&$0, jump) }
        let truth = try #require(measure(base, .plantFootDrift, camera: nil)?.value)
        let raw = try #require(measure(moved, .plantFootDrift, camera: nil, phases: base.phases)?.value)
        #expect(raw > truth + 0.05, "uncompensated, the camera's jump looks like the plant foot sliding")
        let fixed = try #require(measure(moved, .plantFootDrift, camera: series(jump, from: c - 0.5, to: c + 0.5), phases: base.phases)?.value)
        #expect(abs(fixed - truth) < 0.02, "compensated (\(fixed) vs \(truth))")
        // Moved, but the window isn't measured → withheld, never guessed.
        #expect(measure(moved, .plantFootDrift, camera: series(jump, from: c - 0.5, to: c), phases: base.phases)?.unavailableReason == .cameraMoving)
        // Zoom suspected → translation compensation doesn't apply → withheld.
        #expect(measure(moved, .plantFootDrift, camera: series(jump, from: c - 0.5, to: c + 0.5, zoom: true), phases: base.phases)?.unavailableReason == .cameraMoving)
    }

    @Test func aPanningCameraIsCompensatedOnlyWhereMeasured() throws {
        let base = setup()
        let c = try #require(base.phases.estimatedContactTime)
        let pan = { (t: Double) in -0.25 * max(0, t - (c - 0.2)) }
        let panned = setup { shift(&$0, pan) }
        let truth = measure(base, .bodyForwardSpeedAtContact, camera: nil)?.value ?? 0
        let raw = measure(panned, .bodyForwardSpeedAtContact, camera: nil, phases: base.phases)?.value ?? 0
        #expect(abs(raw - truth) > 0.5, "panning changes the in-frame body speed")
        let fixed = try #require(measure(panned, .bodyForwardSpeedAtContact, camera: series(pan, from: c - 0.3, to: c + 0.3), phases: base.phases)?.value)
        #expect(abs(fixed - truth) < 0.6, "compensated from measured camera motion (\(fixed) vs \(truth))")
        #expect(measure(panned, .bodyForwardSpeedAtContact, camera: series(pan, from: c + 0.1, to: c + 0.3), phases: base.phases)?.unavailableReason == .cameraMoving)
    }

    @Test func cameraShiftSeriesInterpolatesOnlyInsideTheMeasuredWindow() {
        let s = CameraShiftSeries(times: [0, 1.0 / 30, 2.0 / 30, 0.5], dx: [0, 0.01, 0.02, 0.5], dy: [0, 0, 0, 0], cameraMoved: true, zoomSuspected: false)
        #expect(abs((s.shift(at: 0.5 / 30)?.dx ?? -1) - 0.005) < 1e-9)
        #expect(s.shift(at: 0.3) == nil, "gap too long to interpolate")
        #expect(s.shift(at: 0.6) == nil, "outside the window")
        #expect(s.state(for: [0, 1.0 / 30]) == .compensated)
        #expect(s.state(for: [0, 0.3]) == .notCompensable)
        var steady = s
        steady.cameraMoved = false
        #expect(steady.state(for: [0]) == .steady && steady.state(for: [0.3]) == .unmeasured)
    }

    // MARK: E — units and wording

    @Test func everyDisplayedUnitMatchesItsNormalization() {
        #expect(DisplayFormat.metricValue(0.458, unit: .bodyLengths) == "0.46 torso lengths")
        #expect(DisplayFormat.metricValue(1.637, unit: .bodyLengthsPerSecond) == "1.6 torso lengths/s")
        for key in KickMetricKey.allCases {
            let d = key.definition
            #expect(!d.explanation.contains("body length"), "\(key)")
            if d.unit == .bodyLengths || d.unit == .bodyLengthsPerSecond {
                let shown = DisplayFormat.signedLateralMetrics.contains(key) ? DisplayFormat.lateral(0.5, unit: d.unit) : DisplayFormat.metricValue(0.5, unit: d.unit)
                #expect(shown.contains("torso lengths"), "\(key): \(shown)")
            }
        }
        #expect(AnalysisPresentationBuilder.unitNote.contains("torso lengths"))
    }

    @Test func sidewaysMeasurementsShowTheSideInWords() {
        #expect(DisplayFormat.lateral(0.706, unit: .bodyLengths) == "0.71 torso lengths · plant-leg side")
        #expect(DisplayFormat.lateral(-0.429, unit: .bodyLengths) == "0.43 torso lengths · kicking-leg side")
        #expect(DisplayFormat.lateral(11.2, unit: .degrees) == "11° · plant-leg side")
        #expect(KickMetricKey.plantBallLateralOffset.definition.displayName == "Plant foot to ball (sideways)")
        #expect(KickMetricKey.plantFootWidth.definition.displayName == "Plant foot vs hips (sideways)")
        #expect(KickMetricKey.plantLateralMovement.definition.displayName == "Plant-foot sideways slide")
        #expect(KickMetricKey.plantFootWidth.definition.explanation.contains("negative = it is under the body"))
        let rows = AnalysisPresentationBuilder.metricRows([StoredMetricRecord(key: KickMetricKey.plantFootWidth.rawValue, value: -0.429, unit: .bodyLengths,
                                                                              confidence: 0.59, status: .estimated, phase: .plant)])
        #expect(rows.first?.valueText == "0.43 torso lengths · kicking-leg side")
    }

    // MARK: Measurement inspection (REAL frames, other pose model)

    @Test func plantToBallOverlayUsesStoredPoseAndBallDetections() throws {
        typealias Clip = RealVideoClip1709
        let pose = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        let context = FootballAnalysisContext.make(from: pose, kickingFoot: .right)
        let track = FootballTrackAnalyzer.analyze(broadScan: RealVideo1709Football.broadScan, scanTimes: RealVideo1709Football.scanTimes,
                                                  precision: RealVideo1709Football.precisionFrames, ankle: context.ankle, strike: context.strike,
                                                  aspect: Clip.displayAspectRatio, duration: Clip.durationSeconds, detector: .yoloxS)
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear, football: track))
        let value = try #require(out.biomechanics.measurements.first { $0.key == .plantBallLateralOffset }?.value)
        let result = MeasurementInspection.make(kind: .plantToBall, timeline: out.kickerTimeline, football: track,
                                                contactTime: out.phases.estimatedContactTime, kickingFoot: .right, storedValue: value)
        guard case .success(let i) = result else { Issue.record("expected an overlay, got \(result)"); return }
        #expect(abs(i.time - 7.935) < 0.002, "the contact frame")
        #expect(i.ball != nil)
        #expect(abs(i.reference.x - 0.567) < 0.01 && abs(i.reference.y - 0.585) < 0.01, "the kicked ball on the holder")
        // The drawn offset has the measured sign: the plant (left) ankle is to the image left of the ball.
        #expect(i.ankle.x < i.reference.x && value > 0)
        #expect(i.valueText.hasSuffix("plant-leg side"))
        // Missing inputs: no overlay, a reason.
        #expect(MeasurementInspection.make(kind: .plantToBall, timeline: out.kickerTimeline, football: nil, contactTime: 7.935,
                                           kickingFoot: .right, storedValue: value) == .failure(.noBall))
        #expect(MeasurementInspection.make(kind: .plantToBall, timeline: out.kickerTimeline, football: track, contactTime: nil,
                                           kickingFoot: .right, storedValue: value) == .failure(.noContact))
        #expect(MeasurementInspection.make(kind: .plantToBall, timeline: nil, football: track, contactTime: 7.935,
                                           kickingFoot: .right, storedValue: value) == .failure(.noPose))
        #expect(MeasurementInspection.make(kind: .plantToBall, timeline: out.kickerTimeline, football: track, contactTime: 7.935,
                                           kickingFoot: .right, storedValue: nil) == .failure(.noMeasurement))
    }

    // MARK: E — Athlete Report 4.0 wording (records built from SYNTHETIC engine runs)

    private static func stored(_ key: KickMetricKey, _ value: Double?, _ confidence: Double?) -> StoredMetricRecord {
        StoredMetricRecord(key: key.rawValue, value: value, unit: key.definition.unit, confidence: confidence,
                           status: value == nil ? .unavailable : .estimated, phase: key.definition.phase)
    }

    private func rearRecord() -> AnalysisRecord {
        var r = PresentationTests.record(.fieldGoal)
        r.overallScore = nil
        r.confidence = nil
        r.categories = KickMetricCatalog.scoredCategories.map { StoredCategoryRecord(category: $0, score: nil, confidence: nil, status: .unavailable, summary: nil) }
        let available = [Self.stored(.lateralTrunkLeanAtContact, 9.609, 0.696), Self.stored(.plantFootWidth, -0.533, 0.584),
                         Self.stored(.plantBallLateralOffset, 0.705, 0.83), Self.stored(.plantLateralMovement, 0.16, 0.65)]
        r.metrics = KickMetricKey.allCases.map { k in available.first { $0.key == k.rawValue } ?? Self.stored(k, nil, nil) }
        r.observations = []
        return r
    }

    private func report(_ r: AnalysisRecord, view: ComparableView, others: [RankingEntry] = [], recording: RecordingFlags = RecordingFlags()) -> PerformanceReport {
        PerformanceReport.make(.init(presentation: AnalysisPresentationBuilder.make(r), record: r, view: view, others: others, recording: recording))
    }

    @Test func recordingAdviceIsNotPresentedAsTraining() {
        let rep = report(rearRecord(), view: .depth)
        #expect(rep.focus?.heading == "For a better analysis")
        #expect(PerformanceReport.Focus.practice(title: "x", cue: "y", monitor: "z").heading == "Next training focus")
        #expect(!rep.measurements.isEmpty)
        for m in rep.measurements {
            #expect(!m.context.isEmpty, "\(m.key) needs a context line")
            #expect(m.inspectable == (m.key == .plantBallLateralOffset || m.key == .plantFootWidth), "\(m.key)")
            #expect(!m.valueText.contains("body length"))
        }
        #expect(rep.measurements.first { $0.key == .plantBallLateralOffset }?.valueText == "0.70 torso lengths · plant-leg side", "0.705 is binary 0.70499…")
        #expect(rep.measurements.first { $0.key == .plantFootWidth }?.valueText == "0.53 torso lengths · kicking-leg side")
    }

    @Test func theContactAreaSaysWhatItMeasures() {
        let row = PerformanceReport.AreaRow(category: .contact, title: "Body Position at Contact", score: 97, label: .init(score: 97),
                                            quality: .fair, standing: PersonalRanking.standing(97, others: []))
        #expect(row.note == "Posture and body movement at contact — not how the foot struck the ball.")
        #expect(row.accessibilityText.contains("not how the foot struck the ball"))
        #expect(PerformanceReport.AreaRow(category: .approach, title: "Approach", score: 77, label: .init(score: 77),
                                          quality: .fair, standing: PersonalRanking.standing(97, others: [])).note == nil)
    }

    @Test func everyImprovementShowsItsEvidenceAndWhatToWatch() {
        let rep = report(PresentationTests.record(.fieldGoal), view: .side)
        for i in rep.improvements {
            #expect(!i.evidence.isEmpty && !i.watch.isEmpty && !i.cue.isEmpty, "\(i.id)")
        }
    }

    // MARK: F — personal-history quality control (hand-built entries)

    private func entry(_ n: Double, _ value: Double?, cropped: Bool = false, blocking: Bool = false) -> RankingEntry {
        var e = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_800_000_000 + n * 86_400), kickType: .fieldGoal,
                             view: .depth, engineVersion: PoseVideoAnalysisService.version, completed: true, overallScore: nil,
                             categoryScores: [:], recording: RecordingFlags(cropped: cropped, blocking: blocking))
        if let value { e.metrics[RankingEntry.metricKey(.plantBallLateralOffset)] = value }
        return e
    }

    @Test func historyLeavesOutCroppedAndBlockingRecordingsAndSkipsMissingValues() throws {
        let current = entry(10, 0.70)
        let others = [entry(1, 0.60), entry(2, 0.64), entry(3, nil), entry(4, 0.62), entry(5, 0.10, cropped: true), entry(6, 2.0, blocking: true)]
        let eligibility = PersonalRanking.eligibility(for: current, among: others + [current])
        let c = PersonalRanking.consistency(current: current, eligibility: eligibility)
        let usual = try #require(c.metrics.first { $0.key == .plantBallLateralOffset })
        #expect(usual.count == 3, "three earlier eligible values; the missing one skipped, never zero")
        #expect(abs(usual.mean - 0.62) < 1e-9, "the current kick is NOT in its own usual")
        #expect(abs(usual.spread - 0.02) < 1e-9)
        #expect(c.excluded["recording quality too limited"] == 1)
        #expect(c.excluded.values.reduce(0, +) == 2)
        #expect(c.currentExcludedReason == nil)
        // Only two earlier eligible values → no usual at all.
        let few = PersonalRanking.consistency(current: current, eligibility: PersonalRanking.eligibility(for: current, among: Array(others.prefix(2)) + [current]))
        #expect(few.metrics.isEmpty)
        // A cropped current kick: values shown, not added to history, no trend.
        let cropped = entry(10, 0.70, cropped: true)
        let cc = PersonalRanking.consistency(current: cropped, eligibility: PersonalRanking.eligibility(for: cropped, among: others + [cropped]))
        #expect(cc.currentExcludedReason?.contains("beginning of the clip") == true)
        #expect(cc.improving == nil)
    }

    @Test func croppedMeansTheKickIsAtTheVeryStartOfTheClip() {
        #expect(RecordingFlags.croppedContactSeconds == 0.6)
        #expect(!RecordingFlags(cropped: true).eligibleForMeasurementHistory)
        #expect(!RecordingFlags(blocking: true).eligibleForMeasurementHistory)
        #expect(RecordingFlags().eligibleForMeasurementHistory)
    }

    // MARK: Five reference contacts (regression)

    @Test func theReferenceContactsAreUnchanged() {
        // REAL device series: rear 7.602 s with the device's ball timing.
        let rear = KickPhaseDetector.detect(RealReferenceClipRear.signals, kickType: .fieldGoal, perspective: .depthAway,
                                            ballContact: AutomaticBallContact(lastStationaryTime: 3.833, firstMovementTime: 3.9, basis: "displacedDetections", detectorName: "YOLOX-S"))
        #expect(abs((rear.estimatedContactTime ?? 0) - 3.867) < 0.002)
        // REAL device series: side 6.502 s (pose 2.467 s; ball 2.467–2.500 s narrows within it).
        let side = KickPhaseDetector.detect(RealReferenceClip220.signals, kickType: .fieldGoal)
        #expect(abs((side.estimatedContactTime ?? 0) - 2.467) < 0.002)
        // IMG_1709 (real frames, MediaPipe) is covered by `Biomechanics30Tests` (7.935 s);
        // 9.068 s and 3.663 s are SYNTHETIC reconstructions in `ContactIntelligence29Tests`
        // and `BallFusionTests` (no evidence bundle of either recording is available).
    }
}

extension MeasurementInspection.Failure: CustomStringConvertible {
    public var description: String { message }
}
