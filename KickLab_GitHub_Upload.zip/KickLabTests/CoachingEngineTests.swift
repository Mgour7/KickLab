import Foundation
import Testing
@testable import KickLab

@Suite("Rule-based coaching")
struct CoachingEngineTests {
    let profile = BiomechanicsProfile.standard(for: .fieldGoal)
    let seed = UUID(uuidString: "11111111-2222-3333-4444-555555555555")!

    private func findings(_ available: [KickMetricMeasurement]) -> [CoachingFinding] {
        CoachingEngine.findings(for: measurements(available), profile: profile)
    }

    private func rules(_ f: [CoachingFinding]) -> [CoachingRuleKey] { f.map(\.rule) }

    // MARK: Individual rules

    /// Build 18 (engine 3.0.0): plant timing is measured and shown, but no plant-timing
    /// advice is given — no validated criterion says a particular interval is better.
    @Test func plantTimingIsNeverCoached() {
        for v in [0.02, 0.04, 0.18, 0.40, 0.6] {
            #expect(findings([measured(.plantToContactTime, v, confidence: 0.95)]).isEmpty, "\(v)")
        }
        // The rule keys stay decodable for analyses that issued them before 3.0.0.
        #expect(CoachingRuleKey(rawValue: "plant.timingLate") == .plantLate)
        #expect(CoachingRuleKey(rawValue: "plant.timingEarly") == .plantEarly)
    }

    @Test func plantStabilityRules() {
        let unstable = findings([measured(.plantFootDrift, 0.5)])
        #expect(rules(unstable) == [.plantUnstable])
        #expect(unstable[0].severity == .moderate, "(0.5 − 0.3) ÷ 0.4 = 0.5")
        #expect(unstable[0].observed == "Plant foot moved 0.50 body lengths around estimated contact.")

        #expect(rules(findings([measured(.plantFootDrift, 0.05, confidence: 0.8)])) == [.plantStable])
        #expect(findings([measured(.plantFootDrift, 0.05, confidence: 0.6)]).isEmpty, "KEEP needs ≥ 0.7 confidence")
        #expect(findings([measured(.plantFootDrift, 0.2)]).isEmpty, "between stable and unstable: nothing to say")
    }

    @Test func torsoLeanRules() {
        let back = findings([measured(.torsoLeanAtContact, -35)])
        #expect(rules(back) == [.torsoLeaningBack])
        #expect(back[0].observed == "Torso was leaning back 35° at estimated contact.")
        #expect(back[0].cue == "Keep your chest over the ball at contact.")
        #expect(rules(findings([measured(.torsoLeanAtContact, 22)])) == [.torsoLeaningForward])
        #expect(findings([measured(.torsoLeanAtContact, -10)]).isEmpty)
    }

    @Test func kneeExtensionRules() {
        #expect(rules(findings([measured(.kickingKneeAngleAtContact, 115)])) == [.limitedKneeExtension])
        #expect(rules(findings([measured(.kickingKneeAngleAtContact, 170)])) == [.fullKneeExtension])
        #expect(findings([measured(.kickingKneeAngleAtContact, 145)]).isEmpty)
    }

    @Test func followThroughRules() {
        let short = findings([measured(.followThroughDuration, 0.11)])
        #expect(rules(short) == [.followThroughShort])
        #expect(short[0].severity == .low)
        #expect(rules(findings([measured(.followThroughFootHeight, 1.4)])) == [.highFinish])
    }

    @Test func approachRhythmRuleIsTwoSided() {
        let slowing = findings([measured(.approachLateSpeedChange, -50)])
        #expect(rules(slowing) == [.approachSpeedChange])
        #expect(slowing[0].observed == "Approach speed dropped 50% in the last 0.2 s before the plant.")
        let surging = findings([measured(.approachLateSpeedChange, 60)])
        #expect(surging[0].observed == "Approach speed rose 60% in the last 0.2 s before the plant.")
        #expect(findings([measured(.approachLateSpeedChange, 20)]).isEmpty)
    }

    @Test func severityScalesWithDistancePastTheThreshold() {
        #expect(CoachingEngine.severity(value: 0.35, threshold: 0.3, span: 0.4) == .low)
        #expect(CoachingEngine.severity(value: 0.5, threshold: 0.3, span: 0.4) == .moderate)
        #expect(CoachingEngine.severity(value: 0.7, threshold: 0.3, span: 0.4) == .high)
        #expect(CoachingEngine.severity(value: 95, threshold: 130, span: 40) == .high)
    }

    // MARK: Confidence gate

    @Test func noCoachingClaimWithoutEnoughConfidence() {
        #expect(findings([measured(.torsoLeanAtContact, -40, confidence: 0.49)]).isEmpty)
        #expect(rules(findings([measured(.torsoLeanAtContact, -40, confidence: 0.5)])) == [.torsoLeaningBack])
        let unavailable = KickMetricMeasurement.unavailable(.plantFootDrift, reason: .missingJoints)
        #expect(CoachingEngine.findings(for: [unavailable], profile: profile).isEmpty)
    }

    // MARK: Ranking

    @Test func rankingIsDeterministicAndCapped() {
        let all = findings([
            measured(.approachLateSpeedChange, -60, confidence: 0.7),  // sharp change: (60−35)/50 = 0.5 → moderate
            measured(.plantFootDrift, 0.75, confidence: 0.6),          // unstable: high
            measured(.torsoLeanAtContact, -27, confidence: 0.9),       // back: low
            measured(.kickingKneeAngleAtContact, 100, confidence: 0.8),// limited: (130−100)/40 = 0.75 → high
            measured(.followThroughFootHeight, 2, confidence: 0.9),    // KEEP
        ])
        let improves = all.filter { $0.kind == .improve }
        // high (plant before swing by category order), high, moderate, then low.
        let order: [CoachingRuleKey] = improves.map(\.rule)
        let expectedOrder: [CoachingRuleKey] = [.plantUnstable, .limitedKneeExtension, .approachSpeedChange, .torsoLeaningBack]
        let ranks: [Int?] = improves.map(\.rank)
        let expectedRanks: [Int?] = [0, 1, 2, 3]
        let issued: [Bool] = improves.map(\.issued)
        #expect(order == expectedOrder)
        #expect(ranks == expectedRanks)
        #expect(issued == [true, true, true, false], "at most 3 IMPROVEs are issued")
        let keep = all.first { $0.kind == .keep }
        #expect(keep?.rank == 0)
        #expect(keep?.issued == true)
        // Same input, same order.
        #expect(all == findings([
            measured(.kickingKneeAngleAtContact, 100, confidence: 0.8),
            measured(.followThroughFootHeight, 2, confidence: 0.9),
            measured(.torsoLeanAtContact, -27, confidence: 0.9),
            measured(.plantFootDrift, 0.75, confidence: 0.6),
            measured(.approachLateSpeedChange, -60, confidence: 0.7),
        ]))
    }

    @Test func tiesBreakByConfidenceThenRuleKey() {
        // Same severity (low) and different categories → category order: plant before contact.
        let f = findings([measured(.torsoLeanAtContact, -27, confidence: 0.9), measured(.plantFootDrift, 0.35, confidence: 0.6)])
        let order: [CoachingRuleKey] = f.filter { $0.kind == .improve }.map(\.rule)
        let expected: [CoachingRuleKey] = [.plantUnstable, .torsoLeaningBack]
        #expect(order == expected)
    }

    // MARK: Drafts

    @Test func draftsPairEachImproveWithItsCue() {
        let f = findings([measured(.plantFootDrift, 0.5), measured(.followThroughFootHeight, 2, confidence: 0.9)])
        let drafts = CoachingEngine.drafts(for: f, seed: seed)
        #expect(drafts.map(\.kind) == [.improve, .cue, .keep])
        let improve = drafts[0]
        let cue = drafts[1]
        #expect(improve.message == "Plant foot moved 0.50 body lengths around estimated contact. A plant foot that slides or rolls shifts the hips and makes contact harder to repeat.")
        #expect(improve.severity == .moderate)
        #expect(improve.confidence == 0.8)
        #expect(improve.priority == 0)
        #expect(improve.comparisonBasis == .absolute)
        #expect(improve.evidenceMetricKeys == ["plant.footDrift"])
        #expect(improve.ruleKey == "plant.unstable")
        #expect(improve.source == .engine)
        #expect(cue.message == "Drive the plant foot into the ground and keep it still through the ball.")
        #expect(cue.relatedObservationID == improve.id)
        #expect(cue.severity == nil)
        #expect(drafts[2].severity == nil)

        var existing: [ExistingObservationRef] = []
        for draft in drafts {
            #expect(AnalysisResultValidator.validate(draft, existing: existing).isEmpty)
            existing.append(ExistingObservationRef(id: draft.id, kind: draft.kind))
        }
    }

    @Test func suppressedFindingsAreNotStored() {
        let f = findings([
            measured(.approachLateSpeedChange, -60), measured(.plantFootDrift, 0.75),
            measured(.torsoLeanAtContact, -27), measured(.kickingKneeAngleAtContact, 100),
        ])
        let drafts = CoachingEngine.drafts(for: f, seed: seed)
        #expect(drafts.filter { $0.kind == .improve }.count == 3)
        #expect(drafts.filter { $0.kind == .cue }.count == 3)
        #expect(!drafts.contains { $0.ruleKey == CoachingRuleKey.torsoLeaningBack.rawValue })
        #expect(f.contains { $0.rule == .torsoLeaningBack && !$0.issued }, "still kept in the artifact")
    }

    @Test func observationIDsAreDeterministicPerSeed() {
        let f = findings([measured(.plantFootDrift, 0.5)])
        let a = CoachingEngine.drafts(for: f, seed: seed)
        let b = CoachingEngine.drafts(for: f, seed: seed)
        let other = CoachingEngine.drafts(for: f, seed: UUID(uuidString: "99999999-2222-3333-4444-555555555555")!)
        #expect(a == b)
        #expect(a[0].id != other[0].id)
        #expect(a[0].id != a[1].id)
        #expect(DeterministicID.make(seed: seed, name: "x") == DeterministicID.make(seed: seed, name: "x"))
        #expect(DeterministicID.make(seed: seed, name: "x") != DeterministicID.make(seed: seed, name: "y"))
    }

    @Test func wordingMakesNoMedicalClaims() {
        let everything = findings([
            measured(.plantToContactTime, 0.04), measured(.plantFootDrift, 0.75), measured(.torsoLeanAtContact, -40),
            measured(.kickingKneeAngleAtContact, 100), measured(.followThroughDuration, 0.11),
            measured(.approachLateSpeedChange, -60),
        ]) + findings([measured(.plantToContactTime, 0.5), measured(.torsoLeanAtContact, 30)])
        let banned = ["injur", "pain", "medical", "diagnos", "strain", "tear", "sprain"]
        for f in everything {
            let text = (f.observed + " " + f.whyItMatters + " " + (f.cue ?? "")).lowercased()
            for word in banned { #expect(!text.contains(word), "\(f.rule): \(word)") }
        }
    }

    @Test func endToEndScenariosProduceTheExpectedCoaching() {
        typealias Script = SyntheticPose.KickScript
        var lean = Script.fieldGoal
        lean.torsoLeanDegrees = -35
        var knee = Script.fieldGoal
        knee.kickingKneeAngle = 115
        var slip = Script.fieldGoal
        slip.plantSlip = 0.075
        var late = Script.fieldGoal
        late.plantTime = 1.35
        late.approachEnd = 1.4
        var early = Script.fieldGoal
        early.plantTime = 1.0
        early.approachEnd = 1.05
        var short = Script.fieldGoal
        short.swingStopsAt = 1.5

        func improveRules(_ s: Script) -> [String?] {
            SyntheticBiomechanics.analyze(s).observationDrafts.filter { $0.kind == .improve }.map(\.ruleKey)
        }
        #expect(improveRules(.fieldGoal).isEmpty)
        #expect(improveRules(lean) == ["contact.torsoLeaningBack"])
        #expect(improveRules(knee) == ["swing.limitedKneeExtension"])
        #expect(improveRules(slip) == ["plant.unstable"])
        // Build 18: a late or early plant is measured but never coached.
        #expect(improveRules(late).isEmpty)
        #expect(improveRules(early).isEmpty)
        #expect(improveRules(short) == ["followThrough.short"])
        // The clean kick earns a KEEP for its stable plant.
        #expect(SyntheticBiomechanics.analyze(.fieldGoal).observationDrafts.map(\.ruleKey) == ["plant.stable"])
    }
}
