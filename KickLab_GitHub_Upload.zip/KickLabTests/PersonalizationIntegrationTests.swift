import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Returns the synthetic Step 8 results and names the artifact folder after the analysis,
/// like the real engine does.
final class FolderPerAnalysisEngine: VideoAnalysisService, @unchecked Sendable {
    var engineVersion: String { "scripted-folder-1" }
    var availability: VideoAnalysisAvailability { .available }

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        PreparedVideoAnalysis(requestID: request.id, engineVersion: engineVersion, usableVideoIDs: request.inputVideoIDs,
                              rejectedInputs: [], estimatedFrameCount: nil)
    }

    func analyze(_ request: VideoAnalysisRequest, progress: @escaping @Sendable (VideoAnalysisProgress) -> Void) async throws -> VideoAnalysisResult {
        let r = ScriptedResults.synthetic
        return VideoAnalysisResult(requestID: request.id, engineVersion: engineVersion, metrics: r.metrics, categoryScores: r.scores,
                                   observations: r.observations, overallConfidence: r.overallConfidence, overallScore: r.overallScore,
                                   artifactsRelativePath: request.options.artifactsDirectoryID?.uuidString, poseSummary: nil)
    }
}

/// Requires Xcode: Step 10 personalization against real SwiftData and files.
@MainActor
@Suite("Step 10 personalization with stored kicks")
struct PersonalizationIntegrationTests {
    /// Analyzes `count` new field goals of `athlete` through the app's runner.
    @discardableResult
    private func analyzeKicks(_ x: AppFixture, athlete: Athlete, count: Int, result: KickResult = .made) async throws -> [BiomechanicsAnalysis] {
        var analyses: [BiomechanicsAnalysis] = []
        for _ in 0..<count {
            let kick = try x.f.makeKick(for: athlete, draft: .fieldGoal(result))
            let video = try await x.importVideo(to: kick)
            let outcome = try await x.app.services.analysisRunner.run(kick: kick, videos: [video])
            analyses.append(outcome.analysis)
        }
        return analyses
    }

    @Test func storedHistoryIsFlattenedFaithfully() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let analyses = try await analyzeKicks(x, athlete: athlete, count: 2)
        let learning = x.app.services.learning
        let history = learning.history(for: athlete)
        #expect(history.count == 2)
        let first = try #require(history.first { $0.analysisID == analyses[0].id })
        #expect(first.analysisCompleted)
        #expect(first.kickType == .fieldGoal)
        #expect(first.kickingFoot == .right)
        #expect(first.outcome.result == .made)
        #expect(first.outcome.distanceYards == 40)
        #expect(first.metrics.count == KickMetricKey.allCases.count)
        let drift = try #require(first.metrics[.plantFootDrift])
        let stored = try #require(analyses[0].metrics?.first { $0.metricKey == KickMetricKey.plantFootDrift.rawValue })
        #expect(drift.value == stored.value)
        #expect(drift.confidence == stored.confidence)
        #expect(drift.cameraAngle == stored.sourceAngle)
        #expect(drift.definitionVersion == stored.metricDefinitionVersion)

        let general = learning.generalFindings(analyses[0])
        #expect(general.contains { $0.kind == .improve && $0.cue != nil }, "IMPROVE paired with its CUE")
    }

    @Test func coachingNeverComparesAKickWithItself() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let analyses = try await analyzeKicks(x, athlete: athlete, count: 4)
        let coaching = try #require(try x.app.services.learning.coaching(for: analyses[3]))
        #expect(coaching.report.comparableKickCount == 3)
        #expect(coaching.report.maturity == .emerging)
        #expect(coaching.report.learningMessage == PersonalCoachCopy.learningMessage(needed: 5))
        #expect(coaching.selection?.active.sourceAnalysisIDs.contains(analyses[3].id) == false)
        #expect(coaching.report.findings.contains { $0.generalRuleKey != nil }, "Step 8 coaching is always included")
    }

    @Test func deletingAKickRebuildsTheProfile() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let analyses = try await analyzeKicks(x, athlete: athlete, count: 5)
        let before = try #require(try x.app.services.learning.coaching(for: analyses[4]))
        #expect(before.report.comparableKickCount == 4)
        let doomed = try #require(analyses[0].kick)
        try x.app.services.kicks.deleteKick(doomed)
        let after = try #require(try x.app.services.learning.coaching(for: analyses[4]))
        #expect(after.report.comparableKickCount == 3)
        #expect(after.report.profileFingerprint != before.report.profileFingerprint)
    }

    @Test func completedAnalysesStoreWhatKickLabKnewThen() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let analyses = try await analyzeKicks(x, athlete: athlete, count: 3)
        let recorder = x.app.services.personalizationRecorder
        let first = try #require(recorder.snapshot(for: analyses[0]))
        #expect(first.analysisID == analyses[0].id)
        #expect(first.report.comparableKickCount == 0, "nothing was known before the first kick")
        #expect(first.formatVersion == 1)
        let third = try #require(recorder.snapshot(for: analyses[2]))
        #expect(third.report.comparableKickCount == 2)
        let learnedFrom: Set<UUID> = Set(third.profile?.sourceAnalysisIDs ?? [])
        let earlier: Set<UUID> = [analyses[0].id, analyses[1].id]
        #expect(learnedFrom == earlier)

        // Later kicks never rewrite an earlier snapshot; "now" is computed fresh.
        try await analyzeKicks(x, athlete: athlete, count: 2)
        #expect(recorder.snapshot(for: analyses[0]) == first)
        #expect(try x.app.services.learning.coaching(for: analyses[0])?.report.comparableKickCount == 4)

        // An analysis without a personalization file (Step 7/8 era) simply has none.
        let older = try x.f.makeKick(for: athlete)
        let video = try x.f.addVideo(to: older, path: "k/old.mov")
        let oldAnalysis = try x.f.makeCompletedAnalysis(for: older, video: video, completedAt: .now)
        #expect(recorder.snapshot(for: oldAnalysis) == nil)
    }

    @Test func changingKickingFootStartsASeparateBaseline() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let athleteID = athlete.id
        x.app.load()
        try await analyzeKicks(x, athlete: athlete, count: 3)

        let editor = AthleteEditorViewModel(athleteID: athleteID, app: x.app)
        editor.kickingFoot = .left
        let changedAt = Date.now   // after the three analyses, before the next one
        #expect(editor.save(app: x.app, now: changedAt) == athleteID)
        let state = x.app.services.personalizationState.state(for: athleteID)
        #expect(state.footChanges.map(\.to) == [.left])

        let history = x.app.services.learning.history(for: athlete)
        #expect(history.allSatisfy { $0.kickingFoot == .right }, "earlier analyses keep the foot they used")

        // A new left-footed analysis isn't compared with the right-footed kicks.
        let newKick = try await analyzeKicks(x, athlete: athlete, count: 1)
        let coaching = try #require(try x.app.services.learning.coaching(for: newKick[0]))
        #expect(coaching.report.comparableKickCount == 0)

        // Deleting the athlete removes its personalization state.
        let deletion = AthleteDeletionViewModel(athleteID: athleteID)
        deletion.prepare(app: x.app)
        deletion.typedConfirmation = athlete.fullName
        #expect(deletion.delete(app: x.app))
        #expect(x.app.services.personalizationState.state(for: athleteID) == AthletePersonalizationState())
    }

    @Test func resultsScreenShowsTheCoach() async throws {
        let x = try AppFixture(engine: FolderPerAnalysisEngine())
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        x.app.load()
        let analyses = try await analyzeKicks(x, athlete: athlete, count: 2)
        let results = AnalysisResultsViewModel(analysisID: analyses[1].id)
        results.load(app: x.app)
        let coach = try #require(results.state.value?.coach)
        #expect(coach.learningMessage == PersonalCoachCopy.learningMessage(needed: 7))
        #expect(!coach.fixes.isEmpty, "Step 8 priorities stay primary while personal data is thin")
        await results.loadSnapshot(app: x.app)
        #expect(results.snapshotNote == "When this kick was analyzed, KickLab had 1 comparable field goal to learn from.")

        let home = HomeViewModel()
        home.load(app: x.app)
        #expect(home.state.value?.topPriority?.observed == coach.fixes.first?.headline)
    }
}
