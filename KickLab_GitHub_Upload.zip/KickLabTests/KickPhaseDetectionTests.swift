import Foundation
import Testing
@testable import KickLab

@Suite("Pose signals and kick-phase detection (synthetic timelines)")
struct KickPhaseDetectionTests {
    // MARK: Signals

    @Test func signalsUseBodyLengthsAndTravelDirection() {
        let signals = SyntheticPose.signals(.fieldGoal)
        #expect(near(signals.bodyScale, SyntheticPose.torso, 1e-6))
        #expect(signals.travelDirection == 1)
        #expect(signals.kickingFoot == .right)
        #expect(signals.timestamps.count == 121)

        // Mid-approach body speed: 0.25 u/s ÷ 0.15 = 1.67 body lengths/s.
        let i = signals.timestamps.firstIndex { abs($0 - 0.9) < 1e-6 }!
        #expect(near(signals.values(.bodyCenterSpeed)[i], 0.25 / 0.15, 0.02))
        #expect(near(signals.values(.bodyForwardVelocity)[i], 0.25 / 0.15, 0.02))
        // Standing straight; leg straight down.
        #expect(near(signals.values(.torsoLean)[i], 0, 1e-6))
        #expect(signals.values(.kickingKneeAngle)[i] != nil)

        let peak = signals.values(.kickingAnkleSpeed).compactMap { $0 }.max() ?? 0
        #expect(peak > 8, "1.5 u/s ÷ 0.15 ≈ 10 body lengths/s")
        for key in PoseSignalKey.allCases { #expect(signals.coverage(key) == 1, "\(key)") }
    }

    @Test func travelDirectionIsDetectedBothWays() {
        var leftward = SyntheticPose.KickScript.fieldGoal
        leftward.startX = 0.7
        leftward.direction = -1
        let signals = SyntheticPose.signals(leftward)
        #expect(signals.travelDirection == -1)
        let i = signals.timestamps.firstIndex { abs($0 - 0.9) < 1e-6 }!
        #expect(signals.values(.bodyForwardVelocity)[i].map { $0 > 1 } == true, "forward is positive whichever way they run")
    }

    @Test func anglesAndVelocityHelpers() {
        let right = PoseSignalExtractor.angle(NormalizedPoint(x: 0, y: 1), NormalizedPoint(x: 0, y: 0), NormalizedPoint(x: 1, y: 0))
        #expect(near(right, 90, 1e-9))
        #expect(PoseSignalExtractor.angle(nil, NormalizedPoint(x: 0, y: 0), NormalizedPoint(x: 1, y: 0)) == nil)
        #expect(PoseSignalExtractor.angle(NormalizedPoint(x: 0, y: 0), NormalizedPoint(x: 0, y: 0), NormalizedPoint(x: 1, y: 0)) == nil)

        let v = PoseSignalExtractor.velocity(
            [NormalizedPoint(x: 0, y: 0), nil, NormalizedPoint(x: 0.2, y: 0), NormalizedPoint(x: 0.3, y: 0)],
            [0, 0.1, 0.2, 0.3]
        )
        #expect(v[0] == nil, "no neighbor on either side")
        #expect(v[1] == nil)
        #expect(near(v[2]?.x, 1, 1e-9), "one-sided at a gap")
        #expect(near(v[3]?.x, 1, 1e-9))
    }

    @Test func aspectRatioScalesHorizontalDistances() {
        var t = SyntheticPose.timeline(.fieldGoal)
        t.displayAspectRatio = 2
        let wide = PoseSignalExtractor.extract(from: t, kickingFoot: .right)
        let i = wide.timestamps.firstIndex { abs($0 - 0.9) < 1e-6 }!
        // Horizontal motion counts double; the torso is vertical so the scale is unchanged.
        let expectedWideSpeed: Double = 2.0 * 0.25 / 0.15
        let wideSpeed: Double? = wide.values(.bodyCenterSpeed)[i]
        #expect(near(wideSpeed, expectedWideSpeed, 0.04))
    }

    // MARK: Field goal

    @Test func fieldGoalPhasesMatchGroundTruth() {
        let script = SyntheticPose.KickScript.fieldGoal
        let result = KickPhaseDetector.detect(SyntheticPose.signals(script), kickType: .fieldGoal)
        #expect(result.support == .full)
        #expect(result.phases.map(\.phase) == KickPhase.allCases)

        let contact = result.phase(.contact)
        #expect(contact.status == .estimated, "no ball tracking: contact is an estimate")
        #expect(near(contact.representativeTime, script.expectedContact, 0.034))
        #expect(near(result.estimatedContactTime, 1.4, 0.034))
        #expect(contact.evidence.contains(.kickingAnkleSpeed))

        let plant = result.phase(.plant)
        #expect(plant.status == .detected)
        #expect(near(plant.representativeTime, script.plantTime, 0.05))
        #expect(near(plant.endTime, contact.representativeTime ?? -1, 1e-9))
        #expect(near(result.plantTime, 1.2, 0.05))

        let approach = result.phase(.approach)
        #expect(approach.status == .detected)
        #expect(near(approach.startTime, script.approachStart, 0.05))
        #expect(near(approach.endTime, plant.representativeTime ?? -1, 1e-9))

        let setup = result.phase(.setup)
        #expect(setup.status == .detected)
        #expect(setup.startTime == 0)
        #expect(near(setup.endTime, approach.startTime ?? -1, 1e-9))

        let follow = result.phase(.followThrough)
        #expect(follow.status == .detected)
        #expect(near(follow.endTime, 1.57, 0.05))

        // Phases are in time order.
        let times = [setup.startTime, approach.startTime, plant.startTime, contact.startTime, follow.endTime].compactMap { $0 }
        #expect(times == times.sorted())
        #expect(result.overallConfidence > 0.5)
        #expect(result.overallConfidence <= 1)
        for phase in result.phases {
            #expect((0...1).contains(phase.confidence))
        }
    }

    @Test func patUsesThePlaceKickProfile() {
        let result = KickPhaseDetector.detect(SyntheticPose.signals(.fieldGoal), kickType: .pat)
        #expect(result.support == .full)
        #expect(result.phase(.plant).status == .detected)
    }

    @Test func leftFootedKickerIsDetectedFromLeftJoints() {
        var script = SyntheticPose.KickScript.fieldGoal
        script.kickingFoot = .left
        let result = KickPhaseDetector.detect(SyntheticPose.signals(script), kickType: .fieldGoal)
        #expect(result.phase(.plant).status == .detected)
        #expect(near(result.plantTime, 1.2, 0.05))
        #expect(near(result.estimatedContactTime, 1.4, 0.034))

        // Analyzing the same kick as right-footed swaps the legs: the "plant" ankle is
        // the swinging one, so no plant is found. Nothing silently assumes a side.
        let wrongSide = KickPhaseDetector.detect(SyntheticPose.signals(script, detectWith: .right), kickType: .fieldGoal)
        #expect(wrongSide.phase(.plant).status != .detected)
    }

    // MARK: Kickoff

    @Test func kickoffHasLongerApproach() {
        let script = SyntheticPose.KickScript.kickoff
        let result = KickPhaseDetector.detect(SyntheticPose.signals(script), kickType: .kickoff)
        #expect(result.support == .full)
        #expect(near(result.estimatedContactTime, script.expectedContact, 0.034))
        #expect(near(result.plantTime, script.plantTime, 0.05))
        let approach = result.phase(.approach)
        #expect(approach.status == .detected)
        #expect(near(approach.startTime, script.approachStart, 0.05))
        let approachStart: Double = approach.startTime ?? 0
        let approachEnd: Double = approach.endTime ?? 0
        let approachDuration: Double = approachEnd - approachStart
        #expect(approachDuration > 1.0)
    }

    @Test func shortApproachIsOnlyEstimatedForKickoff() {
        // A field-goal-length approach is too short for a kickoff profile.
        let result = KickPhaseDetector.detect(SyntheticPose.signals(.fieldGoal), kickType: .kickoff)
        #expect(result.phase(.approach).status == .estimated)
        #expect(result.notes.contains { $0.contains("approach was shorter") })
    }

    // MARK: Ambiguity and missing data

    @Test func twoEqualSwingsMakeContactAmbiguous() {
        var script = SyntheticPose.KickScript.fieldGoal
        script.extraSwingStart = 0.0          // a practice swing before the approach
        let result = KickPhaseDetector.detect(SyntheticPose.signals(script), kickType: .fieldGoal)
        let contact = result.phase(.contact)
        #expect(contact.status == .ambiguous)
        #expect(contact.confidence < 0.5)
        #expect(result.phase(.plant).status == .ambiguous || result.phase(.plant).status == .unavailable)
        #expect(result.notes.contains { $0.contains("More than one kicking motion") })
    }

    @Test func missingLegDataMakesEverythingUnavailable() {
        var timeline = SyntheticPose.timeline(.fieldGoal)
        for i in timeline.samples.indices where i % 3 != 0 {
            timeline.samples[i].joints[.rightAnkle] = .unavailable
        }
        let signals = PoseSignalExtractor.extract(
            from: PoseTimelineProcessor.process(timeline, configuration: PoseProcessingConfiguration(maximumInterpolationGapSeconds: 0.01)),
            kickingFoot: .right
        )
        let result = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        #expect(result.phases.allSatisfy { $0.status == .unavailable })
        #expect(result.overallConfidence == 0)
        #expect(result.plantTime == nil)
        #expect(result.estimatedContactTime == nil)
    }

    @Test func noKickingMotionIsNotInvented() {
        var script = SyntheticPose.KickScript.fieldGoal
        script.swingDistance = 0.01           // a shuffle, not a kick
        let result = KickPhaseDetector.detect(SyntheticPose.signals(script), kickType: .fieldGoal)
        #expect(result.estimatedContactTime == nil)
        #expect(result.notes.contains("No kicking motion was found."))
    }

    @Test func emptySignalsAreUnavailable() {
        let result = KickPhaseDetector.detect(.empty, kickType: .fieldGoal)
        #expect(result.phases.count == KickPhase.allCases.count)
        #expect(result.phases.allSatisfy { !$0.isAvailable })
    }

    // MARK: Kick-type support

    @Test func puntIsLimited() {
        let result = KickPhaseDetector.detect(SyntheticPose.signals(.fieldGoal), kickType: .punt)
        #expect(result.support == .limited)
        #expect(result.phase(.contact).status == .estimated)
        #expect(result.phase(.followThrough).isAvailable)
        #expect(result.phase(.plant).status == .unavailable)
        #expect(result.phase(.approach).status == .unavailable)
        #expect(result.phase(.setup).status == .unavailable)
    }

    @Test func unknownKickTypeIsUnsupported() {
        let result = KickPhaseDetector.detect(SyntheticPose.signals(.fieldGoal), kickType: .unknown)
        #expect(result.support == .unsupported)
        #expect(result.phases.allSatisfy { $0.status == .unavailable })
    }

    @Test func detectionResultIsCodable() throws {
        let result = KickPhaseDetector.detect(SyntheticPose.signals(.fieldGoal), kickType: .fieldGoal)
        let decoded = try JSONDecoder().decode(KickPhaseDetectionResult.self, from: JSONEncoder().encode(result))
        #expect(decoded == result)
    }
}
