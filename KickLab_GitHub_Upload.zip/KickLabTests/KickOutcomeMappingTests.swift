import Foundation
import Testing
@testable import KickLab

/// Pure typed-outcome ↔ column mapping. No SwiftData; runs on any Swift toolchain.
@Suite("Typed outcome mapping")
struct KickOutcomeMappingTests {

    @Test(arguments: [
        KickOutcome.fieldGoal(FieldGoalOutcome(
            result: .made,
            distance: .measured(65.2, from: .primaryVideo, confidence: 0.94),
            accuracy: .manual(AccuracyCoordinate(x: 0.25, y: 0.6))
        )),
        KickOutcome.pat(FieldGoalOutcome(result: .blocked)),
        KickOutcome.kickoff(KickoffOutcome(
            distance: .manual(62),
            landing: .measured(KickoffLanding(yardLine: 3, zone: .left), from: .multiVideo, confidence: 0.8),
            touchback: false,
            outOfBounds: false,
            hangTime: .measured(4.05, from: .secondaryVideo, confidence: nil)
        )),
        KickOutcome.punt(PuntOutcome(distance: .manual(44), hangTime: .manual(4.6))),
    ])
    func outcomesRoundTripThroughColumns(outcome: KickOutcome) {
        let columns = KickOutcomeColumns(outcome: outcome)
        #expect(KickOutcome(kickType: outcome.kickType, columns: columns) == outcome)
    }

    @Test func videoMeasuredDistanceKeepsDecimalAndConfidence() {
        let columns = KickOutcomeColumns(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            distance: .measured(65.2, from: .primaryVideo, confidence: 0.94)
        )))
        #expect(columns.distanceYards == 65.2)
        #expect(columns.storedDistanceSource == "primaryVideo")
        #expect(columns.distanceConfidence == 0.94)
    }

    @Test func encodingClearsColumnsFromOtherKickTypes() {
        let columns = KickOutcomeColumns(outcome: .fieldGoal(FieldGoalOutcome(result: .made)))
        #expect(columns.landingYardLine == nil)
        #expect(columns.storedLandingSource == nil)
        #expect(columns.landingConfidence == nil)
        #expect(columns.touchback == nil)
        #expect(columns.outOfBounds == nil)
        #expect(columns.hangTimeSeconds == nil)
        #expect(columns.storedHangTimeSource == nil)
        #expect(columns.hangTimeConfidence == nil)
    }

    @Test func unknownKickTypeHasNoTypedOutcome() {
        #expect(KickOutcome(kickType: .unknown, columns: KickOutcomeColumns()) == nil)
    }

    @Test func missingSourceDecodesAsUnknownRatherThanManual() throws {
        let columns = KickOutcomeColumns(storedResult: "made", distanceYards: 38)
        let outcome = try #require(KickOutcome(kickType: .fieldGoal, columns: columns))
        guard case .fieldGoal(let fg) = outcome else {
            Issue.record("Expected a field goal outcome")
            return
        }
        #expect(fg.distance?.source == .unknown)
    }

    @Test func typeChangeAtColumnLevelClearsValuesAndProvenance() {
        let kickoff = KickOutcomeColumns(outcome: .kickoff(KickoffOutcome(
            distance: .measured(64.5, from: .primaryVideo, confidence: 0.9),
            landing: .measured(KickoffLanding(yardLine: -2, zone: .right), from: .multiVideo, confidence: 0.85),
            touchback: true,
            hangTime: .measured(4.2, from: .secondaryVideo, confidence: 0.8)
        )))
        #expect(kickoff.storedLandingSource == "multiVideo")

        let fieldGoal = KickOutcomeColumns(outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(41))))
        #expect(fieldGoal == KickOutcomeColumns(
            storedResult: "made",
            distanceYards: 41,
            storedDistanceSource: "manual"
        ))
    }

    @Test func resultAndAccuracyStayDistinct() {
        // A make recorded without a crossing point keeps accuracy nil, and an
        // accuracy recorded with an unknown result keeps the result unknown.
        let noAccuracy = KickOutcomeColumns(outcome: .fieldGoal(FieldGoalOutcome(result: .made)))
        #expect(noAccuracy.storedResult == "made")
        #expect(noAccuracy.accuracyX == nil && noAccuracy.storedAccuracySource == nil)

        let unknownResult = KickOutcomeColumns(outcome: .fieldGoal(FieldGoalOutcome(
            result: .unknown,
            accuracy: .manual(AccuracyCoordinate(x: 2.1))
        )))
        #expect(unknownResult.storedResult == "unknown")
        #expect(unknownResult.accuracyX == 2.1)
    }
}
