import Foundation
import Testing
@testable import KickLab

@Suite("Pose processing")
struct PoseProcessingTests {
    /// One joint (left ankle) over `xs.count` samples at 60 fps; nil = not detected.
    private func timeline(_ values: [(x: Double, confidence: Double)?]) -> KickerPoseTimeline {
        KickerPoseTimeline(samples: values.enumerated().map { i, value in
            KickerPoseSample(
                frameIndex: i, timestamp: Double(i) / 60,
                joints: value.map { [.leftAnkle: PosePoint(x: $0.x, y: 0.5, confidence: $0.confidence)] } ?? [:]
            )
        })
    }

    private func ankle(_ t: KickerPoseTimeline, _ i: Int) -> PosePoint? { t.samples[i].joints[.leftAnkle] }

    @Test func lowConfidencePointsBecomeUnavailable() {
        let t = PoseTimelineProcessor.applyConfidenceThreshold(timeline([(0.1, 0.9), (0.2, 0.1), (0.3, 0.3)]), minimum: 0.3)
        #expect(ankle(t, 0)?.status == .measured)
        #expect(ankle(t, 1)?.status == .unavailable)
        #expect(ankle(t, 2)?.status == .measured, "the threshold is inclusive")
    }

    @Test func shortGapsAreInterpolatedAndMarked() {
        // Measured at frames 0 and 3 (0.05 s apart): frames 1–2 are filled.
        let t = PoseTimelineProcessor.interpolateShortGaps(
            timeline([(0.0, 0.9), nil, nil, (0.3, 0.6), (0.4, 0.9)]), maximumGapSeconds: 0.1
        )
        #expect(ankle(t, 1)?.status == .interpolated)
        #expect(approximately(ankle(t, 1)?.x, 0.1))
        #expect(approximately(ankle(t, 2)?.x, 0.2))
        #expect(ankle(t, 2)?.confidence == 0.6, "interpolated confidence is the lower bound")
        #expect(ankle(t, 3)?.status == .measured)
    }

    @Test func longGapsStayUnavailable() {
        // Measured at 0 and 10 (0.167 s apart) → occlusion, not filled.
        var values: [(x: Double, confidence: Double)?] = [(0, 0.9)]
        values += Array(repeating: nil, count: 9)
        values += [(1, 0.9)]
        let t = PoseTimelineProcessor.interpolateShortGaps(timeline(values), maximumGapSeconds: 0.1)
        for i in 1...9 { #expect(ankle(t, i) == nil || ankle(t, i)?.status == .unavailable) }
    }

    @Test func gapsAtTheEndsAreNotExtrapolated() {
        let t = PoseTimelineProcessor.process(timeline([nil, (0.5, 0.9), (0.5, 0.9), (0.5, 0.9), nil]))
        #expect(ankle(t, 0)?.isAvailable != true)
        #expect(ankle(t, 4)?.isAvailable != true)
    }

    @Test func interpolationOnlyBridgesMeasuredPoints() {
        // A gap next to a low-confidence point: after thresholding the bridge is too long.
        let t = PoseTimelineProcessor.process(
            timeline([(0, 0.9), (0.1, 0.1), nil, nil, nil, nil, nil, (0.7, 0.9)]),
            configuration: PoseProcessingConfiguration(smoothingRadius: 0)
        )
        #expect(ankle(t, 3)?.isAvailable != true)
    }

    @Test func smoothingKeepsProvenanceAndNeverInventsPoints() {
        let raw = timeline([(0.0, 0.9), (0.3, 0.9), (0.0, 0.9), nil, nil, nil, nil, nil, nil, (0.5, 0.9)])
        let t = PoseTimelineProcessor.smooth(raw, radius: 1)
        #expect(approximately(ankle(t, 1)?.x, 0.1), "centered average of 0, 0.3, 0")
        #expect(ankle(t, 1)?.status == .measured)
        #expect(ankle(t, 1)?.confidence == 0.9)
        #expect(ankle(t, 4) == nil, "no point created in a gap")
        #expect(ankle(t, 9)?.x == 0.5, "an isolated point is left as is")
        #expect(PoseTimelineProcessor.smooth(raw, radius: 0) == raw)
    }

    @Test func configurationIsOneCodableValue() throws {
        let config = PoseProcessingConfiguration(minimumJointConfidence: 0.4, maximumInterpolationGapSeconds: 0.05, smoothingRadius: 2)
        let decoded = try JSONDecoder().decode(PoseProcessingConfiguration.self, from: JSONEncoder().encode(config))
        #expect(decoded == config)
        #expect(PoseProcessingConfiguration.standard.minimumJointConfidence == 0.3)
    }

    @Test func bodyPoseSummaries() {
        let body = SyntheticPose.body(center: NormalizedPoint(x: 0.5, y: 0.5))
        #expect(approximately(body.confidence, 0.9))
        #expect(body.center == NormalizedPoint(x: 0.5, y: 0.5))
        #expect(body.boundingBox?.contains(NormalizedPoint(x: 0.5, y: 0.6)) == true)
        var partial = body
        partial.joints[.leftHip] = .unavailable
        #expect(partial.center == NormalizedPoint(x: 0.5, y: 0.5), "falls back to root")
    }
}
