import Foundation
import Testing
@testable import KickLab

/// Build 21 Hotfix 2 — contact correction, discovery trace, session diagnostics, net and
/// camera-view settings. Pure logic with SYNTHETIC data (hand-built manifests and scan
/// frames). Nothing here has seen the athlete's real net-practice recording.
@Suite("Build 21 hotfix 2: contact correction, diagnostics, discovery trace")
struct TrainingSessionHotfix2Tests {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    private func session(context: RecordingContext? = nil) -> (TrainingSessionManifest, UUID) {
        var m = TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: UUID(), name: "Net practice", location: "Backyard",
                                                  defaults: SessionKickDetails(kickType: .fieldGoal, distanceYards: 30, hash: .center), now: now)
        m.recordingContext = context
        let s = TrainingSessionEditor.addSource(&m, id: UUID(), role: .unspecified, origin: .inAppRecording, fileExtension: "mov",
                                                status: .recording, now: now)
        TrainingSessionEditor.finalizeSource(&m, id: s.id, duration: 60, frameRate: 60, bytes: 90_000_000, now: now)
        m.processing.scan[s.id.uuidString] = .done
        return (m, s.id)
    }

    /// A kick at `contact` whose clip (26 s → 33 s for contact 30) was cut and analyzed automatically.
    private func analyzedKick(_ m: inout TrainingSessionManifest, source: UUID, contact: Double, outcome: ContactOutcome?, clipContact: Double?) throws -> UUID {
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: source, contact: contact, now: now)
        let i = try #require(m.candidates.firstIndex { $0.id == c.id })
        m.candidates[i].contactProvenance = .scan   // as if found by the scan
        m.candidates[i].discovery = .automatic
        SessionProcessingQueue.enqueueReady(&m)
        SessionProcessingQueue.markRunning(&m, c.id)
        SessionProcessingQueue.recordMaterialized(&m, c.id, kickID: UUID(), clipStartInSource: contact - 4,
                                                  clipTiming: ClipTimingRecord.make(requestedStart: contact - 4, requestedDuration: 7, exportedDuration: 7, info: nil))
        SessionProcessingQueue.recordAnalysis(&m, c.id, analysisID: UUID(), completed: outcome != nil, contactOutcome: outcome,
                                              clipContact: clipContact, contactUncertainty: 0.02,
                                              failureReason: outcome == nil ? "Contact not found" : nil, now: now)
        return c.id
    }

    // MARK: Contact correction (the release-blocking workflow)

    @Test func contactNotFoundCanBeCorrectedInTheClipAndReanalyzedWithoutDuplicates() throws {
        var (m, src) = session()
        let id = try analyzedKick(&m, source: src, contact: 30, outcome: .contactUnavailable, clipContact: nil)
        var c = try #require(m.candidate(id))
        let kickID = c.kickID
        #expect(c.status == .needsReview)
        #expect(SessionKickStatusText.contactNotFound(c))
        #expect(SessionKickStatusText.line(c) == "Contact not found — select contact frame.")
        #expect(SessionKickStatusText.nextStep(c) == .findContact)
        #expect(c.automaticContact?.outcome == ContactOutcome.contactUnavailable.rawValue, "the automatic result is kept")

        // Step to the frame in the kick's clip, Set Contact Here.
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: id, clipTime: 4.2, frameDuration: 1.0 / 60, now: now)
        c = try #require(m.candidate(id))
        #expect(abs((c.contactTime ?? 0) - 30.2) < 1e-9, "clip 4.2 s = recording 26 + 4.2")
        #expect(c.contactProvenance == .user && c.userContact?.timeline == .kickClip && c.userContact?.uncertainty == 1.0 / 60)

        // Save & Reanalyze: queued for the SAME kick, with the athlete's frame handed to the engine.
        try TrainingSessionEditor.requestReanalysis(&m, candidateID: id, now: now)
        #expect(SessionProcessingQueue.next(m)?.id == id)
        c = try #require(m.candidate(id))
        #expect(SessionKickStatusText.line(c) == "Reanalyzing with your contact frame…")
        #expect(TrainingSessionEditor.assistedContactClipTime(c, clipStartInSource: c.clipStartInSource) == 4.2)
        SessionProcessingQueue.markRunning(&m, id)
        SessionProcessingQueue.recordAnalysis(&m, id, analysisID: UUID(), completed: true, contactOutcome: .userSelectedContact,
                                              clipContact: 4.2, contactUncertainty: nil, assistedContactClipTime: 4.2, now: now)
        c = try #require(m.candidate(id))
        #expect(c.kickID == kickID, "the existing Kick is reused")
        #expect(m.candidates.count == 1 && m.attempts.count == 1, "one physical kick, counted once")
        #expect(c.status == .probable, "a human-chosen contact never makes a kick 'confirmed'")
        #expect(c.userContact?.reanalyzedAt != nil && c.userContact?.lastResult == "Reanalyzed using your contact frame.")
        #expect(c.automaticContact?.outcome == ContactOutcome.contactUnavailable.rawValue, "original automatic result still available")
        #expect(abs((c.contactTime ?? 0) - 30.2) < 1e-9)
        #expect(SessionKickStatusText.line(c) == "Analysis complete (your contact frame).")
    }

    @Test func aSuccessfulAutomaticContactCanBeCorrectedRepeatedly() throws {
        var (m, src) = session()
        let id = try analyzedKick(&m, source: src, contact: 30, outcome: .ballVerifiedContact, clipContact: 3.95)
        var c = try #require(m.candidate(id))
        #expect(c.status == .confirmed && c.contactProvenance == .analysis && abs((c.contactTime ?? 0) - 29.95) < 1e-9)
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: id, clipTime: 4.05, frameDuration: 1.0 / 60, now: now)
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: id, clipTime: 4.0, frameDuration: 1.0 / 60, now: now)
        c = try #require(m.candidate(id))
        #expect(c.userContact?.clipTime == 4.0, "the latest choice wins")
        #expect(c.automaticContact?.clipTime == 3.95 && c.automaticContact?.outcome == ContactOutcome.ballVerifiedContact.rawValue)
        let markers = KickContactMarkers.inClip(c, clipStart: 26)
        #expect(markers.automatic == 3.95 && markers.user == 4.0, "both markers are shown separately")
    }

    @Test func aContactChosenInTheRecordingIsMappedThroughTheClipStart() throws {
        var (m, src) = session()
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 31, now: now)
        try TrainingSessionEditor.setUserContact(&m, candidateID: c.id, sourceTime: 31.0, frameDuration: 1.0 / 60, now: now)
        #expect(TrainingSessionEditor.assistedContactClipTime(m.candidate(c.id)!, clipStartInSource: nil) == nil, "no clip yet")
        SessionProcessingQueue.recordMaterialized(&m, c.id, kickID: UUID(), clipStartInSource: 27.0)
        let mapped = TrainingSessionEditor.assistedContactClipTime(m.candidate(c.id)!, clipStartInSource: 27.0)
        #expect(mapped == 4.0)
        // Once the clip exists, a recording time outside it is refused (it would not be analyzed).
        #expect(throws: TrainingSessionEditor.EditError.outsideKickClip) {
            try TrainingSessionEditor.setUserContact(&m, candidateID: c.id, sourceTime: 40, frameDuration: nil, now: now)
        }
    }

    @Test func aFailedReanalysisKeepsTheAthletesFrameAndSaysWhy() throws {
        var (m, src) = session()
        let id = try analyzedKick(&m, source: src, contact: 30, outcome: .contactUnavailable, clipContact: nil)
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: id, clipTime: 0.3, frameDuration: 1.0 / 30, now: now)
        try TrainingSessionEditor.requestReanalysis(&m, candidateID: id, now: now)
        SessionProcessingQueue.markRunning(&m, id)
        SessionProcessingQueue.recordAnalysis(&m, id, analysisID: UUID(), completed: false, contactOutcome: nil, clipContact: nil,
                                              contactUncertainty: nil, assistedContactClipTime: 0.3,
                                              failureReason: "The kicker couldn't be followed.", now: now)
        let c = try #require(m.candidate(id))
        #expect(c.contactProvenance == .user && c.userContact?.clipTime == 0.3, "never silently replaced")
        #expect(c.userContact?.lastResult?.contains("The kicker couldn't be followed.") == true)
        #expect(c.analysis.lastError == "The kicker couldn't be followed.")
        #expect(c.status == .needsReview)
    }

    @Test func addKickHereNeverDuplicatesAKick() throws {
        var (m, src) = session()
        _ = try analyzedKick(&m, source: src, contact: 30, outcome: .ballVerifiedContact, clipContact: 4)
        #expect(throws: TrainingSessionEditor.EditError.duplicateKick) {
            _ = try TrainingSessionEditor.addKickHere(&m, sourceID: src, contact: 30.8, frameDuration: 1.0 / 60, now: now)
        }
        let added = try TrainingSessionEditor.addKickHere(&m, sourceID: src, contact: 48.5, frameDuration: 1.0 / 60, now: now)
        #expect(added.discovery == .manual && added.contactProvenance == .user && added.userContact?.timeline == .sourceRecording)
        SessionProcessingQueue.enqueueReady(&m)
        #expect(m.candidate(added.id)?.analysis.status == .queued, "a manually added kick enters the normal queue")
        #expect(DiscoveryHypothesis.of(added) == .userMarked)
    }

    @Test func reanalysisIsRefusedWhileRunningAndForRejectedKicks() throws {
        var (m, src) = session()
        let id = try analyzedKick(&m, source: src, contact: 30, outcome: .poseEstimatedContact, clipContact: 4)
        SessionProcessingQueue.markRunning(&m, id)
        #expect(throws: TrainingSessionEditor.EditError.alreadyAnalyzing) { try TrainingSessionEditor.requestReanalysis(&m, candidateID: id, now: now) }
        let i = try #require(m.candidates.firstIndex { $0.id == id })
        m.candidates[i].analysis.status = .done
        try TrainingSessionEditor.reject(&m, candidateID: id, practiceSwing: false, now: now)
        #expect(throws: TrainingSessionEditor.EditError.self) { try TrainingSessionEditor.requestReanalysis(&m, candidateID: id, now: now) }
    }

    // MARK: Clip timing records

    @Test func clipTimingWarnsOnlyWhenTheMeasuredMappingDiffers() {
        var info = MediaTimingInfo()
        info.nominalFrameRate = 60
        info.minFrameDuration = 1.0 / 60
        info.firstFrameTime = 0
        #expect(ClipTimingRecord.make(requestedStart: 26, requestedDuration: 7, exportedDuration: 7.0, info: info).warning == nil)
        info.firstFrameTime = 0.05   // three frames late: an edit list wasn't honoured
        #expect(ClipTimingRecord.make(requestedStart: 26, requestedDuration: 7, exportedDuration: 7.0, info: info).warning?.contains("first frame") == true)
        info.firstFrameTime = 0
        #expect(ClipTimingRecord.make(requestedStart: 26, requestedDuration: 7, exportedDuration: 8.1, info: info).warning?.contains("8.10") == true)
        #expect(ClipTimeMapping.clipTime(sourceTime: 30.2, clipStartInSource: 26) == 30.2 - 26)
    }

    // MARK: Discovery trace and hypotheses (synthetic scans)

    private let rest = ScanBall(cx: 0.5, cy: 0.8, w: 0.03, h: 0.03, score: 0.8)

    /// 5 frames/s; kicks at the given times (ball rests at `spot` for 8 s, leaves at the kick).
    private func scan(duration: Double, kicks: [(time: Double, spot: ScanBall)], reboundAfter: Double? = nil,
                      practice: [Double] = [], handled: [Double] = []) -> [SessionScanSample] {
        stride(from: 0.0, through: duration, by: 0.2).map { t in
            var balls: [ScanBall] = []
            for k in kicks where t >= k.time - 8 && t <= k.time + 1e-9 { balls.append(k.spot) }
            if let r = reboundAfter { for k in kicks where t > k.time + r - 1e-9 && t <= k.time + r + 0.4 { balls.append(k.spot) } }
            for h in handled {
                if t >= h - 8 && t <= h + 1e-9 { balls.append(rest) }
                if t > h && t <= h + 1.0 { var b = rest; b.cx += (t - h) * 0.05; balls.append(b) }
            }
            var person = ScanPerson(leftAnkle: NormalizedPoint(x: 0.3, y: 0.85), rightAnkle: NormalizedPoint(x: 0.32, y: 0.85),
                                    hipCenter: NormalizedPoint(x: 0.3, y: 0.6), torsoLength: 0.1)
            for k in kicks.map(\.time) + practice {
                if t >= k - 2 && t <= k { person.hipCenter = NormalizedPoint(x: 0.3 + (t - (k - 2)) * 0.08, y: 0.6) }
                if abs(t - k) < 0.01 { person.rightAnkle = NormalizedPoint(x: 0.5, y: 0.8) }
                if abs(t - (k - 0.2)) < 0.01 { person.rightAnkle = NormalizedPoint(x: 0.2, y: 0.8) }
            }
            return SessionScanSample(time: t, balls: balls, person: person)
        }
    }

    @Test func theTraceMatchesDiscoveryExactly() {
        let samples = scan(duration: 120, kicks: [(20, rest), (55, rest), (100, rest)], practice: [75], handled: [88])
        let traced = KickDiscovery.discoverWithTrace(samples)
        #expect(traced.kept == KickDiscovery.discover(samples), "no threshold or decision differs")
        #expect(traced.kept.count == 4, "3 kicks + 1 practice swing for review")
        #expect(traced.trace.contains { $0.outcome == .droppedHandledBall || $0.outcome == .droppedBallStayed },
                "picking the ball up is explained, not silently dropped")
        #expect(traced.trace.filter { $0.outcome == .keptAutoVerify }.count == 3)
        #expect(traced.trace.contains { $0.origin == .swingWithoutDeparture && $0.outcome == .keptForReview })
    }

    @Test func twoFootballsLeavingOnOneSwingAreOneCandidate() {
        // A second ball nearby is knocked off 1.2 s later by the same movement.
        let other = ScanBall(cx: 0.62, cy: 0.8, w: 0.03, h: 0.03, score: 0.7)
        let traced = KickDiscovery.discoverWithTrace(scan(duration: 60, kicks: [(30, rest), (31.2, other)]))
        #expect(traced.kept.count == 1)
        #expect(traced.trace.contains { $0.outcome == .mergedAsDuplicate && $0.mergedInto != nil })
    }

    @Test func aBallHiddenAtOnceByTheNetIsStillFound() {
        // Net: the ball is never seen again after contact (no airborne detections needed).
        let found = KickDiscovery.discover(scan(duration: 60, kicks: [(30, rest)]))
        #expect(found.count == 1 && found[0].evidence.ballDeparted)
    }

    @Test func aBallReboundingOntoItsSpotIsStillListedButWithAShiftedEstimate() {
        // Net rebound (synthetic): the ball lands back on the tee spot 0.6 s after contact and
        // sits there 0.4 s. The scan bridges the short gap, so the ball looks as if it never
        // left until the rebound rolls away: the departure is found ≈1.1 s late, away from the
        // swing, so it isn't auto-verified.
        // Documented limitation (Docs/NET_PRACTICE.md) — unchanged until real footage shows it.
        let traced = KickDiscovery.discoverWithTrace(scan(duration: 60, kicks: [(30, rest)], reboundAfter: 0.6))
        #expect(traced.kept.count == 1, "the kick is not lost")
        let k = traced.kept[0]
        #expect(!k.autoVerify, "it needs the athlete's review")
        #expect(k.contactTime > 30.5 && k.contactTime < 31.5, "the estimate is late: \(k.contactTime)")
        // The default clip around the late estimate still contains the real contact at 30 s.
        let b = ClipBoundaryPolicy.boundaries(contact: k.contactTime, sourceDuration: 60)
        #expect(b.start < 30 - 1.5 && b.end > 30)
    }

    @Test func longGapsBetweenKicksDoNotMergeThem() {
        let found = KickDiscovery.discover(scan(duration: 600, kicks: [(30, rest), (300, rest), (580, rest)]))
        #expect(found.map { ($0.contactTime / 10).rounded() } == [3, 30, 58])
    }

    // MARK: Session diagnostics

    @Test func diagnosticsCarryEvidenceButNoNamesPlacesOrIDs() throws {
        var (m, src) = session(context: .net)
        let id = try analyzedKick(&m, source: src, contact: 30, outcome: .contactUnavailable, clipContact: nil)
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: id, clipTime: 4.1, frameDuration: 1.0 / 60, now: now)
        let samples = scan(duration: 60, kicks: [(30, rest)])
        var media = MediaTimingInfo()
        media.width = 1920; media.height = 1080; media.displayOrientation = "portrait"; media.codec = "hvc1"; media.nominalFrameRate = 60
        let analysisID = UUID()
        let kicks: [UUID: SessionDiagnosticsKickInput] = [id: SessionDiagnosticsKickInput(
            videoAngle: "unknown", clipMedia: media, enteredResult: "made", enteredDistanceYards: 30,
            analyses: [(analysisID, "pose-biomechanics-3.1.0", "completed", false, nil, now, "evidence/analysis1.zip"),
                       (UUID(), "pose-biomechanics-3.1.0+assisted", "completed", true, nil, now, "evidence/analysis2.zip")])]
        let r = SessionDiagnosticsBuilder.make(m, scans: [src: samples], media: [src: media], kicks: kicks,
                                               app: .init(appVersion: "0.1.0", appBuild: "21", osVersion: "iOS", engineVersion: "pose-biomechanics-3.1.0"),
                                               exportID: "abcd1234", now: now)
        let json = String(decoding: try SessionDiagnosticsBuilder.jsonEncoder().encode(r), as: UTF8.self)
        for secret in [m.name, "Backyard", m.athleteID.uuidString, m.id.uuidString, src.uuidString, id.uuidString, analysisID.uuidString] {
            #expect(!json.contains(secret), "\(secret) must not be exported")
        }
        #expect(r.format == "kicklab-session-diagnostics" && r.formatVersion == 1 && r.recordingContext == "net")
        #expect(r.recordings.first?.ref == "camera1-recording1" && r.recordings.first?.media?.displayOrientation == "portrait")
        #expect(r.recordings.first?.scan.samples == samples.count && r.recordings.first?.scan.samplingFramesPerSecond == 5)
        let c = try #require(r.candidates.first)
        #expect(c.contactProvenance == "user" && c.userContact?.clipTime == 4.1 && abs((c.contactInClip ?? 0) - 4.1) < 1e-9)
        #expect(c.automaticContact?.outcome == "contactUnavailable")
        #expect(c.kick?.enteredResult == "made", "the entered result is reported, separately")
        #expect(c.kick?.analyses.map(\.userAssisted) == [false, true])
        #expect(r.discoveryTrace["camera1-recording1"]?.isEmpty == false)
        #expect(r.includedVideos.isEmpty, "no video unless chosen")
        let csv = SessionDiagnosticsBuilder.scanCSV(samples)
        #expect(csv.hasPrefix("time,balls,ball_cx") && csv.split(separator: "\n").count == samples.count + 1)
        #expect(SessionDiagnosticsBuilder.readme(r).contains("No names"))
    }

    @Test func diagnosticsJSONRoundTrips() throws {
        let (m, src) = session()
        let r = SessionDiagnosticsBuilder.make(m, scans: [src: scan(duration: 10, kicks: [])], media: [:], kicks: [:], app: .init(),
                                               exportID: "x", now: now)
        let data = try SessionDiagnosticsBuilder.jsonEncoder().encode(r)
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        #expect(try d.decode(SessionDiagnosticsReport.self, from: data) == r)
    }

    // MARK: Camera view, net context and saved-session compatibility

    @Test func aCameraViewAppliesToAllItsRecordingsAndKicks() throws {
        var (m, src) = session()
        let second = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .finalized,
                                                     now: now.addingTimeInterval(120))
        #expect(m.source(second.id)?.role == .unspecified, "a later recording takes its camera's view")
        let id = try analyzedKick(&m, source: second.id, contact: 10, outcome: .poseEstimatedContact, clipContact: 4)
        TrainingSessionEditor.setRole(&m, sourceID: src, role: .side, now: now)
        #expect(m.sources.allSatisfy { $0.role == .side })
        let videos = TrainingSessionEditor.kickVideosOfCamera(m, sourceID: src)
        #expect(videos.map(\.candidateID) == [id] && videos.first?.isPrimaryClip == true)
        #expect(SessionCameraRole.unspecified.angle == .unknown, "not set → the engine works the view out from the movement")
        TrainingSessionEditor.setRecordingContext(&m, .net, now: now)
        #expect(m.recordingContext == .net)
    }

    @Test func sessionsSavedBeforeHotfix2StillLoad() throws {
        var (m, src) = session()
        _ = try analyzedKick(&m, source: src, contact: 30, outcome: .ballVerifiedContact, clipContact: 4)
        // Strip every Hotfix 2 field, as Build 21 wrote them.
        let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601
        var object = try #require(try JSONSerialization.jsonObject(with: try e.encode(m)) as? [String: Any])
        object["recordingContext"] = nil
        object["plannedCameraRole"] = nil
        var candidates = try #require(object["candidates"] as? [[String: Any]])
        for i in candidates.indices { candidates[i]["automaticContact"] = nil; candidates[i]["userContact"] = nil; candidates[i]["clipTiming"] = nil }
        object["candidates"] = candidates
        let old = try JSONSerialization.data(withJSONObject: object)
        let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601
        let decoded = try d.decode(TrainingSessionManifest.self, from: old)
        #expect(decoded.candidates.count == 1 && decoded.candidates[0].userContact == nil && decoded.recordingContext == nil)
        #expect(decoded.candidates[0].contactTime == m.candidates[0].contactTime, "saved contact events are unchanged")
    }

    @Test func statusSeparatesReviewPendingAndCompleteForTheThreeKickScenario() throws {
        var (m, src) = session(context: .net)
        _ = try analyzedKick(&m, source: src, contact: 10, outcome: .ballVerifiedContact, clipContact: 4)
        let notFound = try analyzedKick(&m, source: src, contact: 25, outcome: .contactUnavailable, clipContact: nil)
        let maybe = try TrainingSessionEditor.addManualKick(&m, sourceID: src, contact: 45, now: now)
        if let i = m.candidates.firstIndex(where: { $0.id == maybe.id }) { m.candidates[i].status = .needsReview; m.candidates[i].discovery = .automatic }
        var s = SessionStatus.make(m)
        #expect(s.stage == .awaitingReview && s.awaitingReview == 2 && s.confirmedKicks == 1)
        try TrainingSessionEditor.setUserContactInClip(&m, candidateID: notFound, clipTime: 4, frameDuration: nil, now: now)
        try TrainingSessionEditor.requestReanalysis(&m, candidateID: notFound, now: now)
        s = SessionStatus.make(m)
        #expect(s.analysisPending == 1 && s.awaitingReview == 1)
        #expect(SessionReviewSummary.make(m, results: [:]).attempts == 1, "possible kicks are not counted as attempts")
    }
}
