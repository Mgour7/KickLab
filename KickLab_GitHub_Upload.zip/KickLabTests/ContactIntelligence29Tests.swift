import Foundation
import Testing
@testable import KickLab

/// Build 16 — Contact Intelligence 2.9.0.
///
/// Evidence classes, kept apart:
/// - REAL exported device pose: the build-10 rear clip (7.602 s, `RealReferenceClipRear`)
///   and the side clip (6.502 s, `RealReferenceClip220`), each with the ball timing the
///   device reported. These are the strongest checks available here.
/// - SYNTHETIC: `DepthViewSynthetic` kicks with a scripted second, faster knee extension
///   after the ball left — a reconstruction of what the 9.068 s rear clip's diagnostics
///   describe. It shows the rule behaves as designed; it does NOT verify the original
///   footage (no evidence bundle of that clip exists yet).
@Suite("Contact Intelligence 2.9.0")
struct ContactIntelligence29Tests {
    typealias Script = DepthViewSynthetic.Script
    let frame = 1.0 / 30

    /// The default synthetic rear kick (true contact 1.55 s; pose strike drive from
    /// 1.467 s), plus a later and FASTER knee extension starting at 1.733 s — after the ball
    /// was already moving — like the follow-through extension on the 9.068 s clip.
    /// `muchFaster`: the follow-through extension is over 1.7× the strike drive's rate
    /// (3360°/s vs 1726°/s), so pose alone still takes it (Build 22's strike-drive rule
    /// applies from 0.6× to 0.8×; the default 2400°/s is 0.72×).
    private func followThroughSignals(muchFaster: Bool = false) -> PoseSignalSet {
        var sig = DepthViewSynthetic.run(Script(), angle: .rear).signals
        var knee = sig.values(.kickingKneeAngle)
        for (i, t) in sig.timestamps.enumerated() {
            if abs(t - 1.700) < 1e-3 { knee[i] = 120 }
            if abs(t - 1.733) < 1e-3 { knee[i] = muchFaster ? 60 : 80 }
            if abs(t - 1.767) < 1e-3 { knee[i] = 160 }
            if abs(t - 1.800) < 1e-3 { knee[i] = 172 }
        }
        sig.series[.kickingKneeAngle] = knee
        return sig
    }

    private func ball(_ rest: Double, _ moved: Double, basis: String = "displacedDetections") -> AutomaticBallContact {
        AutomaticBallContact(lastStationaryTime: rest, firstMovementTime: moved, basis: basis, detectorName: "test")
    }

    // MARK: A — the 9.068 s rear-clip conflict (SYNTHETIC reconstruction)

    @Test func syntheticPoseAlonePicksTheLaterFasterExtension() throws {
        // Build 22: a follow-through extension 0.6–0.8× faster than the strike drive no longer
        // wins on pose alone (device kicks, App 0.1.0 (25)); a much faster one still does.
        let p = KickPhaseDetector.detect(followThroughSignals(), kickType: .fieldGoal, perspective: .depthAway)
        let e = try #require(p.evidence?.contactEarliestTime)
        #expect(e < 1.6, "pose alone now picks the strike drive (\(e))")
        #expect(p.evidence?.contactCandidates?.contains { $0.rejectionReasons.contains { $0.contains("follow-through extension") } } == true)
        let fast = KickPhaseDetector.detect(followThroughSignals(muchFaster: true), kickType: .fieldGoal, perspective: .depthAway)
        let f = try #require(fast.evidence?.contactEarliestTime)
        #expect(f > 1.7, "a much faster later extension still wins on pose alone (\(f))")
    }

    @Test func syntheticPoseAloneNowAgreesWithTheBall() throws {
        let p = KickPhaseDetector.detect(followThroughSignals(), kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.5667))
        let f = try #require(p.evidence?.ballFusion)
        #expect(f.accepted && f.acceptancePath == BallFusionReport.Path.poseStrikeAgreement.rawValue)
        #expect(ContactOutcome.of(p) == .ballConstrainedContactInterval)
        #expect((1.5...1.5667).contains(p.phase(.contact).representativeTime ?? 0))
    }

    @Test func syntheticAnEarlierCredibleDriveAgreeingWithTheBallIsUsed() throws {
        let p = KickPhaseDetector.detect(followThroughSignals(muchFaster: true), kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.5667))
        let f = try #require(p.evidence?.ballFusion)
        #expect(f.accepted, "\(f.rejectionReason ?? "")")
        #expect(f.acceptancePath == BallFusionReport.Path.earlierCredibleDrive.rawValue)
        #expect(abs((p.phase(.contact).representativeTime ?? 0) - 1.5333) < 1e-3)
        #expect(ContactOutcome.of(p) == .ballConstrainedContactInterval)
        let drives = try #require(f.drives)
        #expect(drives.contains { $0.role == "usedWithBall" && $0.overlapsBall && !$0.startsAfterBallLeft })
        #expect(drives.contains { $0.role == "followThroughExtension" && $0.startsAfterBallLeft && !$0.overlapsBall })
        #expect(p.notes.contains { $0.contains("follow-through, not the strike") })
        #expect(p.phase(.contact).status == .estimated, "estimated, never 'detected'")
    }

    @Test func syntheticABallLeavingBeforeEveryDriveStaysAConflict() throws {
        // The ball moved long before any knee drive: no drive can explain it.
        let p = KickPhaseDetector.detect(followThroughSignals(), kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.2, 1.2667))
        let f = try #require(p.evidence?.ballFusion)
        #expect(!f.accepted)
        #expect(f.acceptancePath == nil)
        #expect(ContactOutcome.of(p) != .ballConstrainedContactInterval && ContactOutcome.of(p) != .ballVerifiedContact)
    }

    @Test func syntheticABallLeavingAfterThePoseStrikeIsNotReassigned() throws {
        // Unmodified kick (strike 1.467 s); the ball leaves at 1.9 s. The selected drive is
        // BEFORE the ball, so it isn't a follow-through: the conflict is preserved.
        let sig = DepthViewSynthetic.run(Script(), angle: .rear).signals
        let p = KickPhaseDetector.detect(sig, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.8667, 1.9))
        let f = try #require(p.evidence?.ballFusion)
        #expect(!f.accepted)
        #expect(p.evidence?.ballEvidence?.outcome == .conflicting)
        #expect(p.evidence?.contactTimingMethod != "ballDetector")
    }

    @Test func syntheticTwoEarlierDrivesOverlappingTheBallAreNotChosenBetween() throws {
        // A second credible drive inside the ball's interval: the fusion abstains.
        var sig = followThroughSignals(muchFaster: true)
        var knee = sig.values(.kickingKneeAngle)
        var speed = sig.values(.kickingAnkleSpeed)
        for (i, t) in sig.timestamps.enumerated() {
            if abs(t - 1.533) < 1e-3 { knee[i] = 100 }
            if abs(t - 1.567) < 1e-3 { knee[i] = 150 }
            if abs(t - 1.600) < 1e-3 { knee[i] = 172 }
            if t > 1.5, t < 1.75 { speed[i] = max(speed[i] ?? 0, 6) }
        }
        sig.series[.kickingKneeAngle] = knee
        sig.series[.kickingAnkleSpeed] = speed
        let p = KickPhaseDetector.detect(sig, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.6))
        let f = try #require(p.evidence?.ballFusion)
        #expect(!f.accepted, "two overlapping earlier drives must not be resolved by picking one")
        #expect(f.rejectionReason?.contains("2 earlier knee drives overlap") == true)
        #expect((f.drives ?? []).filter { $0.overlapsBall }.count == 2)
    }

    // MARK: C — the acceptance path on the REAL rear clip (7.602 s)

    @Test func theRealRearClipIsAcceptedByPoseStrikeAgreementNotTheFootRule() throws {
        let p = KickPhaseDetector.detect(RealReferenceClipRear.signals, kickType: .fieldGoal, perspective: .depthAway,
                                         ballContact: AutomaticBallContact(lastStationaryTime: 3.833, firstMovementTime: 3.9,
                                                                           basis: "displacedDetections", detectorName: "YOLOX-S"))
        let f = try #require(p.evidence?.ballFusion)
        #expect(f.accepted)
        #expect(f.acceptancePath == BallFusionReport.Path.poseStrikeAgreement.rawValue)
        // The device showed "0.47 of strike peak · supports no · accepted". That is this
        // path: the foot ratio is informational here; the 50% rule is NOT weakened.
        #expect(DepthViewPhaseDetector.footSupportRatio == 0.5)
        #expect(f.lines.contains { $0.contains("informational on this path") })
        #expect(f.lines.contains { $0.contains("via poseStrikeAgreement") })
        #expect(abs((p.phase(.contact).representativeTime ?? 0) - 3.867) < 0.002, "regression: about 3.867–3.900")
        #expect(abs((p.plantTime ?? 0) - 3.767) < 0.002)
    }

    @Test func theFootRuleStillDecidesWhenThereIsNoPoseStrike() throws {
        // No usable knee signal: pose establishes no strike, so the ball stands only on
        // the kicking-foot rule (≥ 50% of strike speed as the ball left).
        var sig = DepthViewSynthetic.run(Script(), angle: .rear).signals
        sig.series[.kickingKneeAngle] = sig.timestamps.map { _ in nil }
        let p = KickPhaseDetector.detect(sig, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.5667))
        let f = try #require(p.evidence?.ballFusion)
        #expect(f.poseFoundStrike == false)
        #expect(f.accepted && f.acceptancePath == BallFusionReport.Path.kickingFootSwing.rawValue)
        #expect(f.kickingFootSupports == true)
        #expect(f.lines.contains { $0.contains("required on this path") })
        // The same ball with the foot NOT swinging as it left: rejected, not accepted.
        var still = sig
        still.series[.kickingAnkleSpeed] = sig.timestamps.enumerated().map { i, t in abs(t - 1.53) < 0.12 ? 0.1 : sig.values(.kickingAnkleSpeed)[i] }
        let q = KickPhaseDetector.detect(still, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.5667))
        #expect(q.evidence?.ballFusion?.accepted == false)
    }

    // MARK: E — side clip (6.502 s) on its REAL exported signals

    @Test func theRealSideClipIsNarrowedToAbout2_500() throws {
        let sig = RealReferenceClip220.signals
        let p = KickPhaseDetector.detect(sig, kickType: .fieldGoal)
        #expect(abs((p.estimatedContactTime ?? 0) - 2.467) < 0.002, "pose alone, unchanged")
        let timeline = KickerPoseTimeline(samples: sig.timestamps.enumerated().map { KickerPoseSample(frameIndex: $0.offset, timestamp: $0.element, joints: [:]) })
        let r = FootballContactFusion.refineSideContact(p, ball: AutomaticBallContact(lastStationaryTime: 2.467, firstMovementTime: 2.533,
                                                                                         basis: "displacedDetections", detectorName: "YOLOX-S"),
                                                        timeline: timeline)
        let c = r.phase(.contact)
        #expect((c.representativeTime ?? 0) >= 2.467 - 1e-3 && (c.representativeTime ?? 0) <= 2.500 + 2e-3, "about 2.467–2.500 (\(c.representativeTime ?? -1))")
        #expect(r.evidence?.ballFusion?.acceptancePath == BallFusionReport.Path.poseStrikeAgreement.rawValue)
        // D: the pose timing score is kept separately and is NOT raised by the ball.
        let pose = try #require(r.evidence?.poseTimingScore)
        #expect(abs(pose - p.phase(.contact).confidence) < 1e-3)
        #expect(abs(c.confidence - p.phase(.contact).confidence) < 1e-9, "the ball doesn't inflate the stored score")
        let b = ContactConfidenceBreakdown.make(phases: r, football: nil, poseTimingScore: pose, frame: frame)
        #expect(b.agreement == .agree)
        #expect(b.finalContact == .strong || b.finalContact == .moderate)
        #expect(b.line.contains("not a probability"))
    }

    // MARK: B — departure classifications

    private func track(_ states: [FootballFrameState], basis: String? = nil, appearance: Double? = nil) -> FootballTrack {
        var t = FootballTrack(method: .automaticFootballDetection, detector: .yoloxS, note: "test")
        t.observations = states.enumerated().map { i, s in
            FootballFrameObservation(time: Double(i) / 30, state: s, source: s == .notSeen ? .unavailable : .detected, box: nil,
                                     score: s == .notSeen ? nil : 0.8, appearance: appearance)
        }
        if let basis { t.lastStationaryTime = 0.1; t.firstPersistentMovementTime = 0.2; t.movementBasis = basis }
        return t
    }

    @Test func departuresAreClassifiedWithoutMergingDisappearanceOcclusionAndMovement() {
        #expect(track([.atRest, .atRest, .moving, .moving, .moving], basis: "displacedDetections").departure?.kind == .observedMovingBall)
        #expect(track([.atRest, .atRest, .notSeen, .notSeen, .notSeen], basis: "restVanished").departure?.kind == .restSiteVacated)
        // Hidden after its last resting frame, no confirmation → occluded, never "moved".
        let hidden = track([.atRest, .atRest, .obscured, .notSeen, .notSeen])
        #expect(hidden.departure?.kind == .occludedAtDeparture)
        #expect(hidden.contactBounds == nil, "occlusion never bounds contact")
        #expect(track([.atRest, .atRest, .atRest]).departure?.kind == .departureUncertain)
        #expect(track([.atRest, .moving, .atRest, .moving, .moving]).departure?.kind == .departureUncertain)
        #expect(FootballTrack.unavailable("x").departure == nil)
        #expect(FootballDepartureKind.observedMovingBall.boundsContact && FootballDepartureKind.restSiteVacated.boundsContact)
        #expect(!FootballDepartureKind.occludedAtDeparture.boundsContact && !FootballDepartureKind.departureUncertain.boundsContact)
    }

    @Test func departureAndSelectionCheckAppearInDiagnostics() {
        var t = track([.atRest, .atRest, .moving, .moving, .moving], basis: "displacedDetections")
        t.sites = [FootballRestSite(center: NormalizedPoint(x: 0.5, y: 0.6), size: 0.03, firstSeen: 0, lastSeen: 0.1, detections: 4,
                                    meanScore: 0.8, afterStrikeShare: 0, closestAnkleSizes: 1.2, selected: true, reason: "selected")]
        let lines = FootballDiagnosticsSummary(t).lines
        #expect(lines.contains { $0.contains("departure: observedMovingBall") })
        #expect(lines.contains { $0.contains("ball selection: 1 ball(s) found") && $0.contains("no rival ball") })
    }

    // MARK: D — the confidence breakdown

    @Test func theConfidenceBreakdownNeverCallsAHeuristicAProbability() {
        let sig = DepthViewSynthetic.run(Script(), angle: .rear).signals
        let poseOnly = KickPhaseDetector.detect(sig, kickType: .fieldGoal, perspective: .depthAway)
        let b = ContactConfidenceBreakdown.make(phases: poseOnly, football: nil, poseTimingScore: poseOnly.evidence?.poseTimingScore, frame: frame)
        #expect(b.footballTracking == .unavailable)
        #expect(b.agreement == .notApplicable)
        #expect(b.finalContact == .weak, "a strike window is weak")
        let withBall = KickPhaseDetector.detect(sig, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball(1.5, 1.5667))
        let c = ContactConfidenceBreakdown.make(phases: withBall, football: track([.atRest, .atRest, .moving, .moving, .moving], basis: "displacedDetections"),
                                                poseTimingScore: withBall.evidence?.poseTimingScore, frame: frame)
        #expect(c.footballTracking == .strong)
        #expect(c.agreement == .agree)
        #expect(c.intervalWidthSeconds != nil)
        // The pose-only score is the same with or without the ball: more signals don't raise it.
        #expect(withBall.evidence?.poseTimingScore == poseOnly.evidence?.poseTimingScore)
    }

    @Test func olderEvidenceWithoutBuild16FieldsStillDecodes() throws {
        let json = #"{"detectorRan":true,"ballSelected":true,"plantRejected":false,"accepted":true}"#
        let f = try JSONDecoder().decode(BallFusionReport.self, from: Data(json.utf8))
        #expect(f.acceptancePath == nil && f.drives == nil && f.departure == nil)
        #expect(f.lines.last?.contains("ACCEPTED") == true)
    }
}
