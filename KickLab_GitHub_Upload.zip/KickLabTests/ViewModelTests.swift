import Foundation
import SwiftData
import Testing
@testable import KickLab

/// An engine that reports some progress and then waits until it is cancelled.
final class SlowAnalysisEngine: VideoAnalysisService, @unchecked Sendable {
    var engineVersion: String { "slow-1" }
    var availability: VideoAnalysisAvailability { .available }

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        PreparedVideoAnalysis(requestID: request.id, engineVersion: engineVersion, usableVideoIDs: request.inputVideoIDs,
                              rejectedInputs: [], estimatedFrameCount: nil)
    }

    func analyze(_ request: VideoAnalysisRequest, progress: @escaping @Sendable (VideoAnalysisProgress) -> Void) async throws -> VideoAnalysisResult {
        progress(VideoAnalysisProgress(stage: .detectingPose, fractionCompleted: 0.2))
        while true {
            try await Task.sleep(nanoseconds: 5_000_000)   // throws CancellationError when cancelled
        }
    }
}

/// Real SwiftData, real files in a temporary folder, and the app model wired to them.
@MainActor
struct AppFixture {
    let f: ServiceFixture
    let temp: TemporaryDirectory
    let store: ManagedMediaStore
    let selection = InMemoryAthleteSelection()
    let app: AppModel

    init(engine: any VideoAnalysisService = UnavailableVideoAnalysisService()) throws {
        f = try ServiceFixture()
        temp = try TemporaryDirectory()
        store = ManagedMediaStore(
            locations: MediaLocations(baseURL: temp.kickLabBase),
            metadataReader: FixedMetadataReader(metadata: VideoMediaMetadata(
                durationSeconds: 3, frameRate: 240, pixelWidth: 1080, pixelHeight: 1920, hasAudio: false
            )),
            thumbnailGenerator: WritingThumbnailGenerator()
        )
        try store.prepareDirectories()
        app = AppModel(services: AppServices(context: f.context, mediaStore: store, analysisEngine: engine),
                       selectionStore: selection)
    }

    /// Imports a small file through VideoStorageService, like the app does.
    @discardableResult
    func importVideo(to kick: Kick, angle: VideoAngleType = .side) async throws -> VideoAsset {
        let source = try temp.writeFile(named: "\(UUID().uuidString).mov", bytes: Array(repeating: 9, count: 32))
        return try await app.services.videos.importVideo(from: source, for: kick, angle: angle, sourceType: .filesImport)
    }

    static func summary(_ status: KickerSelectionStatus) -> PoseAnalysisSummary {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right
        ))
        var summary = PoseAnalysisSummary(primaryVideoID: UUID(), output: output)
        summary.kickerStatus = status
        return summary
    }
}

/// Polls (yielding the main actor) until `condition` holds or about four seconds pass.
@MainActor
func waitUntil(_ condition: () -> Bool) async {
    var attempts = 0
    while !condition() && attempts < 2000 {
        attempts += 1
        try? await Task.sleep(nanoseconds: 2_000_000)
    }
}

/// Requires Xcode: Step 9 view models against real SwiftData and services.
@MainActor
@Suite("Step 9 view models")
struct ViewModelTests {
    // MARK: Athletes and selection

    @Test func appModelLoadsSelectsAndFallsBackAfterDeletion() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        x.app.load()
        #expect(x.app.hasLoaded)
        #expect(x.app.athletes.isEmpty)
        #expect(x.app.selectedAthleteID == nil)

        let zed = try x.f.makeAthlete("Zed")
        let amy = try x.f.makeAthlete("Amy")
        x.app.load()
        #expect(x.app.athletes.count == 2)
        #expect(x.app.selectedAthleteID == amy.id, "first by name when nothing was chosen")

        let revision = x.app.revision
        x.app.select(zed.id)
        #expect(x.app.selectedAthlete?.name == "Zed Kicker")
        #expect(x.selection.storedAthleteID == zed.id, "remembered between launches")
        #expect(x.app.revision > revision, "screens reload for the new athlete")
        x.app.select(UUID())
        #expect(x.app.selectedAthleteID == zed.id, "unknown IDs are ignored")

        // Delete the selected athlete through the safe flow.
        let deletion = AthleteDeletionViewModel(athleteID: zed.id)
        deletion.prepare(app: x.app)
        #expect(deletion.summary.contains("0 kicks"))
        #expect(!deletion.canDelete)
        #expect(!deletion.delete(app: x.app), "not without the typed confirmation")
        deletion.typedConfirmation = "Zed Kicker"
        #expect(deletion.canDelete)
        #expect(deletion.delete(app: x.app))
        #expect(x.app.athletes.map(\.id) == [amy.id])
        #expect(x.app.selectedAthleteID == amy.id, "falls back to a remaining athlete")
    }

    @Test func storedSelectionIsRestored() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        _ = try x.f.makeAthlete("Amy")
        let zed = try x.f.makeAthlete("Zed")
        x.selection.storedAthleteID = zed.id
        x.app.load()
        #expect(x.app.selectedAthleteID == zed.id)
    }

    @Test func athleteEditorCreatesSelectsAndPreservesOtherFields() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        x.app.load()
        let blank = AthleteEditorViewModel()
        #expect(blank.save(app: x.app) == nil)
        #expect(blank.issueMessages == ["Enter a first or last name."])

        let editor = AthleteEditorViewModel()
        editor.firstName = "Riley"
        editor.kickingFoot = .left
        let id = try #require(editor.save(app: x.app))
        #expect(x.app.selectedAthleteID == id, "a new athlete is selected")
        #expect(x.app.selectedAthlete?.kickingFootText == "Left-footed")

        let athlete = try #require(x.app.athleteModel(id))
        var profile = x.app.services.athletes.profile(of: athlete)
        profile.jerseyNumber = "3"
        try x.app.services.athletes.updateProfile(athlete, with: profile)

        let edit = AthleteEditorViewModel(athleteID: id, app: x.app)
        #expect(edit.firstName == "Riley")
        edit.lastName = "Boot"
        #expect(edit.save(app: x.app) == id)
        #expect(athlete.fullName == "Riley Boot")
        #expect(x.app.services.athletes.profile(of: athlete).jerseyNumber == "3", "fields not on the form are kept")
    }

    // MARK: Dashboard

    @Test func dashboardIsEmptyWithoutKicksAndAggregatesWithThem() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        x.app.load()
        let home = HomeViewModel()
        home.load(app: x.app)
        let empty = try #require(home.state.value)
        #expect(empty.isEmpty)
        #expect(empty.latestScoreText == nil)

        try x.f.makeKick(for: athlete, draft: .fieldGoal(.made, distance: 40))
        try x.f.makeKick(for: athlete, draft: .fieldGoal(.missedLeft, distance: 50))
        try x.f.makeKick(for: athlete, draft: .kickoff())
        x.app.dataDidChange()
        home.load(app: x.app)
        let d = try #require(home.state.value)
        #expect(!d.isEmpty)
        #expect(d.stats.first { $0.title == "Total kicks" }?.value == "3")
        #expect(d.stats.first { $0.title == "Field goals (30 days)" }?.value == "50%")
        #expect(d.stats.first { $0.title == "Touchbacks (30 days)" }?.value == "100%")
        #expect(d.recentActivity.count == 3)
        #expect(d.latestScoreText == nil, "no analysis yet, nothing invented")
        #expect(d.analysisEmptyMessage == DashboardPresentation.noAnalysisMessage)
    }

    @Test func homeWithoutAthleteFailsGracefully() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        x.app.load()
        let home = HomeViewModel()
        home.load(app: x.app)
        #expect(home.state == .failed("Add an athlete to get started."))
    }

    // MARK: Kick entry

    @Test func kickEntryValidatesSavesAndAddsAnother() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let session = try x.f.makeSession(for: athlete, type: .game)
        x.app.load()

        let entry = KickEntryViewModel(sessionID: session.id)
        entry.form.distanceText = "abc"
        #expect(entry.save(app: x.app) == nil)
        #expect(entry.issues == [.invalidNumber(.distance)])
        #expect((athlete.kicks ?? []).isEmpty, "nothing saved")

        entry.form.distanceText = "38"
        entry.form.hash = .right
        let revision = x.app.revision
        let id = try #require(entry.save(app: x.app, addAnother: true))
        #expect(entry.savedCount == 1)
        #expect(entry.form.distanceText == "38", "rep setup is kept")
        #expect(entry.form.hash == .right)
        #expect(x.app.revision > revision)
        let kick = try #require(ModelLookup.kick(id, in: x.app.context))
        #expect(kick.session?.id == session.id)
        #expect(kick.context == .game, "context defaults from the session")

        let edit = KickEntryViewModel(editing: id, app: x.app)
        #expect(edit.isEditing)
        #expect(edit.form.distanceText == "38")
        edit.form.result = .missedRight
        #expect(edit.save(app: x.app) == id)
        if case .fieldGoal(let fg)? = kick.outcome { #expect(fg.result == .missedRight) } else { Issue.record("outcome") }
    }

    @Test func kickEntryNeedsAnAthlete() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        x.app.load()
        let entry = KickEntryViewModel()
        #expect(entry.save(app: x.app) == nil)
        #expect(entry.errorMessage == "Choose an athlete first.")
    }

    // MARK: Videos

    @Test func kickDetailImportsSwitchesPrimaryAndRemovesVideos() async throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        let kick = try x.f.makeKick(for: athlete)
        x.app.load()
        let detail = KickDetailViewModel(kickID: kick.id)

        let source = try x.temp.writeFile(named: "pick.mov", bytes: Array(repeating: 1, count: 40))
        await detail.importVideo(from: source, source: .filesImport, angle: .side, makePrimary: true, app: x.app)
        let second = try x.temp.writeFile(named: "pick2.mov", bytes: Array(repeating: 2, count: 40))
        await detail.importVideo(from: second, source: .filesImport, angle: .rear, makePrimary: false, app: x.app)
        #expect(detail.errorMessage == nil)
        #expect(exists(source) && exists(second), "originals are never removed")

        let content = try #require(detail.state.value)
        #expect(content.videos.count == 2)
        #expect(content.videos[0].isPrimary)
        #expect(content.videos[0].angleText == "Side view")
        #expect(content.videos.allSatisfy { $0.isPlayable })
        #expect(detail.thumbnailURL(videoID: content.videos[0].id, app: x.app) != nil)

        let other = content.videos[1].id
        detail.setPrimary(videoID: other, app: x.app)
        #expect(detail.state.value?.videos.first?.id == other)

        let removedFile = try #require(detail.fileURL(videoID: other, app: x.app))
        detail.removeVideo(videoID: other, app: x.app)
        #expect(detail.state.value?.videos.count == 1)
        #expect(!exists(removedFile), "KickLab's copy is removed")
        #expect(detail.state.value?.videos.first?.isPrimary == true, "a remaining video becomes primary")
    }

    @Test func pickerTemporaryCopyIsRemovedOnlyWhenAsked() async throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        x.app.load()
        let detail = KickDetailViewModel(kickID: kick.id)
        let temporaryCopy = try x.temp.writeFile(named: "photos-copy.mov")
        await detail.importVideo(from: temporaryCopy, source: .photosImport, angle: .side, makePrimary: true,
                                 app: x.app, removeSourceAfterImport: true)
        #expect(!exists(temporaryCopy))
        #expect(detail.state.value?.videos.count == 1)
    }

    // MARK: Analysis

    @Test func analysisRunSucceedsAndResultsLoad() async throws {
        let x = try AppFixture(engine: ScriptedAnalysisEngine(.succeed(AppFixture.summary(.selected), artifacts: nil, results: .synthetic)))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick)
        x.app.load()

        let run = x.app.analysisRun(for: kick.id)
        #expect(x.app.analysisRun(for: kick.id) === run, "one run per kick")
        run.start(app: x.app)
        #expect(run.state.isBusy)
        await waitUntil { !run.state.isBusy }
        guard case .completed(let analysisID) = run.state else {
            Issue.record("expected completion, got \(run.state)")
            return
        }

        let results = AnalysisResultsViewModel(analysisID: analysisID)
        results.load(app: x.app)
        let content = try #require(results.state.value)
        #expect(content.presentation.header.statusText == "Current analysis")
        #expect(content.presentation.priorities.first?.cue != nil)
        #expect(content.previousAnalysis.rows.isEmpty)
        #expect(content.previousAnalysis.emptyMessage == "This is the first completed analysis of this kick.")
        #expect(content.baselineComparison.emptyMessage == PersonalInsights.baselineNeededMessage, "no baseline from one kick")
        #expect(content.references.allSatisfy { $0.baseline == nil })

        // A second run: the earlier one stays in history and becomes the comparison.
        run.retry(app: x.app)
        await waitUntil { !run.state.isBusy }
        guard case .completed(let secondID) = run.state else {
            Issue.record("expected completion, got \(run.state)")
            return
        }
        let second = AnalysisResultsViewModel(analysisID: secondID)
        second.load(app: x.app)
        #expect(second.state.value?.previousAnalysis.emptyMessage == nil)
        #expect(second.state.value?.previousAnalysis.rows.isEmpty == false)

        let history = AnalysisHistoryViewModel(scope: .kick(kick.id))
        history.load(app: x.app)
        let records = try #require(history.state.value)
        #expect(records.count == 2)
        #expect(records.filter(\.isCurrent).map(\.id) == [secondID], "exactly one current analysis")
        let athleteHistory = AnalysisHistoryViewModel(scope: .athlete)
        athleteHistory.load(app: x.app)
        #expect(athleteHistory.state.value?.first?.id == secondID)

        let home = HomeViewModel()
        home.load(app: x.app)
        #expect(home.state.value?.latestScoreText != nil, "dashboard shows the latest mechanics score")
    }

    @Test func analysisFailuresAreUserFacing() async throws {
        let x = try AppFixture(engine: ScriptedAnalysisEngine(.succeed(AppFixture.summary(.ambiguous), artifacts: nil, results: .synthetic)))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .failed(.ambiguousKicker))
        #expect(AnalysisProblem.ambiguousKicker.suggestsKickerSelection)

        let simulator = try AppFixture(engine: ScriptedAnalysisEngine(.fail(.poseDetectionUnavailable(environment: .simulator))))
        defer { simulator.temp.remove() }
        let kick2 = try simulator.f.makeKick(for: try simulator.f.makeAthlete())
        try await simulator.importVideo(to: kick2)
        simulator.app.load()
        let run2 = simulator.app.analysisRun(for: kick2.id)
        run2.start(app: simulator.app)
        await waitUntil { !run2.state.isBusy }
        #expect(run2.state == .failed(.poseDetectionUnavailable(.simulator)))
    }

    @Test func analysisNeedsAVideoFile() async throws {
        let x = try AppFixture(engine: ScriptedAnalysisEngine(.succeed(nil, artifacts: nil, results: .synthetic)))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        #expect(run.state == .failed(.noVideo))

        try x.f.addVideo(to: kick, path: "missing/file.mov")   // a record whose file isn't there
        run.retry(app: x.app)
        #expect(run.state == .failed(.videoMissing))
        #expect((kick.analyses ?? []).isEmpty, "no analysis record was created")
    }

    @Test func analysisCanBeCancelled() async throws {
        let x = try AppFixture(engine: SlowAnalysisEngine())
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil {
            if case .running(_, let fraction) = run.state { return fraction > 0 }
            return false
        }
        #expect(run.state == .running(stage: .detectingPose, fraction: 0.2))
        run.cancel()
        #expect(run.state == .cancelling)
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .cancelled)
        let analysis = try #require(kick.analyses?.first)
        #expect(analysis.processingStatus == .cancelled)
        #expect(analysis.isCurrent == false)
    }

    @Test func kickerSeedIsPassedToTheEngine() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(nil, artifacts: nil, results: .synthetic))
        let x = try AppFixture(engine: engine)
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        let source = try #require(run.kickerSelectionSource(app: x.app))
        #expect(near(source.timestamp, 1, 1e-9), "a third of the 3 s video, where the thumbnail is taken")
        run.chooseKicker(at: NormalizedPoint(x: 0.4, y: 0.6), source: source)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        #expect(engine.lastRequest?.options.kickerSeed == KickerSeed(timestamp: 1, point: NormalizedPoint(x: 0.4, y: 0.6)))
    }

    // MARK: Stats

    @Test func statsFilterByKickTypeAndShowInsightsHonestly() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let athlete = try x.f.makeAthlete()
        try x.f.makeKick(for: athlete, draft: .fieldGoal(.made))
        try x.f.makeKick(for: athlete, draft: .fieldGoal(.missedLeft))
        x.app.load()
        let stats = StatsViewModel()
        stats.load(app: x.app)
        let content = try #require(stats.state.value)
        #expect(content.sections.first?.rows.first { $0.title == "Made" }?.value == "1 of 2")
        #expect(content.insights.baselineAvailability == .needsMoreKicks(have: 0, need: 3), "no analyses, no baseline")

        stats.kickType = .kickoff
        stats.load(app: x.app)
        #expect(stats.state.value?.sections.first?.emptyMessage == "No kickoff kicks in this period.")
    }
}
