import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: the Step 11 real-device protections against real SwiftData and files.
@MainActor
@Suite("Step 11 real-device protections in the app")
struct DeviceReadinessViewModelTests {
    @Test func firstLaunchStartsEmptyWithoutErrors() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        #expect(!x.app.hasLoaded)
        x.app.load()
        #expect(x.app.hasLoaded)
        #expect(x.app.athletes.isEmpty, "the welcome screen is shown")
        #expect(x.app.loadError == nil)
        #expect(x.app.selectedAthleteID == nil)
        let home = HomeViewModel()
        home.load(app: x.app)
        #expect(home.state == .failed("Add an athlete to get started."))
    }

    @Test func overlongVideosAreRefusedBeforeAnalysis() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(nil, artifacts: nil, results: .synthetic))
        let x = try AppFixture(engine: engine)
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick)
        video.durationSeconds = 600
        try x.f.context.save()
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        #expect(run.state == .failed(.videoTooLong(seconds: 600)))
        #expect((kick.analyses ?? []).isEmpty, "nothing was started or recorded")
        #expect(engine.lastRequest == nil)
    }

    @Test func goingToTheBackgroundStopsAnalysisCleanly() async throws {
        let x = try AppFixture(engine: SlowAnalysisEngine())
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil {
            if case .running(_, let fraction) = run.state { return fraction > 0 }
            return false
        }
        x.app.interruptRunningAnalyses()
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .failed(.interruptedByBackground))
        let analysis = try #require(kick.analyses?.first)
        #expect(analysis.processingStatus == .cancelled, "recorded as cancelled, never left processing")
        #expect(analysis.isCurrent == false)

        // An ordinary cancel is still reported as a cancel.
        run.retry(app: x.app)
        await waitUntil {
            if case .running(_, let fraction) = run.state { return fraction > 0 }
            return false
        }
        run.cancel()
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .cancelled)
        #expect((kick.analyses ?? []).count == 2, "each attempt is one record; nothing duplicated")
    }

    @Test func importsStopWhenThePhoneIsFull() async throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        x.app.load()
        let detail = KickDetailViewModel(kickID: kick.id)
        detail.availableBytes = { _ in 1_000 }   // nearly full
        let source = try x.temp.writeFile(named: "clip.mov", bytes: Array(repeating: 1, count: 4_096))
        await detail.importVideo(from: source, source: .filesImport, angle: .side, makePrimary: true, app: x.app)
        #expect(detail.errorMessage?.contains("isn't enough free space") == true)
        #expect((kick.videos ?? []).isEmpty, "nothing was copied")
        #expect(exists(source), "the original is untouched")

        detail.errorMessage = nil
        detail.availableBytes = { _ in 10 * 1_073_741_824 }
        await detail.importVideo(from: source, source: .filesImport, angle: .side, makePrimary: true, app: x.app)
        #expect(detail.errorMessage == nil)
        #expect((kick.videos ?? []).count == 1)
    }
}
