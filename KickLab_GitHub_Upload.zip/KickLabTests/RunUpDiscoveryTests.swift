import Foundation
import Testing
@testable import KickLab

/// Build 22: session kick discovery for run-ups along the camera's line of sight (filmed
/// from behind). SYNTHETIC 5 fps scans shaped like the real IMG_6269 kicks K1/K2, where the
/// kicker's image shrank from about 0.15 to 0.075 over 1.2–1.8 s, then held while the leg
/// moved at only 3–5 torso lengths/s at scan rate (below the swing detector). Pure (Linux).
@Suite("Build 22: rear-view run-ups are discovered")
struct RunUpDiscoveryTests {
    /// 5 fps. The run-up shrinks the kicker from `from` to `to` between 1.0 s and
    /// 1.0 + `runUp` s, moving `sideways` (normalized x) meanwhile; after it the kicker holds
    /// still with ankle movement of `leg` torso lengths/s around 0.4 s after the stop.
    static func scan(from: Double = 0.15, to: Double = 0.075, runUp: Double = 1.6, sideways: Double = 0,
                     leg: Double = 4.5, duration: Double = 8) -> [SessionScanSample] {
        let step = 0.2
        return (0...Int(duration / step)).map { i in
            let t = Double(i) * step
            let u = min(1, max(0, (t - 1) / runUp))
            let size = from + (to - from) * u
            let hip = NormalizedPoint(x: 0.5 + sideways * u, y: 0.6 - 0.1 * u)
            let stop = 1 + runUp
            // The kicking ankle moves back and forth around the expected contact.
            let swinging = abs(t - (stop + 0.4)) <= 0.41
            let dx = swinging ? (i % 2 == 0 ? 1.0 : -1.0) * leg * size * step / 2 : 0
            let ankle = NormalizedPoint(x: hip.x + 0.02 + dx, y: hip.y + 2 * size)
            return SessionScanSample(time: t, balls: [], person: ScanPerson(leftAnkle: NormalizedPoint(x: hip.x - 0.02, y: hip.y + 2 * size),
                                                                             rightAnkle: ankle, hipCenter: hip, torsoLength: size))
        }
    }

    @Test func aRunUpAwayFromTheCameraThatStopsIsListed() throws {
        let (kept, trace) = KickDiscovery.discoverWithTrace(Self.scan())
        let k = try #require(kept.first)
        #expect(kept.count == 1)
        // The run-up ends at 2.6 s; contact is expected about 0.4 s later.
        #expect(abs(k.contactTime - 3.0) <= 0.21, "\(k.contactTime)")
        #expect(k.evidence.approachSeen && !k.autoVerify, "listed for Stage B to confirm, never auto-verified from the scan")
        #expect(k.evidence.score >= KickDiscovery.minimumListedScore)
        #expect(trace.contains { $0.origin == .runUpAlongLineOfSight && $0.outcome == .keptForReview })
    }

    @Test func walkingAcrossTheViewIsNotARunUp() {
        // Same shrink, but moving 3 torso lengths sideways (walking off at an angle).
        #expect(KickDiscovery.runUpStops(Self.scan(sideways: 0.25)).isEmpty)
    }

    @Test func walkingTowardTheCameraIsNotARunUp() {
        // Growing: on the session recordings these were people walking back.
        #expect(KickDiscovery.runUpStops(Self.scan(from: 0.075, to: 0.15)).isEmpty)
    }

    @Test func aDifferentPersonBecomingProminentIsNotARunUp() {
        // A 4× size change in 0.4 s: the scan switched to another person.
        #expect(KickDiscovery.runUpStops(Self.scan(from: 0.3, to: 0.075, runUp: 0.4)).isEmpty)
    }

    @Test func noLegMovementAtTheStopIsNotAKick() {
        // A run-up that ends standing still (walking up to the ball, then waiting).
        #expect(KickDiscovery.runUpStops(Self.scan(leg: 0)).isEmpty)
    }

    @Test func aSlowShrinkIsNotARunUp() {
        // Shrinking by half over 8 s (strolling away): never 1.4× within 2.5 s.
        #expect(KickDiscovery.runUpStops(Self.scan(runUp: 8, duration: 12)).isEmpty)
    }
}
