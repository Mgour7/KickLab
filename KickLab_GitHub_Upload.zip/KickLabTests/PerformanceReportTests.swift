import Foundation
import Testing
@testable import KickLab

/// Build 16 — Performance Report 2.0: the ten report scenarios, rankings and the scoring
/// integrity rules. Records are built from real engine runs on SYNTHETIC pose
/// (`SyntheticBiomechanics`), then edited to represent each scenario; no real-athlete data.
@Suite("Performance Report 2.0")
struct PerformanceReportTests {
    private let day = 86_400.0

    private func record(_ edit: (inout AnalysisRecord) -> Void = { _ in }) -> AnalysisRecord {
        var r = PresentationTests.record()
        edit(&r)
        return r
    }

    private func report(_ r: AnalysisRecord, view: ComparableView = .side, others: [RankingEntry] = [],
                        suitability: [SuitabilityFinding] = [], outcome: String? = nil) -> PerformanceReport {
        PerformanceReport.make(.init(presentation: AnalysisPresentationBuilder.make(r), record: r, view: view, others: others,
                                     suitability: suitability, outcomeText: outcome))
    }

    private func entry(_ daysAgo: Double, overall: Double?, contact: Double? = nil, type: KickType = .fieldGoal,
                       view: ComparableView = .side, engine: String = PoseVideoAnalysisService.version, completed: Bool = true) -> RankingEntry {
        RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_800_000_000 - daysAgo * day), kickType: type, view: view,
                     engineVersion: engine, completed: completed, overallScore: overall,
                     categoryScores: contact.map { [.contact: $0] } ?? [:])
    }

    // 1. Fully supported side view.
    @Test func fullySupportedSideView() throws {
        let r = record()
        let rep = report(r)
        let overall = try #require(r.overallScore)
        #expect(rep.headline.score == Int(overall.rounded()))
        #expect(rep.headline.label == PerformanceReport.Label(score: overall))
        #expect(rep.headline.unavailableTitle == nil)
        #expect(rep.headline.viewText == "Side view")
        #expect(rep.categories.map(\.title) == ["Approach", "Plant", "Swing", "Body Position at Contact", "Follow-Through"])
        #expect(rep.strengths.count <= 3 && rep.issues.count <= 3 && rep.focus.count <= 2)
        #expect(rep.issues.allSatisfy { !$0.cue.isEmpty }, "every issue carries one cue")
        #expect(rep.footnote.contains("not percentiles"))
        let scores: [Int] = rep.categories.compactMap(\.score)
        #expect(scores.allSatisfy { (0...100).contains($0) })
    }

    // 2. Rear view: 4 measurements, no score.
    @Test func rearViewWithMeasurementsButNoScore() {
        let r = record { r in
            r.overallScore = nil
            r.categories = r.categories.map { var c = $0; c.score = nil; c.status = .unavailable; return c }
            r.metrics = Array(r.metrics.filter { $0.value != nil }.prefix(4))
            r.observations = []
        }
        let rep = report(r, view: .depth)
        #expect(rep.headline.score == nil)
        #expect(rep.headline.unavailableTitle == "Partial Analysis — Overall Score Unavailable")
        #expect(rep.categories.allSatisfy { $0.statusText == "Not rated" && $0.standing.rank == nil })
        #expect(rep.strengths.isEmpty && rep.issues.isEmpty, "no filler")
        #expect(rep.history?.previous == nil)
    }

    // 3. Short clip: ball contact found, no plant (plant metrics missing).
    @Test func shortClipWithoutPlant() {
        let r = record { r in
            r.metrics = r.metrics.filter { $0.phase != .plant }
            r.categories = r.categories.map { c in
                guard c.category == .plant || c.category == .approach else { return c }
                var x = c; x.score = nil; x.status = .unavailable; return x
            }
            r.overallScore = 71
        }
        let rep = report(r, view: .depth)
        let plant = rep.categories.first { $0.category == .plant }
        #expect(plant?.statusText == "Not rated")
        #expect(plant?.notRatedReason != nil)
        #expect(rep.headline.score == 71, "3 rated areas are enough for the engine's overall")
    }

    // 4. Failed contact.
    @Test func failedContactHasNoScore() {
        let r = record { $0.status = .failed; $0.failureReason = "Couldn't pinpoint the strike." }
        var p = AnalysisPresentationBuilder.make(r)
        p.header.outcome = .kickDetectedTimingUncertain
        let rep = PerformanceReport.make(.init(presentation: p, record: r, view: .depth, others: []))
        #expect(rep.headline.score == nil)
        #expect(rep.headline.unavailableTitle == "Contact Not Found — No Score")
        #expect(rep.strengths.isEmpty && rep.issues.isEmpty && rep.focus.isEmpty)
        #expect(!rep.recordingAdvice.isEmpty, "recommend a better recording instead of drills")
        #expect(rep.history == nil)
    }

    // 5. No kick.
    @Test func noKickFound() {
        let r = record { $0.status = .failed }
        var p = AnalysisPresentationBuilder.make(r)
        p.header.outcome = .noKickDetected
        let rep = PerformanceReport.make(.init(presentation: p, record: r, view: .side, others: []))
        #expect(rep.headline.unavailableTitle == "No Kick Found")
        #expect(rep.nextStep == "Record a clearer clip")
    }

    // 6. Several comparable kicks: rankings.
    @Test func comparableKicksAreRanked() throws {
        let r = record { $0.overallScore = 80 }
        let contact = try #require(AnalysisPresentationBuilder.make(r).categories.first { $0.category == .contact }?.score)
        let others = [entry(10, overall: 70, contact: contact + 5), entry(5, overall: 75, contact: contact - 5), entry(2, overall: 85, contact: contact - 10)]
        let rep = report(r, others: others)
        let h = try #require(rep.history)
        #expect(h.previous == 85 && h.change == -5)
        #expect(h.best == 85 && !h.isPersonalBest)
        let average: Double = 230.0 / 3
        #expect(abs((h.recentAverage ?? 0) - average) < 1e-9)
        #expect(h.standing.rank == 2 && h.standing.outOf == 4)
        #expect(h.standing.text == "#2 of 4 comparable kicks")
        let c = rep.categories.first { $0.category == .contact }
        #expect(c?.standing.rank == 2 && c?.standing.outOf == 4)
        #expect(h.trend != nil)
    }

    // 7. Only one eligible kick: no ranking.
    @Test func oneEligibleKickIsNotRanked() {
        let rep = report(record(), others: [entry(3, overall: 60, contact: 50)])
        #expect(rep.history?.standing.rank == nil)
        #expect(rep.history?.standing.text == PersonalRanking.notEnoughText)
        #expect(rep.history?.message == PersonalRanking.historyWillPopulate)
        #expect(rep.categories.allSatisfy { $0.standing.rank == nil })
    }

    // 8. Incompatible views or kick types are never compared.
    @Test func incompatibleKicksAreExcluded() {
        let others = [entry(3, overall: 60, view: .depth), entry(4, overall: 61, type: .kickoff), entry(5, overall: 62, view: .unknown),
                      entry(6, overall: 63, engine: "pose-biomechanics-2.7.0"), entry(7, overall: 64, engine: "pose-biomechanics-2.9.0+assisted")]
        let rep = report(record(), others: others)
        #expect(rep.history?.previous == nil)
        #expect(rep.history?.standing.rank == nil)
        let note = rep.history?.exclusionNote ?? ""
        #expect(note.contains("older engine") && note.contains("another view") && note.contains("user-assisted"))
        // An unrecorded view is never ranked at all.
        let unknown = report(record(), view: .unknown, others: [entry(3, overall: 60, view: .unknown), entry(4, overall: 60, view: .unknown)])
        #expect(unknown.history?.standing.rank == nil)
    }

    // 9. Low confidence: no drills, record better; tentative quality.
    @Test func lowConfidenceRecommendsABetterRecording() {
        let r = record { $0.confidence = 0.3 }
        let rep = report(r, suitability: [SuitabilityFinding(kind: .kickerSmall, severity: .limiting, message: "Move closer.")])
        #expect(rep.headline.quality == .limited)
        #expect(rep.focus.isEmpty)
        #expect(rep.recordingAdvice == ["Move closer."])
        let blocked = report(record(), suitability: [SuitabilityFinding(kind: .kickerTooSmall, severity: .blocking, message: "Too small.")])
        #expect(blocked.headline.quality <= .limited)
    }

    // 10. Missing history / older analyses.
    @Test func olderAnalysesAndMissingHistory() {
        let rep = report(record(), others: [entry(30, overall: 90, engine: "pose-biomechanics-2.5.0"), entry(20, overall: nil)])
        #expect(rep.history?.previous == nil, "an older engine's score and a missing score are never used")
        #expect(rep.history?.message == PersonalRanking.historyWillPopulate)
        let r = record { $0.engineVersion = "pose-biomechanics-2.6.0" }
        let old = report(r, others: [entry(3, overall: 60), entry(4, overall: 62)])
        #expect(old.history?.standing.rank == nil, "an older analysis isn't ranked against the current scoring model")
        #expect(old.footnote.contains("earlier (not compared)"))
    }

    // MARK: Integrity rules

    @Test func scoresAreWholeNumbersAndLabelsFollowTheDocumentedBands() {
        #expect(PerformanceReport.Label(score: 97.0) == .excellent)
        #expect(PerformanceReport.Label(score: 84.6) == .excellent, "rounded first: shown as 85")
        #expect(PerformanceReport.Label(score: 84.4) == .good)
        #expect(PerformanceReport.Label(score: 69.5) == .good)
        #expect(PerformanceReport.Label(score: 50) == .developing)
        #expect(PerformanceReport.Label(score: 49.4) == .needsWork)
        #expect(PerformanceReport.Label.criteria.contains("provisional"))
    }

    @Test func theUserEnteredResultIsSeparateFromTheTechniqueScore() {
        let r = record()
        let a = report(r, outcome: "Made · 35 yd"), b = report(r, outcome: "Missed left")
        #expect(a.outcomeText == "Made · 35 yd")
        #expect(a.headline == b.headline, "the result never changes the technique score")
        #expect(PerformanceReport.outcomeLabel.contains("entered by you"))
    }

    @Test func userAssistedAnalysesAreLabeled() {
        let r = record { $0.engineVersion = PoseVideoAnalysisService.version + "+assisted" }
        let rep = report(r)
        #expect(rep.headline.isUserAssisted && rep.headline.modeText == "User-assisted")
    }

    @Test func rankingRulesAreDeterministic() {
        #expect(PersonalRanking.standing(80, others: [80, 70]).rank == 1, "ties share the better rank")
        #expect(PersonalRanking.standing(nil, others: [1, 2, 3]).text == "Not rated")
        #expect(PersonalRanking.standing(50, others: [60]).rank == nil)
        #expect(PersonalRanking.trend([50, 55, 60, 65]) == .improving)
        #expect(PersonalRanking.trend([60, 60, 61]) == .steady)
        #expect(PersonalRanking.trend([70, 60, 50]) == .declining)
        #expect(ScoringModel.family(of: "pose-biomechanics-2.9.0+assisted") == "2.9")
        #expect(ScoringModel.version(ofEngine: "pose-biomechanics-2.8.2") == ScoringModel.current)
        #expect(ScoringModel.version(ofEngine: "pose-biomechanics-2.7.0") == nil)
        #expect(ScoringModel.family(of: "garbage") == nil)
        #expect(ComparableView(angle: .rear) == .depth && ComparableView(angle: .front) == .depth && ComparableView(angle: nil) == .unknown)
    }

    @Test func laterKicksAndReanalysesOfTheSameKickDontCount() {
        let r = record()
        var same = entry(1, overall: 99); same.kickID = r.kickID
        let later = entry(-3, overall: 99)
        let rep = report(r, others: [same, later, entry(5, overall: 40), entry(6, overall: 45)])
        #expect(rep.history?.best != 99)
        #expect(rep.history?.standing.outOf == 3)
    }

    @Test func detailedAnalysisListsMeasurementsAndShortReasons() {
        let r = record()
        let p = AnalysisPresentationBuilder.make(r)
        let rep = report(r)
        let d = DetailedAnalysisReport.make(report: rep, presentation: p, timing: ["Contact 1.533 s"])
        #expect(d.areas.count == 5)
        #expect(d.areas.allSatisfy { $0.metrics.allSatisfy(\.isAvailable) })
        #expect(d.notes.contains(PerformanceReport.Label.criteria))
    }
}
