import Foundation
import Testing
@testable import KickLab

/// Pure rules behind AthleteService. No SwiftData.
@Suite("Athlete service logic")
struct AthleteLogicTests {
    // MARK: Profile validation

    @Test func validProfilePasses() {
        let profile = AthleteProfile(firstName: "Sam", lastName: "Lee", graduationYear: 2028, heightInches: 70, weightPounds: 175, jerseyNumber: "07")
        #expect(AthleteProfileValidator.validate(profile).isEmpty)
    }

    @Test func nameIsRequired() {
        #expect(AthleteProfileValidator.validate(AthleteProfile(firstName: "  ", lastName: "")) == [.missingName])
        #expect(AthleteProfileValidator.validate(AthleteProfile(firstName: "", lastName: "Lee")).isEmpty)
    }

    @Test func implausibleValuesAreRejected() {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let profile = AthleteProfile(
            firstName: "Sam",
            dateOfBirth: now.addingTimeInterval(86_400),
            graduationYear: 1900,
            heightInches: .nan,
            weightPounds: 900,
            jerseyNumber: "12345"
        )
        let issues = AthleteProfileValidator.validate(profile, now: now)
        #expect(issues.contains(.dateOfBirthInFuture))
        #expect(issues.contains(.valueOutOfRange(.graduationYear, value: 1900)))
        #expect(issues.contains(.nonFiniteValue(.heightInches)))
        #expect(issues.contains(.valueOutOfRange(.weightPounds, value: 900)))
        #expect(issues.contains(.jerseyNumberTooLong))
    }

    @Test func normalizationTrimsText() {
        let p = AthleteProfile(firstName: " Sam ", lastName: " Lee ", schoolTeam: "   ", jerseyNumber: " 7 ").normalized
        #expect(p.firstName == "Sam")
        #expect(p.lastName == "Lee")
        #expect(p.schoolTeam == nil)
        #expect(p.jerseyNumber == "7")
    }

    // MARK: Deletion plan and fingerprint

    private let athleteID = UUID()
    private let sessions = [UUID(), UUID()]
    private let kicks = [UUID(), UUID(), UUID()]
    private let videos = [UUID(), UUID()]
    private let analyses = [UUID()]

    private func plan(
        sessions: [UUID]? = nil,
        kicks: [UUID]? = nil,
        videos: [UUID]? = nil,
        sizes: [Int64?] = [100, 250],
        name: String = "Sam Lee",
        at date: Date = Date(timeIntervalSince1970: 0)
    ) -> AthleteDeletionPlan {
        AthleteDeletionPlan(
            athleteID: athleteID,
            athleteDisplayName: name,
            sessionIDs: sessions ?? self.sessions,
            kickIDs: kicks ?? self.kicks,
            videoIDs: videos ?? self.videos,
            analysisIDs: analyses,
            videoFileSizes: sizes,
            generatedAt: date
        )
    }

    @Test func planCountsEverything() {
        let p = plan()
        #expect(p.sessionCount == 2)
        #expect(p.kickCount == 3)
        #expect(p.videoCount == 2)
        #expect(p.analysisCount == 1)
        #expect(p.estimatedMediaBytes == 350)
    }

    @Test func unknownVideoSizesCountAsZero() {
        #expect(plan(sizes: [nil, 40]).estimatedMediaBytes == 40)
    }

    @Test func fingerprintIgnoresOrderAndGenerationTime() {
        let a = plan(kicks: kicks, at: Date(timeIntervalSince1970: 0))
        let b = plan(kicks: kicks.reversed(), at: Date(timeIntervalSince1970: 999))
        #expect(a.matches(b))
        #expect(a.fingerprint == b.fingerprint)
    }

    @Test func addedOrRemovedRecordsMakeThePlanStale() {
        let original = plan()
        #expect(!original.matches(plan(kicks: kicks + [UUID()])))
        #expect(!original.matches(plan(sessions: [sessions[0]])))
        #expect(!original.matches(plan(videos: videos + [UUID()], sizes: [100, 250, nil])))
        #expect(!original.matches(plan(sizes: [100, 999])))
    }

    @Test func swappingAKickForAnotherWithTheSameCountIsStale() {
        let original = plan()
        #expect(!original.matches(plan(kicks: [kicks[0], kicks[1], UUID()])))
    }

    @Test func fingerprintIsDeterministic() {
        let ids = [UUID(uuidString: "00000000-0000-0000-0000-000000000001")!]
        let a = AthleteHistoryFingerprint(sessionIDs: ids, kickIDs: [], videoIDs: [], analysisIDs: [], mediaBytes: 0)
        let b = AthleteHistoryFingerprint(sessionIDs: ids, kickIDs: [], videoIDs: [], analysisIDs: [], mediaBytes: 0)
        let moved = AthleteHistoryFingerprint(sessionIDs: [], kickIDs: ids, videoIDs: [], analysisIDs: [], mediaBytes: 0)
        #expect(a.digest == b.digest)
        #expect(a.digest != moved.digest)
    }

    // MARK: Confirmation

    @Test func confirmationMustMatchTheAthleteName() {
        let p = plan(name: "Sam Lee")
        #expect(p.confirmationPhrase == "Sam Lee")
        #expect(p.isConfirmed(by: AthleteDeletionConfirmation(typedText: " Sam Lee ")))
        #expect(!p.isConfirmed(by: AthleteDeletionConfirmation(typedText: "sam lee")))
        #expect(!p.isConfirmed(by: AthleteDeletionConfirmation(typedText: "")))
    }

    @Test func unnamedAthleteRequiresDELETE() {
        let p = plan(name: "  ")
        #expect(p.confirmationPhrase == "DELETE")
        #expect(p.isConfirmed(by: AthleteDeletionConfirmation(typedText: "DELETE")))
    }
}
