import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: real SwiftData plus real files in a temporary directory.
@MainActor
@Suite("VideoStorageService")
struct VideoStorageServiceTests {
    let f: ServiceFixture
    let temp: TemporaryDirectory
    let store: ManagedMediaStore
    let videos: VideoStorageService
    let athlete: Athlete
    let kick: Kick

    init() throws {
        f = try ServiceFixture()
        temp = try TemporaryDirectory()
        store = ManagedMediaStore(
            locations: MediaLocations(baseURL: temp.kickLabBase),
            metadataReader: FixedMetadataReader(metadata: VideoMediaMetadata(
                durationSeconds: 3.2, frameRate: 240, pixelWidth: 1080, pixelHeight: 1920, hasAudio: true
            )),
            thumbnailGenerator: WritingThumbnailGenerator()
        )
        try store.prepareDirectories()
        videos = VideoStorageService(context: f.context, store: store)
        athlete = try f.makeAthlete()
        kick = try f.makeKick(for: athlete)
    }

    private func source(_ name: String = "clip.mov", bytes: Int = 64) throws -> URL {
        try temp.writeFile(named: "\(UUID().uuidString)-\(name)", bytes: Array(repeating: 7, count: bytes))
    }

    // MARK: Import

    @Test func importAttachesVideoWithRelativePathsAndMetadata() async throws {
        defer { temp.remove() }
        let src = try source(bytes: 100)
        let video = try await videos.importVideo(from: src, for: kick, angle: .side, sourceType: .filesImport)

        #expect(video.kick?.id == kick.id)
        let path = try #require(video.relativeFilePath)
        #expect(!path.hasPrefix("/"))
        #expect(path == ManagedPath.originalVideoPath(kickID: kick.id, videoID: video.id, fileExtension: "mov"))
        #expect(videos.fileExists(for: video))
        #expect(video.storageStatus == .local)
        #expect(video.fileSizeBytes == 100)
        #expect(video.thumbnailRelativePath == ManagedPath.thumbnailPath(kickID: kick.id, videoID: video.id))
        #expect(video.durationSeconds == 3.2)
        #expect(video.frameRate == 240)
        #expect(video.pixelWidth == 1080 && video.pixelHeight == 1920)
        #expect(video.hasAudio == true)
        #expect(video.angleType == .side)
        #expect(video.sourceType == .filesImport)
        #expect(fileBytes(at: src)?.count == 100, "the source file is untouched")
        #expect(!f.context.hasChanges)
    }

    @Test func firstVideoBecomesPrimaryAndMakingAnotherPrimaryClearsIt() async throws {
        defer { temp.remove() }
        let first = try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        let second = try await videos.importVideo(from: try source(), for: kick, angle: .rear, sourceType: .captured)
        #expect(first.isPrimary)
        #expect(!second.isPrimary)
        #expect(second.sortOrder > first.sortOrder)

        let third = try await videos.importVideo(from: try source(), for: kick, angle: .front, sourceType: .captured, makePrimary: true)
        #expect((kick.videos ?? []).filter(\.isPrimary).map(\.id) == [third.id])

        try videos.setPrimary(second)
        #expect((kick.videos ?? []).filter(\.isPrimary).map(\.id) == [second.id])
    }

    @Test func thumbnailFailureDoesNotFailImport() async throws {
        defer { temp.remove() }
        let failingStore = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: FailingThumbnailGenerator())
        let service = VideoStorageService(context: f.context, store: failingStore)
        let video = try await service.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        #expect(video.thumbnailRelativePath == nil)
        #expect(service.fileExists(for: video))
    }

    @Test func failedSaveDiscardsTheCopiedFiles() async throws {
        defer { temp.remove() }
        let failing = VideoStorageService(context: f.context, store: store, saveHandler: ServiceFixture.failingSave)
        await #expect(throws: VideoStorageError.self) {
            _ = try await failing.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        }
        #expect(try f.count(VideoAsset.self) == 0)
        #expect(store.orphanReport(referencedMediaPaths: [], referencedAnalysisPaths: [], minimumAge: 0).isEmpty)
    }

    @Test func modelsFromAnotherContextAreRejected() async throws {
        defer { temp.remove() }
        let other = try ServiceFixture()
        let foreignKick = try other.makeKick(for: try other.makeAthlete())
        await #expect(throws: VideoStorageError.notInServiceContext) {
            _ = try await videos.importVideo(from: try source(), for: foreignKick, angle: .side, sourceType: .captured)
        }
    }

    // MARK: Status

    @Test func missingFileProducesMissingStatusNotACrash() async throws {
        defer { temp.remove() }
        let video = try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        try FileManager.default.removeItem(at: try #require(videos.fileURL(for: video)))

        #expect(!videos.fileExists(for: video))
        #expect(try videos.refreshStorageStatus(of: video) == .missing)
        #expect(video.storageStatus == .missing)
    }

    @Test func photosReferenceIsKeptAndNeverDeleted() async throws {
        defer { temp.remove() }
        let video = try await videos.importVideo(
            from: try source(), for: kick, angle: .side, sourceType: .photosImport, photosLocalIdentifier: "PHOTOS-ASSET-1"
        )
        #expect(video.photosLocalIdentifier == "PHOTOS-ASSET-1")

        // The managed copy disappears: status falls back to the Photos reference.
        try FileManager.default.removeItem(at: try #require(videos.fileURL(for: video)))
        #expect(try videos.refreshStorageStatus(of: video) == .photosLibrary)

        // Cleanup requests contain only managed paths, never the Photos identifier.
        let request = VideoStorageService.managedFiles(of: [video])
        #expect(!request.relativePaths.contains("PHOTOS-ASSET-1"))
        let thumbnail = try #require(video.thumbnailRelativePath)
        let outcome = try videos.removeVideo(video)
        #expect(outcome.removed == [thumbnail])
        #expect(outcome.alreadyMissing.count == 1)
    }

    @Test func corruptedPathIsRejectedAndNothingOutsideTheRootIsTouched() throws {
        defer { temp.remove() }
        let sentinel = try temp.writeFile(named: "escape.mov")
        let video = VideoAsset(angleType: .side, storageStatus: .local, relativeFilePath: "../../escape.mov")
        f.context.insert(video)
        video.kick = kick
        try f.context.save()

        #expect(videos.fileURL(for: video) == nil)
        #expect(!videos.fileExists(for: video))
        #expect(try videos.refreshStorageStatus(of: video) == .missing)
        let outcome = try videos.removeVideo(video)
        #expect(outcome.rejectedUnsafe == ["../../escape.mov"])
        #expect(exists(sentinel))
    }

    // MARK: Removal

    @Test func removingAVideoRemovesItsManagedCopyAndPromotesTheNextPrimary() async throws {
        defer { temp.remove() }
        let first = try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        let second = try await videos.importVideo(from: try source(), for: kick, angle: .rear, sourceType: .captured)
        let firstURL = try #require(videos.fileURL(for: first))

        let outcome = try videos.removeVideo(first)

        #expect(outcome.removed.count == 2)   // original + thumbnail
        #expect(!exists(firstURL))
        #expect(try f.count(VideoAsset.self) == 1)
        #expect(second.isPrimary)
        #expect(videos.fileExists(for: second))
    }

    @Test func removeAllVideosRemovesRecordsAndTheKickFolder() async throws {
        defer { temp.remove() }
        try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        try await videos.importVideo(from: try source("b.mp4"), for: kick, angle: .rear, sourceType: .captured)

        let outcome = try videos.removeAllVideos(of: kick)

        #expect(outcome.isComplete)
        #expect(try f.count(VideoAsset.self) == 0)
        #expect(!exists(store.mediaRootURL.appendingPathComponent(ManagedPath.kickDirectory(kickID: kick.id))))
        #expect(try f.count(Kick.self) == 1, "the kick itself is kept")
    }

    // MARK: Totals and orphans

    @Test func mediaByteTotals() async throws {
        defer { temp.remove() }
        let a = try await videos.importVideo(from: try source(bytes: 100), for: kick, angle: .side, sourceType: .captured)
        let otherKick = try f.makeKick(for: athlete)
        try await videos.importVideo(from: try source(bytes: 250), for: otherKick, angle: .side, sourceType: .captured)

        let totals = videos.mediaByteTotals(for: athlete)
        #expect(totals.videoCount == 2)
        #expect(totals.recordedBytes == 350)
        #expect(totals.onDiskBytes == 350 + 4 + 4)   // two 4-byte thumbnails
        #expect(totals.missingFileCount == 0)

        try FileManager.default.removeItem(at: try #require(videos.fileURL(for: a)))
        let afterLoss = videos.mediaByteTotals(for: athlete)
        #expect(afterLoss.missingFileCount == 1)
        #expect(afterLoss.recordedBytes == 350, "recorded size is history; on-disk size is reality")
        #expect(afterLoss.onDiskBytes == 250 + 4 + 4)
    }

    @Test func orphanSweepDeletesOnlyUnreferencedKickLabMedia() async throws {
        defer { temp.remove() }
        let kept = try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        let stray = try temp.writeFile("deadbeef/cafe/original.mov", under: store.mediaRootURL)
        let strayArtifact = try temp.writeFile("feedface/pose.bin", under: store.analysisRootURL)
        let outsideRoot = try temp.writeFile(named: "unrelated.mov")

        #expect(try videos.orphanReport(minimumAge: 3600).isEmpty, "fresh files are protected by the grace period")

        let outcome = try videos.sweepOrphans(minimumAge: 0)
        #expect(outcome.removed.sorted() == ["deadbeef/cafe/original.mov", "feedface/pose.bin"])
        #expect(!exists(stray))
        #expect(!exists(strayArtifact))
        #expect(exists(outsideRoot))
        #expect(videos.fileExists(for: kept))
        #expect(try videos.sweepOrphans(minimumAge: 0).removed.isEmpty, "sweeping is idempotent")
    }

    @Test func artifactsLocationIsUnderTheAnalysisRoot() async throws {
        defer { temp.remove() }
        let video = try await videos.importVideo(from: try source(), for: kick, angle: .side, sourceType: .captured)
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [video])
        let location = try videos.artifactsLocation(for: analysis)
        #expect(location.relativePath == ManagedPath.analysisDirectory(analysisID: analysis.id))
        #expect(location.url.deletingLastPathComponent().path == store.analysisRootURL.path)
    }
}
