import Foundation
import Testing
@testable import KickLab

/// Step 12E: replay markers and speeds, metric provenance, and the drill library.
@Suite("Replay, provenance and drills")
struct ReplayAndDrillTests {
    @Test func phaseMarkersSayWhereTheirTimeCameFrom() {
        let auto = KickPhaseDetector.detect(RealReferenceClipRear.signals, kickType: .fieldGoal, perspective: .depthAway)
        let markers = PhaseMarker.markers(from: auto)
        #expect(markers.map(\.phase) == [.setup, .approach, .plant, .contact, .followThrough])
        #expect(markers.first { $0.phase == .contact }?.source == .estimated)
        #expect(markers.first { $0.phase == .contact }?.title == "Estimated Contact")
        let assisted = KickPhaseDetector.detect(RealReferenceClipRear.signals, kickType: .fieldGoal,
                                                assistance: PhaseDetectionAssistance(contactTime: 3.867), perspective: .depthAway)
        let contact = PhaseMarker.markers(from: assisted).first { $0.phase == .contact }
        #expect(contact?.source == .userSupplied)
        #expect(contact?.title == "Your Contact")
        #expect(contact?.source.label == "chosen by you")
    }

    @Test func slowMotionRatesNeverInventFrames() {
        #expect(PlaybackRate.allCases.map(\.rawValue) == [1, 0.5, 0.25])
        #expect(PlaybackRate.allCases.map(\.title) == ["1×", "½×", "¼×"])
    }

    @Test func metricRowsCarryTheirEvidenceOrigin() {
        let records = [
            StoredMetricRecord(key: KickMetricKey.plantToContactTime.rawValue, value: 0.267, unit: .seconds, confidence: 0.5, status: .estimated, phase: .plant),
            StoredMetricRecord(key: KickMetricKey.approachSpeed.rawValue, value: 4, unit: .bodyLengthsPerSecond, confidence: 0.8, status: .measured, phase: .approach),
            StoredMetricRecord(key: KickMetricKey.kickingKneeAngleAtContact.rawValue, value: nil, unit: .degrees, confidence: nil, status: .unavailable, phase: .contact),
        ]
        let auto = AnalysisPresentationBuilder.metricRows(records)
        #expect(auto.first { $0.key == .plantToContactTime }?.provenanceText == "Estimated from video")
        #expect(auto.first { $0.key == .approachSpeed }?.provenanceText == "Measured from video")
        #expect(auto.first { $0.key == .kickingKneeAngleAtContact }?.provenanceText == "Unavailable")
        let assisted = AnalysisPresentationBuilder.metricRows(records, userAssisted: true)
        #expect(assisted.first { $0.key == .plantToContactTime }?.provenanceText == "Uses the contact you chose")
        #expect(assisted.first { $0.key == .approachSpeed }?.provenanceText == "Measured from video", "doesn't depend on contact")
    }

    @Test func theDrillLibraryIsCompleteAndLabeledGeneral() {
        let ids = DrillLibrary.all.map(\.id)
        #expect(Set(ids).count == ids.count, "unique ids")
        for focus in DrillFocus.allCases { #expect(!DrillLibrary.drills(for: focus).isEmpty, "\(focus)") }
        for drill in DrillLibrary.all {
            #expect(!drill.instructions.isEmpty && !drill.equipment.isEmpty && !drill.commonMistakes.isEmpty, "\(drill.id)")
            #expect(!drill.kickTypes.isEmpty && !drill.repetitions.isEmpty, "\(drill.id)")
            #expect(drill.cautions.contains { $0.contains("pain") }, "\(drill.id): never train through pain")
        }
        #expect(DrillLibrary.generalCaution.contains("not individually prescribed"))
        #expect(DrillLibrary.drills(for: .puntingFundamentals).allSatisfy { $0.kickTypes.contains(.punt) })
    }

    @Test func suggestionsFollowTheFlaggedAreasOnly() {
        #expect(DrillSuggestions.drills(for: [], kickType: .fieldGoal).isEmpty, "nothing flagged, nothing suggested")
        let s = DrillSuggestions.drills(for: [.plant, .plant, .swing, .followThrough, .approach], kickType: .fieldGoal)
        #expect(s.count == 3, "at most three, like the coaching priorities")
        #expect(s.map(\.focus) == [.plantFootPosition, .legSwing, .followThrough])
        #expect(DrillSuggestions.drills(for: [.overall], kickType: .fieldGoal).isEmpty)
    }
}
