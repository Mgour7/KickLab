import Foundation
import Testing
@testable import KickLab

/// Build 18 — Biomechanics Intelligence 3.0 (engine pose-biomechanics-3.0.0).
///
/// Evidence classes:
/// - REAL FRAMES, other pose model: IMG_1709 (rear, 12.202 s) — MediaPipe landmarks of the
///   real frames and the real YOLOX-S detections, through the full production pipeline on
///   Linux. NOT an Apple Vision run.
/// - SYNTHETIC: hand-built inputs for the rules (confidence levels, scoring exclusions).
@Suite("Biomechanics Intelligence 3.0")
struct Biomechanics30Tests {
    typealias Clip = RealVideoClip1709
    typealias Real = RealVideo1709Football

    private func run(football: FootballTrack?, angle: VideoAngleType = .rear) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                          cameraAngle: angle, football: football))
    }

    private func realTrack() -> FootballTrack {
        let context = FootballAnalysisContext.make(from: run(football: nil), kickingFoot: .right)
        return FootballTrackAnalyzer.analyze(broadScan: Real.broadScan, scanTimes: Real.scanTimes, precision: Real.precisionFrames,
                                             ankle: context.ankle, strike: context.strike, aspect: Clip.displayAspectRatio,
                                             duration: Clip.durationSeconds, detector: .yoloxS)
    }

    private func m(_ out: KickAnalysisPipelineOutput, _ key: KickMetricKey) -> KickMetricMeasurement? {
        out.biomechanics.measurements.first { $0.key == key }
    }

    // MARK: Recovered rear-view measurements (real frames)

    @Test func rearViewPlantMeasurementsAreRecoveredOnRealFrames() throws {
        let out = run(football: realTrack())
        // Contact regression: unchanged by 3.0.0.
        #expect(abs((out.phases.estimatedContactTime ?? 0) - 7.935) < 0.002)
        let beside = try #require(m(out, .plantBallLateralOffset))
        #expect(beside.isAvailable)
        #expect(abs((beside.value ?? 0) - 0.569) < 0.01, "plant ankle about half a torso length beside the ball (\(beside.value ?? -1))")
        #expect((beside.confidence ?? 0) >= 0.5)
        let movement = try #require(m(out, .plantLateralMovement))
        #expect(movement.isAvailable && (movement.value ?? 1) < 0.3)
        // Still the four earlier rear measurements, and nothing side-only.
        for key in [KickMetricKey.plantToContactTime, .followThroughDuration, .lateralTrunkLeanAtContact, .plantFootWidth] {
            #expect(m(out, key)?.isAvailable == true, "\(key)")
        }
        #expect(m(out, .kickingKneeAngleAtContact)?.unavailableReason == .cameraAngleUnsupported)
        // Descriptive: never scored, so no rear area appears from them.
        let profile = BiomechanicsProfile.standard(for: .fieldGoal)
        #expect(profile.scoring[.plantBallLateralOffset] == nil && profile.scoring[.plantLateralMovement] == nil)
        #expect(out.biomechanics.categories.first { $0.category == .plant }?.score == nil)
    }

    @Test func withoutTheBallThePlacementIsNotInvented() {
        let out = run(football: nil)
        #expect(m(out, .plantBallLateralOffset)?.isAvailable == false)
        // Pose alone found only a strike window, so contact-timed values are withheld.
        #expect(m(out, .plantBallLateralOffset)?.unavailableReason == .contactTimingUncertain)
        var context = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear, perspective: .depthAway)
        context.ballRest = nil
        #expect(FootballTrack.kickedBallRest(.unavailable("none")) == nil)
    }

    @Test func frontalPlaneMeasurementsAreNeverMadeFromTheSide() {
        let context = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side, perspective: .side)
        for key in [KickMetricKey.plantBallLateralOffset, .plantLateralMovement] {
            #expect(PerspectiveMetricSupport.support(key, context: context) == .unsupported)
        }
        let oblique = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .oblique, perspective: .oblique)
        #expect(PerspectiveMetricSupport.support(.plantBallLateralOffset, context: oblique) == .unsupported)
    }

    // MARK: Kicking-leg tracking (real frames)

    @Test func kickingLegTrackingSeparatesMeasuredInferredOverlappingAndUnavailable() throws {
        let out = run(football: realTrack())
        let report = try #require(KickingLegTrackingReport.make(timeline: out.kickerTimeline, signals: out.signals, phases: out.phases,
                                                                kickingFoot: .right, perspective: .depthAway))
        let total = report.measured + report.inferred + report.overlapping + report.unavailable
        #expect(total >= 20, "≈0.7 s at 30 fps")
        #expect(report.measured > report.overlapping)
        // On this clip the ankles cross in the image about 0.43 s after contact (the foot
        // coming down in front of the plant foot, seen from behind).
        if let lost = report.lostAt {
            #expect(lost > 7.935)
            #expect(report.cause.contains("projection"))
        }
        let d = AnalysisDiagnosticsBuilder.build(AnalysisDiagnosticsInput(output: out), storedStatus: "completed", storedFailureReason: nil,
                                                kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0))
        #expect(d.kickingLeg != nil)
        #expect(d.contactSummaryLines.contains { $0.contains("kicking-leg tracking") })
    }

    // MARK: Contact confidence (Part B)

    private func phases(outcome: ContactOutcome, path: BallFusionReport.Path?, earliest: Double, latest: Double) -> KickPhaseDetectionResult {
        var p = KickPhaseDetector.detect(DepthViewSynthetic.run(DepthViewSynthetic.Script(), angle: .rear).signals, kickType: .fieldGoal, perspective: .depthAway)
        p.evidence?.contactOutcome = outcome
        p.evidence?.contactEarliestTime = earliest
        p.evidence?.contactLatestTime = latest
        var f = BallFusionReport(detectorRan: true, ballSelected: true)
        f.accepted = path != nil
        f.acceptancePath = path?.rawValue
        p.evidence?.ballFusion = f
        return p
    }

    private func track(_ basis: String, seen: Int, of n: Int) -> FootballTrack {
        var t = FootballTrack(method: .automaticFootballDetection, detector: .yoloxS, note: "test")
        t.observations = (0..<n).map { i in
            FootballFrameObservation(time: Double(i) / 30, state: i < 2 ? .atRest : .moving, source: i < seen ? .detected : .unavailable,
                                     box: nil, score: i < seen ? 0.8 : nil, appearance: nil)
        }
        t.lastStationaryTime = 1 / 30.0
        t.firstPersistentMovementTime = 2 / 30.0
        t.movementBasis = basis
        return t
    }

    @Test func aNarrowIntervalAloneNeverMakesContactConfidenceHigh() {
        // The side reference: the spot emptied (restSiteVacated), one moving sighting, a
        // two-frame interval agreeing with pose. Build 16 called this "strong"; it is moderate.
        let side = ContactConfidenceBreakdown.make(phases: phases(outcome: .ballConstrainedContactInterval, path: .poseStrikeAgreement, earliest: 2.467, latest: 2.5),
                                                   football: track("restVanished", seen: 3, of: 6), poseTimingScore: 0.225, frame: 1 / 30)
        #expect(side.footballTracking == .moderate)
        #expect(side.timePrecision == .strong, "the interval IS narrow")
        #expect(side.contactEvent == .moderate)
        #expect(side.finalContact == .moderate, "…but that doesn't make the contact certain")
        // Seen moving away on most frames, agreeing with pose, two frames wide → strong.
        let rear = ContactConfidenceBreakdown.make(phases: phases(outcome: .ballConstrainedContactInterval, path: .poseStrikeAgreement, earliest: 7.902, latest: 7.968),
                                                   football: track("displacedDetections", seen: 5, of: 6), poseTimingScore: 0.15, frame: 1 / 30)
        #expect(rear.finalContact == .strong)
        // An earlier credible drive or the foot-swing rule never reach "strong".
        let earlier = ContactConfidenceBreakdown.make(phases: phases(outcome: .ballConstrainedContactInterval, path: .earlierCredibleDrive, earliest: 4.735, latest: 4.835),
                                                      football: track("displacedDetections", seen: 5, of: 6), poseTimingScore: 0.15, frame: 1 / 30)
        #expect(earlier.finalContact == .moderate)
        // Pose only, strike window → weak, whatever its width.
        let window = ContactConfidenceBreakdown.make(phases: phases(outcome: .strikeWindowOnly, path: nil, earliest: 1.5, latest: 1.533),
                                                     football: nil, poseTimingScore: 0.15, frame: 1 / 30)
        #expect(window.finalContact == .weak)
        #expect(side.plainLines.contains("Overall contact confidence: Moderate (rule-based, not a probability)"))
    }

    // MARK: Scoring (Part B)

    @Test func plantTimingIsMeasuredButNotScoredOrCoached() {
        let profile = BiomechanicsProfile.standard(for: .fieldGoal)
        #expect(profile.scoring[.plantToContactTime] == nil)
        #expect(KickMetricKey.plantToContactTime.definition.betterDirection == .none)
        let r = SyntheticBiomechanics.analyze(.fieldGoal)
        #expect(r.measurements.first { $0.key == .plantToContactTime }?.isAvailable == true, "still measured and shown")
        #expect(!r.findings.contains { $0.rule == .plantLate || $0.rule == .plantEarly })
        let plant = r.categories.first { $0.category == .plant }
        #expect(plant?.components.contains { $0.key == .plantToContactTime } != true)
    }

    @Test func noMetricIsScoredTwiceAndUnmeasurableMetricsAreNotPenalized() {
        for type in [KickType.fieldGoal, .kickoff, .punt] {
            let profile = BiomechanicsProfile.standard(for: type)
            let scored = profile.scoring.filter { $0.value.weight > 0 }.map(\.key)
            #expect(Set(scored).count == scored.count)
            for key in scored { #expect(!PerspectiveMetricSupport.frontalPlaneMetrics.contains(key), "\(key) is side-only scoring") }
        }
        // Only measured components contribute to a score; a missing one is excluded, not zero.
        let measurements = [KickMetricMeasurement(key: .plantFootDrift, definitionVersion: 1, value: 0.05, unit: .bodyLengths, status: .estimated,
                                                  confidence: 0.8, confidenceLevel: .high, phase: .plant, sampleTime: nil, windowStart: nil,
                                                  windowEnd: nil, unavailableReason: nil, missingPhase: nil, confidenceInputs: nil),
                            .unavailable(.plantKneeAngleAtContact, reason: .missingJoints)]
        let plant = KickScorer.scoreCategory(.plant, byKey: Dictionary(uniqueKeysWithValues: measurements.map { ($0.key, $0) }),
                                             profile: BiomechanicsProfile.standard(for: .fieldGoal))
        #expect(plant.score == 100, "the measured component scores; the missing one doesn't pull it down")
    }

    @Test func engineVersionAndScoringModel() {
        #expect(PoseVideoAnalysisService.version == "pose-biomechanics-3.0.0")
        #expect(ScoringModel.version(ofEngine: PoseVideoAnalysisService.version) == "provisional-bands-2")
    }
}
