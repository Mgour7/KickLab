import Foundation
import Testing
@testable import KickLab

@Suite("Step 10 personal profile statistics")
struct PersonalProfileTests {
    typealias F = PersonalFixture

    // MARK: Statistics

    @Test func distributionStatisticsAreExact() throws {
        let kicks = F.series(.plantToContactTime, [0.18, 0.20, 0.22, 0.19, 0.21])
        let b = try #require(try F.profile(kicks).baseline(.plantToContactTime))
        #expect(b.sampleCount == 5)
        #expect(near(b.lifetime.mean, 0.20, 1e-12))
        #expect(near(b.lifetime.median, 0.20, 1e-12))
        #expect(near(b.lifetime.standardDeviation, (0.001 / 4).squareRoot(), 1e-12), "sample SD (n − 1)")
        #expect(near(b.lifetime.robustSpread, 1.4826 * 0.01, 1e-12), "1.4826 × median absolute deviation")
        #expect(near(b.lifetime.minimum, 0.18, 1e-12))
        #expect(near(b.lifetime.maximum, 0.22, 1e-12))
        #expect(near(b.lifetime.lowerQuartile, 0.19, 1e-12))
        #expect(near(b.lifetime.upperQuartile, 0.21, 1e-12))
        #expect(b.lifetime.meanConfidence == 0.8)
        #expect(near(b.deviationScale, 0.03, 1e-12), "floored at the minimum meaningful difference")
        #expect(b.unit == .seconds, "Step 8 units are kept")
        #expect(b.lifetime.firstDate == F.date(0))
        #expect(b.lifetime.lastDate == F.date(4))

        #expect(PersonalStatistics.quantile([1, 2, 3, 4], 0.25) == 1.75)
        #expect(PersonalStatistics.sampleStandardDeviation([5]) == 0)
        #expect(PersonalStatistics.recencyWeight(ageDays: 60, halfLifeDays: 60) == 0.5)
        #expect(PersonalStatistics.recencyWeight(ageDays: -5, halfLifeDays: 60) == 1, "future dates count as now")
    }

    @Test func maturityProgresses() throws {
        let thresholds = MaturityThresholds()
        #expect([0, 2, 3, 7, 8, 19, 20, 50].map(thresholds.level(for:)) ==
                [.insufficient, .insufficient, .emerging, .emerging, .established, .established, .strong, .strong])
        for (count, expected) in [(2, ProfileMaturity.insufficient), (3, .emerging), (8, .established), (20, .strong)] {
            let kicks = F.series(.plantToContactTime, Array(repeating: 0.2, count: count))
            let p = try F.profile(kicks)
            #expect(p.eligibleKickCount == count)
            #expect(p.maturity == expected)
            #expect(p.baseline(.plantToContactTime)?.maturity == expected)
        }
        #expect(try F.profile([]).maturity == .insufficient)
        #expect(try F.profile(F.series(.plantToContactTime, [0.2, 0.2, 0.2])).kicksNeeded(for: .established, thresholds: thresholds) == 5)
    }

    @Test func metricMaturityCanDifferFromTheProfile() throws {
        var kicks = F.series(.plantToContactTime, Array(repeating: 0.2, count: 8))
        for i in 0..<2 { kicks[i].metrics[.torsoLeanAtContact] = HistoricalMetricValue(value: -5, confidence: 0.8, status: .estimated) }
        let p = try F.profile(kicks)
        #expect(p.maturity == .established)
        #expect(p.baseline(.torsoLeanAtContact)?.maturity == .insufficient)
    }

    // MARK: Eligibility

    @Test func confidenceFilteringIsConfigurable() throws {
        let kicks = F.series(.plantToContactTime, [0.2, 0.2, 0.2], confidence: 0.4) + F.series(.plantToContactTime, [0.3, 0.3, 0.3], firstIndex: 3)
        let p = try F.profile(kicks)
        #expect(p.baseline(.plantToContactTime)?.sampleCount == 3)
        #expect(near(p.baseline(.plantToContactTime)?.lifetime.mean, 0.3, 1e-12))
        #expect(p.metricExclusions[.plantToContactTime]?.lowConfidence == 3)
        #expect(p.eligibleKickCount == 3)
        #expect(p.kickExclusions.noEligibleMetrics == 3)

        var config = PersonalizationConfiguration()
        config.minimumMetricConfidence = 0.3
        #expect(try F.profile(kicks, configuration: config).baseline(.plantToContactTime)?.sampleCount == 6)
    }

    @Test func missingMetricsAreNeverZero() throws {
        var kicks = F.series(.plantToContactTime, [0.2, 0.3, 0.4])
        kicks.append(F.kick(3, values: [.torsoLeanAtContact: -5]))   // no plant timing at all
        var unavailable = F.kick(4, values: [:])
        unavailable.metrics[.plantToContactTime] = HistoricalMetricValue(value: nil, confidence: nil, status: .unavailable)
        kicks.append(unavailable)
        let p = try F.profile(kicks)
        let b = try #require(p.baseline(.plantToContactTime))
        #expect(b.sampleCount == 3)
        #expect(near(b.lifetime.mean, 0.3, 1e-12))
        #expect(near(b.lifetime.minimum, 0.2, 1e-12))
        #expect(p.metricExclusions[.plantToContactTime]?.unavailable == 1)
    }

    @Test func incompatibleDefinitionsAndIncompleteAnalysesAreSkipped() throws {
        var kicks = F.series(.plantToContactTime, [0.2, 0.2, 0.2])
        kicks[0].metrics[.plantToContactTime]?.definitionVersion = 99
        kicks.append(F.kick(5, values: [.plantToContactTime: 0.9], completed: false))
        let p = try F.profile(kicks)
        #expect(p.baseline(.plantToContactTime)?.sampleCount == 2)
        #expect(p.metricExclusions[.plantToContactTime]?.incompatibleDefinition == 1)
        #expect(p.kickExclusions.analysisNotCompleted == 1)
    }

    @Test func kickTypesAreNeverCombined() throws {
        let fieldGoals = F.series(.plantToContactTime, [0.2, 0.2, 0.2])
        let pats = (10..<14).map { F.kick($0, type: .pat, values: [.plantToContactTime: 0.5]) }
        let fg = try F.profile(fieldGoals + pats)
        #expect(fg.eligibleKickCount == 3)
        #expect(near(fg.baseline(.plantToContactTime)?.lifetime.mean, 0.2, 1e-12))
        #expect(fg.kickExclusions.differentKickType == 4)
        let pat = try F.profile(fieldGoals + pats, scope: F.scope(.pat))
        #expect(pat.eligibleKickCount == 4)
        #expect(near(pat.baseline(.plantToContactTime)?.lifetime.mean, 0.5, 1e-12))
        #expect(throws: PersonalizationError.unsupportedKickType) { try F.profile([], scope: F.scope(.unknown)) }
    }

    @Test func kickingFeetAreIsolated() throws {
        let right = F.series(.plantToContactTime, [0.2, 0.2, 0.2, 0.2, 0.2])
        let left = (10..<14).map { F.kick($0, foot: .left, values: [.plantToContactTime: 0.4]) }
        let unknown = F.kick(20, foot: nil, values: [.plantToContactTime: 0.9])
        let p = try F.profile(right + left + [unknown])
        #expect(p.eligibleKickCount == 5)
        #expect(near(p.baseline(.plantToContactTime)?.lifetime.mean, 0.2, 1e-12))
        #expect(p.kickExclusions.differentKickingFoot == 4)
        #expect(p.kickExclusions.unknownKickingFoot == 1)
        let l = try F.profile(right + left + [unknown], scope: F.scope(foot: .left))
        #expect(l.eligibleKickCount == 4)

        // The foot an old analysis used is recovered from the change log.
        var state = AthletePersonalizationState()
        state.recordFootChange(from: .right, to: .left, at: F.date(50))
        #expect(state.kickingFoot(at: F.date(10), current: .left) == .right)
        #expect(state.kickingFoot(at: F.date(60), current: .left) == .left)
        state.recordFootChange(from: .left, to: .right, at: F.date(70))
        #expect(state.kickingFoot(at: F.date(60), current: .right) == .left)
        #expect(state.kickingFoot(at: F.date(80), current: .right) == .right)
        state.recordFootChange(from: .right, to: .right, at: F.date(90))
        #expect(state.footChanges.count == 2, "no change recorded when the foot is the same")
    }

    @Test func cameraAngleRestrictsAngleDependentMetrics() throws {
        let side = (0..<3).map { F.kick($0, values: [.plantToContactTime: 0.2, .torsoLeanAtContact: -5], angle: .side) }
        let rear = (3..<6).map { F.kick($0, values: [.plantToContactTime: 0.2, .torsoLeanAtContact: 10], angle: .rear) }
        let p = try F.profile(side + rear, scope: F.scope(angle: .side))
        #expect(p.baseline(.plantToContactTime)?.sampleCount == 6, "timing doesn't depend on the camera")
        #expect(p.baseline(.torsoLeanAtContact)?.sampleCount == 3, "lean seen from behind isn't the same measurement")
        #expect(p.metricExclusions[.torsoLeanAtContact]?.differentCameraAngle == 3)
        #expect(near(p.baseline(.torsoLeanAtContact)?.lifetime.mean, -5, 1e-12))
        let any = try F.profile(side + rear, scope: F.scope(angle: nil))
        #expect(any.baseline(.torsoLeanAtContact)?.sampleCount == 6, "no angle requested, nothing filtered")
    }

    @Test func baselineEpochsLimitTheActiveBaseline() throws {
        let kicks = F.series(.plantToContactTime, [0.3, 0.3, 0.3, 0.2, 0.2, 0.2])
        var state = AthletePersonalizationState()
        let epoch = state.startNewBaseline(for: .fieldGoal, at: F.date(3), note: "New approach")
        #expect(epoch.generation == 1)
        #expect(state.startNewBaseline(for: .fieldGoal, at: F.date(4)).generation == 2)
        #expect(state.activeEpoch(for: .fieldGoal)?.generation == 2)
        #expect(state.activeEpoch(for: .kickoff) == nil)
        let p = try F.profile(kicks, scope: F.scope(epoch: epoch))
        #expect(p.eligibleKickCount == 3)
        #expect(near(p.baseline(.plantToContactTime)?.lifetime.mean, 0.2, 1e-12))
        #expect(p.kickExclusions.beforeBaselineEpoch == 3)
        #expect(try F.profile(kicks).eligibleKickCount == 6, "history is kept and usable")
    }

    // MARK: Success

    @Test func successIsNeverInferredFromMissingOutcomes() {
        let config = PersonalizationConfiguration()
        let evaluator = StandardKickSuccessEvaluator(configuration: config)
        func fg(_ r: KickResult?) -> KickSuccess { evaluator.evaluate(F.kick(0, result: r, values: [:])) }
        #expect(fg(.made) == .successful)
        #expect(fg(.missedLeft) == .unsuccessful)
        #expect(fg(.short) == .unsuccessful)
        #expect(fg(.blocked) == .unknown, "blocks are usually protection, not mechanics")
        #expect(fg(nil) == .unknown)
        #expect(fg(.unknown) == .unknown)

        let kickoff = F.kick(0, type: .kickoff, values: [:], outcome: KickOutcomeSummary(distanceYards: 65, touchback: true))
        #expect(evaluator.evaluate(kickoff) == .unknown, "no universal kickoff success formula")

        var configured = config
        configured.kickoffSuccess = KickoffSuccessCriteria(minimumDistanceYards: 60)
        configured.puntSuccess = PuntSuccessCriteria(minimumDistanceYards: 40, minimumHangTimeSeconds: 4)
        configured.blockedCountsAsMiss = true
        let e = StandardKickSuccessEvaluator(configuration: configured)
        #expect(e.evaluate(kickoff) == .successful)
        #expect(e.evaluate(F.kick(0, type: .kickoff, values: [:], outcome: KickOutcomeSummary(distanceYards: 55, touchback: false))) == .unsuccessful)
        #expect(e.evaluate(F.kick(0, type: .kickoff, values: [:], outcome: KickOutcomeSummary(touchback: false))) == .unknown, "distance unknown")
        #expect(e.evaluate(F.kick(0, type: .kickoff, values: [:], outcome: KickOutcomeSummary(distanceYards: 70, outOfBounds: true))) == .unsuccessful)
        #expect(e.evaluate(F.kick(0, type: .punt, values: [:], outcome: KickOutcomeSummary(distanceYards: 45, hangTimeSeconds: 4.2))) == .successful)
        #expect(e.evaluate(F.kick(0, type: .punt, values: [:], outcome: KickOutcomeSummary(distanceYards: 45))) == .unknown)
        #expect(e.evaluate(F.kick(0, result: .blocked, values: [:])) == .unsuccessful)
    }

    @Test func successfulAndUnsuccessfulProfilesAreSeparate() throws {
        let made = [0.04, 0.05, 0.06, 0.05, 0.05, 0.05]
        let missed = [0.28, 0.30, 0.32, 0.30, 0.30]
        let kicks = F.series(.plantFootDrift, made + missed, results: Array(repeating: .made, count: 6) + Array(repeating: .missedRight, count: 5))
        let p = try F.profile(kicks)
        #expect(p.successfulKickCount == 6)
        #expect(p.unsuccessfulKickCount == 5)
        let pattern = try #require(p.baseline(.plantFootDrift)?.successfulPattern)
        #expect(pattern.successful.count == 6)
        #expect(near(pattern.successful.mean, 0.05, 1e-12))
        #expect(near(pattern.unsuccessful?.mean, 0.30, 1e-12))
        #expect(pattern.isStrong == false, "6 < 8 successful kicks")
        #expect(near(pattern.rangeLow, 0.025, 1e-12), "widened to ± half the minimum meaningful difference")
        #expect(near(pattern.rangeHigh, 0.075, 1e-12))

        let r = try #require(p.relationship(.plantFootDrift))
        #expect(r.status == .associated)
        #expect(near(r.meanDifference, -0.25, 1e-12))
        #expect(r.successfulSideIsHigher == false)
        #expect((r.effectSize ?? 0) < -0.8)
        #expect(r.isOnUnsuccessfulSide(0.25))
        #expect(!r.isOnUnsuccessfulSide(0.08))
    }

    // MARK: Outcome relationships

    @Test func outcomeAssociationsNeedEnoughKicksEffectAndConfidence() throws {
        func relationship(made: [Double], missed: [Double], confidence: Double = 0.8) throws -> MetricOutcomeRelationship? {
            let kicks = F.series(.plantToContactTime, made + missed,
                                 results: Array(repeating: .made, count: made.count) + Array(repeating: .missedLeft, count: missed.count),
                                 confidence: confidence)
            return try F.profile(kicks).relationship(.plantToContactTime)
        }
        let few = try relationship(made: [0.1, 0.1, 0.1, 0.1], missed: [0.4, 0.4, 0.4, 0.4])
        #expect(few?.status == .insufficientData, "4 + 4 kicks is too few, however big the difference")
        #expect(few?.isReportable == false)

        let small = try relationship(made: [0.20, 0.21, 0.19, 0.20, 0.20], missed: [0.21, 0.22, 0.20, 0.21, 0.21])
        #expect(small?.status == .notMeaningful, "0.01 s is below the minimum meaningful difference")

        let uncertain = try relationship(made: [0.1, 0.1, 0.1, 0.1, 0.1], missed: [0.4, 0.4, 0.4, 0.4, 0.4], confidence: 0.55)
        #expect(uncertain?.status == .lowConfidence)

        let clear = try relationship(made: [0.1, 0.11, 0.09, 0.1, 0.1], missed: [0.4, 0.41, 0.39, 0.4, 0.4])
        #expect(clear?.status == .associated)
        #expect(clear?.successfulCount == 5)
        #expect(clear?.unsuccessfulCount == 5)
        #expect(near(clear?.medianDifference, -0.3, 1e-12))
        // Pooled SD (0.00707) is floored at half the minimum meaningful difference (0.015).
        #expect(near(clear?.effectSize, -0.3 / 0.015, 1e-9))
    }

    // MARK: Recency, trends, consistency

    @Test func recencyWeightingAndRecentVsLifetime() throws {
        let old = (0..<10).map { F.kick($0, day: -100, values: [.plantToContactTime: 0.30]) }
        let new = (10..<15).map { F.kick($0, day: Double(85 + $0), values: [.plantToContactTime: 0.20]) }
        let b = try #require(try F.profile(old + new).baseline(.plantToContactTime))
        let lifetimeMean: Double = (10 * 0.3 + 5 * 0.2) / 15
        #expect(near(b.lifetime.mean, lifetimeMean, 1e-12))
        #expect(b.recentSource == .lastKicks)
        #expect(b.recent.count == 10)
        #expect(near(b.recent.mean, 0.25, 1e-12))
        #expect(b.lastDays?.count == 5)
        #expect(near(b.lastDays?.mean, 0.20, 1e-12))
        // Weights: old kicks 0.5^(200/60), new kicks 0.5^((100 − day)/60).
        let oldWeight: Double = pow(0.5, 200.0 / 60)
        let newWeights: [Double] = (10..<15).map { (i: Int) -> Double in pow(0.5, (100 - Double(85 + i)) / 60) }
        let newWeightSum: Double = newWeights.reduce(0, +)
        let weightedTotal: Double = 10 * oldWeight * 0.3 + newWeightSum * 0.2
        let expected: Double = weightedTotal / (10 * oldWeight + newWeightSum)
        #expect(near(b.recencyWeightedMean, expected, 1e-12))
        #expect(b.normal < b.lifetime.mean, "recent kicks count more")

        let short = try #require(try F.profile(F.series(.plantToContactTime, [0.2, 0.3])).baseline(.plantToContactTime))
        #expect(short.recentSource == .lifetimeFallback)
        #expect(short.recent == short.lifetime)
        #expect(short.lastDays == nil)
    }

    @Test func trendsSeparateRealChangeFromNormalVariation() throws {
        let rising = try #require(try F.profile(F.series(.plantFootDrift, [0.05, 0.06, 0.05, 0.06, 0.05, 0.06, 0.20, 0.21, 0.20, 0.21, 0.20, 0.21]))
            .baseline(.plantFootDrift))
        #expect(rising.trend.direction == .rising)
        #expect(rising.trend.recentCount == 6)
        #expect(near(rising.trend.change, 0.15, 1e-12))
        // With logged makes, trends are judged against the successful-kick median.
        #expect(rising.trend.targetBasis == "successfulPattern")

        let noOutcome = (0..<12).map { i in
            F.kick(i, result: nil, values: [.plantFootDrift: i < 6 ? 0.05 + 0.01 * Double(i % 2) : 0.20 + 0.01 * Double(i % 2)])
        }
        let worse = try #require(try F.profile(noOutcome).baseline(.plantFootDrift))
        #expect(worse.trend.direction == .rising)
        #expect(worse.trend.assessment == .worsening, "plant-foot movement: lower is better")
        #expect(worse.trend.targetBasis == "generalDirection")

        let noisy = try #require(try F.profile(F.series(.plantFootDrift, [0.05, 0.25, 0.05, 0.25, 0.05, 0.25, 0.25, 0.05, 0.25, 0.05, 0.25, 0.05]))
            .baseline(.plantFootDrift))
        #expect(noisy.trend.direction == .stable, "same spread before and after: normal variation")
        #expect(noisy.trend.assessment == .neutral)

        let few = try #require(try F.profile(F.series(.plantFootDrift, [0.05, 0.3, 0.3])).baseline(.plantFootDrift))
        #expect(few.trend.direction == .insufficientData)
    }

    @Test func consistencyIsScoredOnlyWhereItMatters() throws {
        let tight = try #require(try F.profile(F.series(.plantToContactTime, [0.19, 0.20, 0.21, 0.20, 0.20, 0.19, 0.21, 0.20]))
            .baseline(.plantToContactTime))
        #expect(tight.consistency.basis == .successfulKicks)
        #expect(tight.consistency.level == .highlyRepeatable)
        let sd = try #require(tight.consistency.standardDeviation)
        #expect(tight.consistency.score == PersonalStatistics.round3(1 - sd / 0.1))

        let loose = try #require(try F.profile(F.series(.plantToContactTime, [0.05, 0.30, 0.10, 0.35, 0.08, 0.32]))
            .baseline(.plantToContactTime))
        #expect(loose.consistency.level == .variable)

        let speed = try #require(try F.profile(F.series(.peakFootSpeed, [20, 21, 22, 20, 21, 22])).baseline(.peakFootSpeed))
        #expect(speed.consistency.level == .notAssessed, "less variation in foot speed isn't a goal in itself")
        #expect(speed.consistency.score == nil)
    }

    @Test func consistencyChangeOverTime() throws {
        let previous = Array(repeating: [0.19, 0.21], count: 10).flatMap { $0 }        // SD ≈ 0.010
        let recentLoose = Array(repeating: [0.12, 0.28], count: 5).flatMap { $0 }      // SD ≈ 0.084
        let worse = try #require(try F.profile(F.series(.plantToContactTime, previous + recentLoose)).baseline(.plantToContactTime))
        #expect(worse.consistency.recentCount == 10)
        #expect(worse.consistency.previousCount == 20)
        #expect(worse.consistency.change == .lessConsistent)

        let looseFirst: [Double] = Array(repeating: [0.12, 0.28], count: 10).flatMap { $0 }
        let tightLater: [Double] = Array(repeating: [0.19, 0.21], count: 5).flatMap { $0 }
        let better = try #require(try F.profile(F.series(.plantToContactTime, looseFirst + tightLater)).baseline(.plantToContactTime))
        #expect(better.consistency.change == .moreConsistent)

        let same = try #require(try F.profile(F.series(.plantToContactTime, Array(repeating: [0.19, 0.21], count: 15).flatMap { $0 }))
            .baseline(.plantToContactTime))
        #expect(same.consistency.change == .unchanged)
    }

    // MARK: Distance

    @Test func distanceBucketsWaitForEnoughKicks() throws {
        let short = (0..<10).map { F.kick($0, distance: 25, values: [.plantToContactTime: 0.18]) }
        let long = (10..<13).map { F.kick($0, distance: 45, values: [.plantToContactTime: 0.25]) }
        let noDistance = F.kick(20, distance: nil, values: [.plantToContactTime: 0.5])
        let history = short + long + [noDistance]
        let config = PersonalizationConfiguration()

        let longKick = F.current([.plantToContactTime: 0.25], distance: 46)
        let s1 = try #require(try PersonalCoachingEngine.profiles(for: longKick, history: history, epoch: nil, now: F.date(100),
                                                                   model: StatisticalAthleteLearningModel(), configuration: config))
        #expect(!s1.usesDistanceProfile, "40–49 has only 3 kicks: use the overall field-goal profile")
        #expect(s1.active.eligibleKickCount == 14)

        let shortKick = F.current([.plantToContactTime: 0.18], distance: 24)
        let s2 = try #require(try PersonalCoachingEngine.profiles(for: shortKick, history: history, epoch: nil, now: F.date(100),
                                                                   model: StatisticalAthleteLearningModel(), configuration: config))
        #expect(s2.usesDistanceProfile)
        #expect(s2.active.scope.distanceBucket == .under30)
        #expect(s2.active.eligibleKickCount == 10)
        #expect(s2.active.kickExclusions.differentDistanceBucket == 4, "3 long kicks + 1 with no distance")
        #expect(s2.overall.eligibleKickCount == 14)

        let pat = F.current([.plantToContactTime: 0.18], distance: 20, type: .pat)
        let s3 = try #require(try PersonalCoachingEngine.profiles(for: pat, history: history, epoch: nil, now: F.date(100),
                                                                   model: StatisticalAthleteLearningModel(), configuration: config))
        #expect(!s3.usesDistanceProfile, "distance buckets are for field goals")
    }

    // MARK: Rebuilds

    @Test func profilesAreReproducibleAndRebuildAfterDeletion() throws {
        let kicks = F.series(.plantToContactTime, [0.18, 0.2, 0.22, 0.19, 0.21, 0.2, 0.2, 0.19, 0.21, 0.2])
        let a = try F.profile(kicks)
        let b = try F.profile(kicks.reversed())
        #expect(a == b, "input order doesn't matter")
        let data1 = try JSONEncoder().encode(a)
        let data2 = try JSONEncoder().encode(b)
        #expect(try JSONDecoder().decode(AthleteBiomechanicsProfile.self, from: data1) == a)
        #expect(data1.count == data2.count)

        var remaining = kicks
        let deleted = remaining.remove(at: 4)
        let rebuilt = try F.profile(remaining)
        #expect(rebuilt.eligibleKickCount == 9)
        #expect(!rebuilt.sourceAnalysisIDs.contains(deleted.analysisID))
        #expect(rebuilt.sourceFingerprint != a.sourceFingerprint)
        let rebuiltMean: Double = (2.0 - 0.21) / 9
        #expect(near(rebuilt.baseline(.plantToContactTime)?.lifetime.mean, rebuiltMean, 1e-12))
        #expect(try F.profile(remaining) == rebuilt)
    }

    @Test func invalidConfigurationIsRejected() {
        var config = PersonalizationConfiguration()
        config.maturity = MaturityThresholds(emerging: 5, established: 4, strong: 20)
        #expect(throws: PersonalizationError.invalidConfiguration("maturity")) { try F.profile([], configuration: config) }
        config = PersonalizationConfiguration()
        config.minimumMetricConfidence = 1.5
        #expect(throws: PersonalizationError.invalidConfiguration("minimumMetricConfidence")) { try F.profile([], configuration: config) }
    }

    @Test func referenceLayerShipsEmpty() {
        let query = ReferenceQuery(kickType: .fieldGoal, kickingFoot: .right, competitionLevel: .college, groups: [.successfulPeers, .levelReference])
        #expect(NoBiomechanicsReferences().references(for: query).isEmpty)
        var reference = BiomechanicsReferenceProfile(
            id: "test", group: .levelReference, kickType: .fieldGoal, competitionLevel: .college, ageGroup: nil, kickingFoot: nil,
            athleteCount: 0, kickCount: 0, source: "", version: "0", metricDefinitionVersions: [:], metrics: [:]
        )
        #expect(!reference.isUsable, "no source, no samples: not usable")
        reference.source = "Test dataset"
        reference.athleteCount = 12
        reference.kickCount = 240
        reference.metrics = [.plantToContactTime: ReferenceMetricStatistics(sampleCount: 240, mean: 0.2, median: 0.2, standardDeviation: 0.02,
                                                                            lowerQuartile: 0.19, upperQuartile: 0.21)]
        #expect(!reference.isUsable, "definition versions must be stated")
        reference.metricDefinitionVersions = [.plantToContactTime: 1]
        #expect(reference.isUsable)
    }
}
