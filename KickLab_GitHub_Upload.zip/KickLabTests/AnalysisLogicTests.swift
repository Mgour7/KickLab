import Foundation
import Testing
@testable import KickLab

/// Pure rules behind AnalysisService. No SwiftData.
@Suite("Analysis service logic")
struct AnalysisLogicTests {
    // MARK: Lifecycle transitions

    @Test(arguments: [
        (ProcessingStatus.queued, ProcessingStatus.processing),
        (.queued, .cancelled),
        (.processing, .completed),
        (.processing, .failed),
        (.processing, .cancelled),
    ])
    func allowedTransitions(from: ProcessingStatus, to: ProcessingStatus) {
        #expect(from.canTransition(to: to))
    }

    @Test func everyOtherTransitionIsRejected() {
        let allowed: Set<String> = ["queued>processing", "queued>cancelled", "processing>completed", "processing>failed", "processing>cancelled"]
        for from in ProcessingStatus.allCases {
            for to in ProcessingStatus.allCases where !allowed.contains("\(from.rawValue)>\(to.rawValue)") {
                #expect(!from.canTransition(to: to), "\(from.rawValue) → \(to.rawValue) must be rejected")
            }
        }
    }

    @Test func terminalStatusesAndMutability() {
        for status in [ProcessingStatus.completed, .failed, .cancelled, .unknown] {
            #expect(status.isTerminal)
            #expect(!status.acceptsResults)
            #expect(!status.acceptsInputVideos)
        }
        #expect(ProcessingStatus.processing.acceptsResults)
        #expect(!ProcessingStatus.queued.acceptsResults)
        #expect(ProcessingStatus.queued.acceptsInputVideos)
        #expect(ProcessingStatus.processing.acceptsInputVideos)
    }

    // MARK: Current-analysis selection

    private let t0 = Date(timeIntervalSince1970: 1_000_000)

    private func snap(_ status: ProcessingStatus, current: Bool, minute: Int) -> AnalysisCurrencySnapshot {
        let date = t0.addingTimeInterval(Double(minute) * 60)
        return AnalysisCurrencySnapshot(
            id: UUID(),
            status: status,
            isCurrent: current,
            createdAt: date,
            completedAt: status == .completed ? date : nil
        )
    }

    @Test func zeroCurrentSelectsNewestCompleted() {
        let old = snap(.completed, current: false, minute: 1)
        let new = snap(.completed, current: false, minute: 5)
        let failed = snap(.failed, current: false, minute: 9)
        #expect(CurrentAnalysisSelector.selectCurrent(from: [old, new, failed]) == new.id)
    }

    @Test func multipleCurrentNewestCompletedCurrentWins() {
        let a = snap(.completed, current: true, minute: 1)
        let b = snap(.completed, current: true, minute: 3)
        let newerButNotCurrent = snap(.completed, current: false, minute: 9)
        #expect(CurrentAnalysisSelector.selectCurrent(from: [a, b, newerButNotCurrent]) == b.id)
    }

    @Test func invalidCurrentRecordsAreClearedAndNewestCompletedSelected() {
        let failedCurrent = snap(.failed, current: true, minute: 9)
        let processingCurrent = snap(.processing, current: true, minute: 8)
        let completed = snap(.completed, current: false, minute: 2)
        let flags = CurrentAnalysisSelector.currentFlags(for: [failedCurrent, processingCurrent, completed])
        #expect(flags[failedCurrent.id] == false)
        #expect(flags[processingCurrent.id] == false)
        #expect(flags[completed.id] == true)
    }

    @Test func noCompletedMeansNothingIsCurrent() {
        let items = [snap(.failed, current: true, minute: 1), snap(.queued, current: false, minute: 2)]
        #expect(CurrentAnalysisSelector.selectCurrent(from: items) == nil)
        #expect(CurrentAnalysisSelector.currentFlags(for: items).values.allSatisfy { !$0 })
    }

    @Test func exactlyOneFlagIsTrueWhenACompletedAnalysisExists() {
        let items = (0..<6).map { snap($0.isMultiple(of: 2) ? .completed : .failed, current: $0 < 4, minute: $0) }
        #expect(CurrentAnalysisSelector.currentFlags(for: items).values.filter { $0 }.count == 1)
    }

    // MARK: Metric validation

    @Test func unavailableMetricWithValueIsRejected() {
        let draft = MetricDraft(metricKey: "plant.kneeAngle", value: 142, unit: .degrees, confidence: nil, measurementStatus: .unavailable)
        #expect(AnalysisResultValidator.validate(draft).contains(.unavailableHasValue(.metricValue)))
    }

    @Test func unavailableFactoryIsValid() {
        #expect(AnalysisResultValidator.validate(.unavailable("plant.kneeAngle", unit: .degrees)).isEmpty)
    }

    @Test func measuredMetricWithoutValueIsRejected() {
        let draft = MetricDraft(metricKey: "torso.lean", value: nil, unit: .degrees, confidence: 0.8, measurementStatus: .measured)
        #expect(AnalysisResultValidator.validate(draft).contains(.measuredValueMissing(.metricValue)))
    }

    @Test(arguments: [-0.1, 1.5, Double.nan])
    func invalidMetricConfidenceIsRejected(confidence: Double) {
        let draft = MetricDraft(metricKey: "torso.lean", value: 12, unit: .degrees, confidence: confidence, measurementStatus: .measured)
        let issues = AnalysisResultValidator.validate(draft)
        #expect(issues.contains(.valueOutOfRange(.metricConfidence, value: confidence)) || issues.contains(.nonFiniteValue(.metricConfidence)))
    }

    @Test func metricKeyAndUnitAreRequired() {
        let draft = MetricDraft(metricKey: "  ", value: 1, unit: .unknown, confidence: 0.5, measurementStatus: .estimated)
        let issues = AnalysisResultValidator.validate(draft)
        #expect(issues.contains(.emptyMetricKey))
        #expect(issues.contains(.unknownMetricUnit))
    }

    @Test func validMeasuredMetricPasses() {
        let draft = MetricDraft(metricKey: "plant.lateralDistance", value: 11.5, unit: .inches, confidence: 0.82, measurementStatus: .measured, phase: .plant)
        #expect(AnalysisResultValidator.validate(draft).isEmpty)
    }

    // MARK: Category score validation

    @Test func categoryScoreAboveHundredIsRejected() {
        let draft = CategoryScoreDraft(category: .plant, score: 104, confidence: 0.7, measurementStatus: .measured)
        #expect(AnalysisResultValidator.validate(draft).contains(.valueOutOfRange(.score, value: 104)))
    }

    @Test func unavailableScoreMustBeNil() {
        let draft = CategoryScoreDraft(category: .swing, score: 50, confidence: nil, measurementStatus: .unavailable)
        #expect(AnalysisResultValidator.validate(draft).contains(.unavailableHasValue(.score)))
    }

    @Test func scoreConfidenceMustBeWithinZeroToOne() {
        let draft = CategoryScoreDraft(category: .swing, score: 80, confidence: 2, measurementStatus: .measured)
        #expect(AnalysisResultValidator.validate(draft).contains(.valueOutOfRange(.scoreConfidence, value: 2)))
    }

    // MARK: Observation validation

    private let improveID = UUID()
    private let keepID = UUID()

    private var existing: [ExistingObservationRef] {
        [ExistingObservationRef(id: improveID, kind: .improve), ExistingObservationRef(id: keepID, kind: .keep)]
    }

    @Test func cueMayReferenceImproveInSameAnalysis() {
        let cue = CoachingObservationDraft(kind: .cue, category: .plant, message: "Get the plant underneath you.", relatedObservationID: improveID)
        #expect(AnalysisResultValidator.validate(cue, existing: existing).isEmpty)
    }

    @Test func cueCannotReferenceObservationFromAnotherAnalysis() {
        let otherAnalysisObservation = UUID()
        let cue = CoachingObservationDraft(kind: .cue, category: .plant, message: "Stay tall.", relatedObservationID: otherAnalysisObservation)
        #expect(AnalysisResultValidator.validate(cue, existing: existing) == [.relatedObservationNotInAnalysis(otherAnalysisObservation)])
    }

    @Test func cueMustReferenceImproveNotKeep() {
        let cue = CoachingObservationDraft(kind: .cue, category: .plant, message: "Stay tall.", relatedObservationID: keepID)
        #expect(AnalysisResultValidator.validate(cue, existing: existing) == [.relatedObservationMustBeImprove(found: .keep)])
    }

    @Test func onlyCuesCarryRelatedObservation() {
        let improve = CoachingObservationDraft(kind: .improve, category: .plant, message: "Plant is wide.", relatedObservationID: improveID)
        #expect(AnalysisResultValidator.validate(improve, existing: existing).contains(.relatedObservationOnlyForCue(.improve)))
    }

    @Test func severityOnlyForImprove() {
        let keep = CoachingObservationDraft(kind: .keep, category: .swing, message: "Great knee-through.", severity: .high)
        #expect(AnalysisResultValidator.validate(keep, existing: []) == [.severityOnlyForImprove(.keep)])
        let improve = CoachingObservationDraft(kind: .improve, category: .plant, message: "Plant is wide.", severity: .high)
        #expect(AnalysisResultValidator.validate(improve, existing: []).isEmpty)
    }

    @Test func emptyMessageAndSelfReferenceAreRejected() {
        var draft = CoachingObservationDraft(kind: .cue, category: .plant, message: "   ")
        draft.relatedObservationID = draft.id
        let issues = AnalysisResultValidator.validate(draft, existing: [])
        #expect(issues.contains(.emptyMessage))
        #expect(issues.contains(.relatedObservationIsSelf))
    }

    @Test func duplicateObservationIDIsRejected() {
        let draft = CoachingObservationDraft(id: improveID, kind: .keep, category: .plant, message: "Repeat.")
        #expect(AnalysisResultValidator.validate(draft, existing: existing).contains(.duplicateObservationID(improveID)))
    }

    // MARK: Completion values

    @Test func completionValuesAreValidated() {
        #expect(AnalysisResultValidator.validateCompletion(confidence: 0.9, overallScore: 88).isEmpty)
        #expect(AnalysisResultValidator.validateCompletion(confidence: nil, overallScore: nil).isEmpty)
        #expect(AnalysisResultValidator.validateCompletion(confidence: 1.2, overallScore: nil) == [.valueOutOfRange(.analysisConfidence, value: 1.2)])
        #expect(AnalysisResultValidator.validateCompletion(confidence: .infinity, overallScore: 101) == [
            .nonFiniteValue(.analysisConfidence),
            .valueOutOfRange(.overallScore, value: 101),
        ])
    }
}
