import Foundation
import Testing
@testable import KickLab

/// Build 20 — Kick Comparison 1.0 (pure logic: alignment, compatibility, table, filters,
/// reference kick) and the progress-screen consistency groups.
///
/// SYNTHETIC: every kick here is hand-built. The contact times and intervals mirror real
/// reference values (rear 7.602 s contact 3.867 s with a 3.867–3.933 s window; IMG_1709
/// 7.935 s with 7.902–7.968 s) only to make the numbers concrete — no videos are played.
/// Synchronized playback itself (AVPlayer) runs only on Apple devices and is not tested here.
@Suite("Kick Comparison 1.0")
struct KickComparison10Tests {
    private let day = 86_400.0

    private func kick(_ n: Double, view: ComparableView = .depth, type: KickType = .fieldGoal, result: KickResult? = .made,
                      yards: Double? = 40, session: UUID? = nil, reference: Bool = false, assisted: Bool = false,
                      metrics: [KickMetricKey: Double] = [:], version: Int? = nil, kickID: UUID = UUID()) -> ComparisonKick {
        ComparisonKick(analysisID: UUID(), kickID: kickID, athleteID: nil, date: Date(timeIntervalSince1970: 1_800_000_000 + n * day),
                       kickType: type, view: view, result: result, distanceYards: yards, sessionID: session, isReference: reference,
                       hasVideo: true, engineVersion: PoseVideoAnalysisService.version + (assisted ? AnalysisAssistanceLabel.suffix : ""),
                       metrics: metrics.mapValues { ComparisonMetric(value: $0, definitionVersion: version ?? 1, confidence: 0.8) })
    }

    private func side(_ contact: Double?, _ lo: Double? = nil, _ hi: Double? = nil, duration: Double = 8, fps: Double = 30) -> ComparisonSide {
        ComparisonSide(contactTime: contact, contactEarliest: lo, contactLatest: hi,
                       provenance: contact == nil ? .notEstablished : .automatic, duration: duration, frameInterval: 1 / fps)
    }

    // MARK: Alignment relative to contact

    @Test func playbackIsAlignedAtContactNotAtVideoStart() throws {
        let a = ComparisonAlignment(a: side(3.867, 3.867, 3.933, duration: 7.602), b: side(7.935, 7.902, 7.968, duration: 12.202))
        #expect(abs(a.timeA(0) - 3.867) < 1e-9 && abs(a.timeB(0) - 7.935) < 1e-9, "relative time 0 = each kick's contact")
        #expect(abs(a.timeA(-0.5) - 3.367) < 1e-9 && abs(a.timeB(-0.5) - 7.435) < 1e-9)
        let range = try #require(a.range)
        #expect(abs(range.lowerBound - (-3.867)) < 1e-9, "Kick A's start limits how far back both can go")
        #expect(abs(range.upperBound - (7.602 - 3.867)) < 1e-9)
        if case .aligned(let u) = a.status { #expect(abs(u - 0.066) < 1e-9) } else { Issue.record("\(a.status)") }
        #expect(a.statusText == "Aligned at contact (±0.066 s)")
        #expect(abs(a.initialRelativeTime - (-1)) < 1e-9, "starts a second before contact")
    }

    @Test func uncertainContactIsSaidOutLoud() {
        // A wide interval (e.g. pose-only timing) on Kick B.
        let a = ComparisonAlignment(a: side(2.467, 2.467, 2.5), b: side(4.768, 4.6, 4.9))
        if case .uncertain(let u) = a.status { #expect(abs(u - (0.033 + 0.3) / 2) < 1e-9) } else { Issue.record("\(a.status)") }
        #expect(a.statusText.hasPrefix("Contact timing is uncertain"))
        // No stored interval: one frame each.
        let f = ComparisonAlignment(a: side(1), b: side(2))
        if case .aligned(let u) = f.status { #expect(abs(u - 1.0 / 30) < 1e-9) } else { Issue.record("\(f.status)") }
    }

    @Test func aMissingContactIsNeverPresentedAsSynchronized() {
        let a = ComparisonAlignment(a: side(3.867), b: side(nil))
        #expect(!a.isContactAligned)
        #expect(a.timeA(1) == 1 && a.timeB(1) == 1, "videos start together")
        #expect(a.statusText == "Contact wasn't established for Kick B, so the videos start together and are not synchronized at contact.")
        #expect(a.initialRelativeTime == 0)
    }

    @Test func manualAlignmentIsAComparisonOnlyNudgeInWholeFrames() {
        let base = ComparisonAlignment(a: side(3.867, fps: 30), b: side(7.935, fps: 60))
        #expect(abs(base.step - 1.0 / 30) < 1e-9, "steps by the coarser frame so both videos change")
        let n = base.nudged(frames: 2)
        #expect(abs(n.manualOffset - 2.0 / 30) < 1e-9)
        #expect(abs(n.timeB(0) - (7.935 + 2.0 / 30)) < 1e-9 && n.timeA(0) == base.timeA(0), "only Kick B moves")
        #expect(n.statusText.hasSuffix("· Kick B shifted +0.067 s by you (this comparison only)"))
        #expect(n.a == base.a && n.b == base.b, "the analyses' own contact times are untouched")
        #expect(base.nudged(frames: 1000).manualOffset == ComparisonAlignment.maximumOffset)
        #expect(n.nudged(frames: -2).manualOffset == 0)
    }

    @Test func scrubbingStaysInsideFootageBothVideosHave() {
        let a = ComparisonAlignment(a: side(0.18, duration: 3.663), b: side(3.867, duration: 7.602))
        #expect(abs(a.clamp(-5) - (-0.18)) < 1e-9, "the cropped clip has only 0.18 s before contact")
        #expect(abs(a.clamp(10) - (3.663 - 0.18)) < 1e-9)
        let none = ComparisonAlignment(a: side(0, duration: 0.1), b: side(0, duration: 0.2), manualOffset: 0.5)
        #expect(none.range == nil, "no overlapping footage")
    }

    // MARK: Compatibility and the measurement table

    @Test func onlyCompatibleMeasurementsAreComparedAndMissingIsNeverZero() throws {
        let a = kick(1, metrics: [.plantBallLateralOffset: 0.62, .plantFootWidth: -0.53, .lateralTrunkLeanAtContact: 9.6])
        let b = kick(2, metrics: [.plantBallLateralOffset: 0.74, .lateralTrunkLeanAtContact: 10.1])
        let rows = KickComparison.rows(a, b)
        let offset = try #require(rows.first { $0.key == KickMetricKey.plantBallLateralOffset.rawValue })
        #expect(offset.a == "0.62 torso lengths · plant-leg side" && offset.b == "0.74 torso lengths · plant-leg side")
        #expect(offset.difference == "+0.12 torso lengths" && offset.note == nil)
        let width = try #require(rows.first { $0.key == KickMetricKey.plantFootWidth.rawValue })
        #expect(width.b == "—" && width.difference == nil && width.note == "Not measured reliably in Kick B")
        let lean = try #require(rows.first { $0.key == KickMetricKey.lateralTrunkLeanAtContact.rawValue })
        #expect(lean.note == "Within measurement precision", "0.5° < the 3° meaningful change")
        #expect(!rows.contains { $0.key == KickMetricKey.approachSpeed.rawValue }, "not measurable from this view, and in neither kick")
    }

    @Test func differentViewsShareVideosButNotMeasurements() {
        let a = kick(1, view: .side, metrics: [.approachSpeed: 3])
        let b = kick(2, view: .depth, metrics: [.plantBallLateralOffset: 0.6])
        #expect(KickComparison.incompatibility(a, b)?.contains("different camera views") == true)
        #expect(KickComparison.rows(a, b).isEmpty)
        #expect(KickComparison.incompatibility(kick(1, view: .unknown), kick(2, view: .unknown)) != nil)
        let same = UUID()
        #expect(KickComparison.incompatibility(kick(1, kickID: same), kick(2, kickID: same)) == "These are two analyses of the same kick.")
    }

    @Test func differentDefinitionsAreShownButNotSubtracted() {
        let a = kick(1, metrics: [.plantFootWidth: -0.5], version: 1)
        let b = kick(2, metrics: [.plantFootWidth: -0.4], version: 2)
        let row = KickComparison.rows(a, b).first { $0.key == KickMetricKey.plantFootWidth.rawValue }
        #expect(row?.difference == nil && row?.note == "Measured with different definitions — not compared")
    }

    @Test func notesFlagKickTypeAndAssistedAnalyses() {
        let notes = KickComparison.notes(kick(1, type: .fieldGoal), kick(2, type: .pat, assisted: true))
        #expect(notes.count == 2)
    }

    // MARK: Picking kicks

    @Test func filtersCoverTheUsefulComparisons() {
        let s = UUID()
        let all = [kick(1, result: .made, yards: 35, session: s), kick(2, result: .missedLeft, yards: 38, session: s),
                   kick(3, result: .short, yards: 52), kick(4, result: .unknown, yards: nil, reference: true),
                   kick(5, view: .side, result: .made, yards: 31)]
        #expect(KickComparison.filter(all, by: .made).count == 2)
        #expect(KickComparison.filter(all, by: .missed).count == 2, "unknown results are neither made nor missed")
        #expect(KickComparison.filter(all, by: .sameDistance(33)).map(\.distanceYards) == [31, 38, 35], "30–39 yd band, newest first")
        #expect(KickComparison.filter(all, by: .sameSession(s)).count == 2)
        #expect(KickComparison.filter(all, by: .reference).count == 1)
        #expect(KickComparison.filter(all, by: .sameView(.side)).count == 1)
        #expect(KickComparison.filter(all, by: .all, sort: .distance).first?.distanceYards == 52)
        #expect(KickComparison.filter(all, by: .all, excluding: all[0].analysisID).count == 4)
    }

    @Test func theSuggestedPartnerPrefersTheChosenReferenceThenTheLatestComparableKick() {
        let latest = kick(10)
        let ref = kick(1, reference: true)
        let others = [kick(5), kick(8), kick(9, view: .side), ref, latest]
        #expect(KickComparison.suggestedPartner(for: latest, among: others) == ref)
        #expect(KickComparison.suggestedPartner(for: latest, among: [kick(5), kick(8), latest])?.date == Date(timeIntervalSince1970: 1_800_000_000 + 8 * day))
    }

    @Test func oneReferenceKickPerKickTypeChosenByTheAthlete() {
        let a = UUID(), b = UUID(), c = UUID(), d = UUID()
        let kicks: [(id: UUID, kickType: KickType, isReference: Bool)] = [(a, .fieldGoal, true), (b, .fieldGoal, false), (c, .pat, true), (d, .fieldGoal, false)]
        #expect(PersonalReferencePolicy.kicksToClear(selected: b, kickType: .fieldGoal, kicks: kicks) == [a], "the PAT reference stays")
        #expect(PersonalReferencePolicy.kicksToClear(selected: a, kickType: .fieldGoal, kicks: kicks).isEmpty)
        #expect(PersonalReferencePolicy.explanation.contains("doesn't judge it as ideal"))
    }

    @Test func editingAKickKeepsItsReferenceFlag() throws {
        let form = KickEntryForm.editing(outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(40))), context: .training,
                                         hash: .center, notes: nil, timestamp: Date(timeIntervalSince1970: 1_800_000_000), isReferenceKick: true)
        let draft = try #require(form.makeDraft().draft)
        #expect(draft.isReferenceKick, "Build 19 and earlier reset this to false on every edit")
    }

    // MARK: Overlays use stored evidence only

    @Test func overlaysOnlyDrawOnTheirOwnFrame() {
        #expect(ComparisonOverlay.isContactFrame(time: 3.88, contact: 3.867, frame: 1.0 / 30))
        #expect(!ComparisonOverlay.isContactFrame(time: 3.9, contact: 3.867, frame: 1.0 / 30))
        #expect(!ComparisonOverlay.isContactFrame(time: 3.867, contact: nil, frame: 1.0 / 30))
        #expect(ComparisonOverlay.plantFoot(nil, at: 1, frame: 1.0 / 30, kickingFoot: .right) == nil)
        #expect(ComparisonOverlay.measurementLine(view: .side, timeline: nil, football: nil, contact: 1, time: 1, frame: 1.0 / 30,
                                                  kickingFoot: .right, storedValue: 0.5) == nil, "side views have no sideways plant line")
    }

    @Test func aFilledInPlantAnkleIsMarkedAsNotDetected() throws {
        // SYNTHETIC timeline with one interpolated plant-ankle point.
        var raw = SyntheticPose.timeline(SyntheticPose.KickScript.realWorld30fps)
        let i = 20
        let t = raw.samples[i].timestamp
        if let p = raw.samples[i].joints[.leftAnkle] { raw.samples[i].joints[.leftAnkle] = PosePoint(x: p.x, y: p.y, confidence: p.confidence, status: .interpolated) }
        let p = try #require(ComparisonOverlay.plantFoot(raw, at: t, frame: 1.0 / 30, kickingFoot: .right))
        #expect(p.measured == false)
        let q = try #require(ComparisonOverlay.plantFoot(raw, at: raw.samples[i + 1].timestamp, frame: 1.0 / 30, kickingFoot: .right))
        #expect(q.measured)
        #expect(ComparisonOverlay.plantFoot(raw, at: t + 10, frame: 1.0 / 30, kickingFoot: .right) == nil, "no sample, nothing drawn")
    }

    // MARK: Progress consistency groups

    private func entry(_ n: Double, _ v: Double?, view: ComparableView = .depth, type: KickType = .fieldGoal, cropped: Bool = false,
                       kickID: UUID = UUID()) -> RankingEntry {
        var e = RankingEntry(id: UUID(), kickID: kickID, date: Date(timeIntervalSince1970: 1_800_000_000 + n * day), kickType: type, view: view,
                             engineVersion: PoseVideoAnalysisService.version, completed: true, overallScore: nil, categoryScores: [:],
                             recording: RecordingFlags(cropped: cropped))
        if let v { e.metrics[RankingEntry.metricKey(.plantBallLateralOffset)] = v }
        return e
    }

    @Test func progressGroupsNeverMixViewsOrKickTypes() throws {
        let entries = [entry(1, 0.6), entry(2, 0.62), entry(3, 0.64), entry(4, 0.66), entry(5, 0.1, cropped: true),
                       entry(1, 1.0, view: .side), entry(2, 0.5, type: .pat)]
        let groups = ProgressConsistencyGroup.make(entries: entries)
        #expect(groups.count == 3)
        let rear = try #require(groups.first { $0.view == .depth && $0.kickType == .fieldGoal })
        #expect(rear.report.status == .assessed, "the latest ELIGIBLE kick is assessed (the cropped one is skipped)")
        #expect(rear.report.metrics.first { $0.key == .plantBallLateralOffset }?.spreadCount == 4)
        #expect(groups.first { $0.view == .side }?.report.status == .buildingBaseline(have: 1, need: 4))
    }
}
