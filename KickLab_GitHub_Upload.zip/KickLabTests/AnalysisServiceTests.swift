import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("AnalysisService")
struct AnalysisServiceTests {
    let f: ServiceFixture
    let athlete: Athlete
    let kick: Kick
    let video: VideoAsset

    init() throws {
        f = try ServiceFixture()
        athlete = try f.makeAthlete()
        kick = try f.makeKick(for: athlete)
        video = try f.addVideo(to: kick, path: "k/side.mov")
    }

    private func processing() throws -> BiomechanicsAnalysis {
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [video])
        try f.analyses.startProcessing(analysis)
        return analysis
    }

    // MARK: Create

    @Test func createsQueuedNonCurrentAnalysis() throws {
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: " 1.0.0 ", inputVideos: [video])
        #expect(analysis.processingStatus == .queued)
        #expect(analysis.isCurrent == false)
        #expect(analysis.analysisVersion == "1.0.0")
        #expect(analysis.kick?.id == kick.id)
        #expect(analysis.inputVideos?.map(\.id) == [video.id])
    }

    @Test func rejectsVideoFromAnotherKick() throws {
        let otherKick = try f.makeKick(for: athlete)
        let otherVideo = try f.addVideo(to: otherKick, path: "other.mov")
        #expect(throws: AnalysisServiceError.integrity([
            .videoBelongsToDifferentKick(videoID: otherVideo.id, videoKickID: otherKick.id, analysisKickID: kick.id),
        ])) {
            try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [otherVideo])
        }
        #expect(try f.count(BiomechanicsAnalysis.self) == 0)
    }

    @Test func rejectsOrphanedVideo() throws {
        let orphan = VideoAsset(angleType: .rear)
        f.context.insert(orphan)
        try f.context.save()
        #expect(throws: AnalysisServiceError.integrity([.videoIsOrphaned(videoID: orphan.id)])) {
            try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [orphan])
        }
    }

    @Test func rejectsEmptyVersionAndNoVideos() throws {
        #expect(throws: AnalysisServiceError.emptyAnalysisVersion) {
            try f.analyses.createAnalysis(for: kick, analysisVersion: "  ", inputVideos: [video])
        }
        #expect(throws: AnalysisServiceError.noInputVideos) {
            try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [])
        }
    }

    // MARK: Lifecycle

    @Test func validTransitionsSucceed() throws {
        let completed = try processing()
        try f.analyses.markCompleted(completed, confidence: 0.92, overallScore: 81)
        #expect(completed.processingStatus == .completed)
        #expect(completed.completedAt != nil)
        #expect(completed.confidence == 0.92)

        let failed = try processing()
        try f.analyses.markFailed(failed, reason: " Ball not visible ")
        #expect(failed.processingStatus == .failed)
        #expect(failed.failureReason == "Ball not visible")

        let cancelledFromQueue = try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [video])
        try f.analyses.cancel(cancelledFromQueue)
        #expect(cancelledFromQueue.processingStatus == .cancelled)
    }

    @Test func invalidTransitionsFail() throws {
        let queued = try f.analyses.createAnalysis(for: kick, analysisVersion: "1.0.0", inputVideos: [video])
        #expect(throws: AnalysisServiceError.invalidTransition(from: .queued, to: .completed)) {
            try f.analyses.markCompleted(queued, confidence: 0.9)
        }
        #expect(throws: AnalysisServiceError.invalidTransition(from: .queued, to: .failed)) {
            try f.analyses.markFailed(queued, reason: "x")
        }

        let completed = try processing()
        try f.analyses.markCompleted(completed, confidence: 0.9)
        #expect(throws: AnalysisServiceError.invalidTransition(from: .completed, to: .processing)) {
            try f.analyses.startProcessing(completed)
        }
        #expect(throws: AnalysisServiceError.invalidTransition(from: .completed, to: .cancelled)) {
            try f.analyses.cancel(completed)
        }
    }

    @Test func invalidCompletionConfidenceKeepsAnalysisProcessing() throws {
        let analysis = try processing()
        #expect(throws: AnalysisServiceError.invalidResult([.valueOutOfRange(.analysisConfidence, value: 1.4)])) {
            try f.analyses.markCompleted(analysis, confidence: 1.4)
        }
        #expect(analysis.processingStatus == .processing)
    }

    // MARK: Current analysis

    @Test func failedAnalysisCannotBecomeCurrent() throws {
        let analysis = try processing()
        try f.analyses.markFailed(analysis, reason: "Blurry")
        #expect(throws: AnalysisServiceError.notCompleted(status: .failed)) {
            try f.analyses.promote(analysis)
        }
        #expect(!analysis.isCurrent)
    }

    @Test func processingAnalysisCannotBecomeCurrent() throws {
        let analysis = try processing()
        #expect(throws: AnalysisServiceError.notCompleted(status: .processing)) {
            try f.analyses.promote(analysis)
        }
    }

    @Test func promoteMakesExactlyOneCurrentAndKeepsHistory() throws {
        let v1 = try f.makeCompletedAnalysis(for: kick, video: video, version: "1.0.0", completedAt: Date(timeIntervalSince1970: 100))
        let v2 = try f.makeCompletedAnalysis(for: kick, video: video, version: "2.0.0", completedAt: Date(timeIntervalSince1970: 200))
        let v3 = try f.makeCompletedAnalysis(for: kick, video: video, version: "3.0.0", completedAt: Date(timeIntervalSince1970: 300))

        try f.analyses.promote(v1)
        try f.analyses.promote(v3)

        #expect((kick.analyses ?? []).filter(\.isCurrent).map(\.id) == [v3.id])
        #expect(!v1.isCurrent && !v2.isCurrent)
        #expect(try f.count(BiomechanicsAnalysis.self) == 3, "history is never deleted")
    }

    @Test func repairCurrentHandlesZeroCurrent() throws {
        let older = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: Date(timeIntervalSince1970: 100))
        let newer = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: Date(timeIntervalSince1970: 200))

        let result = try f.analyses.repairCurrent(for: kick)

        #expect(result.currentAnalysisID == newer.id)
        #expect(newer.isCurrent && !older.isCurrent)
    }

    @Test func repairCurrentHandlesMultipleCurrent() throws {
        let a = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: Date(timeIntervalSince1970: 100))
        let b = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: Date(timeIntervalSince1970: 200))
        a.isCurrent = true   // simulated corruption
        b.isCurrent = true
        try f.context.save()

        let result = try f.analyses.repairCurrent(for: kick)

        #expect(result.currentAnalysisID == b.id)
        #expect(result.changedAnalysisIDs == [a.id])
        #expect(b.isCurrent && !a.isCurrent)
    }

    @Test func repairCurrentClearsInvalidCurrentRecords() throws {
        let completed = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: Date(timeIntervalSince1970: 100))
        let failed = try processing()
        try f.analyses.markFailed(failed, reason: "Blurry")
        let stillProcessing = try processing()
        failed.isCurrent = true            // simulated corruption
        stillProcessing.isCurrent = true
        try f.context.save()

        try f.analyses.repairCurrent(for: kick)

        #expect(!failed.isCurrent)
        #expect(!stillProcessing.isCurrent)
        #expect(completed.isCurrent)
    }

    @Test func repairCurrentWithNoCompletedClearsAll() throws {
        let failed = try processing()
        try f.analyses.markFailed(failed, reason: "Blurry")
        failed.isCurrent = true
        try f.context.save()

        let result = try f.analyses.repairCurrent(for: kick)

        #expect(result.currentAnalysisID == nil)
        #expect((kick.analyses ?? []).allSatisfy { !$0.isCurrent })
    }

    // MARK: Results

    @Test func unavailableMetricWithValueIsRejected() throws {
        let analysis = try processing()
        let draft = MetricDraft(metricKey: "plant.kneeAngle", value: 140, unit: .degrees, confidence: nil, measurementStatus: .unavailable)
        #expect(throws: AnalysisServiceError.invalidResult([.unavailableHasValue(.metricValue)])) {
            try f.analyses.addMetric(draft, to: analysis)
        }
        #expect(try f.count(BiomechanicalMetric.self) == 0)
    }

    @Test func invalidMetricConfidenceIsRejected() throws {
        let analysis = try processing()
        let draft = MetricDraft(metricKey: "torso.lean", value: 12, unit: .degrees, confidence: 1.5, measurementStatus: .measured)
        #expect(throws: AnalysisServiceError.invalidResult([.valueOutOfRange(.metricConfidence, value: 1.5)])) {
            try f.analyses.addMetric(draft, to: analysis)
        }
    }

    @Test func categoryScoreAboveHundredIsRejected() throws {
        let analysis = try processing()
        #expect(throws: AnalysisServiceError.invalidResult([.valueOutOfRange(.score, value: 120)])) {
            try f.analyses.addCategoryScore(CategoryScoreDraft(category: .plant, score: 120, confidence: 0.8, measurementStatus: .measured), to: analysis)
        }
    }

    @Test func cueMayReferenceImproveInSameAnalysis() throws {
        let analysis = try processing()
        let improve = try f.analyses.addObservation(
            CoachingObservationDraft(kind: .improve, category: .plant, message: "Plant is wide.", severity: .moderate),
            to: analysis
        )
        let cue = try f.analyses.addObservation(
            CoachingObservationDraft(kind: .cue, category: .plant, message: "Get the plant underneath you.", relatedObservationID: improve.id),
            to: analysis
        )
        #expect(cue.relatedObservationID == improve.id)
        #expect(analysis.observations?.count == 2)
    }

    @Test func cueCannotReferenceObservationInAnotherAnalysis() throws {
        let first = try processing()
        let improveInFirst = try f.analyses.addObservation(
            CoachingObservationDraft(kind: .improve, category: .plant, message: "Plant is wide."),
            to: first
        )
        let second = try processing()
        #expect(throws: AnalysisServiceError.invalidResult([.relatedObservationNotInAnalysis(improveInFirst.id)])) {
            try f.analyses.addObservation(
                CoachingObservationDraft(kind: .cue, category: .plant, message: "Stay tall.", relatedObservationID: improveInFirst.id),
                to: second
            )
        }
        #expect((second.observations ?? []).isEmpty)
    }

    @Test func completedAnalysisIsImmutable() throws {
        let analysis = try processing()
        try f.analyses.addMetric(MetricDraft(metricKey: "torso.lean", value: 8, unit: .degrees, confidence: 0.9, measurementStatus: .measured), to: analysis)
        try f.analyses.markCompleted(analysis, confidence: 0.9)

        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .completed)) {
            try f.analyses.addMetric(.unavailable("plant.kneeAngle", unit: .degrees), to: analysis)
        }
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .completed)) {
            try f.analyses.addCategoryScore(CategoryScoreDraft(category: .plant, score: 70, confidence: 0.7, measurementStatus: .measured), to: analysis)
        }
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .completed)) {
            try f.analyses.addObservation(CoachingObservationDraft(kind: .keep, category: .swing, message: "Great."), to: analysis)
        }
        let secondVideo = try f.addVideo(to: kick, path: "k/rear.mov")
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .completed)) {
            try f.analyses.addInputVideo(secondVideo, to: analysis)
        }
        #expect(analysis.metrics?.count == 1)
        #expect(analysis.inputVideos?.count == 1)
    }
}
