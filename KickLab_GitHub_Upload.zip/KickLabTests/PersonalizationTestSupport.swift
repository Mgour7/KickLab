import Foundation
@testable import KickLab

/// Synthetic kick histories with exactly known values.
enum PersonalFixture {
    static let start = Date(timeIntervalSince1970: 1_800_000_000)
    static let day: TimeInterval = 86_400

    static func date(_ dayIndex: Double) -> Date { start.addingTimeInterval(dayIndex * day) }

    /// A deterministic UUID from a small number (stable across runs).
    static func id(_ n: Int, _ salt: Int = 0) -> UUID {
        UUID(uuidString: String(format: "00000000-0000-4000-8000-%06X%06X", salt, n))!
    }

    static func kick(
        _ index: Int,
        type: KickType = .fieldGoal,
        foot: KickingFoot? = .right,
        result: KickResult? = .made,
        distance: Double? = 40,
        day: Double? = nil,
        values: [KickMetricKey: Double],
        confidence: Double = 0.8,
        angle: VideoAngleType? = .side,
        completed: Bool = true,
        outcome: KickOutcomeSummary? = nil
    ) -> HistoricalKickAnalysis {
        var metrics: [KickMetricKey: HistoricalMetricValue] = [:]
        for (key, value) in values {
            metrics[key] = HistoricalMetricValue(value: value, confidence: confidence, status: .estimated,
                                                 definitionVersion: key.definition.definitionVersion, cameraAngle: angle)
        }
        return HistoricalKickAnalysis(
            kickID: id(index, 1), analysisID: id(index, 2), kickDate: date(day ?? Double(index)), kickType: type,
            kickingFoot: foot, analysisCompleted: completed,
            outcome: outcome ?? KickOutcomeSummary(result: (type == .fieldGoal || type == .pat) ? result : nil, distanceYards: distance),
            metrics: metrics
        )
    }

    /// One field goal per value of a single metric (made unless `results` says otherwise).
    static func series(_ key: KickMetricKey, _ values: [Double], results: [KickResult]? = nil, firstIndex: Int = 0,
                       confidence: Double = 0.8, angle: VideoAngleType? = .side) -> [HistoricalKickAnalysis] {
        values.enumerated().map { i, v in
            kick(firstIndex + i, result: results?[i] ?? .made, values: [key: v], confidence: confidence, angle: angle)
        }
    }

    static func scope(_ type: KickType = .fieldGoal, foot: KickingFoot = .right, angle: VideoAngleType? = .side,
                      bucket: DistanceBucket? = nil, epoch: BaselineEpoch? = nil, excluding: UUID? = nil,
                      now: Double = 100) -> PersonalizationScope {
        PersonalizationScope(kickType: type, kickingFoot: foot, cameraAngle: angle, distanceBucket: bucket, epoch: epoch,
                             excludingKickID: excluding, now: date(now))
    }

    static func profile(_ kicks: [HistoricalKickAnalysis], scope: PersonalizationScope = scope(),
                        configuration: PersonalizationConfiguration = PersonalizationConfiguration()) throws -> AthleteBiomechanicsProfile {
        try StatisticalAthleteLearningModel().buildProfile(from: kicks, scope: scope, configuration: configuration)
    }

    /// The current kick (index 999) with the given values.
    static func current(_ values: [KickMetricKey: Double], distance: Double? = 40, confidence: Double = 0.8,
                        angle: VideoAngleType? = .side, type: KickType = .fieldGoal) -> HistoricalKickAnalysis {
        kick(999, type: type, result: nil, distance: distance, day: 99, values: values, confidence: confidence, angle: angle)
    }

    static let analysisID = id(999, 9)

    static func report(current: HistoricalKickAnalysis, history: [HistoricalKickAnalysis], general: [GeneralRuleFinding] = [],
                       configuration: PersonalizationConfiguration = PersonalizationConfiguration()) throws -> PersonalizedCoachingReport {
        try PersonalCoachingEngine.report(analysisID: analysisID, current: current, history: history, generalFindings: general,
                                          epoch: nil, now: date(100), configuration: configuration).report
    }
}
