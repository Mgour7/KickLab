import Foundation
import Testing
@testable import KickLab

/// File storage against a real temporary directory. No SwiftData; runs on any platform.
@Suite("Managed media store")
struct ManagedMediaStoreTests {
    private let kickID = UUID()

    private func makeStore(
        _ temp: TemporaryDirectory,
        metadata: VideoMediaMetadata? = nil,
        thumbnails: any VideoThumbnailGenerating = NoThumbnailGenerator()
    ) throws -> ManagedMediaStore {
        let store = ManagedMediaStore(
            locations: MediaLocations(baseURL: temp.kickLabBase),
            metadataReader: FixedMetadataReader(metadata: metadata),
            thumbnailGenerator: thumbnails
        )
        try store.prepareDirectories()
        return store
    }

    // MARK: Roots

    @Test func prepareDirectoriesCreatesBothRoots() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        #expect(exists(store.mediaRootURL))
        #expect(exists(store.analysisRootURL))
        #expect(store.mediaRootURL.lastPathComponent == "Media")
        #expect(store.analysisRootURL.lastPathComponent == "Analysis")
    }

    // MARK: Import

    @Test func importCopiesBytesAndLeavesOriginalUntouched() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        let bytes: [UInt8] = Array(0...255)
        let source = try temp.writeFile(named: "Game Day (1).MOV", bytes: bytes)

        let videoID = UUID()
        let prepared = try await store.prepareImport(from: source, kickID: kickID, videoID: videoID)

        #expect(prepared.relativeFilePath == ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: "mov"))
        #expect(!prepared.relativeFilePath.hasPrefix("/"))
        #expect(prepared.byteCount == 256)
        #expect(prepared.originalFilename == "Game Day (1).MOV")
        let copy = try store.url(for: prepared.relativeFilePath, in: .media)
        #expect(fileBytes(at: copy) == bytes)
        #expect(fileBytes(at: source) == bytes, "the source file is never modified")
        #expect(store.fileExists(prepared.relativeFilePath, in: .media))
    }

    @Test func importRecordsMetadataWhenAvailable() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let metadata = VideoMediaMetadata(durationSeconds: 3.5, frameRate: 240, pixelWidth: 1080, pixelHeight: 1920, hasAudio: false)
        let store = try makeStore(temp, metadata: metadata)
        let prepared = try await store.prepareImport(from: try temp.writeFile(named: "a.mp4"), kickID: kickID, videoID: UUID())
        #expect(prepared.metadata == metadata)
    }

    @Test func missingMetadataDoesNotFailImport() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp, metadata: nil)
        let prepared = try await store.prepareImport(from: try temp.writeFile(named: "a.mov"), kickID: kickID, videoID: UUID())
        #expect(prepared.metadata == nil)
        #expect(store.fileExists(prepared.relativeFilePath, in: .media))
    }

    @Test func thumbnailIsStoredBesideTheVideo() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp, thumbnails: WritingThumbnailGenerator())
        let videoID = UUID()
        let prepared = try await store.prepareImport(from: try temp.writeFile(named: "a.mov"), kickID: kickID, videoID: videoID)
        #expect(prepared.thumbnailRelativePath == ManagedPath.thumbnailPath(kickID: kickID, videoID: videoID))
        #expect(store.fileExists(prepared.thumbnailRelativePath!, in: .media))
    }

    @Test func thumbnailFailureDoesNotFailImportAndLeavesNoPartialFile() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp, thumbnails: FailingThumbnailGenerator())
        let videoID = UUID()
        let prepared = try await store.prepareImport(from: try temp.writeFile(named: "a.mov"), kickID: kickID, videoID: videoID)
        #expect(prepared.thumbnailRelativePath == nil)
        #expect(!store.fileExists(ManagedPath.thumbnailPath(kickID: kickID, videoID: videoID), in: .media))
        #expect(store.fileExists(prepared.relativeFilePath, in: .media))
    }

    @Test func unsupportedTypeIsRejectedAndNothingIsCreated() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        let source = try temp.writeFile(named: "notes.txt")
        await #expect(throws: VideoStorageError.unsupportedVideoType(fileExtension: "txt")) {
            try await store.prepareImport(from: source, kickID: kickID, videoID: UUID())
        }
        #expect(store.orphanReport(referencedMediaPaths: [], referencedAnalysisPaths: [], minimumAge: 0).isEmpty)
    }

    @Test func missingOrRemoteSourceIsRejected() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        await #expect(throws: VideoStorageError.sourceNotFound) {
            try await store.prepareImport(from: temp.url.appendingPathComponent("nope.mov"), kickID: kickID, videoID: UUID())
        }
        await #expect(throws: VideoStorageError.sourceNotAFileURL) {
            try await store.prepareImport(from: URL(string: "https://example.com/a.mov")!, kickID: kickID, videoID: UUID())
        }
    }

    @Test func discardRemovesAnUnsavedImport() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp, thumbnails: WritingThumbnailGenerator())
        let prepared = try await store.prepareImport(from: try temp.writeFile(named: "a.mov"), kickID: kickID, videoID: UUID())
        store.discard(prepared)
        #expect(!store.fileExists(prepared.relativeFilePath, in: .media))
        #expect(!exists(store.mediaRootURL.appendingPathComponent(ManagedPath.kickDirectory(kickID: kickID))))
    }

    // MARK: Removal

    @Test func removalDeletesManagedCopyPrunesFoldersAndIsIdempotent() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp, thumbnails: WritingThumbnailGenerator())
        let source = try temp.writeFile(named: "a.mov")
        let prepared = try await store.prepareImport(from: source, kickID: kickID, videoID: UUID())
        let request = MediaCleanupRequest(mediaRelativePaths: [prepared.relativeFilePath, prepared.thumbnailRelativePath!])

        let first = store.remove(request)
        #expect(first.removed.sorted() == request.mediaRelativePaths)
        #expect(first.isComplete)
        #expect(!exists(store.mediaRootURL.appendingPathComponent(ManagedPath.kickDirectory(kickID: kickID))), "empty folders are pruned")
        #expect(exists(store.mediaRootURL), "the root itself is kept")
        #expect(exists(source), "the import source is never deleted")

        let second = store.remove(request)
        #expect(second.removed.isEmpty)
        #expect(second.alreadyMissing.sorted() == request.mediaRelativePaths)
        #expect(second.isComplete)
    }

    @Test func unsafeCleanupPathsCannotEscapeTheRoots() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        let outsideInBase = try temp.writeFile("outside.txt", under: temp.kickLabBase)
        let outsideInTemp = try temp.writeFile(named: "outside.txt")

        let outcome = store.remove(MediaCleanupRequest(
            mediaRelativePaths: ["../outside.txt", "../../outside.txt", "/etc/hosts", "a/../../outside.txt"],
            analysisRelativePaths: ["../outside.txt", ".."]
        ))

        #expect(outcome.removed.isEmpty)
        #expect(outcome.rejectedUnsafe.count == 6)
        #expect(exists(outsideInBase))
        #expect(exists(outsideInTemp))
        #expect(exists(store.mediaRootURL))
    }

    @Test func removeKickDirectoryRemovesEveryVideoOfAKick() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        let a = try await store.prepareImport(from: try temp.writeFile(named: "a.mov"), kickID: kickID, videoID: UUID())
        let b = try await store.prepareImport(from: try temp.writeFile(named: "b.mp4"), kickID: kickID, videoID: UUID())
        let otherKick = try await store.prepareImport(from: try temp.writeFile(named: "c.mov"), kickID: UUID(), videoID: UUID())

        #expect(store.removeKickDirectory(kickID: kickID).removed == [ManagedPath.kickDirectory(kickID: kickID)])
        #expect(!store.fileExists(a.relativeFilePath, in: .media))
        #expect(!store.fileExists(b.relativeFilePath, in: .media))
        #expect(store.fileExists(otherKick.relativeFilePath, in: .media))
        #expect(store.removeKickDirectory(kickID: kickID).alreadyMissing.count == 1)
    }

    // MARK: Orphans

    @Test func orphanDetectionAndSweepTouchOnlyUnreferencedFiles() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile("k1/v1/original.mov", under: store.mediaRootURL, bytes: [1, 2, 3])
        try temp.writeFile("k1/v1/thumbnail.jpg", under: store.mediaRootURL, bytes: [1])
        try temp.writeFile("k1/v2/original.mov", under: store.mediaRootURL, bytes: [1, 2, 3, 4, 5])
        try temp.writeFile("a1/pose.bin", under: store.analysisRootURL, bytes: [9, 9])
        try temp.writeFile("a1/frames/0001.bin", under: store.analysisRootURL, bytes: [9])
        try temp.writeFile("a2/pose.bin", under: store.analysisRootURL, bytes: [7, 7, 7])

        let referencedMedia: Set<String> = ["k1/v1/original.mov", "k1/v1/thumbnail.jpg"]
        let referencedAnalysis: Set<String> = ["a1"]   // a whole artifacts folder
        let report = store.orphanReport(referencedMediaPaths: referencedMedia, referencedAnalysisPaths: referencedAnalysis, minimumAge: 0)

        #expect(report.mediaPaths == ["k1/v2/original.mov"])
        #expect(report.analysisPaths == ["a2/pose.bin"])
        #expect(report.totalBytes == 8)

        let outcome = store.sweep(report)
        #expect(outcome.removed.sorted() == ["a2/pose.bin", "k1/v2/original.mov"])
        #expect(store.fileExists("k1/v1/original.mov", in: .media))
        #expect(store.fileExists("k1/v1/thumbnail.jpg", in: .media))
        #expect(store.fileExists("a1/pose.bin", in: .analysis))
        #expect(store.fileExists("a1/frames/0001.bin", in: .analysis))
        #expect(store.orphanReport(referencedMediaPaths: referencedMedia, referencedAnalysisPaths: referencedAnalysis, minimumAge: 0).isEmpty)
    }

    @Test func recentFilesAreNeverReportedAsOrphans() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile("k/v/original.mov", under: store.mediaRootURL)
        // An in-flight import: copied, record not yet saved.
        #expect(store.orphanReport(referencedMediaPaths: [], referencedAnalysisPaths: [], minimumAge: 3600).isEmpty)
        #expect(store.orphanReport(referencedMediaPaths: [], referencedAnalysisPaths: [], minimumAge: 3600, now: .now.addingTimeInterval(7200)).mediaPaths == ["k/v/original.mov"])
    }

    // MARK: Sizes

    @Test func fileSizesAreMeasuredFromDisk() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = try makeStore(temp)
        try temp.writeFile("k/v/original.mov", under: store.mediaRootURL, bytes: Array(repeating: 0, count: 1000))
        #expect(store.fileSize("k/v/original.mov", in: .media) == 1000)
        #expect(store.fileSize("k/v/missing.mov", in: .media) == nil)
        #expect(store.fileSize("../escape", in: .media) == nil)
    }
}
