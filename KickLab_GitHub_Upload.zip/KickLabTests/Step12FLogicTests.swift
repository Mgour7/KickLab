import Foundation
import Testing
@testable import KickLab

/// Step 12F logic that runs without Apple frameworks: frame tables and verification,
/// results tracking, the progress dashboard, the capture guide, the coaching report,
/// profile validation and diagnostics format 5.
@Suite("Step 12F logic")
struct Step12FLogicTests {
    typealias Real = RealReferenceClipRear

    // MARK: Source frames

    @Test func frameTablesUseTheVideosOwnTimestamps() {
        // Decode order, a duplicate and a NaN: sorted, de-duplicated, finite.
        let t = SourceFrameTable(times: [0.1, 0, 0.0333, .nan, 0.0333, 0.0667])
        #expect(t.times == [0, 0.0333, 0.0667, 0.1])
        #expect(t.index(at: 0.05) == 1, "the frame on screen at 0.05 s is the one shown at 0.0333 s")
        #expect(t.nearestIndex(to: 0.06) == 2)
        #expect(t.index(at: -1) == 0 && t.index(at: 9) == 3)
        #expect(t.clamped(99) == 3 && t.clamped(-4) == 0)
        #expect(!t.isVariableFrameRate)
        // Variable frame rate: frame N is NOT at N/30.
        let vfr = SourceFrameTable(times: [0, 0.033, 0.066, 0.116, 0.149])
        #expect(vfr.isVariableFrameRate)
        #expect(vfr.time(at: 3) == 0.116)
        #expect(SourceFrameTable(times: []).index(at: 1) == nil)
    }

    @Test func theRealClipsDisagreementIsFiveSourceFrames() {
        let table = SourceFrameTable(times: Real.time)
        #expect(table.count == 228)
        #expect(table.frameDifference(from: Real.engine250AutomaticContact, to: Real.humanReferenceContact) == -5)
        let c = ContactVerificationComparison.make(automatic: Real.engine250AutomaticContact, interval: nil,
                                                   annotation: .contact(time: Real.humanReferenceContact), table: table)
        #expect(c.frames == -5)
        #expect(c.text.contains("5 frames (0.166 s) earlier"))
        let now = ContactVerificationComparison.make(automatic: 3.867, interval: 3.867...3.9, annotation: .contact(time: 3.867), table: table)
        #expect(now.text == "Your frame matches the automatic estimate.")
        #expect(ContactVerificationComparison.make(automatic: 3.867, interval: nil, annotation: .cannotTell, table: table).userTime == nil)
    }

    // MARK: Results tracking

    private func fg(_ result: KickResult?, _ yards: Double?, day: Double = 0, session: UUID? = nil) -> KickStatRecord {
        KickStatRecord(sessionID: session, timestamp: Date(timeIntervalSince1970: 1_800_000_000 + day * 86_400), kickType: .fieldGoal,
                       result: result, distanceYards: yards)
    }

    @Test func fieldGoalSummariesCountRecordedAttemptsOnly() throws {
        let records = [fg(.made, 25), fg(.made, 44), fg(.missedLeft, 47), fg(.missedOther, 52), fg(.short, nil), fg(nil, 30), fg(.unknown, 33)]
        let s = try #require(GoalpostSummary.make(records, type: .fieldGoal))
        #expect(s.overall == RateSummary(successes: 2, attempts: 5))
        #expect(s.overall.text == "40% · 2 of 5")
        #expect(s.overall.sampleNote == "Small sample (5 attempts)")
        #expect(s.unrecorded == 2, "no result recorded: not an attempt")
        #expect(s.withoutDistance == 1)
        #expect(s.longestMake == 44, "a missed 52 is not the longest make")
        #expect(s.byDistance.map(\.bucket) == [.under30, .from40To49, .fiftyPlus])
        #expect(s.misses.map(\.result) == [.missedLeft, .short, .missedOther])
        #expect(GoalpostSummary.make(records, type: .pat) == nil)
        #expect(RateSummary(successes: 80, attempts: 100).sampleNote == nil)
    }

    @Test func kickoffsAndPuntsStaySeparate() throws {
        var ko = KickStatRecord(kickType: .kickoff, distanceYards: 60, touchback: true, hangTimeSeconds: 3.9)
        ko.direction = .left
        var punt = KickStatRecord(kickType: .punt, distanceYards: 38, hangTimeSeconds: 4.1)
        punt.puntInsideTwenty = true
        punt.puntResult = .fairCatch
        let s = SessionPerformanceSummary.make([ko, punt, fg(.made, 30)])
        #expect(s.kickoffs?.count == 1 && s.punts?.count == 1 && s.fieldGoals?.overall.attempts == 1)
        #expect(s.kickoffs?.distance.best == 60 && s.punts?.distance.best == 38, "distances never mix")
        #expect(s.kickoffs?.touchbacks == RateSummary(successes: 1, attempts: 1))
        #expect(s.punts?.insideTwenty == RateSummary(successes: 1, attempts: 1))
        #expect(s.punts?.results[.fairCatch] == 1 && s.kickoffs?.directions[.left] == 1)
        #expect(s.shortText == "FG 1 of 1 · KO 1 · Punts 1")
        #expect(s.sections.map(\.title) == ["Field goals", "Kickoffs", "Punts"])
        #expect(SessionPerformanceSummary.make([]).isEmpty)
        #expect(SessionPerformanceSummary.make([]).shortText == "No kicks recorded")
    }

    @Test func enteredDetailsKeepOnlyWhatAppliesToTheKickType() {
        let all = KickEnteredDetails(ballType: .college, setup: .tee, conditions: "  ", direction: .right, puntInsideTwenty: false, puntResult: .downed)
        let fieldGoal = all.applicable(to: .fieldGoal)
        #expect(fieldGoal.direction == nil && fieldGoal.puntResult == nil && fieldGoal.puntInsideTwenty == nil)
        #expect(fieldGoal.ballType == .college && fieldGoal.setup == .tee && fieldGoal.conditions == nil)
        #expect(all.applicable(to: .kickoff).direction == .right && all.applicable(to: .kickoff).puntResult == nil)
        #expect(all.applicable(to: .punt) .puntResult == .downed)
    }

    @Test func aMissedOtherIsAMissForEveryStatistic() {
        let s = KickStatisticsCalculator.fieldGoal([fg(.made, 30), fg(.missedOther, 30)], kickType: .fieldGoal, measurementSource: .all)
        #expect(s.results.missedOther == 1 && s.results.decided == 2)
        #expect(s.makeRate.attempts == 2 && s.makeRate.successes == 1)
        #expect(KickEntryForm.selectableResults.contains(.missedOther))
    }

    // MARK: Progress dashboard

    private let now = Date(timeIntervalSince1970: 1_800_000_000 + 100 * 86_400)

    @Test func anEmptyDashboardSaysSoAndInventsNothing() {
        let d = ProgressDashboard.make(records: [], sessions: [], analyses: [], range: .allTime, now: now)
        #expect(d.isEmpty && d.totalKicks == 0)
        #expect(d.fieldGoalPoints.isEmpty && d.personalBests.isEmpty && d.analysisGroups.isEmpty && d.recentSessions.isEmpty)
        #expect(d.consistencyText == "No kicks recorded in this period.")
    }

    @Test func theDashboardUsesOnlyKicksInTheRangeButBestsAreAllTime() {
        let session = UUID()
        let old = fg(.made, 51, day: 0)
        let recent = [fg(.made, 30, day: 95, session: session), fg(.missedRight, 40, day: 95, session: session), fg(.made, 35, day: 98)]
        let d = ProgressDashboard.make(records: [old] + recent, sessions: [(id: session, date: recent[0].timestamp, name: "Tuesday")],
                                       analyses: [], range: .last30, now: now)
        #expect(d.totalKicks == 3)
        #expect(d.fieldGoals?.overall == RateSummary(successes: 2, attempts: 3))
        #expect(d.fieldGoalPoints.map(\.value) == [50, 100], "one point per day, from that day's attempts")
        #expect(d.personalBests.first { $0.title == "Longest made field goal" }?.value == DisplayFormat.yards(51))
        #expect(d.recentSessions.first?.summary == "FG 1 of 2")
        #expect(d.trainingDays == 2 && d.sessionsInRange == 1)
        #expect(ProgressDashboard.make(records: [old] + recent, sessions: [], analyses: [], range: .allTime, now: now).totalKicks == 4)
    }

    @Test func analysisTrendsNeverMixViewsVersionsOrAssistedRuns() {
        func a(_ day: Double, _ angle: VideoAngleType, _ version: String, score: Double?, p2c: Double?, assisted: Bool = false) -> AnalysisTrendRecord {
            AnalysisTrendRecord(date: Date(timeIntervalSince1970: 1_800_000_000 + day * 86_400), kickType: .fieldGoal, cameraAngle: angle,
                                engineVersion: version, isUserAssisted: assisted, overallScore: score, plantToContact: p2c)
        }
        let analyses = [
            a(80, .side, "pose-biomechanics-2.5.0", score: 70, p2c: 0.12), a(85, .side, "pose-biomechanics-2.5.0", score: 74, p2c: 0.11),
            a(90, .side, "pose-biomechanics-2.6.0", score: 72, p2c: 0.12),
            a(91, .rear, "pose-biomechanics-2.6.0", score: nil, p2c: 0.10), a(92, .rear, "pose-biomechanics-2.6.0", score: nil, p2c: 0.11),
            a(93, .rear, "pose-biomechanics-2.6.0", score: nil, p2c: 0.30, assisted: true),
        ]
        let d = ProgressDashboard.make(records: [fg(.made, 30, day: 95)], sessions: [], analyses: analyses, range: .allTime, now: now)
        #expect(d.analysisGroups.count == 3, "side 2.5.0, side 2.6.0 and rear 2.6.0 are separate lines")
        let rear = d.analysisGroups.first { $0.cameraAngle == .rear }
        #expect(rear?.points.map(\.value) == [0.10, 0.11], "the user-assisted run is left out")
        #expect(rear?.metricTitle == "Plant → contact (s)", "no score is invented for a rear view")
        #expect(d.analysisGroups.first { $0.engineVersion.hasSuffix("2.6.0") && $0.cameraAngle == .side }?.isChartable == false)
    }

    // MARK: Capture guide

    @Test func theCaptureGuideGivesNoUnvalidatedNumbers() {
        for kick in CaptureGuide.kickTypes {
            for view in CaptureGuide.View.allCases {
                let text = CaptureGuide.tips(kick, view).map { $0.title + " " + $0.detail }.joined(separator: " ")
                #expect(text.contains("60 fps"))
                // No "10 feet", "5 m", "20 yards" style distances.
                let distance = text.range(of: #"\d+\s*(feet|foot|ft|m|meters|metres|yards|yd)\b"#, options: .regularExpression)
                #expect(distance == nil, "\(kick) \(view)")
                #expect(text.contains(kick == .punt ? "drop" : "ball"))
            }
        }
        #expect(CaptureGuide.tips(.fieldGoal, .rear).contains { $0.detail.contains("Rear") })
        #expect(CaptureGuide.frameRateAdvice(29.97).contains("±33 ms"))
        #expect(CaptureGuide.frameRateAdvice(240) == "240 fps — good for timing contact.")
        #expect(CaptureGuide.frameRateAdvice(nil) == "Frame rate unknown.")
        #expect(CaptureGuide.measurementNote(.rear).contains("no score"))
    }

    // MARK: Coaching report

    private func rearInput(annotation: ContactAnnotation, priorities: Bool) -> CoachingReportOverview.Input {
        let phases = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal, perspective: .depthAway)
        return CoachingReportOverview.Input(
            kickType: .fieldGoal, date: Date(timeIntervalSince1970: 1_800_000_000), engineVersion: "pose-biomechanics-2.6.0",
            perspective: PerspectiveDecision(declared: .rear, used: .depthAway, cues: nil, declaredContradicted: false, explanation: ""),
            outcome: .partialMeasurements, phases: phases, metrics: [], annotation: annotation, nominalFrameRate: 29.99,
            hasContactPriorities: priorities
        )
    }

    @Test func theReportIsNumberedAndHonestAboutContact() {
        let r = CoachingReportOverview.make(rearInput(annotation: .contact(time: 3.867), priorities: true))
        #expect(r.items.map(\.number) == [1, 2, 3, 4, 5, 6])
        let contact = r.items[3].lines.joined(separator: " ")
        #expect(contact.contains("Contact estimated from body pose: 3.900 s (possible 3.867–3.933 s) — the ball isn't tracked"))
        #expect(contact.contains("0.033 s earlier than the automatic estimate (about 1 frame)"))
        #expect(r.contactUncertain, "pose-only from behind: no precise contact advice")
        #expect(r.suppressedContactAdvice)
        #expect(r.items[2].lines[0].contains("Knee and hip angles can't be measured"))
        let earlier = CoachingReportOverview.make(rearInput(annotation: .contact(time: 3.8), priorities: false))
        #expect(earlier.items[3].lines.contains { $0.contains("0.100 s earlier than the automatic estimate (about 3 frames)") })
        #expect(!earlier.suppressedContactAdvice, "nothing to withhold")
        #expect(CoachingReportOverview.make(rearInput(annotation: .cannotTell, priorities: false)).items[3].lines.contains { $0.contains("couldn't tell") })
    }

    @Test func informationalMetricsAreMarkedNotValidated() {
        let rows = AnalysisPresentationBuilder.metricRows([
            StoredMetricRecord(key: KickMetricKey.lateralTrunkLeanAtContact.rawValue, value: 9.6, unit: .degrees, confidence: 0.4,
                               status: .estimated, phase: .contact),
        ])
        #expect(rows.first?.provenanceText == "Estimated from video · Not validated")
    }

    // MARK: Profile

    @Test func profileValidationCoversTheNewFields() {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        var p = AthleteProfile(firstName: "Ava")
        p.birthYear = 2090
        p.goals = String(repeating: "x", count: 2_001)
        p.photoData = Data(count: 2_000_001)
        let issues = AthleteProfileValidator.validate(p, now: now)
        #expect(issues.contains(.valueOutOfRange(.birthYear, value: 2090)))
        #expect(issues.contains(.valueOutOfRange(.goals, value: 2001)))
        #expect(issues.contains(.valueOutOfRange(.photo, value: 2_000_001)))
        var ok = AthleteProfile(firstName: "Ava")
        ok.birthYear = 2009
        ok.nickname = "  "
        #expect(AthleteProfileValidator.validate(ok, now: now).isEmpty)
        #expect(ok.normalized.nickname == nil)
        #expect(AthleteRole.allCases.map(\.rawValue) == ["kicker", "punter", "both", "unknown"])
        #expect(PuntResult(storedValue: "fromTheFuture") == .unknown, "unknown stored values never crash")
    }

    // MARK: Diagnostics format 5

    @Test func diagnosticsSummaryCarriesContactEvidenceWithoutTheFrameArrays() {
        let out = DepthViewSynthetic.run(DepthViewSynthetic.Script())
        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: out, engineVersion: "pose-biomechanics-2.6.0"), storedStatus: "completed",
            storedFailureReason: nil, kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0),
            referenceContactTime: 1.55, humanAnnotation: "contact"
        )
        #expect(report.formatVersion == 5)
        let summary = report.summaryText
        #expect(summary.contains("Contact (format 5):"))
        #expect(summary.contains("independent evidence groups agreeing"))
        #expect(summary.contains("ball detector: detectorUnavailable · frames examined 0"))
        #expect(summary.contains("human-reviewed contact: contact"))
        #expect(!summary.contains("--- JSON ---") && !summary.contains("\"timeSeries\""), "frame arrays only in the full export")
        #expect(report.plainText.contains("--- JSON ---"))
        #expect(report.humanReferenceCheck?.referenceTime == 1.55)
        #expect(!report.json().contains("\"x\""), "still no coordinates")
    }
}
