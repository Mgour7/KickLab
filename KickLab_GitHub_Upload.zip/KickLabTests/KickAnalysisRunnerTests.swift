import Foundation
import SwiftData
import Testing
@testable import KickLab

/// A scripted engine: returns a fixed result or throws, and records the request.
final class ScriptedAnalysisEngine: VideoAnalysisService, @unchecked Sendable {
    enum Behavior {
        case succeed(PoseAnalysisSummary?, artifacts: String?)
        case fail(VideoAnalysisError)
    }

    private let lock = NSLock()
    private var recorded: VideoAnalysisRequest?
    let behavior: Behavior
    let availability: VideoAnalysisAvailability

    init(_ behavior: Behavior, availability: VideoAnalysisAvailability = .available) {
        self.behavior = behavior
        self.availability = availability
    }

    var engineVersion: String { "scripted-1" }

    var lastRequest: VideoAnalysisRequest? {
        lock.lock()
        defer { lock.unlock() }
        return recorded
    }

    private func record(_ request: VideoAnalysisRequest) {
        lock.lock()
        defer { lock.unlock() }
        recorded = request
    }

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        PreparedVideoAnalysis(requestID: request.id, engineVersion: engineVersion, usableVideoIDs: request.inputVideoIDs,
                              rejectedInputs: [], estimatedFrameCount: nil)
    }

    func analyze(_ request: VideoAnalysisRequest, progress: @escaping @Sendable (VideoAnalysisProgress) -> Void) async throws -> VideoAnalysisResult {
        record(request)
        switch behavior {
        case .succeed(let summary, let artifacts):
            return VideoAnalysisResult(requestID: request.id, engineVersion: engineVersion,
                                       artifactsRelativePath: artifacts, poseSummary: summary)
        case .fail(let error):
            throw error
        }
    }
}

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("Kick analysis runner")
struct KickAnalysisRunnerTests {
    let f: ServiceFixture
    let athlete: Athlete
    let kick: Kick
    let video: VideoAsset

    init() throws {
        f = try ServiceFixture()
        athlete = try f.athletes.createAthlete(AthleteProfile(firstName: "Lefty", lastName: "Kicker", kickingFoot: .left))
        kick = try f.makeKick(for: athlete)
        video = try f.addVideo(to: kick, path: "k/side.mov")
    }

    private static func summary(_ status: KickerSelectionStatus) -> PoseAnalysisSummary {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right
        ))
        var summary = PoseAnalysisSummary(primaryVideoID: UUID(), output: output)
        summary.kickerStatus = status
        return summary
    }

    @Test func completedRunAttachesArtifactsAndUsesAthleteFoot() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: "abc"))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])

        guard case .completed(let analysis, let summary) = outcome else {
            Issue.record("expected completion, got \(outcome)")
            return
        }
        #expect(analysis.processingStatus == .completed)
        #expect(analysis.artifactsRelativePath == "abc")
        #expect(analysis.analysisVersion == "scripted-1")
        #expect(analysis.isCurrent == false, "not promoted: no metrics yet")
        #expect((analysis.metrics ?? []).isEmpty)
        #expect(summary?.kickerStatus == .selected)
        #expect(f.context.hasChanges == false, "everything saved")

        let request = try #require(engine.lastRequest)
        #expect(request.options.kickingFoot == .left, "kicking foot comes from the athlete")
        #expect(request.options.artifactsDirectoryID == analysis.id, "artifacts folder matches the record")
        #expect(request.kickID == kick.id)
    }

    @Test func ambiguousKickerFailsWithClearReason() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.ambiguous), artifacts: "abc"))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .failed(let analysis, let reason, _) = outcome else {
            Issue.record("expected failure, got \(outcome)")
            return
        }
        #expect(reason.contains("Multiple possible kickers found"))
        #expect(analysis.processingStatus == .failed)
        #expect(analysis.failureReason == reason)
        #expect(analysis.artifactsRelativePath == "abc", "diagnostic artifacts stay attached")
    }

    @Test func engineFailureMarksAnalysisFailed() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.failed("decoder broke")))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        #expect(outcome.analysis.processingStatus == .failed)
        #expect(outcome.analysis.failureReason?.contains("decoder broke") == true)
    }

    @Test func engineCancellationCancelsAnalysis() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.cancelled))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .cancelled(let analysis) = outcome else {
            Issue.record("expected cancellation, got \(outcome)")
            return
        }
        #expect(analysis.processingStatus == .cancelled)
        #expect(analysis.isCurrent == false)
    }

    @Test func unavailableEngineCreatesNoRecord() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.cancelled), availability: .unavailable(reason: "nope"))
        await #expect(throws: VideoAnalysisError.unavailable(reason: "nope")) {
            _ = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        }
        #expect(try f.count(BiomechanicsAnalysis.self) == 0)
    }

    @Test func attachArtifactsValidatesPathAndState() throws {
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: "1", inputVideos: [video])
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .queued)) {
            try f.analyses.attachArtifacts(relativePath: "abc", to: analysis)
        }
        try f.analyses.startProcessing(analysis)
        #expect(throws: AnalysisServiceError.invalidArtifactsPath("../x")) {
            try f.analyses.attachArtifacts(relativePath: "../x", to: analysis)
        }
        try f.analyses.attachArtifacts(relativePath: "abc", to: analysis)
        #expect(analysis.artifactsRelativePath == "abc")
    }

    /// The real pose engine with synthetic pose data, end to end through SwiftData.
    @Test func realEngineWithSyntheticPoseCompletes() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        try temp.writeFile("k/side.mov", under: store.mediaRootURL)
        let leftScript: SyntheticPose.KickScript = {
            var script = SyntheticPose.KickScript.fieldGoal
            script.kickingFoot = .left
            return script
        }()
        let engine = PoseVideoAnalysisService(mediaStore: store, extractor: FakePoseExtractor { SyntheticPose.sequence(leftScript, videoID: $0) })

        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .completed(let analysis, let summary) = outcome else {
            Issue.record("expected completion, got \(outcome)")
            return
        }
        #expect(analysis.analysisVersion == PoseVideoAnalysisService.version)
        #expect(analysis.artifactsRelativePath == ManagedPath.analysisDirectory(analysisID: analysis.id))
        #expect(near(summary?.plantTime, 1.2, 0.05), "left-footed plant found because the athlete is left-footed")
        let manifest = try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL).readManifest(in: try #require(analysis.artifactsRelativePath))
        #expect(manifest.primaryVideoID == video.id)
        #expect(manifest.kickID == kick.id)
    }
}
