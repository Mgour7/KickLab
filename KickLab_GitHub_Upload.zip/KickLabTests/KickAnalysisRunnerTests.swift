import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Result drafts a scripted engine returns.
struct ScriptedResults: Sendable {
    var metrics: [MetricDraft] = []
    var scores: [CategoryScoreDraft] = []
    var observations: [CoachingObservationDraft] = []
    var overallScore: Double?
    var overallConfidence: Double?

    static let none = ScriptedResults()

    /// The Step 8 drafts of the synthetic field goal, with a CUE linked to an IMPROVE.
    static var synthetic: ScriptedResults {
        var script = SyntheticPose.KickScript.fieldGoal
        script.plantSlip = 0.075
        let r = SyntheticBiomechanics.analyze(script)
        return ScriptedResults(metrics: r.metricDrafts, scores: r.scoreDrafts, observations: r.observationDrafts,
                               overallScore: r.overallScore, overallConfidence: r.overallConfidence)
    }

    /// One invalid metric (unavailable but carrying a value) among valid ones.
    static var invalid: ScriptedResults {
        var results = synthetic
        results.metrics.append(MetricDraft(metricKey: "plant.bogus", value: 1, unit: .degrees, confidence: nil, measurementStatus: .unavailable))
        return results
    }
}

/// A scripted engine: returns a fixed result or throws, and records the request.
final class ScriptedAnalysisEngine: VideoAnalysisService, @unchecked Sendable {
    enum Behavior {
        case succeed(PoseAnalysisSummary?, artifacts: String?, results: ScriptedResults = .none)
        case fail(VideoAnalysisError)
    }

    private let lock = NSLock()
    private var recorded: VideoAnalysisRequest?
    let behavior: Behavior
    let availability: VideoAnalysisAvailability

    init(_ behavior: Behavior, availability: VideoAnalysisAvailability = .available) {
        self.behavior = behavior
        self.availability = availability
    }

    var engineVersion: String { "scripted-1" }

    var lastRequest: VideoAnalysisRequest? {
        lock.lock()
        defer { lock.unlock() }
        return recorded
    }

    private func record(_ request: VideoAnalysisRequest) {
        lock.lock()
        defer { lock.unlock() }
        recorded = request
    }

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        PreparedVideoAnalysis(requestID: request.id, engineVersion: engineVersion, usableVideoIDs: request.inputVideoIDs,
                              rejectedInputs: [], estimatedFrameCount: nil)
    }

    func analyze(_ request: VideoAnalysisRequest, progress: @escaping @Sendable (VideoAnalysisProgress) -> Void) async throws -> VideoAnalysisResult {
        record(request)
        switch behavior {
        case .succeed(let summary, let artifacts, let results):
            return VideoAnalysisResult(requestID: request.id, engineVersion: engineVersion,
                                       metrics: results.metrics, categoryScores: results.scores,
                                       observations: results.observations,
                                       overallConfidence: results.overallConfidence, overallScore: results.overallScore,
                                       artifactsRelativePath: artifacts, poseSummary: summary)
        case .fail(let error):
            throw error
        }
    }
}

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("Kick analysis runner")
struct KickAnalysisRunnerTests {
    let f: ServiceFixture
    let athlete: Athlete
    let kick: Kick
    let video: VideoAsset

    init() throws {
        f = try ServiceFixture()
        athlete = try f.athletes.createAthlete(AthleteProfile(firstName: "Lefty", lastName: "Kicker", kickingFoot: .left))
        kick = try f.makeKick(for: athlete)
        video = try f.addVideo(to: kick, path: "k/side.mov")
    }

    private static func summary(_ status: KickerSelectionStatus) -> PoseAnalysisSummary {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right
        ))
        var summary = PoseAnalysisSummary(primaryVideoID: UUID(), output: output)
        summary.kickerStatus = status
        return summary
    }

    @Test func completedRunStoresResultsPromotesAndUsesAthleteFoot() async throws {
        let results = ScriptedResults.synthetic
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: "abc", results: results))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])

        guard case .completed(let analysis, let summary) = outcome else {
            Issue.record("expected completion, got \(outcome)")
            return
        }
        #expect(analysis.processingStatus == .completed)
        #expect(analysis.artifactsRelativePath == "abc")
        #expect(analysis.analysisVersion == "scripted-1")
        #expect(analysis.isCurrent == true, "a sufficient analysis is promoted to current")
        #expect((analysis.metrics ?? []).count == KickMetricKey.allCases.count)
        #expect((analysis.categoryScores ?? []).count == 6)
        #expect((analysis.observations ?? []).count == results.observations.count)
        #expect(analysis.overallScore == results.overallScore)
        #expect(analysis.confidence == results.overallConfidence)
        #expect(summary?.kickerStatus == .selected)

        // Stored exactly as drafted, including unavailable metrics (nil value) and the CUE link.
        let drift = (analysis.metrics ?? []).first { $0.metricKey == "plant.footDrift" }
        #expect(drift?.value == results.metrics.first { $0.metricKey == "plant.footDrift" }?.value)
        #expect(drift?.unit == .bodyLengths)
        let observations = analysis.observations ?? []
        let improve = observations.first { $0.kind == .improve }
        let cue = observations.first { $0.kind == .cue }
        #expect(improve?.ruleKey == "plant.unstable")
        #expect(cue?.relatedObservationID == improve?.id)
        #expect(improve?.evidenceMetricKeys == ["plant.footDrift"])
        #expect(f.context.hasChanges == false, "everything saved")

        let request = try #require(engine.lastRequest)
        #expect(request.options.kickingFoot == .left, "kicking foot comes from the athlete")
        #expect(request.options.artifactsDirectoryID == analysis.id, "artifacts folder matches the record")
        #expect(request.kickID == kick.id)
    }

    @Test func tooLittleMeasuredFailsAndIsNeverCurrent() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: "abc", results: .none))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .failed(let analysis, let reason, _) = outcome else {
            Issue.record("expected failure, got \(outcome)")
            return
        }
        #expect(reason == KickAnalysisRunner.insufficientDataReason)
        #expect(analysis.isCurrent == false)
        #expect(analysis.processingStatus == .failed)
    }

    @Test func invalidResultsAreRejectedWithoutPartialWrites() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: "abc", results: .invalid))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        #expect(outcome.analysis.processingStatus == .failed)
        #expect(outcome.analysis.failureReason == "The analysis produced results that failed validation.")
        #expect((outcome.analysis.metrics ?? []).isEmpty, "nothing from the invalid batch was stored")
        #expect(try f.count(BiomechanicalMetric.self) == 0)
        #expect(try f.count(CoachingObservation.self) == 0)
    }

    @Test func newerSufficientRunBecomesCurrentAndHistoryIsKept() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: nil, results: .synthetic))
        let runner = KickAnalysisRunner(analyses: f.analyses, engine: engine)
        let first = try await runner.run(kick: kick, videos: [video]).analysis
        let second = try await runner.run(kick: kick, videos: [video]).analysis
        #expect(first.isCurrent == false)
        #expect(second.isCurrent == true)
        #expect(first.processingStatus == .completed, "history is kept")
        #expect((kick.analyses ?? []).count == 2)
        #expect(try f.analyses.repairCurrent(for: kick).changedAnalysisIDs.isEmpty, "already consistent with the Step 5 rules")
    }

    @Test func recordResultsIsOneValidatedBatch() throws {
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: "1", inputVideos: [video])
        let results = ScriptedResults.synthetic
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .queued)) {
            try f.analyses.recordResults(metrics: results.metrics, categoryScores: [], observations: [], to: analysis)
        }
        try f.analyses.startProcessing(analysis)
        // A CUE whose IMPROVE is not in the batch is refused, and nothing is inserted.
        let orphanCue = CoachingObservationDraft(kind: .cue, category: .plant, message: "Stay still.", relatedObservationID: UUID())
        #expect(throws: AnalysisServiceError.self) {
            try f.analyses.recordResults(metrics: results.metrics, categoryScores: results.scores, observations: [orphanCue], to: analysis)
        }
        #expect((analysis.metrics ?? []).isEmpty)
        // The real batch, with its CUE after its IMPROVE, goes in at once.
        try f.analyses.recordResults(metrics: results.metrics, categoryScores: results.scores,
                                     observations: results.observations, to: analysis)
        #expect((analysis.metrics ?? []).count == results.metrics.count)
        #expect((analysis.categoryScores ?? []).count == results.scores.count)
        #expect((analysis.observations ?? []).count == results.observations.count)
        #expect(f.context.hasChanges == false)
    }

    @Test func metricSnapshotsComeFromStoredCurrentAnalyses() async throws {
        let results = ScriptedResults.synthetic
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.selected), artifacts: nil, results: results))
        let analysis = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video]).analysis
        let snapshot = try #require(MetricSnapshot(analysis: analysis))
        #expect(snapshot.kickID == kick.id)
        #expect(snapshot.kickType == .fieldGoal)
        let available = results.metrics.filter { $0.measurementStatus != .unavailable }
        #expect(snapshot.values.count == available.count)
        #expect(snapshot.values[.plantToContactTime]?.value == 0.2)
        #expect(MetricSnapshot.history(of: [kick]).count == 1)
        #expect(MetricComparison.compare(snapshot, to: snapshot).allSatisfy { $0.direction == .unchanged || $0.direction == .notApplicable })
    }

    @Test func ambiguousKickerFailsWithClearReason() async throws {
        let engine = ScriptedAnalysisEngine(.succeed(Self.summary(.ambiguous), artifacts: "abc"))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .failed(let analysis, let reason, _) = outcome else {
            Issue.record("expected failure, got \(outcome)")
            return
        }
        #expect(reason.contains("Multiple possible kickers found"))
        #expect(analysis.processingStatus == .failed)
        #expect(analysis.failureReason == reason)
        #expect(analysis.artifactsRelativePath == "abc", "diagnostic artifacts stay attached")
    }

    @Test func engineFailureMarksAnalysisFailed() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.failed("decoder broke")))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        #expect(outcome.analysis.processingStatus == .failed)
        #expect(outcome.analysis.failureReason?.contains("decoder broke") == true)
    }

    @Test func runtimeLimitationIsRecordedAsSuch() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.poseDetectionUnavailable(environment: .simulator)))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .failed(let analysis, let reason, let summary) = outcome else {
            Issue.record("expected failure, got \(outcome)")
            return
        }
        #expect(reason == "Pose detection can't run in the iOS Simulator. Analyze on an iPhone.")
        #expect(!reason.contains("The analysis failed"), "not reported as a broken video or analysis")
        #expect(summary == nil)
        #expect(analysis.artifactsRelativePath == nil)
        #expect((analysis.metrics ?? []).isEmpty)
    }

    @Test func engineCancellationCancelsAnalysis() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.cancelled))
        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .cancelled(let analysis) = outcome else {
            Issue.record("expected cancellation, got \(outcome)")
            return
        }
        #expect(analysis.processingStatus == .cancelled)
        #expect(analysis.isCurrent == false)
    }

    @Test func unavailableEngineCreatesNoRecord() async throws {
        let engine = ScriptedAnalysisEngine(.fail(.cancelled), availability: .unavailable(reason: "nope"))
        await #expect(throws: VideoAnalysisError.unavailable(reason: "nope")) {
            _ = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        }
        #expect(try f.count(BiomechanicsAnalysis.self) == 0)
    }

    @Test func attachArtifactsValidatesPathAndState() throws {
        let analysis = try f.analyses.createAnalysis(for: kick, analysisVersion: "1", inputVideos: [video])
        #expect(throws: AnalysisServiceError.analysisIsImmutable(status: .queued)) {
            try f.analyses.attachArtifacts(relativePath: "abc", to: analysis)
        }
        try f.analyses.startProcessing(analysis)
        #expect(throws: AnalysisServiceError.invalidArtifactsPath("../x")) {
            try f.analyses.attachArtifacts(relativePath: "../x", to: analysis)
        }
        try f.analyses.attachArtifacts(relativePath: "abc", to: analysis)
        #expect(analysis.artifactsRelativePath == "abc")
    }

    /// The real pose engine with synthetic pose data, end to end through SwiftData.
    @Test func realEngineWithSyntheticPoseCompletes() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        try temp.writeFile("k/side.mov", under: store.mediaRootURL)
        let leftScript: SyntheticPose.KickScript = {
            var script = SyntheticPose.KickScript.fieldGoal
            script.kickingFoot = .left
            return script
        }()
        let engine = PoseVideoAnalysisService(mediaStore: store, extractor: FakePoseExtractor { SyntheticPose.sequence(leftScript, videoID: $0) })

        let outcome = try await KickAnalysisRunner(analyses: f.analyses, engine: engine).run(kick: kick, videos: [video])
        guard case .completed(let analysis, let summary) = outcome else {
            Issue.record("expected completion, got \(outcome)")
            return
        }
        #expect(analysis.analysisVersion == PoseVideoAnalysisService.version)
        #expect(analysis.artifactsRelativePath == ManagedPath.analysisDirectory(analysisID: analysis.id))
        #expect(near(summary?.plantTime, 1.2, 0.05), "left-footed plant found because the athlete is left-footed")
        #expect(analysis.isCurrent == true)
        #expect((analysis.metrics ?? []).count == KickMetricKey.allCases.count)
        #expect((analysis.metrics ?? []).first { $0.metricKey == "plant.toContactTime" }?.value == 0.2)
        #expect((analysis.categoryScores ?? []).contains { $0.category == .overall && $0.score != nil })
        #expect((analysis.observations ?? []).map(\.ruleKey) == ["plant.stable"])
        #expect(analysis.overallScore != nil)
        let manifest = try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL).readManifest(in: try #require(analysis.artifactsRelativePath))
        #expect(manifest.primaryVideoID == video.id)
        #expect(manifest.kickID == kick.id)
    }
}
