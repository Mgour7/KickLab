import Foundation
import Testing
@testable import KickLab

/// Build 18 — Athlete Report 3.0, coaching insights, rankings and consistency.
///
/// Evidence classes: records are built from real engine runs on SYNTHETIC pose
/// (`SyntheticBiomechanics`), or hand-built to mirror the device diagnostics of the
/// reference recordings (the side clip's stored values are copied from its Build 14
/// diagnostics export). These test the report's rules, not the original footage.
@Suite("Athlete Report 3.0")
struct AthleteReportTests {
    private let day = 86_400.0

    private func record(_ script: SyntheticPose.KickScript = .fieldGoal, _ edit: (inout AnalysisRecord) -> Void = { _ in }) -> AnalysisRecord {
        var r = PresentationTests.record(script)
        edit(&r)
        return r
    }

    private func report(_ r: AnalysisRecord, view: ComparableView = .side, others: [RankingEntry] = [],
                        suitability: [SuitabilityFinding] = [], outcome: String? = nil, session: UUID? = nil,
                        presentation: AnalysisResultsPresentation? = nil) -> PerformanceReport {
        PerformanceReport.make(.init(presentation: presentation ?? AnalysisPresentationBuilder.make(r), record: r, view: view, others: others,
                                     suitability: suitability, outcomeText: outcome, sessionID: session))
    }

    private func entry(_ daysAgo: Double, overall: Double?, area: (AnalysisCategory, Double)? = nil, type: KickType = .fieldGoal,
                       view: ComparableView = .side, engine: String = PoseVideoAnalysisService.version, completed: Bool = true,
                       metrics: [KickMetricKey: Double] = [:], session: UUID? = nil) -> RankingEntry {
        var e = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_800_000_000 - daysAgo * day), kickType: type, view: view,
                             engineVersion: engine, completed: completed, overallScore: overall,
                             categoryScores: area.map { [$0.0: $0.1] } ?? [:], sessionID: session)
        for (k, v) in metrics { e.metrics[RankingEntry.metricKey(k)] = v }
        return e
    }

    /// Every catalog metric, as stored: the given ones available, the rest unavailable.
    private static func stored(_ available: [StoredMetricRecord]) -> [StoredMetricRecord] {
        KickMetricKey.allCases.map { key in available.first { $0.key == key.rawValue } ?? metric(key, nil, nil) }
    }

    private static func metric(_ key: KickMetricKey, _ value: Double?, _ confidence: Double?) -> StoredMetricRecord {
        StoredMetricRecord(key: key.rawValue, value: value, unit: key.definition.unit, confidence: confidence,
                           status: value == nil ? .unavailable : .estimated, phase: key.definition.phase)
    }

    /// The side reference recording (6.502 s) as stored by the device (Build 14 diagnostics):
    /// Approach 76.9 (confidence 0.733), Body Position at Contact 97.0 (0.489), nothing else rated.
    private func sideReference() -> AnalysisRecord {
        record { r in
            r.overallScore = nil
            r.confidence = 0.61
            r.categories = [
                StoredCategoryRecord(category: .approach, score: 76.9, confidence: 0.733, status: .estimated, summary: nil),
                StoredCategoryRecord(category: .plant, score: nil, confidence: nil, status: .unavailable, summary: nil),
                StoredCategoryRecord(category: .swing, score: nil, confidence: nil, status: .unavailable, summary: nil),
                StoredCategoryRecord(category: .contact, score: 97.0, confidence: 0.489, status: .estimated, summary: nil),
                StoredCategoryRecord(category: .followThrough, score: nil, confidence: nil, status: .unavailable, summary: nil),
            ]
            r.metrics = Self.stored([
                Self.metric(.approachSpeed, 2.997, 0.772), Self.metric(.approachSpeedVariation, 46.268, 0.772),
                Self.metric(.approachLateSpeedChange, 24.35, 0.656), Self.metric(.plantToContactTime, 0.033, 0.477),
                Self.metric(.plantFootDrift, 0.173, 0.328), Self.metric(.plantKneeAngleAtContact, 149.6, 0.509),
                Self.metric(.kickingKneeAngleAtContact, 149.0, 0.488), Self.metric(.backswingDepth, 0.495, 0.522),
                Self.metric(.peakFootSpeed, 18.767, 0.308), Self.metric(.torsoLeanAtContact, -9.38, 0.691),
                Self.metric(.bodyForwardSpeedAtContact, 0.388, 0.675),
            ])
            r.observations = []
        }
    }

    /// A rear recording like the build-10 clip: four rear-view measurements, nothing rated.
    private func rearReference() -> AnalysisRecord {
        record { r in
            r.overallScore = nil
            r.confidence = nil
            r.categories = KickMetricCatalog.scoredCategories.map { StoredCategoryRecord(category: $0, score: nil, confidence: nil, status: .unavailable, summary: nil) }
            r.metrics = Self.stored([
                Self.metric(.plantToContactTime, 0.1, 0.507), Self.metric(.followThroughDuration, 0.433, 0.48),
                Self.metric(.lateralTrunkLeanAtContact, 9.609, 0.696), Self.metric(.plantFootWidth, -0.533, 0.584),
                Self.metric(.plantBallLateralOffset, 0.57, 0.83), Self.metric(.plantLateralMovement, 0.16, 0.65),
            ])
            r.observations = []
        }
    }

    // MARK: The ten report scenarios

    // 1. Fully supported side view: a defensible technique score, ≤ 2 strengths with reasons.
    @Test func fullySupportedSideView() throws {
        let r = record()
        let rep = report(r, outcome: "Made · 40 yd")
        let overall = try #require(r.overallScore)
        guard case .technique(let score, let label, _) = rep.summary else { Issue.record("expected a technique score"); return }
        #expect(score == Int(overall.rounded()) && label == PerformanceReport.Label(score: overall))
        #expect(rep.header.outcomeText == "Made · 40 yd" && rep.header.outcomeRecorded)
        #expect(rep.header.state == .automatic)
        #expect(rep.strengths.count <= 2 && rep.improvements.count <= 2)
        #expect(rep.strengths.allSatisfy { !$0.reason.isEmpty && !$0.reason.contains(" · Good") }, "a reason, not just a grade")
        #expect(Set(rep.strengths.map(\.title)).count == rep.strengths.count)
        #expect(rep.unavailable.isEmpty)
        #expect(rep.measurements.isEmpty, "everything measured is inside a rated area")
    }

    // 2. Rear view with measurements and no score.
    @Test func rearViewWithMeasurementsButNoScore() {
        let rep = report(rearReference(), view: .depth)
        guard case .limited(let detail) = rep.summary else { Issue.record("expected limited"); return }
        #expect(detail.contains("measurements established"))
        #expect(rep.areas.isEmpty, "no empty scoreboard")
        #expect(rep.measurements.count == 5, "Build 20: every reliable rear-view measurement is shown (at most 6; follow-through 0.48 is below 0.5)")
        #expect(rep.measurements.contains { $0.key == .plantBallLateralOffset })
        let approach = rep.unavailable.first { $0.title == "Approach" }
        #expect(approach?.reason == "Not measurable from this camera view")
        #expect(rep.unavailable.first { $0.title == "Follow-Through" }?.reason == "Too few reliable measurements in this recording")
        // Build 20: no history yet → a measurable goal; the recording advice stays as a
        // separate recording recommendation.
        #expect(rep.focus == .goal("Record 3 more comparable kicks (same kick type and camera view) to build your consistency baseline."))
        #expect(rep.recordingAdvice == PerformanceReport.sideRecording)
        #expect(rep.noCorrectionText == PerformanceReport.noCorrection)
    }

    // 3. Short clip: ball contact, no plant.
    @Test func shortClipWithoutPlant() {
        let r = record { r in
            r.metrics = r.metrics.filter { $0.phase != .plant }
            r.categories = r.categories.map { c in
                guard c.category == .plant else { return c }
                var x = c; x.score = nil; x.status = .unavailable; return x
            }
        }
        let rep = report(r)
        #expect(!rep.areas.contains { $0.category == .plant })
        #expect(rep.unavailable.contains { $0.title == "Plant" })
    }

    // 4. Failed contact.
    @Test func failedContact() {
        let r = record { $0.status = .failed; $0.failureReason = "Couldn't pinpoint the strike." }
        var p = AnalysisPresentationBuilder.make(r)
        p.header.outcome = .kickDetectedTimingUncertain
        let rep = report(r, presentation: p)
        #expect(rep.summary == .incomplete(title: "Contact Not Found", detail: AnalysisOutcome.kickDetectedTimingUncertain.explanation))
        #expect(rep.header.state == .incomplete)
        #expect(rep.areas.isEmpty && rep.strengths.isEmpty && rep.improvements.isEmpty && rep.history == nil)
        #expect(rep.noCorrectionText == nil, "no coaching claim either way")
        if case .recording = rep.focus {} else { Issue.record("a recording recommendation") }
    }

    // 5. No kick.
    @Test func noKick() {
        let r = record { $0.status = .failed }
        var p = AnalysisPresentationBuilder.make(r)
        p.header.outcome = .noKickDetected
        #expect(report(r, presentation: p).summary.title == "No Kick Found")
    }

    // 6. Comparable kicks: rankings and comparison.
    @Test func comparableKicksAreRanked() throws {
        let r = record { $0.overallScore = 80 }
        let approach = try #require(AnalysisPresentationBuilder.make(r).categories.first { $0.category == .approach }?.score)
        let others = [entry(10, overall: 70, area: (.approach, approach + 5)), entry(5, overall: 75, area: (.approach, approach - 5)),
                      entry(2, overall: 85, area: (.approach, approach - 10))]
        let rep = report(r, others: others)
        let h = try #require(rep.history)
        #expect(h.previous == 85 && h.change == -5 && h.best == 85 && !h.isPersonalBest)
        #expect(h.standing.rank == 2 && h.standing.outOf == 4)
        #expect(rep.comparisonText?.hasPrefix("#2 of 4 comparable kicks") == true)
        #expect(rep.areas.first { $0.category == .approach }?.standing.rank == 2)
        #expect(h.spread != nil, "4 comparable kicks → a spread")
    }

    // 7. Only one eligible kick: no ranking.
    @Test func oneEligibleKickIsNotRanked() {
        let rep = report(record(), others: [entry(3, overall: 60)])
        #expect(rep.history?.standing.rank == nil)
        #expect(rep.comparisonText == nil)
        #expect(rep.areas.allSatisfy { $0.standing.rank == nil })
    }

    // 8. Incompatible views, kick types and scoring models.
    @Test func incompatibleKicksAreNotCompared() {
        let others = [entry(3, overall: 60, view: .depth), entry(4, overall: 61, type: .kickoff), entry(5, overall: 62, view: .unknown),
                      entry(6, overall: 63, engine: "pose-biomechanics-2.7.0"), entry(7, overall: 64, engine: "pose-biomechanics-3.1.0+assisted")]
        let rep = report(record(), others: others)
        #expect(rep.history?.previous == nil && rep.history?.standing.rank == nil)
        #expect(report(record(), view: .unknown, others: [entry(3, overall: 60, view: .unknown), entry(4, overall: 61, view: .unknown)])
            .history?.standing.rank == nil, "an unrecorded view is never ranked")
    }

    @Test func areaScoresAreComparedOnlyWhereTheScoringRulesMatch() {
        let r = record { $0.overallScore = 80 }
        let approach = AnalysisPresentationBuilder.make(r).categories.first { $0.category == .approach }?.score ?? 0
        let plant = AnalysisPresentationBuilder.make(r).categories.first { $0.category == .plant }?.score ?? 0
        // Two kicks scored by engine 2.9 (provisional-bands-1): Approach rules unchanged, Plant changed.
        let old = (0..<3).map { i in
            var e = entry(Double(10 + i), overall: 50, area: (.approach, approach - 1), engine: "pose-biomechanics-2.9.0")
            e.categoryScores[.plant] = plant - 1
            return e
        }
        let rep = report(r, others: old)
        #expect(rep.areas.first { $0.category == .approach }?.standing.rank == 1, "approach compares across 2.9 and 3.0")
        #expect(rep.areas.first { $0.category == .plant }?.standing.rank == nil, "plant scoring changed: not compared")
        #expect(rep.history?.previous == nil, "overall scoring changed: not compared")
        #expect(rep.history?.exclusionNote?.contains("earlier overall scoring model") == true)
    }

    // 9. Low confidence: limited, recording advice instead of a score.
    @Test func lowConfidenceIsLimited() {
        let r = record { $0.confidence = 0.3 }
        let rep = report(r, suitability: [SuitabilityFinding(kind: .kickerSmall, severity: .limiting, message: "Move closer.")])
        if case .technique = rep.summary { Issue.record("no score from a low-quality analysis") }
        let blocked = report(record(), suitability: [SuitabilityFinding(kind: .kickerTooSmall, severity: .blocking, message: "Too small.")])
        if case .technique = blocked.summary { Issue.record("a blocking recording finding caps the quality") }
        #expect(PerformanceReport.recordingTip(view: .side, suitability: [SuitabilityFinding(kind: .kickerSmall, severity: .limiting, message: "")])
            == "Record closer, keeping the entire kicker and football visible throughout the kick.")
    }

    // 10. Missing history and older analyses.
    @Test func olderAnalysesAndMissingHistory() {
        let rep = report(record(), others: [entry(30, overall: 90, engine: "pose-biomechanics-2.5.0"), entry(20, overall: nil)])
        #expect(rep.history?.previous == nil)
        #expect(rep.history?.message == PersonalRanking.historyWillPopulate)
        let r = record { $0.engineVersion = "pose-biomechanics-2.6.0" }
        #expect(report(r, others: [entry(3, overall: 60), entry(4, overall: 62)]).history?.standing.rank == nil)
        // An older analysis that issued plant-timing advice: never shown now.
        let legacy = record { r in
            let id = UUID()
            r.observations = [
                StoredObservationRecord(id: id, kind: .improve, category: .plant, message: "Plant foot landed only 0.04 s before estimated contact. A late plant…",
                                        severity: .moderate, confidence: 0.9, priority: 0, ruleKey: "plant.timingLate", relatedObservationID: nil,
                                        evidenceMetricKeys: ["plant.toContactTime"]),
                StoredObservationRecord(id: UUID(), kind: .cue, category: .plant, message: "Get the plant foot down a beat earlier.", severity: nil,
                                        confidence: 0.9, priority: 0, ruleKey: "plant.timingLate", relatedObservationID: id, evidenceMetricKeys: []),
            ]
        }
        #expect(report(legacy).improvements.isEmpty)
        #expect(report(legacy).insights.isEmpty)
    }

    // MARK: The side reference recording (stored device values)

    @Test func sideReferenceShowsApproachAndALimitedContactArea() throws {
        let rep = report(sideReference())
        guard case .limited = rep.summary else { Issue.record("2 rated areas: no overall score"); return }
        let approach = try #require(rep.areas.first { $0.category == .approach })
        let contact = try #require(rep.areas.first { $0.category == .contact })
        #expect(approach.score == 77 && approach.quality == .fair && !approach.isLimitedConfidence)
        #expect(contact.score == 97 && contact.isLimitedConfidence, "shown, but clearly limited")
        // Never the strongest mechanic just because its number is highest.
        #expect(rep.strongest?.title == "Approach")
        #expect(!rep.strengths.contains { $0.title.contains("Contact") })
        // The reason names the components that were in range — not the 46% variation.
        #expect(rep.strongest?.reason.lowercased().contains("approach speed") == true)
        #expect(rep.strongest?.reason.lowercased().contains("variation") == false)
        #expect(rep.noCorrectionText == PerformanceReport.noCorrection)
        #expect(Set(rep.unavailable.map(\.title)) == ["Plant", "Swing", "Follow-Through"])
        #expect(rep.unavailable.allSatisfy { $0.reason == "Too few reliable measurements in this recording" })
    }

    // MARK: Quick Report hygiene

    @Test func theQuickReportCarriesNoEngineIdentifiersOrDisclaimers() {
        for rep in [report(record()), report(sideReference()), report(rearReference(), view: .depth)] {
            var visible: [String] = [rep.header.kickTypeText, rep.header.outcomeText, rep.header.viewText, rep.summary.title, rep.comparisonText ?? "", rep.noCorrectionText ?? ""]
            visible += rep.areas.map(\.title) + rep.measurements.flatMap { [$0.name, $0.valueText, $0.personalText ?? ""] }
            visible += rep.strengths.flatMap { [$0.title, $0.reason] } + rep.improvements.flatMap { [$0.title, $0.observed, $0.cue] }
            visible += rep.unavailable.flatMap { [$0.title, $0.reason] } + [rep.focus?.line ?? ""]
            #expect(!visible.contains { $0.contains("pose-biomechanics") || $0.contains("provisional-bands") || $0.contains("percentile") })
            #expect(rep.methodology.contains { $0.contains("pose-biomechanics") }, "kept in Detailed Analysis")
        }
    }

    @Test func outcomeIsAtTheTopAndSeparateFromTechnique() {
        let a = report(record(), outcome: "Made · 40 yd"), b = report(record(), outcome: "Missed left"), c = report(record())
        #expect(a.summary == b.summary, "the result never changes the technique score")
        #expect(c.header.outcomeText == "Outcome not recorded" && !c.header.outcomeRecorded)
    }

    @Test func userAssistedIsLabelled() {
        let r = record { $0.engineVersion = PoseVideoAnalysisService.version + "+assisted" }
        #expect(report(r).header.state == .userAssisted)
    }

    @Test func scoresUseDocumentedBands() {
        #expect(PerformanceReport.Label(score: 97.0) == .excellent)
        #expect(PerformanceReport.Label(score: 84.6) == .excellent)
        #expect(PerformanceReport.Label(score: 84.4) == .good)
        #expect(PerformanceReport.Label(score: 50) == .developing)
        #expect(PerformanceReport.Label(score: 49.4) == .needsWork)
    }

    // MARK: Coaching insights

    @Test func improvementsRequireCredibleEvidence() {
        var slip = SyntheticPose.KickScript.fieldGoal
        slip.plantSlip = 0.075
        let r = record(slip)
        let rep = report(r)
        let i = rep.improvements.first
        #expect(i?.title == "Plant foot moved through the strike")
        #expect(rep.insights.first { $0.isImprovement }?.supportingMetricName == "Plant-foot movement")
        #expect(rep.insights.allSatisfy { !$0.eligibility.isEmpty && !$0.monitorMetricName.isEmpty })
        if case .practice(_, let cue, let monitor) = rep.focus {
            #expect(cue == i?.cue && monitor == "Plant-foot movement")
        } else { Issue.record("one practice priority") }
        // The same finding with a low-confidence measurement isn't shown.
        let weak = record(slip) { r in
            r.metrics = r.metrics.map { m in m.key == KickMetricKey.plantFootDrift.rawValue ? Self.metric(.plantFootDrift, m.value, 0.4) : m }
        }
        #expect(report(weak).improvements.isEmpty)
        // A side-view rule isn't applied to a rear-view recording.
        #expect(report(r, view: .depth).improvements.isEmpty)
    }

    @Test func insightClassesFollowMeasurementQuality() {
        let o = StoredObservationRecord(id: UUID(), kind: .keep, category: .swing, message: "Kicking leg was nearly fully extended at contact (170°). Full extension…",
                                        severity: nil, confidence: 0.9, priority: 0, ruleKey: "swing.fullKneeExtension", relatedObservationID: nil,
                                        evidenceMetricKeys: ["swing.kickingKneeAngleAtContact"])
        func insights(_ c: Double, _ type: KickType = .fieldGoal) -> [CoachingInsight] {
            let rows = AnalysisPresentationBuilder.metricRows([Self.metric(.kickingKneeAngleAtContact, 170, c)])
            return CoachingInsightBuilder.make(observations: [o], metrics: rows, kickType: type, view: .side)
        }
        #expect(insights(0.8).first?.insightClass == .confirmedObservation)
        #expect(insights(0.6).first?.insightClass == .provisionalObservation)
        #expect(insights(0.4).isEmpty, "insufficient evidence is never shown")
        #expect(CoachingInsightBuilder.catalog[.torsoLeaningBack]?.kickTypes.contains(.punt) == false, "place-kick torso rule not applied to punts")
        #expect(CoachingInsightBuilder.catalog[.plantLate] == nil && CoachingInsightBuilder.catalog[.plantEarly] == nil)
    }

    @Test func kickGoalsDiffer() {
        #expect(KickGoal(.fieldGoal).priorityAreas.first == .plant)
        #expect(KickGoal(.kickoff).priorityAreas.first == .approach)
        #expect(KickGoal(.punt).priorityAreas.first == .swing)
        #expect(KickGoal(.pat) == .placeKickAccuracy)
    }

    // MARK: Consistency and improvement

    @Test func aMetricIsCalledImprovingOnlyWithEnoughConsistentEvidence() {
        let r = record()
        let drift = { (v: Double, d: Double) in entry(d, overall: nil, metrics: [.plantFootDrift: v]) }
        // Six kicks (Build 19 minimum) with plant drift steadily falling (lower is better) → improving.
        let falling = [drift(0.34, 10), drift(0.30, 9), drift(0.26, 8), drift(0.21, 7), drift(0.15, 6)]
        let current = { (v: Double) -> AnalysisRecord in
            self.record { rr in
                rr.metrics = rr.metrics.map { m in m.key == KickMetricKey.plantFootDrift.rawValue ? Self.metric(.plantFootDrift, v, 0.8) : m }
            }
        }
        let improving = report(current(0.08), others: falling).consistency?.improving
        #expect(improving?.key == .plantFootDrift)
        // Only five values → too few.
        #expect(report(current(0.08), others: Array(falling.suffix(4))).consistency?.improving == nil)
        // Noisy values → no claim.
        let noisy = [drift(0.10, 9), drift(0.30, 8), drift(0.12, 7), drift(0.28, 6)]
        #expect(report(current(0.11), others: noisy).consistency?.improving == nil)
        // A descriptive metric (no better direction) is never called improving.
        let timing = (0..<5).map { entry(Double(9 - $0), overall: nil, metrics: [.plantToContactTime: 0.3 - 0.04 * Double($0)]) }
        #expect(report(r, others: timing).consistency?.improving?.key != .plantToContactTime)
    }

    @Test func sameSessionConsistencyIsSeparateFromLongTerm() {
        let session = UUID()
        let r = record { $0.overallScore = 78 }
        let others = [entry(0.01, overall: 70, session: session), entry(0.02, overall: 74, session: session), entry(40, overall: 50)]
        let c = report(r, others: others, session: session).consistency
        #expect(c?.session?.kicks == 3)
        #expect(c?.session?.text.contains("70–78") == true)
    }

    // MARK: Detailed Analysis

    @Test func detailedAnalysisIsOrganizedByPhase() {
        let r = rearReference()
        let p = AnalysisPresentationBuilder.make(r)
        let rep = report(r, view: .depth)
        let d = DetailedAnalysisReport.make(report: rep, presentation: p, view: .depth, kickType: .fieldGoal, contactLines: ["Contact event: High"],
                                            followThroughNote: "Kicking foot not tracked after contact (lost after 0.03 s)")
        #expect(d.phases.map(\.title) == ["Approach", "Plant", "Swing", "Body Position at Contact", "Follow-through"])
        let plant = d.phases.first { $0.title == "Plant" }
        #expect(plant?.metrics.contains { $0.key == .plantBallLateralOffset } == true)
        let approach = d.phases.first { $0.title == "Approach" }
        #expect(approach?.unavailable.last?.reason == "Not measurable from this view")
        #expect(d.methodology.contains(PerformanceReport.Label.criteria))
        // Every available metric appears in exactly one phase section.
        let shown = d.phases.flatMap { $0.metrics.map(\.key) }
        #expect(shown.count == Set(shown).count)
    }
}
