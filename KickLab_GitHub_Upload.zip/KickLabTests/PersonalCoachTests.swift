import Foundation
import Testing
@testable import KickLab

@Suite("Step 10 personalized coach")
struct PersonalCoachTests {
    typealias F = PersonalFixture

    static let leanForward = GeneralRuleFinding(
        ruleKey: CoachingRuleKey.torsoLeaningForward.rawValue, kind: .improve, category: .contact, metric: .torsoLeanAtContact,
        observed: "Torso was leaning forward 18° at estimated contact.",
        whyItMatters: "Leaning far forward crowds the swing and can drive the ball low.",
        cue: "Stay tall through the ball: chest up, eyes on the ball.", severity: .low, confidence: 0.8
    )

    /// 10 made field goals that all lean forward ~18° (outside the general band).
    static var forwardLeaningMakes: [HistoricalKickAnalysis] {
        F.series(.torsoLeanAtContact, [17, 18, 19, 18, 17, 19, 18, 18, 17, 19])
    }

    // MARK: Maturity

    @Test func noPersonalClaimsWithoutEnoughKicks() throws {
        let history = F.series(.plantToContactTime, [0.19, 0.2])
        let report = try F.report(current: F.current([.plantToContactTime: 0.35, .torsoLeanAtContact: 18]), history: history,
                                  general: [Self.leanForward])
        #expect(report.maturity == .insufficient)
        #expect(report.comparableKickCount == 2)
        #expect(report.learningMessage == "KickLab is still learning your mechanics. Record 6 more comparable kicks to improve personalized coaching.")
        #expect(report.findings.allSatisfy { $0.sources == [.generalRule] }, "only the Step 8 rule speaks")
        #expect(report.primaryFixes.map(\.generalRuleKey) == [Self.leanForward.ruleKey])
        #expect(report.primaryFixes.first?.resolution == .generalOnly)

        let empty = try F.report(current: F.current([.plantToContactTime: 0.2]), history: [])
        #expect(empty.learningMessage == "KickLab is still learning your mechanics. Record 8 more comparable kicks to improve personalized coaching.")
        #expect(empty.findings.isEmpty)

        let seven = try F.report(current: F.current([.plantToContactTime: 0.2]), history: F.series(.plantToContactTime, Array(repeating: 0.2, count: 7)))
        #expect(seven.learningMessage == "KickLab is still learning your mechanics. Record 1 more comparable kick to improve personalized coaching.")
        let eight = try F.report(current: F.current([.plantToContactTime: 0.2]), history: F.series(.plantToContactTime, Array(repeating: 0.2, count: 8)))
        #expect(eight.learningMessage == nil)
        #expect(eight.maturity == .established)
    }

    // MARK: Deviation from the successful pattern

    @Test func currentKickDeviationFromSuccessfulPattern() throws {
        // Build 18 (personal-coach-1.1): plant timing is compared with the athlete's own
        // successful kicks, but no fix or cue is given — no validated criterion says which
        // interval is better.
        let history = F.series(.plantToContactTime, [0.18, 0.19, 0.20, 0.19, 0.18, 0.20, 0.19, 0.19, 0.18, 0.20])
        let report = try F.report(current: F.current([.plantToContactTime: 0.27]), history: history)
        #expect(report.primaryFixes.isEmpty)
        #expect(!report.findings.contains { $0.metric == .plantToContactTime && $0.kind == .fix })
        #expect(report.findings.filter { $0.metric == .plantToContactTime }.allSatisfy { $0.cue == nil })

        let inside = try F.report(current: F.current([.plantToContactTime: 0.19]), history: history)
        #expect(inside.primaryFixes.isEmpty)
        #expect(inside.strengths.first?.metric == .plantToContactTime)
        #expect(inside.strengths.first?.headline == "Your plant timing has stayed within your successful range on 10 of your last 10 kicks.")
    }

    /// The Step 10 deviation machinery, on a two-sided metric that is still coachable.
    @Test func deviationFromTheSuccessfulPatternOnACoachableMetric() throws {
        let history = F.series(.followThroughDuration, [0.18, 0.19, 0.20, 0.19, 0.18, 0.20, 0.19, 0.19, 0.18, 0.20])
        let report = try F.report(current: F.current([.followThroughDuration: 0.27]), history: history)
        let fix = try #require(report.primaryFixes.first)
        #expect(fix.metric == .followThroughDuration)
        #expect(fix.headline == "Your follow-through lasted a little longer compared with your best kicks.")
        #expect(fix.detail == "Your best 10 field goals averaged 0.19 s; this kick was 0.27 s.")
        #expect(fix.cue == "Finish with the same controlled follow-through as your best kicks.")
        #expect(fix.sources == [.successfulPattern])
        #expect(fix.resolution == .personalOnly)
        #expect(fix.numbers?.thisKick == 0.27)
        #expect(near(fix.numbers?.successfulMedian, 0.19, 1e-12))
        // The follow-through's minimum spread (its measurement floor) widens the range to ±0.02 s.
        #expect(near(fix.numbers?.successfulLow, 0.17, 1e-12))
        #expect(near(fix.numbers?.successfulHigh, 0.21, 1e-12))
        #expect(fix.numbers?.generalIdealLow == 0.15)
        // z = (0.27 − 0.19) ÷ 0.04; strong pattern (10 ≥ 8) → full weight.
        #expect(near(fix.priority.personalDeviation, 8 * 0.08 / 0.04, 1e-9))
        #expect(fix.priority.maturity == 6)
        #expect(near(fix.priority.confidence, 8, 1e-12))
        #expect(fix.confidence == PersonalizationConfidence.personal(measurement: 0.8, maturity: .established))
        #expect(fix.confidenceLevel == .medium)

        let inside = try F.report(current: F.current([.followThroughDuration: 0.19]), history: history)
        #expect(inside.primaryFixes.isEmpty)
        #expect(inside.strengths.first?.headline == "Your follow-through has stayed within your successful range on 10 of your last 10 kicks.")
    }

    @Test func betterInAOneWayMetricIsNeverAFault() throws {
        // Plant-foot movement: lower is better. A much stiller plant than usual is not a fix.
        let history = F.series(.plantFootDrift, [0.10, 0.11, 0.12, 0.10, 0.11, 0.12, 0.10, 0.11, 0.12, 0.11])
        let report = try F.report(current: F.current([.plantFootDrift: 0.01]), history: history)
        #expect(report.findings.allSatisfy { $0.kind != .fix })
    }

    @Test func differentFromNormalIsNotBad() throws {
        // No outcomes logged: only the normal is known. Within the general band, a change is an insight, not a fix.
        let history = (0..<10).map { F.kick($0, result: nil, values: [.followThroughDuration: 0.18 + 0.002 * Double($0 % 3)]) }
        let report = try F.report(current: F.current([.followThroughDuration: 0.26]), history: history)
        let insight = try #require(report.findings.first { $0.metric == .followThroughDuration && $0.kind == .insight })
        #expect(insight.role == .secondary)
        #expect(insight.headline == "Your follow-through lasted a little longer compared with your normal.")
        #expect(insight.cue == nil)
        #expect(report.primaryFixes.isEmpty)

        // Outside the general band and further from it than normal → a (personal) fix.
        let away = try F.report(current: F.current([.followThroughDuration: 0.60]), history: history)
        let fix = try #require(away.findings.first { $0.metric == .followThroughDuration && $0.kind == .fix })
        #expect(fix.sources == [.personalBaseline])
        #expect(fix.headline == "Your follow-through lasted noticeably longer compared with your normal.")

        // Build 18: plant timing, even far from normal, is never turned into a fix.
        let plant = (0..<10).map { F.kick($0, result: nil, values: [.plantToContactTime: 0.12 + 0.002 * Double($0 % 3)]) }
        let plantAway = try F.report(current: F.current([.plantToContactTime: 0.40]), history: plant)
        #expect(!plantAway.findings.contains { $0.metric == .plantToContactTime && $0.kind == .fix })
    }

    // MARK: Repetition is not success

    @Test func aRepeatedMechanicAssociatedWithMissesIsNotIdeal() throws {
        // The athlete usually leans back ~20° — on misses. Makes lean back only ~5°.
        let misses = [-22.0, -21, -20, -19, -18, -20, -21, -19]
        let makes = [-6.0, -5, -4, -5, -5]
        let history = F.series(.torsoLeanAtContact, misses + makes,
                               results: Array(repeating: .missedLeft, count: 8) + Array(repeating: .made, count: 5))
        let profile = try F.profile(history)
        let b = try #require(profile.baseline(.torsoLeanAtContact))
        #expect(b.lifetime.median == -19, "repetition makes ~-19° the athlete's normal…")
        #expect(near(b.successfulPattern?.successful.median, -5, 1e-12), "…but not the successful pattern")

        let report = try F.report(current: F.current([.torsoLeanAtContact: -20]), history: history)
        let fix = try #require(report.primaryFixes.first)
        #expect(fix.metric == .torsoLeanAtContact)
        #expect(fix.sources == [.successfulPattern, .outcomeRelationship])
        #expect(fix.headline == "You were leaning noticeably further back at contact compared with your best kicks.")
        #expect(fix.cue == "Keep your chest over the ball at contact.")
        #expect(fix.evidence[1].summary == "In your recorded kicks, torso lean at contact tends to be -5° on your makes and -20° on your misses. This kick was closer to your misses.")
        #expect(report.strengths.allSatisfy { $0.metric != .torsoLeanAtContact }, "never praised for matching the habit")
        // Scores: deviation 15 (25 × 0.6, pattern not yet strong), outcome 20 (capped), confidence 8, maturity 6.
        #expect(fix.priority.personalDeviation == 15)
        #expect(fix.priority.outcome == 20)
        #expect(fix.priority.total == 49)
    }

    // MARK: Conflict resolution

    @Test func strongSuccessfulPatternDeEmphasizesAWeakGenericWarning() throws {
        let report = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: Self.forwardLeaningMakes, general: [Self.leanForward])
        let finding = try #require(report.findings.first { $0.generalRuleKey == Self.leanForward.ruleKey })
        #expect(finding.resolution == .deEmphasizedBySuccessfulPattern)
        #expect(finding.role == .secondary, "kept and explainable, not promoted")
        #expect(finding.rationale == "Outside the general target range, but consistent with your successful kicks, so it isn't a priority right now.")
        #expect(finding.priority.multiplier == 0.35)
        #expect(finding.sources == [.generalRule, .successfulPattern])
        #expect(finding.headline == Self.leanForward.observed, "the Step 8 observation is never dropped")
        #expect(report.primaryFixes.isEmpty)
    }

    @Test func strongGeneralWarningsStay() throws {
        var high = Self.leanForward
        high.severity = .high
        // Weak personal evidence: Step 8 stays primary.
        let weak = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: Array(Self.forwardLeaningMakes.prefix(2)), general: [high])
        #expect(weak.primaryFixes.first?.resolution == .generalOnly)
        #expect(weak.primaryFixes.first?.priority.ruleSeverity == 30)
        #expect(weak.primaryFixes.first?.cue == high.cue)

        // A low-severity rule with weak personal evidence is still primary (Step 8 remains primary).
        let weakLow = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: Array(Self.forwardLeaningMakes.prefix(2)),
                                   general: [Self.leanForward])
        #expect(weakLow.primaryFixes.count == 1)

        // A high-severity rule that matches the successful pattern is kept, slightly lowered.
        let strong = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: Self.forwardLeaningMakes, general: [high])
        let kept = try #require(strong.primaryFixes.first)
        #expect(kept.resolution == .keptDespiteSuccessfulPattern)
        #expect(kept.priority.multiplier == 0.75)
    }

    @Test func generalWarningPlusPoorOutcomesIsElevated() throws {
        // Makes lean ~0°, misses lean forward ~20°; the current kick leans forward 20°.
        let history = F.series(.torsoLeanAtContact, [0, 1, -1, 0, 1, 20, 21, 19, 20, 22],
                               results: Array(repeating: .made, count: 5) + Array(repeating: .missedRight, count: 5))
        var rule = Self.leanForward
        rule.severity = .moderate
        let report = try F.report(current: F.current([.torsoLeanAtContact: 20]), history: history, general: [rule])
        let fix = try #require(report.primaryFixes.first)
        #expect(fix.resolution == .elevatedByOutcomes)
        #expect(fix.sources.first == .generalRule)
        #expect(fix.sources.contains(.outcomeRelationship))
        #expect(fix.priority.outcome > 0)
        #expect(fix.cue == rule.cue, "the Step 8 cue is kept")
        #expect(fix.headline.hasSuffix("— closer to your misses than your makes.") || fix.headline.hasSuffix("compared with your best kicks."))
    }

    // MARK: Consistency

    @Test func consistencyFindings() throws {
        let previous = Array(repeating: [0.19, 0.21], count: 10).flatMap { $0 }
        let recent = Array(repeating: [0.12, 0.28], count: 5).flatMap { $0 }
        let history = (previous + recent).enumerated().map { i, v in F.kick(i, result: nil, values: [.followThroughDuration: v]) }
        let report = try F.report(current: F.current([.followThroughDuration: 0.2]), history: history)
        let finding = try #require(report.findings.first { $0.id == DeterministicID.make(seed: F.analysisID, name: "personal|consistency|followThrough.duration") })
        #expect(finding.headline == "Your follow-through has varied more over your last 10 kicks than over your previous 20.")
        #expect(finding.cue == "Finish the same way every time, through the target.")
        // Build 18: plant timing gets no consistency fix (no validated criterion).
        let plantHistory = (previous + recent).enumerated().map { i, v in F.kick(i, result: nil, values: [.plantToContactTime: v]) }
        let plant = try F.report(current: F.current([.plantToContactTime: 0.2]), history: plantHistory)
        #expect(!plant.findings.contains { $0.metric == .plantToContactTime && $0.kind == .fix })
        #expect(finding.sources == [.consistency])

        let steady = (0..<10).map { F.kick($0, values: [.plantToContactTime: [0.19, 0.20, 0.21][$0 % 3]]) }
        let good = try F.report(current: F.current([.plantToContactTime: 0.2]), history: steady)
        let strength = try #require(good.strengths.first)
        #expect(strength.sources.contains(.consistency))
        #expect(strength.sources.contains(.successfulPattern))
    }

    // MARK: Determinism, ranking, wording

    @Test func reportsAreDeterministic() throws {
        let history = F.series(.followThroughDuration, [0.18, 0.19, 0.20, 0.19, 0.18, 0.20, 0.19, 0.19, 0.18, 0.20])
            + (20..<30).map { F.kick($0, values: [.torsoLeanAtContact: 18]) }
        let current = F.current([.followThroughDuration: 0.27, .torsoLeanAtContact: 18])
        let a = try F.report(current: current, history: history, general: [Self.leanForward])
        let b = try F.report(current: current, history: history.reversed(), general: [Self.leanForward])
        #expect(a == b)
        #expect(try AnalysisArtifactCoder.encode(TestArtifact(report: a)) == AnalysisArtifactCoder.encode(TestArtifact(report: b)))
        let fix = try #require(a.findings.first { $0.metric == .followThroughDuration && $0.kind == .fix })
        #expect(fix.id == DeterministicID.make(seed: F.analysisID, name: "personal|fix|followThrough.duration"))
        // Ranked: primary fixes, then strengths, then secondary; scores never increase within a role.
        let roles = a.findings.map(\.role)
        #expect(roles == roles.sorted { order($0) < order($1) })
        for role in [PersonalFindingRole.primaryFix, .strength, .secondary] {
            let totals = a.findings.filter { $0.role == role }.map(\.priority.total)
            #expect(totals == totals.sorted(by: >))
        }
        #expect(a.primaryFixes.count <= 3)
        #expect(a.strengths.count <= 2)
    }

    private func order(_ role: PersonalFindingRole) -> Int {
        switch role {
        case .primaryFix: 0
        case .strength: 1
        case .secondary: 2
        }
    }

    @Test func primaryListIsCapped() throws {
        var config = PersonalizationConfiguration()
        config.maximumPrimaryFixes = 1
        let general = [
            Self.leanForward,
            GeneralRuleFinding(ruleKey: CoachingRuleKey.plantUnstable.rawValue, kind: .improve, category: .plant, metric: .plantFootDrift,
                               observed: "Plant foot moved 0.45 body lengths around estimated contact.", severity: .high, confidence: 0.9),
        ]
        let report = try F.report(current: F.current([.torsoLeanAtContact: 18, .plantFootDrift: 0.45]), history: [], general: general, configuration: config)
        #expect(report.primaryFixes.map(\.generalRuleKey) == [CoachingRuleKey.plantUnstable.rawValue], "high severity first")
        #expect(report.secondary.count == 1)
        #expect(report.findings.count == 2, "nothing from Step 8 is dropped")
    }

    @Test func cameraAngleMismatchMakesComparisonUnavailable() throws {
        let history = (0..<10).map { F.kick($0, values: [.torsoLeanAtContact: -5, .plantToContactTime: 0.2], angle: .rear) }
        let report = try F.report(current: F.current([.torsoLeanAtContact: 15, .plantToContactTime: 0.2], angle: .side), history: history)
        #expect(report.unavailableComparisons == [UnavailableComparison(metric: .torsoLeanAtContact, reason: .differentCameraAngle)])
        #expect(report.findings.allSatisfy { $0.metric != .torsoLeanAtContact }, "no lean comparison across camera angles")
        #expect(report.comparableKickCount == 10, "timing is still comparable")
    }

    @Test func wordingIsAssociationNotCausation() throws {
        let history = F.series(.torsoLeanAtContact, [-22, -21, -20, -19, -18, -20, -21, -19, -6, -5, -4, -5, -5],
                               results: Array(repeating: .missedLeft, count: 8) + Array(repeating: .made, count: 5))
            + F.series(.plantToContactTime, [0.19, 0.21, 0.19, 0.21, 0.19, 0.21, 0.19, 0.21, 0.19, 0.21, 0.12, 0.28, 0.12, 0.28, 0.12, 0.28], firstIndex: 20)
        let report = try F.report(current: F.current([.torsoLeanAtContact: -20, .plantToContactTime: 0.3]), history: history,
                                  general: [Self.leanForward])
        var pieces: [String] = []
        for finding in report.findings {
            pieces += [finding.headline, finding.detail ?? "", finding.cue ?? "", finding.rationale]
            pieces += finding.evidence.map(\.summary)
        }
        let text: String = pieces.joined(separator: " ").lowercased()
        let ids = KickMetricKey.allCases.map(\.rawValue) + CoachingRuleKey.allCases.map(\.rawValue)
        let bannedWords = ["cause", "guarantee", "will make", "injur", "diagnos", "unsafe", "metric", "neural", "machine learning"]
            + ids.map { $0.lowercased() }
        for banned in bannedWords {
            #expect(!text.contains(banned), "found \"\(banned)\"")
        }
    }

    @Test func conflictingDirectionsKeepTheGeneralCue() throws {
        // Step 8: leaning forward 18° (too far forward). Personal: best kicks lean forward ~25°,
        // so personally this kick leans "further back". Two opposite cues would confuse: Step 8 stays.
        let history = F.series(.torsoLeanAtContact, [24, 25, 26, 25, 24, 26, 25, 25, 24, 26])
        let report = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: history, general: [Self.leanForward])
        let finding = try #require(report.findings.first { $0.generalRuleKey == Self.leanForward.ruleKey })
        #expect(finding.resolution == .generalKept)
        #expect(finding.cue == Self.leanForward.cue)
        #expect(finding.sources == [.generalRule])
        #expect(finding.rationale == PersonalCoachCopy.conflictingDirectionRationale)
        let leanFixes = report.findings.filter { (f: PersonalCoachingFinding) -> Bool in f.metric == .torsoLeanAtContact && f.kind == .fix }
        #expect(leanFixes.count == 1)
    }

    // MARK: Artifact

    @Test func personalizationArtifactRoundTripsAndRejectsNewerVersions() throws {
        let history = F.series(.plantToContactTime, [0.18, 0.19, 0.20, 0.19, 0.18, 0.20, 0.19, 0.19, 0.18, 0.20])
        let current = F.current([.plantToContactTime: 0.27])
        let (report, selection) = try PersonalCoachingEngine.report(analysisID: F.analysisID, current: current, history: history,
                                                                    generalFindings: [], epoch: nil, now: F.date(100))
        let artifact = PersonalizationArtifact(analysisID: F.analysisID, kickID: current.kickID, createdAt: F.date(100),
                                               modelVersion: StatisticalAthleteLearningModel.version,
                                               configuration: PersonalizationConfiguration(), current: current,
                                               selection: selection, report: report)
        let data = try AnalysisArtifactCoder.encode(artifact)
        #expect(try AnalysisArtifactCoder.decode(PersonalizationArtifact.self, from: data) == artifact)
        #expect(artifact.profile?.eligibleKickCount == 10)

        // In an analysis folder: written next to the Step 7/8 files, read back, absent → nil.
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent("kl-personal-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: temp) }
        try FileManager.default.createDirectory(at: temp, withIntermediateDirectories: true)
        let store = AnalysisArtifactStore(analysisRootURL: temp)
        #expect(try store.readPersonalization(in: "older-analysis") == nil, "Step 7/8 analyses have no personalization file")
        try store.writePersonalization(artifact, in: "abc")
        #expect(try store.readPersonalization(in: "abc") == artifact)
        #expect(throws: AnalysisArtifactError.invalidPath("../escape")) { try store.readPersonalization(in: "../escape") }

        // A newer format is refused, not misread.
        var json = try #require(String(data: data, encoding: .utf8))
        json = json.replacingOccurrences(of: "\"formatVersion\":1", with: "\"formatVersion\":2")
        #expect(throws: AnalysisArtifactError.unsupportedFormatVersion(kind: PersonalizationArtifact.kind, version: 2, supported: 1)) {
            try AnalysisArtifactCoder.decode(PersonalizationArtifact.self, from: Data(json.utf8))
        }
        #expect(throws: AnalysisArtifactError.wrongKind(expected: PersonalizationArtifact.kind, found: BiomechanicsArtifact.kind)) {
            try AnalysisArtifactCoder.decode(PersonalizationArtifact.self, from: Data(#"{"kind":"kicklab.biomechanics","formatVersion":1}"#.utf8))
        }
    }
}

/// Wraps a report so it can be encoded with the artifact coder's settings.
private struct TestArtifact: VersionedArtifact {
    static let kind = "test.report"
    static let currentFormatVersion = 1
    var kind: String = TestArtifact.kind
    var formatVersion: Int = 1
    var report: PersonalizedCoachingReport
}
