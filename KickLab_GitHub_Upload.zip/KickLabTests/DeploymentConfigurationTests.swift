import Foundation
import Testing
@testable import KickLab

/// Locates the project's source tree from this file (works on Linux and in the Simulator,
/// which can read the Mac's files).
enum RepositoryFiles {
    static func root(file: String = #filePath) -> URL? {
        var url = URL(fileURLWithPath: file).resolvingSymlinksInPath().deletingLastPathComponent()
        for _ in 0..<6 {
            if FileManager.default.fileExists(atPath: url.appendingPathComponent("project.yml").path) { return url }
            url = url.deletingLastPathComponent()
        }
        return nil
    }

    static func text(_ relativePath: String) throws -> String {
        let base = try #require(Self.root(), "project source tree not found")
        return try String(contentsOf: base.appendingPathComponent(relativePath), encoding: .utf8)
    }

    static func data(_ relativePath: String) throws -> Data {
        let base = try #require(Self.root(), "project source tree not found")
        return try Data(contentsOf: base.appendingPathComponent(relativePath))
    }

    static func exists(_ relativePath: String) -> Bool {
        guard let base = Self.root() else { return false }
        return FileManager.default.fileExists(atPath: base.appendingPathComponent(relativePath).path)
    }
}

@Suite("Step 11 deployment configuration")
struct DeploymentConfigurationTests {
    /// The KickLab app target's section of project.yml.
    private func appTargetSettings() throws -> String {
        let yml = try RepositoryFiles.text("project.yml")
        let start = try #require(yml.range(of: "  KickLab:\n"))
        let end = try #require(yml.range(of: "  KickLabTests:\n"))
        return String(yml[start.upperBound..<end.lowerBound])
    }

    @Test func appIdentityAndVersioning() throws {
        let app = try appTargetSettings()
        #expect(app.contains("PRODUCT_BUNDLE_IDENTIFIER: com.kicklab.app\n"))
        #expect(app.contains("MARKETING_VERSION: \"0.1.0\""))
        #expect(app.contains("CURRENT_PROJECT_VERSION: \"1\""), "the TestFlight workflow overrides the build number per upload")
        #expect(app.contains("TARGETED_DEVICE_FAMILY: \"1\""), "iPhone-only first beta")
        #expect(app.contains("INFOPLIST_KEY_CFBundleDisplayName: KickLab"))
        #expect(app.contains("INFOPLIST_KEY_LSApplicationCategoryType: public.app-category.sports"))
        #expect(app.contains("ASSETCATALOG_COMPILER_APPICON_NAME: AppIcon"))
        #expect(app.contains("INFOPLIST_FILE: KickLab/Resources/Info.plist"))
        let yml = try RepositoryFiles.text("project.yml")
        #expect(yml.contains("IPHONEOS_DEPLOYMENT_TARGET: \"18.0\""), "SwiftData features used need iOS 18")
        // Ordinary builds stay unsigned so the test workflow needs no credentials.
        #expect(yml.contains("DEVELOPMENT_TEAM: \"\""))
        #expect(yml.contains("CODE_SIGN_IDENTITY: \"\""))
    }

    @Test func exportComplianceAndOnlyCapturePermissions() throws {
        let data = try RepositoryFiles.data("KickLab/Resources/Info.plist")
        let plist = try #require(try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any])
        #expect(plist["ITSAppUsesNonExemptEncryption"] as? Bool == false)
        let yml = try RepositoryFiles.text("project.yml")
        // Build 21 records with the camera (sound only if switched on; Photos add-only for
        // an optional copy). Imports still use the system pickers, so the photo library is
        // never read, and location is never requested. Purpose strings live in Info.plist only.
        // Build 24: Remote Cameras use the local network (Bonjour), declared here.
        #expect(plist["NSBonjourServices"] as? [String] == [RemoteCapture.bonjourType])
        for key in ["NSCameraUsageDescription", "NSMicrophoneUsageDescription", "NSPhotoLibraryAddUsageDescription", "NSLocalNetworkUsageDescription"] {
            #expect((plist[key] as? String)?.isEmpty == false, "\(key) purpose string in Info.plist")
            #expect(!yml.contains(key), "\(key) in project.yml")
        }
        for key in ["NSPhotoLibraryUsageDescription", "NSLocationWhenInUseUsageDescription"] {
            #expect(plist[key] == nil, "\(key) in Info.plist")
            #expect(!yml.contains(key), "\(key) in project.yml")
        }
    }

    @Test func privacyManifestDeclaresWhatTheCodeUses() throws {
        let data = try RepositoryFiles.data("KickLab/Resources/PrivacyInfo.xcprivacy")
        let plist = try #require(try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any])
        #expect(plist["NSPrivacyTracking"] as? Bool == false)
        #expect((plist["NSPrivacyTrackingDomains"] as? [Any])?.isEmpty == true)
        #expect((plist["NSPrivacyCollectedDataTypes"] as? [Any])?.isEmpty == true, "no data leaves the iPhone")
        let accessed = try #require(plist["NSPrivacyAccessedAPITypes"] as? [[String: Any]])
        var reasons: [String: [String]] = [:]
        for entry in accessed {
            if let type = entry["NSPrivacyAccessedAPIType"] as? String {
                reasons[type] = entry["NSPrivacyAccessedAPITypeReasons"] as? [String]
            }
        }
        #expect(reasons["NSPrivacyAccessedAPICategoryUserDefaults"] == ["CA92.1"])
        #expect(reasons["NSPrivacyAccessedAPICategoryFileTimestamp"] == ["C617.1"])
        #expect(reasons["NSPrivacyAccessedAPICategoryDiskSpace"] == ["E174.1"])
    }

    @Test func appIconIsAnOpaque1024PNG() throws {
        let base = "KickLab/Resources/Assets.xcassets/AppIcon.appiconset/"
        let contents = try RepositoryFiles.data(base + "Contents.json")
        let json = try #require(try JSONSerialization.jsonObject(with: contents) as? [String: Any])
        let images = try #require(json["images"] as? [[String: Any]])
        let icon = try #require(images.first)
        #expect(icon["size"] as? String == "1024x1024")
        #expect(icon["platform"] as? String == "ios")
        let file = try #require(icon["filename"] as? String)
        let png = [UInt8](try RepositoryFiles.data(base + file))
        #expect(Array(png.prefix(8)) == [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], "a PNG file")
        func uint32(_ offset: Int) -> Int { png[offset..<offset + 4].reduce(0) { $0 << 8 | Int($1) } }
        #expect(uint32(16) == 1024)
        #expect(uint32(20) == 1024)
        #expect(png[25] == 2, "RGB with no alpha channel (App Store icons must be opaque)")
    }

    @Test func deploymentWorkflowIsManualAndComplete() throws {
        let workflow = try RepositoryFiles.text("Deployment/ios-testflight.yml")
        #expect(workflow.contains("\non:\n  workflow_dispatch:"), "started manually only")
        #expect(!workflow.contains("\n  push:"))
        #expect(!workflow.contains("\n  pull_request:"))
        #expect(workflow.contains("permissions:\n  contents: read"))
        for script in ["validate-config.sh", "check-project-identity.sh", "build-number.sh", "prepare-signing.sh",
                       "archive.sh", "export.sh", "verify-ipa.sh", "upload.sh", "cleanup-signing.sh"] {
            #expect(workflow.contains("Scripts/testflight/\(script)"), "\(script) is used")
            #expect(RepositoryFiles.exists("Scripts/testflight/\(script)"), "\(script) exists")
        }
        let cleanup = try #require(workflow.range(of: "- name: Clean up signing material\n        if: always()"))
        let upload = try #require(workflow.range(of: "- name: Upload to TestFlight"))
        #expect(upload.lowerBound < cleanup.lowerBound, "cleanup runs after the upload, always")
        #expect(!workflow.contains("set -x"), "commands are never traced")
        // Once installed, the GitHub copy should match the reference copy.
        // (Line endings and trailing spaces may change when pasted into GitHub's editor.)
        if RepositoryFiles.exists(".github/workflows/ios-testflight.yml") {
            func normalized(_ text: String) -> [String] {
                text.replacingOccurrences(of: "\r\n", with: "\n").split(separator: "\n", omittingEmptySubsequences: false)
                    .map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            }
            let installed = try RepositoryFiles.text(".github/workflows/ios-testflight.yml")
            #expect(normalized(installed) == normalized(workflow), "installed workflow differs from Deployment/ios-testflight.yml")
        }
    }

    @Test func testWorkflowNeedsNoSigningCredentials() throws {
        let script = try RepositoryFiles.text("Scripts/test-ios.sh")
        #expect(script.contains("CODE_SIGNING_ALLOWED=NO"))
        if RepositoryFiles.exists(".github/workflows/ios-tests.yml") {
            let workflow = try RepositoryFiles.text(".github/workflows/ios-tests.yml")
            #expect(!workflow.contains("secrets."), "the test workflow uses no secrets")
        }
    }

    @Test func archiveAndExportUseDistributionSettings() throws {
        let archive = try RepositoryFiles.text("Scripts/testflight/archive.sh")
        #expect(archive.contains("-configuration Release"))
        #expect(archive.contains("generic/platform=iOS"))
        #expect(archive.contains("CURRENT_PROJECT_VERSION=\"$KICKLAB_BUILD_NUMBER\""))
        let options = try RepositoryFiles.text("Scripts/testflight/make-export-options.sh")
        #expect(options.contains("<string>app-store-connect</string>"))
        #expect(options.contains("<string>Apple Distribution</string>"))
        let export = try RepositoryFiles.text("Scripts/testflight/export.sh")
        #expect(export.contains("-allowProvisioningUpdates"))
        let upload = try RepositoryFiles.text("Scripts/testflight/upload.sh")
        #expect(upload.contains("altool --validate-app"))
        #expect(upload.contains("altool --upload-app"))
        #expect(upload.contains("--apiKey"), "API-key authentication, no Apple ID password")
    }

    @Test func noCredentialsAreCommitted() throws {
        let root = try #require(RepositoryFiles.root())
        let forbidden = ["p8", "p12", "mobileprovision", "cer", "keychain", "keychain-db", "certSigningRequest"]
        let walker = FileManager.default.enumerator(at: root, includingPropertiesForKeys: nil)
        var found: [String] = []
        while let url = walker?.nextObject() as? URL {
            let path = url.path
            if path.contains("/build/") || path.contains("/.git/") || path.contains("/DerivedData/") { continue }
            if forbidden.contains(url.pathExtension) { found.append(url.lastPathComponent) }
        }
        #expect(found.isEmpty, "credential files in the project: \(found)")
    }
}

@Suite("Step 11 real-device protections")
struct DeviceReadinessTests {
    @Test func longVideosAreStoppedBeforeAnalysis() {
        #expect(AnalysisLimits.problem(forDurationSeconds: 3.2) == nil)
        #expect(AnalysisLimits.problem(forDurationSeconds: 60) == nil)
        #expect(AnalysisLimits.problem(forDurationSeconds: nil) == nil, "unknown duration: let the engine read the file")
        #expect(AnalysisLimits.problem(forDurationSeconds: .nan) == nil)
        let problem = AnalysisLimits.problem(forDurationSeconds: 125.4)
        #expect(problem == .videoTooLong(seconds: 125.4))
        #expect(problem?.canRetry == false, "trimming is the fix, not retrying")
        #expect(problem?.message.contains("125 seconds") == true)
        #expect(problem?.message.contains("60 seconds") == true)
        #expect(problem?.title == "Video is too long")
    }

    @Test func backgroundInterruptionIsRetryable() {
        let problem = AnalysisProblem.interruptedByBackground
        #expect(problem.canRetry)
        #expect(!problem.suggestsKickerSelection)
        #expect(problem.message.contains("Keep KickLab open"))
        var state = AnalysisFlowMachine.reduce(.idle, .start)
        state = AnalysisFlowMachine.reduce(state, .cancelRequested)
        state = AnalysisFlowMachine.reduce(state, .failed(.interruptedByBackground))
        #expect(state == .failed(.interruptedByBackground))
        #expect(AnalysisFlowMachine.reduce(state, .start) == .running(stage: .preparing, fraction: 0), "Try Again works")
    }

    @Test func importsNeedRoomToSpare() {
        let mb: Int64 = 1_048_576
        #expect(StorageSpacePolicy.hasRoom(forFileOfSize: 50 * mb, availableBytes: 10_000 * mb))
        #expect(!StorageSpacePolicy.hasRoom(forFileOfSize: 50 * mb, availableBytes: 240 * mb), "keeps a 200 MB margin")
        #expect(StorageSpacePolicy.hasRoom(forFileOfSize: 50 * mb, availableBytes: 250 * mb))
        #expect(StorageSpacePolicy.hasRoom(forFileOfSize: nil, availableBytes: 1), "unknown size never blocks")
        #expect(StorageSpacePolicy.hasRoom(forFileOfSize: 50 * mb, availableBytes: nil), "unknown capacity never blocks")
        #expect(StorageSpacePolicy.notEnoughSpaceMessage(fileSize: 50 * mb).contains("about 250 MB"))
    }

    @Test func diskFullErrorsAreExplained() {
        let cocoa = NSError(domain: NSCocoaErrorDomain, code: NSFileWriteOutOfSpaceError)
        let posix = NSError(domain: NSPOSIXErrorDomain, code: Int(ENOSPC))
        let wrapped = NSError(domain: "SwiftData", code: 1, userInfo: [NSUnderlyingErrorKey: posix])
        #expect(UserFacingError.isOutOfSpace(cocoa))
        #expect(UserFacingError.isOutOfSpace(posix))
        #expect(UserFacingError.isOutOfSpace(wrapped))
        #expect(!UserFacingError.isOutOfSpace(NSError(domain: NSCocoaErrorDomain, code: NSFileNoSuchFileError)))
        #expect(UserFacingError.message(for: wrapped) == UserFacingError.outOfSpaceMessage)
    }

    @Test func startupFailuresAreExplainedNotCrashed() {
        struct StoreError: Error {}
        let generic = UserFacingError.startupMessage(for: StoreError())
        #expect(generic.contains("couldn't open its data"))
        #expect(!generic.contains("StoreError"), "no raw error text")
        let full = UserFacingError.startupMessage(for: NSError(domain: NSPOSIXErrorDomain, code: Int(ENOSPC)))
        #expect(full.contains("out of storage space"))
    }
}
