import Foundation
import SwiftData
import Testing
@testable import KickLab

/// The Kick model's outcome boundary (`applyOutcome`, `make(from:)`, typed accessors).
@MainActor
@Suite("Kick model outcome boundary")
struct KickModelOutcomeTests {
    let container: ModelContainer
    let context: ModelContext

    init() throws {
        container = try ModelContainerFactory.makeContainer(inMemory: true)
        context = container.mainContext
    }

    @Test func typedAccessorsMatchKickType() throws {
        let pat = try Kick.make(from: KickDraft(outcome: .pat(FieldGoalOutcome(result: .made))))
        context.insert(pat)
        #expect(pat.kickType == .pat)
        #expect(pat.fieldGoalOutcome?.result == .made)
        #expect(pat.kickoffOutcome == nil)
        #expect(pat.puntOutcome == nil)

        let kickoff = try Kick.make(from: KickDraft(outcome: .kickoff(KickoffOutcome(touchback: true))))
        context.insert(kickoff)
        #expect(kickoff.fieldGoalOutcome == nil)
        #expect(kickoff.kickoffOutcome?.touchback == true)
    }

    @Test func changingKickoffToFieldGoalClearsValuesAndProvenance() throws {
        let kick = try Kick.make(from: KickDraft(outcome: .kickoff(KickoffOutcome(
            distance: .measured(64.5, from: .primaryVideo, confidence: 0.9),
            landing: .measured(KickoffLanding(yardLine: -2, zone: .right), from: .multiVideo, confidence: 0.85),
            touchback: true,
            outOfBounds: false,
            hangTime: .measured(4.2, from: .secondaryVideo, confidence: 0.8)
        ))))
        context.insert(kick)
        #expect(kick.storedLandingSource == "multiVideo")

        try kick.applyOutcome(.fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(41))))

        #expect(kick.kickType == .fieldGoal)
        // Kickoff values gone.
        #expect(kick.landingYardLine == nil)
        #expect(kick.storedLandingZone == nil)
        #expect(kick.touchback == nil)
        #expect(kick.outOfBounds == nil)
        #expect(kick.hangTimeSeconds == nil)
        // Kickoff provenance gone.
        #expect(kick.storedLandingSource == nil)
        #expect(kick.landingConfidence == nil)
        #expect(kick.storedHangTimeSource == nil)
        #expect(kick.hangTimeConfidence == nil)
        // Distance provenance replaced, not merged: manual has no confidence.
        #expect(kick.distanceYards == 41)
        #expect(kick.storedDistanceSource == "manual")
        #expect(kick.distanceConfidence == nil)
        #expect(kick.validationIssues.isEmpty)
    }

    @Test func changingFieldGoalToPuntClearsAccuracyProvenance() throws {
        let kick = try Kick.make(from: KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .missedRight,
            accuracy: .measured(AccuracyCoordinate(x: 1.3, y: 0.4), from: .primaryVideo, confidence: 0.75)
        ))))
        context.insert(kick)

        try kick.applyOutcome(.punt(PuntOutcome(distance: .manual(40))))

        #expect(kick.kickType == .punt)
        #expect(kick.storedResult == nil)
        #expect(kick.accuracyX == nil)
        #expect(kick.accuracyY == nil)
        #expect(kick.storedAccuracySource == nil)
        #expect(kick.accuracyConfidence == nil)
        #expect(kick.validationIssues.isEmpty)
    }

    @Test func invalidOutcomeLeavesKickUnchanged() throws {
        let kick = try Kick.make(from: KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(35)))))
        context.insert(kick)
        let before = kick.outcomeColumns

        #expect(throws: KickValidationError.self) {
            try kick.applyOutcome(.kickoff(KickoffOutcome(touchback: true, outOfBounds: true)))
        }
        #expect(kick.kickType == .fieldGoal)
        #expect(kick.outcomeColumns == before)
    }

    @Test func assignAthleteKeepsAthleteIDInSync() throws {
        let athlete = Athlete(firstName: "Test", lastName: "Kicker")
        let kick = try Kick.make(from: KickDraft(outcome: .pat(FieldGoalOutcome(result: .made))))
        context.insert(athlete)
        context.insert(kick)

        kick.assignAthlete(athlete)
        #expect(kick.athleteID == athlete.id)

        kick.assignAthlete(nil)
        #expect(kick.athleteID == nil)
        #expect(kick.athlete == nil)
    }

    @Test func spotIsStoredButNeverWrittenIntoDistance() throws {
        let noDistance = try Kick.make(from: KickDraft(
            outcome: .fieldGoal(FieldGoalOutcome(result: .made)),
            spotDistanceToTargetGoalLine: 30
        ))
        context.insert(noDistance)
        #expect(noDistance.spotDistanceToTargetGoalLine == 30)
        #expect(noDistance.distanceYards == nil)

        let measured = try Kick.make(from: KickDraft(
            outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .measured(41.3, from: .primaryVideo, confidence: 0.9))),
            spotDistanceToTargetGoalLine: 30
        ))
        context.insert(measured)
        #expect(measured.distanceYards == 41.3)
        #expect(measured.storedDistanceSource == "primaryVideo")
    }
}
