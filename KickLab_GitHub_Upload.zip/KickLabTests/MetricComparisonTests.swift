import Foundation
import Testing
@testable import KickLab

@Suite("Metric comparison and baseline foundation")
struct MetricComparisonTests {
    private func snapshot(_ values: [KickMetricKey: Double], day: Double = 0, confidence: Double = 0.8, kickType: KickType = .fieldGoal) -> MetricSnapshot {
        MetricSnapshot(
            kickType: kickType,
            recordedAt: Date(timeIntervalSince1970: 1_800_000_000 + day * 86_400),
            values: values.mapValues { .init(value: $0, confidence: confidence, status: .estimated, definitionVersion: 1) }
        )
    }

    let profile = BiomechanicsProfile.standard(for: .fieldGoal)

    @Test func kickToKickDeltasUseBetterDirections() {
        let before = snapshot([.plantFootDrift: 0.4, .peakFootSpeed: 20, .plantToContactTime: 0.4, .torsoLeanRange: 10])
        let after = snapshot([.plantFootDrift: 0.2, .peakFootSpeed: 18, .plantToContactTime: 0.2, .torsoLeanRange: 10.1])
        let deltas = MetricComparison.compare(after, to: before, profile: profile)
        func delta(_ key: KickMetricKey) -> MetricDelta? { deltas.first { $0.key == key } }
        #expect(delta(.plantFootDrift)?.direction == .improved, "lower is better")
        #expect(delta(.plantFootDrift)?.difference == -0.2)
        #expect(delta(.plantFootDrift)?.percentChange == -50)
        #expect(delta(.peakFootSpeed)?.direction == .worsened, "higher is better")
        // Build 18: plant-to-contact time has no validated "better" interval, so a change in it
        // is reported without calling it better or worse.
        #expect(delta(.plantToContactTime)?.direction == .notApplicable, "descriptive: no better direction")
        #expect(delta(.torsoLeanRange)?.direction == .unchanged, "within 2%")
        #expect(deltas.map(\.key) == [.plantToContactTime, .plantFootDrift, .peakFootSpeed, .torsoLeanRange], "catalog order")
    }

    @Test func comparisonsSkipMissingLowConfidenceAndChangedDefinitions() {
        var a = snapshot([.plantFootDrift: 0.2, .peakFootSpeed: 20])
        let b = snapshot([.plantFootDrift: 0.3, .approachSpeed: 3])
        #expect(MetricComparison.compare(a, to: b).map(\.key) == [.plantFootDrift])
        a.values[.plantFootDrift]?.confidence = 0.3
        #expect(MetricComparison.compare(a, to: b).isEmpty)
        a.values[.plantFootDrift] = .init(value: 0.2, confidence: 0.9, status: .estimated, definitionVersion: 2)
        #expect(MetricComparison.compare(a, to: b).isEmpty, "a redefined metric is not compared with the old one")
    }

    @Test func baselineNeedsEnoughHistory() {
        let two = [snapshot([.approachSpeed: 3]), snapshot([.approachSpeed: 4])]
        #expect(MetricComparison.baseline(from: two, kickType: .fieldGoal) == nil, "single-kick analysis needs no baseline")
        let other = [snapshot([.approachSpeed: 3], kickType: .kickoff)] + two
        #expect(MetricComparison.baseline(from: other, kickType: .fieldGoal) == nil, "other kick types don't count")
    }

    @Test func baselineStatisticsAndDeviation() throws {
        let history = [2.0, 3.0, 4.0, 5.0].enumerated().map { i, v in snapshot([.approachSpeed: v, .plantFootDrift: 0.1], day: Double(i)) }
        let baseline = try #require(MetricComparison.baseline(from: history, kickType: .fieldGoal))
        #expect(baseline.kickCount == 4)
        let stat = try #require(baseline.statistics[.approachSpeed])
        #expect(stat.count == 4)
        #expect(stat.mean == 3.5)
        #expect(stat.median == 3.5)
        #expect(stat.standardDeviation == 1.118)

        let deviations = MetricComparison.compare(snapshot([.approachSpeed: 6, .plantFootDrift: 0.3]), to: baseline, profile: profile)
        let speed = deviations.first { $0.key == .approachSpeed }
        #expect(speed?.difference == 2.5)
        #expect(speed?.standardScore == 2.236)
        let drift = deviations.first { $0.key == .plantFootDrift }
        #expect(drift?.standardScore == nil, "no spread in the baseline")
        #expect(drift?.direction == .worsened)
    }

    @Test func trendSlopePerDay() {
        let history = [(0.0, 0.5), (2.0, 0.4), (4.0, 0.3)].map { snapshot([.plantFootDrift: $0.1], day: $0.0) }
        let trend = MetricComparison.trend(of: .plantFootDrift, in: history.reversed())
        #expect(trend.points.map(\.value) == [0.5, 0.4, 0.3], "oldest first")
        #expect(near(trend.slopePerDay, -0.05, 1e-9))
        #expect(MetricComparison.trend(of: .approachSpeed, in: history).slopePerDay == nil)
    }

    @Test func snapshotsFromMeasurementsDropUnavailableValues() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal, kickType: .punt)
        let s = MetricSnapshot(kickType: .punt, recordedAt: Date(timeIntervalSince1970: 0), measurements: r.measurements)
        #expect(s.values[.plantFootDrift] == nil)
        #expect(s.values[.kickingKneeAngleAtContact]?.value == r.measurement(.kickingKneeAngleAtContact)?.value)
        #expect(s.values.count == r.availableMetricCount)
    }
}
