import Foundation
import Testing
@testable import KickLab

/// Build 20 — the five reference recordings as one regression suite, plus what the new
/// Performance Intelligence layer does with each.
///
/// EVIDENCE CLASS per case (nothing here ran on an iPhone):
/// - Rear 7.602 s — REAL Apple Vision signals exported from the iPhone (`RealReferenceClipRear`)
///   with the device's ball timing.
/// - IMG_1709 (12.202 s) — REAL video frames, but MediaPipe landmarks + real YOLOX-S detections
///   (`RealVideoClip1709`, `RealVideo1709Football`); NOT an Apple Vision run.
/// - Rear 9.068 s — SYNTHETIC reconstruction (no evidence bundle of this recording exists).
/// - Rear 3.663 s — SYNTHETIC reconstruction (no evidence bundle of this recording exists).
/// - Side 6.502 s — REAL Apple Vision signals exported from the iPhone (`RealReferenceClip220`).
@Suite("Reference regression (Build 20)")
struct ReferenceRegression20Tests {

    // MARK: Rear 7.602 s — REAL device signals

    @Test func rear7602ContactAndPlantAreUnchanged() throws {
        let ball = AutomaticBallContact(lastStationaryTime: 3.833, firstMovementTime: 3.9, basis: "displacedDetections", detectorName: "YOLOX-S")
        let p = KickPhaseDetector.detect(RealReferenceClipRear.signals, kickType: .fieldGoal, perspective: .depthAway, ballContact: ball)
        #expect(abs((p.estimatedContactTime ?? 0) - 3.867) < 0.002)
        #expect(abs((p.plantTime ?? 0) - 3.767) < 0.002)
        let outcome = ContactOutcome.of(p)
        #expect(outcome == .ballConstrainedContactInterval || outcome == .ballVerifiedContact, "ball-aware contact evidence kept (\(outcome))")
        #expect(p.phase(.contact).status == .estimated, "estimated, never 'detected'")
    }

    // MARK: IMG_1709 — REAL frames (MediaPipe) + REAL YOLOX-S detections

    @Test func img1709ContactBallIntervalAndPlant() throws {
        typealias Clip = RealVideoClip1709
        let pose = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        let context = FootballAnalysisContext.make(from: pose, kickingFoot: .right)
        let track = FootballTrackAnalyzer.analyze(broadScan: RealVideo1709Football.broadScan, scanTimes: RealVideo1709Football.scanTimes,
                                                  precision: RealVideo1709Football.precisionFrames, ankle: context.ankle, strike: context.strike,
                                                  aspect: Clip.displayAspectRatio, duration: Clip.durationSeconds, detector: .yoloxS)
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                                     cameraAngle: .rear, football: track))
        let p = out.phases
        #expect(abs((p.estimatedContactTime ?? 0) - 7.935) < 0.002)
        #expect(abs((p.evidence?.contactEarliestTime ?? 0) - 7.902) < 0.002)
        #expect(abs((p.evidence?.contactLatestTime ?? 0) - 7.968) < 0.002)
        // The Build 20 brief lists plant ≈ 7.835 s; the automatic plant on these frames is
        // 7.868 s (one frame later) and is NOT changed to match. 7.835 s is what a person
        // supplied in an earlier assisted test. Unverified on the device.
        #expect(abs((p.plantTime ?? 0) - 7.868) < 0.002)
        #expect(out.biomechanics.overallScore == nil, "no technique score from behind")
        // Rear-view measurements Build 20 interprets.
        for key in [KickMetricKey.plantBallLateralOffset, .plantToContactTime, .lateralTrunkLeanAtContact] {
            #expect(out.biomechanics.measurement(key)?.isAvailable == true, "\(key)")
        }
    }

    // MARK: Rear 9.068 s — SYNTHETIC reconstruction

    @Test func syntheticRear9068EarlierCredibleDriveStillAccepted() throws {
        try ContactIntelligence29Tests().syntheticAnEarlierCredibleDriveAgreeingWithTheBallIsUsed()
        try ContactIntelligence29Tests().syntheticPoseAlonePicksTheLaterFasterExtension()
    }

    @Test func syntheticPartlyObservedFollowThroughRuleIsKept() {
        // The rule a 9.068-style overlap (4.902–5.135 s on the device) would need; whether
        // the real clip qualifies needs its evidence bundle.
        Reliability31Tests().aPartlyObservedFollowThroughNeedsTheFootStillMovingWhenItReappears()
    }

    // MARK: Rear 3.663 s — SYNTHETIC reconstruction

    @Test func syntheticRear3663BallAnchoredWithoutPlant() throws {
        try BallFusionTests().aBallDepartureLocatesAKickWhenNoRunUpWasSeen()
    }

    @Test func aContactAt0_180sIsCroppedAndKeptOutOfBaselines() {
        // Contact 0.180 s ≤ 0.6 s: the run-up and plant aren't in the clip.
        #expect(0.180 <= RecordingFlags.croppedContactSeconds)
        func entry(_ n: Double, _ v: Double, cropped: Bool = false) -> RankingEntry {
            var e = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_800_000_000 + n * 86_400), kickType: .fieldGoal,
                                 view: .depth, engineVersion: PoseVideoAnalysisService.version, completed: true, overallScore: nil,
                                 categoryScores: [:], recording: RecordingFlags(cropped: cropped))
            e.metrics[RankingEntry.metricKey(.lateralTrunkLeanAtContact)] = v
            return e
        }
        let cropped = entry(4, 30, cropped: true)
        let current = entry(5, 9.6)
        let r = ConsistencyModel.make(current: current, eligibility: PersonalRanking.eligibility(for: current, among: [entry(1, 9), entry(2, 10), entry(3, 9.5), cropped, current]))
        #expect(r.metrics.first { $0.key == .lateralTrunkLeanAtContact }?.earlier == [9, 10, 9.5])
        #expect(r.excluded.values.reduce(0, +) == 1)
    }

    // MARK: Side 6.502 s — REAL device signals

    @Test func side6502IdentityCollapseAndKneeNaming() throws {
        try Reliability31Tests().theSideClipsKickingAnkleLabelCollapsesOntoThePlantFootBeforeContact()
        Reliability31Tests().kickingLegValuesAtContactAreWithheldWhenTheLabelCollapsedBeforeContact()   // SYNTHETIC timeline
        Reliability31Tests().aKneeTimedFollowThroughIsNeverReportedAsTheFootsFollowThrough()             // SYNTHETIC timeline
    }

    /// Technique categories, weights and gates are unchanged in Build 20 (provisional-bands-2).
    @Test func techniqueScoringIsUnchanged() {
        let p = BiomechanicsProfile.standard(for: .fieldGoal)
        let weights = p.scoring.mapValues(\.weight)
        #expect(weights == [
            .approachSpeed: 0, .approachSpeedVariation: 0, .approachLateSpeedChange: 0,
            .plantFootDrift: 1.5, .plantKneeAngleAtContact: 1,
            .kickingKneeAngleAtContact: 1.5, .kickingHipAngleAtContact: 0.5, .backswingDepth: 1, .peakFootSpeed: 1, .footSpeedAtContact: 0,
            .torsoLeanAtContact: 1.5, .torsoLeanRange: 1, .bodyForwardSpeedAtContact: 1,
            .followThroughDuration: 1, .followThroughFootHeight: 1, .followThroughBodyTravel: 1,
        ])
        #expect(p.minimumScoringConfidence == 0.35)
        #expect(p.minimumCategoryWeightFraction == 0.5)
        #expect(p.minimumCategoriesForOverall == 3)
        #expect(ScoringModel.current == "provisional-bands-3")
        #expect(PoseVideoAnalysisService.version == "pose-biomechanics-3.2.0", "Build 20 added no measurement change; Build 22 withholds foot extremes seen at the frame edge (scoring unchanged)")
    }

    // MARK: What feedback appears as a kicker records more (SYNTHETIC history)

    /// One rear-view field goal per day with the IMG_1709-like plant-to-ball value 0.57; the
    /// earlier values are synthetic. Shows exactly which feedback becomes available when.
    @Test func feedbackGrowsWithComparableKicks() throws {
        let values = [0.55, 0.60, 0.58, 0.57, 0.71]
        func entries(_ n: Int) -> [RankingEntry] {
            (0..<n).map { i in
                var e = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_800_000_000 + Double(i) * 86_400),
                                     kickType: .fieldGoal, view: .depth, engineVersion: PoseVideoAnalysisService.version, completed: true,
                                     overallScore: nil, categoryScores: [:])
                e.metrics[RankingEntry.metricKey(.plantBallLateralOffset)] = values[i]
                return e
            }
        }
        func report(_ n: Int) -> MetricConsistencyAssessment? {
            let all = entries(n)
            let current = all.last!
            return ConsistencyModel.make(current: current, eligibility: PersonalRanking.eligibility(for: current, among: all))
                .metrics.first { $0.key == .plantBallLateralOffset }
        }
        // 1st kick: the value and its quality only.
        #expect(report(1)?.comparison == .noBaseline(have: 0))
        #expect(report(1)?.spread == nil)
        // 3rd kick: still building (2 earlier).
        #expect(report(3)?.comparison == .noBaseline(have: 2))
        // 4th kick: usual value (3 earlier), within/outside, AND a spread (4 kicks).
        let fourth = try #require(report(4))
        #expect(fourth.comparison == .withinUsual)
        #expect(fourth.spreadText == "Varied by 0.05 torso lengths across 4 comparable kicks")
        #expect(fourth.level == .withinPrecision, "SD 0.021 ≤ the 0.03 resolution: as repeatable as KickLab can measure")
        // 5th kick: 0.71 vs usual 0.575 ± 0.02 → outside the usual range, said without judgement.
        let fifth = try #require(report(5))
        #expect(fifth.comparison == .higherThanUsual)
        #expect(fifth.interpretation == "Your plant foot was farther to the side of the football than on your recent comparable kicks.")
        // Never "improving" for a measurement without a better direction.
        #expect(KickMetricKey.plantBallLateralOffset.definition.betterDirection == .none)
    }
}
