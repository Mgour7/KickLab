import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode (SwiftData): Step 12G schema V3 and verified frames. Typechecked on
/// Linux; runs on the macOS CI runner.
@MainActor
@Suite("Step 12G persistence (SwiftData)")
struct Step12GPersistenceTests {
    @Test func aVersion2StoreOpensAsVersion3WithItsVideosKept() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("kicklab-v3-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: dir) }
        let url = dir.appendingPathComponent("KickLab.store")
        let videoID = UUID()
        do {
            let v2 = Schema(versionedSchema: KickLabSchemaV2.self)
            let container = try ModelContainer(for: v2, configurations: ModelConfiguration(schema: v2, url: url, cloudKitDatabase: .none))
            let context = container.mainContext
            let kick = KickLabSchemaV2.Kick(id: UUID(), timestamp: Date(timeIntervalSince1970: 1_800_000_000))
            context.insert(kick)
            let video = KickLabSchemaV2.VideoAsset(id: videoID, angleType: .rear, isPrimary: true, storageStatus: .local, relativeFilePath: "Videos/a.mov")
            video.contactTimeSeconds = 7.935
            video.storedContactTimeSource = "manual"
            video.kick = kick
            context.insert(video)
            try context.save()
        }
        let v3 = Schema(versionedSchema: KickLabSchemaV3.self)
        let container = try ModelContainer(for: v3, migrationPlan: KickLabMigrationPlan.self,
                                           configurations: ModelConfiguration(schema: v3, url: url, cloudKitDatabase: .none))
        let video = try #require(try container.mainContext.fetch(FetchDescriptor<VideoAsset>()).first)
        #expect(video.id == videoID && video.contactTimeSeconds == 7.935 && video.contactTimeSource == .manual && video.angleType == .rear)
        #expect(video.verificationData == nil && video.verification.isEmpty, "new column starts empty")
        var v = video.verification
        v.plant = .frame(time: 7.868)
        video.verification = v
        try container.mainContext.save()
        #expect(try container.mainContext.fetch(FetchDescriptor<VideoAsset>()).first?.verification.plant == .frame(time: 7.868))
    }

    @Test func verifiedFramesAreStoredOnTheVideoAndClearable() throws {
        let f = try ServiceFixture()
        let kick = try f.makeKick(for: try f.makeAthlete())
        let video = try f.addVideo(to: kick, path: "Videos/x.mov")
        var v = VideoVerification()
        v.plant = .cannotTell
        v.firstBallMovement = .frame(time: 7.968)
        v.ballMark = VideoVerification.BallMark(time: 7.302, x: 0.57, y: 0.58, radius: 0.018)
        video.verification = v
        try f.context.save()
        #expect(video.verification == v)
        video.verification = VideoVerification()
        try f.context.save()
        #expect(video.verificationData == nil, "an empty record is stored as nothing")
    }
}
