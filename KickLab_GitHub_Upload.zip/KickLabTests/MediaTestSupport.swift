import Foundation
@testable import KickLab

/// A fresh, empty directory under the system temp folder. Call `remove()` when done.
struct TemporaryDirectory {
    let url: URL

    init() throws {
        url = FileManager.default.temporaryDirectory
            .appendingPathComponent("KickLabTests-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    }

    /// `<temp>/KickLab`, used as the media base so `../` escapes would land in `<temp>`.
    var kickLabBase: URL { url.appendingPathComponent("KickLab", isDirectory: true) }

    func remove() {
        try? FileManager.default.removeItem(at: url)
    }

    /// Writes `bytes` to `<temp>/<name>` and returns its URL.
    @discardableResult
    func writeFile(named name: String, bytes: [UInt8] = Array("fake video bytes".utf8)) throws -> URL {
        let file = url.appendingPathComponent(name)
        try Data(bytes).write(to: file)
        return file
    }

    /// Writes a file at a path relative to a root, creating folders as needed.
    @discardableResult
    func writeFile(_ relativePath: String, under root: URL, bytes: [UInt8] = [1, 2, 3, 4]) throws -> URL {
        let file = relativePath.split(separator: "/").reduce(root) { $0.appendingPathComponent(String($1)) }
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data(bytes).write(to: file)
        return file
    }
}

func fileBytes(at url: URL) -> [UInt8]? {
    (try? Data(contentsOf: url)).map(Array.init)
}

func exists(_ url: URL) -> Bool {
    FileManager.default.fileExists(atPath: url.path)
}

/// Writes a small JPEG-like file and reports success.
struct WritingThumbnailGenerator: VideoThumbnailGenerating {
    func generateThumbnail(for videoURL: URL, writingTo destination: URL) async -> Bool {
        (try? Data([0xFF, 0xD8, 0xFF, 0xD9]).write(to: destination)) != nil
    }
}

/// Writes a partial file but reports failure, like a generator that died midway.
struct FailingThumbnailGenerator: VideoThumbnailGenerating {
    func generateThumbnail(for videoURL: URL, writingTo destination: URL) async -> Bool {
        try? Data([0x00]).write(to: destination)
        return false
    }
}

struct FixedMetadataReader: VideoMetadataReading {
    let metadata: VideoMediaMetadata?
    func readMetadata(at url: URL) async -> VideoMediaMetadata? { metadata }
}

/// Approximate equality for averages that are not exactly representable.
func approximately(_ value: Double?, _ expected: Double, tolerance: Double = 1e-9) -> Bool {
    guard let value else { return false }
    return abs(value - expected) <= tolerance
}
