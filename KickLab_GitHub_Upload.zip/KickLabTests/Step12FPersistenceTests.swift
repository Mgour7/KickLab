import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode (SwiftData): Step 12F schema V2 migration, profiles, entered kick
/// details and contact verification. Typechecked on Linux; runs on the macOS CI runner.
@MainActor
@Suite("Step 12F persistence (SwiftData)")
struct Step12FPersistenceTests {
    // MARK: Migration

    @Test func aVersion1StoreOpensAsTheCurrentVersionWithEveryRecordKept() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("kicklab-migration-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: dir) }
        let url = dir.appendingPathComponent("KickLab.store")
        let athleteID = UUID(), kickID = UUID()

        // 1. A store written by a V1 build (Step 12E and earlier).
        do {
            let v1 = Schema(versionedSchema: KickLabSchemaV1.self)
            let container = try ModelContainer(for: v1, configurations: ModelConfiguration(schema: v1, url: url, cloudKitDatabase: .none))
            let context = container.mainContext
            let athlete = KickLabSchemaV1.Athlete(id: athleteID, firstName: "Ava", lastName: "Kicker", kickingFoot: .left)
            athlete.graduationYear = 2027
            context.insert(athlete)
            let kick = KickLabSchemaV1.Kick(id: kickID, timestamp: Date(timeIntervalSince1970: 1_700_000_000))
            kick.storedKickType = "fieldGoal"
            kick.storedResult = "made"
            kick.distanceYards = 42
            kick.athlete = athlete
            kick.athleteID = athleteID
            context.insert(kick)
            try context.save()
        }

        // 2. Opened by the current build (V3 since Step 12G) with the migration plan:
        //    V1 → V2 → V3.
        let current = Schema(versionedSchema: KickLabSchemaV3.self)
        let container = try ModelContainer(for: current, migrationPlan: KickLabMigrationPlan.self,
                                           configurations: ModelConfiguration(schema: current, url: url, cloudKitDatabase: .none))
        let context = container.mainContext
        let athletes = try context.fetch(FetchDescriptor<Athlete>())
        let kicks = try context.fetch(FetchDescriptor<Kick>())
        #expect(athletes.count == 1 && kicks.count == 1)
        let athlete = try #require(athletes.first)
        #expect(athlete.id == athleteID && athlete.firstName == "Ava" && athlete.kickingFoot == .left && athlete.graduationYear == 2027)
        #expect(athlete.nickname == nil && athlete.primaryRole == nil && athlete.photoData == nil, "new columns start empty")
        let kick = try #require(kicks.first)
        #expect(kick.id == kickID && kick.distanceYards == 42 && kick.storedResult == "made" && kick.athlete?.id == athleteID)
        #expect(kick.ballType == nil && kick.puntResult == nil)
        // New columns are writable after migration.
        athlete.nickname = "Boomer"
        try context.save()
        #expect(try context.fetch(FetchDescriptor<Athlete>()).first?.nickname == "Boomer")
    }

    // MARK: Profiles

    @Test func theNewProfileFieldsSaveAndEdit() throws {
        let f = try ServiceFixture()
        var profile = AthleteProfile(firstName: "Ava", lastName: "Kicker", graduationYear: 2027, schoolTeam: "North High")
        profile.nickname = "Boomer"
        profile.birthYear = 2009
        profile.primaryRole = .both
        profile.experienceLevel = .developing
        profile.goals = "Make 45 yards"
        profile.preferredBallType = .highSchool
        let athlete = try f.athletes.createAthlete(profile)
        #expect(athlete.nickname == "Boomer" && athlete.primaryRole == .both && athlete.experienceLevel == .developing)
        #expect(f.athletes.profile(of: athlete) == profile.normalized)
        var edited = f.athletes.profile(of: athlete)
        edited.nickname = "  "
        try f.athletes.updateProfile(athlete, with: edited)
        #expect(athlete.nickname == nil, "blank nickname is cleared")
        #expect(athlete.goals == "Make 45 yards", "other fields untouched")
    }

    @Test func archivingHidesAnAthleteButKeepsTheirKicks() throws {
        let f = try ServiceFixture()
        let a = try f.makeAthlete("A")
        try f.makeAthlete("B")
        try f.makeKick(for: a)
        try f.athletes.archive(a)
        #expect(try f.athletes.activeAthletes().map(\.firstName) == ["B"])
        #expect(try f.athletes.archivedAthletes().map(\.firstName) == ["A"])
        #expect((a.kicks ?? []).count == 1)
        try f.athletes.restore(a)
        #expect(try f.athletes.archivedAthletes().isEmpty)
    }

    // MARK: Entered kick details

    @Test func enteredDetailsSaveAndOnlyApplicableOnesAreKept() throws {
        let f = try ServiceFixture()
        let athlete = try f.makeAthlete()
        var draft = KickDraft(outcome: .punt(PuntOutcome(distance: .manual(41), hangTime: .manual(4.2))))
        draft.details = KickEnteredDetails(ballType: .college, setup: .drop, conditions: " light wind ", direction: .right,
                                           puntInsideTwenty: true, puntResult: .fairCatch)
        let kick = try f.kicks.createKick(for: athlete, in: nil, draft: draft)
        #expect(kick.ballType == .college && kick.kickSetup == .drop && kick.conditionsNote == "light wind")
        #expect(kick.kickDirection == .right && kick.puntInsideTwenty == true && kick.puntResult == .fairCatch)
        // Corrected to a field goal: punt-only and kickoff/punt-only fields are cleared.
        var corrected = KickDraft(id: kick.id, outcome: .fieldGoal(FieldGoalOutcome(result: .missedOther, distance: .manual(38), accuracy: nil)))
        corrected.details = draft.details
        try f.kicks.updateKick(kick, with: corrected)
        #expect(kick.kickDirection == nil && kick.puntInsideTwenty == nil && kick.puntResult == nil)
        #expect(kick.ballType == .college, "ball type applies to every kick")
        #expect(KickStatRecord(kick: kick).result == .missedOther)
    }

    @Test func sessionSummaryComesFromItsSavedKicks() throws {
        let f = try ServiceFixture()
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        for (result, yards) in [(KickResult.made, 32.0), (.made, 44), (.missedLeft, 47)] {
            try f.makeKick(for: athlete, in: session,
                           draft: KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: result, distance: .manual(yards), accuracy: nil))))
        }
        let summary = SessionPerformanceSummary.make((session.kicks ?? []).map(KickStatRecord.init(kick:)))
        #expect(summary.fieldGoals?.overall == RateSummary(successes: 2, attempts: 3))
        #expect(summary.fieldGoals?.longestMake == 44)
        #expect(summary.kickoffs == nil && summary.punts == nil)
    }
}
