import Foundation
import Testing
@testable import KickLab

@Suite("Step 10 coach presentation")
struct PersonalCoachPresentationTests {
    typealias F = PersonalFixture

    @Test func cardsShowNormalThisKickBestKicksAndConfidence() throws {
        let history = F.series(.followThroughDuration, [0.18, 0.19, 0.20, 0.19, 0.18, 0.20, 0.19, 0.19, 0.18, 0.20])
        let report = try F.report(current: F.current([.followThroughDuration: 0.27]), history: history)
        let coach = PersonalCoachPresentation.make(report: report)
        #expect(coach.learningMessage == nil)
        #expect(coach.maturityText == "Personal coaching: established · 10 comparable field goals")
        let card = try #require(coach.fixes.first)
        #expect(card.headline == "Your follow-through lasted a little longer compared with your best kicks.")
        #expect(card.rows.map(\.title) == ["Your Normal", "This Kick", "Best Kicks"])
        #expect(card.rows[0].value == "0.19 s")
        #expect(card.rows[1].value == "0.27 s")
        #expect(card.rows[2].value.hasSuffix(" s"))
        #expect(card.confidenceText == "Medium")
        #expect(card.basisText == "Your successful kicks")
        #expect(card.categoryTitle == "Follow-Through")
        #expect(card.detail.evidence.map(\.title) == ["Compared with your successful kicks"])
        #expect(card.detail.priorityRows.first?.title == "Priority score")
        #expect(card.detail.rationale == PersonalCoachCopy.personalOnlyRationale)
        #expect(!card.headline.contains("followThrough.duration"))
    }

    @Test func generalOnlyCardsShowTheGeneralTarget() throws {
        let report = try F.report(current: F.current([.torsoLeanAtContact: 18]), history: [], general: [PersonalCoachTests.leanForward])
        let coach = PersonalCoachPresentation.make(report: report)
        #expect(coach.learningMessage == PersonalCoachCopy.learningMessage(needed: 8))
        #expect(coach.maturityText == "Personal coaching: not enough kicks yet (0 comparable field goals)")
        let card = try #require(coach.fixes.first)
        #expect(card.rows.map(\.title) == ["This Kick", "General Target"])
        #expect(card.rows[1].value == "-15–5°")
        #expect(card.basisText == "General kicking mechanics")
        #expect(card.cue == PersonalCoachTests.leanForward.cue)

        let top = try #require(PersonalCoachPresentation.topPriority(report))
        #expect(top.observed == PersonalCoachTests.leanForward.observed)
        #expect(top.severityText == "Low priority")
    }

    @Test func notesExplainDistanceAngleAndSnapshot() throws {
        let short = (0..<10).map { F.kick($0, distance: 25, values: [.plantToContactTime: 0.18, .torsoLeanAtContact: -5], angle: .rear) }
        let (report, selection) = try PersonalCoachingEngine.report(
            analysisID: F.analysisID, current: F.current([.plantToContactTime: 0.18, .torsoLeanAtContact: -5], distance: 24),
            history: short, generalFindings: [], epoch: nil, now: F.date(100))
        let artifact = PersonalizationArtifact(analysisID: F.analysisID, kickID: F.id(999, 1), createdAt: F.date(100),
                                               modelVersion: StatisticalAthleteLearningModel.version, configuration: PersonalizationConfiguration(),
                                               current: F.current([:]), selection: selection, report: report)
        let coach = PersonalCoachPresentation.make(report: report, snapshot: artifact)
        #expect(coach.notes == [
            "Compared with your Under 30-yard field goals.",
            PersonalCoachPresentation.unavailableAngleNote,
            "When this kick was analyzed, KickLab had 10 comparable field goals to learn from.",
        ])
    }

    @Test func storedObservationsBecomeGeneralFindings() {
        let improveID = UUID()
        let stored = [
            StoredObservationRecord(id: UUID(), kind: .keep, category: .swing,
                                    message: "Kicking leg was nearly fully extended at contact (165°). Full extension carries the most foot speed into the ball.",
                                    severity: nil, confidence: 0.9, priority: 0, ruleKey: "swing.fullKneeExtension", relatedObservationID: nil,
                                    evidenceMetricKeys: ["swing.kickingKneeAngleAtContact"]),
            StoredObservationRecord(id: UUID(), kind: .cue, category: .plant, message: "Drive the plant foot into the ground.",
                                    severity: nil, confidence: 0.8, priority: 0, ruleKey: "plant.unstable", relatedObservationID: improveID,
                                    evidenceMetricKeys: ["plant.footDrift"]),
            StoredObservationRecord(id: improveID, kind: .improve, category: .plant,
                                    message: "Plant foot moved 0.46 torso lengths around estimated contact. A plant foot that slides shifts the hips.",
                                    severity: .moderate, confidence: 0.8, priority: 0, ruleKey: "plant.unstable", relatedObservationID: nil,
                                    evidenceMetricKeys: ["plant.footDrift"]),
        ]
        let findings = GeneralRuleFinding.from(stored: stored)
        #expect(findings.count == 2, "the CUE is folded into its IMPROVE")
        let improve = findings.first { $0.kind == .improve }
        #expect(improve?.observed == "Plant foot moved 0.46 torso lengths around estimated contact.")
        #expect(improve?.whyItMatters == "A plant foot that slides shifts the hips.")
        #expect(improve?.cue == "Drive the plant foot into the ground.")
        #expect(improve?.metric == .plantFootDrift)
        #expect(improve?.severity == .moderate)
        let keep = findings.first { $0.kind == .keep }
        #expect(keep?.metric == .kickingKneeAngleAtContact)
        #expect(keep?.cue == nil)
    }

    @Test func step8FindingsConvertAndSurviveWithoutHistory() {
        var script = SyntheticPose.KickScript.fieldGoal
        script.plantSlip = 0.075
        let result = SyntheticBiomechanics.analyze(script)
        let general = GeneralRuleFinding.from(result.findings)
        #expect(general.count == result.findings.filter(\.issued).count)
        let current = HistoricalKickAnalysis(
            kickID: UUID(), analysisID: UUID(), kickDate: F.date(0), kickType: .fieldGoal, kickingFoot: .right,
            metrics: Dictionary(uniqueKeysWithValues: result.measurements.map {
                ($0.key, HistoricalMetricValue(value: $0.value, confidence: $0.confidence, status: $0.status,
                                               definitionVersion: $0.definitionVersion, cameraAngle: .side))
            })
        )
        let report = PersonalizedCoach.coach(PersonalCoachingInput(
            analysisID: F.analysisID, current: current, generalFindings: general, profile: nil, usedDistanceProfile: false,
            generalProfile: .standard(for: .fieldGoal), configuration: PersonalizationConfiguration()))
        let improves = general.filter { $0.kind == .improve }.map(\.ruleKey)
        #expect(report.primaryFixes.compactMap(\.generalRuleKey) == improves, "with no history the Step 8 ranking is unchanged")
        #expect(report.findings.compactMap(\.generalRuleKey).sorted() == general.map(\.ruleKey).sorted(), "every Step 8 observation is kept")
    }
}
