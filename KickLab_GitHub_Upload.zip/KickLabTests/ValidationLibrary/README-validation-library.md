# Private contact validation library

This folder holds **real, human-annotated reference clips** for checking KickLab's
automatic contact estimate (`ContactValidationHarness`). It is empty on purpose: KickLab
has **not** yet been validated on real athletes.

## What a clip is

One JSON file per recording, `kind: "kicklab.contact-reference"`, format version 1
(`ContactReferenceClip`):

- the stored Vision pose sequence (body coordinates for every analyzed frame — **no video
  frames or images**);
- kick type, kicking foot and camera angle;
- the source frame rate;
- the reviewer-marked contact time and the reviewer's uncertainty (normally ±1 frame);
- the reviewer's role (not a name) and a rights note.

The annotation is used **only** to measure error after the automatic estimate is made.
Analysis never reads it.

## Adding a clip

1. On the iPhone, analyze the video with the current build.
2. Turn on diagnostics: Profile → Developer → Analysis diagnostics.
3. Open **Pose Validation**, step frame by frame to the frame where the foot meets the
   ball, and tap **Mark This Frame as Contact**.
4. On the **Diagnostics** screen, tap **Export Pose for Validation…**. Confirm that you
   have permission, then share the file.
5. Give the file a neutral name (for example `fg-side-30fps-001.json`) and add it here.
   Never use athlete names in file names or IDs.
6. Run the tests. `thePrivateValidationLibraryIsEvaluatedWhenPresent` prints, for each
   clip:
   - the signed and absolute error, in milliseconds and in analyzed frames;
   - mean, median and 90th-percentile error;
   - the share of clips within 1, 2 and 3 frames;
   - unavailable estimates;
   - confidence calibration.

## Rights and permission

Add a recording only when the athlete has agreed — or a parent or guardian, for a minor —
and you have the right to use it. College and professional kickers' recordings need the
athlete's written permission and the recording owner's permission (team, school or
videographer). Record this in `rightsNote`.

Pose files contain body motion, so keep this library in a **private** repository and out of
public bug reports.

Have a second person independently re-mark contact on a sample of clips to estimate
annotation error.
