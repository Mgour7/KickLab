#if canImport(AVFoundation) && canImport(Vision) && canImport(CoreML)
import AVFoundation
import CoreVideo
import Foundation
import Testing
@testable import KickLab

/// Generates small test videos on the fly with AVAssetWriter: a plain gray frame, no
/// people, no real footage. Used to exercise the real AVFoundation and Vision code paths.
enum FixtureVideo {
    struct WriteError: Error {
        let message: String
    }

    static func writeGrayVideo(
        to url: URL,
        frameCount: Int,
        framesPerSecond: Int32,
        width: Int = 160,
        height: Int = 120,
        transform: CGAffineTransform = .identity
    ) async throws {
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [AVVideoAllowFrameReorderingKey: false],
        ])
        input.expectsMediaDataInRealTime = false
        input.transform = transform
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
        ])
        guard writer.canAdd(input) else { throw WriteError(message: "can't add input") }
        writer.add(input)
        guard writer.startWriting() else { throw WriteError(message: writer.error?.localizedDescription ?? "can't start") }
        writer.startSession(atSourceTime: .zero)

        for index in 0..<frameCount {
            while !input.isReadyForMoreMediaData {
                try await Task.sleep(nanoseconds: 2_000_000)
            }
            var buffer: CVPixelBuffer?
            CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, nil, &buffer)
            guard let buffer else { throw WriteError(message: "can't create pixel buffer") }
            CVPixelBufferLockBaseAddress(buffer, [])
            if let base = CVPixelBufferGetBaseAddress(buffer) {
                memset(base, 0x80, CVPixelBufferGetDataSize(buffer))
            }
            CVPixelBufferUnlockBaseAddress(buffer, [])
            guard adaptor.append(buffer, withPresentationTime: CMTime(value: Int64(index), timescale: framesPerSecond)) else {
                throw WriteError(message: writer.error?.localizedDescription ?? "append failed")
            }
        }
        input.markAsFinished()
        await writer.finishWriting()
        guard writer.status == .completed else {
            throw WriteError(message: writer.error?.localizedDescription ?? "finish failed")
        }
    }
}

/// Thread-safe frame counter.
final class FrameCounter: @unchecked Sendable {
    private let lock = NSLock()
    private var count = 0

    /// Increments and returns the new count.
    func increment() -> Int {
        lock.lock()
        defer { lock.unlock() }
        count += 1
        return count
    }

    var value: Int {
        lock.lock()
        defer { lock.unlock() }
        return count
    }
}

/// Requires Xcode: runs the real AVFoundation reader and Vision request on generated
/// fixture videos. The fixtures contain no person, so no pose may be reported.
@Suite("Pose runtime (AVFoundation + Vision)")
struct PoseRuntimeTests {
    private func fixture(_ temp: TemporaryDirectory, frames: Int = 30, fps: Int32 = 30,
                         transform: CGAffineTransform = .identity) async throws -> URL {
        let url = temp.url.appendingPathComponent("fixture-\(UUID().uuidString).mov")
        try await FixtureVideo.writeGrayVideo(to: url, frameCount: frames, framesPerSecond: fps, transform: transform)
        return url
    }

    @Test func trackInfoReadsSizeRateAndOrientation() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let plain = try await VideoFrameReader.trackInfo(for: try await fixture(temp))
        #expect(plain.naturalWidth == 160)
        #expect(plain.naturalHeight == 120)
        #expect(plain.orientation == .up)
        #expect(!plain.isMirrored)
        #expect(near(plain.durationSeconds, 1, 0.05))
        let landscapeAspect: Double = 160.0 / 120.0
        #expect(near(plain.displayAspectRatio, landscapeAspect, 1e-9))

        let portrait = try await VideoFrameReader.trackInfo(
            for: try await fixture(temp, frames: 5, transform: CGAffineTransform(a: 0, b: 1, c: -1, d: 0, tx: 120, ty: 0))
        )
        #expect(portrait.orientation == .right)
        let portraitAspect: Double = 120.0 / 160.0
        #expect(near(portrait.displayAspectRatio, portraitAspect, 1e-9))
    }

    @Test func readerDeliversEveryFrameWithTrueTimestamps() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let url = try await fixture(temp, frames: 30, fps: 30)
        var times: [Double] = []
        var indices: [Int] = []
        let count = try await VideoFrameReader.read(url: url, plan: .everyFrame) { index, time, buffer in
            indices.append(index)
            times.append(time)
            #expect(CVPixelBufferGetWidth(buffer) == 160)
        }
        #expect(count == 30)
        #expect(indices == Array(0..<30))
        for (i, t) in times.enumerated() {
            let expected: Double = Double(i) / 30.0
            #expect(near(t, expected, 0.002))
        }
    }

    @Test func readerSamplesHighFrameRateByTime() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        // 0.5 s at 240 fps, analyzed at 60 fps → every 4th frame.
        let url = try await fixture(temp, frames: 120, fps: 240)
        var times: [Double] = []
        try await VideoFrameReader.read(url: url, plan: .standard) { _, time, _ in times.append(time) }
        #expect(times.count == 30)
        let secondKept: Double? = times.dropFirst().first
        let expectedSecond: Double = 4.0 / 240.0
        #expect(near(secondKept, expectedSecond, 0.002))

        var ranged: [Double] = []
        try await VideoFrameReader.read(url: url, plan: FrameSamplingPlan(rate: .everyFrame, timeRange: 0.25...0.3)) { _, time, _ in
            ranged.append(time)
        }
        #expect(!ranged.isEmpty)
        let rangeStart: Double = 0.25 - 1e-3
        let rangeEnd: Double = 0.3 + 1e-3
        let allInRange: Bool = ranged.allSatisfy { (time: Double) -> Bool in time >= rangeStart && time <= rangeEnd }
        #expect(allInRange)
    }

    @Test func readerStopsWhenCancelled() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let url = try await fixture(temp, frames: 60, fps: 30)
        let counter = FrameCounter()
        // The reading task cancels itself after the third frame.
        let task = Task {
            try await VideoFrameReader.read(url: url, plan: .everyFrame) { _, _, _ in
                if counter.increment() == 3 { withUnsafeCurrentTask { $0?.cancel() } }
            }
        }
        let result = await task.result
        #expect(throws: CancellationError.self) { try result.get() }
        #expect(counter.value == 3, "no frames are delivered after cancellation")
    }

    // MARK: Vision
    //
    // Vision's pose model may be unable to run in the iOS Simulator. These tests accept
    // exactly two outcomes, decided by the runtime probe, never by error text:
    //  1. Vision is available → it executes on every frame and finds no people.
    //  2. Vision is unavailable (allowed ONLY in the simulator) → the typed
    //     runtime-unavailable error is thrown, and no frames, poses or artifacts exist.
    // On a real device, unavailable is a test failure.

    @Test func runtimeProbeIsDeterministicAndDeviceMustBeAvailable() {
        let first = VisionPoseSequenceExtractor.probeRuntime()
        let second = VisionPoseSequenceExtractor.probeRuntime()
        #expect(first == second, "the probe gives the same answer every time")
        switch first.status {
        case .available:
            break
        case .unavailable(let environment):
            #expect(environment == .simulator, "Vision must run on a real device")
            #expect(VisionPoseSequenceExtractor.environment == .simulator)
        }
        if VisionPoseSequenceExtractor.environment == .device {
            #expect(first.status == .available)
            #expect(first.usesCPUOnly == false, "real devices use the standard configuration")
        }
    }

    @Test func visionRunsOnFramesWithoutInventingPeople() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let url = try await fixture(temp, frames: 10, fps: 30)
        let videoID = UUID()
        let probe = VisionPoseSequenceExtractor.probeRuntime()

        let outcome: Result<PoseSequence, any Error>
        do {
            let sequence = try await VisionPoseSequenceExtractor().extract(
                videoURL: url, videoID: videoID, sampling: .everyFrame, progress: { _ in }
            )
            outcome = .success(sequence)
        } catch {
            outcome = .failure(error)
        }

        switch (probe.status, outcome) {
        case (.available, .success(let sequence)):
            #expect(sequence.videoID == videoID)
            #expect(sequence.frames.count == 10)
            #expect(sequence.frames.allSatisfy { $0.status == .analyzed }, "the Vision request executed on every frame")
            #expect(sequence.frames.allSatisfy { $0.bodies.isEmpty }, "a gray frame contains no person")
            #expect(sequence.orientation == .up)
            let expectedAspect: Double = 160.0 / 120.0
            #expect(near(sequence.displayAspectRatio, expectedAspect, 1e-9))
        case (.unavailable(let environment), .failure(let error)):
            #expect(environment == .simulator, "only the simulator may lack Vision")
            #expect(error as? PoseDetectionError == .runtimeUnavailable(environment: .simulator),
                    "a typed limitation, not per-frame failures; no pose data is returned")
        default:
            Issue.record("Probe (\(probe.status)) and extraction (\(outcome)) disagree")
        }
    }

    @Test func engineOnRealVideoWritesArtifactsOrReportsRuntimeLimitation() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        let kickID = UUID(), videoID = UUID()
        let path = ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: "mov")
        let destination = try store.url(for: path, in: .media)
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        try await FixtureVideo.writeGrayVideo(to: destination, frameCount: 15, framesPerSecond: 30)

        let engine = PoseVideoAnalysisService(mediaStore: store, extractor: VisionPoseSequenceExtractor())
        let request = VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [
            VideoAnalysisInput(videoID: videoID, angle: .side, isPrimary: true, relativeFilePath: path,
                               frameRate: 30, durationSeconds: 0.5, syncOffsetSeconds: nil, contactTimeSeconds: nil),
        ])
        let probe = VisionPoseSequenceExtractor.probeRuntime()

        switch probe.status {
        case .available:
            let result = try await engine.analyze(request) { _ in }
            #expect(result.poseSummary?.kickerStatus == .noCandidates)
            #expect(result.poseSummary?.estimatedContactTime == nil)
            #expect(result.metrics.isEmpty)
            let bundle = try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL)
                .readBundle(in: try #require(result.artifactsRelativePath))
            #expect(bundle.pose.sequence.frames.count == 15)
            #expect(bundle.pose.sequence.frames.allSatisfy { $0.bodies.isEmpty })
        case .unavailable(let environment):
            #expect(environment == .simulator, "only the simulator may lack Vision")
            await #expect(throws: VideoAnalysisError.poseDetectionUnavailable(environment: .simulator)) {
                _ = try await engine.analyze(request) { _ in }
            }
            let written = LocalMediaFileSystem().regularFiles(under: store.analysisRootURL)
            #expect(written.isEmpty, "no pose data, metrics or artifacts are produced")
        }
    }
}
#endif
