import Foundation
import Testing
@testable import KickLab

/// Build 22: recognizing the kicked ball without a detector (`StrikeSiteBallFinder`).
/// SYNTHETIC scenes with known geometry (pure; Linux). The real-footage results are in
/// Docs/BALL_RECOGNITION_BUILD22.md (emulation, not the iPhone app).
@Suite("Build 22: kicked ball recognized from image change")
struct StrikeSiteBallTests {
    static let size = 160
    static let fps = 30.0
    /// Ball center and radius (pixels), the frame the ball leaves, and frame count.
    static let ball = (x: 100, y: 110, r: 7)
    static let departFrame = 60
    static let frameCount = 100
    /// Torso length in pixels (the region is the whole 160×160 frame, aspect 1).
    static let torsoPx = 30.0

    struct Scene {
        var kickSpeedTorsoPerSecond = 30.0
        var ballLeaves = true
        var cameraDriftPerFrame = 0.0
    }

    /// Textured static background (seeded), a bright ball until it leaves, a dark kicker
    /// body that walks in from the left and stays left of the ball, small per-frame noise.
    static func frames(_ scene: Scene) -> [StrikeSiteFrame] {
        var rng = SeededGenerator(seed: 7)
        let n = size
        var background = [Int](repeating: 0, count: n * n)
        for i in background.indices { background[i] = 90 + Int.random(in: -25...25, using: &rng) }
        return (0..<frameCount).map { f in
            var px = [UInt8](repeating: 0, count: n * n)
            let drift = Int((scene.cameraDriftPerFrame * Double(f)).rounded())
            for y in 0..<n {
                for x in 0..<n {
                    let sx = min(n - 1, max(0, x + drift))
                    var v = background[y * n + sx] + Int.random(in: -3...3, using: &rng)
                    // Ball (moves with the scene under camera drift).
                    let bx = ball.x - drift
                    if !scene.ballLeaves || f < departFrame {
                        if (x - bx) * (x - bx) + (y - ball.y) * (y - ball.y) <= ball.r * ball.r { v = 220 }
                    }
                    // Kicker's body: a dark column whose right edge reaches 12 px left of the ball.
                    let bodyRight = min(ball.x - 12, 20 + f) - drift
                    if x >= bodyRight - 24 && x <= bodyRight && y >= 30 && y <= 125 { v = 40 }
                    px[y * n + x] = UInt8(min(255, max(0, v)))
                }
            }
            return StrikeSiteFrame(time: Double(f) / fps, image: LumaImage(width: n, height: n, pixels: px))
        }
    }

    /// Pose: plant ankle by the ball; the kicking ankle swings through the ball at the
    /// departure frame at `kickSpeed` torso lengths/s (slow when the ball is just taken away).
    static func pose(_ scene: Scene) -> [StrikeSitePoseSample] {
        let n = Double(size)
        return (0..<frameCount).map { f in
            let t = Double(f) / fps
            let bodyRight = Double(min(ball.x - 12, 20 + f))
            let dt = Double(f - departFrame) / fps
            // Kicking ankle: passes the ball center at the departure frame along +x.
            let kx = Double(ball.x) + scene.kickSpeedTorsoPerSecond * torsoPx * dt
            let kxClamped = f < departFrame - 8 ? bodyRight - 5 : min(n - 2, max(bodyRight - 5, kx))
            return StrikeSitePoseSample(
                time: t,
                kickingAnkle: NormalizedPoint(x: kxClamped / n, y: Double(ball.y) / n),
                plantAnkle: NormalizedPoint(x: (bodyRight - 3) / n, y: Double(ball.y + 8) / n),
                body: NormalizedRect(minX: (bodyRight - 24) / n, minY: 30 / n, maxX: bodyRight / n, maxY: 125 / n),
                torso: torsoPx / n)
        }
    }

    static let region = NormalizedRect(minX: 0, minY: 0, maxX: 1, maxY: 1)

    @Test func aBallThatLeavesAsTheFootSwingsThroughIsFoundAndTimed() throws {
        let scene = Scene()
        let r = try #require(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1))
        // Found where it rested…
        #expect(abs(r.center.x * 160 - Double(Self.ball.x)) <= 3, "x \(r.center.x * 160)")
        #expect(abs(r.center.y * 160 - Double(Self.ball.y)) <= 3, "y \(r.center.y * 160)")
        // …last seen on the frame before it left, gone on the departure frame.
        #expect(abs(r.lastPresentTime - Double(Self.departFrame - 1) / Self.fps) < 1e-6, "last \(r.lastPresentTime)")
        #expect(abs(r.firstGoneTime - Double(Self.departFrame) / Self.fps) < 1e-6, "gone \(r.firstGoneTime)")
        #expect(r.swingAtDeparture >= StrikeSiteBallFinder.minimumSwingSpeed)
        #expect(r.footDistanceAtDeparture <= StrikeSiteBallFinder.maximumFootDistance)
    }

    @Test func aBallTakenAwayWithoutAFastFootIsNotAKick() {
        // Same picture, but no foot moves fast near the ball (picked up, rolled away).
        let scene = Scene(kickSpeedTorsoPerSecond: 2)
        #expect(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1) == nil)
    }

    @Test func theSearchExplainsWhyNothingPassed() {
        // Build 22: device diagnostics need the reason, not just "no ball".
        let slow = Scene(kickSpeedTorsoPerSecond: 2)
        let r = StrikeSiteBallFinder.findWithReport(frames: Self.frames(slow), region: Self.region, pose: Self.pose(slow), aspect: 1)
        #expect(r.result == nil)
        #expect(r.report.contains("none passed the kick check"), "\(r.report)")
        #expect(r.report.contains("foot ≥ 10 torso lengths/s"), "\(r.report)")
        let ok = StrikeSiteBallFinder.findWithReport(frames: Self.frames(Scene()), region: Self.region, pose: Self.pose(Scene()), aspect: 1)
        #expect(ok.result != nil && ok.report.contains("ball left at 2.000 s"), "\(ok.report)")
        // The note reaches the track (and the diagnostics) when nothing was found.
        var raw = Self.rawEvidence(nil)
        raw.strikeSiteCheck = r.report
        #expect(FootballTrackAnalyzer.analyze(raw: raw, detector: .yoloxS).note.contains("Image-change check at the strike spot: "))
    }

    @Test func aViewFromBehindAcceptsASlowerImageSwing() throws {
        // Build 23: from behind, the foot's image speed is a fraction of the real one
        // (device: 6.4 torso lengths/s at a real strike). 7 torso lengths/s at the ball:
        let scene = Scene(kickSpeedTorsoPerSecond: 7)
        #expect(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1) == nil,
                "side-view minimum (10)")
        let r = try #require(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1,
                                                       minimumSwing: StrikeSiteBallFinder.depthViewMinimumSwingSpeed))
        #expect(abs(r.firstGoneTime - Double(Self.departFrame) / Self.fps) < 1e-6)
        // A ball taken away with no swing at all is still not a kick.
        let still = Scene(kickSpeedTorsoPerSecond: 2)
        #expect(StrikeSiteBallFinder.find(frames: Self.frames(still), region: Self.region, pose: Self.pose(still), aspect: 1,
                                          minimumSwing: StrikeSiteBallFinder.depthViewMinimumSwingSpeed) == nil)
    }

    @Test func aBallThatNeverLeavesIsNotAKick() {
        let scene = Scene(ballLeaves: false)
        #expect(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1) == nil)
    }

    @Test func aSlowlyPanningCameraIsFollowed() throws {
        // 0.15 px per frame → 15 px of drift over the clip.
        let scene = Scene(cameraDriftPerFrame: 0.15)
        let r = try #require(StrikeSiteBallFinder.find(frames: Self.frames(scene), region: Self.region, pose: Self.pose(scene), aspect: 1))
        #expect(abs(r.firstGoneTime - Double(Self.departFrame) / Self.fps) <= 1 / Self.fps + 1e-6, "gone \(r.firstGoneTime)")
    }

    // MARK: Into the football track

    static func rawEvidence(_ site: StrikeSiteBallResult?) -> FootballRawEvidence {
        var raw = FootballRawEvidence(scanTimes: [0, 0.2, 0.4], broadScan: [], precisionTimes: nil, precision: nil,
                                      appearanceTimes: [], appearanceScores: [], cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [],
                                      camera: nil, strikeStart: nil, strikeEnd: nil, ankle: [], aspect: 16.0 / 9, duration: 3)
        raw.strikeSite = site
        return raw
    }

    static let site = StrikeSiteBallResult(center: NormalizedPoint(x: 0.87, y: 0.68), width: 0.03, height: 0.07,
                                           lastPresentTime: 1.966667, firstGoneTime: 2.0, firstClearTime: 2.0,
                                           swingAtDeparture: 32, footDistanceAtDeparture: 0.2, presentFraction: 1, score: 9,
                                           framesExamined: 120, region: NormalizedRect(minX: 0.5, minY: 0.3, maxX: 1, maxY: 0.9))

    @Test func theTrackUsesTheStrikeSiteBallWhenTheDetectorFoundNothing() throws {
        let track = FootballTrackAnalyzer.analyze(raw: Self.rawEvidence(Self.site), detector: .yoloxS)
        #expect(track.method == .automaticStrikeSite)
        #expect(track.method.isAutomatic)
        let bounds = try #require(track.contactBounds)
        #expect(bounds.afterTime == 1.966667 && bounds.byTime == 2.0)
        #expect(track.rest?.cx == 0.87)
        let ball = try #require(AutomaticBallContact(track))
        #expect(ball.footVerifiedAtDeparture == true)
        #expect(ball.detectorName == FootballAnalysisMethod.strikeSiteName)
        // Rear/front-view plant placement can use the ball's position.
        #expect(FootballTrack.kickedBallRest(track) != nil)
    }

    @Test func withoutAStrikeSiteNothingChanges() {
        let track = FootballTrackAnalyzer.analyze(raw: Self.rawEvidence(nil), detector: .yoloxS)
        #expect(track.method == .ballUnavailable)
        #expect(AutomaticBallContact(track) == nil)
    }

    @Test func rawEvidenceRoundTripsAndOlderBundlesStillDecode() throws {
        let raw = Self.rawEvidence(Self.site)
        let data = try JSONEncoder().encode(raw)
        #expect(try JSONDecoder().decode(FootballRawEvidence.self, from: data) == raw)
        // A Build 15–21 bundle has no "strikeSite" key.
        var object = try #require(try JSONSerialization.jsonObject(with: data) as? [String: Any])
        object.removeValue(forKey: "strikeSite")
        let old = try JSONSerialization.data(withJSONObject: object)
        #expect(try JSONDecoder().decode(FootballRawEvidence.self, from: old).strikeSite == nil)
        // A Build 21 AutomaticBallContact (no footVerifiedAtDeparture) still decodes.
        let contact = AutomaticBallContact(lastStationaryTime: 1, firstMovementTime: 1.1, basis: "x", detectorName: "d")
        var c = try #require(try JSONSerialization.jsonObject(with: JSONEncoder().encode(contact)) as? [String: Any])
        c.removeValue(forKey: "footVerifiedAtDeparture")
        #expect(try JSONDecoder().decode(AutomaticBallContact.self, from: JSONSerialization.data(withJSONObject: c)).footVerifiedAtDeparture == nil)
    }

    // MARK: Side-view anchoring

    @Test func theSideViewAnchorIsTheEarlierMiddleFrameOfTheBallInterval() {
        let times = (0..<90).map { Double($0) / 30 }
        var speed = [Double?](repeating: 1, count: 90)
        for i in 58...62 { speed[i] = 20 }
        let ball = AutomaticBallContact(lastStationaryTime: times[59], firstMovementTime: times[60], basis: StrikeSiteBallResult.basis,
                                        detectorName: FootballAnalysisMethod.strikeSiteName)
        #expect(KickPhaseDetector.ballAnchorIndex(ball, times: times, kickingSpeed: speed, minimumSpeed: 3) == 59)
        // No kicking-foot swing near the departure → no anchor.
        #expect(KickPhaseDetector.ballAnchorIndex(ball, times: times, kickingSpeed: [Double?](repeating: 1, count: 90), minimumSpeed: 3) == nil)
    }

    // MARK: Region sampling

    @Test func regionSamplingReadsTheDisplayedRegion() throws {
        // A 200×100 stored plane whose luma is x (0…199); upright, unmirrored.
        let image = try #require(LumaThumbnail.region(storedWidth: 200, storedHeight: 100, orientation: .up, isMirrored: false,
                                                      region: NormalizedRect(minX: 0.5, minY: 0, maxX: 1, maxY: 1), width: 50, height: 50,
                                                      luma: { x, _ in UInt8(x) }))
        #expect(image.width == 50 && image.height == 50)
        #expect(abs(Int(image[0, 0]) - 100) <= 2, "left edge of the right half: \(image[0, 0])")
        #expect(abs(Int(image[49, 25]) - 198) <= 2, "right edge: \(image[49, 25])")
    }

    @Test func theRegionCoversTheFeetAroundTheStrike() throws {
        let pose = Self.pose(Scene())
        let region = try #require(StrikeSiteBallFinder.region(pose: pose, around: [2.0], aspect: 1))
        #expect(region.contains(NormalizedPoint(x: Double(Self.ball.x) / 160, y: Double(Self.ball.y) / 160)))
        let px = StrikeSiteBallFinder.pixelSize(of: region, aspect: 1)
        #expect(max(px.width, px.height) == StrikeSiteBallFinder.regionLongSide)
    }
}

/// Deterministic random numbers for synthetic scenes.
struct SeededGenerator: RandomNumberGenerator {
    var state: UInt64
    init(seed: UInt64) { state = seed &* 0x9E37_79B9_7F4A_7C15 | 1 }
    mutating func next() -> UInt64 {
        state ^= state << 13
        state ^= state >> 7
        state ^= state << 17
        return state
    }
}
