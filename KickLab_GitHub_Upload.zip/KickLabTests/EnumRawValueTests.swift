import Testing
@testable import KickLab

/// Freezes every persisted raw value (invariant G1). If one of these fails, a stored
/// string was renamed or removed — that would orphan existing data. Add new cases
/// by appending to the expected list; never edit an existing entry.
@MainActor
@Suite("Enum raw values are frozen")
struct EnumRawValueTests {
    @Test func kickType() {
        #expect(KickType.allCases.map(\.rawValue) == ["fieldGoal", "pat", "kickoff", "punt", "unknown"])
        #expect(KickType.selectableCases == [.fieldGoal, .pat, .kickoff, .punt])
    }

    @Test func kickContext() {
        #expect(KickContext.allCases.map(\.rawValue) == ["training", "game", "camp", "competition", "warmup"])
    }

    @Test func hashLocation() {
        #expect(HashLocation.allCases.map(\.rawValue) == ["left", "center", "right", "notApplicable"])
    }

    @Test func kickResult() {
        #expect(KickResult.allCases.map(\.rawValue) == ["made", "missedLeft", "missedRight", "short", "blocked", "unknown"])
    }

    @Test func landingZone() {
        #expect(LandingZone.allCases.map(\.rawValue) == ["left", "middle", "right", "unknown"])
    }

    @Test func playingLevel() {
        #expect(PlayingLevel.allCases.map(\.rawValue) == ["youth", "middleSchool", "highSchool", "college", "professional", "other"])
    }

    @Test func outcomeMeasurementSource() {
        #expect(OutcomeMeasurementSource.allCases.map(\.rawValue) == ["manual", "primaryVideo", "secondaryVideo", "multiVideo", "imported", "unknown"])
    }

    @Test func kickingSessionType() {
        #expect(KickingSessionType.allCases.map(\.rawValue) == ["training", "game", "camp", "competition", "warmup"])
    }

    @Test func kickingFoot() {
        #expect(KickingFoot.allCases.map(\.rawValue) == ["right", "left"])
    }

    @Test func videoEnums() {
        #expect(VideoAngleType.allCases.map(\.rawValue) == ["side", "rear", "front", "behindGoal", "unknown"])
        #expect(VideoSourceType.allCases.map(\.rawValue) == ["captured", "photosImport", "filesImport", "unknown"])
        #expect(VideoStorageStatus.allCases.map(\.rawValue) == ["local", "photosLibrary", "offloaded", "missing"])
        #expect(ContactTimeSource.allCases.map(\.rawValue) == ["manual", "detected", "unknown"])
    }

    @Test func analysisEnums() {
        #expect(ProcessingStatus.allCases.map(\.rawValue) == ["queued", "processing", "completed", "failed", "cancelled", "unknown"])
        #expect(MeasurementStatus.allCases.map(\.rawValue) == ["measured", "estimated", "unavailable"])
        #expect(AnalysisCategory.allCases.map(\.rawValue) == ["setup", "approach", "plant", "swing", "contact", "followThrough", "overall", "unknown"])
        #expect(MechanicsPhase.allCases.map(\.rawValue) == ["setup", "approach", "plant", "swing", "contact", "followThrough", "overall", "unknown"])
        #expect(MetricUnit.allCases.map(\.rawValue) == [
            "unitless", "inches", "centimeters", "meters", "yards", "degrees", "degreesPerSecond",
            "metersPerSecond", "milesPerHour", "seconds", "milliseconds", "ratio", "percent", "unknown",
        ])
        #expect(ObservationKind.allCases.map(\.rawValue) == ["keep", "improve", "cue", "unknown"])
        #expect(ObservationKind.selectableCases == [.keep, .improve, .cue])
        #expect(CoachingSeverity.allCases.map(\.rawValue) == ["info", "low", "moderate", "high"])
        #expect(ComparisonBasis.allCases.map(\.rawValue) == ["absolute", "personalMakes", "personalBest", "referenceGroup", "unknown"])
        #expect(ObservationSource.allCases.map(\.rawValue) == ["engine", "coach", "athlete", "unknown"])
    }

    // MARK: Fallback behavior for strings written by a newer app version

    @Test func unrecognizedValuesFallBackInsteadOfCrashing() {
        #expect(KickType(storedValue: "onsideKick") == .unknown)
        #expect(KickResult(storedValue: "doink") == .unknown)
        #expect(MeasurementStatus(storedValue: "guessed") == .unavailable)
        #expect(VideoStorageStatus(storedValue: "teleported") == .missing)
        #expect(OutcomeMeasurementSource(storedValue: "radar") == .unknown)
        #expect(PlayingLevel(storedValue: "ncaaD1") == .other)
    }

    @Test func optionalStoredValues() {
        #expect(LandingZone(optionalStoredValue: nil) == nil)
        #expect(LandingZone(optionalStoredValue: "left") == .left)
        #expect(LandingZone(optionalStoredValue: "deepLeft") == .unknown)
    }

    @Test func manualSourceNeverAllowsConfidence() {
        #expect(OutcomeMeasurementSource.manual.allowsConfidence == false)
        for source in OutcomeMeasurementSource.allCases where source != .manual {
            #expect(source.allowsConfidence)
        }
    }
}
