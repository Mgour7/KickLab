import Foundation
import Testing
@testable import KickLab

/// Step 12E: the six outcome classes, from engine runs and from stored analyses.
@Suite("Analysis outcome classes")
struct AnalysisOutcomeTests {
    @Test func engineRunsAreClassifiedByWhatTheyProduced() {
        let side = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side))
        #expect(side.outcome == .fullySupported)
        #expect(PoseAnalysisSummary(primaryVideoID: UUID(), output: side).outcome == .fullySupported)

        // Step 12G: from behind, pose alone gives a strike window; with a verified contact
        // the same clip gives measurements without a score.
        #expect(DepthViewSynthetic.run(DepthViewSynthetic.Script()).outcome == .kickDetectedTimingUncertain, "rear, pose only")
        let s = DepthViewSynthetic.Script()
        #expect(DepthViewSynthetic.run(s, assistance: PhaseDetectionAssistance(contactTime: s.expectedContact)).outcome == .partialMeasurements,
                "rear with a verified contact: measurements, no score")

        var hiddenStrike = DepthViewSynthetic.Script()
        hiddenStrike.kickingAnkleHidden = DepthViewSynthetic.timestamps(hiddenStrike).filter { $0 > 1.49 && $0 < 1.72 }
        #expect(DepthViewSynthetic.run(hiddenStrike).outcome == .kickDetectedTimingUncertain)

        var noSwing = DepthViewSynthetic.Script()
        noSwing.kickingAnkleHidden = DepthViewSynthetic.timestamps(noSwing).filter { $0 > 1.25 && $0 < 2.1 }
        #expect(DepthViewSynthetic.run(noSwing).outcome == .noKickDetected)

        var empty = DepthViewSynthetic.sequence(DepthViewSynthetic.Script())
        for i in empty.frames.indices { empty.frames[i].bodies = [] }
        let nobody = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: empty, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        #expect(nobody.outcome == .insufficientEvidence)

        let twoKicks = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(from: SyntheticPose.concatenated([.fieldGoal, .fieldGoal])),
            kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side))
        #expect(twoKicks.outcome == .kickDetectedTimingUncertain, "several kicks: the user chooses one")
    }

    @Test func storedAnalysesAreClassifiedFromTheirRecord() {
        func of(_ status: ProcessingStatus, _ reason: String?, scored: Int = 0, metrics: Int = 0) -> AnalysisOutcome? {
            AnalysisOutcome.of(status: status, failureReason: reason, scoredCategoryCount: scored, availableMetricCount: metrics)
        }
        #expect(of(.completed, nil, scored: 3, metrics: 12) == .fullySupported)
        #expect(of(.completed, nil, scored: 0, metrics: 3) == .partialMeasurements)
        #expect(of(.failed, AnalysisFailureCause.noCredibleKickWindow.reasonText) == .noKickDetected)
        #expect(of(.failed, AnalysisFailureCause.ambiguousContact.reasonText, metrics: 1) == .kickDetectedTimingUncertain)
        #expect(of(.failed, AnalysisFailureCause.plantUnavailable.reasonText, metrics: 1) == .partialMeasurements,
                "the build-10 rear analysis: one trustworthy metric, kept and shown, never scored")
        #expect(of(.failed, AnalysisFailureCause.legJointsNotVisible.reasonText) == .insufficientEvidence)
        #expect(of(.failed, KickAnalysisRunnerReasons.reason(for: .noCandidates)) == .insufficientEvidence)
        #expect(of(.failed, "The analysis failed: Couldn't save analysis data.") == .technicalFailure)
        #expect(of(.processing, nil) == nil)
        #expect(of(.cancelled, nil) == nil)
    }

    @Test func aFailedAnalysisStillShowsItsTrustworthyMeasurement() {
        var record = AnalysisRecord(
            id: UUID(), kickID: UUID(), kickType: .fieldGoal, kickDate: nil, createdAt: Date(timeIntervalSince1970: 0),
            completedAt: nil, status: .failed, isCurrent: false, overallScore: nil, confidence: nil,
            failureReason: AnalysisFailureCause.plantUnavailable.reasonText, engineVersion: "pose-biomechanics-2.4.0+assisted",
            metrics: [], categories: [], observations: []
        )
        record.metrics = [StoredMetricRecord(key: KickMetricKey.lateralTrunkLeanAtContact.rawValue, value: 9.609, unit: .degrees,
                                             confidence: 0.72, status: .estimated, phase: .contact)]
        let p = AnalysisPresentationBuilder.make(record)
        #expect(p.hasMechanics, "the measurement is displayed")
        #expect(p.header.outcome == .partialMeasurements)
        #expect(p.header.overallScore == nil)
        #expect(p.categories.allSatisfy { $0.score == nil })
        #expect(p.metrics.first { $0.key == .lateralTrunkLeanAtContact }?.value == 9.609)
        #expect(p.metrics.first { $0.key == .lateralTrunkLeanAtContact }?.isAvailable == true)
    }
}
