import Foundation
import Testing
@testable import KickLab

/// Build 22: each Kick Breakdown card's crop around the kicker and its skeleton. Pure (Linux).
@Suite("Build 22: breakdown card framing")
struct KickBreakdownFramesTests {
    /// A standing kicker 0.4 of the frame tall, centered at x, in a 16:9 frame.
    static func sample(_ t: Double, x: Double) -> KickerPoseSample {
        var j: [PoseJoint: PosePoint] = [:]
        j[.nose] = PosePoint(x: x, y: 0.3, confidence: 0.9)
        j[.neck] = PosePoint(x: x, y: 0.36, confidence: 0.9)
        j[.leftShoulder] = PosePoint(x: x - 0.02, y: 0.37, confidence: 0.9)
        j[.rightShoulder] = PosePoint(x: x + 0.02, y: 0.37, confidence: 0.9)
        j[.leftHip] = PosePoint(x: x - 0.015, y: 0.5, confidence: 0.9)
        j[.rightHip] = PosePoint(x: x + 0.015, y: 0.5, confidence: 0.9)
        j[.leftKnee] = PosePoint(x: x - 0.015, y: 0.6, confidence: 0.9)
        j[.rightKnee] = PosePoint(x: x + 0.03, y: 0.6, confidence: 0.9)
        j[.leftAnkle] = PosePoint(x: x - 0.015, y: 0.7, confidence: 0.9)
        j[.rightAnkle] = PosePoint(x: x + 0.05, y: 0.68, confidence: 0.1)  // low confidence: not drawn
        return KickerPoseSample(frameIndex: Int(t * 30), timestamp: t, joints: j)
    }

    static let timeline = KickerPoseTimeline(samples: (0..<90).map { sample(Double($0) / 30, x: 0.2 + Double($0) * 0.005) }, displayAspectRatio: 16.0 / 9)

    @Test func oneZoomForTheKickCenteredOnTheKickerEachTime() throws {
        let frames = PhaseFrameFraming.make(timeline: Self.timeline, times: [1.0, 2.0], contactTime: 2.0, kickingFoot: .right, aspect: 16.0 / 9)
        let a = try #require(frames[1.0]), b = try #require(frames[2.0])
        // Height 1.9 × the kicker's 0.4 → 0.76; 4:3 in display units.
        #expect(abs(a.crop.height - 0.76) < 1e-9 && abs(b.crop.height - 0.76) < 1e-9)
        #expect(abs(a.crop.width * 16 / 9 / a.crop.height - 4.0 / 3) < 1e-9)
        // Each window follows the kicker (x moved 0.15 between the two times).
        #expect(abs((b.crop.minX - a.crop.minX) - 0.15) < 0.01)
        #expect(a.crop.minX >= 0 && b.crop.maxX <= 1 && a.crop.minY >= 0 && a.crop.maxY <= 1)
    }

    @Test func bonesAreInCropCoordinatesWithLegRolesAndConfidence() throws {
        let f = try #require(PhaseFrameFraming.make(timeline: Self.timeline, times: [1.0], contactTime: 1.0, kickingFoot: .right, aspect: 16.0 / 9)[1.0])
        #expect(f.bones.allSatisfy { (0...1).contains($0.from.x) && (0...1).contains($0.from.y) && (0...1).contains($0.to.y) })
        #expect(f.bones.filter { $0.role == .kickingLeg }.count == 1, "right hip–knee; the low-confidence right ankle isn't drawn")
        #expect(f.bones.filter { $0.role == .plantLeg }.count == 2)
        let left = PhaseFrameFraming.make(timeline: Self.timeline, times: [1.0], contactTime: 1.0, kickingFoot: .left, aspect: 16.0 / 9)[1.0]
        #expect(left?.bones.filter { $0.role == .kickingLeg }.count == 2)
    }

    @Test func noPoseNearTheTimeNoFrame() {
        #expect(PhaseFrameFraming.make(timeline: Self.timeline, times: [9.0], contactTime: 1.0, kickingFoot: .right, aspect: 16.0 / 9).isEmpty)
        #expect(PhaseFrameFraming.make(timeline: KickerPoseTimeline(samples: []), times: [1.0], contactTime: 1.0, kickingFoot: .right, aspect: 1).isEmpty)
    }
}
