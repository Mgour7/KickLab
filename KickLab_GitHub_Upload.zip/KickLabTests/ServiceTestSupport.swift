import Foundation
import SwiftData
@testable import KickLab

/// Thrown by an injected save handler to simulate a failed `ModelContext.save()`.
struct SimulatedSaveFailure: Error {}

/// Records media-cleanup calls together with what the database looked like at
/// the moment of each call, so tests can prove cleanup happened only after the save.
final class SpyMediaCleanup: MediaCleanupHandling {
    struct Call {
        let request: MediaCleanupRequest
        /// Value returned by `probe` at call time (e.g. a fetchCount).
        let probeValue: Int
        /// `context.hasChanges` at call time; false means everything was saved.
        let contextHadUnsavedChanges: Bool
    }

    private(set) var calls: [Call] = []
    var probe: () -> Int = { -1 }
    var unsavedChanges: () -> Bool = { false }

    func cleanUp(_ request: MediaCleanupRequest) {
        calls.append(Call(request: request, probeValue: probe(), contextHadUnsavedChanges: unsavedChanges()))
    }
}

/// An in-memory store plus services wired to it. Each test gets a fresh one.
///
/// Records that have no Step 5 service yet (videos are created by the future
/// VideoStorageService) are inserted directly here as test fixtures.
@MainActor
struct ServiceFixture {
    let container: ModelContainer
    let context: ModelContext
    let media = SpyMediaCleanup()

    init() throws {
        container = try ModelContainerFactory.makeContainer(inMemory: true)
        context = container.mainContext
        let context = self.context
        media.unsavedChanges = { context.hasChanges }
    }

    var kicks: KickService { KickService(context: context, mediaCleanup: media) }
    var sessions: KickingSessionService { KickingSessionService(context: context) }
    var athletes: AthleteService { AthleteService(context: context, mediaCleanup: media) }
    var analyses: AnalysisService { AnalysisService(context: context) }

    static let failingSave: ModelSaveHandler = { _ in throw SimulatedSaveFailure() }

    func count<T: PersistentModel>(_ type: T.Type) throws -> Int {
        try context.fetchCount(FetchDescriptor<T>())
    }

    // MARK: Builders (all go through services except videos)

    @discardableResult
    func makeAthlete(_ firstName: String = "Test", level: PlayingLevel = .highSchool) throws -> Athlete {
        try athletes.createAthlete(AthleteProfile(firstName: firstName, lastName: "Kicker", currentPlayingLevel: level))
    }

    @discardableResult
    func makeSession(for athlete: Athlete, type: KickingSessionType = .training, name: String = "Practice") throws -> KickingSession {
        try sessions.createSession(for: athlete, name: name, sessionType: type)
    }

    @discardableResult
    func makeKick(
        for athlete: Athlete,
        in session: KickingSession? = nil,
        draft: KickDraft = .fieldGoal()
    ) throws -> Kick {
        try kicks.createKick(for: athlete, in: session, draft: draft)
    }

    /// Fixture only: inserts a video directly and saves.
    @discardableResult
    func addVideo(to kick: Kick, path: String? = nil, bytes: Int64? = nil) throws -> VideoAsset {
        let video = VideoAsset(angleType: .side, isPrimary: (kick.videos ?? []).isEmpty, storageStatus: .local, relativeFilePath: path)
        context.insert(video)
        video.fileSizeBytes = bytes
        video.kick = kick
        try context.save()
        return video
    }

    /// queued → processing → completed, with an explicit completion time.
    func makeCompletedAnalysis(for kick: Kick, video: VideoAsset, version: String = "1.0.0", completedAt: Date) throws -> BiomechanicsAnalysis {
        let analysis = try analyses.createAnalysis(for: kick, analysisVersion: version, inputVideos: [video])
        try analyses.startProcessing(analysis)
        try analyses.markCompleted(analysis, confidence: 0.9)
        analysis.completedAt = completedAt   // fixture: deterministic recency
        try context.save()
        return analysis
    }
}

extension KickDraft {
    static func fieldGoal(_ result: KickResult = .made, distance: Double = 40) -> KickDraft {
        KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: result, distance: .manual(distance))))
    }

    static func kickoff() -> KickDraft {
        KickDraft(outcome: .kickoff(KickoffOutcome(
            distance: .measured(64.5, from: .primaryVideo, confidence: 0.9),
            landing: .measured(KickoffLanding(yardLine: -2, zone: .middle), from: .multiVideo, confidence: 0.85),
            touchback: true,
            outOfBounds: false,
            hangTime: .measured(4.1, from: .secondaryVideo, confidence: 0.8)
        )))
    }
}
