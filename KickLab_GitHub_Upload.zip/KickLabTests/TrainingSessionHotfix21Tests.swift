import Foundation
import Testing
@testable import KickLab

/// Build 21 hotfix — session playback, session status and sequential recordings.
/// Pure logic only, with SYNTHETIC manifests (no video plays here; AVPlayer playback is
/// checked on the iPhone).
@Suite("Build 21 hotfix: playback, status, recording segments")
struct TrainingSessionHotfix21Tests {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)

    private func session() -> TrainingSessionManifest {
        TrainingSessionEditor.makeSession(athleteID: UUID(), kickingSessionID: UUID(), name: "Test", location: nil,
                                          defaults: SessionKickDetails(kickType: .fieldGoal, distanceYards: 30, hash: .center), now: now)
    }

    /// Two in-app recordings: 0:06 and 0:37, the second started 60 s after the first.
    private func twoRecordings() -> (TrainingSessionManifest, UUID, UUID) {
        var m = session()
        let a = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .recording, now: now)
        TrainingSessionEditor.finalizeSource(&m, id: a.id, duration: 6, frameRate: 60, bytes: 10_000_000, now: now)
        let b = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .recording,
                                                now: now.addingTimeInterval(60))
        TrainingSessionEditor.finalizeSource(&m, id: b.id, duration: 37, frameRate: 60, bytes: 56_000_000, now: now)
        return (m, a.id, b.id)
    }

    // MARK: Sequential recordings are one camera

    @Test func aSecondRecordingOnThisIPhoneIsTheSameCamera() throws {
        let (m, a, b) = twoRecordings()
        let second = try #require(m.source(b))
        #expect(second.cameraGroup == a)
        #expect(m.cameraIDs == [a], "one camera, two recordings")
        #expect(m.isLaterSegment(second) && !m.isLaterSegment(m.source(a)!))
        #expect(second.sync.provenance == .sameCamera, "not 'Not synchronized'")
        #expect(abs(second.sync.offsetSeconds - 60) < 1e-9, "continues camera A's timeline from its start time")
        #expect(second.role == .side)
    }

    @Test func kicksInALaterRecordingAreAnalyzedAndNeverPairedWithTheFirst() throws {
        var (m, a, b) = twoRecordings()
        _ = try TrainingSessionEditor.addManualKick(&m, sourceID: a, contact: 3, now: now)
        _ = try TrainingSessionEditor.addManualKick(&m, sourceID: b, contact: 31, now: now)
        SessionProcessingQueue.enqueueReady(&m)
        #expect(m.candidates.allSatisfy { $0.analysis.status == .queued }, "the second recording's kick isn't held back for sync")
        #expect(MultiCameraSync.pairAutomatically(&m, primarySourceID: a, secondarySourceID: b, now: now) == 0)
        #expect(m.pairs.isEmpty)
    }

    @Test func manifestsWrittenBeforeTheHotfixAreRelabelledWithoutTouchingFiles() throws {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("kl21h-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: base) }
        let store = TrainingSessionStore(baseURL: base)
        var (m, a, b) = twoRecordings()
        // What Build 21 wrote: the second recording as an unsynchronized second camera.
        let i = try #require(m.sources.firstIndex { $0.id == b })
        m.sources[i].cameraGroup = nil
        m.sources[i].sync = .unsynchronized
        // Plus a genuine imported second camera, which must stay unsynchronized.
        let imported = TrainingSessionEditor.addSource(&m, id: UUID(), role: .rear, origin: .imported, fileExtension: "mov", status: .finalized, now: now)
        try store.prepare(m.id)
        try store.save(m)
        // Fake recording files: their bytes must be identical after loading.
        for s in m.sources {
            let url = store.url(session: m.id, relativePath: s.relativePath)
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try Data("video \(s.id)".utf8).write(to: url)
        }
        let loaded = try store.load(m.id)
        #expect(loaded.source(b)?.cameraGroup == a)
        #expect(loaded.source(b)?.sync.provenance == .sameCamera)
        #expect(loaded.source(imported.id)?.sync.provenance == SourceSync.Provenance.none, "a real second camera still needs syncing")
        #expect(loaded.cameraIDs.count == 2)
        for s in m.sources {
            #expect(try Data(contentsOf: store.url(session: m.id, relativePath: s.relativePath)) == Data("video \(s.id)".utf8))
        }
        #expect(loaded.candidates == m.candidates && loaded.marks == m.marks)
    }

    @Test func syncingACameraCarriesItsLaterRecordings() throws {
        var m = session()
        // Camera B imported first (reference), then two recordings on this iPhone.
        _ = TrainingSessionEditor.addSource(&m, id: UUID(), role: .rear, origin: .imported, fileExtension: "mov", status: .finalized, now: now)
        let a1 = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .finalized, now: now)
        let a2 = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .finalized,
                                                 now: now.addingTimeInterval(45))
        #expect(m.source(a2.id)?.sync.provenance == SourceSync.Provenance.none, "its camera isn't synchronized yet")
        MultiCameraSync.setSync(&m, sourceID: a1.id, sync: MultiCameraSync.manualSync(referenceMark: 10, sourceMark: 4, referenceFrameRate: 30,
                                                                                    sourceFrameRate: 60, now: now), now: now)
        let s2 = try #require(m.source(a2.id)?.sync)
        #expect(s2.provenance == .sameCamera)
        #expect(abs(s2.offsetSeconds - (6 + 45)) < 1e-9)
    }

    @Test func manualPairingOffersEveryCameraARecording() throws {
        var (m, a, b) = twoRecordings()
        let rear = TrainingSessionEditor.addSource(&m, id: UUID(), role: .rear, origin: .imported, fileExtension: "mov", status: .finalized, now: now)
        MultiCameraSync.setSync(&m, sourceID: rear.id, sync: MultiCameraSync.manualSync(referenceMark: 91, sourceMark: 20, referenceFrameRate: 60,
                                                                                      sourceFrameRate: 30, now: now), now: now)
        _ = try TrainingSessionEditor.addManualKick(&m, sourceID: a, contact: 3, now: now)
        let inSecond = try TrainingSessionEditor.addManualKick(&m, sourceID: b, contact: 31, now: now)   // shared 91
        let rearKick = try TrainingSessionEditor.addManualKick(&m, sourceID: rear.id, contact: 20, now: now)
        #expect(MultiCameraSync.pairingChoices(m, for: rearKick.id).map(\.id) == [inSecond.id])
        #expect(MultiCameraSync.pairingChoices(m, for: inSecond.id).isEmpty, "camera A's own recordings aren't offered for pairing")
        #expect(MultiCameraSync.pairAutomatically(&m, primarySourceID: b, secondarySourceID: rear.id, now: now) == 1)
    }

    // MARK: Playback

    @Test func everyCandidateCanBeWatchedFromTheOriginalRecording() throws {
        var (m, _, b) = twoRecordings()
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: b, contact: 31, now: now)
        let i = try #require(m.candidates.firstIndex { $0.id == c.id })
        m.candidates[i].status = .needsReview   // not confirmed: still playable
        let plan = try SessionPlaybackPlan.make(m, sourceID: b, candidateID: c.id) { _ in true }.get()
        #expect(plan.relativePath == m.source(b)?.relativePath, "the source recording itself, not a copy")
        #expect(plan.contact == 31)
        #expect(plan.window.lowerBound <= 31 - 3 && plan.window.lowerBound >= 31 - 5, "3–5 s before contact")
        #expect(plan.window.upperBound >= 31 + 2 && plan.window.upperBound <= 37, "2 s+ after, within the 37 s recording")
        #expect(plan.initialTime == plan.window.lowerBound)
        #expect(plan.title.contains("recording 2"))
    }

    @Test func fullRecordingPlaybackCoversTheWholeFile() throws {
        let (m, a, _) = twoRecordings()
        let plan = try SessionPlaybackPlan.make(m, sourceID: a) { _ in true }.get()
        #expect(plan.window == 0...6 && plan.candidateID == nil && plan.contact == nil && plan.frameRate == 60)
    }

    @Test func playbackReportsMissingOrUnfinishedFilesInsteadOfDoingNothing() throws {
        var (m, a, _) = twoRecordings()
        #expect(SessionPlaybackPlan.make(m, sourceID: a) { _ in false } == .failure(.fileMissing))
        #expect(SessionPlaybackPlan.make(m, sourceID: UUID()) { _ in true } == .failure(.unknownSource))
        #expect(SessionPlaybackPlan.make(m, sourceID: a, candidateID: UUID()) { _ in true } == .failure(.unknownCandidate))
        let i = try #require(m.sources.firstIndex { $0.id == a })
        m.sources[i].status = .recording
        #expect(SessionPlaybackPlan.make(m, sourceID: a) { _ in true } == .failure(.stillRecording))
        #expect(!SessionPlaybackPlan.text(.fileMissing).isEmpty)
    }

    @Test func playbackRequestsIdentifyClipAndFullRecordingSeparately() {
        let s = UUID(), src = UUID(), c = UUID()
        let full = SessionPlaybackRequest(sessionID: s, sourceID: src, candidateID: nil)
        let clip = SessionPlaybackRequest(sessionID: s, sourceID: src, candidateID: c)
        #expect(full != clip && full.id != clip.id)
        #expect(full == SessionPlaybackRequest(sessionID: s, sourceID: src, candidateID: nil))
    }

    // MARK: Session status

    @Test func theDeviceScenarioSaysAKickNeedsReviewNotAllProcessed() throws {
        var (m, a, b) = twoRecordings()
        m.processing.scan[a.uuidString] = .done
        m.processing.scan[b.uuidString] = .done
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: b, contact: 31, now: now)
        let i = try #require(m.candidates.firstIndex { $0.id == c.id })
        m.candidates[i].status = .needsReview
        let s = SessionStatus.make(m)
        #expect(s.stage == .awaitingReview)
        #expect(s.awaitingReview == 1 && s.confirmedKicks == 0)
        #expect(s.headline == "1 possible kick needs your review")
        #expect(!s.headline.lowercased().contains("all kicks"))
    }

    @Test func statusDistinguishesEveryStage() throws {
        var m = session()
        #expect(SessionStatus.make(m).stage == .noRecordings)
        let a = TrainingSessionEditor.addSource(&m, id: UUID(), role: .side, origin: .inAppRecording, fileExtension: "mov", status: .recording, now: now)
        #expect(SessionStatus.make(m).stage == .recording)
        TrainingSessionEditor.finalizeSource(&m, id: a.id, duration: 30, frameRate: 60, bytes: 1, now: now)
        #expect(SessionStatus.make(m).stage == .findingKicks)
        m.processing.scan[a.id.uuidString] = .done
        #expect(SessionStatus.make(m).stage == .noKicksDetected)
        let c = try TrainingSessionEditor.addManualKick(&m, sourceID: a.id, contact: 10, now: now)
        #expect(SessionStatus.make(m).stage == .analysisPending)
        let i = try #require(m.candidates.firstIndex { $0.id == c.id })
        m.candidates[i].analysis.status = .done
        m.candidates[i].status = .confirmed
        let done = SessionStatus.make(m)
        #expect(done.stage == .analysisComplete && done.confirmedKicks == 1 && done.headline == "All kicks reviewed and analyzed")
        m.candidates[i].analysis.status = .failed
        #expect(SessionStatus.make(m).headline.contains("couldn't be analyzed"))
        // A rejected candidate doesn't keep the session waiting.
        m.candidates[i].status = .rejected
        #expect(SessionStatus.make(m).stage == .noKicksDetected)
    }
}
