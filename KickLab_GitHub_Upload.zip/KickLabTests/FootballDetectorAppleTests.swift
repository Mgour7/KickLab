#if canImport(CoreML) && canImport(CoreGraphics) && canImport(ImageIO) && canImport(AVFoundation) && canImport(CoreVideo)
import AVFoundation
import CoreGraphics
import CoreML
import CoreVideo
import Foundation
import ImageIO
import Testing
@testable import KickLab

/// Locates this test bundle's resources (the real ball-crop JPEGs in `Fixtures/`).
private final class FootballFixtureBundleToken {}

/// Step 12G (CV rebuild), Apple runtime only: the BUNDLED Core ML football detector on
/// REAL frames. The two fixtures are 384×384 crops around the ball from IMG_1709 (frame 236:
/// ball on the holder; frame 240: ball just kicked). The expected boxes are what
/// onnxruntime finds with the original YOLOX-S ONNX on the same decoded JPEGs
/// (`Scripts/cv/make_1709_fixtures.py`), so these tests check that the Core ML conversion
/// and KickLab's preprocessing/decoding reproduce the reference model.
@Suite("Football detector on Core ML (Apple runtime, real frames)")
struct FootballDetectorAppleTests {
    struct Expected { var cx: Double; var cy: Double; var w: Double; var h: Double; var s: Double }

    /// onnxruntime (fp32) on the decoded fixture JPEGs, coordinates as fractions of the crop.
    static let expected: [Int: Expected] = [
        236: Expected(cx: 0.50015, cy: 0.4925, w: 0.0972, h: 0.15625, s: 0.6657),
        240: Expected(cx: 0.49866, cy: 0.4951, w: 0.08719, h: 0.07955, s: 0.9055),
    ]

    static func fixture(_ frame: Int) throws -> PackedBGRImage {
        let bundle = Bundle(for: FootballFixtureBundleToken.self)
        let url = try #require(bundle.url(forResource: "IMG_1709_f0\(frame)_ballcrop", withExtension: "jpg"), "fixture JPEG in the test bundle")
        let source = try #require(CGImageSourceCreateWithURL(url as CFURL, nil))
        let image = try #require(CGImageSourceCreateImageAtIndex(source, 0, nil))
        let w = image.width, h = image.height
        var rgba = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = rgba.withUnsafeMutableBytes { raw -> Bool in
            guard let context = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                          space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { return false }
            context.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        #expect(drawn)
        var bgr = [UInt8](repeating: 0, count: w * h * 3)
        for i in 0..<(w * h) {
            bgr[3 * i] = rgba[4 * i + 2]
            bgr[3 * i + 1] = rgba[4 * i + 1]
            bgr[3 * i + 2] = rgba[4 * i]
        }
        return PackedBGRImage(width: w, height: h, bytes: bgr)
    }

    @Test func theFootballModelIsBundledAndLoads() throws {
        #expect(CoreMLFootballDetector.modelURL() != nil, "YOLOXSportsBall.mlmodelc must be in the app bundle")
        #expect(CoreMLFootballVideoAnalyzer().isAvailable)
        let detector = try CoreMLFootballDetector.load(computeUnits: .cpuOnly)
        #expect(detector.info == .yoloxS)
    }

    @Test(arguments: [236, 240])
    func coreMLMatchesTheReferenceModelOnARealFrame(frame: Int) throws {
        let detector = try CoreMLFootballDetector.load(computeUnits: .cpuOnly)
        let image = try Self.fixture(frame)
        let region = DisplayRect(x: 0, y: 0, width: Double(image.width), height: Double(image.height))
        let prepared = DetectorInputBuilder.makeInput(source: image, orientation: .up, isMirrored: false, region: region, inputSize: 640)
        let boxes = YOLOXDecoder.displayBoxes(try detector.predict(prepared.input), geometry: prepared.geometry,
                                              displayWidth: Double(image.width), displayHeight: Double(image.height))
        let e = try #require(Self.expected[frame])
        let top = try #require(boxes.first, "the football must be detected on frame \(frame)")
        // fp16 Core ML vs fp32 onnxruntime and different JPEG decoders: small tolerances.
        #expect(abs(top.box.cx - e.cx) < 0.01 && abs(top.box.cy - e.cy) < 0.01, "center \(top.box)")
        #expect(abs(top.box.w - e.w) < 0.02 && abs(top.box.h - e.h) < 0.02, "size \(top.box)")
        #expect(abs(top.score - e.s) < 0.08, "score \(top.score) vs \(e.s)")
    }

    @Test func theDecodedVideoPathFindsTheBall() async throws {
        // The real crop (ball just kicked) written into a short H.264 video, decoded by
        // KickLab's frame reader (4:2:0) and detected through the production path.
        let image = try Self.fixture(240)
        let temp = try TemporaryDirectory()
        let url = temp.url.appendingPathComponent("ballcrop.mov")
        try await Self.writeVideo(image, frames: 3, to: url)
        let info = try await VideoFrameReader.trackInfo(for: url)
        let detector = try CoreMLFootballDetector.load(computeUnits: .cpuOnly)
        var found: [FootballDetection] = []
        let region = DisplayRect(x: 0, y: 0, width: Double(image.width), height: Double(image.height))
        try await VideoFrameReader.read(url: url, plan: FrameSamplingPlan(rate: .everyFrame)) { index, time, buffer in
            guard index == 1 else { return }
            found = try detector.detect(pixelBuffer: buffer, orientation: info.orientation, isMirrored: info.isMirrored,
                                        region: region, time: time, pass: .broadScan)
        }
        let top = try #require(found.first, "no football found after video encoding/decoding")
        #expect(abs(top.box.cx - 0.5) < 0.03 && abs(top.box.cy - 0.5) < 0.03)
        #expect(top.score > 0.4)
    }

    static func writeVideo(_ image: PackedBGRImage, frames: Int, to url: URL) async throws {
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: image.width, AVVideoHeightKey: image.height,
        ])
        input.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: image.width, kCVPixelBufferHeightKey as String: image.height,
        ])
        writer.add(input)
        #expect(writer.startWriting())
        writer.startSession(atSourceTime: .zero)
        for index in 0..<frames {
            while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 2_000_000) }
            var buffer: CVPixelBuffer?
            CVPixelBufferCreate(kCFAllocatorDefault, image.width, image.height, kCVPixelFormatType_32BGRA, nil, &buffer)
            let pixelBuffer = try #require(buffer)
            CVPixelBufferLockBaseAddress(pixelBuffer, [])
            if let base = CVPixelBufferGetBaseAddress(pixelBuffer) {
                let row = CVPixelBufferGetBytesPerRow(pixelBuffer)
                let p = base.assumingMemoryBound(to: UInt8.self)
                for y in 0..<image.height {
                    for x in 0..<image.width {
                        let s = (y * image.width + x) * 3, d = y * row + x * 4
                        p[d] = image.bytes[s]; p[d + 1] = image.bytes[s + 1]; p[d + 2] = image.bytes[s + 2]; p[d + 3] = 255
                    }
                }
            }
            CVPixelBufferUnlockBaseAddress(pixelBuffer, [])
            #expect(adaptor.append(pixelBuffer, withPresentationTime: CMTime(value: Int64(index), timescale: 30)))
        }
        input.markAsFinished()
        await writer.finishWriting()
        #expect(writer.status == .completed)
    }
}
#endif
