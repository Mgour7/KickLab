import Foundation
import Testing
@testable import KickLab

/// Step 12G: the second real rear-camera field goal (IMG_1709.mov).
///
/// Data used, by kind (see `RealVideoClip1709`):
/// - ACTUAL IMAGES: the ball-region luma crops of 41 real frames (ball tracker tests).
/// - REAL VIDEO, DIFFERENT POSE MODEL: MediaPipe landmarks from every real frame (pipeline
///   tests). The app uses Apple Vision on the phone; its numbers differ.
/// - The human references are compared after the fact and never passed to detection.
@Suite("Real video IMG_1709 (second rear clip)")
struct RealVideo1709Tests {
    typealias Clip = RealVideoClip1709
    let frame = 1.0 / 30

    private var crops: [(time: Double, image: LumaImage)] { Clip.ballCrops }
    private var radius: Double { Clip.ballRadiusPixels / Clip.cropDownsample }

    // MARK: Ball movement measured from the real frames

    @Test func theMarkedBallIsSeenLeavingBetween7_902And7_935() throws {
        // The user taps the ball on the frame at 7.302 s (index 8 of the crops).
        let r = BallMotionTracker.analyze(crops, referenceIndex: 8, ballRadius: radius)
        #expect(r.outcome == .departed)
        #expect(r.framesExamined == 41)
        #expect(abs((r.lastAtRestTime ?? 0) - 7.902) < 0.002, "ball untouched in the last frame before impact")
        #expect(abs((r.firstDisturbedTime ?? 0) - 7.935) < 0.002, "foot over the ball, ball still on the holder")
        #expect(abs((r.departureConfirmedTime ?? 0) - 7.935) < 0.002)
        let interval = try #require(r.contactInterval)
        // Frame review: foot on the ball at 7.935 s. The user's provisional interval
        // (7.967–8.000 s) starts one frame later; both are reported, neither is adjusted.
        #expect(interval.contains(Clip.frameReviewFootOnBall))
        #expect(abs(Clip.userContactInterval.lowerBound - interval.upperBound) < frame + 0.002, "within one frame of the user's interval")
        // The device's 2.6.0 answer (7.835 s) is three frames before the ball was touched.
        #expect(Clip.device260Contact < interval.lowerBound - 2 * frame)
    }

    @Test func theResultDoesNotDependOnWhichPreKickFrameIsTapped() {
        for ref in [0, 4, 8, 12, 16, 20] {
            let r = BallMotionTracker.analyze(crops, referenceIndex: ref, ballRadius: radius)
            #expect(r.outcome == .departed && abs((r.firstDisturbedTime ?? 0) - 7.935) < 0.002, "reference \(ref)")
        }
    }

    @Test func framesBeforeTheKickShowABallThatNeverMoved() {
        let before = Array(crops.prefix(20))   // 7.035–7.668 s
        #expect(BallMotionTracker.analyze(before, referenceIndex: 0, ballRadius: radius).outcome == .neverMoved)
    }

    @Test func tappingGrassInsteadOfTheBallIsRefused() {
        // A tap on plain turf: a ball template isn't found at rest, or the patch has no
        // structure. Simulated by flattening the reference frame.
        var flat = crops
        let ref = flat[8].image
        flat[8].image = LumaImage(width: ref.width, height: ref.height, pixels: Array(repeating: 120, count: ref.pixels.count))
        #expect(BallMotionTracker.analyze(flat, referenceIndex: 8, ballRadius: radius).outcome == .notFoundAtRest)
    }

    // MARK: The pipeline on the real motion (MediaPipe pose)

    private func run(_ assistance: PhaseDetectionAssistance? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                          cameraAngle: .rear, assistance: assistance))
    }

    @Test func poseAloneGivesAStrikeWindowNotAFalseContact() throws {
        let out = run()
        #expect(out.perspective?.used == .depthAway)
        let p = out.phases
        #expect(p.evidence?.algorithmVersion == "contact-intelligence-4")
        let c = p.phase(.contact)
        // Primary acceptance: no confident contact at 7.835 s (or anywhere) from pose alone.
        #expect(c.status == .ambiguous, "contact timing uncertain")
        #expect(p.evidence?.contactTimingMethod == "strikeWindow")
        #expect(c.confidence <= ContactIntelligence.strikeWindowConfidence + 1e-9)
        let lo = try #require(p.evidence?.contactEarliestTime), hi = try #require(p.evidence?.contactLatestTime)
        #expect(lo <= Clip.frameReviewFootOnBall && Clip.userContactInterval.upperBound <= hi, "the window holds both human reviews")
        #expect(hi - lo > 2 * ContactTimingCheck.toleranceSeconds, "too wide to call a contact time")
        // Plant: found (it was missing on the device).
        #expect(p.phase(.plant).isAvailable)
        #expect(abs((p.plantTime ?? 0) - 7.868) < 0.002)
        #expect((p.plantTime ?? 99) < lo)
        // Nothing contact-timed is measured; the outcome says so and offers verification.
        for key in [KickMetricKey.plantToContactTime, .followThroughDuration, .lateralTrunkLeanAtContact, .plantFootWidth] {
            #expect(out.biomechanics.measurement(key)?.unavailableReason == .contactTimingUncertain, "\(key)")
        }
        #expect(out.outcome == .kickDetectedTimingUncertain)
        #expect(AssistanceOffer.make(phases: p, engineVersion: "pose-biomechanics-3.0.0") == .chooseContact)
        #expect(out.biomechanics.overallScore == nil)
    }

    @Test func withTheMarkedBallContactComesFromTheFrames() throws {
        let ball = BallMotionTracker.analyze(crops, referenceIndex: 8, ballRadius: radius)
        let out = run(PhaseDetectionAssistance(ballMotion: ball))
        let p = out.phases
        #expect(p.isUserAssisted, "the user located the ball: never automatic accuracy")
        #expect(abs((p.estimatedContactTime ?? 0) - 7.935) < 0.002)
        #expect(p.evidence?.contactProvenance == "ballMotionUserMarked")
        #expect(p.evidence?.contactTimingMethod == "ballMotion")
        #expect(abs((p.evidence?.contactEarliestTime ?? 0) - 7.902) < 0.002)
        #expect(abs((p.plantTime ?? 0) - 7.868) < 0.002, "plant searched independently")
        #expect(out.completionBasis == .measurementsOnly)
        #expect(abs((out.biomechanics.measurement(.plantToContactTime)?.value ?? 0) - 0.067) < 0.005)
        #expect(out.biomechanics.overallScore == nil, "no score from behind, however many phases")
        #expect(AnalysisRunMode(assistance: p.assistance) == .verified(PhaseDetectionAssistance(ballMotion: ball)))
    }

    @Test func aUserPlantFrameIsUsedAndLabeled() {
        let out = run(PhaseDetectionAssistance(contactTime: 7.935, plantTime: 7.835))
        #expect(abs((out.phases.plantTime ?? 0) - 7.835) < 0.002)
        #expect(out.phases.evidence?.plantState == .userSupplied)
        #expect(out.phases.notes.first?.contains("Plant frame chosen by the user") == true)
        // A plant chosen after contact is refused, not used.
        let late = run(PhaseDetectionAssistance(contactTime: 7.935, plantTime: 8.1))
        #expect(late.phases.evidence?.plantState != .userSupplied)
    }

    // MARK: Geometry

    @Test func theCropIsTakenAroundTheBallInTheStoredFrame() throws {
        // IMG_1709 is stored 1920×1080 and displayed rotated (orientation .right).
        let mark = VideoVerification.BallMark(time: 7.302, x: Clip.ballTap.x, y: Clip.ballTap.y, radius: Clip.ballRadiusPixels / 1920)
        let g = try #require(LumaCropGeometry.crop(mark: mark, bufferWidth: 1920, bufferHeight: 1080, orientation: .right,
                                                   isMirrored: false, targetRadius: 8.5))
        #expect(g.cx == 1115 && g.cy == 465, "display (615, 1115) in the stored landscape buffer")
        #expect(g.half == 102 && g.factor == 4 && abs(g.radius - 8.5) < 1e-9)
        // A mark too close to the edge to crop is refused rather than clipped.
        let edge = VideoVerification.BallMark(time: 0, x: 0.01, y: 0.5, radius: 0.02)
        #expect(LumaCropGeometry.crop(mark: edge, bufferWidth: 1920, bufferHeight: 1080, orientation: .right, isMirrored: false, targetRadius: 8) == nil)
        let img = LumaCropGeometry.downsample({ x, _ in UInt8(x % 256) }, x0: 0, y0: 0, size: 8, factor: 4)
        #expect(img.width == 2 && img.pixels == [1, 5, 1, 5])
    }

    @Test func verifiedFramesBecomeAUserAssistedRequestOnlyWhenAsked() {
        var v = VideoVerification()
        #expect(v.assistance(contactTime: nil) == nil, "nothing verified, nothing used")
        v.plant = .frame(time: 7.868)
        v.ballMotion = BallMotionTracker.analyze(Clip.ballCrops, referenceIndex: 8, ballRadius: 8.5)
        let a = v.assistance(contactTime: nil)
        #expect(a?.plantTime == 7.868 && a?.effectiveContactTime == 7.935)
        #expect(v.assistance(contactTime: 7.968)?.ballMotion == nil, "a contact frame the user marked takes precedence")
        v.plant = .cannotTell
        #expect(v.assistance(contactTime: nil)?.plantTime == nil)
        let round = VideoVerification.decode(try! v.encoded())
        #expect(round == v)
    }

    @Test func aTappedDisplayPointMapsBackToTheStoredFrame() {
        for o in VideoOrientation.allCases {
            for mirrored in [false, true] {
                let stored = NormalizedPoint(x: 0.3, y: 0.8)
                var shown = PoseCoordinates.upright(stored, from: o)
                if mirrored { shown.x = 1 - shown.x }
                let back = PoseCoordinates.stored(shown, from: o, isMirrored: mirrored)
                #expect(abs(back.x - 0.3) < 1e-9 && abs(back.y - 0.8) < 1e-9, "\(o) mirrored \(mirrored)")
            }
        }
    }
}

/// Step 12G: SYNTHETIC ball images (test-only): a bright disk on textured turf.
@Suite("Ball tracker on synthetic images")
struct BallMotionSyntheticTests {
    static func image(ball: (x: Double, y: Double)?, second: (x: Double, y: Double)? = nil, occluder: (x: Double, y: Double)? = nil,
                      size: Int = 51, radius: Double = 8, seed: Int = 0) -> LumaImage {
        var px = [UInt8](repeating: 0, count: size * size)
        for y in 0..<size {
            for x in 0..<size {
                var v = 90.0 + 25 * sin(Double(x * 7 + y * 13 + seed % 3)) * cos(Double(y * 5 - x * 3))
                func disk(_ c: (x: Double, y: Double)?, _ value: Double, _ r: Double) {
                    guard let c else { return }
                    let d = hypot(Double(x) - c.x, Double(y) - c.y)
                    if d <= r { v = value - 30 * (d / r) + (Double((x + y) % 4) * 6) }
                }
                disk(ball, 230, radius)
                disk(second, 230, radius)
                disk(occluder, 60, radius * 1.3)
                px[y * size + x] = UInt8(max(0, min(255, v)))
            }
        }
        return LumaImage(width: size, height: size, pixels: px)
    }

    private func frames(_ makes: [LumaImage]) -> [(time: Double, image: LumaImage)] {
        makes.enumerated().map { (Double($0.offset) / 30, $0.element) }
    }

    @Test func aBallThatIsKickedAwayDeparts() {
        let c = (x: 25.0, y: 25.0)
        var seq = (0..<10).map { _ in Self.image(ball: c) }
        seq.append(Self.image(ball: c, occluder: (x: 22, y: 26)))          // foot over the ball
        seq += (1...5).map { k in Self.image(ball: (x: 25 + Double(k) * 9, y: 25 - Double(k) * 6)) }
        let r = BallMotionTracker.analyze(frames(seq), referenceIndex: 0, ballRadius: 8)
        #expect(r.outcome == .departed)
        #expect(abs((r.firstDisturbedTime ?? 0) - 10.0 / 30) < 1e-6)
    }

    @Test func aPassingFootThatDoesNotMoveTheBallIsNotADeparture() {
        let c = (x: 25.0, y: 25.0)
        var seq = (0..<8).map { _ in Self.image(ball: c) }
        seq += (0..<2).map { _ in Self.image(ball: c, occluder: (x: 25, y: 25)) }   // occluded
        seq += (0..<8).map { _ in Self.image(ball: c) }                              // back
        #expect(BallMotionTracker.analyze(frames(seq), referenceIndex: 0, ballRadius: 8).outcome == .unstable)
    }

    @Test func aSpareBallMovingNearbyIsIgnored() {
        // The tapped ball stays; another ball rolls past at the edge of the search area.
        let c = (x: 25.0, y: 25.0)
        let seq = (0..<16).map { k in Self.image(ball: c, second: (x: 4 + Double(k) * 3, y: 6)) }
        #expect(BallMotionTracker.analyze(frames(seq), referenceIndex: 0, ballRadius: 8).outcome == .neverMoved)
    }

    @Test func noisyCameraShakeIsTolerated() {
        let seq = (0..<16).map { k in Self.image(ball: (x: 25 + Double(k % 3) - 1, y: 25 + Double(k % 2)), seed: k) }
        #expect(BallMotionTracker.analyze(frames(seq), referenceIndex: 0, ballRadius: 8).outcome == .neverMoved)
    }
}
