import Foundation
import Testing
@testable import KickLab

/// Builds an available measurement for rule-level tests.
func measured(
    _ key: KickMetricKey,
    _ value: Double,
    confidence: Double = 0.8,
    status: MeasurementStatus = .estimated
) -> KickMetricMeasurement {
    let d = key.definition
    return KickMetricMeasurement(
        key: key, definitionVersion: d.definitionVersion, value: value, unit: d.unit, status: status,
        confidence: confidence, confidenceLevel: ConfidenceLevel(confidence), phase: d.phase,
        sampleTime: 1.4, windowStart: nil, windowEnd: nil, unavailableReason: nil, missingPhase: nil,
        confidenceInputs: nil
    )
}

/// All metrics unavailable except the ones given.
func measurements(_ available: [KickMetricMeasurement]) -> [KickMetricMeasurement] {
    KickMetricKey.allCases.map { key in
        available.first { $0.key == key } ?? .unavailable(key, reason: .missingJoints)
    }
}

@Suite("Biomechanics scoring")
struct BiomechanicsScoringTests {
    let profile = BiomechanicsProfile.standard(for: .fieldGoal)

    @Test func scoreBandIsPiecewiseLinear() {
        let band = ScoreBand(zeroLow: 0, idealLow: 10, idealHigh: 20, zeroHigh: 40)
        #expect(band.score(15) == 100)
        #expect(band.score(10) == 100)
        #expect(band.score(20) == 100)
        #expect(band.score(5) == 50)
        #expect(band.score(30) == 50)
        #expect(band.score(-3) == 0)
        #expect(band.score(99) == 0)
        let open = ScoreBand(zeroLow: nil, idealLow: 0, idealHigh: 0.1, zeroHigh: nil)
        #expect(open.score(-5) == 100)
        #expect(open.score(5) == 100)
        #expect(band.distanceFromIdeal(15) == 0)
        #expect(band.distanceFromIdeal(25) == 5)
        #expect(band.distanceFromIdeal(4) == 6)
    }

    @Test func categoryScoreIsConfidenceWeightedAndExplained() {
        // Plant (provisional-bands-2, engine 3.0.0): drift 0.35 (100 × (0.6−0.35)/0.5 = 50,
        // weight 1.5), knee 115 (100 × (115−95)/40 = 50, weight 1). Plant-to-contact time is
        // reported but no longer scored (no validated criterion for a "good" interval).
        let m = measurements([
            measured(.plantToContactTime, 0.2, confidence: 0.8),
            measured(.plantFootDrift, 0.35, confidence: 0.8),
            measured(.plantKneeAngleAtContact, 115, confidence: 0.6),
        ])
        let plant = KickScorer.scoreCategory(.plant, byKey: Dictionary(uniqueKeysWithValues: m.map { ($0.key, $0) }), profile: profile)
        // Σ w·c·s = 1.5·0.8·50 + 1·0.6·50 = 60 + 30 = 90; Σ w·c = 1.2 + 0.6 = 1.8.
        #expect(plant.score == 50)
        // Confidence = Σ w·c ÷ Σ w = 1.8 ÷ 2.5.
        #expect(plant.confidence == 0.72)
        #expect(plant.status == .estimated)
        #expect(plant.components.map(\.key) == [.plantFootDrift, .plantKneeAngleAtContact])
        #expect(plant.components.map(\.componentScore) == [50, 50])
        #expect(plant.excluded.isEmpty)
        #expect(plant.availableWeightFraction == 1)
        #expect(plant.summary == "Based on 2 of 2 measurements.")
        #expect(plant.draft.score == 50)
        #expect(profile.scoring[.plantToContactTime] == nil, "plant timing is descriptive only")
    }

    @Test func hiddenJointsAreExcludedNotPunished() {
        let byKey = { (m: [KickMetricMeasurement]) in Dictionary(uniqueKeysWithValues: m.map { ($0.key, $0) }) }
        let all = measurements([
            measured(.torsoLeanAtContact, 0),                 // 100
            measured(.torsoLeanRange, 30),                    // 50
            measured(.bodyForwardSpeedAtContact, 2),          // 100
        ])
        // The poor torso-range value is hidden by the camera: the score uses the rest.
        let hidden = measurements([measured(.torsoLeanAtContact, 0), measured(.bodyForwardSpeedAtContact, 2)])
        let full = KickScorer.scoreCategory(.contact, byKey: byKey(all), profile: profile)
        let partial = KickScorer.scoreCategory(.contact, byKey: byKey(hidden), profile: profile)
        #expect(full.score == 85.7)
        #expect(partial.score == 100, "a hidden joint is not scored as 0 or as bad")
        let partialConfidence: Double = partial.confidence ?? 1
        let fullConfidence: Double = full.confidence ?? 0
        #expect(partialConfidence < fullConfidence, "it lowers confidence instead")
        #expect(partial.excluded == [ExcludedScoreComponent(key: .torsoLeanRange, weight: 1, reason: .unavailable)])
        #expect(partial.summary == "Based on 2 of 3 measurements.")
    }

    @Test func tooLittleEvidenceGivesNoScore() {
        // Only body speed (weight 1 of 3.5) is available: under half the weight.
        let m = measurements([measured(.bodyForwardSpeedAtContact, 2)])
        let contact = KickScorer.scoreCategory(.contact, byKey: Dictionary(uniqueKeysWithValues: m.map { ($0.key, $0) }), profile: profile)
        #expect(contact.score == nil)
        #expect(contact.confidence == nil)
        #expect(contact.status == .unavailable)
        #expect(contact.summary == "Not enough reliable measurements to score (1 of 3 measurements available).")
        #expect(AnalysisResultValidator.validate(contact.draft).isEmpty)
    }

    @Test func lowConfidenceMetricsAreNotScored() {
        let m = measurements([
            measured(.torsoLeanAtContact, -38, confidence: 0.3),   // below 0.35: excluded
            measured(.torsoLeanRange, 5),
            measured(.bodyForwardSpeedAtContact, 2),
        ])
        let contact = KickScorer.scoreCategory(.contact, byKey: Dictionary(uniqueKeysWithValues: m.map { ($0.key, $0) }), profile: profile)
        #expect(contact.excluded == [ExcludedScoreComponent(key: .torsoLeanAtContact, weight: 1.5, reason: .lowConfidence)])
        #expect(contact.score == 100)
    }

    @Test func informationalMetricsAreNeverScored() {
        let m = measurements([
            measured(.kickingKneeAngleAtContact, 170), measured(.peakFootSpeed, 25),
            measured(.footSpeedAtContact, 1), measured(.backswingDepth, 1),
        ])
        let swing = KickScorer.scoreCategory(.swing, byKey: Dictionary(uniqueKeysWithValues: m.map { ($0.key, $0) }), profile: profile)
        #expect(!swing.components.contains { $0.key == .footSpeedAtContact })
        #expect(!swing.excluded.contains { $0.key == .footSpeedAtContact })
    }

    @Test func overallNeedsThreeCategoriesAndIgnoresUnavailableOnes() {
        // One category (plant) unavailable; four scored.
        var script = SyntheticPose.KickScript.fieldGoal
        script.torsoLeanDegrees = -35
        var timeline = SyntheticPose.timeline(script)
        for i in timeline.samples.indices where (1.1...1.7).contains(timeline.samples[i].timestamp) {
            timeline.samples[i].joints[.leftAnkle] = .unavailable
        }
        let r = SyntheticBiomechanics.analyze(script, timeline: timeline)
        #expect(r.category(.plant)?.score == nil)
        let scored = r.categories.filter { $0.category != .overall && $0.score != nil }
        #expect(scored.count == 4)
        let overall = r.overall
        let mean = scored.compactMap(\.score).reduce(0, +) / 4
        #expect(near(overall?.score, (mean * 10).rounded() / 10, 1e-9))
        #expect(overall?.summary == "Average of 4 of 5 category scores.")
        // Confidence scaled by coverage (4 of 5).
        let meanConfidence = scored.compactMap(\.confidence).reduce(0, +) / 4
        #expect(near(overall?.confidence, meanConfidence * 0.8, 0.001))

        let few = KickScorer.overall([
            CategoryScoreBreakdown(category: .plant, score: 90, confidence: 0.8, status: .estimated, components: [], excluded: [],
                                   availableWeightFraction: 1, summary: ""),
        ], profile: profile)
        #expect(few.score == nil)
        #expect(few.status == .unavailable)
    }

    @Test func normalFieldGoalScoresMatchTheRules() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal)
        // Plant: 0.2 s, no drift, knee 169.4° — all inside the ideal bands.
        #expect(r.category(.plant)?.score == 100)
        // Contact: lean 0 (100, w 1.5), range 0 (100, w 1), body speed 0 → 100 × 1 ÷ 1.5 = 66.7 (w 1):
        // (150 + 100 + 66.7) ÷ 3.5 = 90.5.
        #expect(r.category(.contact)?.score == 90.5)
        // Follow-through: duration ideal (100), ankle never above the hip (0), travel 0 →
        // 100 × 0.3 ÷ 0.4 = 75: mean 58.3.
        #expect(r.category(.followThrough)?.score == 58.3)
        #expect(r.categories.map(\.category) == [.approach, .plant, .swing, .contact, .followThrough, .overall])
        #expect(r.overall?.score != nil)
        #expect(r.overallScore == r.overall?.score)
        for c in r.categories { #expect(AnalysisResultValidator.validate(c.draft).isEmpty) }
    }

    @Test func scoringIsDeterministic() {
        let m = measurements([measured(.plantToContactTime, 0.31), measured(.plantFootDrift, 0.2), measured(.plantKneeAngleAtContact, 150)])
        #expect(KickScorer.score(m, profile: profile) == KickScorer.score(m, profile: profile))
    }

    @Test func profilesAreExplicitAndPerKickType() {
        #expect(BiomechanicsProfile.standard(for: .kickoff).scoring[.approachSpeed]?.band.idealLow == 4)
        #expect(BiomechanicsProfile.standard(for: .fieldGoal).scoring[.approachSpeed]?.band.idealLow == 2.5)
        #expect(BiomechanicsProfile.standard(for: .punt).expectedCategories == [.swing, .contact, .followThrough])
        #expect(BiomechanicsProfile.standard(for: .fieldGoal).expectedCategories == KickMetricCatalog.scoredCategories)
        #expect(BiomechanicsProfile.standard(for: .unknown).supportedMetrics.isEmpty)

        // A custom provider (e.g. tuned by level later) is honored.
        struct Strict: BiomechanicsProfileProviding {
            func profile(for context: BiomechanicsContext) -> BiomechanicsProfile {
                var p = BiomechanicsProfile.standard(for: context.kickType)
                p.coaching.torsoLeanBackBelowDegrees = 30
                return p
            }
        }
        let r = SyntheticBiomechanics.analyze(.fieldGoal, profiles: Strict())
        #expect(r.findings.contains { $0.rule == .torsoLeaningBack })
        #expect(!SyntheticBiomechanics.analyze(.fieldGoal).findings.contains { $0.rule == .torsoLeaningBack })
        // Build 18: plant-timing advice is never issued, whatever the threshold.
        struct Timing: BiomechanicsProfileProviding {
            func profile(for context: BiomechanicsContext) -> BiomechanicsProfile {
                var p = BiomechanicsProfile.standard(for: context.kickType)
                p.coaching.plantEarlyAboveSeconds = 0.01
                return p
            }
        }
        #expect(!SyntheticBiomechanics.analyze(.fieldGoal, profiles: Timing()).findings.contains { $0.rule == .plantEarly || $0.rule == .plantLate })

        let data = try? JSONEncoder().encode(BiomechanicsProfile.standard(for: .kickoff))
        #expect(data.flatMap { try? JSONDecoder().decode(BiomechanicsProfile.self, from: $0) } == .standard(for: .kickoff))
    }
}
