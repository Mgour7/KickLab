import Foundation
import Testing
@testable import KickLab

/// TEST-ONLY football observations. Nothing in the app creates ball observations; the
/// shipping tracker is `UnavailableBallTrackingService`. These exist only to exercise the
/// fusion rules.
enum TestOnlyBallObservations {
    static let rest = NormalizedPoint(x: 0.52, y: 0.80)
    static let radius = 0.01

    /// The ball rests at `rest` until `launch`, then moves away 0.05 per frame.
    static func track(times: [Double], launch: Double, missing: Set<Int> = [], glitchAt: Int? = nil) -> BallTrackingResult {
        let obs = times.enumerated().map { i, t -> BallObservation in
            if missing.contains(i) {
                return BallObservation(timestamp: t, position: nil, radius: nil, confidence: 0, status: .lost)
            }
            var p = rest
            if t >= launch - 1e-9 {
                let k = Double(times.filter { $0 >= launch - 1e-9 && $0 <= t + 1e-9 }.count)
                p = NormalizedPoint(x: rest.x, y: rest.y - 0.05 * k)
            }
            if i == glitchAt { p = NormalizedPoint(x: rest.x + 0.2, y: rest.y) }
            return BallObservation(timestamp: t, position: p, radius: radius, confidence: 0.9, status: .tracked)
        }
        return BallTrackingResult(status: .tracked, observations: obs, launchTime: nil)
    }

    /// The kicking ankle reaches the ball from `arrive` until `leave`, elsewhere far away.
    static func ankle(times: [Double], arrive: Double, leave: Double) -> [(time: Double, point: NormalizedPoint)] {
        times.map { t in (t, t >= arrive - 1e-9 && t <= leave + 1e-9 ? NormalizedPoint(x: rest.x + 0.01, y: rest.y - 0.01) : NormalizedPoint(x: 0.3, y: 0.5)) }
    }
}

@Suite("Step 12F contact intelligence: evidence groups, abstention, ball fusion")
struct ContactIntelligenceTests {
    typealias Real = RealReferenceClipRear
    typealias Ball = TestOnlyBallObservations

    private func index(_ t: Double) -> Int { Real.time.indices.min { abs(Real.time[$0] - t) < abs(Real.time[$1] - t) }! }
    private var times: [Double] { Real.time.filter { $0 >= 3.5 && $0 <= 4.4 } }

    // MARK: Evidence groups

    @Test func correlatedCuesCountOnceAndDoNotRaiseConfidence() throws {
        let p = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal, perspective: .depthAway)
        let chosen = try #require(p.evidence?.contactCandidates?.first { $0.selected })
        // Two independent groups (leg drive, trunk lean), whatever the number of leg cues.
        #expect(chosen.independentSupport == 2)
        #expect(Set(chosen.supportingSignals) == ["kickingLegDrive", "trunkLateralLean"])
        #expect(p.phase(.contact).confidence <= ContactIntelligence.twoGroupConfidence + 1e-9)
        #expect(p.phase(.contact).confidence <= DepthViewPhaseDetector.maximumContactConfidence)
    }

    @Test func twoEquallyFastKneeDrivesAreAmbiguous() {
        // Copy the real drive 0.2 s later: two strike candidates, contact not established.
        var signals = Real.signals
        var knee = Real.kickingKneeAngle
        let r = index(3.867)
        for k in 0..<5 { knee[r + 5 + k] = Real.kickingKneeAngle[r - 1 + k] }
        signals.series[.kickingKneeAngle] = knee
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(!p.phase(.contact).isAvailable)
        #expect(p.notes.contains { $0.contains("Two separate knee drives") })
        #expect(p.evidence?.contactCandidates?.allSatisfy { !$0.selected } == true)
    }

    @Test func aSlowKneeIsNotAStrike() {
        var signals = Real.signals
        // Halve every change in knee angle around the kick: the drive is below 200°/s.
        let knee = Real.kickingKneeAngle
        signals.series[.kickingKneeAngle] = knee.indices.map { i in
            guard let v = knee[i] else { return nil }
            return 150 + (v - 150) * 0.3
        }
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(!p.phase(.contact).isAvailable)
    }

    @Test func implausibleKneeFoldsAreIgnored() {
        #expect(ContactIntelligence.minimumPlausibleKneeAngle == 40)
        var signals = Real.signals
        var knee = Real.kickingKneeAngle
        knee[index(3.833)] = 5  // a projection fold, not a knee angle
        signals.series[.kickingKneeAngle] = knee
        let p = KickPhaseDetector.detect(signals, kickType: .fieldGoal, perspective: .depthAway)
        #expect(abs((p.estimatedContactTime ?? 0) - 3.867) < 0.002, "the drive after it is still found")
    }

    @Test func threeEventsAreKeptApart() throws {
        let p = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal, perspective: .depthAway)
        let approach = try #require(p.evidence?.strikeApproachStartTime)
        let contact = try #require(p.estimatedContactTime)
        let markers: [PhaseEndpointCandidate] = p.evidence?.postContactMarkers ?? []
        let post = try #require(markers.map(\.time).min())
        #expect(approach < contact && contact < post)
        #expect(p.evidence?.postContactMarkers?.allSatisfy { !$0.accepted } == true, "post-contact markers are never contact")
    }

    // MARK: Ball fusion (test-only observations)

    @Test func noTrackerMeansPoseOnly() {
        let e = BallContactFusion.evaluate(ball: .unavailable, kickingAnkle: [], aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .detectorUnavailable)
        #expect(e.framesExamined == 0)
        #expect(BallContactFusion.fusedInterval(pose: 3.867...3.9, ball: e).provenance == "poseOnly")
        #expect(UnavailableBallTrackingService().isAvailable == false)
    }

    @Test func aBallThatLeavesInsideThePoseIntervalConfirmsIt() {
        let ball = Ball.track(times: times, launch: 3.9)
        let e = BallContactFusion.evaluate(ball: ball, kickingAnkle: Ball.ankle(times: times, arrive: 3.833, leave: 3.933),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .consistent)
        #expect(e.lastStationaryTime == 3.867)
        #expect(e.firstDisplacementTime == 3.9)
        #expect(e.framesExamined == times.count && e.framesWithBall == times.count)
        let fused = BallContactFusion.fusedInterval(pose: 3.867...3.9, ball: e)
        #expect(fused.provenance == "ballAware")
        #expect(fused.interval == 3.867...3.9)
    }

    @Test func aBallThatLeavesLaterConflictsAndIsNotForced() {
        let ball = Ball.track(times: times, launch: 4.2)
        let e = BallContactFusion.evaluate(ball: ball, kickingAnkle: Ball.ankle(times: times, arrive: 4.1, leave: 4.2),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .conflicting)
        #expect(BallContactFusion.fusedInterval(pose: 3.867...3.9, ball: e).interval == nil)
    }

    @Test func anOccludedBallFallsBackToPose() {
        let missing = Set(times.indices.filter { $0 % 3 != 0 })
        let e = BallContactFusion.evaluate(ball: Ball.track(times: times, launch: 3.9, missing: missing),
                                           kickingAnkle: Ball.ankle(times: times, arrive: 3.833, leave: 3.933),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .ballNotVisible)
        #expect(BallContactFusion.fusedInterval(pose: 3.867...3.9, ball: e).provenance == "poseOnly")
    }

    @Test func aOneFrameJumpIsAMisdetectionNotALaunch() {
        // The ball "jumps" for one frame at 3.6 s and is back at rest; it really leaves at 4.3 s.
        let i = times.firstIndex { abs($0 - 3.6) < 0.002 }!
        let e = BallContactFusion.evaluate(ball: Ball.track(times: times, launch: 4.3, glitchAt: i),
                                           kickingAnkle: Ball.ankle(times: times, arrive: 3.833, leave: 3.933),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .unreliable)
    }

    @Test func aBallMovingWithoutTheFootIsNotAStrike() {
        let e = BallContactFusion.evaluate(ball: Ball.track(times: times, launch: 3.9),
                                           kickingAnkle: Ball.ankle(times: times, arrive: 4.3, leave: 4.4),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .unreliable)
        #expect(e.note.contains("without the kicking foot"))
    }

    @Test func aStationaryBallNeverMakesAContact() {
        let e = BallContactFusion.evaluate(ball: Ball.track(times: times, launch: 99),
                                           kickingAnkle: Ball.ankle(times: times, arrive: 3.833, leave: 3.933),
                                           aspect: 1, poseInterval: 3.867...3.9, window: 3.3...4.4)
        #expect(e.outcome == .unreliable)
        #expect(e.contactEarliestTime == nil)
    }

    @Test func fusionInThePipelineMarksConflictsAndLeavesUserRunsAlone() throws {
        // Synthetic rear kick (projected 3D model); test-only ball placed at the kicking
        // ankle's position at the true contact and launched 0.4 s late → conflict.
        let s = DepthViewSynthetic.Script()
        let out = DepthViewSynthetic.run(s)
        let timeline = try #require(out.kickerTimeline)
        let foot = KickingSideJoints(kickingFoot: .right).kickingAnkle
        let at = try #require(timeline.samples.min { abs($0.timestamp - s.contactTime) < abs($1.timestamp - s.contactTime) }?.point(foot))
        let obs = timeline.samples.map { smp -> BallObservation in
            let moved = smp.timestamp >= s.contactTime + 0.4
            return BallObservation(timestamp: smp.timestamp, position: NormalizedPoint(x: at.x, y: moved ? at.y - 0.2 : at.y),
                                   radius: 0.01, confidence: 0.9, status: .tracked)
        }
        let ball = BallTrackingResult(status: .tracked, observations: obs, launchTime: nil)
        let fused = BallContactFusion.apply(out.phases, ball: ball, timeline: timeline, kickingFoot: .right)
        #expect(fused.evidence?.ballEvidence?.outcome == .conflicting)
        #expect(fused.phase(.contact).status == .ambiguous)
        // A user-assisted result is never changed by the ball.
        let assisted = DepthViewSynthetic.run(s, assistance: PhaseDetectionAssistance(contactTime: s.contactTime))
        #expect(BallContactFusion.apply(assisted.phases, ball: ball, timeline: timeline, kickingFoot: .right) == assisted.phases)
    }

    @Test func theShippingPipelineRecordsThatNoBallWasLookedFor() {
        let out = DepthViewSynthetic.run(DepthViewSynthetic.Script())
        #expect(out.phases.evidence?.ballEvidence == .unavailable)
        #expect(out.phases.evidence?.contactProvenance == "poseOnly")
    }
}
