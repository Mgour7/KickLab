import Foundation
import Testing
@testable import KickLab

@MainActor
@Suite("KickValidator")
struct KickValidatorTests {
    // MARK: Valid drafts

    @Test func validDraftsForEveryKickTypePass() {
        let drafts: [KickDraft] = [
            KickDraft(
                outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(40))),
                spotDistanceToTargetGoalLine: 30,
                hashLocation: .left
            ),
            KickDraft(outcome: .pat(FieldGoalOutcome(result: .missedRight))),
            KickDraft(outcome: .kickoff(KickoffOutcome(
                distance: .manual(65),
                landing: .manual(KickoffLanding(yardLine: -3, zone: .middle)),
                touchback: true,
                outOfBounds: false,
                hangTime: .measured(4.1, from: .primaryVideo, confidence: 0.9)
            ))),
            KickDraft(outcome: .punt(PuntOutcome(distance: .manual(42), hangTime: .manual(4.4)))),
        ]
        for draft in drafts {
            #expect(KickValidator.validate(draft).isEmpty, "\(draft.kickType) should be valid")
        }
    }

    // MARK: Incompatible outcome fields (columns, as an import or legacy row would hold them)

    @Test func fieldGoalWithTouchbackIsRejected() {
        let columns = KickOutcomeColumns(storedResult: "made", touchback: true)
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.fieldNotAllowed(.touchback, kickType: .fieldGoal)))
    }

    @Test func kickoffWithMissedLeftIsRejected() {
        let columns = KickOutcomeColumns(storedResult: "missedLeft")
        let issues = KickValidator.validate(kickType: .kickoff, columns: columns)
        #expect(issues.contains(.fieldNotAllowed(.result, kickType: .kickoff)))
    }

    @Test func patWithKickoffLandingYardLineIsRejected() {
        let columns = KickOutcomeColumns(
            storedResult: "made",
            landingYardLine: 12,
            storedLandingSource: "manual"
        )
        let issues = KickValidator.validate(kickType: .pat, columns: columns)
        #expect(issues.contains(.fieldNotAllowed(.landing, kickType: .pat)))
    }

    @Test func puntWithFieldGoalAccuracyIsRejected() {
        let columns = KickOutcomeColumns(accuracyX: 0.2, storedAccuracySource: "manual")
        let issues = KickValidator.validate(kickType: .punt, columns: columns)
        #expect(issues.contains(.fieldNotAllowed(.accuracy, kickType: .punt)))
    }

    @Test func fieldGoalWithHangTimeIsRejected() {
        let columns = KickOutcomeColumns(storedResult: "made", hangTimeSeconds: 2, storedHangTimeSource: "manual")
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.fieldNotAllowed(.hangTime, kickType: .fieldGoal)))
    }

    @Test func fieldGoalRequiresResult() {
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: KickOutcomeColumns())
        #expect(issues.contains(.missingRequiredField(.result)))
    }

    @Test func kickoffCannotBeTouchbackAndOutOfBounds() {
        let draft = KickDraft(outcome: .kickoff(KickoffOutcome(touchback: true, outOfBounds: true)))
        #expect(KickValidator.validate(draft).contains(.touchbackAndOutOfBounds))
    }

    @Test func unknownKickTypeCannotBeWritten() {
        #expect(KickValidator.validate(kickType: .unknown, columns: KickOutcomeColumns()) == [.unknownKickType])
    }

    @Test func unrecognizedStoredStringsAreReported() {
        let columns = KickOutcomeColumns(storedResult: "doink")
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.unrecognizedStoredValue(.result, rawValue: "doink")))
    }

    // MARK: Provenance and confidence

    @Test func manualMeasurementCanHaveNilConfidence() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(65))))
        #expect(KickValidator.validate(draft).isEmpty)
        #expect(KickOutcomeColumns(outcome: draft.outcome).distanceConfidence == nil)
    }

    @Test func manualMeasurementCannotCarryConfidence() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            distance: MeasuredValue(value: 65, source: .manual, confidence: 0.9)
        )))
        #expect(KickValidator.validate(draft).contains(.manualMeasurementHasConfidence(.distance)))
    }

    @Test(arguments: [0.0, 0.5, 0.94, 1.0])
    func automatedConfidenceWithinZeroToOneIsAccepted(confidence: Double) {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            distance: .measured(65.2, from: .primaryVideo, confidence: confidence)
        )))
        #expect(KickValidator.validate(draft).isEmpty)
    }

    @Test(arguments: [-0.01, 1.01, 94.0])
    func automatedConfidenceOutsideZeroToOneIsRejected(confidence: Double) {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            distance: .measured(65.2, from: .multiVideo, confidence: confidence)
        )))
        #expect(KickValidator.validate(draft).contains(.confidenceOutOfRange(.distance, value: confidence)))
    }

    @Test(arguments: [Double.nan, Double.infinity, -Double.infinity])
    func nonFiniteConfidenceIsRejected(confidence: Double) {
        let draft = KickDraft(outcome: .punt(PuntOutcome(
            hangTime: .measured(4.2, from: .secondaryVideo, confidence: confidence)
        )))
        #expect(KickValidator.validate(draft).contains(.nonFiniteConfidence(.hangTime)))
    }

    @Test func automatedMeasurementMayOmitConfidence() {
        let draft = KickDraft(outcome: .kickoff(KickoffOutcome(
            landing: .measured(KickoffLanding(yardLine: 4), from: .primaryVideo, confidence: nil)
        )))
        #expect(KickValidator.validate(draft).isEmpty)
    }

    @Test func confidenceWithoutValueIsRejected() {
        let columns = KickOutcomeColumns(storedResult: "made", distanceConfidence: 0.8)
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.confidenceWithoutValue(.distance)))
    }

    @Test func valueWithoutSourceIsRejected() {
        let columns = KickOutcomeColumns(storedResult: "made", distanceYards: 40)
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.valueWithoutSource(.distance)))
    }

    @Test func sourceWithoutValueIsRejected() {
        let draft = KickDraft(outcome: .kickoff(KickoffOutcome(landing: .manual(KickoffLanding()))))
        #expect(KickValidator.validate(draft).contains(.sourceWithoutValue(.landing)))
    }

    // MARK: Ranges

    @Test func nonFiniteDistanceIsRejected() {
        let draft = KickDraft(outcome: .punt(PuntOutcome(distance: .manual(.infinity))))
        #expect(KickValidator.validate(draft).contains(.nonFiniteValue(.distance)))
    }

    @Test func outOfRangeValuesAreRejected() {
        let draft = KickDraft(outcome: .kickoff(KickoffOutcome(
            distance: .manual(500),
            hangTime: .manual(0)
        )))
        let issues = KickValidator.validate(draft)
        #expect(issues.contains(.valueOutOfRange(.distance, value: 500)))
        #expect(issues.contains(.valueOutOfRange(.hangTime, value: 0)))
    }

    @Test(arguments: [-1, 101, 120])
    func spotOutsideZeroToHundredIsRejected(spot: Int) {
        let draft = KickDraft(outcome: .pat(FieldGoalOutcome(result: .made)), spotDistanceToTargetGoalLine: spot)
        #expect(KickValidator.validate(draft).contains(.valueOutOfRange(.spotDistanceToTargetGoalLine, value: Double(spot))))
    }

    @Test(arguments: [0, 30, 50, 65, 100])
    func spotInsideZeroToHundredIsAccepted(spot: Int) {
        let draft = KickDraft(outcome: .pat(FieldGoalOutcome(result: .made)), spotDistanceToTargetGoalLine: spot)
        #expect(KickValidator.validate(draft).isEmpty)
    }

    // MARK: Accuracy coordinates

    @Test func madeKickInsideUprightsIsValid() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            accuracy: .manual(AccuracyCoordinate(x: 0.3, y: 0.8))
        )))
        #expect(KickValidator.validate(draft).isEmpty)
    }

    @Test(arguments: [
        (KickResult.missedLeft, -1.8),
        (KickResult.missedLeft, -1.0),
        (KickResult.missedRight, 2.4),
        (KickResult.missedRight, 1.2),
    ])
    func missesOutsideTheUprightsAreValid(result: KickResult, x: Double) {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: result,
            accuracy: .manual(AccuracyCoordinate(x: x))
        )))
        #expect(KickValidator.validate(draft).isEmpty)
    }

    @Test func horizontalOnlyAccuracyIsValid() {
        let draft = KickDraft(outcome: .pat(FieldGoalOutcome(
            result: .made,
            accuracy: .measured(AccuracyCoordinate(x: -0.4, y: nil), from: .primaryVideo, confidence: 0.7)
        )))
        #expect(KickValidator.validate(draft).isEmpty)
    }

    @Test func madeKickOutsideUprightsContradicts() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            accuracy: .manual(AccuracyCoordinate(x: 1.6))
        )))
        #expect(KickValidator.validate(draft).contains(.resultContradictsAccuracy(.made, x: 1.6, y: nil)))
    }

    @Test func madeKickBelowCrossbarContradicts() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .made,
            accuracy: .manual(AccuracyCoordinate(x: 0, y: -0.5))
        )))
        #expect(KickValidator.validate(draft).contains(.resultContradictsAccuracy(.made, x: 0, y: -0.5)))
    }

    @Test func missLeftThatCrossedInsideContradicts() {
        let draft = KickDraft(outcome: .fieldGoal(FieldGoalOutcome(
            result: .missedLeft,
            accuracy: .manual(AccuracyCoordinate(x: 0.2))
        )))
        #expect(KickValidator.validate(draft).contains(.resultContradictsAccuracy(.missedLeft, x: 0.2, y: nil)))
    }

    @Test func verticalAccuracyRequiresHorizontal() {
        let columns = KickOutcomeColumns(storedResult: "made", accuracyY: 0.5, storedAccuracySource: "manual")
        let issues = KickValidator.validate(kickType: .fieldGoal, columns: columns)
        #expect(issues.contains(.verticalAccuracyWithoutHorizontal))
    }

    @Test func accuracyCoordinateZones() {
        #expect(AccuracyCoordinate(x: 0).horizontalZone == .insideUprights)
        #expect(AccuracyCoordinate(x: 1).horizontalZone == .insideUprights)
        #expect(AccuracyCoordinate(x: -1.01).horizontalZone == .outsideLeft)
        #expect(AccuracyCoordinate(x: 3).horizontalZone == .outsideRight)
        #expect(AccuracyCoordinate(x: 0).isAboveCrossbar == nil)
        #expect(AccuracyCoordinate(x: 0, y: 0.2).isAboveCrossbar == true)
        #expect(AccuracyCoordinate(x: 0, y: -0.2).isAboveCrossbar == false)
    }

    // MARK: Errors and helpers

    @Test func validateOrThrowThrowsTypedError() {
        let draft = KickDraft(outcome: .kickoff(KickoffOutcome(touchback: true, outOfBounds: true)))
        do {
            try KickValidator.validateOrThrow(draft)
            Issue.record("Expected a KickValidationError")
        } catch let error as KickValidationError {
            #expect(error.issues == [.touchbackAndOutOfBounds])
        } catch {
            Issue.record("Unexpected error: \(error)")
        }
    }

    @Test func spotNeverConstrainsMeasuredDistance() {
        // Spot and distance are independent facts: no cross-check, no derivation.
        let draft = KickDraft(
            outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .measured(43.6, from: .primaryVideo, confidence: 0.9))),
            spotDistanceToTargetGoalLine: 30
        )
        #expect(KickValidator.validate(draft).isEmpty)
        #expect(KickOutcomeColumns(outcome: draft.outcome).distanceYards == 43.6)
    }
}
