import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: the import → analysis → persistence → deletion → re-import → replay
/// lifecycle through the real runner, SwiftData and artifact files (reanalysis fix).
@MainActor
@Suite("Reanalysis lifecycle in the app")
struct ReanalysisLifecycleTests {
    private func fixture() throws -> AppFixture {
        let holder = try AppFixtureStore()
        var script = SyntheticPose.KickScript.fieldGoal
        script.confidence = 0.9
        let fixed = script
        let engine = PoseVideoAnalysisService(mediaStore: holder.store,
                                              extractor: FakePoseExtractor { SyntheticPose.sequence(fixed, videoID: $0) })
        return try AppFixture(store: holder, engine: engine)
    }

    private func phases(of analysis: BiomechanicsAnalysis, _ x: AppFixture) throws -> PhaseArtifactSummary {
        let path = try #require(analysis.artifactsRelativePath)
        return try AnalysisArtifactStore(analysisRootURL: x.app.services.videos.analysisRootURL).readPhases(in: path)
    }

    private func finished(_ run: AnalysisRunViewModel, _ x: AppFixture) async throws -> BiomechanicsAnalysis {
        await waitUntil { !run.state.isBusy }
        let id = try #require(run.lastAnalysisID)
        return try #require(ModelLookup.analysis(id, in: x.app.context))
    }

    /// Requirement 10: what a clean automatic analysis stores.
    private func expectCleanAutomatic(_ analysis: BiomechanicsAnalysis, _ x: AppFixture) throws {
        #expect(analysis.analysisVersion == PoseVideoAnalysisService.version)
        #expect(!analysis.analysisVersion.hasSuffix(AnalysisAssistanceLabel.suffix))
        let stored = try phases(of: analysis, x)
        #expect(stored.manifest.assistance == nil, "no assistance in the manifest")
        #expect(stored.phases.phases.assistance == nil, "no assistance in the phases")
        #expect(stored.phases.phases.evidence?.contactTimingBasis == "automatic")
        #expect(stored.phases.phases.evidence?.userAssistedContactTime == nil)
        #expect(stored.manifest.engineVersion == PoseVideoAnalysisService.version)
    }

    @Test func reanalyzingAutomaticallyAfterAManualContactRunUsesNoManualContact() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)

        run.start(app: x.app)
        let first = try await finished(run, x)
        try expectCleanAutomatic(first, x)
        #expect(run.lastRunMode == .automatic)

        let chosen = SyntheticPose.KickScript.fieldGoal.expectedContact
        run.reanalyze(app: x.app, mode: .manualContact(seconds: chosen))
        let assisted = try await finished(run, x)
        #expect(assisted.id != first.id)
        #expect(assisted.analysisVersion == PoseVideoAnalysisService.version + AnalysisAssistanceLabel.suffix)
        #expect(try phases(of: assisted, x).manifest.assistance?.contactTime == chosen)
        #expect(try phases(of: assisted, x).phases.phases.evidence?.contactTimingBasis == "user")

        run.startAutomatic(app: x.app)
        let again = try await finished(run, x)
        #expect(again.id != assisted.id, "a new analysis")
        try expectCleanAutomatic(again, x)
        #expect(run.lastRunMode == .automatic)
        #expect(run.lastAnalysisVersion == PoseVideoAnalysisService.version)
        #expect(again.isCurrent, "the new automatic analysis is current")
        #expect(!assisted.isCurrent)
        #expect((kick.analyses ?? []).count == 3, "history kept")

        // Results and diagnostics show the source and version.
        let results = AnalysisResultsViewModel(analysisID: again.id)
        results.load(app: x.app)
        await results.loadVideo(app: x.app)
        #expect(results.provenance?.contactSource == .automatic)
        #expect(results.provenance?.engineText == "Engine: \(PoseVideoAnalysisService.version)")
        #expect(results.state.value?.presentation.header.mode != .userAssisted)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: again.id)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(report.analysisMode == "automatic")
        #expect(report.contactTimingSource == "automatic")
        #expect(report.assistance == nil)
        #expect(report.automaticReplay == nil)
    }

    @Test func tryAgainAfterAManualContactRunIsAutomatic() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: SyntheticPose.KickScript.fieldGoal.expectedContact))
        let assisted = try await finished(run, x)
        #expect(AnalysisAssistanceLabel.isAssisted(assisted.analysisVersion))
        run.retry(app: x.app)
        let retried = try await finished(run, x)
        try expectCleanAutomatic(retried, x)
        #expect(run.lastAssistance == nil)
    }

    @Test func replayingDiagnosticsOfAnAssistedAnalysisCreatesNothing() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: SyntheticPose.KickScript.fieldGoal.expectedContact))
        let assisted = try await finished(run, x)
        let count = (kick.analyses ?? []).count
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: assisted.id)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(report.analysisMode == "userAssisted")
        #expect(report.contactTimingSource == "user")
        #expect(report.automaticReplay?.evidence?.contactTimingSource == .automatic)
        #expect((kick.analyses ?? []).count == count, "replay saves no analysis")
    }

    @Test func deletingAnAssistedAnalysisRemovesItsFilesAndRestoresTheAutomaticOne() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        let automatic = try await finished(run, x)
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: SyntheticPose.KickScript.fieldGoal.expectedContact))
        let assisted = try await finished(run, x)
        #expect(assisted.isCurrent)
        let assistedID = assisted.id
        let folder = x.app.services.videos.analysisRootURL.appendingPathComponent(try #require(assisted.artifactsRelativePath))
        #expect(FileManager.default.fileExists(atPath: folder.path))

        let results = AnalysisResultsViewModel(analysisID: assistedID)
        #expect(results.deleteAnalysis(app: x.app))
        #expect(ModelLookup.analysis(assistedID, in: x.app.context) == nil)
        #expect(!FileManager.default.fileExists(atPath: folder.path), "files and the recorded manual contact are gone")
        #expect(automatic.isCurrent, "the automatic analysis is current again")
        #expect(ModelLookup.video(video.id, in: x.app.context) != nil, "the video stays")
        #expect(run.state == .idle, "the Analyze screen no longer shows the deleted result")
        #expect(run.lastRunMode == nil)

        run.start(app: x.app)
        try expectCleanAutomatic(try await finished(run, x), x)
    }

    @Test func deletingTheOnlyAnalysisLeavesNothingCurrentAndKeepsTheVideo() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: SyntheticPose.KickScript.fieldGoal.expectedContact))
        let assisted = try await finished(run, x)
        #expect(AnalysisResultsViewModel(analysisID: assisted.id).deleteAnalysis(app: x.app))
        #expect((kick.analyses ?? []).isEmpty)
        #expect(ModelLookup.video(video.id, in: x.app.context) != nil)
        #expect(x.app.services.videos.fileExists(for: video))
    }

    @Test func removingAndReimportingTheVideoGivesAFreshAutomaticAnalysis() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let first = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: SyntheticPose.KickScript.fieldGoal.expectedContact))
        let assisted = try await finished(run, x)
        guard case .completed = run.state else {
            Issue.record("expected the assisted run to complete, got \(run.state)")
            return
        }

        let detail = KickDetailViewModel(kickID: kick.id)
        detail.removeVideo(videoID: first.id, app: x.app)
        #expect(run.state == .idle, "removing the video invalidates the finished run")
        let second = try await x.importVideo(to: kick, angle: .side)
        #expect(second.id != first.id, "a re-import is a new video record")
        #expect(ModelLookup.analysis(assisted.id, in: x.app.context) != nil, "history is kept")

        run.start(app: x.app)
        let fresh = try await finished(run, x)
        try expectCleanAutomatic(fresh, x)
        #expect((fresh.inputVideos ?? []).map(\.id) == [second.id])
        #expect(fresh.isCurrent)
    }

    @Test func aFinishedRunIsStaleOnceTheKicksVideosChange() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        _ = try await finished(run, x)
        run.refresh(app: x.app)
        #expect(run.state != .idle, "nothing changed")
        // A video added outside the kick screen (e.g. by another flow): the Analyze screen
        // refreshes on appear.
        try await x.importVideo(to: kick, angle: .side)
        run.refresh(app: x.app)
        #expect(run.state == .idle)
    }

    @Test func aMarkedContactOnTheVideoNeverReachesAnAutomaticRun() async throws {
        let x = try fixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        let first = try await finished(run, x)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: first.id)
        await diagnostics.load(app: x.app)
        await diagnostics.saveReferenceContact(1.0, app: x.app)
        #expect(video.contactTimeSource == .manual)
        run.startAutomatic(app: x.app)
        try expectCleanAutomatic(try await finished(run, x), x)
    }
}
