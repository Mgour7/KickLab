import Testing
@testable import KickLab

/// The 0–100 field coordinate and its football-notation display.
@Suite("Field geometry")
struct FieldGeometryTests {
    @Test(arguments: [
        (30, "Opp 30"),
        (40, "Opp 40"),
        (50, "50"),
        (60, "Own 40"),
        (80, "Own 20"),
        (1, "Opp 1"),
        (49, "Opp 49"),
        (51, "Own 49"),
        (65, "Own 35"),
        (0, "Opp 0"),
        (100, "Own 0"),
    ])
    func coordinateToFootballNotation(spot: Int, expected: String) {
        #expect(FieldGeometry.footballNotation(spotDistanceToTargetGoalLine: spot) == expected)
    }

    @Test(arguments: [-1, 101, 150])
    func outOfRangeCoordinateHasNoNotation(spot: Int) {
        #expect(FieldGeometry.footballNotation(spotDistanceToTargetGoalLine: spot) == nil)
    }

    @Test func footballNotationRoundTripsForEveryCoordinate() {
        for spot in 0...100 {
            let yardLine = spot <= 50 ? spot : 100 - spot
            let side: FieldSide = spot < 50 ? .opponent : .own
            #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: yardLine, side: side) == spot)
        }
    }

    @Test func notationToCoordinate() {
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: 30, side: .opponent) == 30)
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: 40, side: .own) == 60)
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: 50, side: .own) == 50)
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: 50, side: .opponent) == 50)
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: 51, side: .own) == nil)
        #expect(FieldGeometry.spotDistanceToTargetGoalLine(yardLine: -1, side: .opponent) == nil)
    }

    @Test func distanceEstimateIsAHelperOnly() {
        // Hold: Opp 30 → about a 40-yard field goal.
        #expect(FieldGeometry.estimatedFieldGoalDistance(spotDistanceToTargetGoalLine: 30) == 40)
        #expect(FieldGeometry.footballNotation(spotDistanceToTargetGoalLine: 30) == "Opp 30")
    }
}
