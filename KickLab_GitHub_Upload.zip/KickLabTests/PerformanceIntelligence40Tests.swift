import Foundation
import Testing
@testable import KickLab

/// Build 20 — Performance Intelligence 4.0: technique / consistency / results layers and
/// Athlete Report 5.0.
///
/// Evidence classes: history entries and records here are HAND-BUILT (synthetic) to test
/// the rules; the rear-view values mirror the device's stored values for the rear 7.602 s
/// clip (plant foot vs hips −0.533, sideways lean 9.6°), but no real multi-kick history
/// exists yet — every "usual" value below is synthetic.
@Suite("Performance Intelligence 4.0")
struct PerformanceIntelligence40Tests {
    private let day = 86_400.0

    private func entry(_ n: Double, _ values: [KickMetricKey: Double], view: ComparableView = .depth, type: KickType = .fieldGoal,
                       kickID: UUID = UUID(), cropped: Bool = false, blocking: Bool = false, assisted: Bool = false) -> RankingEntry {
        var e = RankingEntry(id: UUID(), kickID: kickID, date: Date(timeIntervalSince1970: 1_800_000_000 + n * day), kickType: type,
                             view: view, engineVersion: PoseVideoAnalysisService.version + (assisted ? AnalysisAssistanceLabel.suffix : ""),
                             completed: true, overallScore: nil, categoryScores: [:], recording: RecordingFlags(cropped: cropped, blocking: blocking))
        for (k, v) in values { e.metrics[RankingEntry.metricKey(k)] = v }
        return e
    }

    private func consistency(_ current: RankingEntry, _ others: [RankingEntry]) -> ConsistencyReport {
        ConsistencyModel.make(current: current, eligibility: PersonalRanking.eligibility(for: current, among: others + [current]))
    }

    private let offset = KickMetricKey.plantBallLateralOffset

    // MARK: Measurement precision

    @Test func everyMetricHasADocumentedPrecisionWithAMeaningfulChangeAboveIt() {
        for key in KickMetricKey.allCases {
            let p = MeasurementPrecision.of(key)
            #expect(p.resolution > 0 && p.meaningfulChange >= 2 * p.resolution - 1e-9, "\(key)")
            #expect(!p.source.isEmpty)
        }
        #expect(MeasurementPrecision.of(.plantBallLateralOffset).resolution == 0.03)
        #expect(MeasurementPrecision.of(.lateralTrunkLeanAtContact).meaningfulChange == 3)
        // Timing can't resolve less than one analyzed frame (the Step 10 value of 0.03 s for
        // plant-to-contact is finer than a 30 fps frame — see GRADING_AUDIT).
        #expect(abs(MeasurementPrecision.of(.plantToContactTime).resolution - 1.0 / 30) < 1e-9)
        #expect(abs(MeasurementPrecision.of(.kneeSwingAfterContact).meaningfulChange - 2.0 / 30) < 1e-9)
        #expect(MeasurementPrecision.of(.torsoLeanAtContact).meaningfulChange == 4, "Step 10 minimum meaningful difference")
    }

    // MARK: Consistency layer

    @Test func noConsistencyFromOneRecording() {
        let r = consistency(entry(10, [offset: 0.7]), [])
        #expect(r.status == .buildingBaseline(have: 1, need: 4))
        #expect(r.summaryText == "Building baseline · 1 of 4 comparable kicks")
        #expect(r.baselineGoal == "Record 3 more comparable kicks (same kick type and camera view) to build your consistency baseline.")
        #expect(r.metrics.allSatisfy { $0.level == nil && $0.spread == nil })
        if case .noBaseline(let have)? = r.metrics.first?.comparison { #expect(have == 0) } else { Issue.record("no baseline") }
    }

    @Test func fourComparableKicksGiveASpreadAndADescriptiveLevel() throws {
        let r = consistency(entry(10, [offset: 0.64]), [entry(1, [offset: 0.62]), entry(2, [offset: 0.58]), entry(3, [offset: 0.66])])
        #expect(r.status == .assessed)
        let a = try #require(r.metrics.first { $0.key == offset })
        #expect(a.spreadCount == 4)
        #expect(abs((a.range ?? 0) - 0.08) < 1e-9)
        #expect(a.spreadText == "Varied by 0.08 torso lengths across 4 comparable kicks")
        #expect(a.level == .repeatable, "SD 0.034: above the 0.03 resolution, within the 0.06 meaningful change")
        #expect(a.comparison == .withinUsual)
        #expect(a.interpretation == "Within your usual range.")
        #expect(a.usualText == "Usual 0.62 torso lengths · plant-leg side (SD 0.04, 3 earlier kicks)")
        #expect(r.summaryText == "Repeatable on 1 of 1 measurement · 4 comparable kicks")
    }

    @Test func aDifferenceIsNotableOnlyBeyondPrecisionAndUsualSpread() throws {
        let earlier = [entry(1, [offset: 0.62]), entry(2, [offset: 0.58]), entry(3, [offset: 0.66])]
        let far = try #require(consistency(entry(10, [offset: 0.80]), earlier).metrics.first)
        #expect(far.comparison == .higherThanUsual, "+0.18 > max(0.06, 2 × 0.04)")
        #expect(far.interpretation == "Your plant foot was farther to the side of the football than on your recent comparable kicks.")
        #expect(far.signedDifferenceText(far.difference ?? 0) == "+0.18 torso lengths")
        let near = try #require(consistency(entry(10, [offset: 0.69]), earlier).metrics.first)
        #expect(near.comparison == .withinUsual, "+0.07 is inside 2 × the usual spread")
        // A perfectly steady history: the measurement precision still protects against noise.
        let flat = [entry(1, [offset: 0.62]), entry(2, [offset: 0.62]), entry(3, [offset: 0.62])]
        #expect(consistency(entry(10, [offset: 0.66]), flat).metrics.first?.comparison == .withinUsual, "0.04 < the 0.06 meaningful change")
        #expect(consistency(entry(10, [offset: 0.55]), flat).metrics.first?.comparison == .lowerThanUsual)
    }

    @Test func interpretationsDescribeDirectionNeverQuality() {
        let words = ["better", "worse", "should", "improve", "good", "bad", "correct", "ideal"]
        for key in KickMetricKey.allCases {
            for higher in [true, false] {
                let text = ConsistencyModel.directionPhrase(key, higher: higher, current: 0.5, usual: 0.4).lowercased()
                #expect(!words.contains { text.contains($0) }, "\(key): \(text)")
            }
        }
    }

    @Test func onlyEligibleComparableKicksCountAndEachPhysicalKickOnce() throws {
        let shared = UUID()
        let others = [
            entry(1, [offset: 0.60]), entry(2, [offset: 0.64]),
            entry(3, [offset: 0.61], kickID: shared), entry(3.5, [offset: 0.63], kickID: shared),   // re-analysis of one kick
            entry(4, [offset: 2.0], view: .side),                // another view
            entry(5, [offset: 2.0], type: .pat),                 // another kick type
            entry(6, [offset: 2.0], assisted: true),             // user-assisted vs automatic
            entry(7, [offset: 0.05], cropped: true),             // Build 19 exclusions
            entry(8, [offset: 2.0], blocking: true),
            entry(9, [:]),                                       // not measured: skipped, never zero
        ]
        let r = consistency(entry(10, [offset: 0.62]), others)
        let a = try #require(r.metrics.first { $0.key == offset })
        #expect(a.earlier == [0.60, 0.64, 0.63], "one value per physical kick (the later analysis)")
        #expect(r.excluded["recording quality too limited"] == 1)
        #expect(r.excluded.values.reduce(0, +) == 2)
        #expect(r.comparableKicks == 5, "4 earlier eligible kicks (one unmeasured) + this one")
    }

    @Test func aCroppedCurrentKickIsShownButNotAssessed() {
        let earlier = [entry(1, [offset: 0.62]), entry(2, [offset: 0.58]), entry(3, [offset: 0.66])]
        let r = consistency(entry(10, [offset: 0.9], cropped: true), earlier)
        #expect(r.metrics.allSatisfy { $0.current == nil })
        if case .notApplicable(let reason) = r.status { #expect(reason.contains("beginning of the clip")) } else { Issue.record("\(r.status)") }
    }

    @Test func aDifferenceThatRoundsToZeroShowsNoDirection() {
        #expect(DisplayFormat.signedDifference(0.009, unit: .degrees) == "0°")
        #expect(DisplayFormat.signedDifference(-0.004, unit: .bodyLengths) == "0.00 torso lengths")
        #expect(DisplayFormat.signedDifference(-2.4, unit: .degrees) == "−2°")
        #expect(DisplayFormat.signedDifference(0.06, unit: .bodyLengths) == "+0.06 torso lengths")
    }

    @Test func levelsFollowTheDocumentedCriteria() {
        let p = MeasurementPrecision(resolution: 0.03, meaningfulChange: 0.06, source: "")
        #expect(RepeatabilityLevel.of(spread: 0.02, precision: p) == .withinPrecision)
        #expect(RepeatabilityLevel.of(spread: 0.05, precision: p) == .repeatable)
        #expect(RepeatabilityLevel.of(spread: 0.07, precision: p) == .variable)
    }

    // MARK: Results layer (entered results only)

    private func kick(_ n: Double, _ result: KickResult?, _ yards: Double?, session: UUID? = nil, type: KickType = .fieldGoal) -> KickStatRecord {
        var r = KickStatRecord()
        r.timestamp = Date(timeIntervalSince1970: 1_800_000_000 + n * day)
        r.kickType = type
        r.result = result
        r.distanceYards = yards
        r.sessionID = session
        return r
    }

    @Test func resultsAreSummarizedWithSampleSizes() {
        let s1 = UUID(), s2 = UUID()
        let records = [kick(1, .made, 32, session: s1), kick(1, .missedLeft, 45, session: s1), kick(1, .made, 41, session: s1),
                       kick(2, .made, 38, session: s2), kick(2, .short, 52, session: s2), kick(2, .unknown, 40, session: s2),
                       kick(3, .made, 20, type: .pat)]
        let r = KickResultsSummary.make(kickID: nil, sessionID: s1, kickType: .fieldGoal, thisKick: "Made · 41 yd", records: records)
        #expect(r.session == "2 of 3 made")
        #expect(r.overall?.overall == RateSummary(successes: 3, attempts: 5), "an unrecorded result isn't an attempt; PATs aren't field goals")
        #expect(r.summaryText == "Made · 41 yd · this session 2 of 3 made · all field goals 60% · 3 of 5")
        #expect(r.lines.contains { $0.title == "30–39 yd" && $0.value == "100% · 2 of 2" && $0.detail == "Small sample (2 attempts)" })
        #expect(r.lines.contains { $0.title == "Longest recorded make" && $0.value == "41 yd" })
        #expect(r.lines.contains { $0.title == "Misses" && $0.value == "missed left 1, short 1" })
        #expect(r.lines.contains { $0.title == "Result not recorded" && $0.value == "1" })
        #expect(r.recentSessions.count == 2 && r.recentSessions.first?.value == "FG 1 of 2")
        let none = KickResultsSummary.make(kickID: nil, sessionID: nil, kickType: .fieldGoal, thisKick: nil, records: [])
        #expect(none.summaryText == "Result not recorded")
    }

    // MARK: Athlete Report 5.0

    private static func stored(_ key: KickMetricKey, _ value: Double?, _ confidence: Double?) -> StoredMetricRecord {
        StoredMetricRecord(key: key.rawValue, value: value, unit: key.definition.unit, confidence: confidence,
                           status: value == nil ? .unavailable : .estimated, phase: key.definition.phase)
    }

    /// A rear-view kick shaped like the device's rear 7.602 s analysis (synthetic history).
    private func rearRecord(offset value: Double = 0.70) -> AnalysisRecord {
        var r = PresentationTests.record(.fieldGoal)
        r.overallScore = nil
        r.confidence = nil
        r.kickDate = Date(timeIntervalSince1970: 1_800_000_000 + 10 * day)
        r.categories = KickMetricCatalog.scoredCategories.map { StoredCategoryRecord(category: $0, score: nil, confidence: nil, status: .unavailable, summary: nil) }
        let available = [Self.stored(.lateralTrunkLeanAtContact, 9.609, 0.696), Self.stored(.plantFootWidth, -0.533, 0.584),
                         Self.stored(.plantBallLateralOffset, value, 0.83), Self.stored(.plantLateralMovement, 0.16, 0.65)]
        r.metrics = KickMetricKey.allCases.map { k in available.first { $0.key == k.rawValue } ?? Self.stored(k, nil, nil) }
        r.observations = []
        return r
    }

    private func report(_ r: AnalysisRecord, view: ComparableView = .depth, others: [RankingEntry] = [], results: [KickStatRecord] = [],
                        outcome: String? = nil, tracking: [String] = [], suitability: [SuitabilityFinding] = []) -> PerformanceReport {
        PerformanceReport.make(.init(presentation: AnalysisPresentationBuilder.make(r), record: r, view: view, others: others,
                                     suitability: suitability, outcomeText: outcome, results: results, contactQuality: "Contact: high confidence",
                                     trackingNotes: tracking))
    }

    private var rearHistory: [RankingEntry] {
        [entry(1, [offset: 0.62, .plantFootWidth: -0.50, .plantLateralMovement: 0.05, .lateralTrunkLeanAtContact: 9.0]),
         entry(2, [offset: 0.58, .plantFootWidth: -0.55, .plantLateralMovement: 0.06, .lateralTrunkLeanAtContact: 10.0]),
         entry(3, [offset: 0.66, .plantFootWidth: -0.52, .plantLateralMovement: 0.04, .lateralTrunkLeanAtContact: 9.5])]
    }

    @Test func aRearViewKickWithoutHistoryIsUsefulAndHonest() {
        let rep = report(rearRecord(), outcome: "Made · 38 yd")
        #expect(rep.technique.graded == false && rep.technique.text == "Not graded")
        #expect(rep.technique.detail.contains("side view"))
        #expect(rep.consistencyReport?.summaryText == "Building baseline · 1 of 4 comparable kicks")
        #expect(rep.results?.thisKick == "Made · 38 yd")
        #expect(rep.headline == "Kick detected · 4 measurements. Building your baseline (1 of 4 comparable kicks).")
        #expect(rep.header.contactQualityText == "Contact: high confidence")
        #expect(rep.keyFindings.isEmpty, "nothing reliable to say yet — no filler")
        #expect(rep.measurements.allSatisfy { $0.interpretation == nil && $0.usualText == nil }, "said once (tile + goal), not on every row")
    }

    @Test func aRearViewKickWithHistoryComparesEveryMeasurementWithTheUsualValue() throws {
        let rep = report(rearRecord(offset: 0.80), others: rearHistory)
        let row = try #require(rep.measurements.first { $0.key == offset })
        #expect(row.valueText == "0.80 torso lengths · plant-leg side")
        #expect(row.usualText == "Usual 0.62 torso lengths · plant-leg side (SD 0.04, 3 earlier kicks)")
        #expect(row.differenceText == "+0.18 torso lengths vs usual")
        #expect(row.comparison == .higherThanUsual)
        #expect(row.spreadText?.hasPrefix("Varied by 0.22 torso lengths across 4 comparable kicks") == true)
        let slide = try #require(rep.measurements.first { $0.key == .plantLateralMovement })
        #expect(slide.comparison == .higherThanUsual, "0.16 vs 0.05 ± 0.01")
        let width = try #require(rep.measurements.first { $0.key == .plantFootWidth })
        #expect(width.comparison == .withinUsual)
        #expect(rep.headline.contains("within your usual range") && rep.headline.contains("outside your usual range"))
        #expect(rep.keyFindings.count <= 3)
        #expect(rep.keyFindings.first?.kind == .differenceFromUsual)
        #expect(rep.keyFindings.contains { $0.kind == .repeatablePattern })
        #expect(rep.consistencyReport?.status == .assessed)
        #expect(rep.focus.map { if case .goal = $0 { return false } else { return true } } ?? true, "baseline complete: no baseline goal")
    }

    @Test func trackingLimitsBecomeFindingsOnlyWhenGiven() {
        let rep = report(rearRecord(), tracking: ["Kicking foot not tracked after contact (lost at or before contact)"])
        #expect(rep.keyFindings == [PerformanceReport.Finding(kind: .trackingLimitation, title: "Tracking",
                                                              detail: "Kicking foot not tracked after contact (lost at or before contact)")])
    }

    @Test func aGradedSideViewKeepsItsProvisionalScoreSeparateFromResults() {
        let r = PresentationTests.record(.fieldGoal)
        let rep = report(r, view: .side, outcome: "Missed Left · 45 yd")
        #expect(rep.technique.graded)
        #expect(rep.technique.text.hasPrefix("\(Int((r.overallScore ?? 0).rounded())) · "))
        #expect(rep.technique.detail.hasPrefix("Provisional"))
        #expect(rep.results?.summaryText == "Missed Left · 45 yd", "the result is never adjusted by the score, nor the score by the result")
    }

    @Test func aSideViewWithoutEnoughAreasSaysWhyItIsNotGraded() {
        var r = PresentationTests.record(.fieldGoal)
        r.overallScore = nil
        r.categories = r.categories.map { c in
            guard c.category != .approach else { return c }
            var x = c; x.score = nil; x.status = .unavailable; return x
        }
        let rep = report(r, view: .side)
        #expect(rep.technique.text == "Not graded")
        #expect(rep.technique.detail == "1 of 5 areas had enough reliable measurements (3 needed)")
        #expect(!rep.areas.isEmpty, "the rated area is still shown")
    }

    @Test func coachingStatesItsKind() {
        #expect(PerformanceReport.Improvement(id: "a", title: "t", observed: "o", cue: "c", insightClass: .confirmedObservation).kind == .provisionalSuggestion)
        #expect(PerformanceReport.Improvement(id: "a", title: "t", observed: "o", cue: "c", insightClass: .recordingRecommendation).kind == .recording)
        #expect(PerformanceReport.Strength(id: "s", title: "t", reason: "r").kindLabel == "Evidence-based observation")
        #expect(PerformanceReport.CoachingKind.provisionalSuggestion.title == "Provisional technique suggestion")
    }

    @Test func recordingProblemsStillComeFirstWhenThereIsNoCorrection() {
        let finding = SuitabilityFinding(kind: .kickerSmall, severity: .limiting, message: "Kicker small")
        let rep = report(rearRecord(), suitability: [finding])
        #expect(rep.focus == .recording("Record closer, keeping the entire kicker and football visible throughout the kick."))
        #expect(rep.recordingAdvice == nil, "shown once, as the focus")
    }
}
