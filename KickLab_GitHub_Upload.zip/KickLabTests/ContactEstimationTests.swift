import Foundation
import Testing
@testable import KickLab

/// Step 12C: evidence-based contact estimation, plant and follow-through recovery, the
/// validation harness, annotation isolation and the pose overlay model.
@Suite("Step 12C contact estimation and validation")
struct ContactEstimationTests {
    typealias Script = SyntheticPose.KickScript

    private struct Run {
        var signals: PoseSignalSet
        var phases: KickPhaseDetectionResult
        var repair: PoseRepairReport
    }

    private func run(_ timeline: KickerPoseTimeline, foot: KickingFoot = .right, kickType: KickType = .fieldGoal,
                     repair: Bool = true) -> Run {
        let config = PoseProcessingConfiguration(repairsLegLabels: repair)
        let (processed, report) = PoseTimelineProcessor.processWithReport(timeline, configuration: config)
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: foot)
        return Run(signals: signals, phases: KickPhaseDetector.detect(signals, kickType: kickType), repair: report)
    }

    private func run(_ script: Script, kickType: KickType = .fieldGoal, repair: Bool = true) -> Run {
        run(SyntheticPose.timeline(script), foot: script.kickingFoot, kickType: kickType, repair: repair)
    }

    private func contactError(_ r: Run, _ s: Script) -> Double {
        let estimate: Double = r.phases.estimatedContactTime ?? .infinity
        return abs(estimate - s.expectedContact)
    }

    private func oneFrame(_ s: Script) -> Double { 1 / s.frameRate + 1e-9 }

    /// The Step 7–12B rule: contact = the single highest kicking-ankle speed.
    private func globalPeakTime(_ signals: PoseSignalSet) -> Double? {
        let speed = signals.values(.kickingAnkleSpeed)
        let best = speed.indices.filter { speed[$0] != nil }.max { speed[$0]! < speed[$1]! }
        return best.map { signals.timestamps[$0] }
    }

    // MARK: Reference kicks with exact contact times

    @Test func referenceKicksAreTimedWithinOneFrame() {
        let scripts: [(Script, KickType)] = [(.fieldGoal, .fieldGoal), (.kickoff, .kickoff), (.realWorld30fps, .fieldGoal),
                                             (.backswingPattern, .fieldGoal), (.fieldGoal, .pat)]
        for (script, kickType) in scripts {
            let r = run(script, kickType: kickType)
            #expect(contactError(r, script) <= oneFrame(script), "\(kickType) \(script.frameRate) fps")
            #expect(r.phases.phase(.contact).status == .estimated, "never 'measured' without ball tracking")
            #expect(r.phases.evidence?.algorithmVersion == ContactEstimator.algorithmVersion)
            let selected = r.phases.evidence?.contactCandidates?.filter(\.selected) ?? []
            #expect(selected.count == 1)
        }
    }

    // MARK: The real-clip failure pattern (early false peak)

    @Test func theBackswingPeakIsNotTakenAsContact() throws {
        let s = Script.backswingPattern
        let r = run(s)
        // The old rule: the global peak is the backswing, well before the strike, while
        // the plant foot is still stepping — so the plant search window misses the plant.
        let oldContact = try #require(globalPeakTime(r.signals))
        let early: Double = s.expectedContact - oldContact
        #expect(early >= 0.1, "the global speed peak comes \(early) s early, as on the real clip")
        let oldIndex = try #require(r.signals.timestamps.firstIndex(of: oldContact))
        let plantAtOldContact: Double = r.signals.values(.plantAnkleSpeed)[oldIndex] ?? 0
        #expect(plantAtOldContact > KickPhaseProfile.placeKick.plantStillSpeedThreshold)

        // The new estimator picks the strike and recovers plant and follow-through.
        #expect(contactError(r, s) <= oneFrame(s))
        #expect(r.phases.phase(.plant).status == .detected)
        #expect(r.phases.phase(.followThrough).status == .detected)
        #expect(r.phases.evidence?.plantState == .touchdownDetected)
        let candidates = r.phases.evidence?.contactCandidates ?? []
        let fastest = try #require(candidates.max { $0.peakSpeed < $1.peakSpeed })
        #expect(!fastest.selected)
        #expect(!fastest.rejectionReasons.isEmpty, "the reason is recorded")
        #expect(r.phases.notes.contains { $0.contains("fastest foot motion") }, "the conflict is exposed")
        let chosen = try #require(candidates.first { $0.selected })
        #expect(chosen.independentSupport >= 3, "plant foot, hips and the foot-passing cue all agree")
    }

    @Test func aBackwardBackswingIsRejectedOutright() {
        var s = Script.realWorld30fps
        s.backswingDistance = 0.12
        let r = run(s)
        #expect(contactError(r, s) <= oneFrame(s))
        let rejected = (r.phases.evidence?.contactCandidates ?? []).filter { $0.rejectionReasons.contains { $0.contains("backward") } }
        #expect(!rejected.isEmpty)
        #expect(rejected.allSatisfy { $0.score == 0 })
    }

    @Test func lateFalsePeaksAreNotTakenAsContactEvenWithoutRepair() {
        var s = Script.realWorld30fps
        s.kickingAnkleSpikes = [1.5, 3.0]
        s.spikeSize = 0.3
        let r = run(s, repair: false)
        #expect(contactError(r, s) <= oneFrame(s))
        #expect(r.phases.phase(.plant).isAvailable)
    }

    @Test func anIsolatedSpikeIsRejected() {
        // Hand-built: a one-sample spike (neighbours under 30% of it) is not a swing.
        let n = 40
        var speed = [Double](repeating: 0.5, count: n)
        speed[10] = 12
        for i in 24...30 { speed[i] = [3, 6, 9, 10, 8, 4, 1][i - 24] }
        let times = (0..<n).map { Double($0) / 30 }
        let set = PoseSignalSet(timestamps: times, series: [
            .kickingAnkleSpeed: speed.map { Optional($0) },
            .plantAnkleSpeed: speed.map { _ in Optional(0.1) },
            .bodyCenterSpeed: speed.map { _ in Optional(0.1) },
        ], bodyScale: 0.15, travelDirection: 0)
        let phases = KickPhaseDetector.detect(set, kickType: .fieldGoal)
        let spike = phases.evidence?.contactCandidates?.first { abs($0.time - times[10]) < 1e-9 }
        #expect(spike?.rejectionReasons.contains { $0.contains("isolated") } == true)
        #expect(abs((phases.estimatedContactTime ?? 0) - times[27]) < 1e-9)
    }

    // MARK: Feet, directions, perspective

    @Test func leftFootedAndReversedKicksGiveTheSameTiming() {
        let base = Script.backswingPattern
        var variants: [Script] = []
        for foot in [KickingFoot.right, .left] {
            for direction in [1.0, -1.0] {
                var s = base
                s.kickingFoot = foot
                s.direction = direction
                if direction < 0 { s.startX = 0.88 }
                variants.append(s)
            }
        }
        let times: [Double?] = variants.map { run($0).phases.estimatedContactTime }
        for t in times { #expect(t != nil && abs(t! - base.expectedContact) <= oneFrame(base)) }
        #expect(Set(times.compactMap { $0 }).count == 1, "identical whichever foot or direction")
    }

    @Test func cameraAspectDoesNotChangeTiming() {
        let s = Script.realWorld30fps
        var reference: Double?
        for aspect in [9.0 / 16.0, 1.0, 16.0 / 9.0] {
            var t = SyntheticPose.timeline(s)
            t.displayAspectRatio = aspect
            let r = run(t)
            let contact = r.phases.estimatedContactTime
            #expect(contact != nil)
            if reference == nil { reference = contact }
            #expect(contact == reference, "aspect \(aspect)")
        }
    }

    // MARK: Frame rates

    @Test func sourceFrameRatesAreTimedAtTheAnalysisRate() {
        // Sources of 30/60/120/240 fps are analyzed at min(source, 60) fps
        // (FrameSamplingPlan.standard). Precision is judged in ANALYZED frames.
        for source in [30.0, 60, 120, 240] {
            var s = Script.backswingPattern
            s.frameRate = min(source, 60)
            let r = run(s)
            #expect(contactError(r, s) <= oneFrame(s), "\(source) fps source")
        }
        // Every-frame analysis of slow motion (no jitter, since uncorrelated per-frame
        // jitter at 240 fps is not realistic).
        for fps in [120.0, 240] {
            var s = Script.fieldGoal
            s.frameRate = fps
            let r = run(s)
            #expect(contactError(r, s) <= oneFrame(s), "\(fps) fps every frame")
        }
    }

    @Test func coarseFrameRatesAreFlaggedAndLessConfident() {
        var coarse = Script.fieldGoal
        coarse.frameRate = 10
        let low = run(coarse)
        let normal = run(Script.fieldGoal)
        #expect(low.phases.notes.contains { $0.contains("timing is coarse") })
        #expect(low.phases.phase(.contact).confidence < normal.phases.phase(.contact).confidence)
        let lowUncertainty: Double = low.phases.evidence?.contactUncertaintySeconds ?? 0
        let normalUncertainty: Double = normal.phases.evidence?.contactUncertaintySeconds ?? 1
        #expect(lowUncertainty > normalUncertainty)
    }

    // MARK: Partial, obstructed, no contact, low confidence

    @Test func aClipEndingAtContactHasNoFollowThrough() {
        let s = Script.realWorld30fps
        let trimmed = SyntheticPose.trim(SyntheticPose.timeline(s), from: 0, to: s.expectedContact + 0.04)
        let r = run(trimmed)
        #expect(r.phases.phase(.followThrough).status == .unavailable)
        #expect(r.phases.phase(.contact).isAvailable)
    }

    @Test func aClipStartingMidApproachStillFindsContact() {
        let s = Script.realWorld30fps
        let trimmed = SyntheticPose.trim(SyntheticPose.timeline(s), from: 1.9, to: s.duration)
        let r = run(trimmed)
        #expect(contactError(r, s) <= oneFrame(s))
        #expect(r.phases.phase(.approach).status != .detected, "the approach start isn't in the clip")
    }

    @Test func legsHiddenAroundContactAreNotInvented() {
        let s = Script.realWorld30fps
        var t = SyntheticPose.timeline(s)
        SyntheticPose.occludeLegs(&t, from: s.expectedContact - 0.25, to: s.expectedContact + 0.25)
        let r = run(t)
        if let contact = r.phases.estimatedContactTime {
            #expect(abs(contact - s.expectedContact) > 0.2, "no estimate inside the hidden stretch")
        }
        let clean = run(s)
        #expect(r.phases.phase(.contact).confidence < clean.phases.phase(.contact).confidence)
    }

    @Test func aFeintWithoutContactGivesNoContact() {
        var s = Script.fieldGoal
        s.swingDistance = 0          // no strike…
        s.extraSwingStart = 1.2      // …only a quick out-and-back feint
        s.swingDuration = 0.12
        let r = run(s)
        #expect(r.phases.estimatedContactTime == nil)
        #expect(r.phases.phases.allSatisfy { $0.status == .unavailable })
        #expect(r.phases.notes.contains { $0.contains("supporting evidence") || $0.contains("No kicking motion") })
    }

    @Test func lowConfidenceJointsGiveNoPhases() {
        var s = Script.fieldGoal
        s.confidence = 0.25   // below the 0.3 processing threshold
        let r = run(s)
        #expect(r.phases.phases.allSatisfy { !$0.isAvailable })
    }

    // MARK: Plant states

    @Test func plantStatesAreDistinguished() {
        #expect(run(Script.realWorld30fps).phases.evidence?.plantState == .touchdownDetected)

        var unstable = Script.realWorld30fps
        unstable.plantLiftLead = 0.06
        unstable.plantLiftAtContact = 0.04
        let u = run(unstable)
        #expect(u.phases.evidence?.plantState == .unstableAfterTouchdown)
        #expect(u.phases.phase(.plant).status == .estimated)

        var none = Script.realWorld30fps
        none.plantLiftAtContact = 0
        none.plantTime = none.expectedContact + 0.2
        let n = run(none)
        #expect(n.phases.evidence?.plantState == .notDetected)
        #expect(n.phases.plantTime == nil)
        #expect(n.phases.evidence?.plantCandidates?.contains { $0.accepted } != true)
    }

    @Test func plantMetricsCarryThePhaseConfidenceReduction() {
        var unstable = Script.realWorld30fps
        unstable.plantLiftLead = 0.06
        unstable.plantLiftAtContact = 0.04
        let estimated = SyntheticBiomechanics.analyze(unstable)
        let detected = SyntheticBiomechanics.analyze(.realWorld30fps)
        let a = estimated.measurement(.plantToContactTime)
        let b = detected.measurement(.plantToContactTime)
        // Plant-to-contact needs plant AND contact (always estimated): factors multiply.
        let estimatedFactor: Double = a?.confidenceInputs?.phaseFactor ?? 0
        let detectedFactor: Double = b?.confidenceInputs?.phaseFactor ?? 0
        let reduction: Double = MetricConfidenceModel.phaseFactor(.estimated) ?? 0
        #expect(abs(estimatedFactor - detectedFactor * reduction) < 1e-9, "the estimated plant costs one phase factor")
        #expect(a?.status == .estimated)
    }

    // MARK: Follow-through

    @Test func followThroughUsesTheSwingApexAndIgnoresAQuickDip() {
        let s = Script.realWorld30fps
        let r = run(s)
        let follow = r.phases.phase(.followThrough)
        #expect(follow.status == .detected)
        let end: Double = follow.endTime ?? 0
        let swingEnd: Double = s.swingStart + s.swingDuration
        #expect(abs(end - swingEnd) <= 3 / s.frameRate + 1e-9, "ends near where the swing really ends")
        #expect(r.phases.evidence?.followThroughCandidates?.contains { $0.kind == "swingApex" } == true)
    }

    @Test func followThroughWithASecondSpeedPeakEndsAtTheSustainedSlowdown() {
        let speed: [Double] = [0, 0, 1, 4, 10, 2, 7, 5, 2, 0.4, 0.2, 0.1, 0.1, 0.1]
        let times = speed.indices.map { Double($0) / 30 }
        let set = PoseSignalSet(timestamps: times, series: [
            .kickingAnkleSpeed: speed.map { Optional($0) },
            .plantAnkleSpeed: speed.map { _ in Optional(0.1) },
            .bodyCenterSpeed: speed.map { _ in Optional(0.1) },
        ], bodyScale: 0.15, travelDirection: 0)
        let phases = KickPhaseDetector.detect(set, kickType: .fieldGoal)
        let end: Double = phases.phase(.followThrough).endTime ?? 0
        #expect(abs(end - times[8]) < 1e-9, "the first low sample that stays low")
    }

    // MARK: Ranking

    @Test func rankingIsDeterministic() {
        let a = run(Script.backswingPattern)
        let b = run(Script.backswingPattern)
        #expect(a.phases == b.phases)
        #expect(a.phases.evidence?.contactCandidates == b.phases.evidence?.contactCandidates)
    }

    @Test func twoEquallySupportedKicksAreAmbiguous() {
        // Step 12D: two real kicks (each with an approach) need the user's choice.
        let r = run(SyntheticPose.concatenated([.fieldGoal, .fieldGoal]))
        #expect(r.phases.phase(.contact).status == .ambiguous)
        #expect(r.phases.kickWindows?.needsSelection == true)
        let kicks: Int = r.phases.kickWindows?.windows.filter { $0.hasSwing }.count ?? 0
        #expect(kicks == 2)
    }

    @Test func aWrongKickingFootIsNotSilentlyCorrected() {
        // A left-footed kick analyzed as right-footed: the "kicking" leg is really the plant
        // leg, so no kick is found on it. Nothing silently swaps sides.
        var s = Script.realWorld30fps
        s.kickingFoot = .left
        let r = run(SyntheticPose.timeline(s), foot: .right)
        #expect(r.phases.phase(.plant).status != .detected)
    }

    @Test func aPlantLegThatSwingsFastestIsALegRoleConflict() {
        let n = 30
        let times = (0..<n).map { Double($0) / 30 }
        let kicking: [Double?] = (0..<n).map { $0 == 15 ? 4 : ($0 == 14 || $0 == 16 ? 3 : 0.2) }
        let plant: [Double?] = (0..<n).map { abs($0 - 15) <= 1 ? 12 : 0.3 }
        let set = PoseSignalSet(timestamps: times, series: [.kickingAnkleSpeed: kicking, .plantAnkleSpeed: plant],
                                bodyScale: 0.15, travelDirection: 1)
        // The kicking ankle is at rest for the 0.15 s before the moment being checked.
        #expect(KickPhaseDetector.legRoleConflict(set, times, contactTime: times[22], kickingPeak: 4, threshold: 1))
        #expect(!KickPhaseDetector.legRoleConflict(set, times, contactTime: times[22], kickingPeak: 11, threshold: 1))
    }

    // MARK: Validation harness

    private func harnessChecks() -> [ContactTimingCheck] {
        var cases: [(String, Script)] = []
        cases.append(("correct kick", .realWorld30fps))
        cases.append(("backswing early peak", .backswingPattern))
        var late = Script.realWorld30fps; late.kickingAnkleSpikes = [3.0]; late.spikeSize = 0.3
        cases.append(("late spike", late))
        var rolling = Script.realWorld30fps; rolling.plantLiftAtContact = 0.03
        cases.append(("plant rolling", rolling))
        var moving = Script.realWorld30fps; moving.plantLiftLead = 0.06; moving.plantLiftAtContact = 0.04
        cases.append(("plant moving through contact", moving))
        var slow = Script.realWorld30fps; slow.approachSpeed = 0.12
        cases.append(("slow approach", slow))
        cases.append(("kickoff", .kickoff))
        var lefty = Script.backswingPattern; lefty.kickingFoot = .left
        cases.append(("left-footed", lefty))
        var reversed = Script.backswingPattern; reversed.direction = -1; reversed.startX = 0.88
        cases.append(("reversed direction", reversed))
        var sixty = Script.backswingPattern; sixty.frameRate = 60
        cases.append(("60 fps", sixty))
        return cases.map { label, s in
            let r = run(s, kickType: label == "kickoff" ? .kickoff : .fieldGoal)
            return ContactTimingCheck(label: label, referenceTime: s.expectedContact, estimatedTime: r.phases.estimatedContactTime,
                                      confidence: r.phases.phase(.contact).confidence, sourceFrameRate: s.frameRate,
                                      analysisFrameRate: s.frameRate, referenceUncertaintyFrames: 0)
        }
    }

    @Test func theSyntheticValidationCollectionIsWithinOneFrame() {
        let checks = harnessChecks()
        let summary = ContactTimingSummary(checks)
        #expect(summary.count == 10)
        #expect(summary.missing == 0)
        #expect(summary.withinOneFrame == 1, "\(ContactTimingSummary.report(checks))")
        let median: Double = summary.medianAbsoluteError ?? 1
        let p90: Double = summary.p90AbsoluteError ?? 1
        #expect(median <= 1 / 60.0 + 1e-6)
        #expect(p90 <= 1 / 30.0 + 1e-6)
        let report = ContactTimingSummary.report(checks)
        #expect(report.contains("within 1 / 2 / 3 frames"))
        #expect(report.contains("backswing early peak"))
    }

    @Test func harnessStatisticsAndCalibration() {
        func check(_ error: Double, _ confidence: Double) -> ContactTimingCheck {
            ContactTimingCheck(label: "c", referenceTime: 2, estimatedTime: 2 + error, confidence: confidence,
                               sourceFrameRate: 30, analysisFrameRate: 30)
        }
        let checks = [check(0.0, 0.9), check(0.033, 0.8), check(-0.1, 0.3), check(0.2, 0.2),
                      ContactTimingCheck(label: "none", referenceTime: 2, estimatedTime: nil, confidence: nil,
                                         sourceFrameRate: 30, analysisFrameRate: 30)]
        let s = ContactTimingSummary(checks)
        #expect(s.missing == 1)
        #expect(checks[2].errorMilliseconds == -100)
        #expect(checks[2].absoluteErrorFrames == 3)
        #expect(abs(s.withinOneFrame - 2.0 / 5) < 1e-9, "missing estimates count as misses")
        #expect(abs(s.withinThreeFrames - 3.0 / 5) < 1e-9)
        #expect(s.medianAbsoluteError == 0.033)
        #expect(s.p90AbsoluteError == 0.2)
        let calibration = s.calibration
        #expect(calibration?.higherConfidenceIsMoreAccurate == true)
        let inverted = [check(0.2, 0.9), check(0.1, 0.8), check(0.0, 0.3), check(0.01, 0.2)]
        #expect(ContactTimingSummary(inverted).calibration?.higherConfidenceIsMoreAccurate == false)
    }

    // MARK: Reference library

    private func referenceClip(_ s: Script = .backswingPattern, contact: Double? = nil) -> ContactReferenceClip {
        var sequence = SyntheticPose.sequence(s)
        sequence.kickerTrackID = nil
        let tracked = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal,
                                                                         kickingFoot: s.kickingFoot)).sequence
        return ContactReferenceClip(clipID: "fg-side-30fps-test", kickType: .fieldGoal, kickingFoot: s.kickingFoot,
                                    cameraAngle: .side, sourceFrameRate: s.frameRate,
                                    annotatedContactTime: contact ?? s.expectedContact, annotationUncertaintyFrames: 1,
                                    annotator: "test", rightsNote: "synthetic", poseEngineVersion: nil, sequence: tracked)
    }

    @Test func referenceClipsRoundTripAndAreEvaluated() throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let clip = referenceClip()
        try JSONEncoder().encode(clip).write(to: temp.url.appendingPathComponent("a.json"))
        try Data("not a clip".utf8).write(to: temp.url.appendingPathComponent("notes.txt"))
        let library = try ContactValidationHarness.loadLibrary(at: temp.url)
        #expect(library == [clip])
        let check = ContactValidationHarness.evaluate(library[0])
        #expect(check.withinTolerance)
        #expect(check.label == "fg-side-30fps-test")
        #expect(check.referenceUncertaintyFrames == 1)

        try Data("{\"kind\":\"other\"}".utf8).write(to: temp.url.appendingPathComponent("b.json"))
        #expect(throws: (any Error).self) { try ContactValidationHarness.loadLibrary(at: temp.url) }
    }

    @Test func theAnnotationNeverReachesTheEstimate() {
        // The estimator's inputs carry no annotation; a wildly wrong mark changes only the error.
        let right = ContactValidationHarness.evaluate(referenceClip())
        let wrong = ContactValidationHarness.evaluate(referenceClip(contact: 0.5))
        #expect(right.estimatedTime == wrong.estimatedTime)
        #expect(right.estimateConfidence == wrong.estimateConfidence)
        #expect(!wrong.withinTolerance)
    }

    @Test func thePrivateValidationLibraryIsEvaluatedWhenPresent() throws {
        // Real, human-annotated clips go in KickLabTests/ValidationLibrary/*.json (see its
        // README). None are committed yet, so this reports 0 clips until some are added.
        let directory = URL(fileURLWithPath: #filePath).deletingLastPathComponent().appendingPathComponent("ValidationLibrary")
        let clips = try ContactValidationHarness.loadLibrary(at: directory)
        let checks = clips.map(ContactValidationHarness.evaluate)
        print("Validation library: \(clips.count) real clip(s)\n\(ContactTimingSummary.report(checks))")
        #expect(checks.count == clips.count)
    }

    // MARK: Annotation isolation in the engine

    @Test func aMarkedContactInTheRequestDoesNotChangeTheAnalysis() async throws {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        let kickID = UUID(), videoID = UUID()
        let path = ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: "mov")
        try temp.writeFile(path, under: store.mediaRootURL)
        let engine = PoseVideoAnalysisService(mediaStore: store,
                                              extractor: FakePoseExtractor { SyntheticPose.sequence(.backswingPattern, videoID: $0) },
                                              now: { Date(timeIntervalSince1970: 1_800_000_000) })
        func request(_ contact: Double?) -> VideoAnalysisRequest {
            VideoAnalysisRequest(kickID: kickID, kickType: .fieldGoal, inputs: [
                VideoAnalysisInput(videoID: videoID, angle: .side, isPrimary: true, relativeFilePath: path, frameRate: 30,
                                   durationSeconds: 6.5, syncOffsetSeconds: 0, contactTimeSeconds: contact),
            ], options: VideoAnalysisOptions())
        }
        let without = try await engine.analyze(request(nil)) { _ in }
        let with = try await engine.analyze(request(0.5)) { _ in }
        #expect(without.metrics == with.metrics)
        #expect(without.categoryScores == with.categoryScores)
        #expect(without.poseSummary?.estimatedContactTime == with.poseSummary?.estimatedContactTime)
    }

    // MARK: Old artifacts

    @Test func step12BEvidenceStillDecodes() throws {
        let json = #"{"contactPeakTime":2.333,"contactPeakSpeed":18.767,"anklePassTime":2.419,"plantStillThreshold":1.457}"#
        let evidence = try JSONDecoder().decode(PhaseDetectionEvidence.self, from: Data(json.utf8))
        #expect(evidence.contactPeakTime == 2.333)
        #expect(evidence.contactCandidates == nil)
        #expect(evidence.algorithmVersion == nil)
        #expect(throws: (any Error).self) {
            try JSONDecoder().decode(PhaseDetectionEvidence.self, from: Data("{\"contactPeakTime\":\"x\"}".utf8))
        }
    }

    // MARK: Overlay

    @Test func aspectFitLetterboxesAndPillarboxesWithoutDistortion() {
        // Portrait video in a landscape container: pillarboxed.
        let pillar = PoseOverlayGeometry.aspectFitRect(containerWidth: 400, containerHeight: 300, contentAspect: 9.0 / 16.0)
        #expect(abs(pillar.height - 300) < 1e-9)
        #expect(abs(pillar.width - 168.75) < 1e-9)
        #expect(abs(pillar.x - 115.625) < 1e-9)
        // Landscape video in a portrait container: letterboxed.
        let letter = PoseOverlayGeometry.aspectFitRect(containerWidth: 300, containerHeight: 400, contentAspect: 16.0 / 9.0)
        #expect(abs(letter.width - 300) < 1e-9)
        #expect(abs(letter.height - 168.75) < 1e-9)
        #expect(abs(letter.y - 115.625) < 1e-9)
        // The aspect ratio of the drawn rect always equals the video's.
        let sizes: [(Double, Double, Double)] = [(390, 420, 9.0 / 16.0), (1024, 420, 16.0 / 9.0), (300, 300, 4.0 / 3.0)]
        for (w, h, a) in sizes {
            let r = PoseOverlayGeometry.aspectFitRect(containerWidth: w, containerHeight: h, contentAspect: a)
            #expect(abs(r.width / r.height - a) < 1e-9)
            #expect(r.x >= 0 && r.y >= 0 && r.x + r.width <= w + 1e-9 && r.y + r.height <= h + 1e-9)
        }
        let p = PoseOverlayGeometry.point(x: 0.5, y: 1, in: pillar)
        #expect(abs(p.x - 200) < 1e-9 && abs(p.y - 300) < 1e-9)
        let degenerate = PoseOverlayGeometry.aspectFitRect(containerWidth: 100, containerHeight: 0, contentAspect: 1)
        #expect(degenerate.height == 0)
    }

    private func validationTimeline(_ s: Script = .backswingPattern, marked: Double? = 2.5) -> PoseValidationTimeline? {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(s), kickType: .fieldGoal,
                                                                     kickingFoot: s.kickingFoot))
        let replay = DiagnosticsReplay.run(AnalysisDiagnosticsInput(output: out), kickingFoot: s.kickingFoot)
        return PoseValidationTimeline.make(sequence: out.sequence, storedTimeline: out.kickerTimeline,
                                           currentTimeline: replay?.timeline, repair: replay?.replay.repair,
                                           kickingFoot: s.kickingFoot, storedPhases: out.phases,
                                           currentPhases: replay?.phases, markedContact: marked)
    }

    @Test func theValidationTimelineAlignsPoseWithVideoTime() throws {
        let t = try #require(validationTimeline())
        #expect(t.availableSources == [.raw, .stored, .current])
        #expect(t.limitations.allSatisfy { !$0.contains("no stored processed pose") })
        #expect(t.markers.contains { $0.kind == .contact && abs($0.time - 2.5) < 0.034 })
        #expect(t.markers.contains { $0.kind == .plant })
        #expect(t.markers.contains { $0.kind == .followThroughEnd })
        #expect(t.markers.contains { $0.kind == .markedContact && $0.time == 2.5 })
        #expect(t.markers.contains { $0.kind == .contactCandidate }, "rejected candidates can be jumped to")
        #expect(t.markers == t.markers.sorted { $0.time < $1.time })

        // Nearest analyzed frame, within half an interval; nothing between far samples.
        let i = try #require(t.sampleIndex(at: 2.5))
        #expect(abs(t.timestamps[i] - 2.5) < 1e-9)
        #expect(t.sampleIndex(at: 2.5 + 0.4 / 30) == i)
        #expect(t.sampleIndex(at: 99) == nil)
        // Stepping uses stored timestamps: 50 steps land exactly on sample i + 50.
        var time = t.timestamps[i]
        for _ in 0..<50 { time = t.steppedTime(from: time, by: 1) ?? time }
        #expect(time == t.timestamps[i + 50])
        for _ in 0..<50 { time = t.steppedTime(from: time, by: -1) ?? time }
        #expect(time == t.timestamps[i])
        #expect(t.steppedTime(from: 0, by: -5) == t.timestamps[0], "clamped at the start")

        // Joints are drawn where the pose says, colored by leg role.
        let joints = t.overlay(at: i, source: .raw)
        let ankle = try #require(joints.first { $0.joint == .rightAnkle })
        let raw = try #require(t.raw[i][.rightAnkle])
        #expect(ankle.x == raw.x && ankle.y == raw.y)
        #expect(ankle.role == .kickingLeg)
        #expect(joints.first { $0.joint == .leftAnkle }?.role == .plantLeg)
        #expect(t.bones().contains { $0.from == .rightKnee && $0.to == .rightAnkle && $0.role == .kickingLeg })
    }

    @Test func repairedJointsAreMarkedInTheCurrentPoseOnly() throws {
        let s = Script.realWorld30fps
        var frames = SyntheticPose.frames(s)
        let swapAt = SyntheticPose.sampleTime(s, near: 2.433)
        for i in frames.indices where abs(frames[i].timestamp - swapAt) < 1e-6 {
            var body = frames[i].bodies[0]
            for (a, b) in [(PoseJoint.leftAnkle, PoseJoint.rightAnkle), (.leftKnee, .rightKnee)] {
                let x = body.joints[a]
                body.joints[a] = body.joints[b]
                body.joints[b] = x
            }
            frames[i].bodies[0] = BodyPose(joints: body.joints, trackID: body.trackID)
        }
        var sequence = SyntheticPose.sequence(s)
        sequence.frames = frames
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right))
        let replay = DiagnosticsReplay.run(AnalysisDiagnosticsInput(output: out), kickingFoot: .right)
        let t = try #require(PoseValidationTimeline.make(
            sequence: out.sequence, storedTimeline: out.kickerTimeline, currentTimeline: replay?.timeline,
            repair: replay?.replay.repair, kickingFoot: .right, storedPhases: out.phases, currentPhases: replay?.phases,
            markedContact: nil))
        let i = try #require(t.sampleIndex(at: swapAt))
        #expect(t.overlay(at: i, source: .current).contains { $0.repaired && $0.joint == .rightAnkle })
        #expect(!t.overlay(at: i, source: .raw).contains { $0.repaired })
        // Raw shows Vision's swapped labels; current shows them repaired.
        let rawRight = try #require(t.raw[i][.rightAnkle])
        let currentRight = try #require(t.current?[i][.rightAnkle])
        #expect(abs(rawRight.x - currentRight.x) > 0.02)
    }

    @Test func historicalArtifactsWithoutAProcessedPoseSayTheLimitation() throws {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal,
                                                                     kickingFoot: .right))
        let t = try #require(PoseValidationTimeline.make(
            sequence: out.sequence, storedTimeline: nil, currentTimeline: nil, repair: nil, kickingFoot: .right,
            storedPhases: out.phases, currentPhases: nil, markedContact: nil))
        #expect(t.availableSources == [.raw])
        #expect(t.limitations.count == 2)
        var untracked = out.sequence
        untracked.kickerTrackID = nil
        #expect(PoseValidationTimeline.make(sequence: untracked, storedTimeline: nil, currentTimeline: nil, repair: nil,
                                            kickingFoot: .right, storedPhases: nil, currentPhases: nil, markedContact: nil) == nil)
    }

    @Test func mirroredVideosKeepStoredDisplayCoordinates() throws {
        var sequence = SyntheticPose.sequence(.fieldGoal)
        sequence.isMirrored = true
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right))
        let t = try #require(PoseValidationTimeline.make(
            sequence: out.sequence, storedTimeline: out.kickerTimeline, currentTimeline: nil, repair: nil, kickingFoot: .right,
            storedPhases: out.phases, currentPhases: nil, markedContact: nil))
        #expect(t.isMirrored)
        // Coordinates are already in displayed (mirrored) space: drawn as stored, no second flip.
        let joint = try #require(t.overlay(at: 10, source: .raw).first { $0.joint == .rightAnkle })
        #expect(joint.x == t.raw[10][.rightAnkle]?.x)
    }

    @Test func contactComparisonText() {
        let late = ContactComparison(marked: 2.5, estimated: 2.333, framesPerSecond: 30)
        #expect(late.signedMilliseconds == -167)
        #expect(late.absoluteMilliseconds == 167)
        #expect(late.frames == -5.01)
        #expect(late.text.contains("before the marked contact"))
        #expect(ContactComparison(marked: 2.5, estimated: nil, framesPerSecond: 30).text.contains("No automatic"))
    }

    // MARK: Presentation integrity

    @Test func gradesOnThinEvidenceAreTentative() {
        #expect(ScoreGrade.excellent.label(confidence: 0.9) == "Excellent")
        #expect(ScoreGrade.excellent.label(confidence: 0.47) == "Excellent · tentative")
        #expect(ScoreGrade.unavailable.label(confidence: 0.1) == "Not scored")
    }

    @Test func noCorrectionsIsQualifiedWhenEvidenceIsPartial() {
        let partial = SyntheticBiomechanics.analyze({ () -> Script in
            var s = Script.realWorld30fps
            s.plantLiftAtContact = 0
            s.plantTime = s.expectedContact + 0.2
            return s
        }())
        let cards = KickMetricCatalog.scoredCategories.map { category in
            CategoryCardPresentation(category: category, title: category.presentationTitle,
                                     score: partial.categories.first { $0.category == category }?.score, scoreText: "",
                                     grade: .unavailable, confidence: partial.categories.first { $0.category == category }?.confidence,
                                     confidenceText: "", summary: nil, topMetrics: [], unavailableMetricNames: [])
        }
        let header = AnalysisHeaderPresentation(kickTypeText: "", date: Date(timeIntervalSince1970: 0), overallScore: nil,
                                                overallScoreText: "", grade: .unavailable, confidence: nil, confidenceText: "",
                                                isCurrent: true, statusText: "")
        let presentation = AnalysisResultsPresentation(header: header, categories: cards, metrics: [], priorities: [],
                                                       strengths: [], notes: [], problem: nil)
        #expect(presentation.noCorrectionsDetail.contains("not a clean bill of health"))
    }
}
