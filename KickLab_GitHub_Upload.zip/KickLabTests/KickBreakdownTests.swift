import Foundation
import Testing
@testable import KickLab

/// Build 22: the phase-by-phase Kick Breakdown — statuses, numbers and words agree, the
/// priority is supported, and nothing the camera can't measure is graded. Pure (Linux).
@Suite("Build 22: Kick Breakdown")
struct KickBreakdownTests {
    static func row(_ key: KickMetricKey, _ value: Double, confidence: Double = 0.8) -> MetricRowPresentation {
        let d = key.definition
        return MetricRowPresentation(key: key, name: d.displayName, explanation: d.explanation,
                                     valueText: DisplayFormat.metricValue(value, unit: d.unit), value: value, unit: d.unit,
                                     status: .measured, statusText: "Measured", confidence: confidence,
                                     confidenceText: DisplayFormat.confidence(confidence), category: d.category)
    }

    static func card(_ c: AnalysisCategory, _ score: Double?) -> CategoryCardPresentation {
        CategoryCardPresentation(category: c, title: c.presentationTitle, score: score, scoreText: DisplayFormat.score(score),
                                 grade: ScoreGrade(score: score), confidence: score == nil ? nil : 0.7, confidenceText: "",
                                 summary: score == nil ? "Not enough reliable measurements to score (0 of 3 measurements available)." : nil,
                                 topMetrics: [], unavailableMetricNames: [])
    }

    static func coaching(_ c: AnalysisCategory, cue: String, keys: [KickMetricKey], priority: Int) -> CoachingItemPresentation {
        CoachingItemPresentation(id: UUID(), category: c, categoryTitle: c.presentationTitle, observed: "Observed on this kick.",
                                 whyItMatters: nil, cue: cue, severity: .moderate, severityText: nil, confidence: 0.8,
                                 confidenceText: "", priority: priority, evidenceMetricKeys: keys.map(\.rawValue))
    }

    static let markers = [
        PhaseMarker(phase: .approach, title: "Approach", time: 2.4, isEstimated: false, source: .detected),
        PhaseMarker(phase: .plant, title: "Plant", time: 3.77, isEstimated: true, source: .estimated),
        PhaseMarker(phase: .contact, title: "Contact", time: 3.937, isEstimated: false, source: .fromBall),
        PhaseMarker(phase: .followThrough, title: "Follow-Through", time: 3.97, isEstimated: false, source: .detected),
    ]

    /// A side-view kick: approach measured but not graded (Build 22, provisional-bands-3),
    /// plant "Strength", swing "Solid", contact "Solid", follow-through "Work on" (low finish).
    static func sideInput() -> KickBreakdownBuilder.Input {
        KickBreakdownBuilder.Input(
            kickType: .fieldGoal,
            metrics: [row(.approachSpeed, 2.6), row(.approachSpeedVariation, 40), row(.approachLateSpeedChange, 10),
                      row(.plantFootDrift, 0.05), row(.plantKneeAngleAtContact, 150), row(.plantToContactTime, 0.17),
                      row(.kickingKneeAngleAtContact, 165), row(.backswingDepth, 1.1), row(.peakFootSpeed, 26),
                      row(.torsoLeanAtContact, -4), row(.bodyForwardSpeedAtContact, 3.2),
                      row(.followThroughFootHeight, 0.2), row(.followThroughDuration, 0.3), row(.followThroughBodyTravel, 0.6)],
            categories: [card(.approach, nil), card(.plant, 92), card(.swing, 80), card(.contact, 74), card(.followThrough, 60)],
            coaching: [coaching(.followThrough, cue: "Finish tall: swing the kicking foot up through the target line.",
                                keys: [.followThroughFootHeight], priority: 1),
                       coaching(.plant, cue: "Keep doing it.", keys: [.plantFootDrift], priority: 2)],
            markers: markers, viewText: "Side view", contactOutcome: .ballConstrainedContactInterval, contactTime: 3.937,
            overallScore: 73.6)
    }

    @Test func aSideViewKickReadsConsistently() throws {
        let b = KickBreakdownBuilder.make(Self.sideInput())
        #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
        let status = Dictionary(uniqueKeysWithValues: b.phases.map { ($0.phase, $0.status) })
        #expect(status[.approach] == .notGraded, "Build 22: the approach is measured, not graded")
        #expect(status[.plant] == .strength)
        #expect(status[.swing] == .solid)
        #expect(status[.followThrough] == .workOn)
        #expect(status[.setup] == .notMeasured)
        // The work-on card is explained by its weakest measurement, stated with its target.
        let ft = try #require(b.phases.first { $0.phase == .followThrough })
        #expect(ft.headline?.key == .followThroughFootHeight)
        #expect(ft.explanation.contains("below the provisional target"))
        #expect(ft.explanation.contains("(0.50–3.00 torso lengths)"), "\(ft.explanation)")
        // The approach still shows its measurements, without a grade.
        #expect(b.phases.first { $0.phase == .approach }?.headline != nil)
        // One priority, in a phase that needs work, resting on a measurement shown there.
        let p = try #require(b.priority)
        #expect(p.phase == .followThrough && p.metricKey == .followThroughFootHeight)
        #expect(p.drillTitle != nil)
        #expect(p.checkNextKick.contains("this kick:"))
        #expect(b.grade.text == "Technique 74 · Good")
        #expect(b.grade.basis.contains("4 of 4 areas graded"), "\(b.grade.basis)")
        #expect(b.phases.first { $0.phase == .approach }?.explanation.contains("doesn't grade the approach yet") == true)
        #expect(b.contactText.contains("from the ball"))
        #expect(b.coachSummary.contains("Strongest area: plant"))
        #expect(b.coachSummary.contains("Biggest gain: follow-through"))
        // Frames: swing and contact share the contact frame; the plant has its own.
        #expect(b.phases.first { $0.phase == .contact }?.frameTime == 3.937)
        #expect(b.phases.first { $0.phase == .plant }?.frameSource == "Plant · estimated")
    }

    @Test func targetBarsPlaceTheValueWhereTheVerdictSays() throws {
        let b = KickBreakdownBuilder.make(Self.sideInput())
        let ft = try #require(b.phases.first { $0.phase == .followThrough }?.headline)
        let g = try #require(ft.gauge)
        // 0.20 torso lengths, below a 0.50–3.00 target.
        #expect(ft.verdict == .below && g.value < g.targetStart && !g.openLow && !g.openHigh)
        // "≥ 20 torso lengths/s" runs to the end of the bar.
        let speed = try #require(b.phases.first { $0.phase == .swing }.flatMap { c in ([c.headline].compactMap { $0 } + c.others).first { $0.key == .peakFootSpeed } })
        #expect(speed.gauge?.openHigh == true && speed.gauge?.targetEnd == 1)
        #expect(speed.verdict == .inside)
        // Torso lean −4° shows a real minus sign, like its target.
        let lean = try #require(b.phases.first { $0.phase == .contact }?.headline)
        #expect(lean.valueText.hasPrefix("−"), "\(lean.valueText)")
        // No target, no bar.
        #expect(b.phases.first { $0.phase == .approach }?.headline?.gauge == nil)
    }

    @Test func theFollowThroughCardShowsTheHighestFootPoint() throws {
        var input = Self.sideInput()
        input.frames = KickBreakdownBuilder.frames(samples: [.followThroughFootHeight: .init(value: 1.2, time: 4.12),
                                                             .followThroughDuration: .init(value: 0.3, time: 3.937),
                                                             .plantToContactTime: .init(value: 0.17, time: 3.77)])
        let b = KickBreakdownBuilder.make(input)
        let ft = try #require(b.phases.first { $0.phase == .followThrough })
        #expect(ft.frameTime == 4.12 && ft.frameSource == "Follow-through · highest foot point")
        #expect(b.phases.first { $0.phase == .plant }?.frameTime == 3.77, "other cards keep their phase marker")
        // Without the height (foot left the frame), the end of the measured swing.
        let end = KickBreakdownBuilder.frames(samples: [.followThroughDuration: .init(value: 0.3, time: 3.937)])[.followThrough]
        #expect(end.map { abs($0.time - 4.237) < 1e-9 } == true && end?.label == "Follow-through · end of the swing")
    }

    @Test func aCoachingCueForAGoodAreaIsNeverThePriority() {
        var input = Self.sideInput()
        input.coaching = [Self.coaching(.plant, cue: "Plant closer.", keys: [.plantFootDrift], priority: 1)]
        let b = KickBreakdownBuilder.make(input)
        #expect(b.priority == nil, "the plant is a Strength on this kick")
        #expect(b.noPriorityText != nil)
        #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
    }

    @Test func withNoFixAGoodAreasOutOfTargetMeasurementIsWatched() throws {
        var input = Self.sideInput()
        input.coaching = []
        // Every graded area good; the follow-through height (0.20, below 0.50–3.00) remains.
        input.categories = [Self.card(.approach, nil), Self.card(.plant, 92), Self.card(.swing, 80), Self.card(.contact, 74), Self.card(.followThrough, 86)]
        let b = KickBreakdownBuilder.make(input)
        #expect(b.priority == nil)
        let w = try #require(b.watch)
        #expect(w.phase == .followThrough && w.measurement.key == .followThroughFootHeight)
        #expect(w.text == "Watch: follow-through leg height 0.20 torso lengths, below the provisional target (0.50–3.00 torso lengths).")
        #expect(b.coachSummary.hasSuffix(w.text))
        #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
    }

    @Test func aPriorityMustRestOnAMeasurementTheCardShows() {
        var input = Self.sideInput()
        // The finding cites a measurement this recording didn't produce.
        input.coaching = [Self.coaching(.followThrough, cue: "Swing longer.", keys: [.kneeSwingAfterContact], priority: 1)]
        let b = KickBreakdownBuilder.make(input)
        #expect(b.priority == nil)
    }

    @Test func aRearViewIsMeasuredButNotGraded() throws {
        let input = KickBreakdownBuilder.Input(
            kickType: .fieldGoal,
            metrics: [Self.row(.plantToContactTime, 0.133), Self.row(.followThroughDuration, 0.467),
                      Self.row(.lateralTrunkLeanAtContact, 6.4), Self.row(.plantBallLateralOffset, -0.61), Self.row(.plantLateralMovement, 0.085)],
            categories: [Self.card(.approach, nil), Self.card(.plant, nil), Self.card(.swing, nil), Self.card(.contact, nil), Self.card(.followThrough, nil)],
            coaching: [], markers: Self.markers, viewText: "View from behind", contactOutcome: .ballConstrainedContactInterval,
            contactTime: 3.95, overallScore: nil, recordingAdvice: PerformanceReport.sideRecording)
        let b = KickBreakdownBuilder.make(input)
        #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
        #expect(b.grade.text == "Not graded")
        #expect(b.grade.basis.hasPrefix("Fewer than 3 areas could be graded"))
        #expect(b.phases.allSatisfy { !$0.status.isGraded })
        #expect(b.phases.first { $0.phase == .plant }?.status == .notGraded)
        #expect(b.phases.first { $0.phase == .swing }?.status == .notMeasured)
        // No target is invented for a sideways measurement.
        let plant = try #require(b.phases.first { $0.phase == .plant })
        #expect(plant.headline?.verdict == .noTarget)
        #expect(plant.explanation.contains("No target is set"))
        #expect(b.priority == nil)
        #expect(b.noPriorityText?.contains("Record from the side") == true)
        #expect(b.coachSummary.hasPrefix("Measured on this kick:"))
    }

    @Test func aLowConfidenceGradedMeasurementIsShownButNotCountedAsReliable() throws {
        // Device diagnostics (App 0.1.0 (24)): plant-foot movement 0.107 at confidence 0.33
        // (below the 0.35 scoring minimum), plant knee 150° at 0.51 → plant not graded.
        var input = Self.sideInput()
        input.metrics = [Self.row(.plantFootDrift, 0.107, confidence: 0.328), Self.row(.plantKneeAngleAtContact, 149.6, confidence: 0.509),
                         Self.row(.plantToContactTime, 0.033, confidence: 0.477), Self.row(.torsoLeanAtContact, -9.4, confidence: 0.69)]
        input.categories = [Self.card(.approach, nil), Self.card(.plant, nil), Self.card(.swing, nil), Self.card(.contact, 97), Self.card(.followThrough, nil)]
        input.coaching = []
        input.overallScore = nil
        let b = KickBreakdownBuilder.make(input)
        let plant = try #require(b.phases.first { $0.phase == .plant })
        #expect(plant.status == .notGraded)
        #expect(plant.reason == "Not graded: 1 of 2 graded measurements was reliable on this kick — not usable: plant-foot movement (low confidence).",
                "\(plant.reason ?? "")")
        #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
    }

    @Test func theCheckCatchesContradictions() {
        var b = KickBreakdownBuilder.make(Self.sideInput())
        // A pill that disagrees with its score.
        b.phases[3].status = .strength
        // A sentence that disagrees with its number.
        b.phases[5].explanation = "Finish height looked great."
        let issues = KickBreakdownCheck.issues(b)
        #expect(issues.contains { $0.contains("Swing: status Strength but score 80") })
        #expect(issues.contains { $0.contains("Follow-through: explanation doesn't state") })
    }

    @Test func everySyntheticKickTypeBuildsAConsistentBreakdown() {
        // Real engine output on the synthetic kicks (all scripted cases).
        for script in [SyntheticPose.KickScript.fieldGoal, .realWorld30fps] {
            let r = SyntheticBiomechanics.analyze(script)
            let rows = r.measurements.filter(\.isAvailable).compactMap { m in m.value.map { Self.row(m.key, $0, confidence: m.confidence ?? 0.5) } }
            let cards = r.categories.filter { $0.category != .overall }.map { Self.card($0.category, $0.score) }
            let b = KickBreakdownBuilder.make(KickBreakdownBuilder.Input(
                kickType: .fieldGoal, metrics: rows, categories: cards, coaching: [], markers: Self.markers, viewText: "Side view",
                contactOutcome: .poseEstimatedContact, contactTime: 1.4, overallScore: r.overallScore))
            #expect(KickBreakdownCheck.issues(b).isEmpty, "\(KickBreakdownCheck.issues(b))")
        }
    }

    @Test func contactMarkersSayWhenTheBallTimedContact() {
        var evidence = PhaseDetectionEvidence(contactPeakTime: 1.4, contactPeakSpeed: 10)
        evidence.contactProvenance = "ballAware"
        evidence.contactOutcome = .ballConstrainedContactInterval
        var result = KickPhaseDetectionResult(kickType: .fieldGoal, support: .full,
                                              phases: KickPhase.allCases.map { p in
                                                  p == .contact ? DetectedKickPhase(phase: .contact, startTime: 1.4, endTime: 1.4, representativeTime: 1.4,
                                                                                    confidence: 0.7, evidence: [], status: .estimated)
                                                      : .unavailable(p) },
                                              overallConfidence: 0.5, dataCoverage: 1, notes: [])
        result.evidence = evidence
        let m = PhaseMarker.markers(from: result)
        #expect(m.first { $0.phase == .contact }?.source == .fromBall)
        #expect(m.first { $0.phase == .contact }?.source.label == "timed from the ball")
    }
}
