import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: Step 12A diagnostics through the real runner, SwiftData and files.
@MainActor
@Suite("Step 12A diagnostics in the app")
struct DiagnosticsViewModelTests {
    /// The real pose engine on synthetic pose at the given Vision confidence.
    private func engine(_ x: AppFixtureStore, confidence: Double) -> PoseVideoAnalysisService {
        var script = SyntheticPose.KickScript.fieldGoal
        script.confidence = confidence
        let fixed = script
        return PoseVideoAnalysisService(mediaStore: x.store, extractor: FakePoseExtractor { SyntheticPose.sequence(fixed, videoID: $0) })
    }

    @Test func rearCameraFailureIsDiagnosedEndToEnd() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.55))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .rear)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .failed(.cameraAngleLimited), "not 'legs weren't visible'")
        let analysisID = try #require(run.lastAnalysisID)
        let analysis = try #require(ModelLookup.analysis(analysisID, in: x.app.context))
        #expect(analysis.failureReason == AnalysisFailureCause.cameraAngleLimited.reasonText)
        #expect(analysis.artifactsRelativePath != nil, "files are kept for diagnosis")

        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: analysisID)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(report.hasAnalysisFiles)
        #expect(report.failureCause == .cameraAngleLimited)
        #expect(report.storedStatus == ProcessingStatus.failed.rawValue)
        #expect(report.cameraAngle == .rear)
        #expect(report.kickingFoot == .right)
        #expect(report.manualKickerSelection == false)
        #expect((report.framesSampled ?? 0) > 0)
        #expect(report.joints.contains { $0.joint == .rightAnkle && $0.role == "kicking" && $0.detectedFrames > 0 })
        #expect(report.plainText.contains("Diagnosed cause: cameraAngleLimited"))
    }

    @Test func sideViewOfTheSameKickIsScored() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.55))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        guard case .completed(let id) = run.state else {
            Issue.record("expected completion, got \(run.state)")
            return
        }
        #expect(run.lastAnalysisID == id)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: id)
        await diagnostics.load(app: x.app)
        #expect(diagnostics.state.value?.failureCause == nil)
        #expect((diagnostics.state.value?.scoredCategoryCount ?? 0) > 0)
    }

    @Test func analysesWithoutFilesStillGetASummary() async throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try x.f.addVideo(to: kick, path: "k/old.mov")
        let analysis = try x.f.analyses.createAnalysis(for: kick, analysisVersion: "1", inputVideos: [video])
        try x.f.analyses.startProcessing(analysis)
        try x.f.analyses.markFailed(analysis, reason: "The analysis failed: Pose detection failed on every frame.")
        x.app.load()
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: analysis.id)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(!report.hasAnalysisFiles)
        #expect(report.storedFailureReason == "The analysis failed: Pose detection failed on every frame.")
        #expect(report.contributingFactors.contains { $0.hasPrefix("No analysis files were stored") })
    }

    @Test func diagnosticsAreOffUntilTurnedOn() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let settings = InMemoryDeveloperSettings()
        let app = AppModel(services: x.app.services, selectionStore: InMemoryAthleteSelection(), developerSettings: settings)
        #expect(app.showsAnalysisDiagnostics == false)
        app.showsAnalysisDiagnostics = true
        #expect(settings.showsAnalysisDiagnostics, "remembered")
        let again = AppModel(services: x.app.services, selectionStore: InMemoryAthleteSelection(), developerSettings: settings)
        #expect(again.showsAnalysisDiagnostics)
    }
}

/// A media store created before the engine, so the engine can share it.
@MainActor
struct AppFixtureStore {
    let temp: TemporaryDirectory
    let store: ManagedMediaStore

    init() throws {
        temp = try TemporaryDirectory()
        store = ManagedMediaStore(
            locations: MediaLocations(baseURL: temp.kickLabBase),
            metadataReader: FixedMetadataReader(metadata: VideoMediaMetadata(
                durationSeconds: 2, frameRate: 30, pixelWidth: 1080, pixelHeight: 1920, hasAudio: false
            )),
            thumbnailGenerator: WritingThumbnailGenerator()
        )
        try store.prepareDirectories()
    }
}
