import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: Step 12A–12C diagnostics through the real runner, SwiftData and files.
@MainActor
@Suite("Step 12A diagnostics in the app")
struct DiagnosticsViewModelTests {
    /// The real pose engine on synthetic pose at the given Vision confidence.
    private func engine(_ x: AppFixtureStore, confidence: Double) -> PoseVideoAnalysisService {
        var script = SyntheticPose.KickScript.fieldGoal
        script.confidence = confidence
        let fixed = script
        return PoseVideoAnalysisService(mediaStore: x.store, extractor: FakePoseExtractor { SyntheticPose.sequence(fixed, videoID: $0) })
    }

    /// Step 12E: a kick filmed from behind completes as a measurements-only analysis
    /// (no score is invented), with its perspective and gates in diagnostics.
    ///
    /// Updated for Step 12G (contact-intelligence-4): from behind, body pose alone finds
    /// only a strike WINDOW for this synthetic kick (1.467–1.633 s, wider than the ±0.05 s
    /// contact tolerance), so the automatic run must not invent contact timing: it stops
    /// as "contact uncertain" (cause `ambiguousContact`) with no timing metrics. Once the
    /// contact frame is verified (user-assisted), the same video completes as a
    /// measurements-only rear analysis — the Step 12E behaviour this test protects.
    @Test func aRearViewKickCompletesWithMeasurementsOnly() async throws {
        let holder = try AppFixtureStore()
        let script = DepthViewSynthetic.Script()
        let engine = PoseVideoAnalysisService(mediaStore: holder.store,
                                              extractor: FakePoseExtractor { DepthViewSynthetic.sequence(script, videoID: $0) })
        let x = try AppFixture(store: holder, engine: engine)
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .rear)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)

        // 1. Automatic, pose only: a strike window is not a contact time.
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        guard case .failed = run.state else {
            Issue.record("expected the automatic rear analysis to stop as contact-uncertain, got \(run.state)")
            return
        }
        let automaticID = try #require(run.lastAnalysisID)
        let automatic = try #require(ModelLookup.analysis(automaticID, in: x.app.context))
        #expect(automatic.overallScore == nil, "no score is invented for a rear view")
        #expect(automatic.failureReason == AnalysisFailureCause.ambiguousContact.reasonText)
        #expect(!(automatic.metrics ?? []).contains { $0.metricKey == KickMetricKey.plantToContactTime.rawValue && $0.measurementStatus != .unavailable },
                "no timing measured from an uncertain contact")
        let automaticDiagnostics = AnalysisDiagnosticsViewModel(analysisID: automaticID)
        await automaticDiagnostics.load(app: x.app)
        let automaticReport = try #require(automaticDiagnostics.state.value)
        #expect(automaticReport.perspective?.used == .depthAway)
        #expect(automaticReport.outcome == .kickDetectedTimingUncertain)
        #expect(automaticReport.replay?.evidence?.contactTimingMethod == "strikeWindow")
        #expect(automaticReport.gates?.last?.gate == .completion)
        #expect(automaticReport.gates?.last?.passed == false)

        // 2. Contact frame verified: a measurements-only rear analysis.
        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: script.expectedContact))
        await waitUntil { !run.state.isBusy }
        guard case .completed(let id) = run.state else {
            Issue.record("expected a completed rear analysis with the verified contact, got \(run.state)")
            return
        }
        let analysis = try #require(ModelLookup.analysis(id, in: x.app.context))
        #expect(analysis.overallScore == nil, "no score is invented for a rear view")
        #expect(analysis.isCurrent)
        let available = (analysis.metrics ?? []).filter { $0.measurementStatus != .unavailable }.compactMap { KickMetricKey(rawValue: $0.metricKey) }
        #expect(Set(available).isSubset(of: PerspectiveMetricSupport.depthViewMetrics))
        #expect(available.contains(.plantToContactTime))
        #expect((analysis.metrics ?? []).allSatisfy { $0.sourceAngle == .rear })
        let results = AnalysisResultsViewModel(analysisID: id)
        results.load(app: x.app)
        #expect(results.state.value?.presentation.header.mode == .partial)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: id)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(report.perspective?.used == .depthAway)
        #expect(report.gates?.last?.gate == .completion)
        #expect(report.gates?.last?.passed == true)
    }

    /// Step 12E: a side-view clip whose camera angle was set to "rear" is analyzed as the
    /// side view it is (before: failed as "camera angle limited").
    @Test func aSideClipSetToRearIsAnalyzedAsSide() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.55))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .rear)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        let analysisID = try #require(run.lastAnalysisID)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: analysisID)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(report.perspective?.used == .side)
        #expect(report.perspective?.declaredContradicted == true)
        #expect(report.cameraAngle == .rear)
    }

    @Test func sideViewOfTheSameKickIsScored() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.55))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        guard case .completed(let id) = run.state else {
            Issue.record("expected completion, got \(run.state)")
            return
        }
        #expect(run.lastAnalysisID == id)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: id)
        await diagnostics.load(app: x.app)
        #expect(diagnostics.state.value?.failureCause == nil)
        #expect((diagnostics.state.value?.scoredCategoryCount ?? 0) > 0)
    }

    @Test func markedContactIsSavedAndCompared() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.9))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        let id = try #require(run.lastAnalysisID)
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: id)
        await diagnostics.load(app: x.app)
        #expect(diagnostics.state.value?.contactCheck == nil, "nothing marked yet")
        #expect(diagnostics.state.value?.replay?.differsFromStored == false)
        #expect(diagnostics.state.value?.timeSeries != nil)

        let truth = SyntheticPose.KickScript.fieldGoal.expectedContact
        await diagnostics.saveReferenceContact(truth, app: x.app)
        #expect(diagnostics.referenceError == nil)
        #expect(diagnostics.referenceContactTime == truth)
        #expect(video.contactTimeSeconds == truth)
        #expect(video.contactTimeSource == .manual)
        let check = try #require(diagnostics.state.value?.contactCheck)
        #expect(check.withinTolerance)

        await diagnostics.saveReferenceContact(-1, app: x.app)
        #expect(diagnostics.referenceError != nil, "outside the video")
        #expect(video.contactTimeSeconds == truth, "unchanged")

        await diagnostics.saveReferenceContact(nil, app: x.app)
        #expect(video.contactTimeSeconds == nil)
        #expect(video.contactTimeSource == nil)
        #expect(diagnostics.state.value?.contactCheck == nil)
    }

    /// Step 12C: the Pose Validation player's data, and marking contact from it.
    @Test func poseValidationLoadsAndMarksContactWithoutChangingTheAnalysis() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.9))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        let id = try #require(run.lastAnalysisID)
        let analysis = try #require(ModelLookup.analysis(id, in: x.app.context))
        let metricsBefore = (analysis.metrics ?? []).map { "\($0.metricKey)=\(String(describing: $0.value))" }.sorted()
        let scoreBefore = analysis.overallScore

        let player = PoseValidationViewModel(analysisID: id)
        await player.load(app: x.app)
        let content = try #require(player.state.value)
        #expect(content.videoURL != nil, "the stored video is played")
        #expect(content.timeline.availableSources.contains(.current))
        #expect(content.timeline.markers.contains { $0.kind == .contact })
        #expect(content.estimatedContact != nil)

        let truth = SyntheticPose.KickScript.fieldGoal.expectedContact
        let frame = try #require(content.timeline.steppedTime(from: truth, by: 0))
        await player.markContact(at: frame, app: x.app)
        #expect(player.annotationError == nil)
        #expect(video.contactTimeSeconds == frame)
        #expect(video.contactTimeSource == .manual)
        #expect(player.comparison?.absoluteMilliseconds.map { $0 <= 34 } == true)
        #expect(player.state.value?.timeline.markers.contains { $0.kind == .markedContact } == true)

        // Evaluation data only: the stored analysis is untouched.
        let metricsAfter = (analysis.metrics ?? []).map { "\($0.metricKey)=\(String(describing: $0.value))" }.sorted()
        #expect(metricsAfter == metricsBefore)
        #expect(analysis.overallScore == scoreBefore)

        // The diagnostics screen sees the same mark, and can export a validation clip.
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: id)
        await diagnostics.load(app: x.app)
        #expect(diagnostics.referenceContactTime == frame)
        let clipText = await diagnostics.validationClipJSON(app: x.app, annotator: "test", rightsNote: "test")
        let clipJSON = try #require(clipText)
        let clip = try JSONDecoder().decode(ContactReferenceClip.self, from: Data(clipJSON.utf8))
        #expect(clip.annotatedContactTime == frame)
        #expect(ContactValidationHarness.evaluate(clip).withinTolerance)

        await player.markContact(at: nil, app: x.app)
        #expect(video.contactTimeSeconds == nil)
        #expect(player.comparison == nil)
    }

    /// Step 12D: two kicks in one video → "choose the kick" → a NEW user-assisted analysis
    /// of the chosen kick; the automatic analysis is kept unchanged.
    @Test func choosingAKickRunsANewUserAssistedAnalysisAndKeepsTheOld() async throws {
        let holder = try AppFixtureStore()
        let twoKicks = SyntheticPose.concatenated([.fieldGoal, .fieldGoal])
        let engine = PoseVideoAnalysisService(mediaStore: holder.store,
                                              extractor: FakePoseExtractor { SyntheticPose.sequence(from: twoKicks, videoID: $0) })
        let x = try AppFixture(store: holder, engine: engine)
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .failed(.multipleKicksFound))
        let automaticID = try #require(run.lastAnalysisID)
        let automatic = try #require(ModelLookup.analysis(automaticID, in: x.app.context))
        let automaticReason = automatic.failureReason
        #expect(automatic.analysisVersion == PoseVideoAnalysisService.version)

        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(windowStart: 2.2, windowEnd: 4.0))
        await waitUntil { !run.state.isBusy }
        guard case .completed(let assistedID) = run.state else {
            Issue.record("expected the assisted run to complete, got \(run.state)")
            return
        }
        #expect(assistedID != automaticID, "a new analysis")
        let assisted = try #require(ModelLookup.analysis(assistedID, in: x.app.context))
        #expect(AnalysisAssistanceLabel.isAssisted(assisted.analysisVersion))
        #expect(run.lastAssistance?.window == 2.2...4.0)
        // The automatic analysis is untouched.
        #expect(automatic.processingStatus == .failed)
        #expect(automatic.failureReason == automaticReason)
        #expect((kick.analyses ?? []).count == 2)
        // Results label it, and don't offer assistance again.
        let results = AnalysisResultsViewModel(analysisID: assistedID)
        results.load(app: x.app)
        await results.loadVideo(app: x.app)
        #expect(results.state.value?.presentation.header.mode == .userAssisted)
        #expect(results.assistanceOffer == .none)
        // Diagnostics: excluded from accuracy.
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: assistedID)
        await diagnostics.load(app: x.app)
        #expect(diagnostics.state.value?.assistance?.window == 2.2...4.0)
    }

    /// Step 12D: cancelling a user-assisted run leaves the earlier analysis as it was.
    @Test func cancellingAnAssistedRunKeepsTheEarlierAnalysis() async throws {
        let holder = try AppFixtureStore()
        let x = try AppFixture(store: holder, engine: engine(holder, confidence: 0.9))
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        try await x.importVideo(to: kick, angle: .side)
        x.app.load()
        let run = x.app.analysisRun(for: kick.id)
        run.start(app: x.app)
        await waitUntil { !run.state.isBusy }
        let firstID = try #require(run.lastAnalysisID)
        let first = try #require(ModelLookup.analysis(firstID, in: x.app.context))
        let wasCurrent = first.isCurrent
        let score = first.overallScore

        run.startAssisted(app: x.app, assistance: PhaseDetectionAssistance(contactTime: 1.4))
        run.cancel()
        await waitUntil { !run.state.isBusy }
        #expect(run.state == .cancelled || run.state.isCompletedOrFailed, "cancelled, or finished before the cancel landed")
        #expect(first.overallScore == score)
        if run.state == .cancelled { #expect(first.isCurrent == wasCurrent, "still the current analysis") }
    }

    @Test func analysesWithoutFilesStillGetASummary() async throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let kick = try x.f.makeKick(for: try x.f.makeAthlete())
        let video = try x.f.addVideo(to: kick, path: "k/old.mov")
        let analysis = try x.f.analyses.createAnalysis(for: kick, analysisVersion: "1", inputVideos: [video])
        try x.f.analyses.startProcessing(analysis)
        try x.f.analyses.markFailed(analysis, reason: "The analysis failed: Pose detection failed on every frame.")
        x.app.load()
        let diagnostics = AnalysisDiagnosticsViewModel(analysisID: analysis.id)
        await diagnostics.load(app: x.app)
        let report = try #require(diagnostics.state.value)
        #expect(!report.hasAnalysisFiles)
        #expect(report.storedFailureReason == "The analysis failed: Pose detection failed on every frame.")
        #expect(report.contributingFactors.contains { $0.hasPrefix("No analysis files were stored") })
    }

    @Test func diagnosticsAreOffUntilTurnedOn() throws {
        let x = try AppFixture()
        defer { x.temp.remove() }
        let settings = InMemoryDeveloperSettings()
        let app = AppModel(services: x.app.services, selectionStore: InMemoryAthleteSelection(), developerSettings: settings)
        #expect(app.showsAnalysisDiagnostics == false)
        app.showsAnalysisDiagnostics = true
        #expect(settings.showsAnalysisDiagnostics, "remembered")
        let again = AppModel(services: x.app.services, selectionStore: InMemoryAthleteSelection(), developerSettings: settings)
        #expect(again.showsAnalysisDiagnostics)
    }
}

extension AnalysisFlowState {
    var isCompletedOrFailed: Bool {
        switch self {
        case .completed, .failed: true
        default: false
        }
    }
}

/// A media store created before the engine, so the engine can share it.
@MainActor
struct AppFixtureStore {
    let temp: TemporaryDirectory
    let store: ManagedMediaStore

    init() throws {
        temp = try TemporaryDirectory()
        store = ManagedMediaStore(
            locations: MediaLocations(baseURL: temp.kickLabBase),
            metadataReader: FixedMetadataReader(metadata: VideoMediaMetadata(
                durationSeconds: 2, frameRate: 30, pixelWidth: 1080, pixelHeight: 1920, hasAudio: false
            )),
            thumbnailGenerator: WritingThumbnailGenerator()
        )
        try store.prepareDirectories()
    }
}
