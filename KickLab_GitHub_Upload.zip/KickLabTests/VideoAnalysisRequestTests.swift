import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: building analysis requests from stored records.
@MainActor
@Suite("VideoAnalysisRequest from records")
struct VideoAnalysisRequestTests {
    let f: ServiceFixture

    init() throws {
        f = try ServiceFixture()
    }

    @Test func requestPreservesIdentityWithPrimaryFirst() throws {
        let kick = try f.makeKick(for: try f.makeAthlete())
        let side = try f.addVideo(to: kick, path: "k/side.mov")       // first → primary
        let rear = try f.addVideo(to: kick, path: "k/rear.mov")

        let request = try VideoAnalysisRequest.make(for: kick, videos: [rear, side])

        #expect(request.kickID == kick.id)
        #expect(request.kickType == .fieldGoal)
        #expect(request.inputVideoIDs == [side.id, rear.id])
        #expect(request.inputs.first?.isPrimary == true)
        #expect(request.inputs.first?.relativeFilePath == "k/side.mov")
    }

    /// Step 12C: a manually marked contact is evaluation data and never reaches the engine.
    @Test func manualContactMarksAreNotGivenToTheEngine() throws {
        let kick = try f.makeKick(for: try f.makeAthlete())
        let video = try f.addVideo(to: kick, path: "k/side.mov")
        video.contactTimeSeconds = 2.5
        video.contactTimeSource = .manual
        #expect(try VideoAnalysisRequest.make(for: kick, videos: [video]).inputs.first?.contactTimeSeconds == nil)
        video.contactTimeSource = .detected
        #expect(try VideoAnalysisRequest.make(for: kick, videos: [video]).inputs.first?.contactTimeSeconds == 2.5)
    }

    @Test func crossKickAndEmptyInputsAreRejected() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        let otherKick = try f.makeKick(for: athlete)
        let otherVideo = try f.addVideo(to: otherKick, path: "o/v.mov")

        #expect(throws: AnalysisServiceError.integrity([
            .videoBelongsToDifferentKick(videoID: otherVideo.id, videoKickID: otherKick.id, analysisKickID: kick.id),
        ])) {
            _ = try VideoAnalysisRequest.make(for: kick, videos: [otherVideo])
        }
        #expect(throws: AnalysisServiceError.noInputVideos) {
            _ = try VideoAnalysisRequest.make(for: kick, videos: [])
        }
    }
}
