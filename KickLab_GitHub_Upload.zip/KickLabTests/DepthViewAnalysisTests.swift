import Foundation
import Testing
@testable import KickLab

/// Step 12E: kicks filmed from behind, in front and diagonally — side by side with the
/// side view — through the real pipeline (tracking → perspective → labels → processing →
/// signals → phases → metrics → completion). The depth-view clips are synthetic
/// projections of a 3D kicker (`DepthViewSynthetic`), not real footage.
@Suite("Step 12E camera-aware analysis: rear, front, diagonal and side")
struct DepthViewAnalysisTests {
    typealias Script = DepthViewSynthetic.Script

    private func frames(_ s: Script, _ n: Double) -> Double { n / s.frameRate + 1e-9 }

    /// The true contact lies within the reported contact window (± `slack` frames).
    private func windowContainsTruth(_ out: KickAnalysisPipelineOutput, _ s: Script, slack: Double = 1) -> Bool {
        let e = out.phases.evidence
        guard let lo = e?.contactEarliestTime, let hi = e?.contactLatestTime else { return false }
        return lo - frames(s, slack) <= s.expectedContact && s.expectedContact <= hi + frames(s, slack)
    }

    private func available(_ out: KickAnalysisPipelineOutput) -> Set<KickMetricKey> {
        Set(out.biomechanics.measurements.filter(\.isAvailable).map(\.key))
    }

    /// Everything a correct depth-view analysis must satisfy (Step 12G).
    ///
    /// From behind or in front, pose alone finds the STRIKE WINDOW; contact is only
    /// "estimated" when that window is within ±0.05 s. Otherwise contact timing is
    /// reported as uncertain and nothing contact-timed is measured — and the same clip
    /// with a verified contact frame gives the measurements.
    private func expectSoundDepthAnalysis(_ out: KickAnalysisPipelineOutput, _ s: Script, plantTruth: Double, _ label: String) {
        let contact = out.phases.phase(.contact)
        let e = out.phases.evidence
        #expect(contact.isAvailable, "\(label): a strike was found")
        #expect(contact.status != .detected, "\(label): contact is never 'detected' without the ball")
        let lo = e?.contactEarliestTime ?? -9, hi = e?.contactLatestTime ?? -9
        #expect(lo - frames(s, 1) <= s.expectedContact && s.expectedContact <= hi + frames(s, 1),
                "\(label): the true contact \(s.expectedContact) lies in the reported window \(lo)–\(hi)")
        let plant: Double = out.phases.plantTime ?? -9
        #expect(abs(plant - plantTruth) <= frames(s, 2), "\(label): plant within 2 frames (\(plant))")
        #expect(plant < lo + 1e-9, "\(label): plant before the strike window")
        #expect(out.phases.phase(.approach).isAvailable, "\(label): approach")
        #expect(available(out).isSubset(of: PerspectiveMetricSupport.depthViewMetrics), "\(label): \(available(out))")
        for m in out.biomechanics.measurements where !PerspectiveMetricSupport.depthViewMetrics.contains(m.key) {
            #expect(m.unavailableReason == .cameraAngleUnsupported, "\(label): \(m.key)")
        }
        #expect(out.biomechanics.overallScore == nil, "\(label): never a score from this view")
        #expect(out.phases.evidence?.contactTimingBasis == "automatic")
        if contact.status == .ambiguous {
            #expect(e?.contactTimingMethod == "strikeWindow", "\(label)")
            for m in out.biomechanics.measurements where m.key.definition.dependsOnContact && PerspectiveMetricSupport.depthViewMetrics.contains(m.key) {
                #expect(m.unavailableReason == .contactTimingUncertain, "\(label): \(m.key) needs a verified contact")
            }
            #expect(out.outcome == .kickDetectedTimingUncertain, "\(label)")
            #expect(AssistanceOffer.make(phases: out.phases, engineVersion: "pose-biomechanics-3.0.0") == .chooseContact, "\(label)")
            // With the contact frame verified, the timing measurements appear.
            let verified = DepthViewSynthetic.run(s, angle: out.perspective?.declared,
                                                  assistance: PhaseDetectionAssistance(contactTime: s.expectedContact))
            #expect(verified.completionBasis == .measurementsOnly, "\(label): verified")
            #expect(Set(verified.biomechanics.measurements.filter(\.isAvailable).map(\.key)).contains(.plantToContactTime), "\(label): verified")
            #expect(verified.biomechanics.overallScore == nil)
        } else {
            #expect(e?.contactTimingMethod == "firstContactInterval", "\(label)")
            #expect(out.completionBasis == .measurementsOnly, "\(label)")
            #expect(available(out).contains(.plantToContactTime), "\(label)")
        }
    }

    // MARK: Root cause, reproduced

    @Test func theSideViewAssumptionsCannotAnalyzeAClipFilmedFromBehind() {
        // What engine 2.3.0 did: side-view signals and detection on a rear clip.
        let s = Script()
        let tracked = DepthViewSynthetic.run(s)   // only for the kicker track
        let raw = KickerPoseTimeline.make(from: tracked.sequence.frames, trackID: tracked.sequence.kickerTrackID!,
                                          displayAspectRatio: DepthViewSynthetic.aspect)
        let sideSignals = PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(raw), kickingFoot: .right)
        #expect(sideSignals.travelDirection == 0, "running away from the camera has no horizontal travel direction")
        let sidePhases = KickPhaseDetector.detect(sideSignals, kickType: .fieldGoal)
        let hipSpeed = sideSignals.values(.bodyCenterSpeed).compactMap { $0 }.max() ?? 0
        #expect(hipSpeed < KickPhaseProfile.placeKick.approachSpeedThreshold * 3, "the run-up barely moves the hips in the image")
        #expect(sidePhases.kickWindows?.selected?.source != "approach", "no run-up is found from horizontal hip motion")
        // The side-view leg repair also deletes the backswing (a fast vertical heel lift).
        let (_, sideRepair) = PoseTimelineProcessor.processWithReport(raw)
        let (_, depthRepair) = PoseTimelineProcessor.processWithReport(raw, perspective: .depthAway)
        #expect(!sideRepair.outlierSamples.isEmpty, "side rule rejects the heel lift as a jump")
        #expect(depthRepair.outlierSamples.isEmpty, "depth rule keeps it")
    }

    // MARK: Rear view

    @Test func rightFootedKickFromBehind() {
        let s = Script()
        let out = DepthViewSynthetic.run(s)
        #expect(out.perspective?.used == .depthAway)
        #expect(out.legIdentity?.outcome == .consistent)
        expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "rear right")
        let verified = DepthViewSynthetic.run(s, assistance: PhaseDetectionAssistance(contactTime: s.expectedContact))
        let width = verified.biomechanics.measurement(.plantFootWidth)?.value ?? 0
        #expect(width > 0.2, "the plant foot lands out to the plant side (0.24 m + hip offset)")
    }

    @Test func leftFootedKickFromBehindMirrorsTheRightFooted() {
        var s = Script()
        s.kickingFoot = .left
        let out = DepthViewSynthetic.run(s)
        expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "rear left")
        let right = DepthViewSynthetic.run(Script())
        #expect(out.phases.estimatedContactTime == right.phases.estimatedContactTime)
        let help = { (x: Script) in DepthViewSynthetic.run(x, assistance: PhaseDetectionAssistance(contactTime: x.expectedContact)) }
        #expect(abs((help(s).biomechanics.measurement(.plantFootWidth)?.value ?? 0) - (help(Script()).biomechanics.measurement(.plantFootWidth)?.value ?? 9)) < 0.02,
                "plant width is measured toward each kicker's own plant side")
    }

    @Test func mirroredRecordingGivesTheSameResult() {
        var s = Script()
        s.mirrored = true
        let out = DepthViewSynthetic.run(s)
        #expect(out.legIdentity?.outcome == .consistent, "mirroring is expected, not mistaken for swapped labels")
        expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "rear mirrored")
        #expect(out.phases.estimatedContactTime == DepthViewSynthetic.run(Script()).phases.estimatedContactTime)
    }

    @Test func labelsReportedAsIfFacingTheCameraAreSwappedBack() {
        for foot in [KickingFoot.right, .left] {
            var s = Script()
            s.kickingFoot = foot
            s.labelsFlippedByDetector = true
            let out = DepthViewSynthetic.run(s)
            #expect(out.legIdentity?.outcome == .swapped, "\(foot)")
            expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "flipped labels \(foot)")
            var clean = s
            clean.labelsFlippedByDetector = false
            #expect(out.phases.estimatedContactTime == DepthViewSynthetic.run(clean).phases.estimatedContactTime)
        }
    }

    @Test func legsCrossingAndAHiddenAnkleAtTheStrike() {
        var s = Script()
        s.legSwapTimes = [s.contactTime - 0.1 + 0.5 / 30]
        s.kickingAnkleHidden = [1.567]
        let out = DepthViewSynthetic.run(s)
        expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "crossing + hidden")
    }

    @Test func sixtyFramesPerSecond() {
        var s = Script()
        s.frameRate = 60
        expectSoundDepthAnalysis(DepthViewSynthetic.run(s), s, plantTruth: s.plantTime, "rear 60 fps")
    }

    @Test func lowConfidenceRearFootageIsEitherSoundOrHonestlyIncomplete() {
        var s = Script()
        s.legConfidence = 0.4
        s.jitter = 0.002
        let out = DepthViewSynthetic.run(s)
        #expect(available(out).isSubset(of: PerspectiveMetricSupport.depthViewMetrics), "never side-view metrics")
        if out.completionBasis == .measurementsOnly {
            #expect(windowContainsTruth(out, s, slack: 2))
        } else {
            #expect(out.failureCause != .cameraAngleLimited, "a phase or visibility cause, never the old camera penalty")
            #expect(AnalysisGates.firstBlocking(out.gates) != nil)
        }
        // Too faint to use at all: pose-confidence threshold removes the legs.
        s.legConfidence = 0.2
        let faint = DepthViewSynthetic.run(s)
        #expect(faint.completionBasis == .insufficient)
        #expect(faint.biomechanics.availableMetricCount == 0)
        #expect([AnalysisFailureCause.legJointsNotVisible, .noCredibleKickWindow, .ambiguousContact].contains(faint.failureCause ?? .kickPhasesNotFound))
    }

    @Test func aStandingKickFromBehindStillFindsTheSwing() {
        var s = Script()
        s.noRunUp = true
        let out = DepthViewSynthetic.run(s, angle: .rear)
        #expect(out.phases.kickWindows?.selected?.source == "swingOnly")
        #expect(!out.phases.phase(.approach).isAvailable, "no run-up, none reported")
        #expect(windowContainsTruth(out, s))
        #expect(available(out).isSubset(of: PerspectiveMetricSupport.depthViewMetrics))
    }

    // MARK: Front, diagonal, unknown

    @Test func kickFilmedFromInFront() {
        var s = Script()
        s.camera = .inFront
        let out = DepthViewSynthetic.run(s)
        #expect(out.perspective?.used == .depthToward)
        #expect(out.legIdentity?.outcome == .consistent, "facing the camera: right side on the image's left")
        expectSoundDepthAnalysis(out, s, plantTruth: s.plantTime, "front")
        // Behind the goal is a view from in front (from far away).
        #expect(DepthViewSynthetic.run(s, angle: .behindGoal).perspective?.used == .depthToward)
    }

    @Test func diagonalViewKeepsOnlyTimingsAndSpeedRatios() {
        var s = Script()
        s.camera = .diagonalBehind
        // A straight swing, seen at 40° (Step 12F: the angled swing is tested below).
        s.swingTurnDegrees = 0
        let out = DepthViewSynthetic.run(s)
        #expect(out.perspective?.used == .oblique)
        #expect(abs((out.phases.estimatedContactTime ?? -9) - s.expectedContact) <= frames(s, 2))
        for m in out.biomechanics.measurements where m.isAvailable {
            let d = m.key.definition
            #expect(d.timing == .interval || d.unit == .percent, "\(m.key): foreshortened values are not reported")
        }
        #expect(out.biomechanics.measurement(.kickingKneeAngleAtContact)?.unavailableReason == .cameraAngleUnsupported)
        #expect(out.completionBasis != .insufficient)
    }

    @Test func aDiagonalViewWhoseSwingRunsAlongTheLineOfSightIsNotGuessed() {
        // Step 12F limitation: filmed at 40° with the swing turned 25° back toward the
        // camera axis, the strike runs mostly along the line of sight. The diagonal path
        // (side-view detector) then finds no forward strike and must not invent one.
        var s = Script()
        s.camera = .diagonalBehind
        let out = DepthViewSynthetic.run(s)
        #expect(out.perspective?.used == .oblique)
        if out.phases.phase(.contact).isAvailable {
            #expect(abs((out.phases.estimatedContactTime ?? -9) - s.expectedContact) <= frames(s, 2))
        } else {
            #expect(out.completionBasis == .insufficient)
            #expect(out.biomechanics.overallScore == nil)
            #expect(AnalysisGates.firstBlocking(out.gates) != nil)
        }
    }

    @Test func unknownCameraAngleIsTakenFromTheMovement() {
        let out = DepthViewSynthetic.run(Script(), angle: .unknown)
        #expect(out.perspective?.used == .depthAway)
        #expect(out.perspective?.declaredContradicted == false)
        expectSoundDepthAnalysis(out, Script(), plantTruth: Script().plantTime, "unknown angle")
    }

    // MARK: Side view preserved

    @Test func theSideViewIsAnalyzedExactlyAsBefore() {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side))
        #expect(out.perspective?.used == .side)
        #expect(out.legIdentity?.outcome == .notApplicable)
        #expect(out.completionBasis == .scored)
        // Every sagittal metric still measured; only the frontal-plane ones are not.
        let missing = Set(out.biomechanics.measurements.filter { !$0.isAvailable }.map(\.key))
        #expect(missing == PerspectiveMetricSupport.frontalPlaneMetrics)
        // Identical phases to the side detector called directly (the Step 12D path).
        let signals = PoseSignalExtractor.extract(from: PoseTimelineProcessor.process(out.kickerTimeline.map { _ in
            KickerPoseTimeline.make(from: out.sequence.frames, trackID: out.sequence.kickerTrackID!, displayAspectRatio: 1)
        }!), kickingFoot: .right)
        let direct = KickPhaseDetector.detect(signals, kickType: .fieldGoal)
        #expect(direct.phases == out.phases.phases)
        // Step 12F: the only addition is the record that no ball tracker ran.
        var expected = direct.evidence
        expected?.ballEvidence = .unavailable
        expected?.contactProvenance = "poseOnly"
        #expect(expected == out.phases.evidence)
    }

    @Test func aSideClipLabeledRearIsAnalyzedAsTheSideViewItIs() {
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        #expect(out.perspective?.used == .side)
        #expect(out.perspective?.declaredContradicted == true)
        #expect(out.suitability.first?.kind == .cameraAngle, "the user is told to check the camera angle")
        #expect(out.biomechanics.measurement(.kickingKneeAngleAtContact)?.confidenceInputs?.cameraFactor == MetricConfidenceModel.cameraFactor(.unknown))
    }

    // MARK: Signals, gates, assistance, diagnostics

    @Test func depthViewSignalsNeverUseHorizontalAsForward() {
        let out = DepthViewSynthetic.run(Script())
        #expect(out.signals.travelDirection == 0)
        for key in [PoseSignalKey.bodyForwardVelocity, .kickingAnkleForwardVelocity, .kickingKneeForwardVelocity,
                    .kickingAnkleForwardOffset, .plantAnkleForwardOffset, .kickingAnkleAheadOfPlant, .torsoLean] {
            #expect(out.signals.coverage(key) == 0, "\(key) is a side-view signal")
        }
        for key in PoseSignalKey.depthViewOnly { #expect(out.signals.coverage(key) > 0.9, "\(key)") }
        // The run-up is a positive perspective rate; standing is ~0.
        let rate = out.signals.values(.approachRate)
        #expect(abs(rate[3] ?? 9) < 0.05)
        #expect((rate.compactMap { $0 }.max() ?? 0) > 0.5)
    }

    @Test func aContactThatCantBeFoundOffersTheUserAssistedWorkflow() {
        // The backswing is seen, but the foot is hidden through the bottom of the swing.
        var s = Script()
        s.kickingAnkleHidden = DepthViewSynthetic.timestamps(s).filter { $0 > 1.49 && $0 < 1.72 }
        let out = DepthViewSynthetic.run(s)
        #expect(!out.phases.phase(.contact).isAvailable)
        #expect(AssistanceOffer.make(phases: out.phases, engineVersion: "pose-biomechanics-2.4.0") == .chooseContact)
        #expect(AnalysisGates.firstBlocking(out.gates)?.gate == .contact)
        #expect(out.failureCause == .ambiguousContact)
        #expect(out.phases.phase(.approach).isAvailable, "the run-up is still reported")
        // The user's frame then gives a user-assisted analysis.
        let assisted = DepthViewSynthetic.run(s, assistance: PhaseDetectionAssistance(contactTime: s.expectedContact))
        #expect(assisted.phases.evidence?.contactTimingBasis == "user")
        #expect(assisted.phases.isUserAssisted)
        #expect(assisted.phases.estimatedContactTime.map { abs($0 - s.expectedContact) <= frames(s, 0.5) } == true)
    }

    @Test func aSwingThatIsNeverSeenIsNoKickNotACameraProblem() {
        var s = Script()
        s.kickingAnkleHidden = DepthViewSynthetic.timestamps(s).filter { $0 > 1.25 && $0 < 2.1 }
        let out = DepthViewSynthetic.run(s)
        #expect(AnalysisGates.firstBlocking(out.gates)?.gate == .kickWindow)
        #expect(out.failureCause == .noCredibleKickWindow)
        #expect(AssistanceOffer.make(phases: out.phases, engineVersion: "pose-biomechanics-2.4.0") == .chooseContact)
        // A user contact frame still works without a visible swing.
        let assisted = DepthViewSynthetic.run(s, assistance: PhaseDetectionAssistance(contactTime: s.expectedContact))
        #expect(assisted.phases.phase(.contact).isAvailable)
        #expect(assisted.phases.evidence?.contactTimingBasis == "user")
    }

    @Test func gatesShowWhereANoPersonRearClipStops() {
        var sequence = DepthViewSynthetic.sequence(Script())
        for i in sequence.frames.indices { sequence.frames[i].bodies = [] }
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        #expect(AnalysisGates.firstBlocking(out.gates)?.gate == .poseDetection)
        #expect(out.gates.last?.gate == .kickerTracking || out.gates.last?.gate == .completion)
    }

    @Test func diagnosticsReplayTheRearAnalysisWithItsPerspectiveAndGates() throws {
        let out = DepthViewSynthetic.run(Script())
        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: out, engineVersion: "pose-biomechanics-2.4.0"), storedStatus: "completed",
            storedFailureReason: nil, kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0)
        )
        #expect(report.perspective?.used == .depthAway)
        #expect(report.legIdentity?.outcome == .consistent)
        let gates = try #require(report.gates)
        #expect(gates.map(\.gate).contains(.perspective))
        #expect(gates.last?.gate == .completion)
        #expect(gates.last?.passed == (out.completionBasis != .insufficient))
        #expect(report.replay?.differsFromStored == false, "the replay uses the same camera-aware path")
        #expect(report.plainText.contains("Camera perspective: depthAway"))
        #expect(report.plainText.contains("Gates (current build on the stored pose):"))
        #expect(!report.json().contains("\"x\""), "no coordinates in the report")
    }

    @Test func completionNeverCreatesAScore() {
        let out = DepthViewSynthetic.run(Script())
        #expect(out.biomechanics.categories.allSatisfy { $0.score == nil })
        #expect(out.biomechanics.overallScore == nil)
        // The side view still needs a scored category.
        let side = AnalysisCompletion.evaluate(kickerSelected: true, perspective: .side, phases: out.phases,
                                               availableMetricCount: 10, scoredCategoryCount: 0)
        #expect(side.basis == .insufficient)
        let oneMetric = AnalysisCompletion.evaluate(kickerSelected: true, perspective: .depthAway, phases: out.phases,
                                                    availableMetricCount: 1, scoredCategoryCount: 0)
        #expect(oneMetric.basis == .insufficient)
    }
}
