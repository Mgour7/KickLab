import Foundation
import Testing
@testable import KickLab

/// Build 22: extremes of the kicking foot's path (highest follow-through point, deepest
/// backswing, fastest swing) are not reported when the foot was at the frame edge or
/// hidden where the extreme could be. Real-footage origin: on the IMG_4541 practice
/// recordings the kicking foot left the frame above hip height in the follow-through and
/// the highest TRACKED point read 0.3–0.9 torso lengths BELOW the hip (an emulation of the
/// app's pipeline with substitute pose; see Docs/COMPETITOR_VALIDATION_BUILD22.md).
///
/// Synthetic geometry, pure: runs on Linux. Says nothing about Vision's behaviour at the
/// frame edge on a device.
@Suite("Build 22: kicking-foot extremes need the foot in frame")
struct FootVisibilityBuild22Tests {
    typealias Script = SyntheticPose.KickScript

    /// The field-goal script shifted sideways so the kicking ankle's right-most position
    /// after `after` seconds lands at `edgeX`. A uniform shift changes no length, angle or
    /// speed, only where in the frame the body is.
    private func shifted(_ script: Script, after: Double, until: Double = .infinity, kickingAnkleMaxX edgeX: Double) -> KickerPoseTimeline {
        let base = SyntheticPose.timeline(script)
        let ankle: PoseJoint = script.kickingFoot == .right ? .rightAnkle : .leftAnkle
        let maxX = base.samples.filter { $0.timestamp >= after && $0.timestamp <= until }.compactMap { $0.point(ankle)?.x }.max() ?? 0.5
        let dx = edgeX - maxX
        let samples = base.samples.map { s -> KickerPoseSample in
            var out = s
            for (j, p) in s.joints where p.isAvailable { out.joints[j]?.x = p.x + dx }
            return out
        }
        return KickerPoseTimeline(samples: samples, displayAspectRatio: base.displayAspectRatio)
    }

    @Test func aFootAtTheFrameEdgeInTheFollowThroughHasNoHeight() {
        let script = Script.fieldGoal
        // Control: the same kick fully in frame keeps its scripted value (−1.333).
        let inside = SyntheticBiomechanics.analyze(script, timeline: shifted(script, after: 1.4, kickingAnkleMaxX: 0.9))
        #expect(inside.measurement(.followThroughFootHeight)?.value == -1.333)

        let edge = SyntheticBiomechanics.analyze(script, timeline: shifted(script, after: 1.4, kickingAnkleMaxX: 0.99))
        let m = edge.measurement(.followThroughFootHeight)
        #expect(m?.isAvailable == false)
        #expect(m?.value == nil, "never a placeholder number")
        #expect(m?.unavailableReason == .kickingFootNotFullyVisible)
        // Measurements that don't take an extreme of the foot's path are unaffected.
        #expect(edge.measurement(.plantFootDrift)?.value == inside.measurement(.plantFootDrift)?.value)
        #expect(edge.measurement(.torsoLeanAtContact)?.value == inside.measurement(.torsoLeanAtContact)?.value)
    }

    @Test func aHiddenRunNextToTheHighestPointMakesItUnknown() {
        let script = Script.fieldGoal
        let r0 = SyntheticBiomechanics.analyze(script)
        guard let start = r0.measurement(.followThroughFootHeight)?.windowStart,
              let end = r0.measurement(.followThroughFootHeight)?.windowEnd, end > start else {
            Issue.record("the control kick must report its follow-through window"); return
        }
        // The kicking ankle rises (smoothly, peak in the middle of the follow-through) — the
        // scripted kick keeps it at ankle height.
        let middle = (start + end) / 2
        let half = (end - start) / 2
        var rising = SyntheticPose.timeline(script)
        for i in rising.samples.indices {
            let t = rising.samples[i].timestamp
            guard t > start, t < end, let y = rising.samples[i].joints[.rightAnkle]?.y else { continue }
            let u = 1 - abs(t - middle) / half
            rising.samples[i].joints[.rightAnkle]?.y = y - 0.04 * u
        }
        let seen = SyntheticBiomechanics.analyze(script, timeline: rising).measurement(.followThroughFootHeight)
        // Control: the rise is measured when the foot is visible throughout.
        #expect((seen?.value ?? -9) > -1.333)

        // Now the foot is hidden around the top of its path (longer than gap filling bridges).
        var hidden = rising
        var count = 0
        for i in hidden.samples.indices where abs(hidden.samples[i].timestamp - middle) <= 0.06 {
            hidden.samples[i].joints[.rightAnkle] = .unavailable
            count += 1
        }
        #expect(count >= 3)
        let m = SyntheticBiomechanics.analyze(script, timeline: hidden).measurement(.followThroughFootHeight)
        #expect(m?.isAvailable == false, "the highest point may have been while the foot was hidden")
        #expect(m?.value == nil)
    }

    @Test func aFootAtTheEdgeDuringTheSwingHasNoPeakSpeed() {
        let script = Script.fieldGoal
        let inside = SyntheticBiomechanics.analyze(script, timeline: shifted(script, after: 1.15, until: 1.45, kickingAnkleMaxX: 0.9))
        #expect(inside.measurement(.peakFootSpeed)?.isAvailable == true)
        let edge = SyntheticBiomechanics.analyze(script, timeline: shifted(script, after: 1.15, until: 1.45, kickingAnkleMaxX: 0.995))
        if edge.measurement(.peakFootSpeed)?.isAvailable == true {
            // Only acceptable if the edge sample lies outside the speed window.
            Issue.record("peak foot speed reported while the foot touched the frame edge")
        }
        #expect(edge.measurement(.peakFootSpeed)?.value == nil)
    }

    @Test func theReasonIsStableForStoredArtifacts() throws {
        // The raw value is persisted in analysis artifacts and evidence bundles.
        #expect(MetricUnavailableReason.kickingFootNotFullyVisible.rawValue == "kickingFootNotFullyVisible")
        let data = try JSONEncoder().encode(MetricUnavailableReason.kickingFootNotFullyVisible)
        #expect(try JSONDecoder().decode(MetricUnavailableReason.self, from: data) == .kickingFootNotFullyVisible)
    }

    @Test func engine3_2KeepsTheSameScoringModel() {
        // Bands and weights are unchanged, so Build 22 scores stay comparable with 3.0/3.1.
        #expect(PoseVideoAnalysisService.version == "pose-biomechanics-3.2.0")
        #expect(ScoringModel.version(ofEngine: "pose-biomechanics-3.2.0") == "provisional-bands-2")
        #expect(ScoringModel.version(ofEngine: "pose-biomechanics-3.2.0+assisted") == "provisional-bands-2")
        #expect(ScoringModel.version(of: .followThrough, engine: "pose-biomechanics-3.2.0")
                == ScoringModel.version(of: .followThrough, engine: "pose-biomechanics-3.1.0"))
    }
}
