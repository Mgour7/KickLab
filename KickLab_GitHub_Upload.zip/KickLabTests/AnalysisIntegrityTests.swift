import Foundation
import SwiftData
import Testing
@testable import KickLab

@MainActor
@Suite("Analysis / video integrity")
struct AnalysisIntegrityTests {
    let container: ModelContainer
    let context: ModelContext

    init() throws {
        container = try ModelContainerFactory.makeContainer(inMemory: true)
        context = container.mainContext
    }

    private func makeKick() throws -> Kick {
        let kick = try Kick.make(from: KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: .made))))
        context.insert(kick)
        return kick
    }

    private func makeVideo(for kick: Kick?) -> VideoAsset {
        let video = VideoAsset(angleType: .side, isPrimary: true)
        context.insert(video)
        video.kick = kick
        return video
    }

    private func makeAnalysis(for kick: Kick?) -> BiomechanicsAnalysis {
        let analysis = BiomechanicsAnalysis(analysisVersion: "0.0.1")
        context.insert(analysis)
        analysis.kick = kick
        return analysis
    }

    @Test func videoFromSameKickCanBeAttached() throws {
        let kick = try makeKick()
        let video = makeVideo(for: kick)
        let analysis = makeAnalysis(for: kick)

        try analysis.attachInputVideo(video)

        #expect(analysis.inputVideos?.map(\.id) == [video.id])
        #expect(AnalysisIntegrityValidator.issues(for: analysis).isEmpty)
    }

    @Test func videoFromAnotherKickIsRejected() throws {
        let kickA = try makeKick()
        let kickB = try makeKick()
        let videoOfB = makeVideo(for: kickB)
        let analysisOfA = makeAnalysis(for: kickA)

        do {
            try analysisOfA.attachInputVideo(videoOfB)
            Issue.record("Expected cross-kick video to be rejected")
        } catch let error as AnalysisIntegrityError {
            #expect(error.issues == [
                .videoBelongsToDifferentKick(videoID: videoOfB.id, videoKickID: kickB.id, analysisKickID: kickA.id),
            ])
        }
        #expect((analysisOfA.inputVideos ?? []).isEmpty)
    }

    @Test func orphanedVideoIsRejected() throws {
        let kick = try makeKick()
        let orphan = makeVideo(for: nil)
        let analysis = makeAnalysis(for: kick)

        #expect(orphan.isOrphaned)
        #expect(throws: AnalysisIntegrityError.self) {
            try analysis.attachInputVideo(orphan)
        }
    }

    @Test func analysisWithoutKickCannotTakeInput() throws {
        let kick = try makeKick()
        let video = makeVideo(for: kick)
        let analysis = makeAnalysis(for: nil)

        #expect(throws: AnalysisIntegrityError.self) {
            try analysis.attachInputVideo(video)
        }
    }

    @Test func auditDetectsCrossKickLinkMadeByBypassingTheBoundary() throws {
        let kickA = try makeKick()
        let kickB = try makeKick()
        let videoOfB = makeVideo(for: kickB)
        let analysisOfA = makeAnalysis(for: kickA)

        // Simulates a bad import that wrote the relationship directly.
        analysisOfA.inputVideos = [videoOfB]

        #expect(AnalysisIntegrityValidator.issues(for: analysisOfA) == [
            .videoBelongsToDifferentKick(videoID: videoOfB.id, videoKickID: kickB.id, analysisKickID: kickA.id),
        ])
    }

    @Test func technicalMetadataIsCappedToSmallPayloads() throws {
        let kick = try makeKick()
        let video = makeVideo(for: kick)
        try video.setTechnicalMetadata(VideoTechnicalMetadata(deviceModel: "iPhone", codec: "hevc", isSlowMotion: true))
        #expect(video.decodedTechnicalMetadata?.codec == "hevc")

        let oversized = VideoTechnicalMetadata(lensDescription: String(repeating: "x", count: 10_000))
        #expect(throws: VideoTechnicalMetadata.EncodingError.self) {
            try video.setTechnicalMetadata(oversized)
        }
    }
}
