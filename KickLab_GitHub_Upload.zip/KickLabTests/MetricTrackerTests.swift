import Foundation
import Testing
@testable import KickLab

/// Build 23: the Metric Tracker follows each measurement kick by kick. Pure (Linux).
@Suite("Build 23: Metric Tracker")
struct MetricTrackerTests {
    static let day = 86_400.0
    static func entry(_ n: Int, view: ComparableView = .side, type: KickType = .fieldGoal,
                      _ metrics: [KickMetricKey: Double], completed: Bool = true) -> RankingEntry {
        var e = RankingEntry(id: UUID(), kickID: UUID(), date: Date(timeIntervalSince1970: 1_700_000_000 + Double(n) * day), kickType: type, view: view,
                             engineVersion: "pose-biomechanics-3.2.0", completed: completed, overallScore: nil, categoryScores: [:])
        for (k, v) in metrics { e.metrics[RankingEntry.metricKey(k)] = v }
        return e
    }

    @Test func viewsAndKickTypesAreNeverMixed() {
        let groups = MetricTracker.groups([
            Self.entry(1, [.plantKneeAngleAtContact: 150]), Self.entry(2, view: .depth, [.plantToContactTime: 0.15]),
            Self.entry(3, type: .kickoff, [.plantKneeAngleAtContact: 140]), Self.entry(4, view: .unknown, [.plantKneeAngleAtContact: 1]),
            Self.entry(5, [.plantKneeAngleAtContact: 1], completed: false),
        ])
        #expect(groups.count == 3, "side FG, rear FG, kickoff; unknown view and incomplete left out")
        #expect(groups.first?.kickType == .kickoff, "most recent group first")
        let side = groups.first { $0.view == .side && $0.kickType == .fieldGoal }
        #expect(side?.kickCount == 1 && side?.tracks.map(\.key) == [.plantKneeAngleAtContact])
    }

    @Test func aGradedMeasurementShowsItsTargetAndMovesTowardIt() throws {
        // Follow-through height below its 0.50–3.00 target, rising kick by kick.
        let values = [0.1, 0.2, 0.25, 0.35, 0.45]
        let g = try #require(MetricTracker.groups(values.enumerated().map { Self.entry($0.offset, [.followThroughFootHeight: $0.element]) }).first)
        let t = try #require(g.tracks.first { $0.key == .followThroughFootHeight })
        #expect(t.targetText == "0.50–3.00 torso lengths")
        #expect(t.targetLow == 0.5 && t.targetHigh == 3.0)
        #expect(t.inTargetCount == 0 && t.inTargetText == "0 of 5 kicks inside the provisional target")
        #expect(t.trend == .towardTarget)
        #expect(t.latestText == "0.45 torso lengths")
        #expect(t.rangeText == "Range 0.10 torso lengths to 0.45 torso lengths over the last 5 kicks")
        #expect(g.watchList.first?.key == .followThroughFootHeight, "latest kick outside its target")
    }

    @Test func aTrendNeedsEnoughKicksAndAConsistentDirection() {
        let band = BiomechanicsProfile.standard(for: .fieldGoal).scoring[.followThroughFootHeight]?.band
        #expect(MetricTracker.trend([0.1, 0.3, 0.2], band: band, direction: .towardIdealBand) == .notEnough(have: 3, need: 4))
        #expect(MetricTracker.trend([0.1, 0.4, 0.1, 0.4, 0.1], band: band, direction: .towardIdealBand) == .steady, "up and down is not a trend")
        #expect(MetricTracker.trend([0.4, 0.3, 0.2, 0.1], band: band, direction: .towardIdealBand) == .awayFromTarget)
        #expect(MetricTracker.trend([1, 1.2, 0.9, 1.1], band: band, direction: .towardIdealBand) == .steady, "always inside the target")
        #expect(MetricTracker.trend([3, 4, 5, 6], band: nil, direction: .none) == .risingNoDirection)
        #expect(MetricTracker.trend([3, 4, 5, 6], band: nil, direction: .lower) == .declining)
    }

    @Test func anUngradedMeasurementHasNoTarget() throws {
        // The approach is measured, not graded (provisional-bands-3).
        let g = try #require(MetricTracker.groups((0..<4).map { Self.entry($0, [.approachSpeed: 2 + Double($0)]) }).first)
        let t = try #require(g.tracks.first)
        #expect(t.targetText == nil && t.inTargetCount == nil && t.points.allSatisfy { $0.inTarget == nil })
        #expect(t.trend == .risingNoDirection)
        #expect(g.watchList.isEmpty)
    }

    @Test func theChartShowsTheValuesAndTheTarget() throws {
        let g = try #require(MetricTracker.groups([0.2, 0.3].enumerated().map { Self.entry($0.offset, [.followThroughFootHeight: $0.element]) }).first)
        let t = try #require(g.tracks.first)
        #expect(t.points.map(\.number) == [1, 2])
        let s = MetricTracker.chartScale(t)
        #expect(s.domain.contains(0.2) && s.domain.contains(3.0))
        #expect(s.band == 0.5...3.0)
        // "≥ 20" (open-ended) runs to the top of the chart.
        let speed = try #require(MetricTracker.groups([Self.entry(1, [.peakFootSpeed: 26])]).first?.tracks.first)
        #expect(speed.targetHigh == nil && MetricTracker.chartScale(speed).band?.upperBound == MetricTracker.chartScale(speed).domain.upperBound)
    }

    @Test func negativeValuesUseARealMinusSign() throws {
        let g = try #require(MetricTracker.groups([Self.entry(1, [.torsoLeanAtContact: -4])]).first)
        #expect(g.tracks.first?.latestText.hasPrefix("−") == true)
    }
}
