import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("KickService")
struct KickServiceTests {
    let f: ServiceFixture

    init() throws {
        f = try ServiceFixture()
    }

    // MARK: Create

    @Test func createsKickWithAthleteAndAthleteID() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)

        #expect(try f.count(Kick.self) == 1)
        #expect(kick.athlete?.id == athlete.id)
        #expect(kick.athleteID == athlete.id)
        #expect(f.kicks.audit(kick).isEmpty)
        #expect(!f.context.hasChanges)
    }

    @Test func snapshotsPlayingLevelAtKick() throws {
        let athlete = try f.makeAthlete(level: .college)
        let snapshot = try f.makeKick(for: athlete)
        #expect(snapshot.playingLevelAtKick == .college)

        var profile = f.athletes.profile(of: athlete)
        profile.currentPlayingLevel = .professional
        try f.athletes.updateProfile(athlete, with: profile)
        #expect(snapshot.playingLevelAtKick == .college, "past kicks keep their snapshot")

        var explicit = KickDraft.fieldGoal()
        explicit.playingLevelAtKick = .highSchool
        #expect(try f.makeKick(for: athlete, draft: explicit).playingLevelAtKick == .highSchool)
    }

    @Test func derivesContextFromSession() throws {
        let athlete = try f.makeAthlete()
        let game = try f.makeSession(for: athlete, type: .game)
        #expect(try f.makeKick(for: athlete, in: game).context == .game)
        #expect(try f.makeKick(for: athlete).context == .training)
    }

    @Test func explicitContextOverridesSession() throws {
        let athlete = try f.makeAthlete()
        let game = try f.makeSession(for: athlete, type: .game)
        var draft = KickDraft.fieldGoal()
        draft.context = .warmup
        #expect(try f.makeKick(for: athlete, in: game, draft: draft).context == .warmup)
    }

    @Test func rejectsSessionBelongingToAnotherAthlete() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let sessionOfB = try f.makeSession(for: b)

        #expect(throws: KickServiceError.sessionBelongsToDifferentAthlete(sessionID: sessionOfB.id, sessionAthleteID: b.id, athleteID: a.id)) {
            try f.kicks.createKick(for: a, in: sessionOfB, draft: .fieldGoal())
        }
        #expect(try f.count(Kick.self) == 0)
    }

    @Test func rejectsArchivedAthlete() throws {
        let athlete = try f.makeAthlete()
        try f.athletes.archive(athlete)
        #expect(throws: KickServiceError.athleteArchived(athleteID: athlete.id)) {
            try f.makeKick(for: athlete)
        }
    }

    @Test func invalidDraftIsRejected() throws {
        let athlete = try f.makeAthlete()
        let bad = KickDraft(outcome: .kickoff(KickoffOutcome(touchback: true, outOfBounds: true)))
        #expect(throws: KickServiceError.invalidDraft([.touchbackAndOutOfBounds])) {
            try f.kicks.createKick(for: athlete, draft: bad)
        }
        #expect(try f.count(Kick.self) == 0)
    }

    @Test func failedSaveOnCreateLeavesNothing() throws {
        let athlete = try f.makeAthlete()
        let failing = KickService(context: f.context, saveHandler: ServiceFixture.failingSave)
        #expect(throws: KickServiceError.self) {
            try failing.createKick(for: athlete, draft: .fieldGoal())
        }
        #expect(try f.count(Kick.self) == 0)
        #expect(!f.context.hasChanges)
    }

    // MARK: Update

    @Test func updateRevalidatesPreservesLinksAndTouchesUpdatedAt() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        let kick = try f.makeKick(for: athlete, in: session)
        kick.updatedAt = .distantPast

        try f.kicks.updateKick(kick, with: .fieldGoal(.missedLeft, distance: 47))

        #expect(kick.fieldGoalOutcome?.result == .missedLeft)
        #expect(kick.distanceYards == 47)
        #expect(kick.athlete?.id == athlete.id)
        #expect(kick.session?.id == session.id)
        #expect(kick.updatedAt > .distantPast)
    }

    @Test func invalidUpdateLeavesKickUnchanged() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        let before = kick.outcomeColumns

        #expect(throws: KickServiceError.self) {
            try f.kicks.updateKick(kick, with: KickDraft(outcome: .kickoff(KickoffOutcome(touchback: true, outOfBounds: true))))
        }
        #expect(kick.kickType == .fieldGoal)
        #expect(kick.outcomeColumns == before)
    }

    @Test func typeChangeClearsValuesProvenanceAndConfidence() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete, draft: .kickoff())
        #expect(kick.storedLandingSource == "multiVideo")

        try f.kicks.updateKick(kick, with: .fieldGoal())

        #expect(kick.kickType == .fieldGoal)
        #expect(kick.landingYardLine == nil && kick.storedLandingZone == nil)
        #expect(kick.storedLandingSource == nil && kick.landingConfidence == nil)
        #expect(kick.hangTimeSeconds == nil && kick.storedHangTimeSource == nil && kick.hangTimeConfidence == nil)
        #expect(kick.touchback == nil && kick.outOfBounds == nil)
        #expect(kick.storedDistanceSource == "manual" && kick.distanceConfidence == nil)
    }

    // MARK: Session assignment

    @Test func assigningNilSessionMakesKickUnassigned() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        let kick = try f.makeKick(for: athlete, in: session)

        try f.kicks.assign(kick, to: nil)

        #expect(kick.session == nil)
        #expect(kick.athlete?.id == athlete.id)
    }

    @Test func assigningMismatchedSessionFailsAndChangesNothing() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let sessionOfA = try f.makeSession(for: a)
        let sessionOfB = try f.makeSession(for: b)
        let kick = try f.makeKick(for: a, in: sessionOfA)

        #expect(throws: KickServiceError.self) {
            try f.kicks.assign(kick, to: sessionOfB)
        }
        #expect(kick.session?.id == sessionOfA.id)
        #expect(kick.athlete?.id == a.id, "the athlete is never changed to make an assignment work")
    }

    // MARK: Athlete reassignment

    @Test func reassignmentKeepsAthleteIDSynchronized() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let kick = try f.makeKick(for: a)

        try f.kicks.reassignAthlete(of: kick, to: b)

        #expect(kick.athlete?.id == b.id)
        #expect(kick.athleteID == b.id)
        #expect(f.kicks.audit(kick).isEmpty)
    }

    @Test func reassignmentConflictingWithSessionFailsUntilSessionCleared() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let sessionOfA = try f.makeSession(for: a)
        let kick = try f.makeKick(for: a, in: sessionOfA)

        #expect(throws: KickServiceError.reassignmentConflictsWithSession(kickID: kick.id, sessionID: sessionOfA.id, newAthleteID: b.id)) {
            try f.kicks.reassignAthlete(of: kick, to: b)
        }
        #expect(kick.athleteID == a.id)

        try f.kicks.assign(kick, to: nil)
        try f.kicks.reassignAthlete(of: kick, to: b)
        #expect(kick.athleteID == b.id)
    }

    // MARK: Delete

    @Test func deletionRemovesRecordAndCascades() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        let video = try f.addVideo(to: kick, path: "k1/side.mov")
        _ = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: .now)

        try f.kicks.deleteKick(kick)

        #expect(try f.count(Kick.self) == 0)
        #expect(try f.count(VideoAsset.self) == 0)
        #expect(try f.count(BiomechanicsAnalysis.self) == 0)
        #expect(try f.count(Athlete.self) == 1)
    }

    @Test func mediaCleanupRunsOnlyAfterSuccessfulSave() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        let video = try f.addVideo(to: kick, path: "k1/side.mov")
        video.thumbnailRelativePath = "k1/side.jpg"
        let analysis = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: .now)
        analysis.artifactsRelativePath = "k1/analysis-1.bin"
        try f.context.save()

        let context = f.context
        f.media.probe = { (try? context.fetchCount(FetchDescriptor<Kick>())) ?? -1 }
        try f.kicks.deleteKick(kick)

        let call = try #require(f.media.calls.first)
        #expect(f.media.calls.count == 1)
        #expect(call.probeValue == 0, "the kick was already gone when cleanup ran")
        #expect(call.contextHadUnsavedChanges == false, "the deletion was already saved")
        #expect(call.request.relativePaths == ["k1/analysis-1.bin", "k1/side.jpg", "k1/side.mov"])
    }

    @Test func failedSaveSkipsMediaCleanupAndKeepsKick() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        try f.addVideo(to: kick, path: "k1/side.mov")
        let failing = KickService(context: f.context, mediaCleanup: f.media, saveHandler: ServiceFixture.failingSave)

        #expect(throws: KickServiceError.self) {
            try failing.deleteKick(kick)
        }
        #expect(f.media.calls.isEmpty)
        #expect(try f.count(Kick.self) == 1)
        #expect(try f.count(VideoAsset.self) == 1)
    }

    // MARK: Audit

    @Test func auditDetectsAthleteIDMismatch() throws {
        let athlete = try f.makeAthlete()
        let kick = try f.makeKick(for: athlete)
        let bogus = UUID()
        kick.athleteID = bogus   // simulated corruption, bypassing the service

        #expect(f.kicks.audit(kick) == [.athleteIDMismatch(storedAthleteID: bogus, linkedAthleteID: athlete.id)])
    }

    @Test func auditDetectsSessionAthleteMismatch() throws {
        let a = try f.makeAthlete("A")
        let b = try f.makeAthlete("B")
        let sessionOfB = try f.makeSession(for: b)
        let kick = try f.makeKick(for: a)
        kick.session = sessionOfB   // simulated corruption, bypassing the service

        #expect(f.kicks.audit(kick) == [.sessionAthleteMismatch(sessionID: sessionOfB.id, sessionAthleteID: b.id, kickAthleteID: a.id)])
    }

    @Test func modelsFromAnotherContextAreRejected() throws {
        let other = try ServiceFixture()
        let foreignAthlete = try other.makeAthlete()
        #expect(throws: KickServiceError.notInServiceContext) {
            try f.kicks.createKick(for: foreignAthlete, draft: .fieldGoal())
        }
    }
}
