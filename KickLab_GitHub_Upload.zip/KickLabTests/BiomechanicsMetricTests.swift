import Foundation
import Testing
@testable import KickLab

/// Step 8 metric extraction on synthetic kicks whose geometry is known exactly.
/// Pure: runs on Linux.
@Suite("Biomechanics metrics (synthetic kicks)")
struct BiomechanicsMetricTests {
    typealias Script = SyntheticPose.KickScript

    private func value(_ r: KickBiomechanicsResult, _ key: KickMetricKey) -> Double? { r.measurement(key)?.value }
    private func confidence(_ r: KickBiomechanicsResult, _ key: KickMetricKey) -> Double? { r.measurement(key)?.confidence }

    // MARK: Normal kicks

    @Test func fieldGoalMetricsMatchTheScriptedGeometry() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal)
        #expect(r.measurements.map(\.key) == KickMetricKey.allCases, "every metric reported, in catalog order")

        // Plant at 1.2 s, contact estimated at 1.4 s.
        #expect(value(r, .plantToContactTime) == 0.2)
        // The plant foot never moves after touchdown; the torso stays upright.
        #expect(value(r, .plantFootDrift) == 0)
        #expect(value(r, .torsoLeanAtContact) == 0)
        #expect(value(r, .torsoLeanRange) == 0)
        // The body stops at 1.25 s, before contact.
        #expect(value(r, .bodyForwardSpeedAtContact) == 0)
        #expect(value(r, .followThroughBodyTravel) == 0)
        // Approach 0.25 units/s with a 0.15 torso = 1.667 body lengths/s; smoothing at the
        // start and end of the run-up pulls the average slightly lower.
        #expect(near(value(r, .approachSpeed), 1.637, 1e-9))
        let speed: Double = value(r, .approachSpeed) ?? 0
        #expect((1.55...1.667).contains(speed))
        // Swing: 0.4 units over 0.4 s with smoothstep, peak 1.5 units/s = 10 body lengths/s.
        #expect(near(value(r, .peakFootSpeed), 10, 0.2))
        #expect(value(r, .footSpeedAtContact) == value(r, .peakFootSpeed), "equal today: contact is estimated at the speed peak")
        // The ankle stays at ankle height: 0.2 below the hip = −1.333 body lengths.
        #expect(value(r, .followThroughFootHeight) == -1.333)
        // Follow-through ends when foot speed falls to 25% of peak (≈ 1.57–1.58 s).
        #expect(near(value(r, .followThroughDuration), 0.183, 0.017))
    }

    @Test func confidenceFollowsTheDocumentedFormula() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal)
        // Every joint has Vision confidence 0.9 and is measured.
        // Approach: phase detected (1.0) → 0.9, and nothing depends on contact → measured.
        #expect(confidence(r, .approachSpeed) == 0.9)
        #expect(r.measurement(.approachSpeed)?.status == .measured)
        #expect(r.measurement(.approachSpeed)?.confidenceLevel == .high)
        // Plant and contact metrics: × 0.85 because contact is estimated → 0.765, estimated.
        #expect(confidence(r, .plantToContactTime) == 0.765)
        #expect(r.measurement(.plantToContactTime)?.status == .estimated)
        // Kicking-leg values at contact: × 0.7 at 60 fps (frame-rate factor) → 0.536.
        #expect(confidence(r, .kickingKneeAngleAtContact) == 0.536)
        #expect(r.measurement(.kickingKneeAngleAtContact)?.confidenceInputs?.frameRateFactor == 0.7)
        #expect(r.measurement(.kickingKneeAngleAtContact)?.confidenceLevel == .medium)
    }

    @Test func higherFrameRateRaisesContactConfidence() {
        var script = Script.fieldGoal
        script.frameRate = 120
        let r = SyntheticBiomechanics.analyze(script)
        #expect(r.measurement(.kickingKneeAngleAtContact)?.confidenceInputs?.frameRateFactor == 1)
        #expect(confidence(r, .kickingKneeAngleAtContact) == 0.765)
    }

    @Test func patUsesThePlaceKickMetrics() {
        let fg = SyntheticBiomechanics.analyze(.fieldGoal)
        let pat = SyntheticBiomechanics.analyze(.fieldGoal, kickType: .pat)
        #expect(pat.profile.name == "pat-v1")
        #expect(pat.measurements == fg.measurements)
        #expect(pat.availableMetricCount == KickMetricKey.allCases.count - PerspectiveMetricSupport.frontalPlaneMetrics.count)
    }

    @Test func kickoffMeasuresTheLongerApproach() {
        let r = SyntheticBiomechanics.analyze(.kickoff, kickType: .kickoff)
        #expect(r.profile.name == "kickoff-v1")
        // 0.3 units/s ÷ 0.15 = 2 body lengths/s.
        let speed: Double = value(r, .approachSpeed) ?? 0
        #expect((1.9...2.0).contains(speed))
        let windowStart: Double = r.measurement(.approachSpeed)?.windowStart ?? 0
        let windowEnd: Double = r.measurement(.approachSpeed)?.windowEnd ?? 0
        #expect(windowEnd - windowStart > 1.5)
        #expect(near(value(r, .plantToContactTime), 0.2, 0.02))
        // Scored with the kickoff band (ideal from 4 body lengths/s): 2 → (2 − 1) ÷ 3.
        let approach = r.category(.approach)?.components.first { $0.key == .approachSpeed }
        #expect(near(approach?.componentScore, 33.0, 1.5))
    }

    @Test func puntIsLimitedToContactAndFollowThrough() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal, kickType: .punt)
        for key in [KickMetricKey.approachSpeed, .plantToContactTime, .plantFootDrift, .backswingDepth, .torsoLeanRange] {
            #expect(r.measurement(key)?.unavailableReason == .unsupportedKickType, "\(key)")
        }
        #expect(r.measurement(.kickingKneeAngleAtContact)?.isAvailable == true)
        #expect(r.measurement(.followThroughDuration)?.isAvailable == true)
        #expect(r.category(.approach)?.summary == "Not scored for this kick type.")
        #expect(r.overall?.score != nil, "3 of 3 expected categories")
    }

    @Test func unknownKickTypeMeasuresNothing() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal, kickType: .unknown)
        #expect(r.availableMetricCount == 0)
        #expect(r.observationDrafts.isEmpty)
        #expect(r.overall?.score == nil)
    }

    // MARK: Kicking foot

    @Test func leftFootedKickIsTheExactMirrorOfTheRightFootedKick() {
        // Mirror the whole right-footed kick (x → 1 − x, left ↔ right). The result is a
        // left-footed kicker running the other way; every metric must be identical.
        let right = SyntheticPose.timeline(.fieldGoal)
        var mirrored = right
        for i in mirrored.samples.indices {
            mirrored.samples[i].joints = PoseCoordinates.mirrored(right.samples[i].joints, swapSides: true)
        }
        var leftScript = Script.fieldGoal
        leftScript.kickingFoot = .left
        let r = SyntheticBiomechanics.analyze(.fieldGoal)
        let l = SyntheticBiomechanics.analyze(leftScript, timeline: mirrored)
        for key in KickMetricKey.allCases where !PerspectiveMetricSupport.frontalPlaneMetrics.contains(key) {
            let a = value(r, key)
            let b = value(l, key)
            #expect(a != nil, "\(key)")
            #expect(near(b, a ?? .nan, 1e-6), "\(key): right \(String(describing: a)) vs left \(String(describing: b))")
        }
        #expect(l.categories.map(\.score) == r.categories.map(\.score))
    }

    @Test func wrongKickingFootFindsNoPlant() {
        var leftScript = Script.fieldGoal
        leftScript.kickingFoot = .left
        let r = SyntheticBiomechanics.analyze(leftScript, analyzeAs: .right)
        #expect(r.measurement(.plantToContactTime)?.isAvailable == false)
        #expect(r.observationDrafts.allSatisfy { $0.ruleKey?.hasPrefix("plant") != true })
    }

    // MARK: Data quality

    @Test func missingShouldersMakeTorsoMetricsUnavailableNotZero() {
        var timeline = SyntheticPose.timeline(.fieldGoal)
        for i in timeline.samples.indices where timeline.samples[i].timestamp >= 1.1 {
            timeline.samples[i].joints[.leftShoulder] = .unavailable
            timeline.samples[i].joints[.rightShoulder] = .unavailable
        }
        let r = SyntheticBiomechanics.analyze(.fieldGoal, timeline: timeline)
        #expect(r.measurement(.torsoLeanAtContact)?.status == .unavailable)
        #expect(r.measurement(.torsoLeanAtContact)?.value == nil)
        #expect(r.measurement(.torsoLeanAtContact)?.unavailableReason == .missingJoints)
        #expect(r.measurement(.torsoLeanRange)?.isAvailable == false)
        #expect(r.measurement(.kickingHipAngleAtContact)?.isAvailable == false, "uses the shoulder")
        // Unaffected metrics are still there.
        #expect(value(r, .plantToContactTime) == 0.2)
    }

    @Test func interpolatedJointsLowerConfidence() {
        var timeline = SyntheticPose.timeline(.fieldGoal)
        // Drop the kicking knee for two frames at contact (short gap → interpolated).
        for i in timeline.samples.indices where [1.4, 1.4 + 1.0 / 60].contains(where: { abs(timeline.samples[i].timestamp - $0) < 1e-9 }) {
            timeline.samples[i].joints[.rightKnee] = nil
        }
        let r = SyntheticBiomechanics.analyze(.fieldGoal, timeline: timeline)
        let knee = r.measurement(.kickingKneeAngleAtContact)
        // Joint quality: (0.9 + 0.9 × 0.6 + 0.9) ÷ 3 = 0.78 → 0.78 × 0.85 × 0.7 = 0.464.
        #expect(near(knee?.confidenceInputs?.jointQuality, 0.78, 1e-9))
        #expect(near(knee?.confidenceInputs?.interpolatedFraction, 1.0 / 3.0, 1e-9))
        #expect(knee?.confidence == 0.464)
        #expect(knee?.confidenceLevel == .low)
        #expect(knee?.status == .estimated)
    }

    @Test func lowConfidenceJointsNeverProduceClaims() {
        var script = Script.fieldGoal
        script.confidence = 0.3
        let r = SyntheticBiomechanics.analyze(script)
        let knee = r.measurement(.kickingKneeAngleAtContact)
        #expect(knee?.status == .unavailable)
        #expect(knee?.unavailableReason == .lowConfidence)
        #expect(knee?.confidenceInputs != nil, "the reason stays explainable")
        #expect(r.observationDrafts.isEmpty, "no coaching from weak evidence")
        #expect(r.overall?.score == nil)
        #expect(r.categories.filter { $0.category != .overall }.allSatisfy { $0.score == nil })
    }

    @Test func ambiguousContactReducesConfidenceAndSilencesCoaching() {
        // Step 12D: two genuine kicks in one clip (a setup practice swing is no longer ambiguous).
        let r = SyntheticBiomechanics.analyze(.fieldGoal, timeline: SyntheticPose.concatenated([.fieldGoal, .fieldGoal]))
        for m in r.measurements where m.isAvailable {
            let confidence: Double = m.confidence ?? 1
            let phaseFactor: Double = m.confidenceInputs?.phaseFactor ?? 1
            #expect(confidence < 0.5, "\(m.key)")
            #expect(m.status == .estimated)
            #expect(phaseFactor <= 0.4)
        }
        #expect(r.measurement(.plantToContactTime)?.isAvailable == false)
        #expect(r.observationDrafts.isEmpty)
        #expect(!r.isSufficient)
    }

    @Test func unavailablePlantMakesPlantMetricsUnavailableWithoutSubstitutes() {
        var timeline = SyntheticPose.timeline(.fieldGoal)
        for i in timeline.samples.indices where (1.1...1.7).contains(timeline.samples[i].timestamp) {
            timeline.samples[i].joints[.leftAnkle] = .unavailable
        }
        let r = SyntheticBiomechanics.analyze(.fieldGoal, timeline: timeline)
        for key in [KickMetricKey.plantToContactTime, .plantFootDrift, .plantKneeAngleAtContact, .backswingDepth, .torsoLeanRange, .approachLateSpeedChange] {
            #expect(r.measurement(key)?.unavailableReason == .phaseUnavailable, "\(key)")
            #expect(r.measurement(key)?.missingPhase == .plant, "\(key)")
        }
        #expect(r.category(.plant)?.score == nil)
        // Contact-only metrics are still measured.
        #expect(r.measurement(.kickingKneeAngleAtContact)?.isAvailable == true)
    }

    @Test func noisyInputStaysCloseToTheCleanKick() {
        var script = Script.fieldGoal
        script.noise = 0.002
        let clean = SyntheticBiomechanics.analyze(.fieldGoal)
        let noisy = SyntheticBiomechanics.analyze(script)
        #expect(near(value(noisy, .plantToContactTime), 0.2, 1.0 / 60))
        #expect(near(value(noisy, .approachSpeed), value(clean, .approachSpeed) ?? 0, 0.1))
        #expect(near(value(noisy, .plantFootDrift), 0, 0.05))
        #expect(near(value(noisy, .torsoLeanAtContact), 0, 2))
        for (a, b) in zip(clean.categories, noisy.categories) {
            #expect(near(b.score, a.score ?? .nan, 6), "\(a.category)")
        }
        #expect(noisy.observationDrafts.allSatisfy { $0.kind != .improve }, "noise alone triggers no corrections")
    }

    @Test func cameraAngleScalesConfidenceButNotValues() {
        let side = SyntheticBiomechanics.analyze(.fieldGoal)
        // Step 12E: a diagonal view keeps timings at full confidence and speed ratios at
        // reduced confidence (values unchanged); foreshortened geometry is not reported.
        let diagonal = SyntheticBiomechanics.analyze(.fieldGoal, cameraAngle: .oblique)
        #expect(value(diagonal, .plantToContactTime) == value(side, .plantToContactTime))
        #expect(diagonal.measurement(.plantToContactTime)?.confidenceInputs?.cameraFactor == 1)
        #expect(confidence(diagonal, .plantToContactTime) == confidence(side, .plantToContactTime))
        #expect(diagonal.measurement(.followThroughDuration)?.confidenceInputs?.cameraFactor == 1)
        #expect(value(diagonal, .approachSpeedVariation) == value(side, .approachSpeedVariation))
        #expect(diagonal.measurement(.approachSpeedVariation)?.confidenceInputs?.cameraFactor == MetricConfidenceModel.cameraFactor(.oblique))
        #expect(diagonal.measurement(.torsoLeanAtContact)?.unavailableReason == .cameraAngleUnsupported)
        #expect(diagonal.measurement(.approachSpeed)?.unavailableReason == .cameraAngleUnsupported)
        // An unknown angle analyzed as a side view keeps the Step 12A penalty on geometry.
        let unknown = SyntheticBiomechanics.analyze(.fieldGoal, cameraAngle: .unknown)
        #expect(value(unknown, .torsoLeanAtContact) == value(side, .torsoLeanAtContact))
        #expect(unknown.measurement(.torsoLeanAtContact)?.confidenceInputs?.cameraFactor == MetricConfidenceModel.cameraFactor(.unknown))
        #expect(unknown.measurement(.plantToContactTime)?.confidenceInputs?.cameraFactor == 1)
        // A rear camera can't show sagittal geometry at all: unsupported, never a halved value.
        let rear = SyntheticBiomechanics.analyze(.fieldGoal, cameraAngle: .rear)
        #expect(rear.measurement(.torsoLeanAtContact)?.unavailableReason == .cameraAngleUnsupported)
        #expect(rear.measurement(.kickingKneeAngleAtContact)?.unavailableReason == .cameraAngleUnsupported)
        #expect(rear.measurement(.plantToContactTime)?.isAvailable == true, "timings are supported from behind")
    }

    // MARK: Scenarios

    @Test func abnormalTorsoLeanIsMeasuredExactly() {
        var back = Script.fieldGoal
        back.torsoLeanDegrees = -35
        #expect(value(SyntheticBiomechanics.analyze(back), .torsoLeanAtContact) == -35)
        var forward = Script.fieldGoal
        forward.torsoLeanDegrees = 22
        #expect(value(SyntheticBiomechanics.analyze(forward), .torsoLeanAtContact) == 22)
    }

    @Test func torsoMovementThroughTheSwingIsItsRange() {
        var script = Script.fieldGoal
        script.torsoLeanDegrees = -20
        script.leanFrom = 1.4   // leans back only from contact
        let r = SyntheticBiomechanics.analyze(script)
        #expect(near(value(r, .torsoLeanRange), 20, 0.5))
    }

    @Test func limitedKneeExtensionIsMeasuredExactly() {
        var script = Script.fieldGoal
        script.kickingKneeAngle = 115
        #expect(value(SyntheticBiomechanics.analyze(script), .kickingKneeAngleAtContact) == 115)
    }

    @Test func plantTimingDifferences() {
        var late = Script.fieldGoal
        late.plantTime = 1.35
        late.approachEnd = 1.4
        var early = Script.fieldGoal
        early.plantTime = 1.0
        early.approachEnd = 1.05
        #expect(value(SyntheticBiomechanics.analyze(late), .plantToContactTime) == 0.05)
        #expect(value(SyntheticBiomechanics.analyze(early), .plantToContactTime) == 0.4)
    }

    @Test func plantSlipAfterContactIsMeasured() {
        var script = Script.fieldGoal
        script.plantSlip = 0.075   // 0.5 body lengths in total, mostly inside the window
        let r = SyntheticBiomechanics.analyze(script)
        #expect(r.measurement(.plantToContactTime)?.isAvailable == true, "Step 7 still finds the plant")
        #expect(near(value(r, .plantFootDrift), 0.458, 1e-9))
        let drift: Double = value(r, .plantFootDrift) ?? 0
        #expect((0.4...0.5).contains(drift))
    }

    @Test func shortenedFollowThroughIsMeasured() {
        var script = Script.fieldGoal
        script.swingStopsAt = 1.5
        let r = SyntheticBiomechanics.analyze(script)
        #expect(near(value(r, .followThroughDuration), 0.117, 1e-9))
        let shortened: Double = value(r, .followThroughDuration) ?? 1
        let normal: Double = value(SyntheticBiomechanics.analyze(.fieldGoal), .followThroughDuration) ?? 0
        #expect(shortened < normal)
    }

    // MARK: Determinism and drafts

    @Test func identicalInputGivesIdenticalOutput() {
        var script = Script.fieldGoal
        script.torsoLeanDegrees = -35
        script.plantSlip = 0.075
        let a = SyntheticBiomechanics.analyze(script)
        let b = SyntheticBiomechanics.analyze(script)
        #expect(a == b)
        #expect(a.observationDrafts.map(\.id) == b.observationDrafts.map(\.id))
    }

    @Test func draftsPassTheStoredResultValidator() {
        var script = Script.fieldGoal
        script.torsoLeanDegrees = -35
        script.kickingKneeAngle = 115
        script.plantSlip = 0.075
        for r in [SyntheticBiomechanics.analyze(script), SyntheticBiomechanics.analyze(.fieldGoal, kickType: .punt),
                  SyntheticBiomechanics.analyze(.fieldGoal, kickType: .unknown)] {
            #expect(r.metricDrafts.count == KickMetricKey.allCases.count)
            for draft in r.metricDrafts { #expect(AnalysisResultValidator.validate(draft).isEmpty, "\(draft.metricKey)") }
            for draft in r.scoreDrafts { #expect(AnalysisResultValidator.validate(draft).isEmpty, "\(draft.category)") }
            var existing: [ExistingObservationRef] = []
            for draft in r.observationDrafts {
                #expect(AnalysisResultValidator.validate(draft, existing: existing).isEmpty, "\(draft.message)")
                existing.append(ExistingObservationRef(id: draft.id, kind: draft.kind))
            }
        }
    }

    @Test func unavailableDraftsCarryNoNumbers() {
        let r = SyntheticBiomechanics.analyze(.fieldGoal, kickType: .punt)
        let draft = r.metricDrafts.first { $0.metricKey == KickMetricKey.plantFootDrift.rawValue }
        #expect(draft?.measurementStatus == .unavailable)
        #expect(draft?.value == nil)
        #expect(draft?.confidence == nil)
        #expect(draft?.unit == .bodyLengths)
    }

    @Test func noKickerMeansEverythingUnavailable() {
        let r = KickBiomechanicsAnalyzer.analyze(
            timeline: nil, signals: .empty,
            phases: .unavailable(kickType: .fieldGoal, support: .full, coverage: 0, notes: []),
            context: BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right), idSeed: SyntheticBiomechanics.seed
        )
        #expect(r.measurements.allSatisfy { $0.unavailableReason == .noKicker })
        #expect(r.observationDrafts.isEmpty)
        #expect(!r.isSufficient)
    }

    @Test func catalogIsCompleteAndConsistent() {
        #expect(Set(KickMetricKey.allCases.map(\.rawValue)).count == KickMetricKey.allCases.count)
        for definition in KickMetricCatalog.all {
            #expect(!definition.displayName.isEmpty)
            #expect(definition.unit != .unknown)
            #expect(definition.unit != .milesPerHour && definition.unit != .metersPerSecond && definition.unit != .yards,
                    "no real-world units from a single camera")
            #expect(KickMetricCatalog.scoredCategories.contains(definition.category))
            #expect(!definition.requiredPhases.isEmpty)
        }
        #expect(KickMetricKey.footSpeedAtContact.definition.betterDirection == .higher)
        #expect(BiomechanicsProfile.standard(for: .fieldGoal).scoring[.footSpeedAtContact]?.weight == 0, "informational")
    }
}
