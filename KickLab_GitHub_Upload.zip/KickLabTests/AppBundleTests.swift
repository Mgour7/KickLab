#if os(iOS)
import Foundation
import Testing
@testable import KickLab

/// Requires Xcode: checks the built app bundle the tests run inside.
@Suite("Step 11 app bundle")
struct AppBundleTests {
    private var info: [String: Any] { Bundle.main.infoDictionary ?? [:] }

    @Test func identityAndVersion() {
        #expect(Bundle.main.bundleIdentifier == "com.kicklab.app")
        #expect(info["CFBundleDisplayName"] as? String == "KickLab")
        #expect(info["CFBundleShortVersionString"] as? String == "0.1.0")
        let build = info["CFBundleVersion"] as? String
        #expect(build.flatMap(Int.init) != nil, "build number is a whole number")
        #expect(info["ITSAppUsesNonExemptEncryption"] as? Bool == false)
        #expect(info["LSApplicationCategoryType"] as? String == "public.app-category.sports")
        #expect(info["MinimumOSVersion"] as? String == "18.0")
        #expect((info["UIDeviceFamily"] as? [Int]) == [1], "iPhone only")
    }

    @Test func requestsOnlyTheCapturePermissions() {
        // Build 21: in-app recording needs the camera; sound is opt-in; "save a copy to
        // Photos" is add-only. Reading the photo library and location are never requested.
        for key in ["NSCameraUsageDescription", "NSMicrophoneUsageDescription", "NSPhotoLibraryAddUsageDescription"] {
            #expect((info[key] as? String)?.isEmpty == false, "\(key) needs a purpose string")
        }
        for key in ["NSPhotoLibraryUsageDescription", "NSLocationWhenInUseUsageDescription"] {
            #expect(info[key] == nil, "\(key) should not be requested")
        }
    }

    @Test func privacyManifestAndIconAreBundled() {
        #expect(Bundle.main.url(forResource: "PrivacyInfo", withExtension: "xcprivacy") != nil)
        let icons = info["CFBundleIcons"] as? [String: Any]
        let primary = icons?["CFBundlePrimaryIcon"] as? [String: Any]
        #expect(primary?["CFBundleIconName"] as? String == "AppIcon")
    }
}
#endif
