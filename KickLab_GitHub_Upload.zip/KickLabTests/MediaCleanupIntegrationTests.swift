import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: KickService/AthleteService deletion with the real `ManagedMediaStore`
/// as their `MediaCleanupHandling`, exactly as wired in `AppServices`.
@MainActor
@Suite("Media cleanup integration")
struct MediaCleanupIntegrationTests {
    let f: ServiceFixture
    let temp: TemporaryDirectory
    let store: ManagedMediaStore
    let videos: VideoStorageService

    init() throws {
        f = try ServiceFixture()
        temp = try TemporaryDirectory()
        store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        videos = VideoStorageService(context: f.context, store: store)
    }

    private var kickService: KickService { KickService(context: f.context, mediaCleanup: store) }

    /// A kick with one imported video (plus thumbnail) and an analysis with an artifacts folder.
    private func kickWithMedia(for athlete: Athlete) async throws -> (Kick, [URL]) {
        let kick = try f.makeKick(for: athlete)
        let source = try temp.writeFile(named: "\(UUID().uuidString).mov")
        let video = try await videos.importVideo(from: source, for: kick, angle: .side, sourceType: .filesImport)
        let analysis = try f.makeCompletedAnalysis(for: kick, video: video, completedAt: .now)
        let artifacts = try videos.artifactsLocation(for: analysis)
        analysis.artifactsRelativePath = artifacts.relativePath   // fixture: engine output arrives in a later step
        try f.context.save()
        let artifactFile = try temp.writeFile("\(artifacts.relativePath)/pose.bin", under: store.analysisRootURL)
        let urls = [try #require(videos.fileURL(for: video)), try #require(videos.thumbnailURL(for: video)), artifactFile]
        return (kick, urls)
    }

    @Test func kickDeletionRemovesManagedFilesAfterTheSave() async throws {
        defer { temp.remove() }
        let athlete = try f.makeAthlete()
        let (kick, urls) = try await kickWithMedia(for: athlete)
        #expect(urls.allSatisfy(exists))

        try kickService.deleteKick(kick)

        #expect(try f.count(Kick.self) == 0)
        #expect(try f.count(VideoAsset.self) == 0)
        #expect(urls.allSatisfy { !exists($0) })
        #expect(store.orphanReport(referencedMediaPaths: [], referencedAnalysisPaths: [], minimumAge: 0).isEmpty)
    }

    @Test func failedSaveKeepsRecordsAndFiles() async throws {
        defer { temp.remove() }
        let athlete = try f.makeAthlete()
        let (kick, urls) = try await kickWithMedia(for: athlete)
        let failing = KickService(context: f.context, mediaCleanup: store, saveHandler: ServiceFixture.failingSave)

        #expect(throws: KickServiceError.self) {
            try failing.deleteKick(kick)
        }
        #expect(try f.count(Kick.self) == 1)
        #expect(urls.allSatisfy(exists), "no file is removed when persistence fails")
    }

    @Test func missingFilesDoNotFailDeletion() async throws {
        defer { temp.remove() }
        let athlete = try f.makeAthlete()
        let (kick, urls) = try await kickWithMedia(for: athlete)
        for url in urls { try FileManager.default.removeItem(at: url) }

        try kickService.deleteKick(kick)

        #expect(try f.count(Kick.self) == 0)
    }

    @Test func onlyThatKicksManagedFilesAreRemoved() async throws {
        defer { temp.remove() }
        let athlete = try f.makeAthlete()
        let (doomed, _) = try await kickWithMedia(for: athlete)
        let (survivor, survivorURLs) = try await kickWithMedia(for: athlete)
        let importSource = try temp.writeFile(named: "keep-me.mov")
        try await videos.importVideo(from: importSource, for: survivor, angle: .rear, sourceType: .filesImport)

        try kickService.deleteKick(doomed)

        #expect(survivorURLs.allSatisfy(exists))
        #expect(exists(importSource), "import sources outside KickLab storage are never deleted")
        #expect(try f.count(Kick.self) == 1)
    }

    @Test func permanentAthleteDeletionRemovesOnlyThatAthletesMedia() async throws {
        defer { temp.remove() }
        let sam = try f.makeAthlete("Sam")
        let alex = try f.makeAthlete("Alex")
        let (_, samURLs) = try await kickWithMedia(for: sam)
        let (_, alexURLs) = try await kickWithMedia(for: alex)
        let athletes = AthleteService(context: f.context, mediaCleanup: store)

        let plan = try athletes.deletionPlan(for: sam)
        try athletes.permanentlyDelete(using: plan, confirmation: AthleteDeletionConfirmation(typedText: plan.confirmationPhrase))

        #expect(samURLs.allSatisfy { !exists($0) })
        #expect(alexURLs.allSatisfy(exists))
    }
}
