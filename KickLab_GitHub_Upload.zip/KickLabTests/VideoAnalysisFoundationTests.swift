import Foundation
import Testing
@testable import KickLab

/// The analysis engine contract. No SwiftData; runs on any platform. No delays.
@Suite("Video analysis foundation")
struct VideoAnalysisFoundationTests {
    private let kickID = UUID()
    private let primaryID = UUID()
    private let secondaryID = UUID()

    private var request: VideoAnalysisRequest {
        VideoAnalysisRequest(
            kickID: kickID,
            kickType: .fieldGoal,
            inputs: [
                VideoAnalysisInput(videoID: primaryID, angle: .side, isPrimary: true, relativeFilePath: "k/v1/original.mov",
                                   frameRate: 240, durationSeconds: 3, syncOffsetSeconds: 0, contactTimeSeconds: nil),
                VideoAnalysisInput(videoID: secondaryID, angle: .rear, isPrimary: false, relativeFilePath: "k/v2/original.mov",
                                   frameRate: 60, durationSeconds: 3.2, syncOffsetSeconds: 0.12, contactTimeSeconds: nil),
            ]
        )
    }

    @Test func requestPreservesKickAndVideoIdentity() {
        let r = request
        #expect(r.kickID == kickID)
        #expect(r.inputVideoIDs == [primaryID, secondaryID])
        #expect(r.inputs.first?.isPrimary == true)
        #expect(r.inputs.last?.syncOffsetSeconds == 0.12)
    }

    @Test func unavailableEngineReportsUnavailable() async {
        let engine: any VideoAnalysisService = UnavailableVideoAnalysisService()
        #expect(engine.availability == .unavailable(reason: UnavailableVideoAnalysisService.reason))
        #expect(!engine.availability.isAvailable)

        await #expect(throws: VideoAnalysisError.unavailable(reason: UnavailableVideoAnalysisService.reason)) {
            _ = try await engine.prepare(request)
        }

        let recorder = ProgressRecorder()
        await #expect(throws: VideoAnalysisError.unavailable(reason: UnavailableVideoAnalysisService.reason)) {
            _ = try await engine.analyze(request) { recorder.record($0) }
        }
        #expect(recorder.events.isEmpty, "an unavailable engine reports no fake progress")
    }

    @Test func cancelledTaskReportsCancelled() async {
        let engine = UnavailableVideoAnalysisService()
        let request = self.request
        // Child tasks added to an already-cancelled group start cancelled, so this is deterministic.
        let error = await withTaskGroup(of: VideoAnalysisError?.self) { group in
            group.cancelAll()
            group.addTask {
                do {
                    _ = try await engine.analyze(request) { _ in }
                    return nil
                } catch let error as VideoAnalysisError {
                    return error
                } catch {
                    return .failed(String(describing: error))
                }
            }
            return await group.next() ?? nil
        }
        #expect(error == .cancelled)
    }

    @Test func progressIsClamped() {
        #expect(VideoAnalysisProgress(stage: .measuring, fractionCompleted: 1.7).fractionCompleted == 1)
        #expect(VideoAnalysisProgress(stage: .preparing, fractionCompleted: -3).fractionCompleted == 0)
        #expect(VideoAnalysisProgress(stage: .scoring, fractionCompleted: .nan).fractionCompleted == 0)
        #expect(VideoAnalysisProgress(stage: .detectingPose, fractionCompleted: 0.42).fractionCompleted == 0.42)
        #expect(VideoAnalysisStage.allCases.first == .preparing)
        #expect(VideoAnalysisStage.allCases.last == .finishing)
    }
}

/// Thread-safe collector for progress callbacks.
final class ProgressRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: [VideoAnalysisProgress] = []

    func record(_ progress: VideoAnalysisProgress) {
        lock.lock()
        storage.append(progress)
        lock.unlock()
    }

    var events: [VideoAnalysisProgress] {
        lock.lock()
        defer { lock.unlock() }
        return storage
    }
}
