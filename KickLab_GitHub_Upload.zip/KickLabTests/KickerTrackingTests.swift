import Foundation
import Testing
@testable import KickLab

@Suite("Multi-person tracking and kicker selection")
struct KickerTrackingTests {
    private func track(_ frames: [PoseFrame]) -> (frames: [PoseFrame], tracks: [PoseTrack]) {
        PoseTracker.assignTracks(frames, aspectRatio: 1)
    }

    @Test func singleKickerIsSelectedAutomatically() {
        let tracked = track(SyntheticPose.frames(.fieldGoal))
        #expect(tracked.tracks.count == 1, "one person stays one track through the kick")
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        #expect(result.status == .selected)
        #expect(result.method == .automatic)
        #expect(result.selectedTrackID == tracked.tracks[0].trackID)
        #expect(!result.isAmbiguous)
        #expect(result.confidence > 0)
    }

    @Test func kickerIsChosenOverStillHolder() {
        let tracked = track(SyntheticPose.frames(.fieldGoal) { [SyntheticPose.holder(at: $0)] })
        #expect(tracked.tracks.count == 2)
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        #expect(result.status == .selected)
        let kickerID = tracked.frames[0].bodies[0].trackID
        #expect(result.selectedTrackID == kickerID)
        #expect(result.candidates.count == 2)
        #expect(result.candidates.first?.trackID == kickerID, "best first")
    }

    /// A second person making the same kicking motion, higher in the frame.
    static func secondKicker(at t: Double) -> BodyPose {
        var script = SyntheticPose.KickScript.fieldGoal
        script.startX = 0.05
        let b = SyntheticPose.kickerBody(at: t, script: script)
        return SyntheticPose.body(center: NormalizedPoint(x: b.center!.x, y: 0.2),
                                  kickingAnkle: b.point(.rightAnkle).map { NormalizedPoint(x: $0.x, y: 0.4) },
                                  plantAnkle: b.point(.leftAnkle).map { NormalizedPoint(x: $0.x, y: 0.4) })
    }

    @Test func twoSimilarMoversAreAmbiguous() {
        let tracked = track(SyntheticPose.frames(.fieldGoal) { [Self.secondKicker(at: $0)] })
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        #expect(result.status == .ambiguous)
        #expect(result.isAmbiguous)
        #expect(result.selectedTrackID == nil, "never silently picks when unsure")
        #expect(result.candidates.count >= 2)
        #expect(result.message.contains("Multiple possible kickers found"))
    }

    @Test func manualSeedWinsOverAutomaticChoice() {
        let tracked = track(SyntheticPose.frames(.fieldGoal) { [SyntheticPose.holder(at: $0)] })
        let holderID = tracked.frames[0].bodies[1].trackID
        let seed = KickerSeed(timestamp: 0.5, point: NormalizedPoint(x: 0.75, y: 0.6))
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks, seed: seed)
        #expect(result.status == .selected)
        #expect(result.method == .manualSeed)
        #expect(result.selectedTrackID == holderID)
        #expect(result.confidence == 1)
    }

    @Test func seedNearAPersonMatches() {
        let tracked = track(SyntheticPose.frames(.fieldGoal))
        // Just outside the skeleton's box, within the seed distance of its center.
        let seed = KickerSeed(timestamp: 0, point: NormalizedPoint(x: 0.3 + 0.06, y: 0.5))
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks, seed: seed)
        #expect(result.status == .selected)
        #expect(result.confidence < 1)
    }

    @Test func seedOnEmptySpaceDoesNotFallBack() {
        let tracked = track(SyntheticPose.frames(.fieldGoal))
        let seed = KickerSeed(timestamp: 1.0, point: NormalizedPoint(x: 0.95, y: 0.05))
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks, seed: seed)
        #expect(result.status == .seedNotMatched)
        #expect(result.selectedTrackID == nil)
    }

    @Test func noPeopleMeansNoCandidates() {
        let frames = (0..<30).map { PoseFrame(frameIndex: $0, timestamp: Double($0) / 30, bodies: []) }
        let tracked = track(frames)
        #expect(tracked.tracks.isEmpty)
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        #expect(result.status == .noCandidates)
        #expect(result.selectedTrackID == nil)
    }

    @Test func briefDetectionsAreNotCandidates() {
        var frames = SyntheticPose.frames(.fieldGoal)
        // A passer-by visible in 5 of 121 frames.
        for i in 0..<5 { frames[i].bodies.append(SyntheticPose.holder(at: 0)) }
        let tracked = track(frames)
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        #expect(result.status == .selected)
        #expect(result.candidates.count == 1)
    }

    @Test func tracksStayStableAndJumpsStartNewTracks() {
        let a = NormalizedPoint(x: 0.2, y: 0.5)
        let b = NormalizedPoint(x: 0.8, y: 0.5)
        var frames: [PoseFrame] = (0..<10).map { i in
            // Detection order swaps each frame; IDs must follow position, not order.
            let bodies = [SyntheticPose.body(center: a), SyntheticPose.body(center: b)]
            return PoseFrame(frameIndex: i, timestamp: Double(i) / 30, bodies: i.isMultiple(of: 2) ? bodies : bodies.reversed())
        }
        frames.append(PoseFrame(frameIndex: 10, timestamp: 10.0 / 30, bodies: [SyntheticPose.body(center: NormalizedPoint(x: 0.5, y: 0.1))]))
        let tracked = track(frames)
        let idA = tracked.frames[0].bodies[0].trackID
        for frame in tracked.frames.prefix(10) {
            let bodyA = frame.bodies.first { $0.center.map { abs($0.x - a.x) < 1e-9 } == true }
            #expect(bodyA?.trackID == idA)
        }
        let jumped = tracked.frames[10].bodies[0].trackID
        #expect(jumped != nil)
        #expect(jumped != idA)
        #expect(tracked.tracks.count == 3)
    }

    @Test func weakBodiesAreNotTracked() {
        let weak = SyntheticPose.body(center: NormalizedPoint(x: 0.5, y: 0.5), confidence: 0.1)
        let tracked = track([PoseFrame(frameIndex: 0, timestamp: 0, bodies: [weak])])
        #expect(tracked.frames[0].bodies[0].trackID == nil)
        #expect(tracked.tracks.isEmpty)
    }

    @Test func trackingResultIsCodable() throws {
        let tracked = track(SyntheticPose.frames(.fieldGoal) { [SyntheticPose.holder(at: $0)] })
        let result = PoseTracker.selectKicker(frames: tracked.frames, tracks: tracked.tracks)
        let decoded = try JSONDecoder().decode(KickerTrackingResult.self, from: JSONEncoder().encode(result))
        #expect(decoded == result)
    }

    // MARK: Pipeline

    @Test func pipelineRunsEndToEndWithAHolderInFrame() {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal) { [SyntheticPose.holder(at: $0)] },
            kickType: .fieldGoal,
            kickingFoot: .right
        ))
        #expect(output.tracking.status == .selected)
        #expect(output.sequence.kickerTrackID == output.tracking.selectedTrackID)
        let kickerSampleCount: Int? = output.kickerTimeline?.samples.count
        #expect(kickerSampleCount == 121)
        #expect(near(output.phases.plantTime, 1.2, 0.05))
        #expect(near(output.phases.estimatedContactTime, 1.4, 0.034))
        #expect(near(output.extractionConfidence, 0.9, 0.01))
        #expect(output.sequence.confidenceStatistics.framesWithKicker == 121)
    }

    @Test func pipelineReportsAmbiguityInsteadOfGuessing() {
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(.fieldGoal) { [Self.secondKicker(at: $0)] },
            kickType: .fieldGoal,
            kickingFoot: .right
        ))
        #expect(output.tracking.status == .ambiguous)
        #expect(output.sequence.kickerTrackID == nil)
        #expect(output.kickerTimeline == nil)
        #expect(output.phases.phases.allSatisfy { $0.status == .unavailable })
        #expect(output.extractionConfidence == 0)
    }
}
