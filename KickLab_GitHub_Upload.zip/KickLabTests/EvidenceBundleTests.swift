import Foundation
import Testing
@testable import KickLab

/// Build 15: evidence bundles — export, strict import, deterministic replay.
///
/// Data used: the REAL IMG_1709 pose (MediaPipe landmarks of the real frames — the app uses
/// Apple Vision, so numbers differ from the device) and the REAL YOLOX-S detections of the
/// real frames (onnxruntime, `RealVideo1709Football`), run through the production analysis
/// service on Linux with a fixture football analyzer standing in for Core ML. Synthetic
/// inputs are labelled.
@Suite("Evidence bundles and replay (build 15)")
struct EvidenceBundleTests {
    typealias Clip = RealVideoClip1709
    typealias Real = RealVideo1709Football

    /// Stands in for the Core ML analyzer: the recorded real detections, run through the
    /// same `analyze(raw:)` entry point the device uses, with the pose context the service
    /// passes in.
    struct FixtureFootballAnalyzer: FootballVideoAnalyzing {
        var isAvailable: Bool { true }
        func analyze(videoURL: URL, context: FootballAnalysisContext, progress: @escaping @Sendable (Double) -> Void) async throws -> FootballTrack {
            let raw = FootballRawEvidence(scanTimes: Real.scanTimes, broadScan: Real.broadScan, precisionTimes: Real.precisionTimes,
                                          precision: Real.precisionFrames.flatMap(\.detections), appearanceTimes: [], appearanceScores: [],
                                          cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [], camera: nil,
                                          strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                          ankle: context.ankle, aspect: context.aspect ?? Clip.displayAspectRatio, duration: Clip.durationSeconds)
            progress(1)
            return FootballTrackAnalyzer.analyze(raw: raw, detector: .yoloxS)
        }
    }

    /// Runs the production service and returns the stored artifacts.
    private func analyzeReal1709(sequence: PoseSequence = Clip.sequence, football: (any FootballVideoAnalyzing)? = FixtureFootballAnalyzer(),
                                 assistance: PhaseDetectionAssistance? = nil) async throws -> AnalysisArtifactBundle {
        let temp = try TemporaryDirectory()
        defer { temp.remove() }
        let store = ManagedMediaStore(locations: MediaLocations(baseURL: temp.kickLabBase), thumbnailGenerator: WritingThumbnailGenerator())
        try store.prepareDirectories()
        let path = ManagedPath.originalVideoPath(kickID: UUID(), videoID: UUID(), fileExtension: "mov")
        let url = try store.url(for: path, in: .media)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data("not a real video".utf8).write(to: url)
        let engine = PoseVideoAnalysisService(mediaStore: store, extractor: FakePoseExtractor { _ in sequence },
                                              footballAnalyzer: football ?? UnavailableFootballVideoAnalyzer(),
                                              now: { Date(timeIntervalSince1970: 1_800_000_000) })
        var options = VideoAnalysisOptions()
        options.kickingFoot = .right
        options.assistance = assistance
        let input = VideoAnalysisInput(videoID: sequence.videoID, angle: .rear, isPrimary: true, relativeFilePath: path,
                                       frameRate: 30, durationSeconds: Clip.durationSeconds, syncOffsetSeconds: 0, contactTimeSeconds: nil)
        let result = try await engine.analyze(VideoAnalysisRequest(kickID: UUID(), kickType: .fieldGoal, inputs: [input], options: options)) { _ in }
        return try AnalysisArtifactStore(analysisRootURL: store.analysisRootURL).readBundle(in: try #require(result.artifactsRelativePath))
    }

    private func context(_ annotations: EvidenceAnnotations = EvidenceAnnotations(contactAnnotation: "none"), crops: [(name: String, data: Data)] = []) -> EvidenceExportContext {
        EvidenceExportContext(appVersion: "0.1.0", appBuild: "15", osVersion: "18.0", status: "completed", failureReason: nil, kickType: .fieldGoal,
                              cameraAngle: .rear, annotations: annotations, summaryText: "summary", createdAt: Date(timeIntervalSince1970: 1_800_000_000),
                              crops: crops)
    }

    // MARK: Round trip and deterministic replay (real data)

    @Test func aRealAnalysisReplaysIdenticallyFromItsEvidence() async throws {
        let artifacts = try await analyzeReal1709()
        #expect(artifacts.phases.football?.raw != nil, "raw detections recorded with the analysis")
        let built = try EvidenceBundle.build(artifacts: artifacts, context: context())
        let contents = try EvidenceBundle.read(zip: built.data)
        #expect(contents.artifacts == artifacts, "every analysis file survives the round trip")
        let report = EvidenceReplay.run(contents)
        #expect(report.footballStage == .replayed)
        #expect(report.matchesRecording, "\(report.text)")
        let r = try #require(report.replayed)
        #expect(r.contactOutcome == ContactOutcome.ballConstrainedContactInterval.rawValue)
        #expect(r.ballLastStationary == 7.902 && r.ballFirstMovement == 7.968)
        #expect(r.contactTime == 7.935)
        #expect(r.footballMethod == "automaticFootballDetection" && r.fusionAccepted == true)
    }

    /// Writes the sample bundle used by `Datasets/evidence/` when KICKLAB_EVIDENCE_SAMPLE_OUT
    /// is set (development tooling; does nothing in normal test runs).
    @Test func writeSampleBundleWhenAsked() async throws {
        guard let out = ProcessInfo.processInfo.environment["KICKLAB_EVIDENCE_SAMPLE_OUT"] else { return }
        let artifacts = try await analyzeReal1709()
        var c = context()
        c.summaryText = "Development sample: IMG_1709 rear view. Pose = MediaPipe landmarks of the real frames (NOT Apple Vision); football = YOLOX-S detections of the real frames from onnxruntime, analyzed by the app's own code on Linux."
        try EvidenceBundle.build(artifacts: artifacts, context: c).data.write(to: URL(fileURLWithPath: out))
    }

    @Test func exportsAreByteForByteReproducible() async throws {
        let artifacts = try await analyzeReal1709()
        let a = try EvidenceBundle.build(artifacts: artifacts, context: context()).data
        let b = try EvidenceBundle.build(artifacts: artifacts, context: context()).data
        #expect(a == b)
    }

    @Test func aChangedDecisionIsReportedAsADifference() async throws {
        let artifacts = try await analyzeReal1709()
        var contents = try EvidenceBundle.read(zip: try EvidenceBundle.build(artifacts: artifacts, context: context()).data)
        contents.recorded?.contactTime = 7.968
        let report = EvidenceReplay.run(contents)
        #expect(report.differences.map(\.field) == ["contactTime"])
        #expect(!report.matchesRecording)
        let baseline = report
        #expect(EvidenceReplay.compare(baseline: baseline, current: report).isEmpty)
    }

    // MARK: Missing data and gate failures

    @Test func anAnalysisWithoutFilesStillExportsAndSaysWhy() throws {
        var c = context()
        c.status = "failed"
        c.failureReason = "The analysis failed: Pose detection failed on every frame."
        let built = try EvidenceBundle.build(artifacts: nil, context: c)
        #expect(built.manifest.unavailable.contains { $0.hasPrefix("analysis files: none were stored") })
        let contents = try EvidenceBundle.read(zip: built.data)
        let report = EvidenceReplay.run(contents)
        #expect(report.replayed == nil && report.footballStage == .absent)
        #expect(report.text.contains("not replayable"))
    }

    /// SYNTHETIC pose: a still person (no run-up, no swing) — the analysis stops at the
    /// kick-window gate, and its evidence still exports and replays to the same stop.
    @Test func aKickWindowFailureExportsAndReplays() async throws {
        let still = SyntheticPose.sequence(.fieldGoal, videoID: Clip.sequence.videoID)
        var frozen = still
        frozen.frames = still.frames.map { f in
            var g = f
            g.bodies = still.frames[0].bodies
            return g
        }
        let artifacts = try await analyzeReal1709(sequence: frozen, football: nil)
        let contents = try EvidenceBundle.read(zip: try EvidenceBundle.build(artifacts: artifacts, context: context()).data)
        let report = EvidenceReplay.run(contents)
        #expect(contents.recorded?.stopGate == report.replayed?.stopGate)
        #expect(report.replayed?.stopGate != nil, "the analysis stopped at a gate")
        #expect(contents.manifest.unavailable.contains { $0.hasPrefix("football: the detector didn't run") })
    }

    @Test func aTrackRecordedBeforeBuild15IsReusedAndSaidToBe() async throws {
        var artifacts = try await analyzeReal1709()
        artifacts.phases.football?.raw = nil
        let built = try EvidenceBundle.build(artifacts: artifacts, context: context())
        #expect(built.manifest.unavailable.contains { $0.hasPrefix("football raw detections: not recorded") })
        let report = EvidenceReplay.run(try EvidenceBundle.read(zip: built.data))
        #expect(report.footballStage == .recordedTrackReused)
        #expect(report.matchesRecording, "\(report.text)")
    }

    // MARK: Human annotations are separate

    @Test func annotationsTravelSeparatelyAndNeverChangeTheReplay() async throws {
        let artifacts = try await analyzeReal1709()
        var marks = EvidenceAnnotations(contactAnnotation: "contact")
        marks.markedContactTime = 8.0
        marks.verification = VideoVerification(plant: .frame(time: 7.8), firstBallMovement: .frame(time: 7.968))
        let plain = EvidenceReplay.run(try EvidenceBundle.read(zip: try EvidenceBundle.build(artifacts: artifacts, context: context()).data))
        let marked = try EvidenceBundle.read(zip: try EvidenceBundle.build(artifacts: artifacts, context: context(marks)).data)
        #expect(marked.annotations?.markedContactTime == 8.0)
        #expect(marked.annotations?.note.hasPrefix("HUMAN INPUT") == true)
        #expect(marked.manifest.privacy.includesHumanAnnotations)
        #expect(EvidenceReplay.run(marked).replayed == plain.replayed, "human marks never feed the replay")
    }

    @Test func userAssistedAnalysesReplayWithTheirRecordedChoice() async throws {
        let artifacts = try await analyzeReal1709(assistance: PhaseDetectionAssistance(contactTime: 8.001667))
        let report = EvidenceReplay.run(try EvidenceBundle.read(zip: try EvidenceBundle.build(artifacts: artifacts, context: context()).data))
        #expect(report.matchesRecording, "\(report.text)")
        #expect(report.replayed?.contactOutcome == ContactOutcome.userSelectedContact.rawValue)
    }

    // MARK: Privacy

    @Test func noVideoNoImagesAndNoIdentifiersByDefault() async throws {
        let artifacts = try await analyzeReal1709()
        let built = try EvidenceBundle.build(artifacts: artifacts, context: context())
        let names = try StoredZip.read(built.data).map(\.path)
        #expect(!names.contains { $0.hasPrefix("crops/") || $0.hasSuffix(".mov") || $0.hasSuffix(".jpg") || $0.hasSuffix(".png") })
        let p = built.manifest.privacy
        #expect(!p.includesVideo && !p.includesImageCrops && p.includesPoseCoordinates)
        #expect(p.notice.contains("body-position coordinates"))
        let manifestText = String(decoding: try #require(try StoredZip.read(built.data).first { $0.path == "manifest.json" }).data, as: UTF8.self)
        for word in ["identifierForVendor", "deviceName", "\"email\"", "userName", "@"] { #expect(!manifestText.contains(word)) }
        // Crops only when the user consented (the context carries them only then).
        let crop = EvidenceBundle.pgm(LumaImage(width: 2, height: 1, pixels: [0, 255]))
        let withCrops = try EvidenceBundle.build(artifacts: artifacts, context: context(crops: [("ball-7.935.pgm", crop)]))
        #expect(withCrops.manifest.privacy.includesImageCrops)
        #expect(try StoredZip.read(withCrops.data).contains { $0.path == "crops/ball-7.935.pgm" && $0.data.starts(with: Data("P5\n2 1\n255\n".utf8)) })
    }

    // MARK: Strict import

    @Test func storedZipRoundTripsAndChecksEverything() throws {
        let entries = [StoredZip.Entry(path: "a.txt", data: Data("hello".utf8)), StoredZip.Entry(path: "dir/b.bin", data: Data([0, 1, 2, 255]))]
        let zip = try StoredZip.write(entries)
        #expect(try StoredZip.read(zip) == entries)
        #expect(StoredZip.crc32(Data("123456789".utf8)) == 0xCBF4_3926, "standard CRC-32 check value")
        // A flipped data byte fails its checksum.
        var bad = zip
        bad[30 + 5] ^= 0xFF
        #expect(throws: StoredZip.ZipError.corrupt("checksum a.txt")) { try StoredZip.read(bad) }
        // Path traversal is refused on write and on read.
        #expect(throws: StoredZip.ZipError.unsafePath("../evil")) { try StoredZip.write([StoredZip.Entry(path: "../evil", data: Data())]) }
        var traversal = try StoredZip.write([StoredZip.Entry(path: "xx/evil", data: Data("x".utf8))])
        let name = Data("xx/evil".utf8), evil = Data("../evil".utf8)
        var i = 0
        while let r = traversal[i...].firstRange(of: name) { traversal.replaceSubrange(r, with: evil); i = r.upperBound }
        #expect(throws: StoredZip.ZipError.unsafePath("../evil")) { try StoredZip.read(traversal) }
        #expect(throws: StoredZip.ZipError.duplicate("a")) { try StoredZip.write([StoredZip.Entry(path: "a", data: Data()), StoredZip.Entry(path: "a", data: Data())]) }
        var tight = StoredZip.Limits()
        tight.maximumEntries = 1
        #expect(throws: StoredZip.ZipError.tooLarge("2 entries")) { try StoredZip.read(zip, limits: tight) }
        #expect(throws: StoredZip.ZipError.notAZip) { try StoredZip.read(Data("not a zip at all, definitely not".utf8)) }
    }

    @Test func malformedOrIncompatibleBundlesAreRejected() async throws {
        let artifacts = try await analyzeReal1709()
        let good = try EvidenceBundle.build(artifacts: artifacts, context: context()).data
        var files: [String: Data] = [:]
        for e in try StoredZip.read(good) { files[e.path] = e.data }
        #expect(throws: EvidenceBundleError.missingManifest) { try EvidenceBundle.read(files: files.filter { $0.key != "manifest.json" }) }
        var tampered = files
        tampered["analysis/phases.json"]?.append(0x20)
        #expect(throws: EvidenceBundleError.checksumMismatch("analysis/phases.json")) { try EvidenceBundle.read(files: tampered) }
        var future = files
        future["manifest.json"] = Data(String(decoding: files["manifest.json"]!, as: UTF8.self)
            .replacingOccurrences(of: "\"formatVersion\" : 1", with: "\"formatVersion\" : 2").utf8)
        #expect(throws: EvidenceBundleError.unsupportedVersion(2)) { try EvidenceBundle.read(files: future) }
        var foreign = files
        foreign["manifest.json"] = Data("{\"format\":\"something.else\",\"formatVersion\":1}".utf8)
        #expect(throws: EvidenceBundleError.wrongFormat("manifest.json is not a KickLab evidence manifest")) { try EvidenceBundle.read(files: foreign) }
        // Units: frame times must increase.
        var broken = artifacts
        broken.pose.sequence.frames.swapAt(10, 11)
        #expect(throws: EvidenceBundleError.invalidUnits("frame times must be finite, non-negative and increasing")) {
            try EvidenceBundle.validateUnits(broken)
        }
    }

    @Test func phaseFilesWithoutRawDetectionsStillDecode() async throws {
        let artifacts = try await analyzeReal1709()
        let data = try AnalysisArtifactCoder.encode(artifacts.phases)
        var json = try #require(try JSONSerialization.jsonObject(with: data) as? [String: Any])
        var football = try #require(json["football"] as? [String: Any])
        football.removeValue(forKey: "raw")
        json["football"] = football
        let old = try AnalysisArtifactCoder.decode(PhaseArtifact.self, from: JSONSerialization.data(withJSONObject: json))
        #expect(old.football?.raw == nil && old.football?.lastStationaryTime == artifacts.phases.football?.lastStationaryTime)
    }
}
