import Foundation
import Testing
@testable import KickLab

/// Pure path rules. Runs on any Swift toolchain.
@Suite("Managed paths")
struct ManagedPathTests {
    private let kick = UUID(uuidString: "AAAAAAAA-0000-0000-0000-000000000001")!
    private let video = UUID(uuidString: "BBBBBBBB-0000-0000-0000-000000000002")!

    @Test func rootsResolveUnderBase() {
        let locations = MediaLocations(baseURL: URL(fileURLWithPath: "/tmp/x/KickLab"))
        #expect(locations.mediaRootURL.path == "/tmp/x/KickLab/Media")
        #expect(locations.analysisRootURL.path == "/tmp/x/KickLab/Analysis")
        #expect(locations.rootURL(for: .media) == locations.mediaRootURL)
        #expect(locations.rootURL(for: .analysis) == locations.analysisRootURL)
    }

    @Test func builtPathsAreRelativeAndUUIDBased() throws {
        let original = ManagedPath.originalVideoPath(kickID: kick, videoID: video, fileExtension: "mov")
        #expect(original == "aaaaaaaa-0000-0000-0000-000000000001/bbbbbbbb-0000-0000-0000-000000000002/original.mov")
        #expect(ManagedPath.thumbnailPath(kickID: kick, videoID: video).hasSuffix("/thumbnail.jpg"))
        #expect(ManagedPath.analysisDirectory(analysisID: kick) == "aaaaaaaa-0000-0000-0000-000000000001")
        for path in [original, ManagedPath.thumbnailPath(kickID: kick, videoID: video)] {
            #expect(!path.hasPrefix("/"))
            #expect(ManagedPath.isValid(path))
        }
    }

    @Test(arguments: [
        "../outside.txt",
        "a/../../outside.txt",
        "/etc/passwd",
        "~/Library/x",
        "a//b",
        "a/./b",
        ".hidden",
        "a/.DS_Store",
        "a/b c.mov",
        "a/b;rm.mov",
        "a\\b.mov",
        "",
        "a/b/",
        "naïve.mov",
    ])
    func unsafePathsAreRejected(path: String) {
        #expect(!ManagedPath.isValid(path))
        #expect(throws: ManagedPathError.self) {
            _ = try ManagedPath.url(for: path, under: URL(fileURLWithPath: "/root/Media"))
        }
    }

    @Test func validPathResolvesInsideRoot() throws {
        let root = URL(fileURLWithPath: "/root/Media")
        let url = try ManagedPath.url(for: "k/v/original.mov", under: root)
        #expect(url.path == "/root/Media/k/v/original.mov")
    }

    @Test func ancestors() {
        #expect(ManagedPath.ancestors(of: "a/b/c.mov") == ["a/b", "a"])
        #expect(ManagedPath.ancestors(of: "c.mov") == [])
    }

    @Test(arguments: [
        ("clip.MOV", "mov"),
        ("clip.mp4", "mp4"),
        ("clip.M4V", "m4v"),
    ])
    func supportedExtensions(name: String, expected: String) {
        #expect(ManagedPath.videoFileExtension(for: URL(fileURLWithPath: "/tmp/\(name)")) == expected)
    }

    @Test(arguments: ["clip.avi", "clip.txt", "clip", "clip.mov.exe"])
    func unsupportedExtensions(name: String) {
        #expect(ManagedPath.videoFileExtension(for: URL(fileURLWithPath: "/tmp/\(name)")) == nil)
    }

    @Test func displayFilenameIsSanitized() {
        #expect(ManagedPath.displayFilename(from: URL(fileURLWithPath: "/tmp/Game Day (1).MOV")) == "Game Day (1).MOV")
        #expect(ManagedPath.displayFilename(fromName: "bad\u{0007}name\u{0000}.mov") == "badname.mov")
        #expect(ManagedPath.displayFilename(fromName: "../../etc/passwd") == "....etcpasswd")
        #expect(ManagedPath.displayFilename(fromName: "  \n ") == nil)
        #expect(ManagedPath.displayFilename(fromName: String(repeating: "a", count: 400) + ".mov")?.count == 255)
    }

    @Test(arguments: [
        // (current, hasPath, exists, hasPhotos, expected)
        (VideoStorageStatus.missing, true, true, false, VideoStorageStatus.local),
        (.local, true, false, false, .missing),
        (.local, true, false, true, .photosLibrary),
        (.local, false, false, true, .photosLibrary),
        (.offloaded, true, false, true, .offloaded),
        (.offloaded, true, true, false, .local),
        (.local, false, false, false, .missing),
    ])
    func storageStatusResolution(current: VideoStorageStatus, hasPath: Bool, exists: Bool, hasPhotos: Bool, expected: VideoStorageStatus) {
        #expect(VideoStorageStatusResolver.resolve(
            current: current,
            hasManagedPath: hasPath,
            managedFileExists: exists,
            hasPhotosIdentifier: hasPhotos
        ) == expected)
    }

    @Test func metadataRejectsUnreliableValues() {
        let metadata = VideoMediaMetadata(durationSeconds: .nan, frameRate: -30, pixelWidth: 0, pixelHeight: 1080, hasAudio: true)
        #expect(metadata.durationSeconds == nil)
        #expect(metadata.frameRate == nil)
        #expect(metadata.pixelWidth == nil)
        #expect(metadata.pixelHeight == 1080)
    }

    @Test func cleanupRequestKeepsAreasSeparate() {
        let request = MediaCleanupRequest(mediaRelativePaths: ["k/v.mov", "k/v.mov"], analysisRelativePaths: ["a1"])
        #expect(request.mediaRelativePaths == ["k/v.mov"])
        #expect(request.analysisRelativePaths == ["a1"])
        #expect(request.relativePaths == ["a1", "k/v.mov"])
        #expect(MediaCleanupRequest(relativePaths: ["x"]).analysisRelativePaths.isEmpty)
    }
}
