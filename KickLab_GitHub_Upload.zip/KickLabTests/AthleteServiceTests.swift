import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Requires Xcode: runs against Apple's SwiftData.
@MainActor
@Suite("AthleteService")
struct AthleteServiceTests {
    let f: ServiceFixture

    init() throws {
        f = try ServiceFixture()
    }

    // MARK: First launch

    @Test func ensureAtLeastOneAthleteDoesNotCreateDuplicates() throws {
        let first = try f.athletes.ensureAtLeastOneAthlete()
        let second = try f.athletes.ensureAtLeastOneAthlete()
        #expect(first.id == second.id)
        #expect(try f.count(Athlete.self) == 1)
        #expect(first.firstName == AthleteProfile.firstLaunchDefault.firstName)
    }

    @Test func ensureAtLeastOneAthleteCreatesWhenOnlyArchivedExist() throws {
        let archived = try f.makeAthlete("Old")
        try f.athletes.archive(archived)
        let active = try f.athletes.ensureAtLeastOneAthlete()
        #expect(active.id != archived.id)
        #expect(try f.count(Athlete.self) == 2)
    }

    // MARK: Profile

    @Test func updateProfileValidatesAndTouchesUpdatedAt() throws {
        let athlete = try f.makeAthlete()
        athlete.updatedAt = .distantPast
        var profile = f.athletes.profile(of: athlete)
        profile.jerseyNumber = " 07 "
        try f.athletes.updateProfile(athlete, with: profile)
        #expect(athlete.jerseyNumber == "07")
        #expect(athlete.updatedAt > .distantPast)

        profile.firstName = ""
        profile.lastName = ""
        #expect(throws: AthleteServiceError.invalidProfile([.missingName])) {
            try f.athletes.updateProfile(athlete, with: profile)
        }
        #expect(athlete.firstName == "Test")
    }

    // MARK: Archive / restore

    @Test func archivePreservesHistoryAndRestoreWorks() throws {
        let athlete = try f.makeAthlete()
        let session = try f.makeSession(for: athlete)
        try f.makeKick(for: athlete, in: session)

        try f.athletes.archive(athlete)
        #expect(athlete.isArchived)
        #expect(try f.count(KickingSession.self) == 1)
        #expect(try f.count(Kick.self) == 1)

        try f.athletes.restore(athlete)
        #expect(!athlete.isArchived)
        #expect(try f.count(Kick.self) == 1)
    }

    // MARK: Deletion plan

    /// Two sessions, three kicks (one unassigned), two videos (100 + 250 bytes), one analysis.
    private func buildHistory(for athlete: Athlete, prefix: String) throws {
        let s1 = try f.makeSession(for: athlete, name: "\(prefix)-1")
        let s2 = try f.makeSession(for: athlete, name: "\(prefix)-2")
        let k1 = try f.makeKick(for: athlete, in: s1)
        let k2 = try f.makeKick(for: athlete, in: s2)
        try f.makeKick(for: athlete)
        let v1 = try f.addVideo(to: k1, path: "\(prefix)/k1.mov", bytes: 100)
        try f.addVideo(to: k2, path: "\(prefix)/k2.mov", bytes: 250)
        _ = try f.makeCompletedAnalysis(for: k1, video: v1, completedAt: .now)
    }

    @Test func deletionPlanCountsAllRelatedRecords() throws {
        let athlete = try f.makeAthlete("Sam")
        try buildHistory(for: athlete, prefix: "sam")

        let plan = try f.athletes.deletionPlan(for: athlete)
        #expect(plan.athleteID == athlete.id)
        #expect(plan.athleteDisplayName == "Sam Kicker")
        #expect(plan.sessionCount == 2)
        #expect(plan.kickCount == 3)
        #expect(plan.videoCount == 2)
        #expect(plan.analysisCount == 1)
        #expect(plan.estimatedMediaBytes == 350)
    }

    @Test func staleDeletionPlanIsRejected() throws {
        let athlete = try f.makeAthlete("Sam")
        try buildHistory(for: athlete, prefix: "sam")
        let plan = try f.athletes.deletionPlan(for: athlete)

        try f.makeKick(for: athlete)   // history changes after the plan was shown

        #expect(throws: AthleteServiceError.stalePlan(athleteID: athlete.id)) {
            try f.athletes.permanentlyDelete(using: plan, confirmation: AthleteDeletionConfirmation(typedText: plan.confirmationPhrase))
        }
        #expect(try f.count(Athlete.self) == 1)
        #expect(try f.count(Kick.self) == 4)
    }

    @Test func wrongConfirmationIsRejected() throws {
        let athlete = try f.makeAthlete("Sam")
        let plan = try f.athletes.deletionPlan(for: athlete)
        #expect(throws: AthleteServiceError.confirmationMismatch) {
            try f.athletes.permanentlyDelete(using: plan, confirmation: AthleteDeletionConfirmation(typedText: "yes"))
        }
        #expect(try f.count(Athlete.self) == 1)
    }

    @Test func permanentDeletionRemovesOnlyTheSelectedAthletesHistory() throws {
        let sam = try f.makeAthlete("Sam")
        let alex = try f.makeAthlete("Alex")
        try buildHistory(for: sam, prefix: "sam")
        try buildHistory(for: alex, prefix: "alex")

        let context = f.context
        f.media.probe = { (try? context.fetchCount(FetchDescriptor<Athlete>())) ?? -1 }
        let plan = try f.athletes.deletionPlan(for: sam)
        let result = try f.athletes.permanentlyDelete(using: plan, confirmation: AthleteDeletionConfirmation(typedText: "Sam Kicker"))

        // Sam's history is gone.
        #expect(result.deletedKickCount == 3)
        #expect(try f.count(Athlete.self) == 1)
        #expect(try f.count(KickingSession.self) == 2)
        #expect(try f.count(Kick.self) == 3)
        #expect(try f.count(VideoAsset.self) == 2)
        #expect(try f.count(BiomechanicsAnalysis.self) == 1)

        // Alex is untouched.
        #expect(alex.kickingSessions?.count == 2)
        #expect(alex.kicks?.count == 3)
        for kick in alex.kicks ?? [] {
            #expect(f.kicks.audit(kick).isEmpty)
        }

        // Media for Sam only, after the save.
        let call = try #require(f.media.calls.first)
        #expect(call.request.relativePaths == ["sam/k1.mov", "sam/k2.mov"])
        #expect(call.probeValue == 1)
        #expect(call.contextHadUnsavedChanges == false)
    }

    // MARK: History reassignment

    @Test func reassignHistoryMovesSessionsAndKicksAndUpdatesAthleteID() throws {
        let source = try f.makeAthlete("Source")
        let destination = try f.makeAthlete("Destination")
        let session = try f.makeSession(for: source)
        let inSession = try f.makeKick(for: source, in: session, draft: .kickoff())
        let unassigned = try f.makeKick(for: source)
        let video = try f.addVideo(to: inSession, path: "x.mov")
        _ = try f.makeCompletedAnalysis(for: inSession, video: video, completedAt: .now)
        let outcomeBefore = inSession.outcomeColumns

        try f.athletes.reassignHistory(from: source, to: destination)

        #expect(session.athlete?.id == destination.id)
        for kick in [inSession, unassigned] {
            #expect(kick.athlete?.id == destination.id)
            #expect(kick.athleteID == destination.id)
            #expect(f.kicks.audit(kick).isEmpty)
        }
        #expect((source.kicks ?? []).isEmpty)
        #expect((source.kickingSessions ?? []).isEmpty)
        #expect(inSession.outcomeColumns == outcomeBefore)
        #expect(inSession.videos?.count == 1)
        #expect(inSession.analyses?.count == 1)
    }

    @Test func reassignHistoryRejectsSameSourceAndDestination() throws {
        let athlete = try f.makeAthlete()
        #expect(throws: AthleteServiceError.sameSourceAndDestination) {
            try f.athletes.reassignHistory(from: athlete, to: athlete)
        }
    }

    @Test func reassignHistoryRejectsSessionsHoldingAnotherAthletesKicks() throws {
        let source = try f.makeAthlete("Source")
        let third = try f.makeAthlete("Third")
        let destination = try f.makeAthlete("Destination")
        let session = try f.makeSession(for: source)
        let foreign = try f.makeKick(for: third)
        foreign.session = session   // simulated corruption
        try f.context.save()

        #expect(throws: AthleteServiceError.inconsistentHistory(kickIDs: [foreign.id])) {
            try f.athletes.reassignHistory(from: source, to: destination)
        }
        #expect(session.athlete?.id == source.id)
    }
}
