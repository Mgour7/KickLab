import Foundation
import Testing
@testable import KickLab

/// Build 15: the debugger's evidence timeline and the automatic-vs-verified comparison.
/// Real IMG_1709 pose (MediaPipe) and real detections; verification marks are test input.
@Suite("Evidence timeline and verification comparison (build 15)")
struct EvidenceTimelineTests {
    typealias Clip = RealVideoClip1709
    typealias Real = RealVideo1709Football

    private func analysis() -> (out: KickAnalysisPipelineOutput, track: FootballTrack) {
        let first = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .rear))
        let context = FootballAnalysisContext.make(from: first, kickingFoot: .right)
        let raw = FootballRawEvidence(scanTimes: Real.scanTimes, broadScan: Real.broadScan, precisionTimes: Real.precisionTimes,
                                      precision: Real.precisionFrames.flatMap(\.detections), appearanceTimes: [], appearanceScores: [],
                                      cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [], camera: nil,
                                      strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                      ankle: context.ankle, aspect: Clip.displayAspectRatio, duration: Clip.durationSeconds)
        let track = FootballTrackAnalyzer.analyze(raw: raw, detector: .yoloxS)
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                                    cameraAngle: .rear, football: track))
        return (out, track)
    }

    @Test func theTimelineShowsEveryDecisionLayer() throws {
        let (out, track) = analysis()
        let m = EvidenceTimelineModel.make(signals: out.signals, phases: out.phases, football: track)
        #expect(m.ballCells.count == track.observations.count)
        #expect(m.ballCells.contains { $0.state == .notSeen && abs($0.time - 7.935) < 1e-3 }, "the hidden frame stays empty")
        let ball = try #require(m.bands.first { $0.kind == .ballContact })
        #expect(abs(ball.start - 7.902) < 1e-3 && abs(ball.end - 7.968) < 1e-3)
        #expect(m.bands.contains { $0.kind == .poseStrike } && m.bands.contains { $0.kind == .kickWindow } && m.bands.contains { $0.kind == .contactShown })
        #expect(m.marks.contains { $0.kind == .ballFirstMovement } && m.marks.contains { $0.kind == .plantAccepted })
        // Build 16: the verdict also names the acceptance rule and how the ball's departure was seen.
        #expect(m.fusionVerdict == "Ball evidence ACCEPTED via poseStrikeAgreement · departure: ball seen leaving")
        #expect(m.ankleSpeed != nil && m.kneeAngle != nil)
        // Phone zoom: a 0.5 s window centered on the playhead, clamped to the clip.
        #expect(m.visibleRange(around: 7.95, span: 0.5) == 7.7...8.2)
        #expect(m.visibleRange(around: 0.1, span: 2).lowerBound == 0)
        #expect(m.visibleRange(around: 5, span: nil) == 0...m.duration)
    }

    @Test func aRejectedFusionSaysWhyOnTheTimeline() {
        var phases = analysis().out.phases
        phases.evidence?.ballFusion?.accepted = false
        phases.evidence?.ballFusion?.rejectionReason = "test reason"
        #expect(EvidenceTimelineModel.make(signals: nil, phases: phases, football: nil).fusionVerdict == "Ball evidence REJECTED — test reason")
    }

    @Test func verifiedMarksAreComparedNotMerged() throws {
        let (out, track) = analysis()
        var v = VideoVerification(plant: .frame(time: out.phases.plantTime! - 1.0 / 30), firstBallMovement: .frame(time: 7.968333))
        v.kickedBall = VideoVerification.KickedBallChoice(x: 614.0 / 1080, y: 1118.0 / 1920, size: 0.025, detectedBallNumber: 2)
        let rows = VerificationComparison.rows(phases: out.phases, football: track, verification: v, annotation: .contact(time: 7.968333), frame: 1.0 / 30)
        let byTitle = Dictionary(uniqueKeysWithValues: rows.map { ($0.title, $0) })
        #expect(byTitle["Contact"]?.verdict == "inside the automatic interval")
        #expect(byTitle["Plant"]?.verdict == "1 frame later (automatic vs yours)")
        #expect(byTitle["First ball movement"]?.verdict == "same frame (automatic vs yours)")
        #expect(byTitle["Kicked football"]?.verdict == "same ball")
        // A range that misses the automatic interval, and a different ball.
        v.contactRange = VideoVerification.RangeMark(start: 8.1, end: 8.2)
        v.kickedBall = VideoVerification.KickedBallChoice(x: 0.2, y: 0.55, size: 0.02, detectedBallNumber: 1)
        let again = Dictionary(uniqueKeysWithValues: VerificationComparison.rows(phases: out.phases, football: track, verification: v,
                                                                                annotation: .none, frame: 1.0 / 30).map { ($0.title, $0) })
        #expect(again["Contact"]?.verdict == "your range doesn't overlap the automatic interval")
        #expect(again["Kicked football"]?.verdict == "DIFFERENT ball")
    }

    @Test func olderVerificationRecordsStillDecode() throws {
        let old = Data(#"{"formatVersion":1,"plant":{"frame":{"time":7.8}}}"#.utf8)
        let v = try #require(VideoVerification.decode(old))
        #expect(v.contactRange == nil && v.kickedBall == nil)
        #expect(v.plant == .frame(time: 7.8))
        var n = v
        n.contactRange = VideoVerification.RangeMark(start: 7.9, end: 7.97)
        #expect(VideoVerification.decode(try n.encoded()) == n)
        #expect(!n.isEmpty)
        // Range and ball choice are human input only: they never become assistance by themselves.
        #expect(VideoVerification(contactRange: n.contactRange).assistance(contactTime: nil) == nil)
    }
}
