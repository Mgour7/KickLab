import Foundation
import Testing
@testable import KickLab

@Suite("Step 9 personalization, dashboard, entry and flow logic")
struct PresentationLogicTests {
    // MARK: Personal insights

    private static let day: TimeInterval = 86_400
    private static let start = Date(timeIntervalSince1970: 1_800_000_000)

    private func entry(_ i: Int, drift: Double, made: Bool = true, score: Double = 80, confidence: Double = 0.75,
                       type: KickType = .fieldGoal) -> KickHistoryEntry {
        let snapshot = MetricSnapshot(
            kickType: type, recordedAt: Self.start.addingTimeInterval(Double(i) * Self.day),
            values: [.plantFootDrift: .init(value: drift, confidence: 0.8, status: .estimated, definitionVersion: 1),
                     .plantToContactTime: .init(value: 0.2, confidence: 0.8, status: .estimated, definitionVersion: 1)]
        )
        return KickHistoryEntry(kickID: UUID(), analysisID: UUID(), date: snapshot.recordedAt, kickType: type,
                                result: made ? .made : .missedLeft, touchback: nil, overallScore: score,
                                overallConfidence: confidence, snapshot: snapshot)
    }

    private var now: Date { Self.start.addingTimeInterval(30 * Self.day) }

    @Test func noPersonalConclusionsFromOneOrTwoKicks() {
        let provider = RuleBasedPersonalInsights()
        let insights = provider.insights(history: [entry(0, drift: 0.2), entry(1, drift: 0.3)], kickType: .fieldGoal, now: now)
        #expect(insights.baseline == nil)
        #expect(insights.baselineAvailability == .needsMoreKicks(have: 2, need: 3))
        #expect(insights.bestKicks.isEmpty)
        #expect(insights.bestKicksAvailability == .needsMoreKicks(have: 2, need: 3))
        #expect(insights.recentTrends.isEmpty)
        #expect(insights.trendAvailability == .needsMoreKicks(have: 2, need: 4))
        #expect(PersonalInsights.baselineNeededMessage == "More kicks are needed before KickLab can build your personal baseline.")
        #expect(insights.methodDescription.contains("does not use machine learning"))

        let reference = MetricReferencePresentation.make(key: .plantFootDrift, currentValue: 0.25,
                                                         profile: .standard(for: .fieldGoal), insights: insights)
        #expect(reference.baseline == nil)
        #expect(reference.baselineMessage == PersonalInsights.baselineNeededMessage)
        #expect(reference.generalTarget == "0.10 torso lengths or less")
    }

    @Test func baselineBestKicksAndTrendWithEnoughHistory() {
        let history = [
            entry(0, drift: 0.40, made: false, score: 60),
            entry(1, drift: 0.30, score: 70),
            entry(2, drift: 0.20, score: 85),
            entry(3, drift: 0.10, score: 90, confidence: 0.4),   // too uncertain to be a "best kick"
            entry(4, drift: 0.15, score: 75),
            entry(5, drift: 0.12, made: false, score: 95),
        ]
        let insights = RuleBasedPersonalInsights().insights(history: history, kickType: .fieldGoal, now: now)
        #expect(insights.baselineAvailability == .available)
        #expect(insights.baseline?.statistics[.plantFootDrift]?.count == 6)
        // Successful kicks first, then score; low-confidence kicks are excluded.
        #expect(insights.bestKicks.map(\.overallScore) == [85, 75, 70, 95, 60])
        #expect(insights.successfulKickAvailability == .available)
        #expect(insights.successfulKickBaseline?.statistics[.plantFootDrift]?.count == 4)
        #expect(insights.trendAvailability == .available)
        let slope = insights.recentTrends[.plantFootDrift] ?? 0
        #expect(slope < 0, "drift is falling")

        let reference = MetricReferencePresentation.make(key: .plantFootDrift, currentValue: 0.12,
                                                         profile: .standard(for: .fieldGoal), insights: insights)
        #expect(reference.baseline?.hasSuffix("average over 6 kicks") == true)
        #expect(reference.bestKicks?.hasSuffix("typical on your successful kicks") == true)
        #expect(reference.trend == "Improving recently", "lower drift is better")
        #expect(reference.baselineMessage == nil)
    }

    @Test func otherKickTypesDontCount() {
        let history = (0..<5).map { entry($0, drift: 0.2, type: .kickoff) }
        let insights = RuleBasedPersonalInsights().insights(history: history, kickType: .fieldGoal, now: now)
        #expect(insights.analyzedKickCount == 0)
        #expect(insights.baseline == nil)
    }

    @Test func providerIsReplaceable() {
        struct Fixed: PersonalInsightsProviding {
            func insights(history: [KickHistoryEntry], kickType: KickType, now: Date) -> PersonalInsights {
                PersonalInsights(kickType: kickType, analyzedKickCount: 99, baseline: nil,
                                 baselineAvailability: .needsMoreKicks(have: 0, need: 1), bestKicks: [],
                                 bestKicksAvailability: .needsMoreKicks(have: 0, need: 1), successfulKickBaseline: nil,
                                 successfulKickAvailability: .needsMoreKicks(have: 0, need: 1), recentTrends: [:],
                                 trendAvailability: .needsMoreKicks(have: 0, need: 1), methodDescription: "Learned model v0")
            }
        }
        let provider: any PersonalInsightsProviding = Fixed()
        #expect(provider.insights(history: [], kickType: .pat, now: now).methodDescription == "Learned model v0")
    }

    @Test func comparisonRowsUseExistingDeltas() {
        let current = MetricSnapshot(kickType: .fieldGoal, recordedAt: now,
                                     values: [.plantFootDrift: .init(value: 0.2, confidence: 0.8, status: .estimated, definitionVersion: 1)])
        let reference = MetricSnapshot(kickType: .fieldGoal, recordedAt: Self.start,
                                       values: [.plantFootDrift: .init(value: 0.4, confidence: 0.8, status: .estimated, definitionVersion: 1)])
        let p = ComparisonPresentation.make(deltas: MetricComparison.compare(current, to: reference), target: .previousAnalysis)
        #expect(p.rows.count == 1)
        #expect(p.rows[0].name == "Plant-foot movement")
        #expect(p.rows[0].directionText == "Better")
        #expect(p.rows[0].differenceText == "-0.20 torso lengths")
        #expect(p.emptyMessage == nil)
        #expect(ComparisonPresentation.make(deltas: [], target: .baseline).emptyMessage != nil)
        #expect(ComparisonPresentation.unavailable(.baseline, message: "m").rows.isEmpty)
    }

    // MARK: Dashboard

    private let athlete = AthleteSummary(id: UUID(), name: "Alex Kicker", kickingFoot: .left, playingLevel: .highSchool, kickCount: 0)

    @Test func emptyDashboardExplainsNextSteps() {
        let d = DashboardPresentation.make(athlete: athlete, totalKicks: 0, recentFieldGoals: nil, recentKickoffs: nil,
                                           recentKicks: [], latestAnalysis: nil, trend: nil)
        #expect(d.isEmpty)
        #expect(d.athleteName == "Alex Kicker")
        #expect(d.kickingFootText == "Left-footed")
        #expect(d.emptyMessage == DashboardPresentation.noKicksMessage)
        #expect(d.analysisEmptyMessage == DashboardPresentation.noAnalysisMessage)
        #expect(d.trendEmptyMessage == DashboardPresentation.noTrendMessage)
        #expect(d.latestScoreText == nil)
        #expect(d.stats.map(\.title) == ["Total kicks"])
    }

    @Test func dashboardAggregatesStatisticsAndLatestAnalysis() {
        let records = [
            KickStatRecord(kickID: UUID(), athleteID: athlete.id, timestamp: now, kickType: .fieldGoal, result: .made, distanceYards: 40),
            KickStatRecord(kickID: UUID(), athleteID: athlete.id, timestamp: now, kickType: .fieldGoal, result: .missedLeft, distanceYards: 45),
            KickStatRecord(kickID: UUID(), athleteID: athlete.id, timestamp: now, kickType: .kickoff,
                           distanceYards: 62, touchback: true, hangTimeSeconds: 3.9),
        ]
        let calc = KickStatisticsCalculator.self
        let fg = calc.fieldGoal(records.filter { $0.kickType == .fieldGoal }, kickType: .fieldGoal, measurementSource: .all)
        let ko = calc.kickoff(records.filter { $0.kickType == .kickoff }, measurementSource: .all)
        let priority = CoachingItemPresentation(id: UUID(), category: .plant, categoryTitle: "Plant", observed: "Plant late.",
                                                whyItMatters: nil, cue: "Plant earlier.", severity: .moderate,
                                                severityText: "Medium priority", confidence: 0.7, confidenceText: "", priority: 0)
        let latest = LatestAnalysisSummary(analysisID: UUID(), kickID: nil, kickType: .fieldGoal, date: now,
                                           overallScore: 78, confidence: 0.76, topPriority: priority)
        let d = DashboardPresentation.make(athlete: athlete, totalKicks: 3, recentFieldGoals: fg, recentKickoffs: ko,
                                           recentKicks: records, latestAnalysis: latest, trend: nil)
        #expect(!d.isEmpty)
        let fgStat = d.stats.first { $0.title == "Field goals (30 days)" }
        #expect(fgStat?.value == "50%")
        #expect(fgStat?.detail == "1 of 2 made")
        #expect(d.stats.contains { $0.title == "Touchbacks (30 days)" && $0.value == "100%" })
        #expect(d.stats.contains { $0.title == "Kickoff distance" && $0.value == "62 yd" })
        #expect(d.latestScoreText == "78")
        #expect(d.latestScoreGrade == .good)
        #expect(d.topPriority?.cue == "Plant earlier.")
        #expect(d.recentActivity.count == 3)
        #expect(d.recentActivity[0].detail == "Made · 40 yd · Training")
        #expect(d.recentActivity[2].detail == "Touchback · 62 yd · 3.90 s hang · Training")
    }

    @Test func trendNeedsBothPeriods() {
        let item = DashboardPresentation.trendItem("Field goal %", MetricTrend(current: 80, previous: 60, currentSampleCount: 5, previousSampleCount: 5),
                                                   format: DisplayFormat.percentage, higherIsBetter: true)
        #expect(item?.directionText == "Improving")
        #expect(item?.change == "+20%")
        let flat = DashboardPresentation.trendItem("x", MetricTrend(current: 60.5, previous: 60, currentSampleCount: 5, previousSampleCount: 5),
                                                   format: DisplayFormat.percentage, higherIsBetter: true)
        #expect(flat?.directionText == "About the same")
        #expect(DashboardPresentation.trendItem("x", MetricTrend(current: 80, previous: nil, currentSampleCount: 5, previousSampleCount: 0),
                                                format: DisplayFormat.percentage, higherIsBetter: true) == nil)
    }

    // MARK: Athlete switching

    @Test func athleteSelectionKeepsOrFallsBack() {
        let a = AthleteSummary(id: UUID(), name: "Zed", kickingFoot: .right, playingLevel: .college, kickCount: 0)
        let b = AthleteSummary(id: UUID(), name: "amy", kickingFoot: .left, playingLevel: .youth, kickCount: 0)
        #expect(AthleteSelection.resolve(selected: a.id, available: [a, b]) == a.id, "a valid selection is kept")
        #expect(AthleteSelection.resolve(selected: UUID(), available: [a, b]) == b.id, "deleted selection → first by name")
        #expect(AthleteSelection.resolve(selected: nil, available: [a, b]) == b.id)
        #expect(AthleteSelection.resolve(selected: a.id, available: []) == nil)
    }
}

@Suite("Step 9 manual kick entry")
struct KickEntryFormTests {
    let when = Date(timeIntervalSince1970: 1_800_000_000)

    @Test func fieldGoalDefaultsMakeAValidDraft() throws {
        var form = KickEntryForm(timestamp: when)
        form.distanceText = "42"
        let built = form.makeDraft()
        let draft = try #require(built.draft)
        #expect(built.issues.isEmpty)
        #expect(draft.kickType == .fieldGoal)
        #expect(draft.hashLocation == .center)
        #expect(draft.context == nil, "session default resolved by KickService")
        #expect(draft.timestamp == when)
        guard case .fieldGoal(let fg) = draft.outcome else { Issue.record("wrong outcome"); return }
        #expect(fg.result == .made)
        #expect(fg.distance == .manual(42))
        #expect(fg.distance?.confidence == nil, "manual entries carry no confidence")
    }

    @Test func numbersAcceptCommaAndRejectText() {
        #expect(KickEntryForm.parse(" 3,85 ").value == 3.85)
        #expect(KickEntryForm.parse("").value == nil)
        #expect(KickEntryForm.parse("").valid)
        #expect(!KickEntryForm.parse("forty").valid)
        var form = KickEntryForm(timestamp: when)
        form.distanceText = "forty"
        #expect(form.makeDraft().issues == [.invalidNumber(.distance)])
        #expect(form.makeDraft().issues.first?.message == "Distance must be a number.")
    }

    @Test func validatorRulesAreSurfacedInPlainWords() {
        var form = KickEntryForm(kickType: .kickoff, timestamp: when)
        form.touchback = true
        form.outOfBounds = true
        #expect(form.makeDraft().issues == [.validation(.touchbackAndOutOfBounds)])

        var wide = KickEntryForm(timestamp: when)
        wide.result = .made
        wide.accuracy = AccuracyCoordinate(x: -1.6, y: 0.5)
        let issues = wide.makeDraft().issues
        #expect(issues.count == 1)
        #expect(issues.first?.message.contains("contradicts") == true)

        var outOfRange = KickEntryForm(timestamp: when)
        outOfRange.distanceText = "150"
        #expect(outOfRange.makeDraft().draft == nil)
    }

    @Test func kickTypeSwitchClearsFieldsThatDontApply() {
        var form = KickEntryForm(timestamp: when)
        form.accuracy = AccuracyCoordinate(x: 0.2)
        form.setKickType(.kickoff)
        #expect(form.accuracy == nil)
        #expect(form.hash == .notApplicable)
        #expect(form.showsKickoffFields && form.showsHangTime && !form.showsResult)
        form.touchback = true
        form.landingZone = .middle
        form.setKickType(.punt)
        #expect(!form.touchback)
        #expect(form.landingZone == nil)
        #expect(form.showsHangTime)
        form.setKickType(.pat)
        #expect(form.hash == .center)
        #expect(!form.showsHangTime)
    }

    @Test func eachKickTypeBuildsItsOutcome() throws {
        var ko = KickEntryForm(kickType: .kickoff, timestamp: when)
        ko.distanceText = "63"
        ko.hangTimeText = "4.1"
        ko.touchback = true
        ko.landingZone = .middle
        guard case .kickoff(let k)? = ko.makeDraft().draft?.outcome else { Issue.record("kickoff"); return }
        #expect(k.distance == .manual(63))
        #expect(k.hangTime == .manual(4.1))
        #expect(k.touchback == true)
        #expect(k.outOfBounds == false)
        #expect(k.landing?.value.zone == .middle)

        var punt = KickEntryForm(kickType: .punt, timestamp: when)
        punt.distanceText = "41"
        punt.hangTimeText = "4.4"
        guard case .punt(let p)? = punt.makeDraft().draft?.outcome else { Issue.record("punt"); return }
        #expect(p.distance == .manual(41))
        #expect(p.hangTime == .manual(4.4))
        #expect(punt.makeDraft().draft?.hashLocation == .notApplicable)

        var pat = KickEntryForm(kickType: .pat, timestamp: when)
        pat.result = .blocked
        pat.notes = "  low snap  "
        let draft = try #require(pat.makeDraft().draft)
        #expect(draft.kickType == .pat)
        #expect(draft.notes == "low snap")
    }

    @Test func saveAndAddAnotherKeepsTheRepSetup() {
        var form = KickEntryForm(timestamp: when)
        form.distanceText = "35"
        form.hash = .left
        form.context = .camp
        form.result = .missedRight
        form.accuracy = AccuracyCoordinate(x: 1.3)
        form.notes = "wind"
        form.prepareNextKick(at: when.addingTimeInterval(60))
        #expect(form.distanceText == "35")
        #expect(form.hash == .left)
        #expect(form.context == .camp)
        #expect(form.kickType == .fieldGoal)
        #expect(form.result == .made)
        #expect(form.accuracy == nil)
        #expect(form.notes.isEmpty)
        #expect(form.timestamp == when.addingTimeInterval(60))
    }

    @Test func editingRoundTripsAStoredOutcome() {
        let outcome = KickOutcome.kickoff(KickoffOutcome(distance: .manual(60.5), landing: .manual(KickoffLanding(yardLine: 3, zone: .left)),
                                                         touchback: false, outOfBounds: false, hangTime: .manual(3.9)))
        let form = KickEntryForm.editing(outcome: outcome, context: .game, hash: .notApplicable, notes: nil, timestamp: when)
        #expect(form.kickType == .kickoff)
        #expect(form.distanceText == "60.50")
        #expect(form.landingYardLineText == "3")
        #expect(form.hangTimeText == "3.90")
        #expect(form.context == .game)
        #expect(form.makeDraft().draft?.outcome == outcome)
    }
}

@Suite("Step 9 analysis flow")
struct AnalysisFlowTests {
    @Test func successfulRun() {
        var s = AnalysisFlowState.idle
        s = AnalysisFlowMachine.reduce(s, .start)
        #expect(s == .running(stage: .preparing, fraction: 0))
        #expect(s.isBusy && !s.canStart)
        s = AnalysisFlowMachine.reduce(s, .progress(VideoAnalysisProgress(stage: .detectingPose, fractionCompleted: 0.5)))
        #expect(s == .running(stage: .detectingPose, fraction: 0.5))
        #expect(s.stageText == "Detecting body position")
        // Progress never goes backwards.
        s = AnalysisFlowMachine.reduce(s, .progress(VideoAnalysisProgress(stage: .detectingEvents, fractionCompleted: 0.3)))
        #expect(s == .running(stage: .detectingEvents, fraction: 0.5))
        let id = UUID()
        s = AnalysisFlowMachine.reduce(s, .completed(analysisID: id))
        #expect(s == .completed(analysisID: id))
        // Late progress is ignored.
        #expect(AnalysisFlowMachine.reduce(s, .progress(VideoAnalysisProgress(stage: .finishing, fractionCompleted: 1))) == s)
    }

    @Test func cancelAndRetry() {
        var s = AnalysisFlowMachine.reduce(.idle, .start)
        #expect(AnalysisFlowMachine.reduce(s, .start) == s, "can't start twice")
        #expect(AnalysisFlowMachine.reduce(s, .reset) == s, "can't reset while running")
        s = AnalysisFlowMachine.reduce(s, .cancelRequested)
        #expect(s == .cancelling)
        s = AnalysisFlowMachine.reduce(s, .cancelled)
        #expect(s == .cancelled)
        #expect(AnalysisFlowMachine.reduce(s, .reset) == .idle)
        #expect(AnalysisFlowMachine.reduce(s, .start) == .running(stage: .preparing, fraction: 0), "retry")
    }

    @Test func failuresBecomeUserFacingProblems() {
        var s = AnalysisFlowMachine.reduce(.idle, .start)
        s = AnalysisFlowMachine.reduce(s, .failed(.ambiguousKicker))
        #expect(s == .failed(.ambiguousKicker))

        #expect(AnalysisProblem.from(kickerStatus: .ambiguous, failureReason: "x") == .ambiguousKicker)
        #expect(AnalysisProblem.from(kickerStatus: .noCandidates, failureReason: "x") == .noKickerFound)
        #expect(AnalysisProblem.from(kickerStatus: .seedNotMatched, failureReason: "x") == .kickerTapMissed)
        #expect(AnalysisProblem.from(kickerStatus: .selected, failureReason: AnalysisFailureReasons.insufficientData) == .notEnoughPoseData)
        #expect(AnalysisProblem.from(kickerStatus: nil, failureReason: "The analysis failed: x") == .failed)
        // Engine errors the runner stored as text are recognized again.
        let simulatorReason = VideoAnalysisError.poseDetectionUnavailable(environment: .simulator).errorDescription ?? ""
        #expect(AnalysisProblem.from(kickerStatus: nil, failureReason: simulatorReason) == .poseDetectionUnavailable(.simulator))
        #expect(AnalysisProblem.from(kickerStatus: nil, failureReason: "There's no usable video to analyze.") == .videoMissing)
        #expect(AnalysisProblem.from(engineError: .poseDetectionUnavailable(environment: .simulator)) == .poseDetectionUnavailable(.simulator))
        #expect(AnalysisProblem.from(engineError: .noUsableInputs) == .videoMissing)
        #expect(AnalysisProblem.from(engineError: .unavailable(reason: "r")) == .engineUnavailable)

        #expect(AnalysisProblem.ambiguousKicker.suggestsKickerSelection)
        #expect(AnalysisProblem.ambiguousKicker.canRetry)
        #expect(!AnalysisProblem.videoMissing.canRetry)
        #expect(!AnalysisProblem.poseDetectionUnavailable(.simulator).canRetry)
        #expect(AnalysisProblem.notEnoughPoseData.message.contains("side view"))
        for problem in [AnalysisProblem.noVideo, .videoMissing, .noKickerFound, .ambiguousKicker, .kickerTapMissed,
                        .notEnoughPoseData, .poseDetectionUnavailable(.device), .engineUnavailable, .failed] {
            #expect(!problem.title.isEmpty)
            #expect(!problem.message.contains("Error"), "no raw error text")
        }
    }
}

@Suite("Step 9 statistics presentation")
struct StatisticsPresentationTests {
    let now = Date(timeIntervalSince1970: 1_800_000_000)

    @Test func emptyPeriodsSaySo() {
        let fg = KickStatisticsCalculator.fieldGoal([], kickType: .fieldGoal, measurementSource: .all)
        let sections = StatisticsPresentation.fieldGoalSections(fg)
        #expect(sections.count == 1)
        #expect(sections[0].emptyMessage == "No field goal kicks in this period.")
        #expect(StatisticsPresentation.kickoffSections(KickStatisticsCalculator.kickoff([], measurementSource: .all))[0].emptyMessage != nil)
        #expect(StatisticsPresentation.puntSections(KickStatisticsCalculator.punt([], measurementSource: .all))[0].emptyMessage != nil)
    }

    @Test func fieldGoalSectionsShowMakesBucketsHashAndAccuracyWhenEnoughData() {
        func kick(_ result: KickResult, _ distance: Double, _ hash: HashLocation, x: Double?) -> KickStatRecord {
            KickStatRecord(kickTypeIs: .fieldGoal, result: result, distance: distance, hash: hash, x: x)
        }
        let few = [kick(.made, 25, .left, x: 0), kick(.missedLeft, 45, .right, x: -1.5), kick(.made, 42, .left, x: nil)]
        let sections = StatisticsPresentation.fieldGoalSections(KickStatisticsCalculator.fieldGoal(few, kickType: .fieldGoal, measurementSource: .all))
        let overview = sections.first { $0.title == "Overview" }
        #expect(overview?.rows.first { $0.title == "Made" }?.value == "2 of 3")
        #expect(overview?.rows.first { $0.title == "Make %" }?.value == "66.7%")
        #expect(overview?.rows.contains { $0.title == "Missed left" && $0.value == "1" } == true)
        let distance = sections.first { $0.title == "By distance" }
        #expect(distance?.rows.map(\.title) == ["Under 30 yd", "40–49 yd"])
        let hash = sections.first { $0.title == "By hash" }
        #expect(hash?.rows.first { $0.title == "Left Hash" }?.value == "100%")
        let accuracy = sections.first { $0.title == "Accuracy" }
        #expect(accuracy?.rows.isEmpty == true)
        #expect(accuracy?.emptyMessage?.contains("at least 5") == true)

        let many = (0..<6).map { kick(.made, 30, .center, x: 0.2 * Double($0 % 3)) }
        let rich = StatisticsPresentation.fieldGoalSections(KickStatisticsCalculator.fieldGoal(many, kickType: .fieldGoal, measurementSource: .all))
        let acc = rich.first { $0.title == "Accuracy" }
        #expect(acc?.emptyMessage == nil)
        #expect(acc?.rows.first?.title == "Average crossing point")
        #expect(StatisticsPresentation.horizontalText(-0.3) == "0.30 left of center")
        #expect(StatisticsPresentation.horizontalText(0.01) == "Center")
    }

    @Test func kickoffAndPuntSections() {
        let kickoffs = [
            KickStatRecord(kickType: .kickoff, distanceYards: 60, touchback: true, landingYardLine: -2, landingZone: .middle, hangTimeSeconds: 4),
            KickStatRecord(kickType: .kickoff, distanceYards: 55, touchback: false, landingZone: .left, hangTimeSeconds: 3.6),
        ]
        let ko = StatisticsPresentation.kickoffSections(KickStatisticsCalculator.kickoff(kickoffs, measurementSource: .all))
        #expect(ko.map(\.title) == ["Overview", "Distance", "Hang time", "Landing zone"])
        #expect(ko[0].rows.first { $0.title == "Touchback %" }?.value == "50%")
        #expect(ko[1].rows.first?.value == "58 yd")
        #expect(ko[2].rows.first { $0.title == "Best" }?.value == "4.00 s")
        #expect(ko[3].rows.contains { $0.title == "Middle" })

        let punts = [KickStatRecord(kickType: .punt, distanceYards: 40, hangTimeSeconds: nil)]
        let p = StatisticsPresentation.puntSections(KickStatisticsCalculator.punt(punts, measurementSource: .all))
        #expect(p[1].rows.first?.value == "40 yd")
        #expect(p[2].emptyMessage == "No hang time recorded yet.")
    }

    @Test func filtersMapToRanges() {
        #expect(StatsDatePreset.allTime.range(endingAt: now) == nil)
        let week = StatsDatePreset.last7.range(endingAt: now)
        #expect(week?.upperBound == now)
        #expect(week?.lowerBound == now.addingTimeInterval(-7 * 86_400))
        #expect(StatsKickTypeFilter.allCases.map(\.kickType) == [.fieldGoal, .pat, .kickoff, .punt])
        #expect(StatsKickTypeFilter.kickoff.title == "Kickoff")
    }
}

private extension KickStatRecord {
    init(kickTypeIs type: KickType, result: KickResult, distance: Double, hash: HashLocation, x: Double?) {
        self.init()
        kickType = type
        self.result = result
        distanceYards = distance
        distanceSource = .manual
        hashLocation = hash
        accuracyX = x
        accuracySource = x == nil ? nil : .manual
    }
}
