import Foundation
import Testing
@testable import KickLab

/// Reanalysis fix (TestFlight build 8): automatic, user-assisted and replayed analyses are
/// kept apart, and a manual contact is never applied implicitly.
///
/// Root cause on device: every repeated "analysis" was user-assisted. The strike-selection
/// screen opened at the automatic estimate (2.467 s) and accepted it as the user's frame
/// without the user moving the video, the Analyze screen kept showing the last
/// (assisted) run for the app's lifetime with no way to start an automatic one, and the
/// assisted analysis stayed the kick's current analysis after its video was removed and
/// re-imported. Nothing restored the contact from storage: no fingerprinting exists and
/// every import creates a new video record.
@Suite("Reanalysis modes and manual-contact isolation")
struct ReanalysisModeTests {
    typealias Script = SyntheticPose.KickScript
    typealias Real = RealReferenceClip220
    static let engine = "pose-biomechanics-2.8.0"

    private func pipeline(_ script: Script = .fieldGoal, assistance: PhaseDetectionAssistance? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: SyntheticPose.sequence(script), kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side,
            assistance: assistance
        ))
    }

    private func encoded(_ phases: KickPhaseDetectionResult) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(phases)
    }

    // MARK: Requirement 10 — a clean automatic analysis

    @Test func aCleanAutomaticAnalysisIsLabeledAutomaticEverywhere() throws {
        let out = pipeline()
        #expect(out.phases.assistance == nil, "no active assistance")
        #expect(!out.phases.isUserAssisted)
        let evidence = try #require(out.phases.evidence)
        #expect(evidence.contactTimingBasis == "automatic")
        #expect(evidence.contactTimingSource == .automatic)
        #expect(evidence.userAssistedContactTime == nil)
        #expect(evidence.contactTimingMethod == "speedPeak" || evidence.contactTimingMethod == "plantAndFootPassing")
        let version = AnalysisAssistanceLabel.version(Self.engine, assistance: out.phases.assistance)
        #expect(version == Self.engine)
        #expect(!version.hasSuffix("+assisted"))
        #expect(!PoseAnalysisSummary(primaryVideoID: UUID(), output: out).isUserAssisted)

        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: out, engineVersion: version), storedStatus: "completed",
            storedFailureReason: nil, kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0)
        )
        #expect(report.analysisMode == "automatic")
        #expect(report.contactTimingSource == "automatic")
        #expect(report.assistance == nil)
        #expect(report.assistance?.contactTime == nil)
        #expect(report.automaticReplay == nil, "the replay of an automatic analysis already is automatic")
        #expect(report.replay?.evidence?.contactTimingSource == .automatic)
        #expect(report.plainText.contains("Analysis mode: automatic · contact timing basis: automatic"))
        #expect(!report.plainText.contains("+assisted"))
    }

    @Test func theRealClipAutomaticallyReportsAnAutomaticBasis() throws {
        let phases = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal)
        #expect(phases.assistance == nil)
        #expect(phases.evidence?.contactTimingBasis == "automatic")
        #expect(phases.evidence?.contactTimingMethod == "plantAndFootPassing")
        #expect(phases.evidence?.userAssistedContactTime == nil)
    }

    /// The device symptom: an assisted contact of exactly the automatic estimate. Same
    /// time, different source — only the user-assisted run says "user".
    @Test func choosingTheAutomaticEstimateIsStillLabeledAsTheUsersChoice() throws {
        let automatic = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal)
        let estimate = try #require(automatic.estimatedContactTime)
        #expect(abs(estimate - 2.466666666666667) < 0.001, "the frame reported on device (exported times are rounded to 1 ms)")
        let assisted = KickPhaseDetector.detect(Real.signals, kickType: .fieldGoal,
                                                assistance: PhaseDetectionAssistance(contactTime: estimate))
        #expect(assisted.evidence?.contactTimingBasis == "user")
        #expect(assisted.evidence?.contactTimingSource == .user)
        #expect(automatic.evidence?.contactTimingSource == .automatic)
    }

    // MARK: Requirement 8 — switching modes never leaks a manual contact

    @Test func automaticResultsAreIdenticalBeforeAndAfterAssistedRuns() throws {
        let first = pipeline()
        let assistedContact = pipeline(assistance: PhaseDetectionAssistance(contactTime: Script.fieldGoal.expectedContact - 0.1))
        let assistedWindow = pipeline(assistance: PhaseDetectionAssistance(windowStart: 0.5, windowEnd: 3.0))
        let again = pipeline()
        #expect(assistedContact.phases.isUserAssisted)
        #expect(assistedWindow.phases.isUserAssisted)
        #expect(try encoded(first.phases) == encoded(again.phases), "byte-identical automatic phases")
        #expect(first.biomechanics.overallScore == again.biomechanics.overallScore)
        #expect(again.phases.assistance == nil)
        #expect(again.phases.evidence?.contactTimingSource == .automatic)
    }

    @Test func automaticRunModeNeverCarriesAssistance() {
        #expect(AnalysisRunMode.automatic.assistance == nil)
        #expect(!AnalysisRunMode.automatic.isUserAssisted)
        #expect(AnalysisRunMode(assistance: nil) == .automatic)
        #expect(AnalysisRunMode(assistance: PhaseDetectionAssistance()) == .automatic, "an empty assistance is automatic")
        let contact = AnalysisRunMode(assistance: PhaseDetectionAssistance(contactTime: 2.4))
        #expect(contact == .manualContact(seconds: 2.4))
        #expect(contact.assistance == PhaseDetectionAssistance(contactTime: 2.4))
        let window = AnalysisRunMode(assistance: PhaseDetectionAssistance(windowStart: 1, windowEnd: 3))
        #expect(window == .manualKickWindow(start: 1, end: 3))
        #expect(window.assistance?.window == 1...3)
        #expect(window.isUserAssisted && contact.isUserAssisted)
    }

    // MARK: The manual-contact screen needs an explicit choice

    @Test func theAutomaticEstimateIsNotAcceptedAsAManualContact() {
        var selection = ManualContactSelection(automaticEstimate: 2.466666666666667)
        #expect(!selection.canSubmit)
        #expect(selection.runMode(currentTime: 2.466666666666667) == nil, "opening at the estimate is not a choice")
        #expect(selection.hint.contains("automatic estimate"))
        selection.userPositionedVideo()
        #expect(selection.canSubmit)
        #expect(selection.runMode(currentTime: 2.5) == .manualContact(seconds: 2.5))
        #expect(selection.runMode(currentTime: .nan) == nil)
        #expect(selection.runMode(currentTime: -1) == nil)
    }

    // MARK: Requirement 6 — provenance on results and diagnostics

    @Test func provenanceShowsTheTimingSourceAndEngineVersion() throws {
        let automatic = pipeline()
        let a = AnalysisProvenance(engineVersion: Self.engine, phases: automatic.phases)
        #expect(a.mode == .automatic)
        #expect(a.contactSource == .automatic)
        #expect(a.contactText.hasPrefix("Contact timing: automatic"))
        #expect(a.engineText == "Engine: pose-biomechanics-2.8.0")

        let t = Script.fieldGoal.expectedContact
        let assisted = pipeline(assistance: PhaseDetectionAssistance(contactTime: t))
        let u = AnalysisProvenance(engineVersion: Self.engine + "+assisted", phases: assisted.phases)
        #expect(u.mode == .manualContact(seconds: t))
        #expect(u.contactSource == .user)
        #expect(u.contactText.hasPrefix("Contact timing: chosen by you"))
        #expect(u.engineText.hasSuffix("+assisted"))

        let none = AnalysisProvenance(engineVersion: "1", phases: nil)
        #expect(none.contactText == "Contact timing: not found")
        #expect(none.mode == .automatic)
    }

    @Test func assistedDiagnosticsAlsoReplayAutomaticallyWithoutTheUsersInput() throws {
        let t = Script.fieldGoal.expectedContact
        let out = pipeline(assistance: PhaseDetectionAssistance(contactTime: t))
        let report = AnalysisDiagnosticsBuilder.build(
            AnalysisDiagnosticsInput(output: out, engineVersion: Self.engine + "+assisted"), storedStatus: "completed",
            storedFailureReason: nil, kickingFoot: .right, appVersion: nil, generatedAt: Date(timeIntervalSince1970: 0)
        )
        #expect(report.analysisMode == "userAssisted")
        #expect(report.contactTimingSource == "user")
        #expect(report.assistance?.contactTime == t)
        #expect(report.replay?.evidence?.contactTimingSource == .user, "Replay Diagnostics re-applies the recorded input")
        let automatic = try #require(report.automaticReplay)
        #expect(automatic.evidence?.contactTimingSource == .automatic)
        #expect(automatic.evidence?.userAssistedContactTime == nil)
        #expect(report.plainText.contains("Automatic replay"))
        #expect(report.plainText.contains("Analysis mode: userAssisted · contact timing basis: user"))
    }

    // MARK: Backward compatibility

    @Test func filesFromEarlier230BuildsStillReadCorrectly() throws {
        // Build 7/8 files stored the METHOD in contactTimingBasis.
        var legacy = PhaseDetectionEvidence()
        legacy.contactTimingBasis = "plantAndFootPassing"
        #expect(legacy.contactTimingSource == .automatic)
        #expect(legacy.contactTimingMethodResolved == "plantAndFootPassing")
        #expect(legacy.contactTimedByConstraints)
        var legacyUser = PhaseDetectionEvidence()
        legacyUser.contactTimingBasis = "user"
        legacyUser.userAssistedContactTime = 2.466666666666667
        #expect(legacyUser.contactTimingSource == .user)
        #expect(legacyUser.contactTimingMethodResolved == "user")
        #expect(PhaseDetectionEvidence().contactTimingSource == nil, "pre-12D files have no timing information")

        // An old automatic constraint-timed analysis still offers manual contact.
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: SyntheticPose.sequence(.fieldGoal),
                                                                      kickType: .fieldGoal, kickingFoot: .right))
        var old = out.phases
        old.evidence?.contactTimingMethod = nil
        old.evidence?.contactTimingBasis = "plantAndFootPassing"
        let decoded = try JSONDecoder().decode(KickPhaseDetectionResult.self, from: JSONEncoder().encode(old))
        #expect(decoded.evidence?.contactTimedByConstraints == true)
        #expect(AssistanceOffer.make(phases: decoded, engineVersion: Self.engine) == .chooseContact)
    }

    // MARK: Requirement 2 — which analysis is current after a deletion

    @Test func deletingTheCurrentAnalysisNeverPromotesAUserAssistedOne() {
        func c(_ id: Int, _ status: ProcessingStatus, assisted: Bool, at seconds: Double) -> CurrentReplacementCandidate {
            CurrentReplacementCandidate(
                snapshot: AnalysisCurrencySnapshot(id: UUID(uuidString: String(format: "00000000-0000-0000-0000-%012d", id))!,
                                                   status: status, isCurrent: false,
                                                   createdAt: Date(timeIntervalSince1970: seconds),
                                                   completedAt: Date(timeIntervalSince1970: seconds + 1)),
                isUserAssisted: assisted)
        }
        let olderAutomatic = c(1, .completed, assisted: false, at: 10)
        let newerAutomatic = c(2, .completed, assisted: false, at: 20)
        let newestAssisted = c(3, .completed, assisted: true, at: 30)
        let failedAutomatic = c(4, .failed, assisted: false, at: 40)
        #expect(CurrentAnalysisSelector.replacementAfterDeletion(from: [olderAutomatic, newerAutomatic, newestAssisted, failedAutomatic])
                == newerAutomatic.snapshot.id)
        #expect(CurrentAnalysisSelector.replacementAfterDeletion(from: [newestAssisted, failedAutomatic]) == nil)
        #expect(CurrentAnalysisSelector.replacementAfterDeletion(from: []) == nil)
    }
}
