import Foundation
import Testing
@testable import KickLab

/// Engine 2.8.1 (build 14): how the football's departure is combined with body pose.
///
/// Root cause reproduced: on the iPhone (IMG_1709, Apple Vision pose), the plant search
/// proposed 8.302 s although the football left at 7.968 s; the contact search was anchored
/// on that plant (8.335–8.752 s), so the ball's departure was declared a "conflict" and the
/// analysis stopped as "Couldn't pinpoint the strike".
///
/// SYNTHETIC: these clips are `DepthViewSynthetic` kicks (rear view, 30 fps). To reproduce
/// a pose plant estimate that comes AFTER the strike — what Vision produced on the device —
/// the synthetic plant foot is scripted to keep moving past contact. The football tracks are
/// test stand-ins with the device's timing (at rest through 7.900 s, moving at 7.967 s).
/// Real-frame football tests are in `FootballVisionTests`.
@Suite("Ball/pose evidence fusion (engine 2.8.1)")
struct BallFusionTests {
    typealias Script = DepthViewSynthetic.Script

    /// A kick timed like IMG_1709: true contact 7.95 s.
    private func lateKick(plantTime: Double) -> Script {
        var s = Script()
        s.duration = 9.5
        s.runStart = 6.9
        s.contactTime = 7.95
        s.plantTime = plantTime
        return s
    }

    private func ball(rest: Double, moved: Double) -> FootballTrack {
        var t = FootballTrack(method: .automaticFootballDetection, detector: .yoloxS, note: "test stand-in")
        t.lastStationaryTime = rest
        t.firstPersistentMovementTime = moved
        t.movementBasis = "displacedDetections"
        return t
    }

    private func run(_ s: Script, football: FootballTrack?, assistance: PhaseDetectionAssistance? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: DepthViewSynthetic.sequence(s), kickType: .fieldGoal, kickingFoot: .right,
                                                          cameraAngle: .rear, assistance: assistance, football: football))
    }

    @Test func aPlantProposedAfterTheBallLeftNoLongerVetoesTheBall() throws {
        let s = lateKick(plantTime: 8.15)
        // Pose alone: the plant lands after the strike, and contact isn't found.
        let poseOnly = run(s, football: nil)
        let posePlant = try #require(poseOnly.phases.plantTime)
        #expect(posePlant > 8.1, "the pose plant estimate comes after the ball left (\(posePlant))")
        #expect(!poseOnly.phases.phase(.contact).isAvailable)

        let out = run(s, football: ball(rest: 7.9, moved: 7.9667))
        let f = try #require(out.phases.evidence?.ballFusion)
        #expect(f.detectorRan && f.ballSelected)
        #expect(abs((f.plantCandidateTime ?? 0) - posePlant) < 1e-6)
        #expect(f.plantPrecedesBall == false && f.plantRejected, "the late plant is flagged and not used")
        #expect(f.accepted, "\(f.rejectionReason ?? "")")
        #expect(f.kickingFootSupports == true)
        let c = out.phases.phase(.contact)
        #expect(c.status == .estimated, "estimated, never 'detected'")
        #expect(ContactOutcome.of(out.phases) == .ballConstrainedContactInterval)
        // The measured interval is kept: three possible frames (7.900, 7.933, 7.967 s).
        #expect(abs((out.phases.evidence?.contactEarliestTime ?? 0) - 7.9) < 1e-3)
        #expect(abs((out.phases.evidence?.contactLatestTime ?? 0) - 7.967) < 1e-3)
        #expect(abs((c.representativeTime ?? 0) - 7.9333) < 1e-3)
        // Physical order: no plant at or after contact is reported.
        if let p = out.phases.plantTime { #expect(p < (c.representativeTime ?? 0)) }
        #expect(out.phases.evidence?.plantCandidates?.contains { !$0.accepted && $0.reason.contains("after the football") } == true)
        // Through to completion: a measurements-only rear analysis.
        #expect(out.completionBasis == .measurementsOnly)
        #expect(out.gates.last?.gate == .completion && out.gates.last?.passed == true)
        #expect(out.biomechanics.overallScore == nil)
    }

    @Test func ballContactStandsWhilePlantIsUnavailable() throws {
        let out = run(lateKick(plantTime: 8.15), football: ball(rest: 7.9, moved: 7.9667))
        #expect(out.phases.plantTime == nil, "no plant landing shortly before the ball left: none is reported")
        #expect(out.phases.phase(.contact).isAvailable)
        let m = out.biomechanics.measurements
        #expect(m.first { $0.key == .plantToContactTime }?.unavailableReason == .phaseUnavailable)
        #expect(m.filter(\.isAvailable).count >= AnalysisCompletion.minimumMeasurementOnlyMetrics)
    }

    @Test func aPlantBeforeTheBallLeftIsKept() throws {
        let s = Script()   // plant 1.4 s, contact 1.55 s
        let out = run(s, football: ball(rest: 1.5333, moved: 1.5667))
        let f = try #require(out.phases.evidence?.ballFusion)
        #expect(f.plantPrecedesBall == true && !f.plantRejected)
        #expect(f.plantUsedTime == f.plantCandidateTime)
        #expect(f.accepted && f.poseFoundStrike == true && f.overlapsPose == true)
        let plant = try #require(out.phases.plantTime)
        #expect(abs(plant - s.plantTime) <= 2.0 / 30)
        #expect(out.biomechanics.measurements.contains { $0.key == .plantToContactTime && $0.isAvailable })
    }

    @Test func aBallThatLeavesWhileTheKickingFootIsNotSwingingIsAConflict() throws {
        // The scripted plant foot hides the strike so pose finds none, and the ball's
        // departure falls where the kicking foot is barely moving.
        let out = run(lateKick(plantTime: 8.2), football: ball(rest: 7.9, moved: 7.9667))
        let f = try #require(out.phases.evidence?.ballFusion)
        #expect(f.kickingFootSupports == false)
        #expect(!f.accepted)
        #expect(f.rejectionReason?.contains("kicking foot wasn't swinging") == true)
        #expect(out.phases.evidence?.ballEvidence?.outcome == .conflicting)
        #expect(!out.phases.phase(.contact).isAvailable, "no certainty is invented")
        #expect(out.completionBasis == .insufficient)
    }

    @Test func aBallLeavingFarFromTheStrikeIsStillAConflict() throws {
        let out = run(Script(), football: ball(rest: 0.6, moved: 0.6333))
        let f = try #require(out.phases.evidence?.ballFusion)
        #expect(!f.accepted)
        #expect(out.phases.evidence?.ballEvidence?.outcome == .conflicting)
        #expect(out.phases.evidence?.contactTimingMethod != "ballDetector")
    }

    @Test func aSpareBallMovingWhileTheKickedBallRestsIsNotDeparture() {
        let aspect = 9.0 / 16.0
        let kicked = FootballRestSite(center: NormalizedPoint(x: 0.5, y: 0.6), size: 0.0225, firstSeen: 0, lastSeen: 1, detections: 9,
                                      meanScore: 0.8, afterStrikeShare: 0, closestAnkleSizes: 1, selected: true, reason: "")
        let spare = FootballRestSite(center: NormalizedPoint(x: 0.35, y: 0.6), size: 0.0225, firstSeen: 0, lastSeen: 1, detections: 9,
                                     meanScore: 0.6, afterStrikeShare: 1, closestAnkleSizes: 9, selected: false, reason: "")
        let frames: [(time: Double, detections: [FootballDetection])] = (0..<12).map { i in
            let t = Double(i) / 30
            let rest = FootballDetection(time: t, box: NormalizedBox(cx: 0.5, cy: 0.6, w: 0.04, h: 0.0225), score: 0.8, pass: .precision)
            // The spare ball is knocked and rolls up the frame from frame 4.
            let y = i < 4 ? 0.6 : 0.6 - 0.03 * Double(i - 3)
            let other = FootballDetection(time: t, box: NormalizedBox(cx: 0.35, cy: y, w: 0.04, h: 0.0225), score: 0.7, pass: .precision)
            return (t, [rest, other])
        }
        let obs = FootballTrackAnalyzer.classify(frames: frames, site: kicked, otherSites: [spare], aspect: aspect)
        #expect(obs.allSatisfy { $0.state == .atRest }, "the kicked ball stays at rest")
        #expect(FootballTrackAnalyzer.motionEvents(obs, site: kicked, aspect: aspect) == nil)
    }

    @Test func withoutTheDetectorPoseOnlyAnalysisIsUnchangedAndSaysSo() throws {
        let s = Script()
        let poseOnly = run(s, football: nil)
        let noDetector = run(s, football: .unavailable("No football detector is available on this device."))
        #expect(noDetector.phases.phase(.contact) == poseOnly.phases.phase(.contact))
        #expect(noDetector.phases.plantTime == poseOnly.phases.plantTime)
        let f = try #require(noDetector.phases.evidence?.ballFusion)
        #expect(!f.detectorRan && !f.accepted)
        #expect(f.rejectionReason?.hasPrefix("The football detector didn't run") == true)
        // Detector ran but found no usable departure: a different, explicit state.
        let none = run(s, football: .unavailable("The detector found no football resting in one place.", detector: .yoloxS))
        let g = try #require(none.phases.evidence?.ballFusion)
        #expect(g.detectorRan && !g.ballSelected && !g.accepted)
        #expect(g.rejectionReason?.hasPrefix("No usable ball departure") == true)
        #expect(ContactOutcome.of(none.phases) == .strikeWindowOnly)
    }

    @Test func aUserChosenContactIsNotTouchedByTheBall() throws {
        let s = lateKick(plantTime: 8.15)
        let out = run(s, football: ball(rest: 7.9, moved: 7.9667), assistance: PhaseDetectionAssistance(contactTime: 8.0))
        #expect(abs((out.phases.phase(.contact).representativeTime ?? 0) - 8.0) < 1e-3)
        #expect(ContactOutcome.of(out.phases) == .userSelectedContact)
        #expect(out.phases.evidence?.ballFusion == nil, "no fusion for a user-assisted run")
    }

    @Test func theSideViewIgnoresTheDepthFusion() throws {
        let seq = SyntheticPose.sequence(.fieldGoal)
        func side(_ football: FootballTrack?) -> KickAnalysisPipelineOutput {
            KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: seq, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side,
                                                              football: football))
        }
        let plain = side(nil), withNone = side(.unavailable("none"))
        #expect(plain.perspective?.used == .side)
        #expect(withNone.phases.phases == plain.phases.phases, "side-view phases unchanged")
        #expect(withNone.phases.evidence?.ballFusion == nil)
        #expect(withNone.biomechanics.overallScore == plain.biomechanics.overallScore)
    }
}
