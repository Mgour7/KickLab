import Foundation
import Testing
@testable import KickLab

/// Step 12G (Computer Vision Intelligence Rebuild): the football layer.
///
/// Data used, by kind:
/// - REAL DETECTOR OUTPUT ON REAL FRAMES (`RealVideo1709Football`): YOLOX-S run with
///   onnxruntime on the real IMG_1709 frames (the same model the app bundles as Core ML).
/// - ACTUAL IMAGES: the real ball-region luma crops and whole-frame thumbnails.
/// - REAL VIDEO, DIFFERENT POSE MODEL: MediaPipe landmarks (`RealVideoClip1709`).
/// - SYNTHETIC: tests named "synthetic" build tiny made-up inputs to check one rule.
/// IMG_1709 is development data: these tests show the pipeline works on one real clip;
/// they are not an accuracy evaluation.
@Suite("Football vision (Step 12G CV rebuild)")
struct FootballVisionTests {
    typealias Real = RealVideo1709Football
    typealias Clip = RealVideoClip1709
    let aspect = 1080.0 / 1920.0

    // MARK: Decoder (real head output)

    @Test func theDecoderReproducesOnnxruntimeOnARealFrame() throws {
        var rows: [Int: [Double]] = [:]
        for r in Real.raw240 { rows[Int(r[0])] = Array(r.dropFirst()) }
        let boxes = YOLOXDecoder.decode(inputSize: 640, classIndex: 32) { a, c in
            guard let r = rows[a] else { return 0 }
            switch c {
            case 0...4: return Float(r[c])
            case 37: return Float(r[5])
            default: return 0
            }
        }
        let geometry = LetterboxGeometry(region: Real.precisionCrop, inputSize: 640)
        let found = YOLOXDecoder.displayBoxes(boxes, geometry: geometry, displayWidth: 1080, displayHeight: 1920)
        #expect(found.count == Real.decoded240.count)
        for (f, e) in zip(found, Real.decoded240) {
            #expect(abs(f.box.cx - e.cx) < 2e-4 && abs(f.box.cy - e.cy) < 2e-4, "center")
            #expect(abs(f.box.w - e.w) < 2e-4 && abs(f.box.h - e.h) < 2e-4, "size")
            #expect(abs(f.score - e.s) < 2e-3, "score")
        }
        // The kicked ball, just off the holder: (625, 1045) px on the 1080×1920 frame.
        let top = try #require(found.first)
        #expect(abs(top.box.cx * 1080 - 625) < 3 && abs(top.box.cy * 1920 - 1045) < 3)
    }

    @Test func anchorsCoverAllThreeStrides() {
        #expect(YOLOXDecoder.anchorCount(inputSize: 640) == 8400)
    }

    @Test func syntheticSuppressionKeepsTheBestOfOverlappingBoxes() {
        let a = ModelBox(cx: 100, cy: 100, w: 40, h: 40, score: 0.9)
        let b = ModelBox(cx: 104, cy: 102, w: 40, h: 40, score: 0.6)
        let c = ModelBox(cx: 300, cy: 300, w: 40, h: 40, score: 0.5)
        #expect(YOLOXDecoder.nonMaximumSuppression([b, c, a]) == [a, c])
    }

    // MARK: Letterbox (synthetic)

    @Test func syntheticLetterboxSamplesTheUprightFrame() {
        // Stored 6×4, displayed rotated (.right) as 4×6. Pixel (x, y) stores B = 10x, G = 10y.
        var bytes: [UInt8] = []
        for y in 0..<4 { for x in 0..<6 { bytes += [UInt8(10 * x), UInt8(10 * y), 0] } }
        let image = PackedBGRImage(width: 6, height: 4, bytes: bytes)
        let r = DetectorInputBuilder.makeInput(source: image, orientation: .right, isMirrored: false,
                                               region: DisplayRect(x: 0, y: 0, width: 4, height: 6), inputSize: 6)
        #expect(r.geometry.scale == 1)
        let plane = 36
        for my in 0..<6 {
            for mx in 0..<6 {
                let b = r.input[my * 6 + mx], g = r.input[plane + my * 6 + mx]
                if mx < 4 {
                    // Displayed (mx, my) is stored (my, 3 − mx).
                    #expect(b == Float(10 * my) && g == Float(10 * (3 - mx)), "(\(mx), \(my))")
                } else {
                    #expect(b == DetectorInputBuilder.padValue, "padding")
                }
            }
        }
        let back = r.geometry.displayPoint(modelX: 2, modelY: 3)
        #expect(back.x == 2 && back.y == 3)
    }

    @Test func cropsStayInsideTheFrame() {
        let c = DetectorInputBuilder.cropRegion(centerX: 1050, centerY: 50, side: 686, displayWidth: 1080, displayHeight: 1920)
        #expect(c == DisplayRect(x: 394, y: 0, width: 686, height: 686))
    }

    @Test func fullRangeGrayStaysGray() {
        let p = YCbCrConversion.bgr(y: 100, cb: 128, cr: 128)
        #expect(p.b == 100 && p.g == 100 && p.r == 100)
    }

    // MARK: Stage 1 — finding the kicked ball among real detections

    private func poseOutput(football: FootballTrack? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                          cameraAngle: .rear, football: football))
    }

    @Test func theBroadScanFindsThePlacedBallAndRejectsTheSpares() throws {
        let context = FootballAnalysisContext.make(from: poseOutput(), kickingFoot: .right)
        let strike = try #require(context.strike)
        let sites = FootballTrackAnalyzer.sites(Real.broadScan, aspect: aspect)
        let r = FootballTrackAnalyzer.selectKickedBall(sites: sites, detections: Real.broadScan, scanTimes: Real.scanTimes,
                                                       ankle: context.ankle, strike: strike, aspect: aspect)
        let k = try #require(r.selected)
        let ball = r.sites[k]
        #expect(abs(ball.center.x * 1080 - 614) < 8 && abs(ball.center.y * 1920 - 1118) < 12, "the ball on the holder")
        #expect((ball.afterStrikeShare ?? 1) <= 0.2)
        // Every other football the detector saw stayed where it was after the kick.
        let others = r.sites.enumerated().filter { $0.offset != k }.map(\.element)
        #expect(!others.isEmpty, "spare footballs on the left of the frame are detected too")
        for o in others { #expect(!o.selected && !o.reason.hasPrefix("selected"), "\(o.reason)") }
        #expect(others.contains { $0.reason.contains("still there after the kick") }, "\(others.map(\.reason))")
    }

    // MARK: Stage 2 — the ball's states and its first persistent movement

    private func realTrack(appearance: [Double: Double] = [:]) throws -> FootballTrack {
        let context = FootballAnalysisContext.make(from: poseOutput(), kickingFoot: .right)
        return FootballTrackAnalyzer.analyze(broadScan: Real.broadScan, scanTimes: Real.scanTimes, precision: Real.precisionFrames,
                                             ankle: context.ankle, strike: context.strike, aspect: aspect, duration: Clip.durationSeconds,
                                             appearance: appearance, detector: .yoloxS)
    }

    @Test func theDetectorSeesTheBallLeaveBetween7_902And7_968() throws {
        let t = try realTrack()
        #expect(t.method == .automaticFootballDetection)
        #expect(abs((t.lastStationaryTime ?? 0) - 7.901667) < 1e-4, "last frame with the ball clearly on the holder")
        #expect(abs((t.firstPersistentMovementTime ?? 0) - 7.968333) < 1e-4, "first frame with the ball seen in the air")
        #expect(t.movementBasis == "displacedDetections")
        func state(_ time: Double) -> FootballFrameState? { t.observations.first { abs($0.time - time) < 1e-4 }?.state }
        #expect(state(7.935) == .notSeen, "the foot covers the ball: no box, and none is invented")
        #expect(state(7.968333) == .moving && state(8.001667) == .moving)
        // Movement constrains contact; it isn't contact. Both human reviews are inside.
        let b = try #require(t.contactBounds)
        #expect(b.afterTime < Clip.frameReviewFootOnBall && Clip.frameReviewFootOnBall <= b.byTime)
        #expect(b.afterTime < Clip.userContactInterval.lowerBound && Clip.userContactInterval.lowerBound <= b.byTime + 1e-3)
        #expect(Clip.device260Contact < b.afterTime, "the 2.6.0 answer (7.835 s) is before the ball was touched")
    }

    @Test func theBallsAppearanceAgreesWithTheDetector() throws {
        // The real luma crops' appearance match (ball tracker seeded on a resting frame).
        let crops = Clip.ballCrops
        let motion = BallMotionTracker.analyze(crops, referenceIndex: 8, ballRadius: Clip.ballRadiusPixels / Clip.cropDownsample)
        var appearance: [Double: Double] = [:]
        for (time, score) in zip(motion.times, motion.scores) { appearance[time] = score }
        let t = try realTrack(appearance: appearance)
        #expect(abs((t.lastStationaryTime ?? 0) - 7.901667) < 1e-4)
        #expect(abs((t.firstPersistentMovementTime ?? 0) - 7.968333) < 1e-4)
    }

    @Test func theBallsLeavingResolvesTheRearViewStrikeWindow() throws {
        let track = try realTrack()
        let out = poseOutput(football: track)
        let p = out.phases
        let c = p.phase(.contact)
        #expect(c.status == .estimated, "no longer just a strike window")
        #expect(p.evidence?.contactTimingMethod == "ballDetector")
        #expect(p.evidence?.contactProvenance == "ballAware")
        #expect(ContactOutcome.of(p) == .ballConstrainedContactInterval)
        #expect(p.evidence?.ballAnalysisMethod == .automaticFootballDetection)
        // Possible contact frames: 7.935 and 7.968 s. Shown at the earlier one.
        #expect(abs((p.evidence?.contactEarliestTime ?? 0) - 7.935) < 1e-3)
        #expect(abs((p.evidence?.contactLatestTime ?? 0) - 7.968) < 1e-3)
        #expect(abs((c.representativeTime ?? 0) - 7.935) < 1e-3)
        #expect(!p.isUserAssisted, "automatic evidence, not user assistance")
        // Against the human references (compared after the fact; never used above).
        let t = try #require(c.representativeTime)
        #expect(abs(t - Clip.userContactInterval.lowerBound) <= ContactTimingCheck.toleranceSeconds)
        #expect(t - Clip.device260Contact >= 0.09, "three frames later than the device's 2.6.0 answer")
        // Timing metrics are no longer withheld for "contact timing uncertain".
        #expect(!out.biomechanics.measurements.contains { $0.unavailableReason == .contactTimingUncertain })
        let poseOnly = poseOutput().biomechanics.measurements
        #expect(poseOnly.contains { $0.unavailableReason == .contactTimingUncertain }, "pose alone withholds them")
    }

    @Test func poseOnlyRunsAreUnchanged() {
        let p = poseOutput().phases
        #expect(p.evidence?.contactTimingMethod == "strikeWindow")
        #expect(ContactOutcome.of(p) == .strikeWindowOnly)
    }

    @Test func aDetectorThatFoundNothingIsRecordedHonestly() {
        let none = FootballTrackAnalyzer.analyze(broadScan: [], scanTimes: Real.scanTimes, precision: nil, ankle: [], strike: nil,
                                                 aspect: aspect, duration: 12, detector: .yoloxS)
        #expect(none.method == .ballUnavailable)
        let p = poseOutput(football: none).phases
        #expect(p.evidence?.contactTimingMethod == "strikeWindow")
        #expect(p.evidence?.ballEvidence?.outcome == .ballNotVisible)
        #expect(p.evidence?.ballAnalysisMethod == .ballUnavailable)
        #expect(ContactOutcome.of(p) == .strikeWindowOnly)
    }

    @Test func aUserAssistedRunIgnoresTheDetector() throws {
        let track = try realTrack()
        let out = KickAnalysisPipeline.run(KickAnalysisPipelineInput(sequence: Clip.sequence, kickType: .fieldGoal, kickingFoot: .right,
                                                                    cameraAngle: .rear, assistance: PhaseDetectionAssistance(contactTime: 8.001667),
                                                                    football: track))
        #expect(abs((out.phases.phase(.contact).representativeTime ?? 0) - 8.001667) < 1e-4)
        #expect(ContactOutcome.of(out.phases) == .userSelectedContact)
    }

    @Test func aBallThatLeavesOutsideTheStrikeIsAConflictNotAContact() {
        let ball = AutomaticBallContact(lastStationaryTime: 5.0, firstMovementTime: 5.033, basis: "displacedDetections", detectorName: "test")
        let times = stride(from: 4.0, through: 6.0, by: 1.0 / 30).map { $0 }
        let r = DepthViewPhaseDetector.ballContact(ball, times: times, poseBounds: 7.8...8.0)
        #expect(r.resolved == nil)
        #expect(r.evidence.outcome == .conflicting)
    }

    @Test func aWideBallIntervalDoesNotSetAContactTime() {
        let ball = AutomaticBallContact(lastStationaryTime: 7.8, firstMovementTime: 8.0, basis: "restVanished", detectorName: "test")
        let times = stride(from: 7.0, through: 9.0, by: 1.0 / 30).map { $0 }
        let r = DepthViewPhaseDetector.ballContact(ball, times: times, poseBounds: 7.7...8.1)
        #expect(r.resolved == nil, "±0.1 s is wider than the timing tolerance")
    }

    // MARK: Synthetic tracking rules

    private func det(_ t: Double, _ x: Double, _ y: Double, _ s: Double = 0.8) -> FootballDetection {
        FootballDetection(time: t, box: NormalizedBox(cx: x, cy: y, w: 0.04, h: 0.0225), score: s, pass: .precision)
    }
    private var site: FootballRestSite {
        FootballRestSite(center: NormalizedPoint(x: 0.5, y: 0.6), size: 0.0225, firstSeen: 0, lastSeen: 1, detections: 5, meanScore: 0.8,
                         afterStrikeShare: 0, closestAnkleSizes: 1, selected: true, reason: "")
    }

    @Test func syntheticAOneFrameJumpIsNotMovement() {
        let frames: [(time: Double, detections: [FootballDetection])] = (0..<10).map { i in
            let t = Double(i) / 30
            return (t, i == 5 ? [det(t, 0.5, 0.5)] : [det(t, 0.5, 0.6)])
        }
        let obs = FootballTrackAnalyzer.classify(frames: frames, site: site, otherSites: [], aspect: aspect)
        #expect(FootballTrackAnalyzer.motionEvents(obs, site: site, aspect: aspect) == nil, "the ball is back at rest after the jump")
    }

    @Test func syntheticASpareBallIsNotTheKickedBall() {
        let spare = FootballRestSite(center: NormalizedPoint(x: 0.2, y: 0.6), size: 0.0225, firstSeen: 0, lastSeen: 2, detections: 9,
                                     meanScore: 0.6, afterStrikeShare: 1, closestAnkleSizes: 20, selected: false, reason: "")
        let frames: [(time: Double, detections: [FootballDetection])] = (0..<10).map { i in
            let t = Double(i) / 30
            return (t, i < 4 ? [det(t, 0.5, 0.6)] : [det(t, 0.2, 0.6)])
        }
        let obs = FootballTrackAnalyzer.classify(frames: frames, site: site, otherSites: [spare], aspect: aspect)
        #expect(obs[5].state == .otherFootball)
        #expect(FootballTrackAnalyzer.motionEvents(obs, site: site, aspect: aspect) == nil, "a spare ball isn't the kicked ball moving")
    }

    @Test func syntheticMovingTowardTheRestingSpotIsNotDeparture() {
        let frames: [(time: Double, detections: [FootballDetection])] = (0..<10).map { i in
            let t = Double(i) / 30
            if i < 4 { return (t, [det(t, 0.5, 0.6)]) }
            return (t, [det(t, 0.5, 0.6 - 0.02 * Double(10 - i))])   // approaching the spot
        }
        let obs = FootballTrackAnalyzer.classify(frames: frames, site: site, otherSites: [], aspect: aspect)
        #expect(FootballTrackAnalyzer.motionEvents(obs, site: site, aspect: aspect) == nil)
    }

    @Test func syntheticASteadyCameraShiftIsFollowed() {
        // The whole picture (ball included) slides right by 2 ball widths from frame 3 on:
        // with the camera shift known, the ball is still at rest.
        let frames: [(time: Double, detections: [FootballDetection])] = (0..<10).map { i in
            let t = Double(i) / 30
            return (t, [det(t, i < 3 ? 0.5 : 0.58, 0.6)])
        }
        let withoutCamera = FootballTrackAnalyzer.classify(frames: frames, site: site, otherSites: [], aspect: aspect)
        #expect(withoutCamera[5].state != .atRest)
        let withCamera = FootballTrackAnalyzer.classify(frames: frames, site: site, otherSites: [], aspect: aspect) { t in
            t >= 0.1 - 1e-6 ? (0.08, 0) : (0, 0)
        }
        #expect(withCamera.allSatisfy { $0.state == .atRest })
    }

    // MARK: Camera motion (real thumbnails + synthetic)

    @Test func theRealCameraWasSteadyAroundTheStrike() {
        let context = FootballAnalysisContext.make(from: poseOutput(), kickingFoot: .right)
        let corridor = NormalizedRect(minX: 0.45, minY: 0, maxX: 0.70, maxY: 0.62)
        let r = CameraMotionEstimator.track(Real.thumbnails, exclude: { t in [corridor] + [context.kickerBox(at: t)].compactMap { $0 } },
                                            ballSize: 0.0255, aspect: aspect)
        #expect(r.summary.framesMeasured >= 8, "background texture matched on most frames")
        #expect(!r.summary.cameraMoved, "\(r.summary.note)")
    }

    @Test func syntheticCameraShiftIsMeasured() {
        var rng = SystemRandomNumberGenerator()
        let w = 90, h = 160
        let base = (0..<(w * h)).map { _ in UInt8.random(in: 0...255, using: &rng) }
        func shifted(_ dx: Int, _ dy: Int) -> LumaImage {
            var px = [UInt8](repeating: 0, count: w * h)
            for y in 0..<h { for x in 0..<w {
                let sx = min(w - 1, max(0, x - dx)), sy = min(h - 1, max(0, y - dy))
                px[y * w + x] = base[sy * w + sx]
            } }
            return LumaImage(width: w, height: h, pixels: px)
        }
        let s = CameraMotionEstimator.shift(reference: shifted(0, 0), next: shifted(3, 2), exclude: [])
        #expect(s.map { abs($0.dx * 90 - 3) < 1e-9 && abs($0.dy * 160 - 2) < 1e-9 } == true)
    }

    @Test func syntheticThumbnailsAreUpright() throws {
        // Stored 4×2 luma, displayed rotated (.right) as 2×4: stored (x, y) = 10x + y.
        let t = try #require(LumaThumbnail.make(storedWidth: 4, storedHeight: 2, orientation: .right, isMirrored: false, targetHeight: 4) { x, y in
            UInt8(10 * x + y)
        })
        #expect(t.width == 2 && t.height == 4)
        // Displayed (0, 0) is stored (0, 1); displayed (1, 3) is stored (3, 0).
        #expect(t[0, 0] == 1 && t[1, 3] == 30)
    }

    // MARK: Storage, diagnostics, overlay

    @Test func phaseFilesWithAndWithoutTheFootballTrackDecode() throws {
        let track = try realTrack()
        let artifact = PhaseArtifact(videoID: UUID(), phases: poseOutput().phases, ball: .unavailable, football: track)
        let data = try JSONEncoder().encode(artifact)
        #expect(try JSONDecoder().decode(PhaseArtifact.self, from: data) == artifact)
        var old = try #require(try JSONSerialization.jsonObject(with: data) as? [String: Any])
        old.removeValue(forKey: "football")
        let decoded = try JSONDecoder().decode(PhaseArtifact.self, from: JSONSerialization.data(withJSONObject: old))
        #expect(decoded.football == nil)
    }

    @Test func theDiagnosticsSummaryHasNoCoordinates() throws {
        let summary = FootballDiagnosticsSummary(try realTrack())
        let json = String(decoding: try JSONEncoder().encode(summary), as: UTF8.self)
        #expect(!json.contains("\"cx\"") && !json.contains("\"center\""))
        #expect(summary.framesMoving >= 3 && summary.restingBallsFound >= 2)
        #expect(summary.lines.joined().contains("first persistent movement 7.968"))
    }

    @Test func theOverlayDrawsOnlyObservedPositions() throws {
        let model = try #require(FootballOverlayModel(track: try realTrack()))
        #expect(model.box(at: 7.935, frame: 1.0 / 30) == nil, "no box where the ball wasn't seen")
        #expect(model.box(at: 7.901667, frame: 1.0 / 30)?.state == .atRest)
        let moving = try #require(model.box(at: 8.001667, frame: 1.0 / 30))
        #expect(moving.state == .moving && moving.label.contains("detected"))
        #expect(model.path(upTo: 8.1).count == model.observations.filter { $0.state == .moving && $0.time <= 8.1 }.count)
    }

    @Test func theDebuggerMarksTheBallsEvents() throws {
        let out = poseOutput()
        let timeline = try #require(PoseValidationTimeline.make(sequence: out.sequence, storedTimeline: out.kickerTimeline, currentTimeline: nil,
                                                                repair: nil, kickingFoot: .right, storedPhases: out.phases, currentPhases: out.phases,
                                                                markedContact: nil, football: try realTrack()))
        #expect(timeline.markers.contains { $0.kind == .ballLastAtRest && abs($0.time - 7.901667) < 1e-4 })
        #expect(timeline.markers.contains { $0.kind == .ballFirstMovement && abs($0.time - 7.968333) < 1e-4 })
    }

    @Test func outcomesForEveryKindOfAnswer() {
        #expect(ContactOutcome.allCases.count == 7)
        #expect(!ContactOutcome.userSelectedContact.isAutomatic)
        #expect(ContactOutcome.ballVerifiedContact.usesBallEvidence && !ContactOutcome.poseEstimatedContact.usesBallEvidence)
        let none = KickPhaseDetectionResult.unavailable(kickType: .fieldGoal, support: .full, coverage: 0, notes: [])
        #expect(ContactOutcome.of(none) == .contactUnavailable)
    }
}
