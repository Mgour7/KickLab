import Foundation
import Testing
@testable import KickLab

@Suite("Pose coordinates, orientation and sampling")
struct PoseGeometryTests {
    // MARK: Orientation

    @Test func orientationFromTransforms() {
        let cases: [(AffineTransformValues, VideoOrientation, Bool)] = [
            (AffineTransformValues(a: 1, b: 0, c: 0, d: 1), .up, false),
            (AffineTransformValues(a: 0, b: 1, c: -1, d: 0), .right, false),     // iPhone portrait
            (AffineTransformValues(a: -1, b: 0, c: 0, d: -1), .down, false),
            (AffineTransformValues(a: 0, b: -1, c: 1, d: 0), .left, false),
            (AffineTransformValues(a: -1, b: 0, c: 0, d: 1), .up, true),         // horizontal mirror
            (AffineTransformValues(a: 0.9999, b: 0.0141, c: -0.0141, d: 0.9999), .up, false), // near-identity snaps
        ]
        for (transform, orientation, mirrored) in cases {
            let result = PoseCoordinates.orientation(from: transform)
            #expect(result.orientation == orientation, "\(transform)")
            #expect(result.isMirrored == mirrored, "\(transform)")
        }
    }

    @Test func uprightMappingRotatesStoredPoints() {
        let topLeftish = NormalizedPoint(x: 0.1, y: 0.2)
        #expect(PoseCoordinates.upright(topLeftish, from: .up) == topLeftish)
        #expect(PoseCoordinates.upright(topLeftish, from: .right) == NormalizedPoint(x: 0.8, y: 0.1))
        #expect(PoseCoordinates.upright(topLeftish, from: .down) == NormalizedPoint(x: 0.9, y: 0.8))
        #expect(PoseCoordinates.upright(topLeftish, from: .left) == NormalizedPoint(x: 0.2, y: 0.9))
    }

    @Test func displayAspectRatioFollowsRotation() {
        let landscape: Double? = PoseCoordinates.displayAspectRatio(naturalWidth: 1920, naturalHeight: 1080, orientation: .up)
        let portrait: Double? = PoseCoordinates.displayAspectRatio(naturalWidth: 1920, naturalHeight: 1080, orientation: .right)
        let landscapeExpected: Double = 1920.0 / 1080.0
        let portraitExpected: Double = 1080.0 / 1920.0
        #expect(landscape == landscapeExpected)
        #expect(portrait == portraitExpected)
        #expect(PoseCoordinates.displayAspectRatio(naturalWidth: 0, naturalHeight: 1080, orientation: .up) == nil)
    }

    // MARK: Vision → app

    @Test func visionPointsFlipToTopLeftOrigin() {
        #expect(PoseCoordinates.fromVision(x: 0.25, y: 0.75) == NormalizedPoint(x: 0.25, y: 0.25))
    }

    @Test func appJointsHandleConfidenceAndMirroring() {
        let raw: [PoseJoint: (x: Double, y: Double, confidence: Double)] = [
            .leftAnkle: (0.2, 0.1, 0.8),
            .rightAnkle: (0.4, 0.1, 0),          // not detected
            .nose: (Double.nan, 0.5, 0.9),       // invalid
        ]
        let plain = PoseCoordinates.appJoints(fromVision: raw, isMirrored: false)
        #expect(plain.count == PoseJoint.allCases.count, "every joint has an entry")
        #expect(plain[.leftAnkle] == PosePoint(x: 0.2, y: 0.9, confidence: 0.8))
        #expect(plain[.rightAnkle]?.status == .unavailable)
        #expect(plain[.nose]?.status == .unavailable)
        #expect(plain[.neck]?.status == .unavailable)

        // Mirrored display: x flips, anatomical labels are kept.
        let mirrored = PoseCoordinates.appJoints(fromVision: raw, isMirrored: true)
        #expect(approximately(mirrored[.leftAnkle]?.x, 0.8))
        #expect(mirrored[.leftAnkle]?.y == 0.9)
        #expect(mirrored[.rightAnkle]?.status == .unavailable)
    }

    @Test func mirroringCanSwapSides() {
        let joints: [PoseJoint: PosePoint] = [.leftWrist: PosePoint(x: 0.3, y: 0.5, confidence: 1)]
        let swapped = PoseCoordinates.mirrored(joints, swapSides: true)
        #expect(swapped[.leftWrist] == nil)
        #expect(approximately(swapped[.rightWrist]?.x, 0.7))
        #expect(PoseJoint.nose.opposite == .nose)
        for joint in PoseJoint.allCases {
            #expect(joint.opposite.opposite == joint)
            #expect(joint.opposite.side == joint.side?.opposite)
        }
    }

    // MARK: Kicking side

    @Test func kickingSideMappingNeverAssumesRightFoot() {
        let right = KickingSideJoints(kickingFoot: .right)
        #expect(right.kickingAnkle == .rightAnkle)
        #expect(right.plantAnkle == .leftAnkle)
        #expect(right.kickingHip == .rightHip)
        #expect(right.plantKnee == .leftKnee)

        let left = KickingSideJoints(kickingFoot: .left)
        #expect(left.kickingAnkle == .leftAnkle)
        #expect(left.plantAnkle == .rightAnkle)
        #expect(left.kickingKnee == .leftKnee)
        #expect(left.plantShoulder == .rightShoulder)
        #expect(left.kickingWrist == .leftWrist)
        #expect(left.head == .nose)
    }

    // MARK: Sampling

    private func kept(_ plan: FrameSamplingPlan, _ times: [Double]) -> [Double] {
        var sampler = FrameSampler(plan: plan)
        var result: [Double] = []
        for t in times {
            switch sampler.decide(presentationTime: t) {
            case .keep: result.append(t)
            case .skip: continue
            case .stop: return result
            }
        }
        return result
    }

    @Test func slowMotionSourceIsSampledByTime() {
        let source = (0..<240).map { Double($0) / 240 }       // 1 s of 240 fps
        let kept60 = kept(.standard, source)
        #expect(kept60.count == 60)
        let firstSourceIndices: [Double] = kept60.prefix(3).map { (time: Double) -> Double in (time * 240.0).rounded() }
        let expectedIndices: [Double] = [0, 4, 8]
        #expect(firstSourceIndices == expectedIndices, "every 4th frame, true timestamps")
        #expect(kept(.everyFrame, source).count == 240)
        #expect(kept(FrameSamplingPlan(rate: .target(framesPerSecond: 120)), source).count == 120)
    }

    @Test func slowerSourceKeepsEveryFrame() {
        let source = (0..<30).map { Double($0) / 30 }
        #expect(kept(.standard, source).count == 30)
    }

    @Test func jitteredTimestampsDoNotDrift() {
        // 120 fps with ±1 ms jitter, sampled at 30 fps over 2 s → ~60 frames.
        let source: [Double] = (0..<240).map { index in
            let base: Double = Double(index) / 120.0
            let jitter: Double = index.isMultiple(of: 2) ? 0.001 : -0.001
            return base + jitter
        }
        let result = kept(FrameSamplingPlan(rate: .target(framesPerSecond: 30)), source)
        #expect((59...61).contains(result.count))
    }

    @Test func timeRangeSkipsBeforeAndStopsAfter() throws {
        let source = (0..<60).map { Double($0) / 60 }
        let plan = FrameSamplingPlan(rate: .everyFrame, timeRange: 0.5...0.75)
        let result = kept(plan, source)
        let firstKept: Double = try #require(result.first)
        let lastKept: Double = try #require(result.last)
        let tolerance: Double = 1e-9
        #expect(firstKept >= 0.5 - tolerance)
        #expect(lastKept <= 0.75 + tolerance)
        #expect(result.count == 16)

        var sampler = FrameSampler(plan: plan)
        #expect(sampler.decide(presentationTime: 0.9) == .stop)
        #expect(sampler.decide(presentationTime: .nan) == .skip)
    }

    @Test func samplingPlanIsCodable() throws {
        let plan = FrameSamplingPlan(rate: .target(framesPerSecond: 90), timeRange: 1...2.5)
        let data = try JSONEncoder().encode(plan)
        #expect(try JSONDecoder().decode(FrameSamplingPlan.self, from: data) == plan)
    }
}
