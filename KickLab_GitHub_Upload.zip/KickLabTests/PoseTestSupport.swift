import Foundation
@testable import KickLab

/// Synthetic, deterministic pose data. No video, no person: hand-built skeletons whose
/// motion is known exactly, so phase timing can be checked against ground truth.
enum SyntheticPose {
    /// Torso length (shoulder midpoint to hip midpoint) of every synthetic body.
    static let torso = 0.15

    /// A full 19-joint skeleton at `center` (mid-hip) with explicit ankle positions.
    static func body(
        center: NormalizedPoint,
        kickingAnkle: NormalizedPoint? = nil,
        plantAnkle: NormalizedPoint? = nil,
        kickingFoot: KickingFoot = .right,
        confidence: Double = 0.9,
        trackID: Int? = nil
    ) -> BodyPose {
        let cx = center.x, cy = center.y
        let kick = KickingSideJoints(kickingFoot: kickingFoot)
        func p(_ x: Double, _ y: Double) -> PosePoint { PosePoint(x: x, y: y, confidence: confidence) }
        var joints: [PoseJoint: PosePoint] = [
            .nose: p(cx, cy - torso - 0.06), .leftEye: p(cx - 0.005, cy - torso - 0.065),
            .rightEye: p(cx + 0.005, cy - torso - 0.065), .leftEar: p(cx - 0.01, cy - torso - 0.06),
            .rightEar: p(cx + 0.01, cy - torso - 0.06), .neck: p(cx, cy - torso),
            .leftShoulder: p(cx - 0.02, cy - torso), .rightShoulder: p(cx + 0.02, cy - torso),
            .leftElbow: p(cx - 0.03, cy - torso + 0.07), .rightElbow: p(cx + 0.03, cy - torso + 0.07),
            .leftWrist: p(cx - 0.03, cy - torso + 0.13), .rightWrist: p(cx + 0.03, cy - torso + 0.13),
            .root: p(cx, cy), .leftHip: p(cx - 0.02, cy), .rightHip: p(cx + 0.02, cy),
            .leftKnee: p(cx - 0.02, cy + 0.1), .rightKnee: p(cx + 0.02, cy + 0.1),
            .leftAnkle: p(cx - 0.02, cy + 0.2), .rightAnkle: p(cx + 0.02, cy + 0.2),
        ]
        if let k = kickingAnkle {
            joints[kick.kickingAnkle] = p(k.x, k.y)
            // Keep the knee between hip and ankle so angles stay sensible.
            joints[kick.kickingKnee] = p((k.x + cx) / 2, (k.y + cy) / 2)
        }
        if let a = plantAnkle {
            joints[kick.plantAnkle] = p(a.x, a.y)
            joints[kick.plantKnee] = p((a.x + cx) / 2, (a.y + cy) / 2)
        }
        return BodyPose(joints: joints, trackID: trackID)
    }

    /// Parameters of one synthetic place kick (times in seconds, positions normalized).
    struct KickScript {
        var duration = 2.0
        var frameRate = 60.0
        var startX = 0.3
        var approachStart = 0.6
        var approachEnd = 1.25
        /// Body-center speed during the approach, normalized units per second.
        var approachSpeed = 0.25
        var plantTime = 1.2
        var swingStart = 1.2
        var swingDuration = 0.4
        var swingDistance = 0.4
        /// An extra swing of the kicking foot (start time), e.g. a practice swing.
        var extraSwingStart: Double?
        var kickingFoot: KickingFoot = .right
        /// Kicking-foot motion travels toward +x (right) when 1, toward −x when −1.
        var direction = 1.0

        static let fieldGoal = KickScript()

        /// Longer, faster approach.
        static var kickoff: KickScript {
            var s = KickScript()
            s.duration = 3.0
            s.startX = 0.05
            s.approachStart = 0.4
            s.approachEnd = 2.05
            s.approachSpeed = 0.3
            s.plantTime = 2.0
            s.swingStart = 2.0
            return s
        }

        var expectedContact: Double { swingStart + swingDuration / 2 }
    }

    static func smoothstep(_ s: Double) -> Double {
        let c = min(1, max(0, s))
        return c * c * (3 - 2 * c)
    }

    static func centerX(_ t: Double, _ s: KickScript) -> Double {
        s.startX + s.direction * s.approachSpeed * min(max(t - s.approachStart, 0), s.approachEnd - s.approachStart)
    }

    /// The kicker's body at time `t`.
    static func kickerBody(at t: Double, script s: KickScript, trackID: Int? = nil) -> BodyPose {
        let cx = centerX(t, s)
        let cy = 0.5
        // Plant foot travels with the body until plant, then stays put.
        let plantX = centerX(min(t, s.plantTime), s) + s.direction * 0.05
        // Kicking foot travels with the body, then swings.
        var kickX = centerX(min(t, s.swingStart), s) - s.direction * 0.03
            + s.direction * s.swingDistance * smoothstep((t - s.swingStart) / s.swingDuration)
        if let extra = s.extraSwingStart {
            let phase = (t - extra) / s.swingDuration
            // Out and back: a full swing that returns, peaking at the same speed.
            if phase > 0, phase < 2 {
                kickX += s.direction * s.swingDistance * (phase <= 1 ? smoothstep(phase) : 1 - smoothstep(phase - 1))
            }
        }
        return body(
            center: NormalizedPoint(x: cx, y: cy),
            kickingAnkle: NormalizedPoint(x: kickX, y: cy + 0.2),
            plantAnkle: NormalizedPoint(x: plantX, y: cy + 0.2),
            kickingFoot: s.kickingFoot,
            trackID: trackID
        )
    }

    static func timestamps(_ s: KickScript) -> [Double] {
        let count = Int((s.duration * s.frameRate).rounded())
        return (0...count).map { Double($0) / s.frameRate }
    }

    /// The kicker alone, as a timeline (already "tracked").
    static func timeline(_ s: KickScript) -> KickerPoseTimeline {
        let samples = timestamps(s).enumerated().map { i, t in
            KickerPoseSample(frameIndex: i, timestamp: t, joints: kickerBody(at: t, script: s).joints)
        }
        return KickerPoseTimeline(samples: samples, displayAspectRatio: 1)
    }

    /// Frames as pose detection would return them (no track IDs), with optional extra people.
    static func frames(_ s: KickScript, extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> [PoseFrame] {
        timestamps(s).enumerated().map { i, t in
            PoseFrame(frameIndex: i, timestamp: t, bodies: [kickerBody(at: t, script: s)] + extraBodies(t))
        }
    }

    static func sequence(_ s: KickScript, videoID: UUID = UUID(), extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> PoseSequence {
        PoseSequence(
            videoID: videoID, durationSeconds: s.duration, nominalFrameRate: s.frameRate,
            analysisFrameRate: s.frameRate, orientation: .up, isMirrored: false,
            displayAspectRatio: 1, frames: frames(s, extraBodies: extraBodies), kickerTrackID: nil
        )
    }

    /// A kneeling holder who barely moves.
    static func holder(at t: Double) -> BodyPose {
        body(center: NormalizedPoint(x: 0.75 + 0.001 * sin(t), y: 0.6))
    }

    static func signals(_ s: KickScript, detectWith foot: KickingFoot? = nil) -> PoseSignalSet {
        let processed = PoseTimelineProcessor.process(timeline(s))
        return PoseSignalExtractor.extract(from: processed, kickingFoot: foot ?? s.kickingFoot)
    }
}

/// Returns pre-built sequences instead of running Vision. Records what it was asked.
struct FakePoseExtractor: PoseSequenceExtracting {
    var isAvailable = true
    let makeSequence: @Sendable (UUID) throws -> PoseSequence

    func extract(
        videoURL: URL,
        videoID: UUID,
        sampling: FrameSamplingPlan,
        progress: @escaping @Sendable (Double) -> Void
    ) async throws -> PoseSequence {
        if Task.isCancelled { throw CancellationError() }
        progress(0.5)
        let sequence = try makeSequence(videoID)
        progress(1)
        return sequence
    }
}

func near(_ value: Double?, _ expected: Double, _ tolerance: Double) -> Bool {
    guard let value else { return false }
    return abs(value - expected) <= tolerance
}
