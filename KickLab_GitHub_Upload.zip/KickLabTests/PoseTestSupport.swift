import Foundation
@testable import KickLab

/// Synthetic, deterministic pose data. No video, no person: hand-built skeletons whose
/// motion is known exactly, so phase timing can be checked against ground truth.
enum SyntheticPose {
    /// Torso length (shoulder midpoint to hip midpoint) of every synthetic body.
    static let torso = 0.15

    /// A full 19-joint skeleton at `center` (mid-hip) with explicit ankle positions.
    static func body(
        center: NormalizedPoint,
        kickingAnkle: NormalizedPoint? = nil,
        plantAnkle: NormalizedPoint? = nil,
        kickingFoot: KickingFoot = .right,
        confidence: Double = 0.9,
        trackID: Int? = nil
    ) -> BodyPose {
        let cx = center.x, cy = center.y
        let kick = KickingSideJoints(kickingFoot: kickingFoot)
        func p(_ x: Double, _ y: Double) -> PosePoint { PosePoint(x: x, y: y, confidence: confidence) }
        var joints: [PoseJoint: PosePoint] = [
            .nose: p(cx, cy - torso - 0.06), .leftEye: p(cx - 0.005, cy - torso - 0.065),
            .rightEye: p(cx + 0.005, cy - torso - 0.065), .leftEar: p(cx - 0.01, cy - torso - 0.06),
            .rightEar: p(cx + 0.01, cy - torso - 0.06), .neck: p(cx, cy - torso),
            .leftShoulder: p(cx - 0.02, cy - torso), .rightShoulder: p(cx + 0.02, cy - torso),
            .leftElbow: p(cx - 0.03, cy - torso + 0.07), .rightElbow: p(cx + 0.03, cy - torso + 0.07),
            .leftWrist: p(cx - 0.03, cy - torso + 0.13), .rightWrist: p(cx + 0.03, cy - torso + 0.13),
            .root: p(cx, cy), .leftHip: p(cx - 0.02, cy), .rightHip: p(cx + 0.02, cy),
            .leftKnee: p(cx - 0.02, cy + 0.1), .rightKnee: p(cx + 0.02, cy + 0.1),
            .leftAnkle: p(cx - 0.02, cy + 0.2), .rightAnkle: p(cx + 0.02, cy + 0.2),
        ]
        if let k = kickingAnkle {
            joints[kick.kickingAnkle] = p(k.x, k.y)
            // Keep the knee between hip and ankle so angles stay sensible.
            joints[kick.kickingKnee] = p((k.x + cx) / 2, (k.y + cy) / 2)
        }
        if let a = plantAnkle {
            joints[kick.plantAnkle] = p(a.x, a.y)
            joints[kick.plantKnee] = p((a.x + cx) / 2, (a.y + cy) / 2)
        }
        return BodyPose(joints: joints, trackID: trackID)
    }

    /// Parameters of one synthetic place kick (times in seconds, positions normalized).
    struct KickScript {
        var duration = 2.0
        var frameRate = 60.0
        var startX = 0.3
        var approachStart = 0.6
        var approachEnd = 1.25
        /// Body-center speed during the approach, normalized units per second.
        var approachSpeed = 0.25
        var plantTime = 1.2
        var swingStart = 1.2
        var swingDuration = 0.4
        var swingDistance = 0.4
        /// An extra swing of the kicking foot (start time), e.g. a practice swing.
        var extraSwingStart: Double?
        var kickingFoot: KickingFoot = .right
        /// Kicking-foot motion travels toward +x (right) when 1, toward −x when −1.
        var direction = 1.0

        // Step 8 scenario knobs (defaults keep the Step 7 kick unchanged).

        /// Joint confidence of every point.
        var confidence = 0.9
        /// Torso lean (degrees, positive toward the target) from `leanFrom` onward.
        var torsoLeanDegrees: Double?
        var leanFrom = 1.1
        /// Forces the kicking hip–knee–ankle angle (degrees) from `kneeFrom` onward.
        var kickingKneeAngle: Double?
        var kneeFrom = 1.1
        /// The plant ankle slips forward this far (normalized units), starting two frames
        /// after contact and ending 0.1 s after contact (after Step 7's plant check).
        var plantSlip = 0.0
        /// The kicking foot stops dead at this time (cuts the follow-through short).
        var swingStopsAt: Double?
        /// Deterministic ± jitter added to every joint (normalized units).
        var noise = 0.0

        static let fieldGoal = KickScript()

        /// Longer, faster approach.
        static var kickoff: KickScript {
            var s = KickScript()
            s.duration = 3.0
            s.startX = 0.05
            s.approachStart = 0.4
            s.approachEnd = 2.05
            s.approachSpeed = 0.3
            s.plantTime = 2.0
            s.swingStart = 2.0
            return s
        }

        var expectedContact: Double { swingStart + swingDuration / 2 }
    }

    static func smoothstep(_ s: Double) -> Double {
        let c = min(1, max(0, s))
        return c * c * (3 - 2 * c)
    }

    static func centerX(_ t: Double, _ s: KickScript) -> Double {
        s.startX + s.direction * s.approachSpeed * min(max(t - s.approachStart, 0), s.approachEnd - s.approachStart)
    }

    /// The kicker's body at time `t`.
    static func kickerBody(at t: Double, script s: KickScript, trackID: Int? = nil) -> BodyPose {
        let cx = centerX(t, s)
        let cy = 0.5
        // Plant foot travels with the body until plant, then stays put.
        let plantX = centerX(min(t, s.plantTime), s) + s.direction * 0.05
        // Kicking foot travels with the body, then swings.
        let swingT = min(t, s.swingStopsAt ?? t)
        var kickX = centerX(min(t, s.swingStart), s) - s.direction * 0.03
            + s.direction * s.swingDistance * smoothstep((swingT - s.swingStart) / s.swingDuration)
        if let extra = s.extraSwingStart {
            let phase = (t - extra) / s.swingDuration
            // Out and back: a full swing that returns, peaking at the same speed.
            if phase > 0, phase < 2 {
                kickX += s.direction * s.swingDistance * (phase <= 1 ? smoothstep(phase) : 1 - smoothstep(phase - 1))
            }
        }
        var slippedPlantX = plantX
        if s.plantSlip != 0 {
            let start = s.expectedContact + 2 / s.frameRate
            let end = s.expectedContact + 0.1
            let fraction = min(1, max(0, (t - start) / (end - start)))
            slippedPlantX += s.direction * s.plantSlip * fraction
        }
        var pose = body(
            center: NormalizedPoint(x: cx, y: cy),
            kickingAnkle: NormalizedPoint(x: kickX, y: cy + 0.2),
            plantAnkle: NormalizedPoint(x: slippedPlantX, y: cy + 0.2),
            kickingFoot: s.kickingFoot,
            confidence: s.confidence,
            trackID: trackID
        )
        applyScenario(&pose, at: t, center: NormalizedPoint(x: cx, y: cy), script: s)
        return pose
    }

    /// Torso lean, forced knee angle and noise.
    static func applyScenario(_ pose: inout BodyPose, at t: Double, center: NormalizedPoint, script s: KickScript) {
        if let degrees = s.torsoLeanDegrees, t >= s.leanFrom - 1e-9 {
            let theta = degrees * .pi / 180
            let dx = s.direction * torso * sin(theta)
            let dy = torso * (1 - cos(theta))
            let upper: [PoseJoint] = [.nose, .leftEye, .rightEye, .leftEar, .rightEar, .neck, .leftShoulder, .rightShoulder,
                                      .leftElbow, .rightElbow, .leftWrist, .rightWrist]
            for joint in upper {
                pose.joints[joint]?.x += dx
                pose.joints[joint]?.y += dy
            }
        }
        if let angle = s.kickingKneeAngle, t >= s.kneeFrom - 1e-9 {
            let sides = KickingSideJoints(kickingFoot: s.kickingFoot)
            if let hip = pose.joints[sides.kickingHip], let ankle = pose.joints[sides.kickingAnkle] {
                let vx = ankle.x - hip.x
                let vy = ankle.y - hip.y
                let length = (vx * vx + vy * vy).squareRoot()
                let half = length / 2
                let offset = half / tan(angle * .pi / 360)
                var nx = -vy / length
                var ny = vx / length
                if nx * s.direction < 0 { nx = -nx; ny = -ny }
                pose.joints[sides.kickingKnee] = PosePoint(
                    x: (hip.x + ankle.x) / 2 + offset * nx, y: (hip.y + ankle.y) / 2 + offset * ny, confidence: s.confidence
                )
            }
        }
        if s.noise > 0 {
            let frame = Double((t * 1000).rounded())
            for (j, joint) in PoseJoint.allCases.enumerated() {
                let seed = frame * 12.9898 + Double(j) * 78.233
                let rx = sin(seed) * 43758.5453
                let ry = sin(seed + 1.618) * 24634.6345
                pose.joints[joint]?.x += s.noise * (2 * (rx - rx.rounded(.down)) - 1)
                pose.joints[joint]?.y += s.noise * (2 * (ry - ry.rounded(.down)) - 1)
            }
        }
        pose = BodyPose(joints: pose.joints, trackID: pose.trackID)
    }

    static func timestamps(_ s: KickScript) -> [Double] {
        let count = Int((s.duration * s.frameRate).rounded())
        return (0...count).map { Double($0) / s.frameRate }
    }

    /// The kicker alone, as a timeline (already "tracked").
    static func timeline(_ s: KickScript) -> KickerPoseTimeline {
        let samples = timestamps(s).enumerated().map { i, t in
            KickerPoseSample(frameIndex: i, timestamp: t, joints: kickerBody(at: t, script: s).joints)
        }
        return KickerPoseTimeline(samples: samples, displayAspectRatio: 1)
    }

    /// Frames as pose detection would return them (no track IDs), with optional extra people.
    static func frames(_ s: KickScript, extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> [PoseFrame] {
        timestamps(s).enumerated().map { i, t in
            PoseFrame(frameIndex: i, timestamp: t, bodies: [kickerBody(at: t, script: s)] + extraBodies(t))
        }
    }

    static func sequence(_ s: KickScript, videoID: UUID = UUID(), extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> PoseSequence {
        PoseSequence(
            videoID: videoID, durationSeconds: s.duration, nominalFrameRate: s.frameRate,
            analysisFrameRate: s.frameRate, orientation: .up, isMirrored: false,
            displayAspectRatio: 1, frames: frames(s, extraBodies: extraBodies), kickerTrackID: nil
        )
    }

    /// A kneeling holder who barely moves.
    static func holder(at t: Double) -> BodyPose {
        body(center: NormalizedPoint(x: 0.75 + 0.001 * sin(t), y: 0.6))
    }

    static func signals(_ s: KickScript, detectWith foot: KickingFoot? = nil) -> PoseSignalSet {
        let processed = PoseTimelineProcessor.process(timeline(s))
        return PoseSignalExtractor.extract(from: processed, kickingFoot: foot ?? s.kickingFoot)
    }
}

/// Returns pre-built sequences instead of running Vision. Records what it was asked.
struct FakePoseExtractor: PoseSequenceExtracting {
    var isAvailable = true
    let makeSequence: @Sendable (UUID) throws -> PoseSequence

    func extract(
        videoURL: URL,
        videoID: UUID,
        sampling: FrameSamplingPlan,
        progress: @escaping @Sendable (Double) -> Void
    ) async throws -> PoseSequence {
        if Task.isCancelled { throw CancellationError() }
        progress(0.5)
        let sequence = try makeSequence(videoID)
        progress(1)
        return sequence
    }
}

func near(_ value: Double?, _ expected: Double, _ tolerance: Double) -> Bool {
    guard let value else { return false }
    return abs(value - expected) <= tolerance
}

/// Runs the Step 7 chain (process → signals → phases) and the Step 8 analyzer on a
/// synthetic kick — the same steps `KickAnalysisPipeline` performs after tracking.
enum SyntheticBiomechanics {
    static let seed = UUID(uuidString: "00000000-0000-0000-0000-0000000000A8")!

    static func analyze(
        _ script: SyntheticPose.KickScript,
        kickType: KickType = .fieldGoal,
        analyzeAs foot: KickingFoot? = nil,
        cameraAngle: VideoAngleType = .side,
        timeline: KickerPoseTimeline? = nil,
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles()
    ) -> KickBiomechanicsResult {
        let processed = PoseTimelineProcessor.process(timeline ?? SyntheticPose.timeline(script))
        let kickingFoot = foot ?? script.kickingFoot
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: kickingFoot)
        let phases = KickPhaseDetector.detect(signals, kickType: kickType)
        return KickBiomechanicsAnalyzer.analyze(
            timeline: processed, signals: signals, phases: phases,
            context: BiomechanicsContext(kickType: kickType, kickingFoot: kickingFoot, cameraAngle: cameraAngle),
            profiles: profiles, idSeed: seed
        )
    }
}
