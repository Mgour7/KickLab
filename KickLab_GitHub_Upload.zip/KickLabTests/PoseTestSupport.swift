import Foundation
@testable import KickLab

/// Synthetic, deterministic pose data. No video, no person: hand-built skeletons whose
/// motion is known exactly, so phase timing can be checked against ground truth.
enum SyntheticPose {
    /// Torso length (shoulder midpoint to hip midpoint) of every synthetic body.
    static let torso = 0.15

    /// A full 19-joint skeleton at `center` (mid-hip) with explicit ankle positions.
    static func body(
        center: NormalizedPoint,
        kickingAnkle: NormalizedPoint? = nil,
        plantAnkle: NormalizedPoint? = nil,
        kickingFoot: KickingFoot = .right,
        confidence: Double = 0.9,
        trackID: Int? = nil
    ) -> BodyPose {
        let cx = center.x, cy = center.y
        let kick = KickingSideJoints(kickingFoot: kickingFoot)
        func p(_ x: Double, _ y: Double) -> PosePoint { PosePoint(x: x, y: y, confidence: confidence) }
        var joints: [PoseJoint: PosePoint] = [
            .nose: p(cx, cy - torso - 0.06), .leftEye: p(cx - 0.005, cy - torso - 0.065),
            .rightEye: p(cx + 0.005, cy - torso - 0.065), .leftEar: p(cx - 0.01, cy - torso - 0.06),
            .rightEar: p(cx + 0.01, cy - torso - 0.06), .neck: p(cx, cy - torso),
            .leftShoulder: p(cx - 0.02, cy - torso), .rightShoulder: p(cx + 0.02, cy - torso),
            .leftElbow: p(cx - 0.03, cy - torso + 0.07), .rightElbow: p(cx + 0.03, cy - torso + 0.07),
            .leftWrist: p(cx - 0.03, cy - torso + 0.13), .rightWrist: p(cx + 0.03, cy - torso + 0.13),
            .root: p(cx, cy), .leftHip: p(cx - 0.02, cy), .rightHip: p(cx + 0.02, cy),
            .leftKnee: p(cx - 0.02, cy + 0.1), .rightKnee: p(cx + 0.02, cy + 0.1),
            .leftAnkle: p(cx - 0.02, cy + 0.2), .rightAnkle: p(cx + 0.02, cy + 0.2),
        ]
        if let k = kickingAnkle {
            joints[kick.kickingAnkle] = p(k.x, k.y)
            // Keep the knee between hip and ankle so angles stay sensible.
            joints[kick.kickingKnee] = p((k.x + cx) / 2, (k.y + cy) / 2)
        }
        if let a = plantAnkle {
            joints[kick.plantAnkle] = p(a.x, a.y)
            joints[kick.plantKnee] = p((a.x + cx) / 2, (a.y + cy) / 2)
        }
        return BodyPose(joints: joints, trackID: trackID)
    }

    /// Parameters of one synthetic place kick (times in seconds, positions normalized).
    struct KickScript {
        var duration = 2.0
        var frameRate = 60.0
        var startX = 0.3
        var approachStart = 0.6
        var approachEnd = 1.25
        /// Body-center speed during the approach, normalized units per second.
        var approachSpeed = 0.25
        var plantTime = 1.2
        var swingStart = 1.2
        var swingDuration = 0.4
        var swingDistance = 0.4
        /// An extra swing of the kicking foot (start time), e.g. a practice swing.
        var extraSwingStart: Double?
        var kickingFoot: KickingFoot = .right
        /// Kicking-foot motion travels toward +x (right) when 1, toward −x when −1.
        var direction = 1.0

        // Step 8 scenario knobs (defaults keep the Step 7 kick unchanged).

        /// Joint confidence of every point.
        var confidence = 0.9
        /// Torso lean (degrees, positive toward the target) from `leanFrom` onward.
        var torsoLeanDegrees: Double?
        var leanFrom = 1.1
        /// Forces the kicking hip–knee–ankle angle (degrees) from `kneeFrom` onward.
        var kickingKneeAngle: Double?
        var kneeFrom = 1.1
        /// The plant ankle slips forward this far (normalized units), starting two frames
        /// after contact and ending 0.1 s after contact (after Step 7's plant check).
        var plantSlip = 0.0
        /// The kicking foot stops dead at this time (cuts the follow-through short).
        var swingStopsAt: Double?
        /// Deterministic ± jitter added to every joint (normalized units).
        var noise = 0.0

        // Step 12B scenario knobs (defaults keep earlier kicks unchanged).

        /// When set, the plant foot STEPS into the plant over this many seconds (still on
        /// the ground behind the body before, then swinging forward and landing at
        /// `plantTime`) instead of gliding along with the body.
        var plantStepDuration: Double?
        /// The plant foot rolls and lifts (forward and up, normalized units) starting one
        /// frame before contact and finishing 0.1 s after: a planted foot that is moving
        /// AT contact, as when a kicker hops through the strike.
        var plantLiftAtContact = 0.0
        /// How long before contact the lift starts (default: one frame).
        var plantLiftLead: Double?

        // Step 12C scenario knobs (defaults keep earlier kicks unchanged).

        /// A fast backswing just before the forward swing: the kicking foot moves back and
        /// up by this much (normalized units) and returns over `backswingDuration`, ending
        /// at `swingStart`. A large one is FASTER in the image than the strike itself.
        var backswingDistance = 0.0
        var backswingDuration = 0.2
        /// How far the foot rises during the backswing (default: half the distance back).
        var backswingLift: Double?
        /// Single-frame kicking-ankle displacements (forward, normalized units) at these
        /// times: pose glitches that create false speed spikes.
        var kickingAnkleSpikes: [Double] = []
        var spikeSize = 0.0

        static let fieldGoal = KickScript()

        /// Step 12B: modeled on a real failing clip (6.5 s, 30 fps, side view, right-footed,
        /// still setup for about a second, approach ≈ 1.3 s, contact ≈ 2.35 s, then standing
        /// after the kick), with a stepping plant foot, Vision-like jitter and a plant foot
        /// that rolls forward through the strike.
        static var realWorld30fps: KickScript {
            var s = KickScript()
            s.duration = 6.5
            s.frameRate = 30
            s.startX = 0.12
            s.approachStart = 1.0
            s.approachEnd = 2.25
            s.approachSpeed = 0.3
            s.plantTime = 2.2
            s.swingStart = 2.15
            s.swingDuration = 0.4
            s.confidence = 0.78
            s.plantStepDuration = 0.3
            s.plantLiftAtContact = 0.02
            s.noise = 0.004
            return s
        }

        /// Step 12C: the failure pattern measured on the real 30 fps clip. The kicking foot
        /// whips up and back as the plant foot lands (faster in the image than the strike),
        /// slows as it reverses at the top, passes the plant foot, and strikes ≈0.17 s after
        /// the backswing peak. A global speed peak picks the backswing.
        static var backswingPattern: KickScript {
            var s = realWorld30fps
            s.approachEnd = 2.4
            s.plantTime = 2.38
            s.plantStepDuration = 0.3
            s.plantLiftAtContact = 0
            s.swingStart = 2.4
            s.swingDuration = 0.2
            s.swingDistance = 0.4
            s.backswingDistance = 0.05
            s.backswingLift = 0.35
            s.backswingDuration = 0.2
            return s
        }

        /// Longer, faster approach.
        static var kickoff: KickScript {
            var s = KickScript()
            s.duration = 3.0
            s.startX = 0.05
            s.approachStart = 0.4
            s.approachEnd = 2.05
            s.approachSpeed = 0.3
            s.plantTime = 2.0
            s.swingStart = 2.0
            return s
        }

        var expectedContact: Double { swingStart + swingDuration / 2 }
    }

    static func smoothstep(_ s: Double) -> Double {
        let c = min(1, max(0, s))
        return c * c * (3 - 2 * c)
    }

    static func centerX(_ t: Double, _ s: KickScript) -> Double {
        s.startX + s.direction * s.approachSpeed * min(max(t - s.approachStart, 0), s.approachEnd - s.approachStart)
    }

    /// The kicker's body at time `t`.
    static func kickerBody(at t: Double, script s: KickScript, trackID: Int? = nil) -> BodyPose {
        let cx = centerX(t, s)
        let cy = 0.5
        // Plant foot travels with the body until plant, then stays put.
        var plantX = centerX(min(t, s.plantTime), s) + s.direction * 0.05
        var plantY = cy + 0.2
        if let step = s.plantStepDuration {
            // Stance behind the body, then a step that lands at plantTime.
            let lift = s.plantTime - step
            let behind = centerX(min(t, lift), s) - s.direction * 0.05
            let landing = centerX(s.plantTime, s) + s.direction * 0.05
            let from = centerX(lift, s) - s.direction * 0.05
            if t <= lift {
                plantX = behind
            } else if t < s.plantTime {
                let f = smoothstep((t - lift) / step)
                plantX = from + (landing - from) * f
                plantY -= 0.03 * sin(.pi * (t - lift) / step)
            } else {
                plantX = landing
            }
        }
        if s.plantLiftAtContact != 0 {
            let start = s.expectedContact - (s.plantLiftLead ?? 1 / s.frameRate)
            let f = smoothstep((t - start) / 0.1)
            plantX += s.direction * s.plantLiftAtContact * f
            plantY -= s.plantLiftAtContact * f
        }
        // Kicking foot travels with the body, then swings.
        let swingT = min(t, s.swingStopsAt ?? t)
        var kickX = centerX(min(t, s.swingStart), s) - s.direction * 0.03
            + s.direction * s.swingDistance * smoothstep((swingT - s.swingStart) / s.swingDuration)
        if let extra = s.extraSwingStart {
            let phase = (t - extra) / s.swingDuration
            // Out and back: a full swing that returns, peaking at the same speed.
            if phase > 0, phase < 2 {
                kickX += s.direction * s.swingDistance * (phase <= 1 ? smoothstep(phase) : 1 - smoothstep(phase - 1))
            }
        }
        var kickY = cy + 0.2
        if s.backswingDistance != 0 || (s.backswingLift ?? 0) != 0 {
            let start = s.swingStart - s.backswingDuration
            if t > start, t < s.swingStart {
                let bump = sin(.pi * (t - start) / s.backswingDuration)
                kickX -= s.direction * s.backswingDistance * bump
                kickY -= (s.backswingLift ?? 0.5 * s.backswingDistance) * bump
            }
        }
        for spike in s.kickingAnkleSpikes where abs(t - spike) < 0.5 / s.frameRate {
            kickX += s.direction * s.spikeSize
        }
        var slippedPlantX = plantX
        if s.plantSlip != 0 {
            let start = s.expectedContact + 2 / s.frameRate
            let end = s.expectedContact + 0.1
            let fraction = min(1, max(0, (t - start) / (end - start)))
            slippedPlantX += s.direction * s.plantSlip * fraction
        }
        var pose = body(
            center: NormalizedPoint(x: cx, y: cy),
            kickingAnkle: NormalizedPoint(x: kickX, y: kickY),
            plantAnkle: NormalizedPoint(x: slippedPlantX, y: plantY),
            kickingFoot: s.kickingFoot,
            confidence: s.confidence,
            trackID: trackID
        )
        applyScenario(&pose, at: t, center: NormalizedPoint(x: cx, y: cy), script: s)
        return pose
    }

    /// Torso lean, forced knee angle and noise.
    static func applyScenario(_ pose: inout BodyPose, at t: Double, center: NormalizedPoint, script s: KickScript) {
        if let degrees = s.torsoLeanDegrees, t >= s.leanFrom - 1e-9 {
            let theta = degrees * .pi / 180
            let dx = s.direction * torso * sin(theta)
            let dy = torso * (1 - cos(theta))
            let upper: [PoseJoint] = [.nose, .leftEye, .rightEye, .leftEar, .rightEar, .neck, .leftShoulder, .rightShoulder,
                                      .leftElbow, .rightElbow, .leftWrist, .rightWrist]
            for joint in upper {
                pose.joints[joint]?.x += dx
                pose.joints[joint]?.y += dy
            }
        }
        if let angle = s.kickingKneeAngle, t >= s.kneeFrom - 1e-9 {
            let sides = KickingSideJoints(kickingFoot: s.kickingFoot)
            if let hip = pose.joints[sides.kickingHip], let ankle = pose.joints[sides.kickingAnkle] {
                let vx = ankle.x - hip.x
                let vy = ankle.y - hip.y
                let length = (vx * vx + vy * vy).squareRoot()
                let half = length / 2
                let offset = half / tan(angle * .pi / 360)
                var nx = -vy / length
                var ny = vx / length
                if nx * s.direction < 0 { nx = -nx; ny = -ny }
                pose.joints[sides.kickingKnee] = PosePoint(
                    x: (hip.x + ankle.x) / 2 + offset * nx, y: (hip.y + ankle.y) / 2 + offset * ny, confidence: s.confidence
                )
            }
        }
        if s.noise > 0 {
            let frame = Double((t * 1000).rounded())
            for (j, joint) in PoseJoint.allCases.enumerated() {
                let seed = frame * 12.9898 + Double(j) * 78.233
                let rx = sin(seed) * 43758.5453
                let ry = sin(seed + 1.618) * 24634.6345
                pose.joints[joint]?.x += s.noise * (2 * (rx - rx.rounded(.down)) - 1)
                pose.joints[joint]?.y += s.noise * (2 * (ry - ry.rounded(.down)) - 1)
            }
        }
        pose = BodyPose(joints: pose.joints, trackID: pose.trackID)
    }

    static func timestamps(_ s: KickScript) -> [Double] {
        let count = Int((s.duration * s.frameRate).rounded())
        return (0...count).map { Double($0) / s.frameRate }
    }

    /// Vision-style label error: the left/right knees and ankles swapped at these times.
    static func swapLegs(_ timeline: inout KickerPoseTimeline, at times: [Double]) {
        for i in timeline.samples.indices where times.contains(where: { abs($0 - timeline.samples[i].timestamp) < 1e-6 }) {
            for (a, b) in [(PoseJoint.leftAnkle, PoseJoint.rightAnkle), (.leftKnee, .rightKnee)] {
                let x = timeline.samples[i].joints[a]
                timeline.samples[i].joints[a] = timeline.samples[i].joints[b]
                timeline.samples[i].joints[b] = x
            }
        }
    }

    /// Vision-style error: both ankles (and knees) reported on the `onto` leg at these times.
    static func collapseLegs(_ timeline: inout KickerPoseTimeline, onto: KickingFoot, at times: [Double]) {
        let (from, to): (PoseJoint, PoseJoint) = onto == .right ? (.leftAnkle, .rightAnkle) : (.rightAnkle, .leftAnkle)
        let (fromKnee, toKnee): (PoseJoint, PoseJoint) = onto == .right ? (.leftKnee, .rightKnee) : (.rightKnee, .leftKnee)
        for i in timeline.samples.indices where times.contains(where: { abs($0 - timeline.samples[i].timestamp) < 1e-6 }) {
            timeline.samples[i].joints[from] = timeline.samples[i].joints[to]
            timeline.samples[i].joints[fromKnee] = timeline.samples[i].joints[toKnee]
        }
    }

    /// Only the samples from `start` to `end` (a clip that starts late or ends early).
    static func trim(_ timeline: KickerPoseTimeline, from start: Double, to end: Double) -> KickerPoseTimeline {
        var t = timeline
        t.samples = t.samples.filter { $0.timestamp >= start - 1e-9 && $0.timestamp <= end + 1e-9 }
        return t
    }

    /// The legs hidden (knees and ankles unavailable) from `start` to `end`.
    static func occludeLegs(_ timeline: inout KickerPoseTimeline, from start: Double, to end: Double) {
        for i in timeline.samples.indices where timeline.samples[i].timestamp >= start - 1e-9 && timeline.samples[i].timestamp <= end + 1e-9 {
            for joint in [PoseJoint.leftKnee, .rightKnee, .leftAnkle, .rightAnkle] { timeline.samples[i].joints[joint] = .unavailable }
        }
    }

    /// The time of the analyzed sample nearest `t`.
    static func sampleTime(_ s: KickScript, near t: Double) -> Double {
        (t * s.frameRate).rounded() / s.frameRate
    }

    /// The kicker alone, as a timeline (already "tracked").
    static func timeline(_ s: KickScript) -> KickerPoseTimeline {
        let samples = timestamps(s).enumerated().map { i, t in
            KickerPoseSample(frameIndex: i, timestamp: t, joints: kickerBody(at: t, script: s).joints)
        }
        return KickerPoseTimeline(samples: samples, displayAspectRatio: 1)
    }

    /// Frames as pose detection would return them (no track IDs), with optional extra people.
    static func frames(_ s: KickScript, extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> [PoseFrame] {
        timestamps(s).enumerated().map { i, t in
            PoseFrame(frameIndex: i, timestamp: t, bodies: [kickerBody(at: t, script: s)] + extraBodies(t))
        }
    }

    static func sequence(_ s: KickScript, videoID: UUID = UUID(), extraBodies: (Double) -> [BodyPose] = { _ in [] }) -> PoseSequence {
        PoseSequence(
            videoID: videoID, durationSeconds: s.duration, nominalFrameRate: s.frameRate,
            analysisFrameRate: s.frameRate, orientation: .up, isMirrored: false,
            displayAspectRatio: 1, frames: frames(s, extraBodies: extraBodies), kickerTrackID: nil
        )
    }

    /// A kneeling holder who barely moves.
    static func holder(at t: Double) -> BodyPose {
        body(center: NormalizedPoint(x: 0.75 + 0.001 * sin(t), y: 0.6))
    }

    static func signals(_ s: KickScript, detectWith foot: KickingFoot? = nil) -> PoseSignalSet {
        let processed = PoseTimelineProcessor.process(timeline(s))
        return PoseSignalExtractor.extract(from: processed, kickingFoot: foot ?? s.kickingFoot)
    }
}

/// Returns pre-built sequences instead of running Vision. Records what it was asked.
struct FakePoseExtractor: PoseSequenceExtracting {
    var isAvailable = true
    let makeSequence: @Sendable (UUID) throws -> PoseSequence

    func extract(
        videoURL: URL,
        videoID: UUID,
        sampling: FrameSamplingPlan,
        progress: @escaping @Sendable (Double) -> Void
    ) async throws -> PoseSequence {
        if Task.isCancelled { throw CancellationError() }
        progress(0.5)
        let sequence = try makeSequence(videoID)
        progress(1)
        return sequence
    }
}

func near(_ value: Double?, _ expected: Double, _ tolerance: Double) -> Bool {
    guard let value else { return false }
    return abs(value - expected) <= tolerance
}

/// Runs the Step 7 chain (process → signals → phases) and the Step 8 analyzer on a
/// synthetic kick — the same steps `KickAnalysisPipeline` performs after tracking.
enum SyntheticBiomechanics {
    static let seed = UUID(uuidString: "00000000-0000-0000-0000-0000000000A8")!

    static func analyze(
        _ script: SyntheticPose.KickScript,
        kickType: KickType = .fieldGoal,
        analyzeAs foot: KickingFoot? = nil,
        cameraAngle: VideoAngleType = .side,
        timeline: KickerPoseTimeline? = nil,
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles()
    ) -> KickBiomechanicsResult {
        let processed = PoseTimelineProcessor.process(timeline ?? SyntheticPose.timeline(script))
        let kickingFoot = foot ?? script.kickingFoot
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: kickingFoot)
        let phases = KickPhaseDetector.detect(signals, kickType: kickType)
        return KickBiomechanicsAnalyzer.analyze(
            timeline: processed, signals: signals, phases: phases,
            context: BiomechanicsContext(kickType: kickType, kickingFoot: kickingFoot, cameraAngle: cameraAngle),
            profiles: profiles, idSeed: seed
        )
    }
}
