import Foundation
@testable import KickLab

/// Step 12E: synthetic kicks filmed from BEHIND, IN FRONT or DIAGONALLY, made by
/// projecting a simple 3D runner/kicker through a pinhole camera — so the image shows
/// real perspective (the kicker shrinks while running away, the leg swing is vertical in
/// the image) instead of side-view geometry with a different label.
///
/// World: X sideways, Y up (m), Z along the field. Leg kinematics in the athlete's
/// sagittal plane: thigh angle from vertical (+ forward) and knee flexion. Ground truth
/// times are exact. Not a substitute for real rear-view footage.
enum DepthViewSynthetic {
    enum Camera: Equatable { case behind, inFront, diagonalBehind }

    struct Script {
        var camera: Camera = .behind
        var kickingFoot: KickingFoot = .right
        var frameRate = 30.0
        var duration = 2.6
        var runStart = 0.5
        var plantTime = 1.4
        var contactTime = 1.55
        /// Video stored mirrored (front-camera style): the image is flipped left-right.
        var mirrored = false
        /// Pose detection labels the body as if it faced the other way (every left/right
        /// label exchanged).
        var labelsFlippedByDetector = false
        var legConfidence = 0.85
        /// Deterministic joint jitter (normalized units).
        var jitter = 0.0
        /// Kicking ankle hidden behind the plant leg for these times.
        var kickingAnkleHidden: [Double] = []
        /// The kicking and plant leg labels exchanged at these times (legs crossing).
        var legSwapTimes: [Double] = []
        /// A standing kick: no run-up.
        var noRunUp = false
        /// Step 12F: the kicking leg's swing plane, turned this many degrees toward the
        /// plant side (an angled strike).
        var swingTurnDegrees = 25.0

        var expectedContact: Double { contactTime }
    }

    // Body dimensions (m).
    static let thigh = 0.45, shank = 0.45, hipHeight = 0.95, torsoLength = 0.5
    static let hipHalfWidth = 0.11, shoulderHalfWidth = 0.19
    static let cameraHeight = 1.2, focal = 1.4, aspect = 9.0 / 16.0

    static func smooth(_ x: Double) -> Double { let s = min(1, max(0, x)); return s * s * (3 - 2 * s) }
    static func lerp(_ a: Double, _ b: Double, _ t0: Double, _ t1: Double, _ t: Double) -> Double {
        a + (b - a) * smooth((t - t0) / (t1 - t0))
    }

    /// Distance run along the approach direction by time t (m).
    static func travelled(_ t: Double, _ s: Script) -> Double {
        if s.noRunUp { return 0 }
        // Speed: 0 → 3.2 m/s over 0.3 s from runStart, braking from plant−0.1 to plant+0.25,
        // then a slow drift 0.25 m/s, stopping by plant+0.8.
        func speed(_ u: Double) -> Double {
            if u < s.runStart { return 0 }
            let up = 3.2 * smooth((u - s.runStart) / 0.3)
            if u < s.plantTime - 0.1 { return up }
            if u < s.plantTime + 0.25 { return lerp(3.2, 0.25, s.plantTime - 0.1, s.plantTime + 0.25, u) }
            return lerp(0.25, 0, s.plantTime + 0.25, s.plantTime + 0.8, u)
        }
        var d = 0.0, u = 0.0
        let step = 0.002
        while u < t { d += speed(u) * step; u += step }
        return d
    }

    struct Pose3 { var joints: [PoseJoint: (x: Double, y: Double, z: Double)] }

    static func world(_ t: Double, _ s: Script) -> Pose3 {
        let run = s.camera == .diagonalBehind ? 40.0 * .pi / 180 : 0
        // Direction of travel (unit, XZ) and the athlete's anatomical right.
        let fz = s.camera == .inFront ? -cos(run) : cos(run)
        let fx = sin(run)
        let rx = fz, rz = -fx
        // The camera stands at the origin looking down the field (+Z). From behind, the
        // kicker starts 3.5 m away and runs away; in front, starts 10 m away and runs
        // toward the camera; diagonally, runs away at 40° across the frame.
        let start: (x: Double, z: Double) = s.camera == .inFront ? (0, 10) : (s.camera == .diagonalBehind ? -1.2 : 0, 3.5)
        let d = travelled(t, s)
        let hip = (x: start.x + fx * d, y: hipHeight, z: start.z + fz * d)
        func at(_ forward: Double, _ up: Double, _ right: Double, from p: (x: Double, y: Double, z: Double)) -> (x: Double, y: Double, z: Double) {
            (p.x + fx * forward + rx * right, p.y + up, p.z + fz * forward + rz * right)
        }
        let kickRight: Double = s.kickingFoot == .right ? 1 : -1
        var j: [PoseJoint: (x: Double, y: Double, z: Double)] = [:]
        j[.leftHip] = at(0, 0, -hipHalfWidth, from: hip)
        j[.rightHip] = at(0, 0, hipHalfWidth, from: hip)
        j[.root] = hip
        let lean = 0.06
        j[.leftShoulder] = at(lean, torsoLength, -shoulderHalfWidth, from: hip)
        j[.rightShoulder] = at(lean, torsoLength, shoulderHalfWidth, from: hip)
        j[.neck] = at(lean, torsoLength, 0, from: hip)
        j[.nose] = at(lean + 0.08, torsoLength + 0.2, 0, from: hip)
        j[.leftEye] = at(lean + 0.07, torsoLength + 0.23, -0.03, from: hip)
        j[.rightEye] = at(lean + 0.07, torsoLength + 0.23, 0.03, from: hip)
        j[.leftEar] = at(lean, torsoLength + 0.21, -0.07, from: hip)
        j[.rightEar] = at(lean, torsoLength + 0.21, 0.07, from: hip)
        j[.leftElbow] = at(lean, torsoLength - 0.28, -0.24, from: hip)
        j[.rightElbow] = at(lean, torsoLength - 0.28, 0.24, from: hip)
        j[.leftWrist] = at(lean + 0.05, torsoLength - 0.52, -0.26, from: hip)
        j[.rightWrist] = at(lean + 0.05, torsoLength - 0.52, 0.26, from: hip)

        func leg(thigh θ: Double, flex φ: Double, side: Double) -> (knee: (x: Double, y: Double, z: Double), ankle: (x: Double, y: Double, z: Double)) {
            let h = at(0, 0, side * hipHalfWidth, from: hip)
            let a = θ * .pi / 180, b = (θ - φ) * .pi / 180
            let knee = at(thigh * sin(a), -thigh * cos(a), 0, from: h)
            let ankle = at(shank * sin(b), -shank * cos(b), 0, from: knee)
            return (knee, ankle)
        }
        // Running stride: alternating legs, 3.2 strides/s.
        let ω = 2 * .pi * 1.6
        func stride(_ phase: Double, _ t: Double) -> (Double, Double) {
            let u = t - s.runStart
            guard u > 0, !s.noRunUp else { return (0, 0) }
            let ramp = smooth(u / 0.3)
            let θ = 28 * sin(ω * u + phase) * ramp
            let φ = 70 * max(0, -cos(ω * u + phase)) * ramp
            return (θ, φ)
        }
        // Kicking leg: stride, then backswing → downswing → contact → follow-through rise
        // → down. Step 12F: the ball is struck DURING knee extension (knee ~40° flexed),
        // and the knee keeps extending for ~0.08 s after contact — as kicking biomechanics
        // describe and as the human-reviewed real rear clip showed. (Step 12E's version
        // struck the ball after the leg had straightened, an assumption the real clip
        // refuted.) The swing plane is turned 25° across the body (an angled, soccer-style
        // strike), so the 2D knee angle never collapses to an impossible fold.
        let c = s.contactTime
        var (kθ, kφ) = stride(0, t)
        var kickSwing = false
        if t >= s.plantTime - 0.12 {
            kickSwing = true
            let (sθ, sφ) = stride(0, s.plantTime - 0.12)
            if t < c - 0.1 { kθ = lerp(sθ, -25, s.plantTime - 0.12, c - 0.1, t); kφ = lerp(sφ, 105, s.plantTime - 0.12, c - 0.1, t) }
            else if t < c { kθ = lerp(-25, 15, c - 0.1, c, t); kφ = lerp(105, 40, c - 0.1, c, t) }
            else if t < c + 0.08 { kθ = lerp(15, 35, c, c + 0.08, t); kφ = lerp(40, 8, c, c + 0.08, t) }
            else if t < c + 0.3 { kθ = lerp(35, 80, c + 0.08, c + 0.3, t); kφ = 8 }
            else { kθ = lerp(80, 5, c + 0.3, c + 0.75, t); kφ = lerp(8, 0, c + 0.3, c + 0.75, t) }
        }
        let kick: (knee: (x: Double, y: Double, z: Double), ankle: (x: Double, y: Double, z: Double))
        if kickSwing {
            // Swing direction turned 25° toward the plant side.
            let turn = s.swingTurnDegrees * .pi / 180 * (-kickRight)
            let sx = fx * cos(turn) + rx * sin(turn), sz = fz * cos(turn) + rz * sin(turn)
            let h = at(0, 0, kickRight * hipHalfWidth, from: hip)
            let a = kθ * .pi / 180, b = (kθ - kφ) * .pi / 180
            let knee = (h.x + sx * thigh * sin(a), h.y - thigh * cos(a), h.z + sz * thigh * sin(a))
            let ankle = (knee.0 + sx * shank * sin(b), knee.1 - shank * cos(b), knee.2 + sz * shank * sin(b))
            kick = (knee, ankle)
        } else {
            kick = leg(thigh: kθ, flex: kφ, side: kickRight)
        }
        // Plant leg: stride until it swings to its landing spot, then planted (fixed in the
        // world) from plantTime.
        let (pθ, pφ) = stride(.pi, t)
        var plant = leg(thigh: pθ, flex: pφ, side: -kickRight)
        if !s.noRunUp, t >= s.plantTime - 0.15 {
            let landingHip = travelled(s.plantTime, s)
            let spot = (x: start.x + fx * (landingHip + 0.3) + rx * (-kickRight * 0.24), y: 0.05,
                        z: start.z + fz * (landingHip + 0.3) + rz * (-kickRight * 0.24))
            if t < s.plantTime {
                let from = leg(thigh: stride(.pi, s.plantTime - 0.15).0, flex: stride(.pi, s.plantTime - 0.15).1, side: -kickRight).ankle
                let k = smooth((t - (s.plantTime - 0.15)) / 0.15)
                plant.ankle = (from.x + (spot.x - from.x) * k, from.y + (spot.y - from.y) * k + 0.08 * sin(.pi * k), from.z + (spot.z - from.z) * k)
            } else if t < c + 0.55 {
                plant.ankle = spot
            }
            let h = at(0, 0, -kickRight * hipHalfWidth, from: hip)
            plant.knee = ((h.x + plant.ankle.x) / 2 + fx * 0.08, (h.y + plant.ankle.y) / 2, (h.z + plant.ankle.z) / 2 + fz * 0.08)
        } else if s.noRunUp {
            plant = leg(thigh: 0, flex: 0, side: -kickRight)
        }
        let kickSide = KickingSideJoints(kickingFoot: s.kickingFoot)
        j[kickSide.kickingKnee] = kick.knee
        j[kickSide.kickingAnkle] = kick.ankle
        j[kickSide.plantKnee] = plant.knee
        j[kickSide.plantAnkle] = plant.ankle
        return Pose3(joints: j)
    }

    /// Pinhole camera at the origin, 1.2 m high, looking along +Z (image x to the right
    /// = +X, image y down).
    static func project(_ p: (x: Double, y: Double, z: Double), _ s: Script) -> (x: Double, y: Double)? {
        guard p.z > 0.5 else { return nil }
        let x = 0.5 + (focal * p.x / p.z) / aspect
        let y = 0.5 + focal * (cameraHeight - p.y) / p.z
        return (s.mirrored ? 1 - x : x, y)
    }

    static func timestamps(_ s: Script) -> [Double] {
        let n = Int((s.duration * s.frameRate).rounded())
        return (0...n).map { Double($0) / s.frameRate }
    }

    static func body(at t: Double, _ s: Script, frame i: Int) -> BodyPose {
        let pose = world(t, s)
        var joints: [PoseJoint: PosePoint] = [:]
        let faceConfidence = s.camera == .inFront ? 0.8 : 0.25
        for (joint, p) in pose.joints {
            guard let (x, y) = project(p, s) else { continue }
            let isLeg = [.leftKnee, .rightKnee, .leftAnkle, .rightAnkle].contains(joint)
            let isFace = [.nose, .leftEye, .rightEye, .leftEar, .rightEar].contains(joint)
            let confidence = isLeg ? s.legConfidence : (isFace ? faceConfidence : 0.85)
            let k = Double(PoseJoint.allCases.firstIndex(of: joint) ?? 0)
            let jx = s.jitter * sin(Double(i) * 12.9898 + k * 78.233)
            let jy = s.jitter * cos(Double(i) * 39.3468 + k * 11.135)
            joints[joint] = PosePoint(x: x + jx, y: y + jy, confidence: confidence)
        }
        let kickSide = KickingSideJoints(kickingFoot: s.kickingFoot)
        if s.kickingAnkleHidden.contains(where: { abs($0 - t) < 0.5 / s.frameRate }) {
            joints[kickSide.kickingAnkle] = nil
        }
        if s.legSwapTimes.contains(where: { abs($0 - t) < 0.5 / s.frameRate }) {
            for (l, r) in [(PoseJoint.leftKnee, PoseJoint.rightKnee), (.leftAnkle, .rightAnkle)] {
                let a = joints[l]; joints[l] = joints[r]; joints[r] = a
            }
        }
        if s.labelsFlippedByDetector {
            for (l, r) in LegIdentityCheck.pairs {
                let a = joints[l]; joints[l] = joints[r]; joints[r] = a
            }
        }
        return BodyPose(joints: joints, trackID: nil)
    }

    static func sequence(_ s: Script, videoID: UUID = UUID()) -> PoseSequence {
        let frames = timestamps(s).enumerated().map { i, t in PoseFrame(frameIndex: i, timestamp: t, bodies: [body(at: t, s, frame: i)]) }
        return PoseSequence(videoID: videoID, durationSeconds: s.duration, nominalFrameRate: s.frameRate, analysisFrameRate: s.frameRate,
                            orientation: .up, isMirrored: s.mirrored, displayAspectRatio: aspect, frames: frames, kickerTrackID: nil)
    }

    static func cameraAngle(_ s: Script) -> VideoAngleType {
        switch s.camera {
        case .behind: .rear
        case .inFront: .front
        case .diagonalBehind: .oblique
        }
    }

    static func run(_ s: Script, angle: VideoAngleType? = nil, kickType: KickType = .fieldGoal,
                    assistance: PhaseDetectionAssistance? = nil) -> KickAnalysisPipelineOutput {
        KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: sequence(s), kickType: kickType, kickingFoot: s.kickingFoot,
            cameraAngle: angle ?? cameraAngle(s), assistance: assistance
        ))
    }
}
