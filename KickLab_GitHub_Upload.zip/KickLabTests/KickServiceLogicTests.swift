import Foundation
import Testing
@testable import KickLab

/// Pure rules behind KickService and KickingSessionService. No SwiftData.
@Suite("Kick and session service logic")
struct KickServiceLogicTests {
    // MARK: Context and playing-level resolution

    @Test func explicitContextWins() {
        #expect(KickCreationDefaults.resolvedContext(explicit: .camp, sessionType: .game) == .camp)
    }

    @Test(arguments: [
        (KickingSessionType.training, KickContext.training),
        (.game, .game),
        (.camp, .camp),
        (.competition, .competition),
        (.warmup, .warmup),
    ])
    func contextDerivesFromSessionType(sessionType: KickingSessionType, expected: KickContext) {
        #expect(KickCreationDefaults.resolvedContext(explicit: nil, sessionType: sessionType) == expected)
    }

    @Test func noSessionAndNoContextFallsBackToTraining() {
        #expect(KickCreationDefaults.resolvedContext(explicit: nil, sessionType: nil) == .training)
    }

    @Test func playingLevelSnapshotsAthleteUnlessExplicit() {
        #expect(KickCreationDefaults.resolvedPlayingLevel(explicit: nil, athleteCurrentLevel: .college) == .college)
        #expect(KickCreationDefaults.resolvedPlayingLevel(explicit: .highSchool, athleteCurrentLevel: .college) == .highSchool)
    }

    @Test func resolvedDraftKeepsOutcomeAndFillsDefaults() {
        let draft = KickDraft(outcome: .pat(FieldGoalOutcome(result: .made)))
        let resolved = KickCreationDefaults.resolvedDraft(draft, sessionType: .game, athleteCurrentLevel: .professional)
        #expect(resolved.context == .game)
        #expect(resolved.playingLevelAtKick == .professional)
        #expect(resolved.outcome == draft.outcome)
        #expect(resolved.id == draft.id)
    }

    // MARK: Integrity audit

    private let kickID = UUID()
    private let athleteA = UUID()
    private let athleteB = UUID()
    private let session = UUID()

    @Test func consistentKickHasNoIssues() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: athleteA, storedAthleteID: athleteA, sessionID: session, sessionAthleteID: athleteA)
        #expect(KickIntegrityAuditor.audit(links: links, outcomeIssues: []).isEmpty)
    }

    @Test func detectsAthleteIDMismatch() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: athleteA, storedAthleteID: athleteB)
        #expect(KickIntegrityAuditor.audit(links: links, outcomeIssues: []) == [
            .athleteIDMismatch(storedAthleteID: athleteB, linkedAthleteID: athleteA),
        ])
    }

    @Test func detectsMissingStoredAthleteID() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: athleteA, storedAthleteID: nil)
        #expect(KickIntegrityAuditor.audit(links: links, outcomeIssues: []) == [
            .athleteIDMismatch(storedAthleteID: nil, linkedAthleteID: athleteA),
        ])
    }

    @Test func detectsSessionAthleteMismatch() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: athleteA, storedAthleteID: athleteA, sessionID: session, sessionAthleteID: athleteB)
        #expect(KickIntegrityAuditor.audit(links: links, outcomeIssues: []) == [
            .sessionAthleteMismatch(sessionID: session, sessionAthleteID: athleteB, kickAthleteID: athleteA),
        ])
    }

    @Test func detectsMissingAthleteAndSessionWithoutAthlete() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: nil, storedAthleteID: athleteA, sessionID: session, sessionAthleteID: nil)
        #expect(KickIntegrityAuditor.audit(links: links, outcomeIssues: []) == [
            .missingAthlete(storedAthleteID: athleteA),
            .sessionWithoutAthlete(sessionID: session),
        ])
    }

    @Test func includesOutcomeIssues() {
        let links = KickLinkSnapshot(kickID: kickID, linkedAthleteID: athleteA, storedAthleteID: athleteA)
        let issues = KickIntegrityAuditor.audit(links: links, outcomeIssues: [.touchbackAndOutOfBounds])
        #expect(issues == [.outcome(.touchbackAndOutOfBounds)])
    }

    // MARK: Media cleanup request

    @Test func cleanupRequestDeduplicatesSortsAndDropsEmptyPaths() {
        let request = MediaCleanupRequest(relativePaths: ["b.mov", "a.mov", "", "b.mov"])
        #expect(request.relativePaths == ["a.mov", "b.mov"])
        #expect(MediaCleanupRequest(relativePaths: [""]).isEmpty)
        #expect(request.merged(with: MediaCleanupRequest(relativePaths: ["c.json", "a.mov"])).relativePaths == ["a.mov", "b.mov", "c.json"])
    }

    @Test func noOpCleanupDoesNothing() {
        NoOpMediaCleanup().cleanUp(MediaCleanupRequest(relativePaths: ["x.mov"]))
    }

    // MARK: Session edits and deletion summary

    @Test func sessionEditRequiresNonEmptyName() {
        #expect(KickingSessionEdit(name: "   ").issues == [.emptyName])
        #expect(KickingSessionEdit(name: "Tuesday").issues.isEmpty)
    }

    @Test func sessionEditNormalizesText() {
        let edit = KickingSessionEdit(name: "  Tuesday  ", location: "  ", notes: " windy ").normalized
        #expect(edit.name == "Tuesday")
        #expect(edit.location == nil)
        #expect(edit.notes == "windy")
    }

    @Test(arguments: [(0, "This session has no kicks."), (1, "1 kick will be kept as unassigned."), (12, "12 kicks will be kept as unassigned.")])
    func deletionSummaryMessage(kickCount: Int, expected: String) {
        let summary = KickingSessionDeletionSummary(sessionID: UUID(), sessionName: "S", kickCount: kickCount)
        #expect(summary.confirmationMessage == expected)
    }

    // MARK: Typed errors are inspectable without strings

    @Test func serviceErrorsCompareByCase() {
        let id = UUID()
        #expect(KickServiceError.kickHasNoAthlete(kickID: id) == .kickHasNoAthlete(kickID: id))
        #expect(KickServiceError.invalidDraft([.touchbackAndOutOfBounds]) != .invalidDraft([]))
        #expect(KickServiceError.athleteArchived(athleteID: id).errorDescription != nil)
    }
}
