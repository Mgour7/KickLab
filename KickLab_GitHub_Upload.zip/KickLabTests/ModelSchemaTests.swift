import Foundation
import SwiftData
import Testing
@testable import KickLab

/// Proves the schema opens and the database-level delete rules behave as specified.
/// Service-level deletion (files, athlete confirmation) is tested in step 5.
@MainActor
@Suite("Schema and delete rules")
struct ModelSchemaTests {
    let container: ModelContainer
    let context: ModelContext

    init() throws {
        container = try ModelContainerFactory.makeContainer(inMemory: true)
        context = container.mainContext
    }

    private func count<T: PersistentModel>(_ type: T.Type) throws -> Int {
        try context.fetchCount(FetchDescriptor<T>())
    }

    /// Athlete → session → kick, with a video and an analysis that has one of each child.
    private func makeGraph() throws -> (Athlete, KickingSession, Kick, VideoAsset, BiomechanicsAnalysis) {
        let athlete = Athlete(firstName: "Test", lastName: "Kicker")
        let session = KickingSession(name: "Tuesday practice", sessionType: .training)
        let kick = try Kick.make(from: KickDraft(outcome: .fieldGoal(FieldGoalOutcome(result: .made, distance: .manual(42)))))
        let video = VideoAsset(angleType: .side, isPrimary: true, storageStatus: .local, relativeFilePath: "k/v.mov")
        let analysis = BiomechanicsAnalysis(analysisVersion: "0.0.1", processingStatus: .completed)
        let metric = BiomechanicalMetric(metricKey: "plant.lateralDistance", value: 11.5, unit: .inches, confidence: 0.8, measurementStatus: .measured, phase: .plant)
        let score = CategoryScore(category: .plant, score: 82, confidence: 0.8, measurementStatus: .measured)
        let observation = CoachingObservation(kind: .keep, category: .swing, message: "Excellent knee-through sequencing.")

        // Insert everything before linking: SwiftData links objects within one context.
        for model in [athlete, session, kick, video, analysis, metric, score, observation] as [any PersistentModel] {
            context.insert(model)
        }

        session.athlete = athlete
        kick.assignAthlete(athlete)
        kick.session = session
        video.kick = kick
        analysis.kick = kick
        try analysis.attachInputVideo(video)
        metric.analysis = analysis
        score.analysis = analysis
        observation.analysis = analysis
        try context.save()
        return (athlete, session, kick, video, analysis)
    }

    @Test func schemaContainsAllEightEntities() {
        let names = Set(container.schema.entities.map(\.name))
        #expect(names == [
            "Athlete", "KickingSession", "Kick", "VideoAsset",
            "BiomechanicsAnalysis", "BiomechanicalMetric", "CategoryScore", "CoachingObservation",
        ])
    }

    @Test func deletingSessionKeepsKicks() throws {
        let (_, session, kick, _, _) = try makeGraph()

        context.delete(session)
        try context.save()

        #expect(try count(KickingSession.self) == 0)
        #expect(try count(Kick.self) == 1)
        #expect(kick.session == nil)
    }

    @Test func deletingKickCascadesVideosAndAnalyses() throws {
        let (_, _, kick, _, _) = try makeGraph()

        context.delete(kick)
        try context.save()

        #expect(try count(Kick.self) == 0)
        #expect(try count(VideoAsset.self) == 0)
        #expect(try count(BiomechanicsAnalysis.self) == 0)
        #expect(try count(BiomechanicalMetric.self) == 0)
        #expect(try count(CategoryScore.self) == 0)
        #expect(try count(CoachingObservation.self) == 0)
        #expect(try count(KickingSession.self) == 1)
        #expect(try count(Athlete.self) == 1)
    }

    @Test func deletingAnalysisCascadesChildrenButKeepsVideo() throws {
        let (_, _, kick, video, analysis) = try makeGraph()

        context.delete(analysis)
        try context.save()

        #expect(try count(BiomechanicalMetric.self) == 0)
        #expect(try count(CategoryScore.self) == 0)
        #expect(try count(CoachingObservation.self) == 0)
        #expect(try count(VideoAsset.self) == 1)
        #expect(video.kick?.id == kick.id)
    }

    @Test func deletingVideoKeepsAnalysis() throws {
        let (_, _, _, video, analysis) = try makeGraph()

        context.delete(video)
        try context.save()

        #expect(try count(BiomechanicsAnalysis.self) == 1)
        #expect((analysis.inputVideos ?? []).isEmpty)
    }

    @Test func deletingAthleteRowNeverDestroysHistory() throws {
        let (athlete, session, kick, _, _) = try makeGraph()

        context.delete(athlete)
        try context.save()

        #expect(try count(KickingSession.self) == 1)
        #expect(try count(Kick.self) == 1)
        #expect(session.athlete == nil)
        #expect(kick.athlete == nil)
        // athleteID is the stable identifier left behind for deliberate re-linking.
        #expect(kick.athleteID != nil)
    }
}
