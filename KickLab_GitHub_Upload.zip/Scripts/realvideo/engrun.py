# Build 22 real-video EMULATION tooling (developer use only; not part of the app).
# Paths come from the environment:
#   KL_WORK   work directory (frame times, pose and scan JSON)      default ./work
#   KL_YOLOX  official YOLOX-S ONNX (Apache-2.0, Megvii)              required
#   KL_VIDEO_A / KL_VIDEO_B  the two recordings (never committed)    required
#   KL_EMU    built emu executable (see README.md)                   for engrun.py
#   KL_SWIFT_LIBS  extra LD_LIBRARY_PATH for a Linux Swift toolchain  optional
# Substitute inputs: MediaPipe pose (not Apple Vision) and onnxruntime YOLOX-S (not the
# Core ML conversion). Results are an emulation of KickLab's decision code, not the app.
import subprocess, numpy as np, json, sys, os, re
import os as _os
WORK=_os.environ.get('KL_WORK','work')
P=lambda name: _os.path.join(WORK, name)
ARGV=list(sys.argv)
sys.argv=['lib','/tmp',P('_vpts'),_os.environ['KL_YOLOX'],P('_o')]
src=open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','cv','make_1709_fixtures.py')).read()
ns={'__name__':'lib'}; exec(src[: src.index('# Stage 1')], ns)
W,H=1920,1080; ns['W'],ns['H']=W,H
EMU=_os.environ['KL_EMU']
env=dict(os.environ, LD_LIBRARY_PATH=os.environ.get('KL_SWIFT_LIBS',''))
SRC={'a':_os.environ['KL_VIDEO_A'],'b':_os.environ['KL_VIDEO_B']}
def frames(cam, t0, t1):
    """Yield (pts, bgr) for every frame with t0<=pts<=t1 (original timestamps)."""
    ss=max(0,t0-3)
    p=subprocess.Popen(['ffmpeg','-v','info','-ss',str(ss),'-i',SRC[cam],'-copyts','-fps_mode','passthrough','-vf','showinfo','-f','rawvideo','-pix_fmt','bgr24','-'],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    import threading, queue
    q=queue.Queue()
    def rd():
        for line in p.stderr:
            m=re.search(rb'pts_time:([0-9.]+)', line)
            if m: q.put(float(m.group(1)))
        q.put(None)
    threading.Thread(target=rd,daemon=True).start()
    while True:
        b=p.stdout.read(W*H*3)
        if len(b)<W*H*3: break
        t=q.get()
        if t is None: break
        if t>t1+0.001: p.kill(); break
        if t>=t0-0.001: yield t, np.frombuffer(b,np.uint8).reshape(H,W,3)
def emu(inp, tag):
    fi=f'{WORK}/eng/{tag}_in.json'; fo=f'{WORK}/eng/{tag}_out.json'
    json.dump(inp,open(fi,'w')); subprocess.run([EMU,'engine',fi,fo],check=True,env=env)
    return json.load(open(fo))
os.makedirs(P('eng'),exist_ok=True)
cam=ARGV[-4]; ki=int(ARGV[-3]); c0=float(ARGV[-2]); c1=float(ARGV[-1])  # clip start/end in source time
pc=json.load(open(f'{WORK}/poseclips_{cam}.json'))[str(ki)]
poses=[{'t':p['t']-c0,'lm':p['lm']} for p in pc if c0-1e-3<=p['t']<=c1+1e-3]
dur=c1-c0
# broad scan on the clip grid
broad=[]; btimes=[]; nxt=0.0; cache={}
for t,img in frames(cam,c0,c1):
    ct=t-c0
    if ct<0.5 or ct+1e-6>=nxt:
        nxt=ct+0.2; btimes.append(ct)
        d,_=ns['run'](img,(0,0,W,H))
        broad+= [dict(t=ct,cx=x['cx'],cy=x['cy'],w=x['w'],h=x['h'],s=x['s']) for x in d]
base=dict(duration=dur,aspect=16/9,displayWidth=W,displayHeight=H,frames=poses,broadTimes=btimes,broad=broad)
results={}
for angle in ARGV[1:-4]:
    tag=f'{cam}{ki+1}_{angle}'
    out=emu(dict(base,angle=angle),tag+'_p1')
    if 'crop' in out and 'withFootball' not in out:
        w0,w1=out['precisionWindow']; x,y,s,_=out['crop']
        key=(w0,w1,x,y,s)
        if key not in cache:
            pt=[]; pd=[]
            for t,img in frames(cam,c0+w0,c0+w1):
                ct=t-c0; pt.append(ct)
                d,_=ns['run'](img,(x,y,s,s))
                pd+=[dict(t=ct,cx=v['cx'],cy=v['cy'],w=v['w'],h=v['h'],s=v['s']) for v in d]
            cache[key]=(pt,pd)
        pt,pd=cache[key]
        out=emu(dict(base,angle=angle,precisionTimes=pt,precision=pd),tag)
    else:
        json.dump(out,open(f'{WORK}/eng/{tag}_out.json','w'))
    wf=out.get('withFootball',out['poseOnly']); eo=wf['evidenceOutcome']
    print(tag,'clip',round(c0,3),'contact',eo['contactOutcome'],eo.get('contactTime'),eo.get('contactEarliest'),eo.get('contactLatest'),'plant',eo.get('plantUsed'),
          'ball',eo.get('ballLastStationary'),eo.get('ballFirstMovement'),'stop',eo.get('stopGate'),'outcome',wf['outcome'],'persp',(wf.get('perspective') or {}).get('used'),flush=True)
