# Build 22 emulation tooling: MediaPipe pose every Nth frame (Stage A person stand-in). See README.md.
import subprocess, numpy as np, mediapipe as mp, sys, json
import os as _os
WORK=_os.environ.get('KL_WORK','work')
P=lambda name: _os.path.join(WORK, name)
cam=sys.argv[1]; src=(_os.environ['KL_VIDEO_A'] if cam=='a' else _os.environ['KL_VIDEO_B'])
step=int(sys.argv[2]); W,H=1280,720
pts=np.load(P(f'{cam}_pts.npy'))
cmd=['ffmpeg','-v','error','-i',src,'-fps_mode','passthrough','-vf',f"select='not(mod(n\\,{step}))',scale={W}:{H}",'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','-']
p=subprocess.Popen(cmd,stdout=subprocess.PIPE)
pose=mp.solutions.pose.Pose(static_image_mode=False, model_complexity=1, min_detection_confidence=0.3, min_tracking_confidence=0.3)
out=[]; n=0
while True:
    buf=p.stdout.read(W*H*3)
    if len(buf)<W*H*3: break
    img=np.frombuffer(buf,np.uint8).reshape(H,W,3)
    r=pose.process(img); k=n*step
    if r.pose_landmarks:
        lm=[[l.x,l.y,l.visibility] for l in r.pose_landmarks.landmark]
    else: lm=None
    out.append({'k':k,'t':float(pts[min(k,len(pts)-1)]),'lm':lm}); n+=1
json.dump(out,open(P(f'pose_{cam}_s{step}.json'),'w'))
print(cam,n,sum(o['lm'] is not None for o in out))
