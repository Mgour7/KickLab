# Real-video emulation tooling (Build 22)

Developer tooling used for `Docs/COMPETITOR_VALIDATION_BUILD22.md`. It runs **KickLab's own
pure decision code** (Stage A discovery, `KickAnalysisPipeline`, `FootballTrackAnalyzer`) on
real recordings, with **substitute** inputs:

| App (device)                         | Emulation (Linux)                                   |
|--------------------------------------|-----------------------------------------------------|
| Apple Vision body pose (19 joints)   | MediaPipe Pose 0.10.14, `model_complexity=1`, mapped to the 19 joints (neck = mid-shoulders, root = mid-hips) |
| YOLOX-S Core ML fp16 conversion      | the official YOLOX-S ONNX on onnxruntime, app-identical letterbox (`Scripts/cv/make_1709_fixtures.py`) |
| ball appearance + camera-motion cues | not computed (empty)                                |

Results are therefore **not** what the iPhone app produces; they show how the app's
decision logic behaves on this footage given comparable inputs. Nothing here is part of the
app, and no video is ever committed.

## Steps
```
export KL_WORK=work KL_YOLOX=/path/yolox_s.onnx KL_VIDEO_A=IMG_4541.mov KL_VIDEO_B=IMG_6269.mov
# frame times (one per decoded frame) → $KL_WORK/{a,b}_pts.npy
ffprobe -v error -select_streams v -show_entries frame=pts_time -of csv=p=0 "$KL_VIDEO_A" | cut -d, -f1 > a_pts.txt   # then np.save
python yscan.py        # CAM=a|b: YOLOX broad scan on a 0.2 s grid → yscan_{cam}.json
python posescan.py a 3 # MediaPipe every 3rd frame → pose_a_s3.json
python mkstagea.py a   # → stagea_in_a.json ([SessionScanSample])
emu stagea work/stagea_in_a.json out.json          # KickDiscovery.discoverWithTrace + ClipBoundaryPolicy
python poseclips.py    # CAM=a|b: MediaPipe on every frame around each kick
python engrun.py unknown side a 1 92.31 99.31      # angles…, camera, kick index, clip start, clip end
```
`emu` is `emu_main.swift` built as an executable against the app's pure sources, exactly like
`Scripts/evidence/replay.sh` builds the replay tool (`-enable-testing`, `@testable import`).
