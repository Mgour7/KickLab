// KickLab EMULATION harness for the IMG_4541 / IMG_6269 assessment.
// Runs the app's own pure decision code (KickDiscovery, KickAnalysisPipeline,
// FootballTrackAnalyzer) on SUBSTITUTE inputs: MediaPipe pose instead of Apple Vision,
// onnxruntime YOLOX-S instead of the Core ML conversion, no appearance or camera-motion
// inputs. Nothing here is the app running on a device.
import Foundation
@testable import KickLabCore

func die(_ s: String) -> Never { FileHandle.standardError.write(Data((s + "\n").utf8)); exit(2) }
let args = CommandLine.arguments
guard args.count >= 3 else { die("usage: emu stagea|engine IN.json [OUT.json]") }
let inData = try Data(contentsOf: URL(fileURLWithPath: args[2]))
let enc = JSONEncoder(); enc.outputFormatting = [.prettyPrinted, .sortedKeys]
func r3(_ v: Double?) -> Double? { v.map { ($0 * 1000).rounded() / 1000 } }

func write(_ obj: Any) {
    let d = try! JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted, .sortedKeys])
    if args.count >= 4 { try! d.write(to: URL(fileURLWithPath: args[3])) } else { print(String(decoding: d, as: UTF8.self)) }
}
func enc2any<T: Encodable>(_ v: T) -> Any { try! JSONSerialization.jsonObject(with: enc.encode(v), options: [.fragmentsAllowed]) }

switch args[1] {
case "stagea":
    struct In: Decodable { var duration: Double; var samples: [SessionScanSample] }
    let input = try JSONDecoder().decode(In.self, from: inData)
    let (kept, trace) = KickDiscovery.discoverWithTrace(input.samples)
    var out: [[String: Any]] = []
    for (i, k) in kept.enumerated() {
        let b = ClipBoundaryPolicy.boundaries(contact: k.contactTime, approachStart: k.approachStart, sourceDuration: input.duration,
                                              previousContact: i > 0 ? kept[i - 1].contactTime : nil,
                                              nextContact: i + 1 < kept.count ? kept[i + 1].contactTime : nil)
        out.append(["contactTime": k.contactTime, "uncertainty": k.contactUncertainty, "autoVerify": k.autoVerify,
                    "evidence": enc2any(k.evidence), "approachStart": k.approachStart as Any,
                    "restSpot": k.restSpot.map { enc2any($0) } as Any,
                    "clipStart": b.start, "clipEnd": b.end, "approachIncomplete": b.approachIncomplete,
                    "followThroughIncomplete": b.followThroughIncomplete])
    }
    write(["kept": out, "trace": enc2any(trace)])

case "engine":
    struct Det: Decodable { var t: Double; var cx: Double; var cy: Double; var w: Double; var h: Double; var s: Double }
    struct Frame: Decodable { var t: Double; var lm: [[Double]]? }
    struct In: Decodable {
        var duration: Double; var aspect: Double; var angle: String; var displayWidth: Double; var displayHeight: Double
        var frames: [Frame]
        var broadTimes: [Double]; var broad: [Det]
        var precisionTimes: [Double]?; var precision: [Det]?
        var assistedContact: Double?
        var strikeSite: StrikeSiteBallResult?
    }
    let input = try JSONDecoder().decode(In.self, from: inData)
    // MediaPipe 33 landmarks → Vision's 19 joints (neck = mid-shoulders, root = mid-hips).
    let map: [(PoseJoint, Int)] = [(.nose, 0), (.leftEye, 2), (.rightEye, 5), (.leftEar, 7), (.rightEar, 8), (.leftShoulder, 11),
                                   (.rightShoulder, 12), (.leftElbow, 13), (.rightElbow, 14), (.leftWrist, 15), (.rightWrist, 16),
                                   (.leftHip, 23), (.rightHip, 24), (.leftKnee, 25), (.rightKnee, 26), (.leftAnkle, 27), (.rightAnkle, 28)]
    var frames: [PoseFrame] = []
    for (i, f) in input.frames.enumerated() {
        guard let lm = f.lm, lm.count >= 33 else { frames.append(PoseFrame(frameIndex: i, timestamp: f.t, bodies: [])); continue }
        var j: [PoseJoint: PosePoint] = [:]
        for (joint, k) in map { j[joint] = PosePoint(x: lm[k][0], y: lm[k][1], confidence: min(1, max(0, lm[k][2]))) }
        func mid(_ a: Int, _ b: Int) -> PosePoint {
            PosePoint(x: (lm[a][0] + lm[b][0]) / 2, y: (lm[a][1] + lm[b][1]) / 2, confidence: min(lm[a][2], lm[b][2]))
        }
        j[.neck] = mid(11, 12); j[.root] = mid(23, 24)
        for (k, p) in j where p.confidence <= 0 { j[k] = .unavailable }
        frames.append(PoseFrame(frameIndex: i, timestamp: f.t, bodies: [BodyPose(joints: j)]))
    }
    let seq = PoseSequence(videoID: UUID(uuid: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1)), durationSeconds: input.duration,
                           nominalFrameRate: 30, analysisFrameRate: nil, orientation: .up, isMirrored: false,
                           displayAspectRatio: input.aspect, frames: frames)
    let angle = VideoAngleType(rawValue: input.angle) ?? .unknown
    var pin = KickAnalysisPipelineInput(sequence: seq, kickType: .fieldGoal, kickingFoot: .right, cameraAngle: angle,
                                        assistance: input.assistedContact.map { PhaseDetectionAssistance(contactTime: $0) })
    let poseOnly = KickAnalysisPipeline.run(pin)
    func summary(_ o: KickAnalysisPipelineOutput, _ football: FootballTrack?) -> [String: Any] {
        var s: [String: Any] = [:]
        s["kickerStatus"] = o.tracking.status.rawValue
        s["kickerMethod"] = o.tracking.method.rawValue
        s["kickerConfidence"] = r3(o.tracking.confidence)
        s["extractionConfidence"] = r3(o.extractionConfidence)
        s["phaseSupport"] = o.phases.support.rawValue
        s["phases"] = o.phases.phases.map { p -> [String: Any] in
            ["phase": p.phase.rawValue, "status": p.status.rawValue, "start": r3(p.startTime) as Any, "end": r3(p.endTime) as Any,
             "t": r3(p.representativeTime) as Any, "confidence": r3(p.confidence) as Any]
        }
        s["notes"] = o.phases.notes
        s["evidence"] = o.phases.evidence.map { enc2any($0) } as Any
        s["kickWindows"] = o.phases.kickWindows.map { enc2any($0) } as Any
        s["perspective"] = o.perspective.map { enc2any($0) } as Any
        s["legIdentity"] = o.legIdentity.map { enc2any($0) } as Any
        s["gates"] = o.gates.map { ["gate": $0.gate.rawValue, "passed": $0.passed as Any, "detail": $0.detail, "values": $0.values] }
        s["outcome"] = o.outcome.rawValue
        s["completionBasis"] = o.completionBasis.rawValue
        s["failureCause"] = o.failureCause.map { enc2any($0) } as Any
        s["repair"] = enc2any(o.repair)
        s["suitability"] = enc2any(o.suitability)
        s["metrics"] = o.biomechanics.measurements.map { m -> [String: Any] in
            ["key": m.key.rawValue, "value": r3(m.value) as Any, "unit": m.unit.rawValue, "status": m.status.rawValue,
             "confidence": r3(m.confidence) as Any, "sampleTime": r3(m.sampleTime) as Any]
        }
        s["categories"] = o.biomechanics.categories.map { c -> [String: Any] in
            ["category": c.category.rawValue, "score": r3(c.score) as Any, "confidence": r3(c.confidence) as Any, "status": c.status.rawValue]
        }
        s["findings"] = o.biomechanics.findings.map { ["rule": $0.rule.rawValue, "kind": $0.kind.rawValue, "observed": $0.observed,
                                                      "severity": $0.severity?.rawValue as Any, "confidence": r3($0.confidence) as Any] }
        s["overallScore"] = r3(o.biomechanics.overallScore) as Any
        // Build 22 Kick Breakdown on this output (same builder as the app).
        let rows: [MetricRowPresentation] = o.biomechanics.measurements.compactMap { m in
            guard m.isAvailable, let v = m.value else { return nil }
            let d = m.key.definition
            return MetricRowPresentation(key: m.key, name: d.displayName, explanation: d.explanation,
                                         valueText: DisplayFormat.metricValue(v, unit: m.unit), value: v, unit: m.unit, status: m.status,
                                         statusText: "", confidence: m.confidence, confidenceText: DisplayFormat.confidence(m.confidence), category: d.category)
        }
        let cards = o.biomechanics.categories.filter { $0.category != .overall }.map { c in
            CategoryCardPresentation(category: c.category, title: c.category.presentationTitle, score: c.score, scoreText: "", grade: ScoreGrade(score: c.score),
                                     confidence: c.confidence, confidenceText: "", summary: c.summary, topMetrics: [], unavailableMetricNames: [])
        }
        let coaching = o.biomechanics.findings.filter { $0.issued && $0.kind == .improve }.enumerated().map { i, f in
            CoachingItemPresentation(id: UUID(), category: f.category, categoryTitle: f.category.presentationTitle, observed: f.observed,
                                     whyItMatters: f.whyItMatters, cue: f.cue, severity: f.severity, severityText: nil, confidence: f.confidence,
                                     confidenceText: "", priority: f.rank ?? i, evidenceMetricKeys: f.evidence.map(\.rawValue))
        }
        let view: String = { switch o.perspective?.used { case .depthAway?: return "View from behind"; case .depthToward?: return "View from in front"; case .oblique?: return "Diagonal view"; default: return "Side view" } }()
        let bd = KickBreakdownBuilder.make(KickBreakdownBuilder.Input(
            kickType: .fieldGoal, metrics: rows, categories: cards, coaching: coaching, markers: PhaseMarker.markers(from: o.phases),
            viewText: view, contactOutcome: ContactOutcome.of(o.phases), contactTime: o.phases.estimatedContactTime,
            overallScore: o.biomechanics.overallScore, recordingAdvice: PerformanceReport.sideRecording, perspective: o.perspective?.used,
            frames: KickBreakdownBuilder.frames(samples: Dictionary(o.biomechanics.measurements.compactMap { m in
                guard m.isAvailable, let v = m.value, let t = m.sampleTime else { return nil }
                return (m.key, KickBreakdownBuilder.Sample(value: v, time: t)) }, uniquingKeysWith: { a, _ in a }))))
        func mj(_ m: KickBreakdown.Measurement?) -> Any {
            guard let m else { return NSNull() }
            return ["key": m.key.rawValue, "name": m.name, "valueText": m.valueText, "targetText": m.targetText as Any, "verdict": m.verdict.rawValue,
                    "definition": m.definition, "quality": m.qualityText,
                    "gauge": m.gauge.map { ["targetStart": $0.targetStart, "targetEnd": $0.targetEnd, "value": $0.value, "openLow": $0.openLow, "openHigh": $0.openHigh] } as Any]
        }
        s["breakdown"] = [
            "grade": ["text": bd.grade.text, "basis": bd.grade.basis, "score": bd.grade.score as Any, "label": bd.grade.label?.title as Any],
            "coachSummary": bd.coachSummary, "contactText": bd.contactText, "viewText": bd.viewText,
            "noPriority": bd.noPriorityText as Any, "watch": bd.watch?.text as Any,
            "priority": bd.priority.map { ["phase": $0.phase.title, "title": $0.title, "observed": $0.observed, "cue": $0.cue, "drill": $0.drillTitle as Any, "check": $0.checkNextKick] } as Any,
            "phases": bd.phases.map { c in ["phase": c.phase.title, "subtitle": c.phase.subtitle, "status": c.status.title, "score": c.score as Any,
                                             "headline": mj(c.headline), "others": c.others.map { mj($0) }, "explanation": c.explanation,
                                             "frameTime": c.frameTime as Any, "frameSource": c.frameSource as Any, "reason": c.reason as Any] },
            "issues": KickBreakdownCheck.issues(bd)]
        let gates = o.gates
        s["evidenceOutcome"] = enc2any(EvidenceOutcome.make(phases: o.phases, football: football, gates: gates,
                                                            measurements: o.biomechanics.measurements, engineVersion: "emulation"))
        return s
    }
    var result: [String: Any] = ["poseOnly": summary(poseOnly, nil)]
    let context = FootballAnalysisContext.make(from: poseOnly, kickingFoot: .right)
    result["contextStrike"] = context.strike.map { [$0.lowerBound, $0.upperBound] } as Any
    let broad = input.broad.map { FootballDetection(time: $0.t, box: NormalizedBox(cx: $0.cx, cy: $0.cy, w: $0.w, h: $0.h), score: $0.s, pass: .broadScan) }
    let aspect = context.aspect ?? input.aspect
    let sites = FootballTrackAnalyzer.sites(broad, aspect: aspect)
    let selection = FootballTrackAnalyzer.selectKickedBall(sites: sites, detections: broad, scanTimes: input.broadTimes,
                                                           ankle: context.ankle, strike: context.strike, aspect: aspect)
    result["sites"] = enc2any(selection.sites)
    result["selected"] = selection.selected as Any
    if let k = selection.selected {
        let site = selection.sites[k]
        let window = FootballTrackAnalyzer.precisionWindow(site: site, strike: context.strike, duration: input.duration)
        let side = max(14 * site.size * input.displayHeight, 0.3 * max(input.displayWidth, input.displayHeight))
        let crop = DetectorInputBuilder.cropRegion(centerX: site.center.x * input.displayWidth, centerY: site.center.y * input.displayHeight,
                                                   side: side, displayWidth: input.displayWidth, displayHeight: input.displayHeight)
        result["precisionWindow"] = [window.lowerBound, window.upperBound]
        result["crop"] = [crop.x, crop.y, crop.width, crop.height]
    }
    if let pt = input.precisionTimes, let pd = input.precision {
        let precision = pd.map { FootballDetection(time: $0.t, box: NormalizedBox(cx: $0.cx, cy: $0.cy, w: $0.w, h: $0.h), score: $0.s, pass: .precision) }
        var raw = FootballRawEvidence(scanTimes: input.broadTimes, broadScan: broad, precisionTimes: pt, precision: precision,
                                      appearanceTimes: [], appearanceScores: [], cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [],
                                      camera: nil, strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                      ankle: context.ankle, aspect: aspect, duration: input.duration)
        raw.strikeSite = input.strikeSite
        let track = FootballTrackAnalyzer.analyze(raw: raw, detector: .yoloxS)
        result["football"] = enc2any(track)
        pin.football = track
        let full = KickAnalysisPipeline.run(pin)
        result["withFootball"] = summary(full, track)
    } else if selection.selected == nil {
        // As on the device: no selected ball → the track is analyzed from the broad scan alone.
        var raw = FootballRawEvidence(scanTimes: input.broadTimes, broadScan: broad, precisionTimes: nil, precision: nil,
                                      appearanceTimes: [], appearanceScores: [], cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [],
                                      camera: nil, strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                      ankle: context.ankle, aspect: aspect, duration: input.duration)
        raw.strikeSite = input.strikeSite
        let track = FootballTrackAnalyzer.analyze(raw: raw, detector: .yoloxS)
        result["football"] = enc2any(track)
        pin.football = track
        result["withFootball"] = summary(KickAnalysisPipeline.run(pin), track)
    }
    write(result)
case "ssregion":
    struct In: Decodable { var aspect: Double; var pose: [StrikeSitePoseSample]; var around: [Double] }
    let input = try JSONDecoder().decode(In.self, from: inData)
    guard let r = StrikeSiteBallFinder.region(pose: input.pose, around: input.around, aspect: input.aspect) else { write(["region": NSNull()]); exit(0) }
    let size = StrikeSiteBallFinder.pixelSize(of: r, aspect: input.aspect)
    write(["region": [r.minX, r.minY, r.maxX, r.maxY], "width": size.width, "height": size.height])
case "ssfind":
    // IN.json: {aspect, region:[minX,minY,maxX,maxY], width, height, times:[...], pose:[...]}; frames in IN.json + ".raw"
    struct In: Decodable { var aspect: Double; var region: [Double]; var width: Int; var height: Int; var times: [Double]; var pose: [StrikeSitePoseSample] }
    let input = try JSONDecoder().decode(In.self, from: inData)
    let raw = try Data(contentsOf: URL(fileURLWithPath: args[2] + ".raw"))
    let n = input.width * input.height
    var frames: [StrikeSiteFrame] = []
    for (i, t) in input.times.enumerated() {
        let px = [UInt8](raw[(i * n)..<((i + 1) * n)])
        frames.append(StrikeSiteFrame(time: t, image: LumaImage(width: input.width, height: input.height, pixels: px)))
    }
    let region = NormalizedRect(minX: input.region[0], minY: input.region[1], maxX: input.region[2], maxY: input.region[3])
    let start = Date()
    let r = StrikeSiteBallFinder.find(frames: frames, region: region, pose: input.pose, aspect: input.aspect, stabilize: ProcessInfo.processInfo.environment["KL_NOSTAB"] == nil)
    var out: [String: Any] = ["seconds": Date().timeIntervalSince(start)]
    if let r { out["result"] = enc2any(r) }
    write(out)
case "ssdebug":
    struct In: Decodable { var aspect: Double; var region: [Double]; var width: Int; var height: Int; var times: [Double]; var pose: [StrikeSitePoseSample] }
    let input = try JSONDecoder().decode(In.self, from: inData)
    let raw = try Data(contentsOf: URL(fileURLWithPath: args[2] + ".raw"))
    let n = input.width * input.height
    var frames: [StrikeSiteFrame] = []
    for (i, t) in input.times.enumerated() { frames.append(StrikeSiteFrame(time: t, image: LumaImage(width: input.width, height: input.height, pixels: [UInt8](raw[(i * n)..<((i + 1) * n)])))) }
    let region = NormalizedRect(minX: input.region[0], minY: input.region[1], maxX: input.region[2], maxY: input.region[3])
    let geo = StrikeSiteBallFinder.Geometry(region: region, width: input.width, height: input.height)
    let pose = input.pose.sorted { $0.time < $1.time }
    let torsoPx = StrikeSiteBallFinder.median(pose.compactMap(\.torso)) * geo.pxPerHeight
    print("region", input.region, "px", input.width, input.height, "torsoPx", torsoPx)
    let st = StrikeSiteBallFinder.Stabilizer.stabilize(frames, pose: pose, geo: geo, torsoPx: torsoPx)
    print("stabilized frames changed:", zip(st, frames).filter { $0.0.image.pixels != $0.1.image.pixels }.count)
    var work = StrikeSiteBallFinder.Work(frames: st, times: st.map(\.time), W: input.width, H: input.height, geo: geo, pose: pose, torsoPx: torsoPx)
    for t in stride(from: Double(args[3])!, through: Double(args[4])!, by: 0.0333) {
        if let a = work.analyze(at: t) { let g = work.gate(a); print(String(format: "ts %.3f ball (%.0f,%.0f) %dx%d score %.1f last %.3f gone %.3f pf %.2f swing %.1f d %.2f ok %d", t, a.cx, a.cy, a.w, a.h, a.score, a.lastPresent, a.firstGone, a.presentFraction, g.swing, g.footDistance, g.approachConsistent ? 1 : 0)) }
        else { print(String(format: "ts %.3f none", t)) }
    }
default:
    die("unknown command")
}
