# Build 22 real-video EMULATION tooling (developer use only; not part of the app).
# Paths come from the environment:
#   KL_WORK   work directory (frame times, pose and scan JSON)      default ./work
#   KL_YOLOX  official YOLOX-S ONNX (Apache-2.0, Megvii)              required
#   KL_VIDEO_A / KL_VIDEO_B  the two recordings (never committed)    required
#   KL_EMU    built emu executable (see README.md)                   for engrun.py
#   KL_SWIFT_LIBS  extra LD_LIBRARY_PATH for a Linux Swift toolchain  optional
# Substitute inputs: MediaPipe pose (not Apple Vision) and onnxruntime YOLOX-S (not the
# Core ML conversion). Results are an emulation of KickLab's decision code, not the app.
import subprocess, numpy as np, mediapipe as mp, json, cv2, os
import os as _os
WORK=_os.environ.get('KL_WORK','work')
P=lambda name: _os.path.join(WORK, name)
cam=_os.environ['CAM']
kicks={'a':[73.26,96.28,118.55,143.75],'b':[41.69,64.71,86.98,112.18]}[cam]
srcf=(_os.environ['KL_VIDEO_A'] if cam=='a' else _os.environ['KL_VIDEO_B'])
pts=np.load(P(f'{cam}_pts.npy')); W,H=1920,1080
clahe=cv2.createCLAHE(clipLimit=3.0,tileGridSize=(8,8))
wins=[(t-4.5,t+3.5) for t in kicks]
res={i:[] for i in range(4)}
poses={i:mp.solutions.pose.Pose(static_image_mode=False, model_complexity=1, min_detection_confidence=0.2, min_tracking_confidence=0.2, smooth_landmarks=False) for i in range(4)}
p=subprocess.Popen(['ffmpeg','-v','error','-i',srcf,'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','bgr24','-'],stdout=subprocess.PIPE)
n=0
while True:
    b=p.stdout.read(W*H*3)
    if len(b)<W*H*3: break
    t=pts[n]
    for i,(a,z) in enumerate(wins):
        if a<=t<=z:
            img=np.frombuffer(b,np.uint8).reshape(H,W,3)
            if cam=='a':
                X0=900; im=img[:,X0:].copy(); lab=cv2.cvtColor(im,cv2.COLOR_BGR2LAB); lab[:,:,0]=clahe.apply(lab[:,:,0]); im=cv2.cvtColor(lab,cv2.COLOR_LAB2BGR); w=W-X0
            else:
                X0=0; im=img; w=W
            r=poses[i].process(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
            lm=[[(X0+l.x*w)/W,l.y,l.visibility] for l in r.pose_landmarks.landmark] if r.pose_landmarks else None
            res[i].append({'k':n,'t':float(t),'lm':lm})
    n+=1
json.dump(res,open(P(f'poseclips_{cam}.json'),'w')); print(cam,[ (len(v),sum(x['lm'] is not None for x in v)) for v in res.values()])
