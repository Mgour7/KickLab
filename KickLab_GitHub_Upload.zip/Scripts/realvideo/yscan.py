# Build 22 real-video EMULATION tooling (developer use only; not part of the app).
# Paths come from the environment:
#   KL_WORK   work directory (frame times, pose and scan JSON)      default ./work
#   KL_YOLOX  official YOLOX-S ONNX (Apache-2.0, Megvii)              required
#   KL_VIDEO_A / KL_VIDEO_B  the two recordings (never committed)    required
#   KL_EMU    built emu executable (see README.md)                   for engrun.py
#   KL_SWIFT_LIBS  extra LD_LIBRARY_PATH for a Linux Swift toolchain  optional
# Substitute inputs: MediaPipe pose (not Apple Vision) and onnxruntime YOLOX-S (not the
# Core ML conversion). Results are an emulation of KickLab's decision code, not the app.
import subprocess, numpy as np, json, sys, os
import os as _os
WORK=_os.environ.get('KL_WORK','work')
P=lambda name: _os.path.join(WORK, name)
sys.argv=['lib','x','x',_os.environ['KL_YOLOX'],'/tmp']
src=open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','cv','make_1709_fixtures.py')).read()
ns={'__name__':'lib'}
open(P('_vpts'),'w').write('0\n')
sys.argv=['lib','/tmp',P('_vpts'),_os.environ['KL_YOLOX'],P('_o')]
exec(src[: src.index('# Stage 1')], ns)
def scan(cam, step_s=0.2):
    W,H=1920,1080; ns['W'],ns['H']=W,H
    pts=np.load(P(f'{cam}_pts.npy'))
    want=set(); g=0.0
    for i,t in enumerate(pts):   # first frame at/after each grid time (KickLab FrameSampler-like)
        if t+1e-6>=g: want.add(i); g=t+step_s
    srcf=(_os.environ['KL_VIDEO_A'] if cam=='a' else _os.environ['KL_VIDEO_B'])
    p=subprocess.Popen(['ffmpeg','-v','error','-i',srcf,'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','bgr24','-'],stdout=subprocess.PIPE)
    out=[]; n=0
    while True:
        b=p.stdout.read(W*H*3)
        if len(b)<W*H*3: break
        if n in want:
            img=np.frombuffer(b,np.uint8).reshape(H,W,3)
            d,_=ns['run'](img,(0,0,W,H))
            out.append({'k':n,'t':float(pts[n]),'balls':d})
        n+=1
    json.dump(out,open(P(f'yscan_{cam}.json'),'w')); print(cam,len(out),sum(len(o['balls']) for o in out))
scan(sys.argv[-1] if False else _os.environ['CAM'])
