import json,sys,subprocess,numpy as np,os,re,threading,queue
EMU='/tmp/claude-0/emu/.build/release/emu'
R='/tmp/claude-0/swiftdl/root'; env=dict(os.environ,LD_LIBRARY_PATH=f'{R}/usr/lib/x86_64-linux-gnu:{R}/usr/libexec/swift/lib')
def pose_samples(frames,W,H):
    """frames: list of (t, lm normalized [x,y,v]*33 or None) -> StrikeSitePoseSample JSON"""
    out=[]
    asp=W/H
    for t,lm in frames:
        s={'time':t}
        if lm:
            def P(i): return {'x':lm[i][0],'y':lm[i][1]} if lm[i][2]>=0.3 else None
            if P(28): s['kickingAnkle']=P(28)
            if P(27): s['plantAnkle']=P(27)
            xs=[p[0] for p in lm if p[2]>=0.3]; ys=[p[1] for p in lm if p[2]>=0.3]
            if xs: s['body']={'minX':min(xs),'minY':min(ys),'maxX':max(xs),'maxY':max(ys)}
            if min(lm[i][2] for i in (11,12,23,24))>=0.3:
                sx=(lm[11][0]+lm[12][0])/2; sy=(lm[11][1]+lm[12][1])/2; hx=(lm[23][0]+lm[24][0])/2; hy=(lm[23][1]+lm[24][1])/2
                s['torso']=float(np.hypot((sx-hx)*asp,sy-hy))
        out.append(s)
    return out
def peaks(frames,W,H):
    t=np.array([f[0] for f in frames]); a=np.array([[f[1][28][0]*W,f[1][28][1]*H] if f[1] else [np.nan,np.nan] for f in frames])
    v=np.r_[np.nan,np.linalg.norm(np.diff(a,axis=0),axis=1)/np.diff(t)]
    vs=np.array([np.nanmedian(v[max(0,i-2):i+3]) if np.isfinite(v[max(0,i-2):i+3]).any() else np.nan for i in range(len(v))])
    out=[]
    for i in np.argsort(-np.nan_to_num(vs,nan=-1)):
        if len(out)>=3 or not np.isfinite(vs[i]): break
        if all(abs(t[i]-o)>0.4 for o in out): out.append(float(t[i]))
    return out
def emu(cmd,obj,tag):
    fi=f'/tmp/claude-0/ss/{tag}_{cmd}.json'; fo=f'/tmp/claude-0/ss/{tag}_{cmd}_out.json'
    json.dump(obj,open(fi,'w')); subprocess.run([EMU,cmd,fi,fo],check=True,env=env); return json.load(open(fo)),fi
def roi_frames(src,t0,t1,crop,size):
    x,y,w,h=crop; W2,H2=size
    p=subprocess.Popen(['ffmpeg','-v','info','-ss',str(max(0,t0-3)),'-i',src,'-copyts','-fps_mode','passthrough','-vf',f'crop={w}:{h}:{x}:{y},scale={W2}:{H2}:flags=area,showinfo','-f','rawvideo','-pix_fmt','gray','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    q=queue.Queue()
    def rd():
        for line in p.stderr:
            m=re.search(rb'pts_time:([0-9.]+)',line)
            if m: q.put(float(m.group(1)))
        q.put(None)
    threading.Thread(target=rd,daemon=True).start()
    T=[];B=[]
    while True:
        t=q.get()
        if t is None: break
        b=p.stdout.read(W2*H2)
        if len(b)<W2*H2: break
        if t>t1: p.kill(); break
        if t>=t0: T.append(t); B.append(b)
    return T,b''.join(B)
def run_clip(tag,src,t0,t1,frames,W,H):
    ps=pose_samples(frames,W,H); ar=peaks(frames,W,H)
    r,_=emu('ssregion',{'aspect':W/H,'pose':ps,'around':ar},tag)
    if r['region'] is None: return None
    x0,y0,x1,y1=r['region']; crop=(int(x0*W),int(y0*H),max(2,int((x1-x0)*W)),max(2,int((y1-y0)*H)))
    T,raw=roi_frames(src,t0,t1,crop,(r['width'],r['height']))
    fi=f'/tmp/claude-0/ss/{tag}_ssfind.json'
    open(fi+'.raw','wb').write(raw)
    out,_=emu('ssfind',{'aspect':W/H,'region':r['region'],'width':r['width'],'height':r['height'],'times':T,'pose':ps},tag)
    return out
