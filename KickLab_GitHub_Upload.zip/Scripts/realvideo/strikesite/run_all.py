import json,sys
sys.path.insert(0,'/tmp/claude-0/ss')
from export import run_clip
A='/mnt/user-data/uploads/IMG_4541.mov'; B='/mnt/user-data/uploads/IMG_6269.mov'
truth={'a':[(73.243,73.277),(96.247,96.280),(118.517,118.550),(143.722,143.755)],'b':[(41.650,41.685),(64.660,64.693),(86.937,86.970),(112.147,112.180)]}
aud={'a':[73.26,96.28,118.55,143.75],'b':[41.69,64.71,86.98,112.18]}
for cam in 'ab':
    pc=json.load(open(f'/tmp/claude-0/vid/poseclips_{cam}.json'))
    for k in range(4):
        c=aud[cam][k]; t0,t1=c-4,c+3
        fr=[(p['t'],p['lm']) for p in pc[str(k)] if t0<=p['t']<=t1]
        out=run_clip(f'{cam}{k+1}',A if cam=='a' else B,t0,t1,fr,1920,1080)
        r=(out or {}).get('result')
        print(cam,k+1,'%.1fs'%(out or {}).get('seconds',0),'NONE' if not r else 'ball (%.3f,%.3f) last %.3f gone %.3f clear %s swing %.1f d %.2f'%(r['center']['x'],r['center']['y'],r['lastPresentTime'],r['firstGoneTime'],r.get('firstClearTime'),r['swingAtDeparture'],r['footDistanceAtDeparture']),'| truth',truth[cam][k],flush=True)
