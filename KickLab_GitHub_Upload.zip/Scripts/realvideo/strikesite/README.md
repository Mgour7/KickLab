# Strike-site ball recognition: real-video checks (Build 22)

The scripts that produced the numbers in `Docs/BALL_RECOGNITION_BUILD22.md`. They are kept as a
record, not as a packaged tool: paths point at the developer's work folders (`/tmp/claude-0/...`)
and the two session recordings, which are never committed. Edit the paths before running.

- `export.py`: MediaPipe pose for a clip → `emu ssregion` (the region the app would decode) →
  luma frames of that region (OpenCV, area resampling like `LumaThumbnail.region`) → `emu ssfind`
  (`StrikeSiteBallFinder.find`, the app's code).
- `run_all.py`: the eight session kicks; `run_extra.py`: the Kicker AI reel and the negatives
  (Stage A candidates that are not kicks).
- `e2e.py`: feeds each finder result into `emu engine` (the app's analysis pipeline) and prints
  contact, plant, perspective and the Kick Breakdown.

Ground truth: `Datasets/reference/IMG_4541_IMG_6269_reference.json` and
`Datasets/reference/kicker_ai_reel_reference.json`.
