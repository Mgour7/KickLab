import json,sys,numpy as np,cv2
sys.path.insert(0,'/tmp/claude-0/ss')
import export as E
from export import pose_samples,peaks,emu,run_clip
# Reel
mp=json.load(open('/tmp/claude-0/reel/mp_reel.json'))
fr=[((i-2)/30,[[p[0]/1080,p[1]/1920,p[2]] for p in mp[str(i)]] if mp.get(str(i)) else None) for i in range(2,81)]
W,H=1080,1920
ps=pose_samples(fr,W,H); ar=peaks(fr,W,H)
r,_=emu('ssregion',{'aspect':W/H,'pose':ps,'around':ar},'reel')
x0,y0,x1,y1=r['region']; crop=(int(x0*W),int(y0*H),int((x1-x0)*W),int((y1-y0)*H))
raw=b''
for i in range(2,81):
    g=cv2.cvtColor(cv2.imread(f'/tmp/claude-0/reel/f/{i:04d}.jpg'),cv2.COLOR_BGR2GRAY)[crop[1]:crop[1]+crop[3],crop[0]:crop[0]+crop[2]]
    raw+=cv2.resize(g,(r['width'],r['height']),interpolation=cv2.INTER_AREA).tobytes()
fi='/tmp/claude-0/ss/reel_ssfind.json'; open(fi+'.raw','wb').write(raw)
out,_=emu('ssfind',{'aspect':W/H,'region':r['region'],'width':r['width'],'height':r['height'],'times':[f[0] for f in fr],'pose':ps},'reel')
res=out.get('result'); f=lambda t:'#%d'%(round(t*30)+2)
print('reel','NONE' if not res else (res['center'],f(res['lastPresentTime']),f(res['firstGoneTime']),res.get('firstClearTime') and f(res['firstClearTime'])),'| truth touch #43 moved #44-45',flush=True)
# Negatives
A='/mnt/user-data/uploads/IMG_4541.mov'; B='/mnt/user-data/uploads/IMG_6269.mov'
for cam,src,cs in (('a',A,[52.0,78.6,124.7,161.1]),('b',B,[4.7,11.7,18.9,51.5])):
    pss=json.load(open(f'/tmp/claude-0/vid/pose_{cam}_s3.json'))
    for c in cs:
        t0,t1=max(0,c-4),c+(2 if cam=='a' else 3)
        frs=[(p['t'],p['lm']) for p in pss if t0<=p['t']<=t1]
        out=run_clip(f'n{cam}{c}',src,t0,t1,frs,1920,1080)
        res=(out or {}).get('result')
        print('neg',cam,c,'no kick' if not res else ('FALSE KICK',res['center'],res['firstGoneTime']),flush=True)
