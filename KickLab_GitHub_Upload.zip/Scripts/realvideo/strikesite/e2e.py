import json,subprocess,os,glob
R='/tmp/claude-0/swiftdl/root'; env=dict(os.environ,LD_LIBRARY_PATH=f'{R}/usr/lib/x86_64-linux-gnu:{R}/usr/libexec/swift/lib')
EMU='/tmp/claude-0/emu/.build/release/emu'
c0={'a1':69.31,'a2':92.31,'a3':114.52,'a4':139.72,'b1':37.69,'b2':60.71,'b3':83.14,'b4':107.95}
truth={'a1':73.243,'a2':96.247,'a3':118.517,'a4':143.722,'b1':41.650,'b2':64.660,'b3':86.937,'b4':112.147}
for k in c0:
    ss=json.load(open(f'/tmp/claude-0/ss/{k}_ssfind_out.json')).get('result') if os.path.exists(f'/tmp/claude-0/ss/{k}_ssfind_out.json') else None
    for an in (['unknown','side'] if k[0]=='a' else ['rear']):
        base=f'/tmp/claude-0/vid/eng/{k}_{an}'
        fi=base+'_in.json' if os.path.exists(base+'_in.json') else base+'_p1_in.json'
        d=json.load(open(fi))
        if ss:
            s=dict(ss); 
            ft=[fr['t'] for fr in d['frames']]
            for f in ('lastPresentTime','firstGoneTime','firstClearTime'):
                if s.get(f) is not None: s[f]=min(ft,key=lambda x:abs(x-(s[f]-c0[k])))
            d['strikeSite']=s
        json.dump(d,open('/tmp/claude-0/ss/e2e_in.json','w'))
        subprocess.run([EMU,'engine','/tmp/claude-0/ss/e2e_in.json',f'/tmp/claude-0/ss/e2e_{k}_{an}.json'],check=True,env=env)
        o=json.load(open(f'/tmp/claude-0/ss/e2e_{k}_{an}.json')); w=o.get('withFootball',o['poseOnly']); e=w['evidenceOutcome']
        ct=e.get('contactTime'); src=lambda t: None if t is None else round(t+c0[k],3)
        print(k,an,(w['perspective'] or {}).get('used'),'fb',o.get('football',{}).get('method'),'|',e['contactOutcome'],src(ct),'[',src(e.get('contactEarliest')),src(e.get('contactLatest')),']','truth',truth[k],'| plant',src(e.get('plantUsed')),'|',w['outcome'],'overall',w['overallScore'])
