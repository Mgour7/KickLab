# Build 22 real-video EMULATION tooling (developer use only; not part of the app).
# Paths come from the environment:
#   KL_WORK   work directory (frame times, pose and scan JSON)      default ./work
#   KL_YOLOX  official YOLOX-S ONNX (Apache-2.0, Megvii)              required
#   KL_VIDEO_A / KL_VIDEO_B  the two recordings (never committed)    required
#   KL_EMU    built emu executable (see README.md)                   for engrun.py
#   KL_SWIFT_LIBS  extra LD_LIBRARY_PATH for a Linux Swift toolchain  optional
# Substitute inputs: MediaPipe pose (not Apple Vision) and onnxruntime YOLOX-S (not the
# Core ML conversion). Results are an emulation of KickLab's decision code, not the app.
import json, numpy as np, sys
import os as _os
WORK=_os.environ.get('KL_WORK','work')
P=lambda name: _os.path.join(WORK, name)
cam=sys.argv[1]
ys=json.load(open(P(f'yscan_{cam}.json'))); ps=json.load(open(P(f'pose_{cam}_s3.json')))
pk={p['k']:p for p in ps}
dur=float(np.load(P(f'{cam}_pts.npy'))[-1])
VIS=0.3
out=[]
for s in ys:
    k=s['k']; p=None
    for d in (0,-1,1,-2,2):
        if k+d in pk: p=pk[k+d]; break
    person=None
    if p and p['lm']:
        lm=p['lm']
        def pt(i): return {'x':lm[i][0],'y':lm[i][1]} if lm[i][2]>=VIS else None
        sh=[(lm[11][0]+lm[12][0])/2,(lm[11][1]+lm[12][1])/2]; hp=[(lm[23][0]+lm[24][0])/2,(lm[23][1]+lm[24][1])/2]
        ok=min(lm[i][2] for i in (11,12,23,24))>=VIS
        person={'leftAnkle':pt(27),'rightAnkle':pt(28),'hipCenter':{'x':hp[0],'y':hp[1]} if ok else None,
                'torsoLength':float(np.hypot(sh[0]-hp[0],sh[1]-hp[1])) if ok else None}
        person={a:b for a,b in person.items() if b is not None}
    balls=[{'cx':b['cx'],'cy':b['cy'],'w':b['w'],'h':b['h'],'score':b['s']} for b in s['balls']]
    smp={'time':s['t'],'balls':balls}
    if person: smp['person']=person
    out.append(smp)
json.dump({'duration':dur,'samples':out},open(P(f'stagea_in_{cam}.json'),'w'))
print(cam,len(out),sum(1 for o in out if 'person' in o),sum(len(o['balls']) for o in out))
