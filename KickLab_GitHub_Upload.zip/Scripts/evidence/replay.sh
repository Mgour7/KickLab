#!/usr/bin/env bash
# Replays a KickLab evidence bundle with the app's own pure analysis code (no video, no
# Vision, no Core ML needed). Requires a Swift 6 toolchain (Xcode 16+ on a Mac, or Swift 6
# on Linux). See Docs/EVIDENCE_BUNDLE_FORMAT.md.
#
#   bash Scripts/evidence/replay.sh KickLab-evidence.zip [--json report.json] [--baseline old.json] [--extract dir]
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORK="${KICKLAB_REPLAY_BUILD:-${TMPDIR:-/tmp}/kicklab-evidence-replay}"
mkdir -p "$WORK/Sources/KickLabCore" "$WORK/Sources/kicklab-replay"
rm -f "$WORK/Sources/KickLabCore/"*.swift
# The app's platform-independent sources (no SwiftData, SwiftUI or Apple-only frameworks).
EXCLUDE='^(Kick\+Outcome|AnalysisIntegrityValidator|VideoAnalysisRequest\+Kick)\.swift$'
for f in $(find "$ROOT/KickLab/Models" "$ROOT/KickLab/Services" "$ROOT/KickLab/Utilities" "$ROOT/KickLab/Presentation" -name '*.swift'); do
  name=$(basename "$f")
  if grep -q '^import SwiftData' "$f" || [[ "$name" =~ $EXCLUDE ]]; then continue; fi
  ln -sf "$f" "$WORK/Sources/KickLabCore/$name"
done
ln -sf "$ROOT/Scripts/evidence/main.swift" "$WORK/Sources/kicklab-replay/main.swift"
# Make the core module's internal API visible to the tool (same module boundary as tests).
cat > "$WORK/Package.swift" <<'PKG'
// swift-tools-version:6.0
import PackageDescription
let package = Package(
    name: "kicklab-replay",
    targets: [
        .target(name: "KickLabCore", path: "Sources/KickLabCore", swiftSettings: [.unsafeFlags(["-enable-testing"])]),
        .executableTarget(name: "kicklab-replay", dependencies: ["KickLabCore"], path: "Sources/kicklab-replay"),
    ]
)
PKG
(cd "$WORK" && swift build -c release --product kicklab-replay >&2)
exec "$WORK/.build/release/kicklab-replay" "$@"
