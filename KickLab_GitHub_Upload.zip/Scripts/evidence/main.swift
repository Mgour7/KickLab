// KickLab evidence replay tool (build 15). Built by replay.sh from the app's own pure
// sources — the same decision code the iPhone runs after Vision and Core ML.
//
//   replay.sh BUNDLE.zip|FOLDER [--json OUT.json] [--baseline PREVIOUS.json] [--extract DIR]
//
// Exit status: 0 identical to the recording (and to the baseline, when given),
//              1 differences, 2 the bundle was rejected.
import Foundation
@testable import KickLabCore

var args = Array(CommandLine.arguments.dropFirst())
@MainActor func option(_ name: String) -> String? {
    guard let i = args.firstIndex(of: name), i + 1 < args.count else { return nil }
    let v = args[i + 1]
    args.removeSubrange(i...(i + 1))
    return v
}
let jsonOut = option("--json"), baselinePath = option("--baseline"), extract = option("--extract")
guard let input = args.first else {
    FileHandle.standardError.write(Data("usage: replay.sh BUNDLE.zip|FOLDER [--json OUT.json] [--baseline PREVIOUS.json] [--extract DIR]\n".utf8))
    exit(2)
}
let url = URL(fileURLWithPath: input)
let contents: EvidenceContents
do {
    var isDir: ObjCBool = false
    if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue {
        var files: [String: Data] = [:]
        var total = 0
        let base = url.standardizedFileURL.path
        if let walker = FileManager.default.enumerator(at: url, includingPropertiesForKeys: nil) {
            for case let f as URL in walker {
                var d: ObjCBool = false
                guard FileManager.default.fileExists(atPath: f.path, isDirectory: &d), !d.boolValue else { continue }
                let rel = String(f.standardizedFileURL.path.dropFirst(base.count + 1))
                guard StoredZip.isSafePath(rel), files.count < StoredZip.Limits.standard.maximumEntries else { continue }
                let data = try Data(contentsOf: f)
                total += data.count
                guard total <= StoredZip.Limits.standard.maximumTotalBytes else { throw StoredZip.ZipError.tooLarge("folder") }
                files[rel] = data
            }
        }
        contents = try EvidenceBundle.read(files: files)
    } else {
        let data = try Data(contentsOf: url)
        contents = try EvidenceBundle.read(zip: data)
        if let extract {
            for e in try StoredZip.read(data) {
                let target = URL(fileURLWithPath: extract).appendingPathComponent(e.path)
                try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                try e.data.write(to: target)
            }
        }
    }
} catch {
    FileHandle.standardError.write(Data("REJECTED: \(error)\n".utf8))
    exit(2)
}
let report = EvidenceReplay.run(contents)
print(report.text)
if !contents.manifest.unavailable.isEmpty {
    print("unavailable in this bundle:")
    contents.manifest.unavailable.forEach { print("  - \($0)") }
}
var status: Int32 = report.matchesRecording ? 0 : 1
if let baselinePath {
    do {
        let baseline = try EvidenceBundle.jsonDecoder().decode(EvidenceReplayReport.self, from: Data(contentsOf: URL(fileURLWithPath: baselinePath)))
        let diffs = EvidenceReplay.compare(baseline: baseline, current: report)
        print(diffs.isEmpty ? "BASELINE (\(baseline.replayEngineVersion)): unchanged" : "BASELINE (\(baseline.replayEngineVersion)): \(diffs.count) change(s)")
        diffs.forEach { print("  \($0.field): baseline \($0.recorded) → now \($0.replayed)") }
        if !diffs.isEmpty { status = 1 }
    } catch {
        FileHandle.standardError.write(Data("baseline unreadable: \(error)\n".utf8))
        exit(2)
    }
}
if let jsonOut { try? EvidenceBundle.jsonEncoder().encode(report).write(to: URL(fileURLWithPath: jsonOut)) }
exit(status)
