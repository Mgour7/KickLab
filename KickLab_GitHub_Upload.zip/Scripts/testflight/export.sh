#!/usr/bin/env bash
#
# Exports a signed, App Store Connect–ready .ipa from build/KickLab.xcarchive.
#   automatic: Xcode cloud signing (-allowProvisioningUpdates + the API key). Xcode
#              creates or reuses the App Store profile and a cloud-managed Apple
#              Distribution certificate. Needs a team API key with the Admin role.
#   manual:    the imported Apple Distribution certificate and App Store profile.
#
# Writes build/export/KickLab.ipa.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

mode="${KICKLAB_SIGNING_MODE:-automatic}"
: "${KICKLAB_API_KEY_PATH:?}" "${ASC_KEY_ID:?}" "${ASC_ISSUER_ID:?}"
log_dir="${KICKLAB_LOG_DIR:-build/logs}"
mkdir -p "$log_dir"
rm -rf build/export

bash "$HERE/make-export-options.sh" build/ExportOptions.plist

args=(
    -exportArchive
    -archivePath build/KickLab.xcarchive
    -exportPath build/export
    -exportOptionsPlist build/ExportOptions.plist
)
if [[ "$mode" == "automatic" ]]; then
    args+=(
        -allowProvisioningUpdates
        -authenticationKeyPath "$KICKLAB_API_KEY_PATH"
        -authenticationKeyID "$ASC_KEY_ID"
        -authenticationKeyIssuerID "$ASC_ISSUER_ID"
    )
fi

section "Export signed .ipa ($mode signing; full log: $log_dir/export.log)"
status=0
xcodebuild "${args[@]}" > "$log_dir/export.log" 2>&1 || status=$?
if [[ $status -ne 0 ]]; then
    grep -E "(error:|\*\* EXPORT FAILED)" "$log_dir/export.log" | sort -u | head -n 40 || true
    tail -n 40 "$log_dir/export.log"
    if grep -q "Cloud signing permission error" "$log_dir/export.log"; then
        echo "hint: automatic signing needs a TEAM API key with the Admin role. Create one, or use manual signing (see Deployment/TESTFLIGHT.md)."
    fi
    if grep -qiE "agreement|Program License" "$log_dir/export.log"; then
        echo "hint: accept the latest agreements at developer.apple.com and in App Store Connect → Business."
    fi
    fail "export failed (exit $status)."
fi
ipa="$(find build/export -maxdepth 1 -name '*.ipa' -print -quit)"
[[ -n "$ipa" ]] || fail "export finished but produced no .ipa."
[[ "$ipa" == "build/export/KickLab.ipa" ]] || mv "$ipa" build/export/KickLab.ipa
note "Exported build/export/KickLab.ipa"
