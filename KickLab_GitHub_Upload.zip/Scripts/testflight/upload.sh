#!/usr/bin/env bash
#
# Validates and uploads the .ipa to App Store Connect with Apple's altool, authenticated
# by the App Store Connect API key (no Apple ID password, no app-specific password).
#
# Usage: upload.sh <KickLab.ipa>
# Reads: ASC_KEY_ID, ASC_ISSUER_ID, KICKLAB_SIGNING_DIR (holds private_keys/AuthKey_<ID>.p8)

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

ipa="$(cd "$(dirname "${1:?usage: upload.sh <KickLab.ipa>}")" && pwd)/$(basename "$1")"
[[ -f "$ipa" ]] || fail "no .ipa to upload."
[[ -f "$KICKLAB_SIGNING_DIR/private_keys/AuthKey_${ASC_KEY_ID}.p8" ]] || fail "the API key isn't installed (prepare-signing.sh must run first)."
log_dir="${KICKLAB_LOG_DIR:-build/logs}"
mkdir -p "$log_dir"
log_dir="$(cd "$log_dir" && pwd)"

# altool looks for AuthKey_<ID>.p8 in ./private_keys, so run it from the signing folder.
cd "$KICKLAB_SIGNING_DIR"

section "Validate with App Store Connect"
if ! xcrun altool --validate-app --type ios --file "$ipa" \
        --apiKey "$ASC_KEY_ID" --apiIssuer "$ASC_ISSUER_ID" > "$log_dir/validate.log" 2>&1; then
    tail -n 60 "$log_dir/validate.log"
    fail "App Store Connect rejected the build during validation (see validate.log)."
fi
tail -n 20 "$log_dir/validate.log"

section "Upload to App Store Connect"
if ! xcrun altool --upload-app --type ios --file "$ipa" \
        --apiKey "$ASC_KEY_ID" --apiIssuer "$ASC_ISSUER_ID" > "$log_dir/upload.log" 2>&1; then
    tail -n 60 "$log_dir/upload.log"
    fail "the upload failed (see upload.log)."
fi
tail -n 20 "$log_dir/upload.log"
note "Uploaded. App Store Connect usually finishes processing in 5–30 minutes; the build then appears under TestFlight."
