#!/usr/bin/env python3
"""Writes the App Store Connect API private key (.p8) from the ASC_API_PRIVATE_KEY
environment variable to <directory>/AuthKey_<ASC_KEY_ID>.p8 with owner-only access.

Accepts the file pasted as-is, the file with its line breaks turned into spaces (common
when copying on a phone), or base64 of the file. Never prints the key.
"""
import base64
import os
import re
import sys

BEGIN = "-----BEGIN PRIVATE KEY-----"
END = "-----END PRIVATE KEY-----"


def normalized(raw: str) -> str:
    text = raw.strip()
    if BEGIN not in text:
        try:
            text = base64.b64decode("".join(text.split()), validate=True).decode("utf-8").strip()
        except Exception:
            raise SystemExit("error: ASC_API_PRIVATE_KEY is not a .p8 private key (no BEGIN PRIVATE KEY line).")
    match = re.search(re.escape(BEGIN) + r"(.*?)" + re.escape(END), text, re.S)
    if not match:
        raise SystemExit("error: ASC_API_PRIVATE_KEY is incomplete (missing the END PRIVATE KEY line).")
    body = "".join(match.group(1).split())
    try:
        base64.b64decode(body, validate=True)
    except Exception:
        raise SystemExit("error: ASC_API_PRIVATE_KEY has damaged key data. Paste the .p8 file again.")
    lines = [body[i:i + 64] for i in range(0, len(body), 64)]
    return "\n".join([BEGIN, *lines, END]) + "\n"


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: write-api-key.py <directory>")
    key_id = os.environ.get("ASC_KEY_ID", "").strip()
    raw = os.environ.get("ASC_API_PRIVATE_KEY", "")
    if not key_id or not raw:
        raise SystemExit("error: ASC_KEY_ID and ASC_API_PRIVATE_KEY are required.")
    directory = sys.argv[1]
    os.makedirs(directory, mode=0o700, exist_ok=True)
    path = os.path.join(directory, f"AuthKey_{key_id}.p8")
    content = normalized(raw)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write(content)
    print(path)


if __name__ == "__main__":
    main()
