#!/usr/bin/env bash
# Shared helpers for the TestFlight scripts. Never prints credential values.
# shellcheck disable=SC2034  # variables here are used by the scripts that source this file

section() { printf '\n==> %s\n' "$*"; }
note() { printf '    %s\n' "$*"; }
fail() { printf '\nerror: %s\n' "$*" >&2; exit 1; }

# Writes KEY=VALUE for later workflow steps (or prints it outside GitHub Actions).
export_env() {
    local name="$1" value="$2"
    if [[ -n "${GITHUB_ENV:-}" ]]; then
        printf '%s=%s\n' "$name" "$value" >> "$GITHUB_ENV"
    fi
    export "$name=$value"
}

# Decodes base64 from stdin, ignoring whitespace/line breaks (pasted values often wrap).
b64decode() {
    python3 -c 'import base64, sys; sys.stdout.buffer.write(base64.b64decode("".join(sys.stdin.read().split()), validate=True))'
}

# Where signing material lives during a run (removed by cleanup-signing.sh).
KICKLAB_SIGNING_DIR="${KICKLAB_SIGNING_DIR:-${RUNNER_TEMP:-/tmp}/kicklab-signing}"
KICKLAB_KEYCHAIN="${KICKLAB_SIGNING_DIR}/kicklab-signing.keychain-db"
