#!/usr/bin/env bash
#
# Self-tests for the TestFlight scripts and workflow. Runs on Linux or macOS without any
# Apple account: it uses throwaway, locally generated keys and never contacts Apple.
#
# Usage: bash Scripts/testflight/selftest.sh
#
# Checks are written as strings evaluated later by expect(), so variables in single
# quotes are intentional here.
# shellcheck disable=SC2016,SC2034,SC2015

set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
passed=0
failed=0

pass() { passed=$((passed + 1)); printf '  ✓ %s\n' "$1"; }
flunk() { failed=$((failed + 1)); printf '  ✗ %s\n' "$1"; }
expect() { if eval "$2"; then pass "$1"; else flunk "$1"; fi; }

# A throwaway P-256 key in .p8 (PKCS#8) form, like App Store Connect issues.
openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out "$TMP/AuthKey_TEST123456.p8" 2> /dev/null
FAKE_KEY="$(cat "$TMP/AuthKey_TEST123456.p8")"
SENTINEL="sentinel-value-that-must-never-be-printed"

valid_env() {
    env -i PATH="$PATH" HOME="$HOME" \
        APPLE_TEAM_ID=ABCDE12345 ASC_KEY_ID=TEST123456 \
        ASC_ISSUER_ID=69a6de70-03db-47e3-e053-5b8c7c11a4d1 \
        ASC_API_PRIVATE_KEY="$FAKE_KEY" "$@"
}

echo "validate-config.sh"
out="$(env -i PATH="$PATH" bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "fails when nothing is configured" '[[ $status -ne 0 ]]'
for name in APPLE_TEAM_ID ASC_KEY_ID ASC_ISSUER_ID ASC_API_PRIVATE_KEY; do
    expect "reports $name by name" 'grep -q "✗ $name" <<< "$out"'
done
expect "says nothing was built" 'grep -q "Nothing was built or uploaded" <<< "$out"'

out="$(valid_env bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "passes with valid automatic settings" '[[ $status -eq 0 ]]'
expect "never prints the private key" '! grep -q "BEGIN PRIVATE KEY" <<< "$out"'

out="$(valid_env APPLE_TEAM_ID="$SENTINEL" bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "rejects a malformed team ID" '[[ $status -ne 0 ]] && grep -q "✗ APPLE_TEAM_ID" <<< "$out"'
expect "never echoes a bad value" '! grep -q "$SENTINEL" <<< "$out"'

out="$(valid_env ASC_API_PRIVATE_KEY="$SENTINEL" bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "rejects a value that isn't a .p8 key" '[[ $status -ne 0 ]] && grep -q "✗ ASC_API_PRIVATE_KEY" <<< "$out"'
expect "never echoes a bad key" '! grep -q "$SENTINEL" <<< "$out"'

b64key="$(printf '%s' "$FAKE_KEY" | base64 | tr -d '\n')"
out="$(valid_env ASC_API_PRIVATE_KEY="$b64key" bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "accepts a base64-encoded .p8" '[[ $status -eq 0 ]]'

out="$(valid_env KICKLAB_SIGNING_MODE=manual bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "manual mode requires the certificate and profile" '[[ $status -ne 0 ]]'
for name in IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64 IOS_DISTRIBUTION_CERTIFICATE_PASSWORD IOS_APPSTORE_PROFILE_BASE64; do
    expect "manual mode reports $name" 'grep -q "✗ $name" <<< "$out"'
done
out="$(valid_env KICKLAB_SIGNING_MODE=manual IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64='not base64!!' \
        IOS_DISTRIBUTION_CERTIFICATE_PASSWORD=x IOS_APPSTORE_PROFILE_BASE64=aGVsbG8= bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "manual mode rejects invalid base64" '[[ $status -ne 0 ]] && grep -q "isn.t valid base64" <<< "$out"'
out="$(valid_env KICKLAB_SIGNING_MODE=sideways bash "$HERE/validate-config.sh" 2>&1)"; status=$?
expect "rejects an unknown signing mode" '[[ $status -ne 0 ]] && grep -q "✗ KICKLAB_SIGNING_MODE" <<< "$out"'

echo "write-api-key.py"
mk() { env -i PATH="$PATH" ASC_KEY_ID=TEST123456 ASC_API_PRIVATE_KEY="$1" python3 "$HERE/write-api-key.py" "$TMP/keys" 2>&1; }
out="$(mk "$FAKE_KEY")"; status=$?
expect "writes AuthKey_<ID>.p8" '[[ $status -eq 0 && -f "$TMP/keys/AuthKey_TEST123456.p8" ]]'
expect "the file is owner-only (600)" '[[ "$(stat -c %a "$TMP/keys/AuthKey_TEST123456.p8" 2>/dev/null || stat -f %Lp "$TMP/keys/AuthKey_TEST123456.p8")" == "600" ]]'
expect "the written key is a valid private key" 'openssl pkey -in "$TMP/keys/AuthKey_TEST123456.p8" -noout 2>/dev/null'
flattened="$(tr '\n' ' ' <<< "$FAKE_KEY")"
rm -rf "$TMP/keys"; out="$(mk "$flattened")"; status=$?
expect "repairs a key whose line breaks became spaces" '[[ $status -eq 0 ]] && openssl pkey -in "$TMP/keys/AuthKey_TEST123456.p8" -noout 2>/dev/null'
rm -rf "$TMP/keys"; out="$(mk "$b64key")"; status=$?
expect "accepts base64 of the key" '[[ $status -eq 0 ]] && openssl pkey -in "$TMP/keys/AuthKey_TEST123456.p8" -noout 2>/dev/null'
out="$(mk "$SENTINEL")"; status=$?
expect "rejects garbage without printing it" '[[ $status -ne 0 ]] && ! grep -q "$SENTINEL" <<< "$out"'

echo "build-number.sh"
bn() { env -i PATH="$PATH" "$@" bash "$HERE/build-number.sh" 2>&1; }
expect "run number" '[[ "$(bn GITHUB_RUN_NUMBER=7)" == "7" ]]'
expect "run number + offset" '[[ "$(bn GITHUB_RUN_NUMBER=7 KICKLAB_BUILD_NUMBER_OFFSET=100)" == "107" ]]'
expect "manual override wins" '[[ "$(bn GITHUB_RUN_NUMBER=7 BUILD_NUMBER_OVERRIDE=42)" == "42" ]]'
expect "rejects a non-numeric override" '! bn GITHUB_RUN_NUMBER=7 BUILD_NUMBER_OVERRIDE=4a > /dev/null'
expect "rejects zero" '! bn BUILD_NUMBER_OVERRIDE=0 > /dev/null'
expect "fails without a run number" '! bn > /dev/null'
expect "grows with every run" '[[ "$(bn GITHUB_RUN_NUMBER=8)" -gt "$(bn GITHUB_RUN_NUMBER=7)" ]]'

echo "make-export-options.sh"
plist_check() {
    python3 - "$1" "$2" << 'PY'
import plistlib, sys
p = plistlib.load(open(sys.argv[1], "rb"))
mode = sys.argv[2]
assert p["method"] == "app-store-connect", p
assert p["destination"] == "export", p
assert p["teamID"] == "ABCDE12345", p
assert p["signingStyle"] == mode, p
assert p["manageAppVersionAndBuildNumber"] is False, p
if mode == "manual":
    assert p["signingCertificate"] == "Apple Distribution", p
    assert p["provisioningProfiles"] == {"com.kicklab.app": "1111-2222"}, p
else:
    assert "provisioningProfiles" not in p, p
PY
}
env -i PATH="$PATH" APPLE_TEAM_ID=ABCDE12345 KICKLAB_BUNDLE_ID=com.kicklab.app bash "$HERE/make-export-options.sh" "$TMP/auto.plist" > /dev/null
expect "automatic export options" 'plist_check "$TMP/auto.plist" automatic'
env -i PATH="$PATH" APPLE_TEAM_ID=ABCDE12345 KICKLAB_BUNDLE_ID=com.kicklab.app KICKLAB_SIGNING_MODE=manual \
    KICKLAB_PROFILE_UUID=1111-2222 bash "$HERE/make-export-options.sh" "$TMP/manual.plist" > /dev/null
expect "manual export options" 'plist_check "$TMP/manual.plist" manual'
expect "manual mode needs a profile" '! env -i PATH="$PATH" APPLE_TEAM_ID=ABCDE12345 KICKLAB_BUNDLE_ID=com.kicklab.app KICKLAB_SIGNING_MODE=manual bash "$HERE/make-export-options.sh" "$TMP/x.plist" > /dev/null 2>&1'

echo "check-project-identity.sh"
cat > "$TMP/settings.txt" << 'TXT'
Build settings for action build and target KickLab:
    ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon
    IPHONEOS_DEPLOYMENT_TARGET = 18.0
    MARKETING_VERSION = 0.1.0
    PRODUCT_BUNDLE_IDENTIFIER = com.kicklab.app
    TARGETED_DEVICE_FAMILY = 1
TXT
out="$(env -i PATH="$PATH" bash "$HERE/check-project-identity.sh" "$TMP/settings.txt" 2>&1)"; status=$?
expect "accepts the KickLab identity" '[[ $status -eq 0 ]] && grep -q "com.kicklab.app" <<< "$out"'
out="$(env -i PATH="$PATH" KICKLAB_BUNDLE_ID_EXPECTED=com.other.app bash "$HERE/check-project-identity.sh" "$TMP/settings.txt" 2>&1)"; status=$?
expect "catches a bundle ID that differs from App Store Connect" '[[ $status -ne 0 ]] && grep -q "doesn.t match" <<< "$out"'
sed 's/TARGETED_DEVICE_FAMILY = 1/TARGETED_DEVICE_FAMILY = 1,2/' "$TMP/settings.txt" > "$TMP/ipad.txt"
expect "rejects iPad in the first beta" '! env -i PATH="$PATH" bash "$HERE/check-project-identity.sh" "$TMP/ipad.txt" > /dev/null 2>&1'
grep -v APPICON "$TMP/settings.txt" > "$TMP/noicon.txt"
expect "rejects a build without an app icon" '! env -i PATH="$PATH" bash "$HERE/check-project-identity.sh" "$TMP/noicon.txt" > /dev/null 2>&1'

echo "cleanup-signing.sh"
mkdir -p "$TMP/signing/private_keys"; echo x > "$TMP/signing/private_keys/AuthKey_X.p8"
env -i PATH="$PATH" HOME="$TMP" KICKLAB_SIGNING_DIR="$TMP/signing" bash "$HERE/cleanup-signing.sh" > /dev/null; status=$?
expect "removes the signing folder and exits 0" '[[ $status -eq 0 && ! -e "$TMP/signing" ]]'
env -i PATH="$PATH" HOME="$TMP" KICKLAB_SIGNING_DIR="$TMP/signing" bash "$HERE/cleanup-signing.sh" > /dev/null; status=$?
expect "is safe to run twice" '[[ $status -eq 0 ]]'

echo "ios-testflight.yml"
WORKFLOW="${WORKFLOW:-$ROOT/Deployment/ios-testflight.yml}"
python3 - "$WORKFLOW" "$ROOT" << 'PY' && pass "workflow structure" || flunk "workflow structure"
import os, re, sys, yaml
path, root = sys.argv[1], sys.argv[2]
text = open(path).read()
w = yaml.safe_load(text)
on = w.get("on", w.get(True))           # PyYAML reads the key `on` as True
assert list(on.keys()) == ["workflow_dispatch"], f"must be manual only, got {list(on)}"
assert w["permissions"] == {"contents": "read"}, w["permissions"]
job = w["jobs"]["deploy"]
assert job["runs-on"].startswith("macos"), job["runs-on"]
steps = job["steps"]
names = [s.get("name", "") for s in steps]
order = ["Check TestFlight settings", "Select newest stable Xcode (26 or later)", "Generate the Xcode project",
         "Install signing material (temporary)", "Archive for iOS devices", "Export signed .ipa",
         "Verify the .ipa", "Upload to TestFlight", "Clean up signing material"]
positions = [names.index(n) for n in order]
assert positions == sorted(positions), "steps out of order"
cleanup = steps[names.index("Clean up signing material")]
assert cleanup.get("if") == "always()", "cleanup must always run"
upload = steps[names.index("Upload to TestFlight")]
assert upload.get("if") == "${{ inputs.upload }}", upload.get("if")
for s in steps:
    run = s.get("run", "")
    assert "set -x" not in run, "never trace commands (could print secrets)"
    assert "${{ secrets." not in run, f"secrets must reach scripts through env, not inline: {s.get('name')}"
    assert not re.search(r"echo[^\n]*\$\{?(ASC_API_PRIVATE_KEY|IOS_DISTRIBUTION_CERTIFICATE|IOS_APPSTORE_PROFILE)", run), "never echo a secret"
    for script in re.findall(r"Scripts/testflight/[\w.-]+", run):
        assert os.path.exists(os.path.join(root, script)), f"missing {script}"
secret_names = set(re.findall(r"secrets\.([A-Z0-9_]+)", text))
assert secret_names <= {"ASC_API_PRIVATE_KEY", "IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64", "IOS_DISTRIBUTION_CERTIFICATE_PASSWORD",
                        "IOS_APPSTORE_PROFILE_BASE64", "APPLE_TEAM_ID", "ASC_KEY_ID", "ASC_ISSUER_ID"}, secret_names
PY

echo "repository hygiene"
leaks="$(cd "$ROOT" && find . \( -name '*.p8' -o -name '*.p12' -o -name '*.mobileprovision' -o -name '*.cer' -o -name '*.keychain*' \) -not -path './build/*' -print)"
expect "no certificates, keys or profiles in the project" '[[ -z "$leaks" ]]'
expect "no private key text in the project" '! grep -rIl --exclude-dir=build --exclude=selftest.sh --exclude=write-api-key.py --exclude=validate-config.sh --exclude="*.md" "BEGIN PRIVATE KEY" "$ROOT" > /dev/null'

if command -v shellcheck > /dev/null 2>&1; then
    (cd "$HERE" && shellcheck -x ./*.sh) && pass "shellcheck" || flunk "shellcheck"
fi
if command -v actionlint > /dev/null 2>&1; then
    actionlint "$WORKFLOW" && pass "actionlint" || flunk "actionlint"
fi

printf '\n%d passed, %d failed\n' "$passed" "$failed"
[[ $failed -eq 0 ]]
