#!/usr/bin/env bash
#
# Archives KickLab for iOS devices (Release). The archive is left unsigned; it is signed
# for distribution during export (export.sh), which avoids needing a development
# certificate or a registered device on the CI machine.
#
# Reads: KICKLAB_BUILD_NUMBER, APPLE_TEAM_ID. Writes build/KickLab.xcarchive.

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

: "${KICKLAB_BUILD_NUMBER:?}" "${APPLE_TEAM_ID:?}"
log_dir="${KICKLAB_LOG_DIR:-build/logs}"
mkdir -p "$log_dir"
rm -rf build/KickLab.xcarchive

section "Archive KickLab (build $KICKLAB_BUILD_NUMBER; full log: $log_dir/archive.log)"
status=0
xcodebuild archive \
    -project KickLab.xcodeproj \
    -scheme KickLab \
    -configuration Release \
    -destination "generic/platform=iOS" \
    -archivePath build/KickLab.xcarchive \
    -derivedDataPath build/DerivedData \
    CURRENT_PROJECT_VERSION="$KICKLAB_BUILD_NUMBER" \
    DEVELOPMENT_TEAM="$APPLE_TEAM_ID" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    > "$log_dir/archive.log" 2>&1 || status=$?

grep -E ": warning: " "$log_dir/archive.log" | sort -u > "$log_dir/archive-warnings.txt" || true
note "Compiler warnings: $(wc -l < "$log_dir/archive-warnings.txt" | tr -d ' ')"
if [[ $status -ne 0 ]]; then
    grep -E "(error:|\*\* ARCHIVE FAILED)" "$log_dir/archive.log" | sort -u | head -n 60 || true
    tail -n 60 "$log_dir/archive.log"
    fail "archive failed (exit $status)."
fi
[[ -d build/KickLab.xcarchive/Products/Applications/KickLab.app ]] || fail "the archive has no KickLab.app."
note "Archive created."
