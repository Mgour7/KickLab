#!/usr/bin/env bash
#
# Removes every piece of signing material this run created. Safe to run more than once
# and when earlier steps failed. Always exits 0.

set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

section "Clean up signing material"
if [[ "$(uname -s)" == "Darwin" && -f "$KICKLAB_KEYCHAIN" ]]; then
    security delete-keychain "$KICKLAB_KEYCHAIN" > /dev/null 2>&1 || true
    note "Temporary keychain deleted."
fi
if [[ -f "$KICKLAB_SIGNING_DIR/installed-profile-uuid" ]]; then
    uuid="$(cat "$KICKLAB_SIGNING_DIR/installed-profile-uuid")"
    rm -f "$HOME/Library/MobileDevice/Provisioning Profiles/$uuid.mobileprovision" \
          "$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles/$uuid.mobileprovision"
    note "Provisioning profile removed."
fi
rm -rf "$KICKLAB_SIGNING_DIR"
rm -f build/ExportOptions.plist
note "Signing directory removed."
exit 0
