#!/usr/bin/env bash
#
# Prints the build number (CFBundleVersion) for this upload.
#   1. BUILD_NUMBER_OVERRIDE (a manual workflow input), when given, or
#   2. GITHUB_RUN_NUMBER + KICKLAB_BUILD_NUMBER_OFFSET (default 0).
# GitHub's run number grows with every run of the workflow, so each upload gets a new,
# higher build number. If the workflow is ever recreated (its run number restarts),
# raise KICKLAB_BUILD_NUMBER_OFFSET above the last uploaded build.

set -euo pipefail

override="${BUILD_NUMBER_OVERRIDE:-}"
offset="${KICKLAB_BUILD_NUMBER_OFFSET:-0}"
run="${GITHUB_RUN_NUMBER:-}"

if [[ -n "$override" ]]; then
    [[ "$override" =~ ^[1-9][0-9]{0,8}$ ]] || { echo "error: build number override must be a whole number from 1 to 999999999." >&2; exit 1; }
    echo "$override"
    exit 0
fi
[[ "$offset" =~ ^[0-9]{1,8}$ ]] || { echo "error: KICKLAB_BUILD_NUMBER_OFFSET must be a whole number." >&2; exit 1; }
[[ "$run" =~ ^[1-9][0-9]{0,8}$ ]] || { echo "error: GITHUB_RUN_NUMBER is not available; pass a build number override." >&2; exit 1; }
echo $(( run + offset ))
