#!/usr/bin/env bash
#
# Reads the KickLab target's identity from `xcodebuild -showBuildSettings` output and
# checks it is distributable. project.yml is the single source of truth; the optional
# KICKLAB_BUNDLE_ID repository variable is only a cross-check against App Store Connect.
#
# Usage: check-project-identity.sh <build-settings.txt>
# Exports (for later steps): KICKLAB_BUNDLE_ID, KICKLAB_MARKETING_VERSION

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

settings="${1:?usage: check-project-identity.sh <build-settings.txt>}"
setting() { sed -nE "s/^[[:space:]]*$1 = (.*)$/\1/p" "$settings" | head -n 1; }

bundle="$(setting PRODUCT_BUNDLE_IDENTIFIER)"
version="$(setting MARKETING_VERSION)"
family="$(setting TARGETED_DEVICE_FAMILY)"
target="$(setting IPHONEOS_DEPLOYMENT_TARGET)"
icon="$(setting ASSETCATALOG_COMPILER_APPICON_NAME)"

section "App identity"
note "Bundle identifier: ${bundle:-<missing>}"
note "Version:           ${version:-<missing>}"
note "Device family:     ${family:-<missing>} (1 = iPhone)"
note "Minimum iOS:       ${target:-<missing>}"
note "App icon:          ${icon:-<missing>}"

[[ "$bundle" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]] || fail "PRODUCT_BUNDLE_IDENTIFIER is missing or invalid in project.yml."
[[ "$version" =~ ^[0-9]+(\.[0-9]+){0,2}$ ]] || fail "MARKETING_VERSION must look like 0.1.0."
[[ "$family" == "1" ]] || fail "TARGETED_DEVICE_FAMILY must be 1 (iPhone) for the first beta."
[[ -n "$icon" ]] || fail "ASSETCATALOG_COMPILER_APPICON_NAME is not set; TestFlight requires an app icon."
if [[ -n "${KICKLAB_BUNDLE_ID_EXPECTED:-}" && "$KICKLAB_BUNDLE_ID_EXPECTED" != "$bundle" ]]; then
    fail "the KICKLAB_BUNDLE_ID variable ($KICKLAB_BUNDLE_ID_EXPECTED) doesn't match project.yml ($bundle). Use the identifier registered in App Store Connect in both places."
fi
export_env KICKLAB_BUNDLE_ID "$bundle"
export_env KICKLAB_MARKETING_VERSION "$version"
