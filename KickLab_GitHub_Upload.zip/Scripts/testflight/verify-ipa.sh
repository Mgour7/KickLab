#!/usr/bin/env bash
#
# Checks the exported .ipa before upload: app present, identity and version as expected,
# signed for distribution by the right team, with an embedded provisioning profile.
#
# Usage: verify-ipa.sh <KickLab.ipa>
# Reads: KICKLAB_BUNDLE_ID, KICKLAB_MARKETING_VERSION, KICKLAB_BUILD_NUMBER, APPLE_TEAM_ID

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

ipa="${1:?usage: verify-ipa.sh <KickLab.ipa>}"
[[ -f "$ipa" ]] || fail "no .ipa was exported."
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
unzip -q "$ipa" -d "$work"
app="$(find "$work/Payload" -maxdepth 1 -name '*.app' -print -quit)"
[[ -n "$app" ]] || fail "the .ipa has no app inside Payload/."

read_plist() { /usr/libexec/PlistBuddy -c "Print :$1" "$app/Info.plist" 2> /dev/null || true; }
bundle="$(read_plist CFBundleIdentifier)"
version="$(read_plist CFBundleShortVersionString)"
build="$(read_plist CFBundleVersion)"
section "Exported app"
note "Bundle identifier: $bundle"
note "Version (build):   $version ($build)"
[[ "$bundle" == "$KICKLAB_BUNDLE_ID" ]] || fail "the app's bundle identifier is $bundle, expected $KICKLAB_BUNDLE_ID."
[[ "$version" == "$KICKLAB_MARKETING_VERSION" ]] || fail "the app's version is $version, expected $KICKLAB_MARKETING_VERSION."
[[ "$build" == "$KICKLAB_BUILD_NUMBER" ]] || fail "the app's build number is $build, expected $KICKLAB_BUILD_NUMBER."
[[ -f "$app/embedded.mobileprovision" ]] || fail "the app has no embedded provisioning profile."
[[ -f "$app/PrivacyInfo.xcprivacy" ]] || fail "the app is missing its privacy manifest."

signature="$(codesign -dv --verbose=2 "$app" 2>&1 || true)"
grep -q "^TeamIdentifier=$APPLE_TEAM_ID$" <<< "$signature" || fail "the app isn't signed by team APPLE_TEAM_ID."
authority="$(grep -m1 '^Authority=' <<< "$signature" | cut -d= -f2-)"
note "Signed by:         ${authority:-unknown}"
if [[ "$authority" != Apple\ Distribution* && "$authority" != iPhone\ Distribution* ]]; then
    note "warning: the signing certificate name doesn't start with 'Apple Distribution'; checking the profile instead."
fi
codesign --verify --deep --strict "$app" || fail "the app's signature doesn't verify."
note "Signature verified."

# The embedded profile must be an App Store profile: no device list, not debuggable.
profile_plist="$work/embedded.plist"
security cms -D -i "$app/embedded.mobileprovision" > "$profile_plist" 2> /dev/null || fail "the embedded provisioning profile can't be read."
devices="$(/usr/libexec/PlistBuddy -c 'Print :ProvisionedDevices' "$profile_plist" 2> /dev/null || true)"
debuggable="$(/usr/libexec/PlistBuddy -c 'Print :Entitlements:get-task-allow' "$profile_plist" 2> /dev/null || true)"
[[ -z "$devices" ]] || fail "the app was signed with a Development or Ad Hoc profile, not an App Store profile."
[[ "$debuggable" != "true" ]] || fail "the app was signed for debugging, not for distribution."
note "Embedded profile is an App Store profile."
