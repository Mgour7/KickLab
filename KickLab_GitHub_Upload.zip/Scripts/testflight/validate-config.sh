#!/usr/bin/env bash
#
# Checks the TestFlight configuration BEFORE any build time is spent.
# Reports each missing or malformed setting by NAME; never prints a value.
#
# Reads (environment):
#   KICKLAB_SIGNING_MODE   automatic (default) | manual
#   APPLE_TEAM_ID          10-character Apple Developer Team ID
#   ASC_KEY_ID             App Store Connect API key ID (10 characters)
#   ASC_ISSUER_ID          App Store Connect API issuer ID (UUID)
#   ASC_API_PRIVATE_KEY    contents of the AuthKey_<KEY_ID>.p8 file (or base64 of it)
#   manual mode only:
#   IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64, IOS_DISTRIBUTION_CERTIFICATE_PASSWORD,
#   IOS_APPSTORE_PROFILE_BASE64
#
# Exit status: 0 when everything needed is present and well-formed, 1 otherwise.

set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

MODE="${KICKLAB_SIGNING_MODE:-automatic}"
problems=0

ok() { printf '  ✓ %s\n' "$1"; }
bad() { printf '  ✗ %s — %s\n' "$1" "$2"; problems=$((problems + 1)); }

# check NAME KIND HOW-TO-FIX [regex]
check() {
    local name="$1" kind="$2" fix="$3" pattern="${4:-}"
    local value="${!name:-}"
    if [[ -z "$value" ]]; then
        bad "$name" "missing. Add it as a repository $kind ($fix)."
        return
    fi
    if [[ -n "$pattern" ]] && ! [[ "$value" =~ $pattern ]]; then
        bad "$name" "is set but doesn't look right. $fix"
        return
    fi
    ok "$name"
}

check_base64() {
    local name="$1" fix="$2"
    local value="${!name:-}"
    if [[ -z "$value" ]]; then
        bad "$name" "missing. Add it as a repository secret ($fix)."
    elif ! printf '%s' "$value" | b64decode > /dev/null 2>&1; then
        bad "$name" "is set but isn't valid base64. $fix"
    else
        ok "$name"
    fi
}

check_private_key() {
    local value="${ASC_API_PRIVATE_KEY:-}"
    if [[ -z "$value" ]]; then
        bad ASC_API_PRIVATE_KEY "missing. Add it as a repository secret (paste the whole AuthKey_<KEY_ID>.p8 file)."
    elif [[ "$value" == *"BEGIN PRIVATE KEY"* ]] || printf '%s' "$value" | b64decode 2> /dev/null | grep -q "BEGIN PRIVATE KEY"; then
        ok ASC_API_PRIVATE_KEY
    else
        bad ASC_API_PRIVATE_KEY "is set but isn't a .p8 private key. Paste the whole file, including the BEGIN and END lines."
    fi
}

section "TestFlight configuration (signing mode: $MODE)"
case "$MODE" in
    automatic|manual) ;;
    *) bad KICKLAB_SIGNING_MODE "must be 'automatic' or 'manual'." ;;
esac

check APPLE_TEAM_ID variable "Apple Developer → Membership details → Team ID: 10 letters and digits" '^[A-Z0-9]{10}$'
check ASC_KEY_ID variable "App Store Connect → Users and Access → Integrations → Team Keys → Key ID" '^[A-Z0-9]{8,12}$'
check ASC_ISSUER_ID variable "App Store Connect → Users and Access → Integrations → Issuer ID" '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
check_private_key

if [[ "$MODE" == "manual" ]]; then
    check_base64 IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64 "base64 of the Apple Distribution .p12 file"
    check IOS_DISTRIBUTION_CERTIFICATE_PASSWORD secret "the password chosen when the .p12 was exported"
    check_base64 IOS_APPSTORE_PROFILE_BASE64 "base64 of the App Store .mobileprovision file"
fi

if [[ -n "${KICKLAB_BUILD_NUMBER_OFFSET:-}" ]] && ! [[ "$KICKLAB_BUILD_NUMBER_OFFSET" =~ ^[0-9]+$ ]]; then
    bad KICKLAB_BUILD_NUMBER_OFFSET "must be a whole number."
fi

if (( problems > 0 )); then
    printf '\n%d setting(s) need attention. Nothing was built or uploaded.\n' "$problems"
    echo "Settings live in GitHub → the repository → Settings → Secrets and variables → Actions."
    exit 1
fi
echo "All required settings are present."
