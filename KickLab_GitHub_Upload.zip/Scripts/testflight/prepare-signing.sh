#!/usr/bin/env bash
#
# Puts the signing material in place for this run only, under $KICKLAB_SIGNING_DIR:
#   - the App Store Connect API key (both modes): private_keys/AuthKey_<ID>.p8
#   - manual mode: a temporary keychain with the Apple Distribution certificate, and the
#     App Store provisioning profile (checked against the team and bundle identifier).
# Never prints credential values. cleanup-signing.sh removes everything afterwards.
#
# Exports: KICKLAB_API_KEY_PATH, and in manual mode KICKLAB_PROFILE_UUID, KICKLAB_PROFILE_NAME

set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$HERE/common.sh"

MODE="${KICKLAB_SIGNING_MODE:-automatic}"
umask 077
mkdir -p "$KICKLAB_SIGNING_DIR/private_keys"

section "App Store Connect API key"
key_path="$(python3 "$HERE/write-api-key.py" "$KICKLAB_SIGNING_DIR/private_keys")"
if command -v openssl > /dev/null 2>&1 && ! openssl pkey -in "$key_path" -noout > /dev/null 2>&1; then
    fail "ASC_API_PRIVATE_KEY could not be read as a private key. Paste the whole .p8 file again."
fi
export_env KICKLAB_API_KEY_PATH "$key_path"
note "API key installed for this run."

[[ "$MODE" == "manual" ]] || { note "Automatic signing: Xcode will use cloud-managed signing during export."; exit 0; }

[[ "$(uname -s)" == "Darwin" ]] || fail "manual signing needs macOS."
: "${APPLE_TEAM_ID:?}" "${KICKLAB_BUNDLE_ID:?}"

section "Temporary keychain"
keychain_password="$(openssl rand -base64 24)"
security create-keychain -p "$keychain_password" "$KICKLAB_KEYCHAIN"
security set-keychain-settings -lut 3600 "$KICKLAB_KEYCHAIN"
security unlock-keychain -p "$keychain_password" "$KICKLAB_KEYCHAIN"
p12="$KICKLAB_SIGNING_DIR/distribution.p12"
printf '%s' "$IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64" | b64decode > "$p12"
security import "$p12" -k "$KICKLAB_KEYCHAIN" -P "$IOS_DISTRIBUTION_CERTIFICATE_PASSWORD" \
    -T /usr/bin/codesign -T /usr/bin/security -T /usr/bin/productbuild > /dev/null \
    || fail "the .p12 couldn't be imported. Check IOS_DISTRIBUTION_CERTIFICATE_P12_BASE64 and its password."
rm -f "$p12"
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "$keychain_password" "$KICKLAB_KEYCHAIN" > /dev/null
# Search the temporary keychain first, keeping the existing ones.
existing="$(security list-keychains -d user | sed -e 's/^ *"//' -e 's/"$//')"
# shellcheck disable=SC2086  # one keychain path per word
security list-keychains -d user -s "$KICKLAB_KEYCHAIN" $existing
identities="$(security find-identity -v -p codesigning "$KICKLAB_KEYCHAIN")"
grep -q "Apple Distribution" <<< "$identities" || fail "the .p12 doesn't contain an Apple Distribution certificate with its private key."
grep -q "($APPLE_TEAM_ID)" <<< "$identities" || fail "the Apple Distribution certificate isn't for team APPLE_TEAM_ID."
note "Apple Distribution certificate imported."

section "App Store provisioning profile"
profile="$KICKLAB_SIGNING_DIR/profile.mobileprovision"
printf '%s' "$IOS_APPSTORE_PROFILE_BASE64" | b64decode > "$profile"
plist="$KICKLAB_SIGNING_DIR/profile.plist"
security cms -D -i "$profile" > "$plist" 2> /dev/null || fail "IOS_APPSTORE_PROFILE_BASE64 isn't a provisioning profile."
pb() { /usr/libexec/PlistBuddy -c "Print :$1" "$plist" 2> /dev/null || true; }
uuid="$(pb UUID)"
name="$(pb Name)"
team="$(pb 'TeamIdentifier:0')"
app_id="$(pb 'Entitlements:application-identifier')"
devices="$(pb ProvisionedDevices)"
[[ "$team" == "$APPLE_TEAM_ID" ]] || fail "the provisioning profile belongs to a different team than APPLE_TEAM_ID."
[[ "$app_id" == "$APPLE_TEAM_ID.$KICKLAB_BUNDLE_ID" ]] || fail "the provisioning profile is for '$app_id', not '$APPLE_TEAM_ID.$KICKLAB_BUNDLE_ID'."
[[ -z "$devices" ]] || fail "the provisioning profile lists devices, so it is Ad Hoc or Development. Create an 'App Store Connect' profile."
dest="$HOME/Library/MobileDevice/Provisioning Profiles"
mkdir -p "$dest"
cp "$profile" "$dest/$uuid.mobileprovision"
# Xcode 16+ also reads profiles from here.
mkdir -p "$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"
cp "$profile" "$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles/$uuid.mobileprovision"
printf '%s\n' "$uuid" > "$KICKLAB_SIGNING_DIR/installed-profile-uuid"
rm -f "$profile" "$plist"
export_env KICKLAB_PROFILE_UUID "$uuid"
export_env KICKLAB_PROFILE_NAME "$name"
note "Profile '$name' installed."
