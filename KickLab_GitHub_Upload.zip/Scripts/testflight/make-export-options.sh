#!/usr/bin/env bash
#
# Writes the ExportOptions.plist used by `xcodebuild -exportArchive`.
#
# Usage: make-export-options.sh <output.plist>
# Reads: KICKLAB_SIGNING_MODE (automatic|manual), APPLE_TEAM_ID, KICKLAB_BUNDLE_ID,
#        and in manual mode KICKLAB_PROFILE_UUID (set by prepare-signing.sh).

set -euo pipefail

out="${1:?usage: make-export-options.sh <output.plist>}"
mode="${KICKLAB_SIGNING_MODE:-automatic}"
team="${APPLE_TEAM_ID:?APPLE_TEAM_ID is required}"
bundle="${KICKLAB_BUNDLE_ID:?KICKLAB_BUNDLE_ID is required}"

signing=""
case "$mode" in
    automatic)
        signing="	<key>signingStyle</key>
	<string>automatic</string>"
        ;;
    manual)
        profile="${KICKLAB_PROFILE_UUID:?KICKLAB_PROFILE_UUID is required in manual mode}"
        signing="	<key>signingStyle</key>
	<string>manual</string>
	<key>signingCertificate</key>
	<string>Apple Distribution</string>
	<key>provisioningProfiles</key>
	<dict>
		<key>${bundle}</key>
		<string>${profile}</string>
	</dict>"
        ;;
    *) echo "error: KICKLAB_SIGNING_MODE must be automatic or manual." >&2; exit 1 ;;
esac

mkdir -p "$(dirname "$out")"
cat > "$out" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>method</key>
	<string>app-store-connect</string>
	<key>destination</key>
	<string>export</string>
	<key>teamID</key>
	<string>${team}</string>
${signing}
	<key>uploadSymbols</key>
	<true/>
	<key>manageAppVersionAndBuildNumber</key>
	<false/>
</dict>
</plist>
PLIST
echo "Wrote $out ($mode signing)"
