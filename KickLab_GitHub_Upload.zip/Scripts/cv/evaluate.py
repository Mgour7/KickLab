#!/usr/bin/env python3
"""KickLab Step 12G evaluation: compares KickLab results with human annotations.

  python3 evaluate.py Datasets/annotations results.json [--detections dets.json] [--split heldOut]

results.json: {"<clip>": {"lastStationary": s|null, "firstMovement": s|null, "contact": s|null,
               "contactOutcome": "...", "runtimeSeconds": s|null}, ...}
  (copy the times from each clip's Diagnostics export: football / contact lines)
dets.json (optional): {"<clip>": [{"t": s, "x": px, "y": px, "width": px, "height": px, "score": p}, ...]}
  (detector boxes in displayed pixels, e.g. from run_detector.py)

Reports, per split and perspective: timing errors (ms and frames) for first ball movement
and first contact, abstention rate (no answer), detection precision/recall at IoU 0.5 where
people drew ball boxes, tracking retention, and runtime. It REFUSES to print accuracy for a
split with no clips, and labels development-split numbers as not validation.
"""
import json, os, statistics, sys

def load_annotations(folder):
    out = {}
    for name in sorted(os.listdir(folder)):
        if name.endswith(".json"):
            a = json.load(open(os.path.join(folder, name)))
            out[a["clip"]] = a
    return out

def ref_time(event):
    if not event or event.get("cannotTell"):
        return None
    if "time" in event:
        return event["time"]
    if "earliest" in event and "latest" in event:
        return (event["earliest"], event["latest"])
    return None

def error(estimate, ref):
    """Signed error in seconds; zero when inside an annotated range."""
    if estimate is None or ref is None:
        return None
    if isinstance(ref, tuple):
        lo, hi = ref
        return 0.0 if lo - 1e-3 <= estimate <= hi + 1e-3 else (estimate - lo if estimate < lo else estimate - hi)
    return estimate - ref

def iou(a, b):
    ix = max(0, min(a["x"] + a["width"], b["x"] + b["width"]) - max(a["x"], b["x"]))
    iy = max(0, min(a["y"] + a["height"], b["y"] + b["height"]) - max(a["y"], b["y"]))
    u = a["width"] * a["height"] + b["width"] * b["height"] - ix * iy
    return ix * iy / u if u > 0 else 0

def summarize(errors, fps):
    vals = [e for e in errors if e is not None]
    if not vals:
        return "no answers to compare"
    ms = [abs(v) * 1000 for v in vals]
    within1 = sum(1 for v in vals if abs(v) * fps <= 1.0001) / len(vals)
    return (f"n={len(vals)} median |error| {statistics.median(ms):.0f} ms, max {max(ms):.0f} ms, "
            f"within one frame {within1:.0%}")

def main():
    args = sys.argv[1:]
    ann_dir, results_path = args[0], args[1]
    dets = json.load(open(args[args.index("--detections") + 1])) if "--detections" in args else {}
    split = args[args.index("--split") + 1] if "--split" in args else None
    anns = load_annotations(ann_dir)
    results = json.load(open(results_path))
    groups = {}
    for clip, a in anns.items():
        if split and a["split"] != split:
            continue
        groups.setdefault((a["split"], a["perspective"]), []).append(clip)
    if not groups:
        print(f"No clips in split {split!r}: no accuracy is reported.")
        return
    for (sp, persp), clips in sorted(groups.items()):
        label = "DEVELOPMENT (not validation)" if sp == "development" else "HELD-OUT"
        print(f"== {label} · {persp} · {len(clips)} clip(s)")
        move_err, contact_err, abstain, runtimes = [], [], 0, []
        tp = fp = fn = 0; retained = total_boxes = 0
        for clip in clips:
            a, r = anns[clip], results.get(clip, {})
            fps = a["frameRate"]
            move_err.append(error(r.get("firstMovement"), ref_time(a["events"].get("firstBallMovement"))))
            contact_err.append(error(r.get("contact"), ref_time(a["events"].get("firstContact"))))
            if r.get("contact") is None:
                abstain += 1
            if r.get("runtimeSeconds") is not None:
                runtimes.append(r["runtimeSeconds"])
            boxes = [b for b in a.get("ballBoxes", []) if b["state"] != "outOfFrame"]
            clip_dets = dets.get(clip, [])
            for b in boxes:
                frame = [d for d in clip_dets if abs(d["t"] - b["time"]) < 0.5 / fps]
                total_boxes += 1
                if any(iou(b, d) >= 0.5 for d in frame):
                    tp += 1; retained += 1
                else:
                    fn += 1
            annotated_times = {round(b["time"], 3) for b in a.get("ballBoxes", [])}
            for d in clip_dets:
                if round(d["t"], 3) in annotated_times and not any(iou(b, d) >= 0.5 for b in boxes if abs(b["time"] - d["t"]) < 0.5 / fps):
                    fp += 1
        fps = anns[clips[0]]["frameRate"]
        print("  first ball movement:", summarize(move_err, fps))
        print("  first contact:      ", summarize(contact_err, fps))
        print(f"  abstained (no contact answer): {abstain}/{len(clips)}")
        if total_boxes:
            prec = tp / (tp + fp) if tp + fp else 0
            print(f"  ball boxes @IoU0.5: precision {prec:.2f}, recall {tp / total_boxes:.2f}, tracking retention {retained / total_boxes:.2f}")
        else:
            print("  ball boxes: none drawn by a person — detection precision/recall not computed")
        if runtimes:
            print(f"  on-device football pass: median {statistics.median(runtimes):.1f} s")
        if sp == "development":
            print("  (development data: these numbers describe the clips the method was built on)")

if __name__ == "__main__":
    main()
