#!/usr/bin/env python3
"""Reproducible conversion of the official YOLOX ONNX release to a Core ML ML Program.

KickLab Step 12G. Source model: Megvii YOLOX (Apache-2.0),
https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/<name>.onnx
(trained on COCO 2017; class 32 = "sports ball").

coremltools no longer converts ONNX directly, so this script maps the small set of ONNX
operators YOLOX uses (Conv, Sigmoid, Mul, Add, Concat, Slice, MaxPool, Resize[nearest],
Reshape, Transpose) onto Core ML MIL operations one-to-one, using the ONNX weights
unchanged. It runs on Linux (coremltools builds and saves the model; Core ML itself only
runs on Apple platforms, which is why the app's CI test checks the converted model's
detections against onnxruntime's on a real frame).

Usage:
  python3 convert_yolox_to_coreml.py yolox_s.onnx KickLab/Resources/Models/YOLOXSportsBall.mlpackage
Requires: pip install coremltools onnx numpy
"""
import sys
import numpy as np
import onnx
from onnx import numpy_helper
import coremltools as ct
from coremltools.converters.mil import Builder as mb


def convert(onnx_path, out_path):
    model = onnx.load(onnx_path)
    g = model.graph
    inits = {i.name: numpy_helper.to_array(i) for i in g.initializer}
    for n in g.node:  # Constant nodes become initializers too
        if n.op_type == "Constant":
            inits[n.output[0]] = numpy_helper.to_array(n.attribute[0].t)
    inp = g.input[0]
    shape = [d.dim_value for d in inp.type.tensor_type.shape.dim]
    # Static shapes for slices: run ONNX shape inference.
    inferred = onnx.shape_inference.infer_shapes(model)
    shapes = {inp.name: shape}
    for vi in list(inferred.graph.value_info) + list(inferred.graph.output):
        shapes[vi.name] = [d.dim_value for d in vi.type.tensor_type.shape.dim]

    def attrs(node):
        return {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}

    @mb.program(input_specs=[mb.TensorSpec(shape=tuple(shape))], opset_version=ct.target.iOS16)
    def prog(images):
        env = {inp.name: images}

        def val(name):
            if name in env:
                return env[name]
            return inits[name]

        for node in g.node:
            op, a, ins, out = node.op_type, attrs(node), list(node.input), node.output[0]
            if op == "Constant":
                continue
            if op == "Conv":
                w = inits[ins[1]].astype(np.float32)
                b = inits[ins[2]].astype(np.float32) if len(ins) > 2 else None
                p = a.get("pads", [0, 0, 0, 0])
                # ONNX pads: [h_begin, w_begin, h_end, w_end]; MIL: [h_begin, h_end, w_begin, w_end]
                x = mb.conv(x=val(ins[0]), weight=w, bias=b, strides=a.get("strides", [1, 1]),
                            pad_type="custom", pad=[p[0], p[2], p[1], p[3]],
                            dilations=a.get("dilations", [1, 1]), groups=a.get("group", 1), name=out)
            elif op == "Sigmoid":
                x = mb.sigmoid(x=val(ins[0]), name=out)
            elif op == "Mul":
                x = mb.mul(x=val(ins[0]), y=val(ins[1]), name=out)
            elif op == "Add":
                x = mb.add(x=val(ins[0]), y=val(ins[1]), name=out)
            elif op == "Concat":
                x = mb.concat(values=[val(i) for i in ins], axis=a["axis"], name=out)
            elif op == "Slice":
                data = val(ins[0])
                rank = len(shapes[ins[0]])
                dims = shapes[ins[0]]
                starts, ends = inits[ins[1]].tolist(), inits[ins[2]].tolist()
                axes = inits[ins[3]].tolist() if len(ins) > 3 else list(range(len(starts)))
                steps = inits[ins[4]].tolist() if len(ins) > 4 else [1] * len(starts)
                begin, end, stride = [0] * rank, list(dims), [1] * rank
                for s, e, ax, st in zip(starts, ends, axes, steps):
                    ax = ax % rank
                    begin[ax] = s
                    end[ax] = min(e, dims[ax])
                    stride[ax] = st
                x = mb.slice_by_index(x=data, begin=begin, end=end, stride=stride, name=out)
            elif op == "MaxPool":
                p = a.get("pads", [0, 0, 0, 0])
                x = mb.max_pool(x=val(ins[0]), kernel_sizes=a["kernel_shape"], strides=a.get("strides", [1, 1]),
                                pad_type="custom", pad=[p[0], p[2], p[1], p[3]], name=out)
            elif op == "Resize":
                scales = inits[ins[2]].tolist()
                assert a.get("mode", b"nearest") in (b"nearest", "nearest")
                x = mb.upsample_nearest_neighbor(x=val(ins[0]), scale_factor_height=float(scales[2]),
                                                 scale_factor_width=float(scales[3]), name=out)
            elif op == "Reshape":
                x = mb.reshape(x=val(ins[0]), shape=[int(v) for v in inits[ins[1]].tolist()], name=out)
            elif op == "Transpose":
                x = mb.transpose(x=val(ins[0]), perm=a["perm"], name=out)
            else:
                raise NotImplementedError(op)
            env[out] = x
        return env[g.output[0].name]

    mlmodel = ct.convert(prog, convert_to="mlprogram", minimum_deployment_target=ct.target.iOS16,
                         compute_precision=ct.precision.FLOAT16)
    spec_names = mlmodel.get_spec()
    mlmodel.short_description = ("YOLOX-S (Megvii, Apache-2.0) COCO detector converted by KickLab Step 12G. "
                                 "Input: 1x3x640x640 BGR 0-255, letterboxed with 114 padding. Output: 1x8400x85 "
                                 "raw (box offsets, objectness, 80 class scores); KickLab decodes class 32 'sports ball'.")
    mlmodel.author = "Megvii (YOLOX). Conversion: KickLab."
    mlmodel.license = "Apache-2.0 (YOLOX). Trained on COCO 2017 - see Models/README.md."
    mlmodel.version = "yolox_s-0.1.1rc0"
    mlmodel.save(out_path)
    names_in = [i.name for i in mlmodel.get_spec().description.input]
    names_out = [o.name for o in mlmodel.get_spec().description.output]
    print("saved", out_path, "inputs", names_in, "outputs", names_out)


if __name__ == "__main__":
    convert(sys.argv[1], sys.argv[2])
