#!/usr/bin/env python3
"""Builds KickLab's Step 12G football-detector test fixtures from the REAL IMG_1709 frames.

IMG_1709.mov is the user's own video and is not in the repository. To regenerate:
  ffmpeg -i IMG_1709.mov -vsync 0 frames/%04d.jpg      (upright 1080x1920 frames)
  ffprobe -select_streams v -show_entries packet=pts_time -of csv=p=0 IMG_1709.mov | sort -n > vpts.txt
  python3 make_1709_fixtures.py frames vpts.txt yolox_s.onnx out/
Outputs: RealVideo1709Football.swift (detections, raw head rows, thumbnails), two JPEG crops
for the Apple-runtime Core ML test, and the expected onnxruntime detections on those crops.
Every number comes from onnxruntime running the official YOLOX-S ONNX on the real frames.
"""
import base64, json, os, sys
import cv2, numpy as np, onnxruntime as ort

frames_dir, vpts_path, onnx_path, out = sys.argv[1:5]
os.makedirs(out, exist_ok=True)
sess = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
vpts = [float(x) for x in open(vpts_path).read().split()]
W, H, N = 1080, 1920, 640

def letterbox_like_app(img, region):
    """Exactly DetectorInputBuilder.makeInput for an upright image: bilinear at pixel centers."""
    x0, y0, rw, rh = region
    s = min(N / rw, N / rh)
    uw, uh = min(N, int(rw * s)), min(N, int(rh * s))
    out = np.full((3, N, N), 114, np.float32)
    mx = np.arange(uw); my = np.arange(uh)
    fx = x0 + (mx + 0.5) / s - 0.5; fy = y0 + (my + 0.5) / s - 0.5
    fx = np.clip(fx, 0, img.shape[1] - 1); fy = np.clip(fy, 0, img.shape[0] - 1)
    x0i = np.floor(fx).astype(int); y0i = np.floor(fy).astype(int)
    x1i = np.minimum(x0i + 1, img.shape[1] - 1); y1i = np.minimum(y0i + 1, img.shape[0] - 1)
    ax = (fx - x0i)[None, :, None]; ay = (fy - y0i)[:, None, None]
    im = img.astype(np.float32)
    p00 = im[y0i][:, x0i]; p10 = im[y0i][:, x1i]; p01 = im[y1i][:, x0i]; p11 = im[y1i][:, x1i]
    v = (p00 * (1 - ax) + p10 * ax) * (1 - ay) + (p01 * (1 - ax) + p11 * ax) * ay
    out[:, :uh, :uw] = v.transpose(2, 0, 1)
    return out[None], s

def grids():
    g = []
    for st in (8, 16, 32):
        n = N // st
        for gy in range(n):
            for gx in range(n):
                g.append((gx, gy, st))
    return np.array(g, np.float32)
G = grids()

def run(img, region, cls=32, thr=0.05):
    x, s = letterbox_like_app(img, region)
    o = sess.run(None, {"images": x})[0][0]
    score = o[:, 4] * o[:, 5 + cls]
    keep = np.where(score >= thr)[0]
    boxes = []
    for a in keep:
        gx, gy, st = G[a]
        boxes.append(((o[a, 0] + gx) * st, (o[a, 1] + gy) * st, np.exp(o[a, 2]) * st, np.exp(o[a, 3]) * st, float(score[a])))
    boxes.sort(key=lambda b: -b[4]); kept = []
    for b in boxes:
        def iou(p, q):
            ix = max(0, min(p[0]+p[2]/2, q[0]+q[2]/2) - max(p[0]-p[2]/2, q[0]-q[2]/2)); iy = max(0, min(p[1]+p[3]/2, q[1]+q[3]/2) - max(p[1]-p[3]/2, q[1]-q[3]/2))
            u = p[2]*p[3] + q[2]*q[3] - ix*iy; return ix*iy/u if u > 0 else 0
        if all(iou(k, b) <= 0.45 for k in kept): kept.append(b)
        if len(kept) == 20: break
    x0, y0, rw, rh = region
    dets = []
    for cx, cy, w, h, sc in kept:
        dx, dy = x0 + cx / s, y0 + cy / s
        if x0 <= dx <= x0 + rw and y0 <= dy <= y0 + rh:
            dets.append(dict(cx=float(round(dx / W, 5)), cy=float(round(dy / H, 5)), w=float(round(w / s / W, 5)), h=float(round(h / s / H, 5)), s=round(sc, 4)))
    raw = [[int(a)] + [float(round(v, 5)) for v in (o[a, 0], o[a, 1], o[a, 2], o[a, 3], o[a, 4], o[a, 5 + cls])]
           for a in np.where(score >= 0.01)[0]]
    return dets, raw

def frame(n): return cv2.imread(f"{frames_dir}/{n:04d}.jpg")

# Stage 1: the app's broad scan (one frame every 0.2 s, whole frame).
scan, nxt = [], 0.0
for n, t in enumerate(vpts, 1):
    if t + 1e-6 >= nxt:
        nxt = t + 0.2
        d, _ = run(frame(n), (0, 0, W, H))
        scan.append(dict(t=t, d=d))
# Stage 2: every frame 7.2-8.75 s, crop of 14 ball sizes / 0.3 of the long side around the resting ball.
site = (614, 1118); side = max(14 * 49, 0.3 * H)
cx0 = min(max(0, site[0] - side / 2), W - side); cy0 = min(max(0, site[1] - side / 2), H - side)
crop = (cx0, cy0, side, side)
prec = []
for n, t in enumerate(vpts, 1):
    if 7.2 <= t <= 8.75:
        d, _ = run(frame(n), crop)
        prec.append(dict(t=t, d=d))
# Raw head rows for the decoder test (frame 240 = 7.968 s, crop).
dets240, raw240 = run(frame(240), crop)
# Whole-frame thumbnails (90x160 gray) for the camera-motion test.
thumbs = [cv2.resize(cv2.cvtColor(frame(n), cv2.COLOR_BGR2GRAY), (90, 160), interpolation=cv2.INTER_AREA) for n in range(232, 242)]
# Apple-runtime fixtures: the crop as JPEG, expected detections on the DECODED JPEG.
apple = {}
# Small crops centered on the ball only (feet and ball, no upper body), 384 x 384.
for n, (bx, by) in ((236, (614, 1118)), (240, (625, 1045))):
    c = frame(n)[by - 192:by + 192, bx - 192:bx + 192]
    path = f"{out}/IMG_1709_f{n:04d}_ballcrop.jpg"
    cv2.imwrite(path, c, [cv2.IMWRITE_JPEG_QUALITY, 80])
    dec = cv2.imread(path)
    d, _ = run(dec, (0, 0, dec.shape[1], dec.shape[0]))
    # Express relative to the crop image itself.
    apple[n] = [dict(cx=round(x["cx"] * W / dec.shape[1], 5), cy=round(x["cy"] * H / dec.shape[0], 5),
                     w=round(x["w"] * W / dec.shape[1], 5), h=round(x["h"] * H / dec.shape[0], 5), s=x["s"]) for x in d]
json.dump(dict(scan=scan, precision=prec, crop=crop, dets240=dets240, raw240=raw240, apple=apple,
               thumbs=[base64.b64encode(t.tobytes()).decode() for t in thumbs], thumbTimes=[vpts[n - 1] for n in range(232, 242)]),
          open(f"{out}/fixtures.json", "w"), default=float)
print("scan", len(scan), "precision", len(prec), "raw rows", len(raw240), "apple", {k: v[:2] for k, v in apple.items()})
