#!/usr/bin/env python3
"""Runs the reference YOLOX-S ONNX model over extracted frames of one clip (for evaluate.py).

  ffmpeg -i clip.mov -vsync 0 frames/%04d.jpg
  ffprobe -select_streams v -show_entries packet=pts_time -of csv=p=0 clip.mov | sort -n > pts.txt
  python3 run_detector.py frames pts.txt yolox_s.onnx "clip.mov" dets.json [--every 1]

Writes {"clip.mov": [{"t", "x", "y", "width", "height", "score"}, ...]} in displayed pixels,
using the same letterbox, decoding and suppression as the app (make_1709_fixtures.py).
This is the reference model in onnxruntime, not the app's Core ML run.
"""
import json, os, sys
sys.argv, extra = sys.argv[:6], sys.argv[6:]
frames_dir, pts_path, onnx_path, clip, out_path = sys.argv[1:6]
every = int(extra[extra.index("--every") + 1]) if "--every" in extra else 1
here = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(here, "make_1709_fixtures.py")).read()
ns = {"__name__": "lib"}
sys.argv = ["lib", frames_dir, pts_path, onnx_path, "/tmp"]
exec(src[: src.index("# Stage 1")], ns)
import cv2
pts = [float(x) for x in open(pts_path).read().split()]
dets = []
for n, t in enumerate(pts, 1):
    if (n - 1) % every:
        continue
    img = cv2.imread(f"{frames_dir}/{n:04d}.jpg")
    h, w = img.shape[:2]
    ns["W"], ns["H"] = w, h
    found, _ = ns["run"](img, (0, 0, w, h))
    for d in found:
        dets.append(dict(t=t, x=(d["cx"] - d["w"] / 2) * w, y=(d["cy"] - d["h"] / 2) * h, width=d["w"] * w, height=d["h"] * h, score=d["s"]))
json.dump({clip: dets}, open(out_path, "w"), default=float)
print(len(dets), "detections")
