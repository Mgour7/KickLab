#!/usr/bin/env bash
#
# Generates KickLab.xcodeproj with XcodeGen, builds the app for an iPhone
# Simulator against Apple's real SDKs, and runs every KickLab test (including the
# SwiftData tests). Used by GitHub Actions and runnable on any Mac with Xcode.
#
# Usage:   bash Scripts/test-ios.sh
#
# Optional environment variables:
#   SIMULATOR_UDID   use this simulator instead of choosing one automatically
#   MIN_IOS          minimum simulator iOS version to accept (default 18.0)
#   BUILD_DIR        output folder (default ./build)
#
# Outputs (in BUILD_DIR):
#   logs/build.log, logs/test.log   full xcodebuild output
#   logs/warnings.txt               unique compiler warnings
#   logs/summary.md                 short result summary
#   KickLab.xcresult                Xcode result bundle (open in Xcode for details)

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PROJECT="KickLab.xcodeproj"
SCHEME="KickLab"
MIN_IOS="${MIN_IOS:-18.0}"
BUILD_DIR="${BUILD_DIR:-$ROOT/build}"
LOG_DIR="$BUILD_DIR/logs"
DERIVED_DATA="$BUILD_DIR/DerivedData"
RESULT_BUNDLE="$BUILD_DIR/KickLab.xcresult"
SUMMARY="$LOG_DIR/summary.md"

section() { printf '\n==> %s\n' "$*"; }
fail() { printf '\nerror: %s\n' "$*" >&2; exit 1; }

# Print the last lines of a log and the error lines in it.
show_failure() {
    local log="$1"
    echo "---- errors in $(basename "$log") ----"
    grep -E "(error:|\*\* BUILD FAILED|\*\* TEST FAILED|✘|Fatal error)" "$log" | sort -u | head -n 100 || true
    echo "---- last 80 lines of $(basename "$log") ----"
    tail -n 80 "$log" || true
}

[[ "$(uname -s)" == "Darwin" ]] || fail "this script needs macOS with Xcode (use GitHub Actions if you have no Mac)."

mkdir -p "$LOG_DIR"
rm -rf "$RESULT_BUNDLE"
: > "$SUMMARY"

# ---------------------------------------------------------------------------
section "Environment"
sw_vers
echo "Xcode path: $(xcode-select -p)"
xcodebuild -version
swift --version 2>&1 | head -n 2

# ---------------------------------------------------------------------------
section "Generate $PROJECT with XcodeGen"
if ! command -v xcodegen >/dev/null 2>&1; then
    command -v brew >/dev/null 2>&1 || fail "XcodeGen is missing and Homebrew is not installed."
    echo "Installing XcodeGen with Homebrew..."
    brew install xcodegen
fi
echo "XcodeGen $(xcodegen --version)"
xcodegen generate --spec project.yml --project "$ROOT"

# ---------------------------------------------------------------------------
section "Choose an iPhone Simulator (iOS >= $MIN_IOS)"
echo "Available iOS runtimes:"
xcrun simctl list runtimes available | grep -i "iOS" || true

# Prints "<udid>\t<ios version>\t<device name>" for the iPhone on the newest
# available iOS runtime that is >= MIN_IOS. Prints nothing if none qualifies.
pick_existing_simulator() {
    xcrun simctl list devices available --json | python3 -c '
import json, re, sys
minimum = tuple(int(p) for p in (sys.argv[1].split(".") + ["0", "0"])[:3])
best = None
for runtime, devices in json.load(sys.stdin)["devices"].items():
    m = re.search(r"iOS-(\d+)-(\d+)(?:-(\d+))?$", runtime)
    if not m:
        continue
    version = tuple(int(g or 0) for g in m.groups())
    if version < minimum:
        continue
    for d in devices:
        if d.get("isAvailable", True) and d["name"].startswith("iPhone"):
            key = (version, d["name"])
            if best is None or key > best[0]:
                best = (key, d)
if best:
    (version, name), device = best
    print(device["udid"], ".".join(map(str, version)), name, sep="\t")
' "$MIN_IOS"
}

# Creates an iPhone on the newest qualifying runtime; prints the same format.
create_simulator() {
    local choice
    choice="$(xcrun simctl list --json | python3 -c '
import json, sys
minimum = tuple(int(p) for p in (sys.argv[1].split(".") + ["0", "0"])[:3])
data = json.load(sys.stdin)
def ver(s): return tuple(int(p) for p in (s.split(".") + ["0", "0"])[:3])
runtimes = [r for r in data["runtimes"]
            if r.get("isAvailable") and r.get("platform", r["name"]).startswith("iOS") and ver(r["version"]) >= minimum]
if not runtimes:
    sys.exit(0)
runtime = max(runtimes, key=lambda r: ver(r["version"]))
supported = {t["identifier"] for t in runtime.get("supportedDeviceTypes", [])}
iphones = [t for t in data["devicetypes"] if t["name"].startswith("iPhone") and (not supported or t["identifier"] in supported)]
if not iphones:
    sys.exit(0)
device = iphones[-1]
print(device["identifier"], runtime["identifier"], runtime["version"], device["name"], sep="\t")
' "$MIN_IOS")"
    [[ -n "$choice" ]] || return 0
    local type_id runtime_id version name udid
    IFS=$'\t' read -r type_id runtime_id version name <<< "$choice"
    udid="$(xcrun simctl create "KickLab CI ($name)" "$type_id" "$runtime_id")"
    printf '%s\t%s\t%s\n' "$udid" "$version" "$name"
}

if [[ -n "${SIMULATOR_UDID:-}" ]]; then
    UDID="$SIMULATOR_UDID"
    SIM_DESC="(from SIMULATOR_UDID)"
else
    SELECTION="$(pick_existing_simulator)"
    if [[ -z "$SELECTION" ]]; then
        echo "No existing iPhone Simulator on iOS >= $MIN_IOS; trying to create one."
        SELECTION="$(create_simulator)"
    fi
    [[ -n "$SELECTION" ]] || fail "no iPhone Simulator runtime >= iOS $MIN_IOS is installed in this Xcode."
    IFS=$'\t' read -r UDID SIM_VERSION SIM_NAME <<< "$SELECTION"
    SIM_DESC="$SIM_NAME, iOS $SIM_VERSION"
fi
echo "Using simulator: $UDID ($SIM_DESC)"
DESTINATION="platform=iOS Simulator,id=$UDID"

section "Boot simulator"
xcrun simctl bootstatus "$UDID" -b

COMMON_ARGS=(
    -project "$PROJECT"
    -scheme "$SCHEME"
    -destination "$DESTINATION"
    -derivedDataPath "$DERIVED_DATA"
    CODE_SIGNING_ALLOWED=NO
    CODE_SIGNING_REQUIRED=NO
)

# ---------------------------------------------------------------------------
section "Build app and tests (full log: $LOG_DIR/build.log)"
BUILD_STATUS=0
xcodebuild build-for-testing "${COMMON_ARGS[@]}" > "$LOG_DIR/build.log" 2>&1 || BUILD_STATUS=$?

grep -E ": warning: " "$LOG_DIR/build.log" | sed -E "s|$ROOT/||" | sort -u > "$LOG_DIR/warnings.txt" || true
WARNING_COUNT="$(wc -l < "$LOG_DIR/warnings.txt" | tr -d ' ')"
echo "Compiler warnings: $WARNING_COUNT"
head -n 100 "$LOG_DIR/warnings.txt" || true

{
    echo "## KickLab iOS build and tests"
    echo ""
    echo "- Xcode: $(xcodebuild -version | head -n 1)"
    echo "- Simulator: $SIM_DESC"
    echo "- Compiler warnings: $WARNING_COUNT"
} >> "$SUMMARY"

if [[ $BUILD_STATUS -ne 0 ]]; then
    show_failure "$LOG_DIR/build.log"
    echo "- Build: **FAILED** (exit $BUILD_STATUS)" >> "$SUMMARY"
    fail "build failed (exit $BUILD_STATUS). See $LOG_DIR/build.log"
fi
echo "- Build: succeeded" >> "$SUMMARY"
echo "Build succeeded."

# ---------------------------------------------------------------------------
section "Run tests (full log: $LOG_DIR/test.log)"
TEST_STATUS=0
xcodebuild test-without-building "${COMMON_ARGS[@]}" \
    -resultBundlePath "$RESULT_BUNDLE" \
    -parallel-testing-enabled NO \
    > "$LOG_DIR/test.log" 2>&1 || TEST_STATUS=$?

echo "Swift Testing / XCTest result lines:"
grep -E "(Test run with|Test Suite .* (passed|failed)|Executed [0-9]+ test|✘|\*\* TEST (SUCCEEDED|FAILED))" "$LOG_DIR/test.log" | tail -n 60 || true

section "Result bundle summary"
if xcrun xcresulttool get test-results summary --path "$RESULT_BUNDLE" > "$LOG_DIR/test-summary.json" 2>/dev/null; then
    python3 - "$LOG_DIR/test-summary.json" <<'PY' | tee -a "$SUMMARY"
import json, sys
s = json.load(open(sys.argv[1]))
total = s.get("totalTestCount", "?")
print(f"- Tests: {total} total, {s.get('passedTests','?')} passed, {s.get('failedTests','?')} failed, {s.get('skippedTests','?')} skipped")
for f in s.get("testFailures", [])[:50]:
    print(f"  - FAILED {f.get('testIdentifierString', f.get('testName','?'))}: {f.get('failureText','')}")
PY
else
    echo "(xcresulttool summary unavailable in this Xcode; see test.log)" | tee -a "$SUMMARY"
fi

if [[ $TEST_STATUS -ne 0 ]]; then
    show_failure "$LOG_DIR/test.log"
    echo "- Tests: **FAILED** (exit $TEST_STATUS)" >> "$SUMMARY"
    fail "tests failed (exit $TEST_STATUS). See $LOG_DIR/test.log and $RESULT_BUNDLE"
fi

echo "- Tests: all passed" >> "$SUMMARY"
section "All KickLab tests passed"
