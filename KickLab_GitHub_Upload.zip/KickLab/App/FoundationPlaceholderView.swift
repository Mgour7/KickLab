import SwiftUI

/// Temporary root view for steps 1–4 (data layer only).
/// Replaced by `RootTabView` in step 9.
struct FoundationPlaceholderView: View {
    var body: some View {
        ContentUnavailableView(
            "KickLab",
            systemImage: "football",
            description: Text("The data foundation is in place. Screens arrive in later steps.")
        )
    }
}

#Preview {
    FoundationPlaceholderView()
}
