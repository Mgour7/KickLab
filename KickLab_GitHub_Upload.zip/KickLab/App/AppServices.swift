import Foundation
import SwiftData

/// The app's composition root: one place that wires services to the main context and
/// to real file storage. Screens (from Step 9) receive services from here.
///
/// Media cleanup for kick and athlete deletion is the real `ManagedMediaStore`, so
/// deleting records removes their managed files only after the save succeeds.
@MainActor
struct AppServices {
    let context: ModelContext
    let mediaStore: ManagedMediaStore
    let analysisEngine: any VideoAnalysisService

    init(context: ModelContext, mediaStore: ManagedMediaStore, analysisEngine: any VideoAnalysisService = UnavailableVideoAnalysisService()) {
        self.context = context
        self.mediaStore = mediaStore
        self.analysisEngine = analysisEngine
    }

    /// Production wiring: Application Support storage plus AVFoundation metadata and thumbnails.
    static func live(container: ModelContainer) throws -> AppServices {
        let store = ManagedMediaStore(
            locations: try MediaLocations.applicationSupport(),
            fileSystem: LocalMediaFileSystem(),
            metadataReader: Self.makeMetadataReader(),
            thumbnailGenerator: Self.makeThumbnailGenerator()
        )
        try store.prepareDirectories()
        return AppServices(context: container.mainContext, mediaStore: store)
    }

    var kicks: KickService { KickService(context: context, mediaCleanup: mediaStore) }
    var sessions: KickingSessionService { KickingSessionService(context: context) }
    var athletes: AthleteService { AthleteService(context: context, mediaCleanup: mediaStore) }
    var analyses: AnalysisService { AnalysisService(context: context) }
    var videos: VideoStorageService { VideoStorageService(context: context, store: mediaStore) }
    var statistics: StatisticsService { StatisticsService(source: SwiftDataKickStatisticsSource(context: context)) }

    private static func makeMetadataReader() -> any VideoMetadataReading {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationVideoMetadataReader()
        #else
        return NoVideoMetadataReader()
        #endif
    }

    private static func makeThumbnailGenerator() -> any VideoThumbnailGenerating {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationThumbnailGenerator()
        #else
        return NoThumbnailGenerator()
        #endif
    }
}
