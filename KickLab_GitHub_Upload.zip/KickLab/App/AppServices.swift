import Foundation
import SwiftData

/// The app's composition root: one place that wires services to the main context and
/// to real file storage. Screens (from Step 9) receive services from here.
///
/// Media cleanup for kick and athlete deletion is the real `ManagedMediaStore`, so
/// deleting records removes their managed files only after the save succeeds.
///
/// The analysis engine is the on-device pose foundation (`PoseVideoAnalysisService`
/// with Apple Vision) where Vision is available, otherwise the unavailable engine.
@MainActor
struct AppServices {
    let context: ModelContext
    let mediaStore: ManagedMediaStore
    let analysisEngine: any VideoAnalysisService
    /// Step 10: kicking-foot changes and baseline resets used by personalization.
    let personalizationState: any PersonalizationStateStoring
    /// Build 21: training-session media work (Stage A scan, clip export, ball flight).
    var sessionScanner: any SessionScanning = UnavailableSessionScanner()
    var clipExporter: any ClipExporting = UnavailableClipExporter()
    var ballFlightTracker: any BallFlightTracking = UnavailableBallFlightTracker()

    init(
        context: ModelContext,
        mediaStore: ManagedMediaStore,
        analysisEngine: any VideoAnalysisService = UnavailableVideoAnalysisService(),
        personalizationState: any PersonalizationStateStoring = InMemoryPersonalizationState()
    ) {
        self.context = context
        self.mediaStore = mediaStore
        self.analysisEngine = analysisEngine
        self.personalizationState = personalizationState
    }

    /// Production wiring: Application Support storage plus AVFoundation metadata and thumbnails.
    static func live(container: ModelContainer) throws -> AppServices {
        let store = ManagedMediaStore(
            locations: try MediaLocations.applicationSupport(),
            fileSystem: LocalMediaFileSystem(),
            metadataReader: Self.makeMetadataReader(),
            thumbnailGenerator: Self.makeThumbnailGenerator()
        )
        try store.prepareDirectories()
        var services = AppServices(context: container.mainContext, mediaStore: store, analysisEngine: Self.makeAnalysisEngine(store: store),
                                   personalizationState: UserDefaultsPersonalizationState())
        Self.attachSessionMedia(&services)
        return services
    }

    /// Build 21: the iPhone implementations (Vision + Core ML + AVFoundation).
    private static func attachSessionMedia(_ services: inout AppServices) {
        #if canImport(Vision) && canImport(AVFoundation) && canImport(CoreML)
        services.sessionScanner = CoreMLSessionScanner(personDetector: VisionScanPerson.detector())
        services.ballFlightTracker = CoreMLBallFlightTracker()
        #endif
        #if canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
        services.clipExporter = AVClipExporter()
        #endif
    }

    /// Build 21: training sessions live beside Media/ and Analysis/ (never swept as orphans).
    var trainingSessions: TrainingSessionStore {
        TrainingSessionStore(baseURL: mediaStore.analysisRootURL.deletingLastPathComponent())
    }

    var kicks: KickService { KickService(context: context, mediaCleanup: mediaStore) }
    var sessions: KickingSessionService { KickingSessionService(context: context) }
    var athletes: AthleteService { AthleteService(context: context, mediaCleanup: mediaStore) }
    var analyses: AnalysisService { AnalysisService(context: context) }
    /// Reanalysis fix: deleting one analysis and its files.
    var analysisDeletion: AnalysisDeletionService { AnalysisDeletionService(context: context, mediaCleanup: mediaStore) }
    var videos: VideoStorageService { VideoStorageService(context: context, store: mediaStore) }
    var analysisRunner: KickAnalysisRunner {
        KickAnalysisRunner(analyses: analyses, engine: analysisEngine, personalization: personalizationRecorder)
    }
    var learning: AthleteLearningService { AthleteLearningService(state: personalizationState) }
    var personalizationRecorder: PersonalizationRecorder {
        PersonalizationRecorder(learning: learning, artifactStore: AnalysisArtifactStore(analysisRootURL: mediaStore.analysisRootURL,
                                                                                        fileSystem: mediaStore.fileSystem))
    }
    /// Step 12F: every source-frame time of a video (for frame-accurate verification).
    var frameTimestamps: any SourceFrameTimestampReading {
        #if canImport(AVFoundation) && canImport(CoreMedia)
        return AVSourceFrameTimestampReader()
        #else
        return UnavailableSourceFrameTimestampReader()
        #endif
    }
    /// Step 12G: the marked ball's region from real frames (for ball-movement timing).
    var ballRegions: any BallRegionReading {
        #if canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
        return AVBallRegionReader()
        #else
        return UnavailableBallRegionReader()
        #endif
    }
    var statistics: StatisticsService { StatisticsService(source: SwiftDataKickStatisticsSource(context: context)) }

    private static func makeMetadataReader() -> any VideoMetadataReading {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationVideoMetadataReader()
        #else
        return NoVideoMetadataReader()
        #endif
    }

    private static func makeAnalysisEngine(store: ManagedMediaStore) -> any VideoAnalysisService {
        #if canImport(Vision) && canImport(AVFoundation) && canImport(CoreML)
        // Step 12G: the bundled football detector (YOLOX-S, Core ML) when its model is in the app.
        return PoseVideoAnalysisService(mediaStore: store, extractor: VisionPoseSequenceExtractor(),
                                        footballAnalyzer: CoreMLFootballVideoAnalyzer())
        #else
        return UnavailableVideoAnalysisService()
        #endif
    }

    private static func makeThumbnailGenerator() -> any VideoThumbnailGenerating {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationThumbnailGenerator()
        #else
        return NoThumbnailGenerator()
        #endif
    }
}
