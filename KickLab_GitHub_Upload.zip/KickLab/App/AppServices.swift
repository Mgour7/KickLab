import Foundation
import SwiftData

/// The app's composition root: one place that wires services to the main context and
/// to real file storage. Screens (from Step 9) receive services from here.
///
/// Media cleanup for kick and athlete deletion is the real `ManagedMediaStore`, so
/// deleting records removes their managed files only after the save succeeds.
///
/// The analysis engine is the on-device pose foundation (`PoseVideoAnalysisService`
/// with Apple Vision) where Vision is available, otherwise the unavailable engine.
@MainActor
struct AppServices {
    let context: ModelContext
    let mediaStore: ManagedMediaStore
    let analysisEngine: any VideoAnalysisService
    /// Step 10: kicking-foot changes and baseline resets used by personalization.
    let personalizationState: any PersonalizationStateStoring

    init(
        context: ModelContext,
        mediaStore: ManagedMediaStore,
        analysisEngine: any VideoAnalysisService = UnavailableVideoAnalysisService(),
        personalizationState: any PersonalizationStateStoring = InMemoryPersonalizationState()
    ) {
        self.context = context
        self.mediaStore = mediaStore
        self.analysisEngine = analysisEngine
        self.personalizationState = personalizationState
    }

    /// Production wiring: Application Support storage plus AVFoundation metadata and thumbnails.
    static func live(container: ModelContainer) throws -> AppServices {
        let store = ManagedMediaStore(
            locations: try MediaLocations.applicationSupport(),
            fileSystem: LocalMediaFileSystem(),
            metadataReader: Self.makeMetadataReader(),
            thumbnailGenerator: Self.makeThumbnailGenerator()
        )
        try store.prepareDirectories()
        return AppServices(context: container.mainContext, mediaStore: store, analysisEngine: Self.makeAnalysisEngine(store: store),
                           personalizationState: UserDefaultsPersonalizationState())
    }

    var kicks: KickService { KickService(context: context, mediaCleanup: mediaStore) }
    var sessions: KickingSessionService { KickingSessionService(context: context) }
    var athletes: AthleteService { AthleteService(context: context, mediaCleanup: mediaStore) }
    var analyses: AnalysisService { AnalysisService(context: context) }
    var videos: VideoStorageService { VideoStorageService(context: context, store: mediaStore) }
    var analysisRunner: KickAnalysisRunner {
        KickAnalysisRunner(analyses: analyses, engine: analysisEngine, personalization: personalizationRecorder)
    }
    var learning: AthleteLearningService { AthleteLearningService(state: personalizationState) }
    var personalizationRecorder: PersonalizationRecorder {
        PersonalizationRecorder(learning: learning, artifactStore: AnalysisArtifactStore(analysisRootURL: mediaStore.analysisRootURL,
                                                                                        fileSystem: mediaStore.fileSystem))
    }
    var statistics: StatisticsService { StatisticsService(source: SwiftDataKickStatisticsSource(context: context)) }

    private static func makeMetadataReader() -> any VideoMetadataReading {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationVideoMetadataReader()
        #else
        return NoVideoMetadataReader()
        #endif
    }

    private static func makeAnalysisEngine(store: ManagedMediaStore) -> any VideoAnalysisService {
        #if canImport(Vision) && canImport(AVFoundation) && canImport(CoreML)
        return PoseVideoAnalysisService(mediaStore: store, extractor: VisionPoseSequenceExtractor())
        #else
        return UnavailableVideoAnalysisService()
        #endif
    }

    private static func makeThumbnailGenerator() -> any VideoThumbnailGenerating {
        #if canImport(AVFoundation) && canImport(ImageIO)
        return AVFoundationThumbnailGenerator()
        #else
        return NoThumbnailGenerator()
        #endif
    }
}
