import Foundation
import SwiftData

/// Builds the app's SwiftData container. All schema access goes through the
/// versioned schema and migration plan.
enum ModelContainerFactory {
    /// The on-disk store name.
    static let storeName = "KickLab"

    /// - Parameter inMemory: true for previews and tests. Each in-memory container
    ///   gets a unique name so tests never share state.
    static func makeContainer(inMemory: Bool = false) throws -> ModelContainer {
        let schema = Schema(versionedSchema: KickLabSchemaV3.self)
        let configuration = ModelConfiguration(
            inMemory ? "KickLab-\(UUID().uuidString)" : storeName,
            schema: schema,
            isStoredInMemoryOnly: inMemory,
            // Explicitly local-only. CloudKit sync, if ever added, is a deliberate change.
            cloudKitDatabase: .none
        )
        return try ModelContainer(
            for: schema,
            migrationPlan: KickLabMigrationPlan.self,
            configurations: configuration
        )
    }
}
