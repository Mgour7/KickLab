import SwiftUI
import SwiftData

@main
struct KickLabApp: App {
    private let container: ModelContainer
    /// The composition root, shared with every screen through `AppModel`.
    @State private var appModel: AppModel

    init() {
        let container: ModelContainer
        let services: AppServices
        do {
            container = try ModelContainerFactory.makeContainer()
            services = try AppServices.live(container: container)
        } catch {
            // TODO (step 13): replace with a recoverable error screen before release.
            fatalError("KickLab could not open its data store: \(error)")
        }
        self.container = container
        _appModel = State(initialValue: AppModel(services: services))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(appModel)
        }
        .modelContainer(container)
    }
}
