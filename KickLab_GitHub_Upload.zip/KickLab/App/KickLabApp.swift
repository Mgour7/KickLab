import SwiftUI
import SwiftData

@main
struct KickLabApp: App {
    private let container: ModelContainer

    init() {
        do {
            container = try ModelContainerFactory.makeContainer()
        } catch {
            // TODO (step 13): replace with a recoverable error screen before release.
            fatalError("KickLab could not open its data store: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup {
            FoundationPlaceholderView()
        }
        .modelContainer(container)
    }
}
