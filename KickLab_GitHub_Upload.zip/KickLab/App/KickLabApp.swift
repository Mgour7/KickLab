import SwiftUI
import SwiftData

@main
struct KickLabApp: App {
    private let container: ModelContainer
    /// The composition root. Screens receive services from here starting in Step 9.
    private let services: AppServices

    init() {
        do {
            container = try ModelContainerFactory.makeContainer()
            services = try AppServices.live(container: container)
        } catch {
            // TODO (step 13): replace with a recoverable error screen before release.
            fatalError("KickLab could not open its data store: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup {
            FoundationPlaceholderView()
        }
        .modelContainer(container)
    }
}
