import SwiftUI
import SwiftData

@main
struct KickLabApp: App {
    /// The data store and services, or the reason they couldn't be opened.
    private enum Launch {
        case ready(ModelContainer, AppModel)
        case failed(String)
    }

    @State private var launch: Launch

    init() {
        do {
            let container = try ModelContainerFactory.makeContainer()
            let services = try AppServices.live(container: container)
            _launch = State(initialValue: .ready(container, AppModel(services: services)))
        } catch {
            // Real devices: show a recoverable screen instead of crashing at launch.
            _launch = State(initialValue: .failed(UserFacingError.startupMessage(for: error)))
        }
    }

    var body: some Scene {
        WindowGroup {
            switch launch {
            case .ready(let container, let appModel):
                RootView()
                    .environment(appModel)
                    .modelContainer(container)
            case .failed(let message):
                StartupFailureView(message: message)
            }
        }
    }
}
