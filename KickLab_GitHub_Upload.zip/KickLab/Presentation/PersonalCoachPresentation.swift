import Foundation

struct CoachValueRow: Equatable, Sendable, Identifiable {
    var title: String
    var value: String
    var id: String { title }
}

struct CoachEvidenceRow: Equatable, Sendable, Identifiable {
    var title: String
    var text: String
    var id: String { title + text }
}

/// The detail behind one coaching card: every piece of evidence and how it was ranked.
struct CoachDetailPresentation: Equatable, Sendable {
    var headline: String
    var why: String?
    var cue: String?
    var rows: [CoachValueRow]
    var confidenceText: String
    var rationale: String
    var evidence: [CoachEvidenceRow]
    var priorityRows: [CoachValueRow]
}

/// One coaching card: headline, the few numbers that matter, confidence and a cue.
struct CoachCardPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var headline: String
    var cue: String?
    var rows: [CoachValueRow]
    /// "High" / "Medium" / "Low".
    var confidenceText: String
    /// What the finding is based on, e.g. "Your successful kicks".
    var basisText: String
    var categoryTitle: String
    var detail: CoachDetailPresentation
}

/// The Coach section of the results screen.
struct PersonalCoachPresentation: Equatable, Sendable {
    var learningMessage: String?
    var maturityText: String
    var fixes: [CoachCardPresentation]
    var strengths: [CoachCardPresentation]
    /// Stored, lower-priority findings (shown behind a disclosure).
    var secondary: [CoachCardPresentation]
    var notes: [String]

    static let unavailableAngleNote = "Some comparisons aren't shown because your earlier kicks were filmed from a different camera angle."

    static func make(report: PersonalizedCoachingReport, snapshot: PersonalizationArtifact? = nil) -> PersonalCoachPresentation {
        var notes: [String] = []
        if report.usedDistanceProfile, let bucket = report.distanceBucket {
            notes.append("Compared with your \(bucket.displayName)-yard field goals.")
        }
        if report.unavailableComparisons.contains(where: { $0.reason == .differentCameraAngle }) {
            notes.append(unavailableAngleNote)
        }
        if let snapshot {
            notes.append(snapshotNote(snapshot))
        }
        return PersonalCoachPresentation(
            learningMessage: report.learningMessage,
            maturityText: maturityText(report),
            fixes: report.primaryFixes.map(card),
            strengths: report.strengths.map(card),
            secondary: report.secondary.map(card),
            notes: notes
        )
    }

    /// The dashboard's "top priority": the first personalized primary fix.
    static func topPriority(_ report: PersonalizedCoachingReport) -> CoachingItemPresentation? {
        guard let f = report.primaryFixes.first else { return nil }
        return CoachingItemPresentation(
            id: f.id, category: f.category, categoryTitle: f.category.presentationTitle, observed: f.headline,
            whyItMatters: f.detail, cue: f.cue, severity: f.severity,
            severityText: f.severity.map(AnalysisPresentationBuilder.severityText),
            confidence: f.confidence, confidenceText: DisplayFormat.confidence(f.confidence), priority: 0
        )
    }

    /// "What KickLab knew when this kick was analyzed."
    static func snapshotNote(_ snapshot: PersonalizationArtifact) -> String {
        let then = snapshot.report.comparableKickCount
        let noun = PersonalCoachCopy.kicksNoun(snapshot.report.kickType, count: then)
        return "When this kick was analyzed, KickLab had \(then) comparable \(noun) to learn from."
    }

    static func maturityText(_ report: PersonalizedCoachingReport) -> String {
        let n = report.comparableKickCount
        let noun = PersonalCoachCopy.kicksNoun(report.kickType, count: n)
        switch report.maturity {
        case .insufficient: return "Personal coaching: not enough kicks yet (\(n) comparable \(noun))"
        default: return "Personal coaching: \(report.maturity.displayName.lowercased()) · \(n) comparable \(noun)"
        }
    }

    static func card(_ f: PersonalCoachingFinding) -> CoachCardPresentation {
        let rows = valueRows(f)
        return CoachCardPresentation(
            id: f.id,
            headline: f.headline,
            cue: f.cue,
            rows: rows,
            confidenceText: f.confidenceLevel.displayName,
            basisText: basisText(f.sources.first { $0 != .generalRule } ?? f.sources.first ?? .generalRule),
            categoryTitle: f.category.presentationTitle,
            detail: CoachDetailPresentation(
                headline: f.headline,
                why: f.detail,
                cue: f.cue,
                rows: rows,
                confidenceText: "\(f.confidenceLevel.displayName) · \(DisplayFormat.percent(fraction: f.confidence))",
                rationale: f.rationale,
                evidence: f.evidence.map { CoachEvidenceRow(title: evidenceTitle($0.source), text: $0.summary) },
                priorityRows: priorityRows(f.priority)
            )
        )
    }

    /// Your Normal / This Kick / Best Kicks (or the general target when there is no personal data).
    static func valueRows(_ f: PersonalCoachingFinding) -> [CoachValueRow] {
        guard let n = f.numbers else { return [] }
        var rows: [CoachValueRow] = []
        let personal = f.sources.contains { $0 != .generalRule }
        if personal, let normal = n.yourNormal {
            rows.append(CoachValueRow(title: "Your Normal", value: PersonalCoachFormat.value(normal, n.unit)))
        }
        if let value = n.thisKick {
            rows.append(CoachValueRow(title: "This Kick", value: PersonalCoachFormat.value(value, n.unit)))
        }
        if personal, let low = n.successfulLow, let high = n.successfulHigh {
            rows.append(CoachValueRow(title: "Best Kicks", value: PersonalCoachFormat.range(low, high, n.unit)))
        }
        if !personal, let low = n.generalIdealLow, let high = n.generalIdealHigh, high < 999 {
            // Build 22: the bands are provisional starting values, not measured elite ranges.
            rows.append(CoachValueRow(title: "Provisional Target", value: PersonalCoachFormat.range(low, high, n.unit)))
        }
        return rows
    }

    static func basisText(_ source: CoachingEvidenceSource) -> String {
        switch source {
        case .generalRule: "General kicking mechanics"
        case .personalBaseline: "Your normal"
        case .successfulPattern: "Your successful kicks"
        case .outcomeRelationship: "Your makes and misses"
        case .consistency: "Your consistency"
        case .trend: "Your recent trend"
        }
    }

    static func evidenceTitle(_ source: CoachingEvidenceSource) -> String {
        switch source {
        case .generalRule: "General kicking mechanics"
        case .personalBaseline: "Compared with your normal"
        case .successfulPattern: "Compared with your successful kicks"
        case .outcomeRelationship: "Makes and misses"
        case .consistency: "Consistency"
        case .trend: "Recent trend"
        }
    }

    static func priorityRows(_ p: PriorityBreakdown) -> [CoachValueRow] {
        var rows = [CoachValueRow(title: "Priority score", value: DisplayFormat.number(p.total, digits: 1))]
        let parts: [(String, Double)] = [
            ("General rule", p.ruleSeverity), ("Difference from your pattern", p.personalDeviation), ("Link to results", p.outcome),
            ("Measurement confidence", p.confidence), ("Amount of history", p.maturity), ("Recent trend", p.trend),
            ("Repeatability", p.repeatability),
        ]
        for (title, value) in parts where value != 0 {
            rows.append(CoachValueRow(title: title, value: DisplayFormat.number(value, digits: 1)))
        }
        if p.multiplier != 1 {
            rows.append(CoachValueRow(title: "Weight", value: "×" + DisplayFormat.number(p.multiplier, digits: 2)))
        }
        return rows
    }
}
