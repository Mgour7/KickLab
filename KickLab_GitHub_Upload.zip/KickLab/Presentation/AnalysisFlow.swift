import Foundation

/// Why an analysis could not produce results, in user terms.
enum AnalysisProblem: Equatable, Sendable {
    case noVideo
    case videoMissing
    case noKickerFound
    case ambiguousKicker
    case kickerTapMissed
    case notEnoughPoseData
    case poseDetectionUnavailable(PoseRuntimeEnvironment)
    case engineUnavailable
    /// Longer than `AnalysisLimits.maximumVideoSeconds`.
    case videoTooLong(seconds: Double)
    /// Step 12A: the specific reasons behind an unscored analysis.
    case kickerTrackTooShort
    case kickPhasesNotFound
    case cameraAngleLimited
    case lowPoseConfidence
    case partialMeasurementsOnly
    /// Step 12D: phase and recording problems, each with its own guidance.
    case noKickFound
    case multipleKicksFound
    case contactUncertain
    case plantNotFound
    case followThroughNotFound
    case athleteTooSmall
    /// KickLab went to the background, so the analysis was stopped cleanly.
    case interruptedByBackground
    case failed

    var title: String {
        switch self {
        case .noVideo: "No video yet"
        case .videoMissing: "Video file is missing"
        case .noKickerFound: "No kicker found"
        case .ambiguousKicker: "More than one possible kicker"
        case .kickerTapMissed: "Couldn't find the kicker there"
        case .notEnoughPoseData: "Not enough of the kick was visible"
        case .poseDetectionUnavailable: "Analysis isn't available here"
        case .engineUnavailable: "Analysis isn't available"
        case .videoTooLong: "Video is too long"
        case .kickerTrackTooShort: "Kicker was only partly followed"
        case .kickPhasesNotFound: "Couldn't find the plant and strike"
        case .cameraAngleLimited: "Camera angle limits the analysis"
        case .lowPoseConfidence: "Body tracking was too uncertain"
        case .partialMeasurementsOnly: "Only partial measurements"
        case .noKickFound: "No kick found"
        case .multipleKicksFound: "More than one kick found"
        case .contactUncertain: "Couldn't pinpoint the strike"
        case .plantNotFound: "Couldn't find the plant step"
        case .followThroughNotFound: "Couldn't measure the follow-through"
        case .athleteTooSmall: "Kicker too small in the video"
        case .interruptedByBackground: "Analysis was paused"
        case .failed: "Analysis didn't finish"
        }
    }

    var message: String {
        switch self {
        case .noVideo:
            "Import a video of this kick to analyze its mechanics."
        case .videoMissing:
            "KickLab can't find the video file for this kick on this device. Import the video again to analyze it."
        case .noKickerFound:
            "KickLab couldn't find a clearly visible person in the video. Try a video filmed from the side with the whole body in frame. If the camera was far away (for example behind the goal), the kicker is too small to detect, so that recording can't be used for body mechanics."
        case .ambiguousKicker:
            "Several people are moving in this video. Tap the kicker so KickLab knows who to analyze."
        case .kickerTapMissed:
            "No person was found where you tapped. Try tapping directly on the kicker's body."
        case .notEnoughPoseData:
            "The kicker's legs weren't visible clearly enough to measure the kick. A side view with the whole body in frame works best."
        case .poseDetectionUnavailable(.simulator):
            "Pose detection can't run in the iOS Simulator. Analyze on an iPhone."
        case .poseDetectionUnavailable(.device):
            "Pose detection isn't available on this device."
        case .engineUnavailable:
            "Video analysis isn't available on this device."
        case .videoTooLong(let seconds):
            "This video is \(Int(seconds.rounded())) seconds long. KickLab analyzes clips up to \(Int(AnalysisLimits.maximumVideoSeconds)) seconds. Trim the video to the kick in Photos, then import it again."
        case .kickerTrackTooShort:
            "KickLab lost track of the kicker for much of the video. Keep the kicker in frame from the approach to the follow-through, or tap the kicker to select them, then try again."
        case .kickPhasesNotFound:
            "KickLab followed the kicker but couldn't find the moments the plant foot lands and the foot strikes the ball. Make sure the clip includes the whole kick, and check the kicking foot in the athlete's profile."
        case .cameraAngleLimited:
            "From the camera angle chosen for this video, KickLab can't measure leg and body angles reliably enough to score them. For a full analysis, film from the side, level with the kicker. If the camera really was mostly to the side, import the video again with the angle set to Side."
        case .lowPoseConfidence:
            "Body tracking wasn't confident about the kicker's position in most frames. Better light, a steady camera, framing the kicker larger, or slow-motion recording usually help."
        case .partialMeasurementsOnly:
            "KickLab measured part of the kick, but not enough of any one phase to give it a score. A clear side view of the whole kick usually helps."
        case .noKickFound:
            "KickLab followed the kicker but found no approach and swing that looks like a kick. Make sure the clip includes the run-up and the kick, or choose the kick yourself."
        case .multipleKicksFound:
            "This video contains more than one kick. Choose the kick you want analyzed; the video itself isn't changed."
        case .contactUncertain:
            "We couldn't confidently identify the strike. Select the frame where your foot contacts the ball, and KickLab will measure the kick around it."
        case .plantNotFound:
            "KickLab couldn't tell when the plant foot landed, so plant measurements aren't available. A steady side view with the feet clearly visible helps; you can also select the strike frame yourself."
        case .followThroughNotFound:
            "KickLab couldn't follow the kicking leg after contact (the foot often blurs at 30 fps). Recording at 60 fps or in slow motion, with the camera still, usually fixes this."
        case .athleteTooSmall:
            "The kicker is too small in this recording for reliable biomechanics analysis. Move closer and keep the entire body visible. Distant footage (for example from behind the goal) can't measure body mechanics."
        case .interruptedByBackground:
            "KickLab stopped the analysis when it left the screen. Keep KickLab open while it analyzes, then tap Try Again."
        case .failed:
            "Something went wrong while analyzing. Your video and kick are safe; you can try again."
        }
    }

    var canRetry: Bool {
        switch self {
        case .noVideo, .videoMissing, .poseDetectionUnavailable, .engineUnavailable, .videoTooLong: false
        default: true
        }
    }

    /// Step 12D: selecting the strike frame yourself is offered.
    var offersContactSelection: Bool {
        switch self {
        case .contactUncertain, .noKickFound, .plantNotFound, .followThroughNotFound, .kickPhasesNotFound, .partialMeasurementsOnly: true
        default: false
        }
    }

    /// Step 12D: choosing which kick (an interval of the video) is offered.
    var offersKickSelection: Bool { self == .multipleKicksFound || self == .noKickFound }

    /// Selecting the kicker by tapping is the suggested fix.
    var suggestsKickerSelection: Bool {
        self == .ambiguousKicker || self == .kickerTapMissed || self == .noKickerFound || self == .kickerTrackTooShort
    }

    /// From a finished run that did not complete.
    static func from(kickerStatus: KickerSelectionStatus?, failureReason: String) -> AnalysisProblem {
        switch kickerStatus {
        case .noCandidates: return .noKickerFound
        case .ambiguous: return .ambiguousKicker
        case .seedNotMatched: return .kickerTapMissed
        case .selected, .none: break
        }
        if failureReason == AnalysisFailureReasons.insufficientData { return .notEnoughPoseData }
        if let cause = AnalysisFailureCause(reasonText: failureReason) { return from(cause) }
        // The runner stores engine errors as their description; map the known ones back.
        for error in Self.recognizedEngineErrors where error.errorDescription == failureReason {
            return from(engineError: error)
        }
        return .failed
    }

    private static let recognizedEngineErrors: [VideoAnalysisError] = [
        .poseDetectionUnavailable(environment: .simulator),
        .poseDetectionUnavailable(environment: .device),
        .noUsableInputs,
    ]

    /// Step 12A: the user-facing problem for a diagnosed cause.
    static func from(_ cause: AnalysisFailureCause) -> AnalysisProblem {
        switch cause {
        case .kickerTrackTooShort: .kickerTrackTooShort
        case .kickPhasesNotFound: .kickPhasesNotFound
        case .cameraAngleLimited: .cameraAngleLimited
        case .lowPoseConfidence: .lowPoseConfidence
        case .legJointsNotVisible: .notEnoughPoseData
        case .notEnoughScoredMetrics: .partialMeasurementsOnly
        case .noCredibleKickWindow: .noKickFound
        case .multipleKickWindows: .multipleKicksFound
        case .ambiguousContact: .contactUncertain
        case .plantUnavailable: .plantNotFound
        case .followThroughUnavailable: .followThroughNotFound
        case .athleteTooSmall: .athleteTooSmall
        }
    }

    /// From an engine error thrown before a record could finish.
    static func from(engineError error: VideoAnalysisError) -> AnalysisProblem {
        switch error {
        case .noInputs: .noVideo
        case .noUsableInputs: .videoMissing
        case .unavailable: .engineUnavailable
        case .poseDetectionUnavailable(let environment): .poseDetectionUnavailable(environment)
        case .cancelled, .failed: .failed
        }
    }
}

/// The analysis screen's state.
enum AnalysisFlowState: Equatable, Sendable {
    case idle
    case running(stage: VideoAnalysisStage, fraction: Double)
    case cancelling
    case completed(analysisID: UUID)
    case failed(AnalysisProblem)
    case cancelled

    var isBusy: Bool {
        switch self {
        case .running, .cancelling: true
        default: false
        }
    }

    var canStart: Bool { !isBusy }

    var stageText: String? {
        guard case .running(let stage, _) = self else { return nil }
        switch stage {
        case .preparing: return "Preparing video"
        case .extractingFrames: return "Reading frames"
        case .detectingPose: return "Detecting body position"
        case .detectingEvents: return "Finding the kick phases"
        case .measuring: return "Measuring mechanics"
        case .scoring: return "Scoring and coaching"
        case .finishing: return "Saving results"
        }
    }
}

enum AnalysisFlowEvent: Equatable, Sendable {
    case start
    case progress(VideoAnalysisProgress)
    case cancelRequested
    case completed(analysisID: UUID)
    case failed(AnalysisProblem)
    case cancelled
    case reset
}

/// Pure transitions. Progress never moves backwards and is ignored once the run ended.
enum AnalysisFlowMachine {
    static func reduce(_ state: AnalysisFlowState, _ event: AnalysisFlowEvent) -> AnalysisFlowState {
        switch (state, event) {
        case (_, .reset):
            return state.isBusy ? state : .idle
        case (let s, .start):
            return s.canStart ? .running(stage: .preparing, fraction: 0) : s
        case (.running(_, let fraction), .progress(let p)):
            return .running(stage: p.stage, fraction: max(fraction, p.fractionCompleted))
        case (.running, .cancelRequested):
            return .cancelling
        case (.running, .completed(let id)), (.cancelling, .completed(let id)):
            return .completed(analysisID: id)
        case (.running, .failed(let problem)), (.cancelling, .failed(let problem)):
            return .failed(problem)
        case (.running, .cancelled), (.cancelling, .cancelled):
            return .cancelled
        default:
            return state
        }
    }
}

/// The three ways a kick can be (re)analyzed. Every run states its mode explicitly; a
/// manual contact or kick interval is used ONLY by the run it was chosen for, and is
/// never remembered for later runs, for the video, or for the kick.
///
/// (Replaying diagnostics is not a run: it re-reads an analysis' stored pose and creates
/// nothing. See `AnalysisDiagnosticsReport.replay` and `.automaticReplay`.)
enum AnalysisRunMode: Equatable, Sendable {
    /// The current engine on the original video, with no user input.
    case automatic
    /// The user's contact frame, chosen on the strike-selection screen for this run.
    case manualContact(seconds: Double)
    /// The user's kick interval, chosen on the kick-selection screen for this run.
    case manualKickWindow(start: Double, end: Double)
    /// Step 12G: frames the user verified in Verify Contact — a contact frame and/or the
    /// ball's measured departure, and/or a plant frame.
    case verified(PhaseDetectionAssistance)

    /// What the engine is given. Nil for automatic runs, always.
    var assistance: PhaseDetectionAssistance? {
        switch self {
        case .automatic: nil
        case .manualContact(let t): PhaseDetectionAssistance(contactTime: t)
        case .manualKickWindow(let a, let b): PhaseDetectionAssistance(windowStart: a, windowEnd: b)
        case .verified(let a): a
        }
    }

    var isUserAssisted: Bool { self != .automatic }

    var title: String {
        switch self {
        case .automatic: "Automatic analysis"
        case .manualContact: "User-assisted analysis (contact frame chosen by you)"
        case .manualKickWindow: "User-assisted analysis (kick chosen by you)"
        case .verified(let a):
            a.ballMotion?.outcome == .departed && a.contactTime == nil
                ? "User-assisted analysis (contact from the ball you marked)"
                : "User-assisted analysis (frames you verified)"
        }
    }

    /// The mode a stored assistance corresponds to (nil or empty = automatic).
    init(assistance: PhaseDetectionAssistance?) {
        if let a = assistance, a.plantTime != nil || a.ballMotion != nil {
            self = .verified(a)
        } else if let t = assistance?.contactTime {
            self = .manualContact(seconds: t)
        } else if let w = assistance?.window {
            self = .manualKickWindow(start: w.lowerBound, end: w.upperBound)
        } else {
            self = .automatic
        }
    }
}

/// Choosing the contact frame by hand (the "Reanalyze With Manual Contact" screen).
///
/// The player opens at the automatic estimate so the user starts near the kick, but the
/// estimate is NOT a choice: the run can only start after the user has positioned the
/// video themselves (stepped, scrubbed or tapped the timeline). Otherwise pressing the
/// button straight away would silently turn the automatic estimate into a "user" contact.
struct ManualContactSelection: Equatable, Sendable {
    /// Where the player opens (the automatic estimate), for orientation only.
    var automaticEstimate: Double?
    /// True once the USER has moved the video (stepped, scrubbed or tapped the timeline).
    private(set) var hasUserPositioned = false

    init(automaticEstimate: Double?) {
        self.automaticEstimate = automaticEstimate
    }

    /// The user moved the video themselves.
    mutating func userPositionedVideo() {
        hasUserPositioned = true
    }

    var canSubmit: Bool { hasUserPositioned }

    /// The run to start with the frame now shown, or nil until the user has positioned
    /// the video themselves.
    func runMode(currentTime: Double) -> AnalysisRunMode? {
        guard hasUserPositioned, currentTime.isFinite, currentTime >= 0 else { return nil }
        return .manualContact(seconds: currentTime)
    }

    var hint: String {
        if hasUserPositioned { return "Reanalyze uses the frame shown now as the contact." }
        if let e = automaticEstimate {
            return String(format: "The video opens at KickLab's automatic estimate (%.3f s). Step or scrub to the frame where the foot meets the ball, then reanalyze.", e)
        }
        return "Step or scrub to the frame where the foot meets the ball, then reanalyze."
    }
}

/// How one analysis was produced: its engine version and who set the contact time.
/// Shown on results and in diagnostics so an automatic and a user-assisted result can't
/// be confused.
struct AnalysisProvenance: Equatable, Sendable {
    var engineVersion: String
    var mode: AnalysisRunMode
    /// Nil when contact wasn't found or the analysis predates this information.
    var contactSource: ContactTimingSource?
    var contactMethod: String?
    var contactTime: Double?

    init(engineVersion: String, phases: KickPhaseDetectionResult?) {
        self.engineVersion = engineVersion
        let assistance = phases?.assistance
        var mode = AnalysisRunMode(assistance: assistance)
        // Older assisted files: the label alone says it was assisted.
        if mode == .automatic, AnalysisAssistanceLabel.isAssisted(engineVersion), let t = phases?.evidence?.userAssistedContactTime {
            mode = .manualContact(seconds: t)
        }
        self.mode = mode
        contactSource = phases?.evidence?.contactTimingSource
        contactMethod = phases?.evidence?.contactTimingMethodResolved
        contactTime = phases?.estimatedContactTime
    }

    var engineText: String { "Engine: \(engineVersion)" }

    var contactText: String {
        guard let contactTime else { return "Contact timing: not found" }
        let time = String(format: "%.3f s", contactTime)
        switch contactSource {
        case .user:
            return "Contact timing: chosen by you (\(time))"
        case .automatic:
            switch contactMethod {
            case "plantAndFootPassing": return "Contact timing: automatic, estimated from the plant step and foot passing (\(time))"
            case "speedPeak": return "Contact timing: automatic, from the fastest kicking-foot swing (\(time))"
            default: return "Contact timing: automatic (\(time))"
            }
        case nil:
            return "Contact timing: automatic (\(time))"
        }
    }
}

/// Step 12D: when to offer user-assisted recovery on a finished analysis.
enum AssistanceOffer: Equatable, Sendable {
    case none
    /// Several kicks: choose one.
    case chooseKick
    /// The strike moment is uncertain: choose the contact frame.
    case chooseContact

    static func make(phases: KickPhaseDetectionResult?, engineVersion: String) -> AssistanceOffer {
        guard let phases, !AnalysisAssistanceLabel.isAssisted(engineVersion), phases.assistance == nil else { return .none }
        if phases.kickWindows?.needsSelection == true { return .chooseKick }
        let contact = phases.phase(.contact)
        if contact.status == .unavailable || contact.status == .ambiguous || contact.confidence < 0.3 { return .chooseContact }
        if phases.evidence?.contactTimedByConstraints == true { return .chooseContact }
        return .none
    }

    var title: String {
        switch self {
        case .none: ""
        case .chooseKick: "Choose which kick to analyze"
        case .chooseContact: "Select the strike frame yourself"
        }
    }

    var message: String {
        switch self {
        case .none: ""
        case .chooseKick: "This video has more than one kick. Pick the one you want; the video and this analysis stay as they are."
        case .chooseContact: "We couldn't confidently identify the moment of contact. Verify Contact lets you step through the frames, or mark the ball so KickLab measures when it leaves its spot; then run a new, user-assisted analysis. This one stays as it is."
        }
    }
}
