import Foundation

/// Why an analysis could not produce results, in user terms.
enum AnalysisProblem: Equatable, Sendable {
    case noVideo
    case videoMissing
    case noKickerFound
    case ambiguousKicker
    case kickerTapMissed
    case notEnoughPoseData
    case poseDetectionUnavailable(PoseRuntimeEnvironment)
    case engineUnavailable
    /// Longer than `AnalysisLimits.maximumVideoSeconds`.
    case videoTooLong(seconds: Double)
    /// Step 12A: the specific reasons behind an unscored analysis.
    case kickerTrackTooShort
    case kickPhasesNotFound
    case cameraAngleLimited
    case lowPoseConfidence
    case partialMeasurementsOnly
    /// KickLab went to the background, so the analysis was stopped cleanly.
    case interruptedByBackground
    case failed

    var title: String {
        switch self {
        case .noVideo: "No video yet"
        case .videoMissing: "Video file is missing"
        case .noKickerFound: "No kicker found"
        case .ambiguousKicker: "More than one possible kicker"
        case .kickerTapMissed: "Couldn't find the kicker there"
        case .notEnoughPoseData: "Not enough of the kick was visible"
        case .poseDetectionUnavailable: "Analysis isn't available here"
        case .engineUnavailable: "Analysis isn't available"
        case .videoTooLong: "Video is too long"
        case .kickerTrackTooShort: "Kicker was only partly followed"
        case .kickPhasesNotFound: "Couldn't find the plant and strike"
        case .cameraAngleLimited: "Camera angle limits the analysis"
        case .lowPoseConfidence: "Body tracking was too uncertain"
        case .partialMeasurementsOnly: "Only partial measurements"
        case .interruptedByBackground: "Analysis was paused"
        case .failed: "Analysis didn't finish"
        }
    }

    var message: String {
        switch self {
        case .noVideo:
            "Import a video of this kick to analyze its mechanics."
        case .videoMissing:
            "KickLab can't find the video file for this kick on this device. Import the video again to analyze it."
        case .noKickerFound:
            "KickLab couldn't find a clearly visible person in the video. Try a video filmed from the side with the whole body in frame."
        case .ambiguousKicker:
            "Several people are moving in this video. Tap the kicker so KickLab knows who to analyze."
        case .kickerTapMissed:
            "No person was found where you tapped. Try tapping directly on the kicker's body."
        case .notEnoughPoseData:
            "The kicker's legs weren't visible clearly enough to measure the kick. A side view with the whole body in frame works best."
        case .poseDetectionUnavailable(.simulator):
            "Pose detection can't run in the iOS Simulator. Analyze on an iPhone."
        case .poseDetectionUnavailable(.device):
            "Pose detection isn't available on this device."
        case .engineUnavailable:
            "Video analysis isn't available on this device."
        case .videoTooLong(let seconds):
            "This video is \(Int(seconds.rounded())) seconds long. KickLab analyzes clips up to \(Int(AnalysisLimits.maximumVideoSeconds)) seconds. Trim the video to the kick in Photos, then import it again."
        case .kickerTrackTooShort:
            "KickLab lost track of the kicker for much of the video. Keep the kicker in frame from the approach to the follow-through, or tap the kicker to select them, then try again."
        case .kickPhasesNotFound:
            "KickLab followed the kicker but couldn't find the moments the plant foot lands and the foot strikes the ball. Make sure the clip includes the whole kick, and check the kicking foot in the athlete's profile."
        case .cameraAngleLimited:
            "From the camera angle chosen for this video, KickLab can't measure leg and body angles reliably enough to score them. For a full analysis, film from the side, level with the kicker. If the camera really was mostly to the side, import the video again with the angle set to Side."
        case .lowPoseConfidence:
            "Body tracking wasn't confident about the kicker's position in most frames. Better light, a steady camera, framing the kicker larger, or slow-motion recording usually help."
        case .partialMeasurementsOnly:
            "KickLab measured part of the kick, but not enough of any one phase to give it a score. A clear side view of the whole kick usually helps."
        case .interruptedByBackground:
            "KickLab stopped the analysis when it left the screen. Keep KickLab open while it analyzes, then tap Try Again."
        case .failed:
            "Something went wrong while analyzing. Your video and kick are safe; you can try again."
        }
    }

    var canRetry: Bool {
        switch self {
        case .noVideo, .videoMissing, .poseDetectionUnavailable, .engineUnavailable, .videoTooLong: false
        default: true
        }
    }

    /// Selecting the kicker by tapping is the suggested fix.
    var suggestsKickerSelection: Bool {
        self == .ambiguousKicker || self == .kickerTapMissed || self == .noKickerFound || self == .kickerTrackTooShort
    }

    /// From a finished run that did not complete.
    static func from(kickerStatus: KickerSelectionStatus?, failureReason: String) -> AnalysisProblem {
        switch kickerStatus {
        case .noCandidates: return .noKickerFound
        case .ambiguous: return .ambiguousKicker
        case .seedNotMatched: return .kickerTapMissed
        case .selected, .none: break
        }
        if failureReason == AnalysisFailureReasons.insufficientData { return .notEnoughPoseData }
        if let cause = AnalysisFailureCause(reasonText: failureReason) { return from(cause) }
        // The runner stores engine errors as their description; map the known ones back.
        for error in Self.recognizedEngineErrors where error.errorDescription == failureReason {
            return from(engineError: error)
        }
        return .failed
    }

    private static let recognizedEngineErrors: [VideoAnalysisError] = [
        .poseDetectionUnavailable(environment: .simulator),
        .poseDetectionUnavailable(environment: .device),
        .noUsableInputs,
    ]

    /// Step 12A: the user-facing problem for a diagnosed cause.
    static func from(_ cause: AnalysisFailureCause) -> AnalysisProblem {
        switch cause {
        case .kickerTrackTooShort: .kickerTrackTooShort
        case .kickPhasesNotFound: .kickPhasesNotFound
        case .cameraAngleLimited: .cameraAngleLimited
        case .lowPoseConfidence: .lowPoseConfidence
        case .legJointsNotVisible: .notEnoughPoseData
        case .notEnoughScoredMetrics: .partialMeasurementsOnly
        }
    }

    /// From an engine error thrown before a record could finish.
    static func from(engineError error: VideoAnalysisError) -> AnalysisProblem {
        switch error {
        case .noInputs: .noVideo
        case .noUsableInputs: .videoMissing
        case .unavailable: .engineUnavailable
        case .poseDetectionUnavailable(let environment): .poseDetectionUnavailable(environment)
        case .cancelled, .failed: .failed
        }
    }
}

/// The analysis screen's state.
enum AnalysisFlowState: Equatable, Sendable {
    case idle
    case running(stage: VideoAnalysisStage, fraction: Double)
    case cancelling
    case completed(analysisID: UUID)
    case failed(AnalysisProblem)
    case cancelled

    var isBusy: Bool {
        switch self {
        case .running, .cancelling: true
        default: false
        }
    }

    var canStart: Bool { !isBusy }

    var stageText: String? {
        guard case .running(let stage, _) = self else { return nil }
        switch stage {
        case .preparing: return "Preparing video"
        case .extractingFrames: return "Reading frames"
        case .detectingPose: return "Detecting body position"
        case .detectingEvents: return "Finding the kick phases"
        case .measuring: return "Measuring mechanics"
        case .scoring: return "Scoring and coaching"
        case .finishing: return "Saving results"
        }
    }
}

enum AnalysisFlowEvent: Equatable, Sendable {
    case start
    case progress(VideoAnalysisProgress)
    case cancelRequested
    case completed(analysisID: UUID)
    case failed(AnalysisProblem)
    case cancelled
    case reset
}

/// Pure transitions. Progress never moves backwards and is ignored once the run ended.
enum AnalysisFlowMachine {
    static func reduce(_ state: AnalysisFlowState, _ event: AnalysisFlowEvent) -> AnalysisFlowState {
        switch (state, event) {
        case (_, .reset):
            return state.isBusy ? state : .idle
        case (let s, .start):
            return s.canStart ? .running(stage: .preparing, fraction: 0) : s
        case (.running(_, let fraction), .progress(let p)):
            return .running(stage: p.stage, fraction: max(fraction, p.fractionCompleted))
        case (.running, .cancelRequested):
            return .cancelling
        case (.running, .completed(let id)), (.cancelling, .completed(let id)):
            return .completed(analysisID: id)
        case (.running, .failed(let problem)), (.cancelling, .failed(let problem)):
            return .failed(problem)
        case (.running, .cancelled), (.cancelling, .cancelled):
            return .cancelled
        default:
            return state
        }
    }
}
