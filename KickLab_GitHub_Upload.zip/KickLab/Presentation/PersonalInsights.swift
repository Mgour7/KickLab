import Foundation

/// One analyzed kick in an athlete's history (the kick's current, completed analysis).
struct KickHistoryEntry: Equatable, Sendable, Identifiable {
    var id: UUID { analysisID }
    var kickID: UUID
    var analysisID: UUID
    var date: Date
    var kickType: KickType
    /// FG/PAT result, when recorded.
    var result: KickResult?
    /// Kickoff touchback, when recorded.
    var touchback: Bool?
    var overallScore: Double?
    var overallConfidence: Double?
    var snapshot: MetricSnapshot

    /// A kick that achieved its goal, by recorded outcome only (unknown → not successful).
    var isSuccessful: Bool {
        switch kickType {
        case .fieldGoal, .pat: result == .made
        case .kickoff: touchback == true
        case .punt, .unknown: false
        }
    }
}

/// Whether a personal comparison can be shown yet.
enum InsightAvailability: Equatable, Sendable {
    case available
    case needsMoreKicks(have: Int, need: Int)

    var isAvailable: Bool { self == .available }
}

/// The athlete-specific references the app can honestly offer for one kick type.
/// Produced by a `PersonalInsightsProviding`; the views read only this type, so a future
/// learning engine can replace the rule-based provider without changing them.
struct PersonalInsights: Equatable, Sendable {
    var kickType: KickType
    /// How many usable analyzed kicks of this type exist.
    var analyzedKickCount: Int
    var baseline: AthleteMetricBaseline?
    var baselineAvailability: InsightAvailability
    /// Best kicks, best first.
    var bestKicks: [KickHistoryEntry]
    var bestKicksAvailability: InsightAvailability
    /// Typical values on successful kicks (a baseline over successful kicks only).
    var successfulKickBaseline: AthleteMetricBaseline?
    var successfulKickAvailability: InsightAvailability
    /// Least-squares slope per day for metrics with enough recent history.
    var recentTrends: [KickMetricKey: Double]
    var trendAvailability: InsightAvailability
    /// How the insights were produced, shown to the user for transparency.
    var methodDescription: String

    static let baselineNeededMessage = "More kicks are needed before KickLab can build your personal baseline."
    static let bestKicksNeededMessage = "More analyzed kicks are needed before KickLab can pick out your best kicks."
    static let successfulNeededMessage = "More successful kicks with video are needed to show your typical values on makes."
    static let trendNeededMessage = "More analyzed kicks are needed to show a trend."
}

protocol PersonalInsightsProviding: Sendable {
    func insights(history: [KickHistoryEntry], kickType: KickType, now: Date) -> PersonalInsights
}

/// Conservative, transparent rules over stored analyses. No machine learning.
///
/// - Baseline: per-metric statistics over at least `minimumKicks` analyzed kicks.
/// - Best kicks: analyzed kicks with overall confidence ≥ `minimumConfidence`, successful
///   ones first, then by overall score; at least `minimumKicks` candidates needed.
/// - Typical values on successful kicks: a baseline over successful kicks only.
/// - Recent trend: slope over the last `trendWindowDays`, needing `minimumTrendKicks` kicks.
struct RuleBasedPersonalInsights: PersonalInsightsProviding {
    var minimumKicks = 3
    var minimumTrendKicks = 4
    var minimumConfidence = 0.5
    var bestKickLimit = 5
    var trendWindowDays: Double = 90

    init() {}

    func insights(history: [KickHistoryEntry], kickType: KickType, now: Date) -> PersonalInsights {
        let kicks = history
            .filter { $0.kickType == kickType && !$0.snapshot.values.isEmpty }
            .sorted { $0.date < $1.date }
        let snapshots = kicks.map(\.snapshot)
        let baseline = MetricComparison.baseline(from: snapshots, kickType: kickType, minimumKicks: minimumKicks)

        let confident = kicks.filter { ($0.overallConfidence ?? 0) >= minimumConfidence && $0.overallScore != nil }
        let ranked = confident.sorted { a, b in
            if a.isSuccessful != b.isSuccessful { return a.isSuccessful }
            let sa = a.overallScore ?? 0
            let sb = b.overallScore ?? 0
            if sa != sb { return sa > sb }
            let ca = a.overallConfidence ?? 0
            let cb = b.overallConfidence ?? 0
            if ca != cb { return ca > cb }
            return a.date > b.date
        }
        let bestAvailable = confident.count >= minimumKicks

        let successful = kicks.filter(\.isSuccessful)
        let successfulBaseline = MetricComparison.baseline(from: successful.map(\.snapshot), kickType: kickType, minimumKicks: minimumKicks)

        let windowStart = now.addingTimeInterval(-trendWindowDays * 86_400)
        let recent = kicks.filter { $0.date >= windowStart }
        var trends: [KickMetricKey: Double] = [:]
        if recent.count >= minimumTrendKicks {
            for key in KickMetricKey.allCases {
                let trend = MetricComparison.trend(of: key, in: recent.map(\.snapshot))
                if trend.points.count >= minimumTrendKicks, let slope = trend.slopePerDay {
                    trends[key] = slope
                }
            }
        }

        return PersonalInsights(
            kickType: kickType,
            analyzedKickCount: kicks.count,
            baseline: baseline,
            baselineAvailability: baseline == nil ? .needsMoreKicks(have: kicks.count, need: minimumKicks) : .available,
            bestKicks: bestAvailable ? Array(ranked.prefix(bestKickLimit)) : [],
            bestKicksAvailability: bestAvailable ? .available : .needsMoreKicks(have: confident.count, need: minimumKicks),
            successfulKickBaseline: successfulBaseline,
            successfulKickAvailability: successfulBaseline == nil ? .needsMoreKicks(have: successful.count, need: minimumKicks) : .available,
            recentTrends: trends,
            trendAvailability: recent.count >= minimumTrendKicks ? .available : .needsMoreKicks(have: recent.count, need: minimumTrendKicks),
            methodDescription: "Based on your stored analyses using fixed rules (at least \(minimumKicks) kicks). KickLab does not use machine learning yet."
        )
    }
}

// MARK: - Per-metric references

/// The four reference points for one metric, each honest about availability.
struct MetricReferencePresentation: Equatable, Sendable, Identifiable {
    var id: String { key.rawValue }
    var key: KickMetricKey
    var name: String
    var currentText: String
    /// "General technique target": the expert-defined ideal band.
    var generalTarget: String?
    var baseline: String?
    var bestKicks: String?
    var trend: String?
    /// Shown instead of a personal value while history is insufficient.
    var baselineMessage: String?
    var bestKicksMessage: String?
    var trendMessage: String?

    static func make(
        key: KickMetricKey,
        currentValue: Double?,
        profile: BiomechanicsProfile,
        insights: PersonalInsights
    ) -> MetricReferencePresentation {
        let definition = key.definition
        let unit = definition.unit
        var target: String?
        if let band = profile.scoring[key]?.band, (profile.scoring[key]?.weight ?? 0) > 0 {
            target = targetText(band, unit: unit)
        }
        var baselineText: String?
        if let stat = insights.baseline?.statistics[key] {
            baselineText = DisplayFormat.metricValue(stat.mean, unit: unit) + " average over \(stat.count) kicks"
        }
        var bestText: String?
        if let stat = insights.successfulKickBaseline?.statistics[key] {
            bestText = DisplayFormat.metricValue(stat.median, unit: unit) + " typical on your successful kicks"
        }
        var trendText: String?
        if let slope = insights.recentTrends[key] {
            trendText = trendDescription(slope: slope, key: key, profile: profile, current: currentValue)
        }
        return MetricReferencePresentation(
            key: key,
            name: definition.displayName,
            currentText: DisplayFormat.metricValue(currentValue, unit: unit),
            generalTarget: target,
            baseline: baselineText,
            bestKicks: bestText,
            trend: trendText,
            baselineMessage: baselineText == nil ? PersonalInsights.baselineNeededMessage : nil,
            bestKicksMessage: bestText == nil ? PersonalInsights.successfulNeededMessage : nil,
            trendMessage: trendText == nil ? PersonalInsights.trendNeededMessage : nil
        )
    }

    static func targetText(_ band: ScoreBand, unit: MetricUnit) -> String {
        let low = DisplayFormat.metricValue(band.idealLow, unit: unit)
        let high = DisplayFormat.metricValue(band.idealHigh, unit: unit)
        if band.idealHigh >= 999 { return "\(low) or more" }
        if band.zeroLow == nil && band.idealLow <= 0 { return "\(high) or less" }
        return "\(low) to \(high)"
    }

    /// Describes a per-day slope as improving / steady / declining using the metric's
    /// better direction (and the ideal band for "toward ideal" metrics).
    static func trendDescription(slope: Double, key: KickMetricKey, profile: BiomechanicsProfile, current: Double?) -> String {
        let perMonth = slope * 30
        let scale = max(abs(current ?? 1), 1e-6)
        if abs(perMonth) < 0.02 * scale { return "Steady recently" }
        let improving: Bool?
        switch key.definition.betterDirection {
        case .higher: improving = perMonth > 0
        case .lower: improving = perMonth < 0
        case .towardIdealBand:
            if let band = profile.scoring[key]?.band, let current {
                let next = current + perMonth
                improving = band.distanceFromIdeal(next) < band.distanceFromIdeal(current)
            } else {
                improving = nil
            }
        case .none: improving = nil
        }
        switch improving {
        case .some(true): return "Improving recently"
        case .some(false): return "Moving away from the target recently"
        case .none: return perMonth > 0 ? "Rising recently" : "Falling recently"
        }
    }
}

// MARK: - Comparisons

enum ComparisonTarget: Equatable, Sendable {
    case previousAnalysis
    case baseline
    case earlierKick(date: Date)

    var title: String {
        switch self {
        case .previousAnalysis: "Compared with the previous analysis of this kick"
        case .baseline: "Compared with your baseline"
        case .earlierKick: "Compared with an earlier kick"
        }
    }
}

struct ComparisonRowPresentation: Equatable, Sendable, Identifiable {
    var id: String { key.rawValue }
    var key: KickMetricKey
    var name: String
    var currentText: String
    var referenceText: String
    var differenceText: String
    var directionText: String
    var direction: MetricChangeDirection
}

struct ComparisonPresentation: Equatable, Sendable {
    var target: ComparisonTarget
    var rows: [ComparisonRowPresentation]
    /// Shown when nothing can be compared.
    var emptyMessage: String?

    static func make(deltas: [MetricDelta], target: ComparisonTarget) -> ComparisonPresentation {
        let rows = deltas.map { delta in
            row(key: delta.key, current: delta.current, reference: delta.reference, difference: delta.difference, direction: delta.direction)
        }
        return ComparisonPresentation(
            target: target, rows: rows,
            emptyMessage: rows.isEmpty ? "No measurements could be compared with enough confidence." : nil
        )
    }

    static func make(deviations: [BaselineDeviation]) -> ComparisonPresentation {
        let rows = deviations.map { d in
            row(key: d.key, current: d.value, reference: d.baselineMean, difference: d.difference, direction: d.direction)
        }
        return ComparisonPresentation(
            target: .baseline, rows: rows,
            emptyMessage: rows.isEmpty ? "No measurements could be compared with your baseline." : nil
        )
    }

    static func unavailable(_ target: ComparisonTarget, message: String) -> ComparisonPresentation {
        ComparisonPresentation(target: target, rows: [], emptyMessage: message)
    }

    static func row(key: KickMetricKey, current: Double, reference: Double, difference: Double, direction: MetricChangeDirection) -> ComparisonRowPresentation {
        let unit = key.definition.unit
        let sign = difference > 0 ? "+" : ""
        return ComparisonRowPresentation(
            key: key,
            name: key.definition.displayName,
            currentText: DisplayFormat.metricValue(current, unit: unit),
            referenceText: DisplayFormat.metricValue(reference, unit: unit),
            differenceText: sign + DisplayFormat.metricValue(difference, unit: unit),
            directionText: directionText(direction),
            direction: direction
        )
    }

    static func directionText(_ direction: MetricChangeDirection) -> String {
        switch direction {
        case .improved: "Better"
        case .worsened: "Worse"
        case .unchanged: "About the same"
        case .notApplicable: "Changed"
        }
    }
}
