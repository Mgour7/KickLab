import Foundation

enum KickEntryField: String, Equatable, Sendable {
    case distance
    case landingYardLine
    case hangTime

    var displayName: String {
        switch self {
        case .distance: "Distance"
        case .landingYardLine: "Landing yard line"
        case .hangTime: "Hang time"
        }
    }
}

/// A problem with the entered kick, worded for the person entering it.
enum KickEntryIssue: Equatable, Sendable {
    case invalidNumber(KickEntryField)
    case unsupportedKickType
    case validation(KickValidationIssue)

    var message: String {
        switch self {
        case .invalidNumber(let field): "\(field.displayName) must be a number."
        case .unsupportedKickType: "Choose a kick type."
        case .validation(let issue): issue.description
        }
    }
}

/// The fast manual kick-entry form. Text fields stay as text so partially typed numbers
/// never crash or silently become zero; `makeDraft()` turns the form into a validated
/// `KickDraft` (using the same `KickValidator` the services use).
struct KickEntryForm: Equatable, Sendable {
    var kickType: KickType = .fieldGoal
    /// Nil uses the session's default context (resolved by KickService).
    var context: KickContext?
    var timestamp: Date
    // Field goal / PAT
    var result: KickResult = .made
    var accuracy: AccuracyCoordinate?
    var hash: HashLocation = .center
    // Shared
    var distanceText: String = ""
    var hangTimeText: String = ""
    // Kickoff
    var touchback = false
    var outOfBounds = false
    var landingYardLineText: String = ""
    var landingZone: LandingZone?
    var notes: String = ""
    /// Build 20: kept through edits (the Personal Reference Kick is set from the kick screen,
    /// not this form; editing a kick must never clear it).
    var isReferenceKick = false
    /// Step 12F: optional entered details.
    var details = KickEnteredDetails()

    init(kickType: KickType = .fieldGoal, timestamp: Date = .now) {
        self.kickType = kickType
        self.timestamp = timestamp
        hash = kickType.usesGoalpostOutcome ? .center : .notApplicable
    }

    static let selectableKickTypes: [KickType] = KickType.selectableCases
    static let selectableResults: [KickResult] = [.made, .missedLeft, .missedRight, .short, .blocked, .missedOther]

    var showsResult: Bool { kickType.usesGoalpostOutcome }
    var showsAccuracy: Bool { kickType.usesGoalpostOutcome }
    var showsHash: Bool { kickType.usesGoalpostOutcome }
    var showsKickoffFields: Bool { kickType == .kickoff }
    var showsHangTime: Bool { kickType == .kickoff || kickType == .punt }

    /// Changes the kick type and resets fields that don't apply to it.
    mutating func setKickType(_ type: KickType) {
        guard type != kickType else { return }
        kickType = type
        if !type.usesGoalpostOutcome {
            accuracy = nil
            hash = .notApplicable
            result = .made
        } else if hash == .notApplicable {
            hash = .center
        }
        if type != .kickoff {
            touchback = false
            outOfBounds = false
            landingYardLineText = ""
            landingZone = nil
        }
        if !showsHangTime { hangTimeText = "" }
    }

    /// After saving, keeps the settings a kicker repeats rep after rep (type, context,
    /// hash and distance) and clears the outcome of the last kick.
    mutating func prepareNextKick(at date: Date = .now) {
        timestamp = date
        result = .made
        accuracy = nil
        touchback = false
        outOfBounds = false
        landingYardLineText = ""
        landingZone = nil
        hangTimeText = ""
        notes = ""
        // Ball, setup and conditions usually stay the same rep to rep; results don't.
        details.direction = nil
        details.puntInsideTwenty = nil
        details.puntResult = nil
    }

    struct ParsedNumber: Equatable, Sendable {
        var value: Double?
        var valid: Bool

        static let empty = ParsedNumber(value: nil, valid: true)
    }

    /// Parses a decimal number, accepting "," as the decimal separator. Empty → nil.
    static func parse(_ text: String) -> ParsedNumber {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",", with: ".")
        guard !trimmed.isEmpty else { return .empty }
        guard let value = Double(trimmed), value.isFinite else { return ParsedNumber(value: nil, valid: false) }
        return ParsedNumber(value: value, valid: true)
    }

    /// The draft, or the reasons it can't be saved.
    func makeDraft(id: UUID = UUID()) -> (draft: KickDraft?, issues: [KickEntryIssue]) {
        var issues: [KickEntryIssue] = []
        let distance = Self.parse(distanceText)
        if !distance.valid { issues.append(.invalidNumber(.distance)) }
        let hang: ParsedNumber = showsHangTime ? Self.parse(hangTimeText) : .empty
        if !hang.valid { issues.append(.invalidNumber(.hangTime)) }
        let landing: ParsedNumber = showsKickoffFields ? Self.parse(landingYardLineText) : .empty
        if !landing.valid { issues.append(.invalidNumber(.landingYardLine)) }
        guard issues.isEmpty else { return (nil, issues) }

        let outcome: KickOutcome
        switch kickType {
        case .fieldGoal, .pat:
            let goalpost = FieldGoalOutcome(
                result: result,
                distance: distance.value.map { MeasuredValue.manual($0) },
                accuracy: accuracy.map { MeasuredValue.manual($0) }
            )
            outcome = kickType == .fieldGoal ? .fieldGoal(goalpost) : .pat(goalpost)
        case .kickoff:
            var landingValue: MeasuredValue<KickoffLanding>?
            if landing.value != nil || landingZone != nil {
                landingValue = MeasuredValue.manual(KickoffLanding(yardLine: landing.value, zone: landingZone))
            }
            outcome = .kickoff(KickoffOutcome(
                distance: distance.value.map { MeasuredValue.manual($0) },
                landing: landingValue,
                touchback: touchback,
                outOfBounds: outOfBounds,
                hangTime: hang.value.map { MeasuredValue.manual($0) }
            ))
        case .punt:
            outcome = .punt(PuntOutcome(
                distance: distance.value.map { MeasuredValue.manual($0) },
                hangTime: hang.value.map { MeasuredValue.manual($0) }
            ))
        case .unknown:
            return (nil, [.unsupportedKickType])
        }

        let trimmedNotes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        let draft = KickDraft(
            id: id,
            timestamp: timestamp,
            outcome: outcome,
            context: context,
            playingLevelAtKick: nil,
            spotDistanceToTargetGoalLine: nil,
            hashLocation: showsHash ? hash : .notApplicable,
            isReferenceKick: isReferenceKick,
            notes: trimmedNotes.isEmpty ? nil : trimmedNotes,
            details: details.applicable(to: kickType)
        )
        let validation = KickValidator.validate(draft).map(KickEntryIssue.validation)
        return validation.isEmpty ? (draft, []) : (nil, validation)
    }

    /// A form pre-filled from a stored kick, for editing.
    static func editing(
        outcome: KickOutcome,
        context: KickContext,
        hash: HashLocation,
        notes: String?,
        timestamp: Date,
        details: KickEnteredDetails = KickEnteredDetails(),
        isReferenceKick: Bool = false
    ) -> KickEntryForm {
        var form = KickEntryForm(kickType: outcome.kickType, timestamp: timestamp)
        form.isReferenceKick = isReferenceKick
        form.context = context
        form.hash = hash
        form.notes = notes ?? ""
        form.details = details
        switch outcome {
        case .fieldGoal(let fg), .pat(let fg):
            form.result = fg.result == .unknown ? .made : fg.result
            form.distanceText = fg.distance.map { text($0.value) } ?? ""
            form.accuracy = fg.accuracy?.value
        case .kickoff(let ko):
            form.distanceText = ko.distance.map { text($0.value) } ?? ""
            form.touchback = ko.touchback ?? false
            form.outOfBounds = ko.outOfBounds ?? false
            form.landingYardLineText = ko.landing?.value.yardLine.map(text) ?? ""
            form.landingZone = ko.landing?.value.zone
            form.hangTimeText = ko.hangTime.map { text($0.value) } ?? ""
        case .punt(let punt):
            form.distanceText = punt.distance.map { text($0.value) } ?? ""
            form.hangTimeText = punt.hangTime.map { text($0.value) } ?? ""
        }
        return form
    }

    /// Compact text for a stored number ("40", "4.25").
    static func text(_ value: Double) -> String {
        value == value.rounded() ? DisplayFormat.number(value, digits: 0) : DisplayFormat.number(value, digits: 2)
    }
}

/// Maps taps on the goalpost pad to normalized goalpost coordinates and back.
/// The pad shows x from −2 to +2 (uprights at ±1) and y from −1 to +2 (crossbar at 0).
enum GoalpostPadGeometry {
    static let xRange: ClosedRange<Double> = -2...2
    static let yRange: ClosedRange<Double> = -1...2

    /// Pad point (top-left origin) → coordinate, rounded to 0.05.
    static func coordinate(x px: Double, y py: Double, width: Double, height: Double) -> AccuracyCoordinate {
        guard width > 0, height > 0 else { return AccuracyCoordinate(x: 0, y: nil) }
        let fx = min(1, max(0, px / width))
        let fy = min(1, max(0, py / height))
        let x = xRange.lowerBound + fx * (xRange.upperBound - xRange.lowerBound)
        let y = yRange.upperBound - fy * (yRange.upperBound - yRange.lowerBound)
        return AccuracyCoordinate(x: round05(x), y: round05(y))
    }

    /// Coordinate → pad point (top-left origin).
    static func point(for coordinate: AccuracyCoordinate, width: Double, height: Double) -> (x: Double, y: Double) {
        let fx = (coordinate.x - xRange.lowerBound) / (xRange.upperBound - xRange.lowerBound)
        let fy = (yRange.upperBound - (coordinate.y ?? 0.5)) / (yRange.upperBound - yRange.lowerBound)
        return (min(1, max(0, fx)) * width, min(1, max(0, fy)) * height)
    }

    /// Plain-language description of a crossing point.
    static func describe(_ coordinate: AccuracyCoordinate?) -> String {
        guard let c = coordinate else { return "Tap where the ball crossed (optional)." }
        let horizontal: String
        if c.x < -1 { horizontal = "Wide left" } else if c.x > 1 { horizontal = "Wide right" }
        else if abs(c.x) <= 1.0 / 3.0 { horizontal = "Down the middle" }
        else { horizontal = c.x < 0 ? "Inside, left side" : "Inside, right side" }
        guard let y = c.y else { return horizontal }
        return horizontal + (y < 0 ? ", below the crossbar" : ", over the crossbar")
    }

    private static func round05(_ v: Double) -> Double { (v * 20).rounded() / 20 }
}
