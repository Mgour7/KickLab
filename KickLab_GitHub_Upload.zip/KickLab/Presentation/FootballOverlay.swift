import Foundation

/// Step 12G (CV rebuild): what the Video Intelligence debugger draws for the football —
/// only what the detector actually reported on each examined frame. Nothing is
/// interpolated or extrapolated: frames without an observation show no ball box.
struct FootballOverlayModel: Equatable, Sendable {
    struct Box: Equatable, Sendable {
        var box: NormalizedBox
        var state: FootballFrameState
        var source: FootballObservationSource
        var score: Double?
        var appearance: Double?
        /// Plain label, e.g. "ball at rest · detected 0.83".
        var label: String
        /// Drawn dashed (obscured / tracked by appearance), solid otherwise.
        var dashed: Bool
    }

    var method: FootballAnalysisMethod
    var detectorName: String?
    var observations: [FootballFrameObservation]
    var rest: NormalizedBox?
    var lastStationaryTime: Double?
    var firstMovementTime: Double?
    var note: String

    init?(track: FootballTrack?) {
        guard let track else { return nil }
        method = track.method
        detectorName = track.detector?.name
        observations = track.observations.sorted { $0.time < $1.time }
        rest = track.rest
        lastStationaryTime = track.lastStationaryTime
        firstMovementTime = track.firstPersistentMovementTime
        note = track.note
    }

    /// The observation on the examined frame nearest `time`, within half a frame.
    func observation(at time: Double, frame: Double) -> FootballFrameObservation? {
        guard let o = observations.min(by: { abs($0.time - time) < abs($1.time - time) }), abs(o.time - time) <= frame / 2 + 1e-6 else { return nil }
        return o
    }

    /// The box to draw at `time` (nil when the ball wasn't observed on that frame).
    func box(at time: Double, frame: Double) -> Box? {
        guard let o = observation(at: time, frame: frame) else { return nil }
        let drawn: NormalizedBox?
        switch o.source {
        case .detected: drawn = o.box
        case .tracked: drawn = rest   // appearance matched at the resting spot
        case .interpolated, .unavailable: drawn = nil
        }
        guard let b = drawn else { return nil }
        let src = o.source == .detected ? (o.score.map { String(format: "detected %.2f", $0) } ?? "detected")
            : (o.appearance.map { String(format: "tracked by appearance %.2f", $0) } ?? "tracked")
        return Box(box: b, state: o.state, source: o.source, score: o.score, appearance: o.appearance,
                   label: "\(Self.title(o.state)) · \(src)", dashed: o.state == .obscured || o.source == .tracked)
    }

    /// Detected positions of the moving ball up to `time` — the observed path only.
    func path(upTo time: Double) -> [NormalizedPoint] {
        observations.filter { $0.time <= time + 1e-6 && $0.state == .moving && $0.source == .detected }.compactMap { $0.box?.center }
    }

    static func title(_ s: FootballFrameState) -> String {
        switch s {
        case .atRest: "ball at rest"
        case .obscured: "ball obscured"
        case .moving: "ball moving"
        case .otherFootball: "other football"
        case .notSeen: "not seen"
        }
    }

    /// The headline for the debugger.
    var summary: String {
        switch method {
        case .automaticFootballDetection: "Football found automatically\(detectorName.map { " (\($0))" } ?? ""). \(note)"
        case .userInitializedBallTracking: "Football located by you; movement measured from the frames. \(note)"
        case .ballUnavailable: "No football evidence: \(note)"
        }
    }
}
