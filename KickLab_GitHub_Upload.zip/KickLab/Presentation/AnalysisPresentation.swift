import Foundation

// MARK: - Plain records (built from stored models by the view-model layer)

struct StoredMetricRecord: Equatable, Sendable {
    var key: String
    var value: Double?
    var unit: MetricUnit
    var confidence: Double?
    var status: MeasurementStatus
    var phase: MechanicsPhase
    var definitionVersion: Int = 1
}

struct StoredCategoryRecord: Equatable, Sendable {
    var category: AnalysisCategory
    var score: Double?
    var confidence: Double?
    var status: MeasurementStatus
    var summary: String?
}


/// Everything the results screen needs about one stored analysis.
struct AnalysisRecord: Equatable, Sendable, Identifiable {
    var id: UUID
    var kickID: UUID?
    var kickType: KickType
    var kickDate: Date?
    var createdAt: Date
    var completedAt: Date?
    var status: ProcessingStatus
    var isCurrent: Bool
    var overallScore: Double?
    var confidence: Double?
    var failureReason: String?
    var engineVersion: String
    var metrics: [StoredMetricRecord]
    var categories: [StoredCategoryRecord]
    var observations: [StoredObservationRecord]

    /// Completion time, else creation time.
    var date: Date { completedAt ?? createdAt }
}

// MARK: - Presentation

struct MetricRowPresentation: Equatable, Sendable, Identifiable {
    var id: String { key.rawValue }
    var key: KickMetricKey
    var name: String
    var explanation: String
    var valueText: String
    var value: Double?
    var unit: MetricUnit
    var status: MeasurementStatus
    var statusText: String
    var confidence: Double?
    var confidenceText: String
    var category: AnalysisCategory
    /// Step 12E: where the value comes from ("Measured from video", "Estimated from
    /// video", "Uses the contact you chose", "Unavailable").
    var provenanceText: String = ""

    var isAvailable: Bool { status != .unavailable && value != nil }
}

struct CategoryCardPresentation: Equatable, Sendable, Identifiable {
    var id: String { category.rawValue }
    var category: AnalysisCategory
    var title: String
    var score: Double?
    var scoreText: String
    var grade: ScoreGrade
    var confidence: Double?
    var confidenceText: String
    var summary: String?
    /// Up to three measured metrics, most confident first.
    var topMetrics: [MetricRowPresentation]
    /// Metrics that could not be measured this time (shown neutrally, not as failures).
    var unavailableMetricNames: [String]

    /// Step 12C: the grade word, marked tentative when confidence is low.
    var gradeText: String { grade.label(confidence: confidence) }

    var isScored: Bool { score != nil }
}

struct CoachingItemPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var category: AnalysisCategory
    var categoryTitle: String
    var observed: String
    var whyItMatters: String?
    var cue: String?
    var severity: CoachingSeverity?
    var severityText: String?
    var confidence: Double?
    var confidenceText: String
    var priority: Int
}

struct AnalysisHeaderPresentation: Equatable, Sendable {
    var kickTypeText: String
    var date: Date
    var overallScore: Double?
    var overallScoreText: String
    var grade: ScoreGrade
    var confidence: Double?
    var confidenceText: String
    var isCurrent: Bool
    var statusText: String

    /// Step 12C: the grade word, marked tentative when confidence is low.
    var gradeText: String { grade.label(confidence: confidence) }
    /// Step 12D: fully automatic, partial, user-assisted or needs better footage.
    var mode: AnalysisMode = .automatic
    /// Step 12E: what the analysis produced (nil while running or cancelled).
    var outcome: AnalysisOutcome? = nil
}

/// Step 12D: what kind of result this is, always shown with the score.
enum AnalysisMode: String, Equatable, Sendable {
    /// Every scored area was measured automatically.
    case automatic
    /// Automatic, but some areas couldn't be scored.
    case partial
    /// The user supplied the contact frame or the kick interval.
    case userAssisted
    /// The analysis couldn't produce results from this recording.
    case needsBetterFootage

    var title: String {
        switch self {
        case .automatic: "Automatic analysis"
        case .partial: "Partial automatic analysis"
        case .userAssisted: "User-assisted analysis"
        case .needsBetterFootage: "Needs better footage"
        }
    }

    var explanation: String {
        switch self {
        case .automatic: "Every scored area was measured automatically."
        case .partial: "Some areas couldn't be measured; their scores are missing, not low."
        case .userAssisted: "You chose part of the kick (such as the contact frame); everything else was measured around your choice. It isn't counted as automatic accuracy."
        case .needsBetterFootage: "This recording couldn't be analyzed. See the guidance for filming the next kick."
        }
    }

    static func of(_ record: AnalysisRecord, categories: [CategoryCardPresentation]) -> AnalysisMode {
        if AnalysisAssistanceLabel.isAssisted(record.engineVersion) { return .userAssisted }
        if record.status == .failed { return .needsBetterFootage }
        return categories.contains { $0.score == nil } ? .partial : .automatic
    }
}

struct AnalysisResultsPresentation: Equatable, Sendable {
    var header: AnalysisHeaderPresentation
    var categories: [CategoryCardPresentation]
    var metrics: [MetricRowPresentation]
    var priorities: [CoachingItemPresentation]
    var strengths: [CoachingItemPresentation]
    /// Standing caveats shown with the results.
    var notes: [String]
    /// Set when the analysis did not complete.
    var problem: String?

    var hasMechanics: Bool { metrics.contains(where: \.isAvailable) }

    /// Step 12C: what "no corrections" means for THIS result. With areas unmeasured or
    /// measured with low confidence it is not a clean bill of health.
    var noCorrectionsDetail: String {
        let scored = categories.filter { $0.score != nil }
        let confident = scored.filter { [.high, .medium].contains(ConfidenceLevel($0.confidence)) }
        if scored.count == categories.count, confident.count == scored.count {
            return "KickLab only suggests a change when it measured the evidence confidently."
        }
        return "Only \(scored.count) of \(categories.count) areas were measured\(confident.count < scored.count ? ", some with low confidence" : ""). Unmeasured areas may still need work — this is not a clean bill of health."
    }
}

enum AnalysisPresentationBuilder {
    static let contactNote = "Contact time is estimated from body motion; KickLab does not track the ball yet."
    static let unitNote = "Sizes and speeds are measured in body lengths (your torso length in the video), not yards or mph."

    static func make(_ record: AnalysisRecord) -> AnalysisResultsPresentation {
        let metrics = metricRows(record.metrics, userAssisted: AnalysisAssistanceLabel.isAssisted(record.engineVersion))
        let byCategory = Dictionary(grouping: metrics, by: \.category)
        let categories = KickMetricCatalog.scoredCategories.map { category in
            card(category, record: record.categories.first { $0.category == category }, metrics: byCategory[category] ?? [])
        }
        let coaching = coachingItems(record.observations)
        let header = AnalysisHeaderPresentation(
            kickTypeText: record.kickType.displayName,
            date: record.date,
            overallScore: record.overallScore,
            overallScoreText: DisplayFormat.score(record.overallScore),
            grade: ScoreGrade(score: record.overallScore),
            confidence: record.confidence,
            confidenceText: DisplayFormat.confidence(record.confidence),
            isCurrent: record.isCurrent,
            statusText: statusText(record),
            mode: AnalysisMode.of(record, categories: categories),
            outcome: AnalysisOutcome.of(status: record.status, failureReason: record.failureReason,
                                        scoredCategoryCount: categories.filter { $0.score != nil }.count,
                                        availableMetricCount: metrics.filter(\.isAvailable).count)
        )
        var problem: String?
        if record.status == .failed {
            problem = record.failureReason ?? "This analysis didn't finish."
        } else if record.status == .cancelled {
            problem = "This analysis was cancelled."
        } else if record.status != .completed {
            problem = "This analysis is still in progress."
        }
        return AnalysisResultsPresentation(
            header: header,
            categories: categories,
            metrics: metrics,
            priorities: coaching.priorities,
            strengths: coaching.strengths,
            notes: [partialNote(categories: categories, overallScore: record.overallScore), contactNote, unitNote].compactMap { $0 },
            problem: problem
        )
    }

    /// Step 12B: when some areas weren't scored, say so plainly, so a partial result is
    /// never read as "the rest was fine". Nil when every area was scored.
    static func partialNote(categories: [CategoryCardPresentation], overallScore: Double?) -> String? {
        let scored = categories.filter { $0.score != nil }
        let unscored = categories.filter { $0.score == nil }
        guard !unscored.isEmpty, !scored.isEmpty else { return nil }
        let names = unscored.map(\.title).joined(separator: ", ")
        if overallScore != nil {
            return "Partial result: the overall score averages only the \(scored.count) of \(categories.count) areas that could be scored. Not scored this time: \(names). Unscored areas are not rated good or bad."
        }
        return "Partial result: only \(scored.count) of \(categories.count) areas could be scored, not enough for an overall score. Not scored this time: \(names)."
    }

    static func statusText(_ record: AnalysisRecord) -> String {
        switch record.status {
        case .completed: record.isCurrent ? "Current analysis" : "Earlier analysis"
        case .failed: "Didn't finish"
        case .cancelled: "Cancelled"
        case .queued, .processing: "In progress"
        case .unknown: "Unknown"
        }
    }

    /// Known metrics only, in catalog order. Metrics from other engines are not shown
    /// (their internal identifiers are never displayed).
    static func metricRows(_ records: [StoredMetricRecord], userAssisted: Bool = false) -> [MetricRowPresentation] {
        KickMetricKey.allCases.compactMap { key in
            guard let record = records.first(where: { $0.key == key.rawValue }) else { return nil }
            let definition = key.definition
            let available = record.status != .unavailable && record.value != nil
            return MetricRowPresentation(
                key: key,
                name: definition.displayName,
                explanation: definition.explanation,
                valueText: available ? DisplayFormat.metricValue(record.value, unit: record.unit) : "Not measured",
                value: available ? record.value : nil,
                unit: record.unit,
                status: available ? record.status : .unavailable,
                statusText: DisplayFormat.statusLabel(available ? record.status : .unavailable),
                confidence: available ? record.confidence : nil,
                confidenceText: available ? DisplayFormat.confidence(record.confidence) : "Not enough data",
                category: definition.category,
                provenanceText: provenance(available: available, status: record.status, dependsOnContact: definition.dependsOnContact,
                                           userAssisted: userAssisted)
            )
        }
    }

    /// Step 12E: the evidence origin of a stored metric value.
    static func provenance(available: Bool, status: MeasurementStatus, dependsOnContact: Bool, userAssisted: Bool) -> String {
        guard available else { return "Unavailable" }
        if userAssisted && dependsOnContact { return "Uses the contact you chose" }
        return status == .measured ? "Measured from video" : "Estimated from video"
    }

    static func card(_ category: AnalysisCategory, record: StoredCategoryRecord?, metrics: [MetricRowPresentation]) -> CategoryCardPresentation {
        let available = metrics.filter(\.isAvailable)
        let top = available.sorted { a, b in
            let ca = a.confidence ?? 0
            let cb = b.confidence ?? 0
            if ca != cb { return ca > cb }
            return a.key.rawValue < b.key.rawValue
        }
        let score = record?.status == .unavailable ? nil : record?.score
        return CategoryCardPresentation(
            category: category,
            title: category.presentationTitle,
            score: score,
            scoreText: DisplayFormat.score(score),
            grade: ScoreGrade(score: score),
            confidence: score == nil ? nil : record?.confidence,
            confidenceText: score == nil ? "Not scored this time" : DisplayFormat.confidence(record?.confidence),
            summary: record?.summary,
            topMetrics: Array(top.prefix(3)),
            // Step 12E: the informational frontal-plane metrics exist only for views from
            // behind or in front; not listing them as missing keeps side-view cards clean.
            unavailableMetricNames: metrics.filter { !$0.isAvailable && !PerspectiveMetricSupport.frontalPlaneMetrics.contains($0.key) }.map(\.name)
        )
    }

    /// IMPROVE observations (with their CUEs) as priorities, KEEPs as strengths, each in
    /// stored priority order.
    static func coachingItems(_ observations: [StoredObservationRecord]) -> (priorities: [CoachingItemPresentation], strengths: [CoachingItemPresentation]) {
        let cues = observations.filter { $0.kind == .cue }
        func item(_ o: StoredObservationRecord) -> CoachingItemPresentation {
            let parts = splitMessage(o.message)
            let cue = o.kind == .improve ? cues.first { $0.relatedObservationID == o.id }?.message : nil
            return CoachingItemPresentation(
                id: o.id,
                category: o.category,
                categoryTitle: o.category.presentationTitle,
                observed: parts.observed,
                whyItMatters: parts.why,
                cue: cue,
                severity: o.kind == .improve ? o.severity : nil,
                severityText: o.kind == .improve ? o.severity.map(severityText) : nil,
                confidence: o.confidence,
                confidenceText: DisplayFormat.confidence(o.confidence),
                priority: o.priority
            )
        }
        let order: (StoredObservationRecord, StoredObservationRecord) -> Bool = { a, b in
            if a.priority != b.priority { return a.priority < b.priority }
            return (a.ruleKey ?? "") < (b.ruleKey ?? "")
        }
        let priorities = observations.filter { $0.kind == .improve }.sorted(by: order).map(item)
        let strengths = observations.filter { $0.kind == .keep }.sorted(by: order).map(item)
        return (priorities, strengths)
    }

    static func severityText(_ severity: CoachingSeverity) -> String {
        switch severity {
        case .high: "High priority"
        case .moderate: "Medium priority"
        case .low: "Low priority"
        case .info: "For your information"
        }
    }

    /// Engine messages are "<what was observed>. <why it matters>". Split at the first
    /// sentence break (". " — decimal points have no following space).
    static func splitMessage(_ message: String) -> (observed: String, why: String?) {
        guard let range = message.range(of: ". ") else { return (message, nil) }
        let observed = String(message[..<range.lowerBound]) + "."
        let why = String(message[range.upperBound...]).trimmingCharacters(in: .whitespaces)
        return (observed, why.isEmpty ? nil : why)
    }
}
