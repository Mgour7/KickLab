import Foundation

// MARK: - Plain records (built from stored models by the view-model layer)

struct StoredMetricRecord: Equatable, Sendable {
    var key: String
    var value: Double?
    var unit: MetricUnit
    var confidence: Double?
    var status: MeasurementStatus
    var phase: MechanicsPhase
    var definitionVersion: Int = 1
}

struct StoredCategoryRecord: Equatable, Sendable {
    var category: AnalysisCategory
    var score: Double?
    var confidence: Double?
    var status: MeasurementStatus
    var summary: String?
}


/// Everything the results screen needs about one stored analysis.
struct AnalysisRecord: Equatable, Sendable, Identifiable {
    var id: UUID
    var kickID: UUID?
    var kickType: KickType
    var kickDate: Date?
    var createdAt: Date
    var completedAt: Date?
    var status: ProcessingStatus
    var isCurrent: Bool
    var overallScore: Double?
    var confidence: Double?
    var failureReason: String?
    var engineVersion: String
    var metrics: [StoredMetricRecord]
    var categories: [StoredCategoryRecord]
    var observations: [StoredObservationRecord]

    /// Completion time, else creation time.
    var date: Date { completedAt ?? createdAt }
}

// MARK: - Presentation

struct MetricRowPresentation: Equatable, Sendable, Identifiable {
    var id: String { key.rawValue }
    var key: KickMetricKey
    var name: String
    var explanation: String
    var valueText: String
    var value: Double?
    var unit: MetricUnit
    var status: MeasurementStatus
    var statusText: String
    var confidence: Double?
    var confidenceText: String
    var category: AnalysisCategory

    var isAvailable: Bool { status != .unavailable && value != nil }
}

struct CategoryCardPresentation: Equatable, Sendable, Identifiable {
    var id: String { category.rawValue }
    var category: AnalysisCategory
    var title: String
    var score: Double?
    var scoreText: String
    var grade: ScoreGrade
    var confidence: Double?
    var confidenceText: String
    var summary: String?
    /// Up to three measured metrics, most confident first.
    var topMetrics: [MetricRowPresentation]
    /// Metrics that could not be measured this time (shown neutrally, not as failures).
    var unavailableMetricNames: [String]

    var isScored: Bool { score != nil }
}

struct CoachingItemPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var category: AnalysisCategory
    var categoryTitle: String
    var observed: String
    var whyItMatters: String?
    var cue: String?
    var severity: CoachingSeverity?
    var severityText: String?
    var confidence: Double?
    var confidenceText: String
    var priority: Int
}

struct AnalysisHeaderPresentation: Equatable, Sendable {
    var kickTypeText: String
    var date: Date
    var overallScore: Double?
    var overallScoreText: String
    var grade: ScoreGrade
    var confidence: Double?
    var confidenceText: String
    var isCurrent: Bool
    var statusText: String
}

struct AnalysisResultsPresentation: Equatable, Sendable {
    var header: AnalysisHeaderPresentation
    var categories: [CategoryCardPresentation]
    var metrics: [MetricRowPresentation]
    var priorities: [CoachingItemPresentation]
    var strengths: [CoachingItemPresentation]
    /// Standing caveats shown with the results.
    var notes: [String]
    /// Set when the analysis did not complete.
    var problem: String?

    var hasMechanics: Bool { metrics.contains(where: \.isAvailable) }
}

enum AnalysisPresentationBuilder {
    static let contactNote = "Contact time is estimated from body motion; KickLab does not track the ball yet."
    static let unitNote = "Sizes and speeds are measured in body lengths (your torso length in the video), not yards or mph."

    static func make(_ record: AnalysisRecord) -> AnalysisResultsPresentation {
        let metrics = metricRows(record.metrics)
        let byCategory = Dictionary(grouping: metrics, by: \.category)
        let categories = KickMetricCatalog.scoredCategories.map { category in
            card(category, record: record.categories.first { $0.category == category }, metrics: byCategory[category] ?? [])
        }
        let coaching = coachingItems(record.observations)
        let header = AnalysisHeaderPresentation(
            kickTypeText: record.kickType.displayName,
            date: record.date,
            overallScore: record.overallScore,
            overallScoreText: DisplayFormat.score(record.overallScore),
            grade: ScoreGrade(score: record.overallScore),
            confidence: record.confidence,
            confidenceText: DisplayFormat.confidence(record.confidence),
            isCurrent: record.isCurrent,
            statusText: statusText(record)
        )
        var problem: String?
        if record.status == .failed {
            problem = record.failureReason ?? "This analysis didn't finish."
        } else if record.status == .cancelled {
            problem = "This analysis was cancelled."
        } else if record.status != .completed {
            problem = "This analysis is still in progress."
        }
        return AnalysisResultsPresentation(
            header: header,
            categories: categories,
            metrics: metrics,
            priorities: coaching.priorities,
            strengths: coaching.strengths,
            notes: [contactNote, unitNote],
            problem: problem
        )
    }

    static func statusText(_ record: AnalysisRecord) -> String {
        switch record.status {
        case .completed: record.isCurrent ? "Current analysis" : "Earlier analysis"
        case .failed: "Didn't finish"
        case .cancelled: "Cancelled"
        case .queued, .processing: "In progress"
        case .unknown: "Unknown"
        }
    }

    /// Known metrics only, in catalog order. Metrics from other engines are not shown
    /// (their internal identifiers are never displayed).
    static func metricRows(_ records: [StoredMetricRecord]) -> [MetricRowPresentation] {
        KickMetricKey.allCases.compactMap { key in
            guard let record = records.first(where: { $0.key == key.rawValue }) else { return nil }
            let definition = key.definition
            let available = record.status != .unavailable && record.value != nil
            return MetricRowPresentation(
                key: key,
                name: definition.displayName,
                explanation: definition.explanation,
                valueText: available ? DisplayFormat.metricValue(record.value, unit: record.unit) : "Not measured",
                value: available ? record.value : nil,
                unit: record.unit,
                status: available ? record.status : .unavailable,
                statusText: DisplayFormat.statusLabel(available ? record.status : .unavailable),
                confidence: available ? record.confidence : nil,
                confidenceText: available ? DisplayFormat.confidence(record.confidence) : "Not enough data",
                category: definition.category
            )
        }
    }

    static func card(_ category: AnalysisCategory, record: StoredCategoryRecord?, metrics: [MetricRowPresentation]) -> CategoryCardPresentation {
        let available = metrics.filter(\.isAvailable)
        let top = available.sorted { a, b in
            let ca = a.confidence ?? 0
            let cb = b.confidence ?? 0
            if ca != cb { return ca > cb }
            return a.key.rawValue < b.key.rawValue
        }
        let score = record?.status == .unavailable ? nil : record?.score
        return CategoryCardPresentation(
            category: category,
            title: category.presentationTitle,
            score: score,
            scoreText: DisplayFormat.score(score),
            grade: ScoreGrade(score: score),
            confidence: score == nil ? nil : record?.confidence,
            confidenceText: score == nil ? "Not scored this time" : DisplayFormat.confidence(record?.confidence),
            summary: record?.summary,
            topMetrics: Array(top.prefix(3)),
            unavailableMetricNames: metrics.filter { !$0.isAvailable }.map(\.name)
        )
    }

    /// IMPROVE observations (with their CUEs) as priorities, KEEPs as strengths, each in
    /// stored priority order.
    static func coachingItems(_ observations: [StoredObservationRecord]) -> (priorities: [CoachingItemPresentation], strengths: [CoachingItemPresentation]) {
        let cues = observations.filter { $0.kind == .cue }
        func item(_ o: StoredObservationRecord) -> CoachingItemPresentation {
            let parts = splitMessage(o.message)
            let cue = o.kind == .improve ? cues.first { $0.relatedObservationID == o.id }?.message : nil
            return CoachingItemPresentation(
                id: o.id,
                category: o.category,
                categoryTitle: o.category.presentationTitle,
                observed: parts.observed,
                whyItMatters: parts.why,
                cue: cue,
                severity: o.kind == .improve ? o.severity : nil,
                severityText: o.kind == .improve ? o.severity.map(severityText) : nil,
                confidence: o.confidence,
                confidenceText: DisplayFormat.confidence(o.confidence),
                priority: o.priority
            )
        }
        let order: (StoredObservationRecord, StoredObservationRecord) -> Bool = { a, b in
            if a.priority != b.priority { return a.priority < b.priority }
            return (a.ruleKey ?? "") < (b.ruleKey ?? "")
        }
        let priorities = observations.filter { $0.kind == .improve }.sorted(by: order).map(item)
        let strengths = observations.filter { $0.kind == .keep }.sorted(by: order).map(item)
        return (priorities, strengths)
    }

    static func severityText(_ severity: CoachingSeverity) -> String {
        switch severity {
        case .high: "High priority"
        case .moderate: "Medium priority"
        case .low: "Low priority"
        case .info: "For your information"
        }
    }

    /// Engine messages are "<what was observed>. <why it matters>". Split at the first
    /// sentence break (". " — decimal points have no following space).
    static func splitMessage(_ message: String) -> (observed: String, why: String?) {
        guard let range = message.range(of: ". ") else { return (message, nil) }
        let observed = String(message[..<range.lowerBound]) + "."
        let why = String(message[range.upperBound...]).trimmingCharacters(in: .whitespaces)
        return (observed, why.isEmpty ? nil : why)
    }
}
