import Foundation

// Build 21 — Session Review: counts, results and descriptive session analytics, from the
// session manifest plus the Kick records its candidates became. Results are only what the
// athlete entered; mechanics only from reliable stored measurements; nothing is inferred
// about fatigue or about why a kick was made or missed.

struct SessionReviewSummary: Equatable, Sendable {
    var candidates: Int
    var confirmed: Int
    var probable: Int
    var needsReview: Int
    var rejected: Int
    var analyzed: Int
    var failed: Int
    var waiting: Int
    /// Physical kicks: confirmed + probable, a camera pair counted once.
    var attempts: Int
    var resultsEntered: Int
    var made: Int
    var missedLeft: Int
    var missedRight: Int
    var short: Int
    var otherMisses: Int
    var makeRate: RateSummary
    var byDistance: [BandRate]
    var byHash: [(hash: HashLocation, rate: RateSummary)]
    var withoutDistance: Int

    static func == (a: Self, b: Self) -> Bool {
        a.candidates == b.candidates && a.attempts == b.attempts && a.made == b.made && a.resultsEntered == b.resultsEntered
            && a.byDistance == b.byDistance && a.byHash.map(\.hash) == b.byHash.map(\.hash) && a.byHash.map(\.rate) == b.byHash.map(\.rate)
            && a.confirmed == b.confirmed && a.probable == b.probable && a.needsReview == b.needsReview && a.rejected == b.rejected
            && a.analyzed == b.analyzed && a.failed == b.failed && a.waiting == b.waiting && a.short == b.short
            && a.missedLeft == b.missedLeft && a.missedRight == b.missedRight && a.otherMisses == b.otherMisses
            && a.makeRate == b.makeRate && a.withoutDistance == b.withoutDistance
    }

    /// - Parameter results: the entered result of each attempt's Kick (by candidate ID).
    static func make(_ m: TrainingSessionManifest, results: [UUID: KickStatRecord]) -> SessionReviewSummary {
        let all = m.candidates
        let active = all.filter(\.status.isActive)
        let attempts = m.attempts
        let records = attempts.compactMap { results[$0.id] }
        let decided = records.filter { ($0.result ?? .unknown) != .unknown }
        func count(_ r: KickResult) -> Int { decided.filter { $0.result == r }.count }
        let goal = GoalpostSummary.make(records.map { r in var x = r; x.kickType = .fieldGoal; return x }, type: .fieldGoal)
        let hashes = HashLocation.allCases.compactMap { h -> (HashLocation, RateSummary)? in
            let inHash = decided.filter { $0.hashLocation == h }
            guard !inHash.isEmpty else { return nil }
            return (h, RateSummary(successes: inHash.filter { $0.result == .made }.count, attempts: inHash.count))
        }
        return SessionReviewSummary(
            candidates: active.count + all.filter { !$0.status.isActive }.count,
            confirmed: all.filter { $0.status == .confirmed }.count,
            probable: all.filter { $0.status == .probable }.count,
            needsReview: all.filter { $0.status == .needsReview }.count,
            rejected: all.filter { !$0.status.isActive }.count,
            analyzed: active.filter { $0.analysis.status == .done }.count,
            failed: active.filter { $0.analysis.status == .failed }.count,
            waiting: active.filter { $0.analysis.status == .queued || $0.analysis.status == .running }.count,
            attempts: attempts.count,
            resultsEntered: decided.count,
            made: count(.made), missedLeft: count(.missedLeft), missedRight: count(.missedRight), short: count(.short),
            otherMisses: count(.blocked) + count(.missedOther),
            makeRate: RateSummary(successes: count(.made), attempts: decided.count),
            byDistance: goal?.byDistance ?? [],
            byHash: hashes,
            withoutDistance: decided.filter { $0.distanceYards == nil }.count)
    }

    var countsText: String {
        "\(attempts) kick\(attempts == 1 ? "" : "s") · \(confirmed) confirmed · \(probable) probable · \(needsReview) to review"
    }
}

/// One measurement across the session's kicks (same camera view), in kick order.
struct SessionMetricTrend: Equatable, Sendable, Identifiable {
    var key: KickMetricKey
    var name: String
    var values: [Double]
    var mean: Double
    var spread: Double?
    var range: Double?
    var level: RepeatabilityLevel?
    var firstHalfMean: Double?
    var secondHalfMean: Double?
    var halvesCount: (Int, Int)
    /// Set only when the halves differ beyond the measurement's meaningful change AND
    /// twice the standard error of the difference.
    var halvesText: String?
    var id: String { key.rawValue }

    static func == (a: Self, b: Self) -> Bool {
        a.key == b.key && a.values == b.values && a.halvesText == b.halvesText && a.level == b.level
    }
}

enum SessionAnalytics {
    /// Each half needs at least this many values for a first-half/second-half description.
    static let minimumPerHalf = 3

    /// Descriptive trends over the session's attempts, one camera view at a time.
    /// `entries` are the attempts' analyses in kick order (one per physical kick).
    static func trends(_ entries: [RankingEntry], view: ComparableView) -> [SessionMetricTrend] {
        let eligible = entries.filter { $0.view == view && $0.completed && $0.recording.eligibleForMeasurementHistory }
        var out: [SessionMetricTrend] = []
        for key in ConsistencyModel.keys(for: view) {
            let values = eligible.compactMap { $0.metric(key) }
            guard values.count >= 2 else { continue }
            let precision = MeasurementPrecision.of(key)
            let mean = values.reduce(0, +) / Double(values.count)
            var t = SessionMetricTrend(key: key, name: key.definition.displayName, values: values, mean: mean, halvesCount: (0, 0))
            if values.count >= ConsistencyModel.minimumForSpread {
                let s = PersonalRanking.standardDeviation(values)
                t.spread = s
                t.range = (values.max() ?? 0) - (values.min() ?? 0)
                t.level = RepeatabilityLevel.of(spread: s, precision: precision)
            }
            let half = values.count / 2
            let first = Array(values.prefix(half)), second = Array(values.suffix(values.count - half))
            t.halvesCount = (first.count, second.count)
            if first.count >= minimumPerHalf, second.count >= minimumPerHalf {
                let m1 = first.reduce(0, +) / Double(first.count), m2 = second.reduce(0, +) / Double(second.count)
                t.firstHalfMean = m1
                t.secondHalfMean = m2
                let s1 = PersonalRanking.standardDeviation(first), s2 = PersonalRanking.standardDeviation(second)
                let se = (s1 * s1 / Double(first.count) + s2 * s2 / Double(second.count)).squareRoot()
                let d = m2 - m1
                if abs(d) > precision.meaningfulChange, abs(d) > 2 * se {
                    let unit = key.definition.unit
                    t.halvesText = "\(key.definition.displayName) was \(d > 0 ? "higher" : "lower") in the second half (\(DisplayFormat.metricValue(m2, unit: unit)) vs \(DisplayFormat.metricValue(m1, unit: unit)), \(second.count) and \(first.count) kicks). This describes the session; it doesn't show fatigue or a cause."
                }
            }
            out.append(t)
        }
        return out
    }
}
