import Foundation

// Build 21 — Session Review: counts, results and descriptive session analytics, from the
// session manifest plus the Kick records its candidates became. Results are only what the
// athlete entered; mechanics only from reliable stored measurements; nothing is inferred
// about fatigue or about why a kick was made or missed.

struct SessionReviewSummary: Equatable, Sendable {
    var candidates: Int
    var confirmed: Int
    var probable: Int
    var needsReview: Int
    var rejected: Int
    var analyzed: Int
    var failed: Int
    var waiting: Int
    /// Physical kicks: confirmed + probable, a camera pair counted once.
    var attempts: Int
    var resultsEntered: Int
    var made: Int
    var missedLeft: Int
    var missedRight: Int
    var short: Int
    var otherMisses: Int
    var makeRate: RateSummary
    var byDistance: [BandRate]
    var byHash: [(hash: HashLocation, rate: RateSummary)]
    var withoutDistance: Int

    static func == (a: Self, b: Self) -> Bool {
        a.candidates == b.candidates && a.attempts == b.attempts && a.made == b.made && a.resultsEntered == b.resultsEntered
            && a.byDistance == b.byDistance && a.byHash.map(\.hash) == b.byHash.map(\.hash) && a.byHash.map(\.rate) == b.byHash.map(\.rate)
            && a.confirmed == b.confirmed && a.probable == b.probable && a.needsReview == b.needsReview && a.rejected == b.rejected
            && a.analyzed == b.analyzed && a.failed == b.failed && a.waiting == b.waiting && a.short == b.short
            && a.missedLeft == b.missedLeft && a.missedRight == b.missedRight && a.otherMisses == b.otherMisses
            && a.makeRate == b.makeRate && a.withoutDistance == b.withoutDistance
    }

    /// - Parameter results: the entered result of each attempt's Kick (by candidate ID).
    static func make(_ m: TrainingSessionManifest, results: [UUID: KickStatRecord]) -> SessionReviewSummary {
        let all = m.candidates
        let active = all.filter(\.status.isActive)
        let attempts = m.attempts
        let records = attempts.compactMap { results[$0.id] }
        let decided = records.filter { ($0.result ?? .unknown) != .unknown }
        func count(_ r: KickResult) -> Int { decided.filter { $0.result == r }.count }
        let goal = GoalpostSummary.make(records.map { r in var x = r; x.kickType = .fieldGoal; return x }, type: .fieldGoal)
        let hashes = HashLocation.allCases.compactMap { h -> (HashLocation, RateSummary)? in
            let inHash = decided.filter { $0.hashLocation == h }
            guard !inHash.isEmpty else { return nil }
            return (h, RateSummary(successes: inHash.filter { $0.result == .made }.count, attempts: inHash.count))
        }
        return SessionReviewSummary(
            candidates: active.count + all.filter { !$0.status.isActive }.count,
            confirmed: all.filter { $0.status == .confirmed }.count,
            probable: all.filter { $0.status == .probable }.count,
            needsReview: all.filter { $0.status == .needsReview }.count,
            rejected: all.filter { !$0.status.isActive }.count,
            analyzed: active.filter { $0.analysis.status == .done }.count,
            failed: active.filter { $0.analysis.status == .failed }.count,
            waiting: active.filter { $0.analysis.status == .queued || $0.analysis.status == .running }.count,
            attempts: attempts.count,
            resultsEntered: decided.count,
            made: count(.made), missedLeft: count(.missedLeft), missedRight: count(.missedRight), short: count(.short),
            otherMisses: count(.blocked) + count(.missedOther),
            makeRate: RateSummary(successes: count(.made), attempts: decided.count),
            byDistance: goal?.byDistance ?? [],
            byHash: hashes,
            withoutDistance: decided.filter { $0.distanceYards == nil }.count)
    }

    var countsText: String {
        "\(attempts) kick\(attempts == 1 ? "" : "s") · \(confirmed) confirmed · \(probable) probable · \(needsReview) to review"
    }
}

/// One measurement across the session's kicks (same camera view), in kick order.
struct SessionMetricTrend: Equatable, Sendable, Identifiable {
    var key: KickMetricKey
    var name: String
    var values: [Double]
    var mean: Double
    var spread: Double?
    var range: Double?
    var level: RepeatabilityLevel?
    var firstHalfMean: Double?
    var secondHalfMean: Double?
    var halvesCount: (Int, Int)
    /// Set only when the halves differ beyond the measurement's meaningful change AND
    /// twice the standard error of the difference.
    var halvesText: String?
    var id: String { key.rawValue }

    static func == (a: Self, b: Self) -> Bool {
        a.key == b.key && a.values == b.values && a.halvesText == b.halvesText && a.level == b.level
    }
}

enum SessionAnalytics {
    /// Each half needs at least this many values for a first-half/second-half description.
    static let minimumPerHalf = 3

    /// Descriptive trends over the session's attempts, one camera view at a time.
    /// `entries` are the attempts' analyses in kick order (one per physical kick).
    static func trends(_ entries: [RankingEntry], view: ComparableView) -> [SessionMetricTrend] {
        let eligible = entries.filter { $0.view == view && $0.completed && $0.recording.eligibleForMeasurementHistory }
        var out: [SessionMetricTrend] = []
        for key in ConsistencyModel.keys(for: view) {
            let values = eligible.compactMap { $0.metric(key) }
            guard values.count >= 2 else { continue }
            let precision = MeasurementPrecision.of(key)
            let mean = values.reduce(0, +) / Double(values.count)
            var t = SessionMetricTrend(key: key, name: key.definition.displayName, values: values, mean: mean, halvesCount: (0, 0))
            if values.count >= ConsistencyModel.minimumForSpread {
                let s = PersonalRanking.standardDeviation(values)
                t.spread = s
                t.range = (values.max() ?? 0) - (values.min() ?? 0)
                t.level = RepeatabilityLevel.of(spread: s, precision: precision)
            }
            let half = values.count / 2
            let first = Array(values.prefix(half)), second = Array(values.suffix(values.count - half))
            t.halvesCount = (first.count, second.count)
            if first.count >= minimumPerHalf, second.count >= minimumPerHalf {
                let m1 = first.reduce(0, +) / Double(first.count), m2 = second.reduce(0, +) / Double(second.count)
                t.firstHalfMean = m1
                t.secondHalfMean = m2
                let s1 = PersonalRanking.standardDeviation(first), s2 = PersonalRanking.standardDeviation(second)
                let se = (s1 * s1 / Double(first.count) + s2 * s2 / Double(second.count)).squareRoot()
                let d = m2 - m1
                if abs(d) > precision.meaningfulChange, abs(d) > 2 * se {
                    let unit = key.definition.unit
                    t.halvesText = "\(key.definition.displayName) was \(d > 0 ? "higher" : "lower") in the second half (\(DisplayFormat.metricValue(m2, unit: unit)) vs \(DisplayFormat.metricValue(m1, unit: unit)), \(second.count) and \(first.count) kicks). This describes the session; it doesn't show fatigue or a cause."
                }
            }
            out.append(t)
        }
        return out
    }
}

// MARK: - Session status (Build 21 hotfix)

/// What a session's kicks need, separated so "nothing in the queue" is never shown as "all
/// done" while candidates still wait for the athlete.
struct SessionStatus: Equatable, Sendable {
    enum Stage: Equatable, Sendable {
        case noRecordings
        case recording
        /// Kick finding hasn't finished for every recording.
        case findingKicks
        /// Every recording was scanned and nothing kick-like was found.
        case noKicksDetected
        /// Candidates are waiting for the athlete (needs review).
        case awaitingReview
        /// Kicks are waiting for (or in) analysis.
        case analysisPending
        /// Every remaining kick is analyzed (or failed) and nothing waits for review.
        case analysisComplete
    }

    var stage: Stage
    /// Candidates the athlete must decide on ("needs review").
    var awaitingReview: Int
    /// Counted kicks (confirmed + probable; a camera pair once).
    var confirmedKicks: Int
    /// Kicks accepted or found strongly but not analyzed yet.
    var analysisPending: Int
    var analyzed: Int
    var failed: Int
    var headline: String
    var details: [String]

    static func make(_ m: TrainingSessionManifest) -> SessionStatus {
        let secondaries = Set(m.pairs.map(\.secondaryCandidateID))
        let primaries = m.candidates.filter { $0.status.isActive && !secondaries.contains($0.id) }
        let review = primaries.filter { $0.status == .needsReview }.count
        let pending = primaries.filter { c in
            c.status != .needsReview && (c.analysis.status == .notQueued || c.analysis.status == .queued || c.analysis.status == .running)
        }.count
        let failed = primaries.filter { $0.analysis.status == .failed && $0.status != .needsReview }.count
        let analyzed = primaries.filter { $0.analysis.status == .done }.count
        let confirmed = m.attempts.count
        let usable = m.sources.filter { $0.status == .finalized || $0.status == .recovered }
        let scanning = usable.contains { (m.processing.scan[$0.id.uuidString] ?? .notStarted) == .notStarted || m.processing.scan[$0.id.uuidString] == .scanning }

        let stage: Stage
        if m.sources.isEmpty {
            stage = .noRecordings
        } else if usable.isEmpty && m.sources.contains(where: { $0.status == .recording }) {
            stage = .recording
        } else if scanning {
            stage = .findingKicks
        } else if primaries.isEmpty {
            stage = .noKicksDetected
        } else if review > 0 {
            stage = .awaitingReview
        } else if pending > 0 {
            stage = .analysisPending
        } else {
            stage = .analysisComplete
        }

        func n(_ k: Int, _ one: String, _ many: String) -> String { "\(k) \(k == 1 ? one : many)" }
        let headline: String
        switch stage {
        case .noRecordings: headline = "No recordings yet"
        case .recording: headline = "Recording…"
        case .findingKicks: headline = "Looking for kicks in the recordings…"
        case .noKicksDetected: headline = "No kicks detected. If one was missed, add it with Add Missed Kick."
        case .awaitingReview: headline = n(review, "possible kick needs your review", "possible kicks need your review")
        case .analysisPending: headline = n(pending, "kick waiting for analysis", "kicks waiting for analysis")
        case .analysisComplete: headline = failed > 0 ? "Analysis finished — \(n(failed, "kick", "kicks")) couldn't be analyzed" : "All kicks reviewed and analyzed"
        }
        var details: [String] = []
        if confirmed > 0 { details.append(n(confirmed, "confirmed kick", "confirmed kicks")) }
        if review > 0, stage != .awaitingReview { details.append(n(review, "to review", "to review")) }
        if pending > 0, stage != .analysisPending { details.append("\(pending) waiting for analysis") }
        if analyzed > 0 { details.append("\(analyzed) analyzed") }
        if failed > 0, stage != .analysisComplete { details.append("\(failed) failed") }
        return SessionStatus(stage: stage, awaitingReview: review, confirmedKicks: confirmed, analysisPending: pending,
                             analyzed: analyzed, failed: failed, headline: headline, details: details)
    }
}

// MARK: - Playback plans (Build 21 hotfix)

/// Session Review's navigation to playback: a whole recording (`candidateID == nil`) or
/// one candidate's clip, by IDs (resolved again when the screen opens).
struct SessionPlaybackRequest: Hashable, Identifiable, Sendable {
    let sessionID: UUID
    let sourceID: UUID
    let candidateID: UUID?
    var id: String { "\(sessionID)-\(sourceID)-\(candidateID?.uuidString ?? "full")" }
}

/// What to play for "Watch Full Recording" and "Watch Clip": always the ORIGINAL source
/// recording (never a copy), at the candidate's interval for a clip. Pure, so navigation and
/// intervals are testable without a video.
struct SessionPlaybackPlan: Equatable, Sendable {
    enum Problem: Error, Equatable, Sendable {
        case unknownSource
        case unknownCandidate
        case stillRecording
        case fileMissing
    }

    var sourceID: UUID
    var candidateID: UUID?
    var relativePath: String
    /// Seconds in the source recording shown by the scrubber.
    var window: ClosedRange<Double>
    var initialTime: Double
    var clipStart: Double?
    var clipEnd: Double?
    var contact: Double?
    var frameRate: Double
    var title: String

    /// - Parameter fileExists: whether the recording file is on this iPhone (relative path).
    static func make(_ m: TrainingSessionManifest, sourceID: UUID, candidateID: UUID? = nil,
                     fileExists: (String) -> Bool) -> Result<SessionPlaybackPlan, Problem> {
        let source: SessionSource
        let candidate: SessionKickCandidate?
        if let candidateID {
            guard let c = m.candidate(candidateID) else { return .failure(.unknownCandidate) }
            guard let s = m.source(c.sourceID) else { return .failure(.unknownSource) }
            source = s
            candidate = c
        } else {
            guard let s = m.source(sourceID) else { return .failure(.unknownSource) }
            source = s
            candidate = nil
        }
        if source.status == .recording { return .failure(.stillRecording) }
        guard source.status != .missing, fileExists(source.relativePath) else { return .failure(.fileMissing) }
        let duration = source.durationSeconds.flatMap { $0.isFinite && $0 > 0 ? $0 : nil }
        let rate = source.nominalFrameRate.flatMap { $0 > 0 ? $0 : nil } ?? 30
        let segmentNumber = (m.segments(ofCamera: m.cameraID(of: source)).firstIndex { $0.id == source.id } ?? 0) + 1
        let cameraTitle = m.isLaterSegment(source) || m.segments(ofCamera: m.cameraID(of: source)).count > 1
            ? "\(source.role.title) · recording \(segmentNumber)" : source.role.title
        guard let c = candidate else {
            let end = duration ?? 0
            return .success(SessionPlaybackPlan(sourceID: source.id, candidateID: nil, relativePath: source.relativePath,
                                                window: 0...max(end, 0), initialTime: 0, clipStart: nil, clipEnd: nil, contact: nil,
                                                frameRate: rate, title: cameraTitle))
        }
        // The clip interval already holds the pre/post-contact context (ClipBoundaryPolicy);
        // clamp to the recording if its length is known.
        let start = max(0, c.startTime)
        let end = duration.map { min(c.endTime, $0) } ?? c.endTime
        let lo = min(start, end), hi = max(start, end)
        return .success(SessionPlaybackPlan(sourceID: source.id, candidateID: c.id, relativePath: source.relativePath,
                                            window: lo...hi, initialTime: lo, clipStart: lo, clipEnd: hi, contact: c.contactTime,
                                            frameRate: rate, title: cameraTitle))
    }

    static func text(_ p: Problem) -> String {
        switch p {
        case .unknownSource, .unknownCandidate: "This kick or recording no longer exists."
        case .stillRecording: "This recording wasn't finished. Reopen the session after the app has recovered it."
        case .fileMissing: "The recording file isn't on this iPhone."
        }
    }
}
