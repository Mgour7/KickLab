import Foundation

/// Step 12F: recording guidance for future clips. Advice is qualitative where no
/// validated number exists: KickLab has no evidence for a universally "correct" distance or
/// height, so none is given.
enum CaptureGuide {
    enum View: String, CaseIterable, Identifiable, Sendable {
        case side, rear, front
        var id: String { rawValue }
        var title: String {
            switch self {
            case .side: "Side"
            case .rear: "Behind"
            case .front: "In front"
            }
        }
    }

    struct Tip: Equatable, Sendable, Identifiable {
        var id: String { title }
        var title: String
        var detail: String
        var symbol: String
    }

    static let kickTypes: [KickType] = [.fieldGoal, .kickoff, .punt]

    /// What each view lets KickLab measure (matches `PerspectiveMetricSupport`).
    static func measurementNote(_ view: View) -> String {
        switch view {
        case .side:
            "Best for mechanics: approach, plant, leg swing and contact timing can all be measured, and a score is possible."
        case .rear, .front:
            "Measures timing (plant to contact, follow-through), sideways trunk lean and plant-foot width. Knee and hip angles can't be measured from this view, and no score is given."
        }
    }

    static func placement(_ kick: KickType, _ view: View) -> String {
        let subject = kick == .punt ? "the punter's catch-and-drop spot" : "the ball"
        switch view {
        case .side:
            return "Stand level with \(subject), square to the kicker's path (90° to the direction of the kick), on the side the kicker faces. Far enough back that the whole run-up, the strike and the follow-through stay in frame."
        case .rear:
            return "Stand behind the kicker, in line with the run-up and the target, far enough back that the kicker's whole body and \(subject) stay in frame from the first step to the follow-through."
        case .front:
            return "Stand in front of the kicker, well out of the ball's path (behind the goalposts or to one side of the target line), with the whole body and \(subject) in frame."
        }
    }

    static func tips(_ kick: KickType, _ view: View) -> [Tip] {
        var tips = [
            Tip(title: "Camera position", detail: placement(kick, view), symbol: "camera.viewfinder"),
            Tip(title: "Whole body in frame", detail: "Head to feet for the entire kick, including the run-up and the follow-through. Cut-off feet are the most common reason analysis fails.", symbol: "figure.stand"),
            Tip(title: "Keep the ball in frame", detail: kick == .punt
                ? "Keep the drop and the strike in frame; the ball's flight doesn't need to be."
                : "Keep the ball visible where it sits before the kick; the flight doesn't need to be.", symbol: "football"),
            Tip(title: "Hold the camera still", detail: "Use a tripod, fence or a person holding the phone steady with both hands. Don't pan or zoom during the kick.", symbol: "iphone.gen3"),
            Tip(title: "Clear view", detail: "No people walking between the camera and the kicker, and no one standing right behind the kicker in the same line.", symbol: "person.2.slash"),
            Tip(title: "Frame rate", detail: "Use 60 fps or more if your phone offers it (Settings › Camera › Record Video). At 30 fps the foot moves a long way between frames, so contact timing is less precise.", symbol: "speedometer"),
            Tip(title: "Light", detail: "Film in daylight or under good field lights, with the sun behind or beside the camera — not shining into the lens.", symbol: "sun.max"),
            Tip(title: "One kick per clip", detail: "Start recording a moment before the run-up and stop after the follow-through.", symbol: "film"),
        ]
        if view != .side {
            tips.append(Tip(title: "Choose the angle in KickLab", detail: "Set the camera angle to \(view == .rear ? "Rear" : "Front") when adding the video so it's analyzed as that view.", symbol: "square.and.pencil"))
        }
        return tips
    }

    /// Plain advice from a recorded frame rate (from the video's own metadata).
    static func frameRateAdvice(_ fps: Double?) -> String {
        guard let fps, fps.isFinite, fps > 0 else { return "Frame rate unknown." }
        let rounded = Int(fps.rounded())
        if fps < 50 { return "\(rounded) fps — contact can only be timed to about ±\(Int((1000 / fps).rounded())) ms; 60 fps or more is better." }
        return "\(rounded) fps — good for timing contact."
    }
}
