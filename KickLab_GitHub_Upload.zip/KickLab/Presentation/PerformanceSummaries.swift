import Foundation

/// Step 12F: a success rate shown WITH its sample size, so 80% of 5 can't be mistaken for
/// 80% of 100.
struct RateSummary: Equatable, Sendable {
    var successes: Int
    var attempts: Int

    /// Fewer attempts than this are flagged as a small sample.
    static let smallSampleAttempts = 10

    var percentage: Double? { attempts > 0 ? Double(successes) / Double(attempts) * 100 : nil }
    var isSmallSample: Bool { attempts > 0 && attempts < Self.smallSampleAttempts }

    /// "60% · 3 of 5".
    var text: String {
        guard let p = percentage else { return "No attempts" }
        return "\(Int(p.rounded()))% · \(successes) of \(attempts)"
    }

    /// "Small sample (5 attempts)" or nil.
    var sampleNote: String? {
        isSmallSample ? "Small sample (\(attempts) attempt\(attempts == 1 ? "" : "s"))" : nil
    }
}

/// Average and best of entered values, with how many were recorded.
struct ValueSummary: Equatable, Sendable {
    var count: Int
    var average: Double?
    var best: Double?

    init(_ values: [Double]) {
        let v = values.filter(\.isFinite)
        count = v.count
        average = v.isEmpty ? nil : v.reduce(0, +) / Double(v.count)
        best = v.max()
    }
}

struct BandRate: Equatable, Sendable {
    var bucket: DistanceBucket
    var rate: RateSummary
}

struct ResultCount: Equatable, Sendable {
    var result: KickResult
    var count: Int
}

struct TypeCount: Equatable, Sendable {
    var type: KickType
    var count: Int
}

/// Step 12F: field goal / PAT results from recorded attempts only.
struct GoalpostSummary: Equatable, Sendable {
    var kickType: KickType
    var overall: RateSummary
    var byDistance: [BandRate]
    var longestMake: Double?
    var misses: [ResultCount]
    /// Kicks without a recorded result (not attempts).
    var unrecorded: Int
    /// Attempts with no distance entered.
    var withoutDistance: Int

    static let missOrder: [KickResult] = [.missedLeft, .missedRight, .short, .blocked, .missedOther]

    static func make(_ records: [KickStatRecord], type: KickType) -> GoalpostSummary? {
        let kicks = records.filter { $0.kickType == type }
        guard !kicks.isEmpty else { return nil }
        let decided = kicks.filter { ($0.result ?? .unknown) != .unknown }
        let makes = decided.filter { $0.result == .made }
        let byDistance = DistanceBucket.allCases.compactMap { bucket -> BandRate? in
            let inBucket = decided.filter { $0.distanceYards.flatMap(DistanceBucket.bucket(forYards:)) == bucket }
            guard !inBucket.isEmpty else { return nil }
            return BandRate(bucket: bucket, rate: RateSummary(successes: inBucket.filter { $0.result == .made }.count, attempts: inBucket.count))
        }
        let misses = missOrder.compactMap { r -> ResultCount? in
            let n = decided.filter { $0.result == r }.count
            return n > 0 ? ResultCount(result: r, count: n) : nil
        }
        return GoalpostSummary(
            kickType: type,
            overall: RateSummary(successes: makes.count, attempts: decided.count),
            byDistance: byDistance,
            longestMake: makes.compactMap(\.distanceYards).max(),
            misses: misses,
            unrecorded: kicks.count - decided.count,
            withoutDistance: decided.filter { $0.distanceYards == nil }.count
        )
    }
}

struct KickoffSummary: Equatable, Sendable {
    var count: Int
    var distance: ValueSummary
    var hangTime: ValueSummary
    /// Touchbacks out of kickoffs where it was recorded.
    var touchbacks: RateSummary
    var outOfBounds: Int
    var directions: [KickDirection: Int]

    static func make(_ records: [KickStatRecord]) -> KickoffSummary? {
        let k = records.filter { $0.kickType == .kickoff }
        guard !k.isEmpty else { return nil }
        let tbRecorded = k.filter { $0.touchback != nil }
        var directions: [KickDirection: Int] = [:]
        for r in k { if let d = r.direction, d != .unknown { directions[d, default: 0] += 1 } }
        return KickoffSummary(
            count: k.count, distance: ValueSummary(k.compactMap(\.distanceYards)), hangTime: ValueSummary(k.compactMap(\.hangTimeSeconds)),
            touchbacks: RateSummary(successes: tbRecorded.filter { $0.touchback == true }.count, attempts: tbRecorded.count),
            outOfBounds: k.filter { $0.outOfBounds == true }.count, directions: directions
        )
    }
}

struct PuntSummary: Equatable, Sendable {
    var count: Int
    var distance: ValueSummary
    var hangTime: ValueSummary
    /// Inside the 20 out of punts where it was recorded.
    var insideTwenty: RateSummary
    var results: [PuntResult: Int]

    static func make(_ records: [KickStatRecord]) -> PuntSummary? {
        let p = records.filter { $0.kickType == .punt }
        guard !p.isEmpty else { return nil }
        let i20 = p.filter { $0.puntInsideTwenty != nil }
        var results: [PuntResult: Int] = [:]
        for r in p { if let x = r.puntResult, x != .unknown { results[x, default: 0] += 1 } }
        return PuntSummary(
            count: p.count, distance: ValueSummary(p.compactMap(\.distanceYards)), hangTime: ValueSummary(p.compactMap(\.hangTimeSeconds)),
            insideTwenty: RateSummary(successes: i20.filter { $0.puntInsideTwenty == true }.count, attempts: i20.count), results: results
        )
    }
}

/// Step 12F: a training session's statistics, from its recorded kicks only. Field goals,
/// PATs, kickoffs and punts are kept separate.
struct SessionPerformanceSummary: Equatable, Sendable {
    var fieldGoals: GoalpostSummary?
    var pats: GoalpostSummary?
    var kickoffs: KickoffSummary?
    var punts: PuntSummary?

    static func make(_ records: [KickStatRecord]) -> SessionPerformanceSummary {
        SessionPerformanceSummary(fieldGoals: .make(records, type: .fieldGoal), pats: .make(records, type: .pat),
                                  kickoffs: .make(records), punts: .make(records))
    }

    var isEmpty: Bool { fieldGoals == nil && pats == nil && kickoffs == nil && punts == nil }

    /// "FG 4 of 6 · KO 3" for lists.
    var shortText: String {
        var parts: [String] = []
        if let fg = fieldGoals { parts.append("FG \(fg.overall.successes) of \(fg.overall.attempts)") }
        if let pat = pats { parts.append("PAT \(pat.overall.successes) of \(pat.overall.attempts)") }
        if let ko = kickoffs { parts.append("KO \(ko.count)") }
        if let p = punts { parts.append("Punts \(p.count)") }
        return parts.isEmpty ? "No kicks recorded" : parts.joined(separator: " · ")
    }

    var sections: [StatSection] {
        var out: [StatSection] = []
        for g in [fieldGoals, pats].compactMap({ $0 }) { out.append(Self.section(g)) }
        if let k = kickoffs {
            var rows = [StatRow(title: "Kickoffs", value: "\(k.count)", detail: nil)]
            rows += Self.valueRows("Distance", k.distance, unit: "yd")
            rows += Self.valueRows("Hang time", k.hangTime, unit: "s")
            if k.touchbacks.attempts > 0 { rows.append(StatRow(title: "Touchbacks", value: k.touchbacks.text, detail: k.touchbacks.sampleNote)) }
            if k.outOfBounds > 0 { rows.append(StatRow(title: "Out of bounds", value: "\(k.outOfBounds)", detail: nil)) }
            for d in KickDirection.selectableCases { if let n = k.directions[d] { rows.append(StatRow(title: "Direction: \(d.displayName)", value: "\(n)", detail: nil)) } }
            out.append(StatSection(title: "Kickoffs", rows: rows, emptyMessage: nil))
        }
        if let p = punts {
            var rows = [StatRow(title: "Punts", value: "\(p.count)", detail: nil)]
            rows += Self.valueRows("Distance", p.distance, unit: "yd")
            rows += Self.valueRows("Hang time", p.hangTime, unit: "s")
            if p.insideTwenty.attempts > 0 { rows.append(StatRow(title: "Inside the 20", value: p.insideTwenty.text, detail: p.insideTwenty.sampleNote)) }
            for r in PuntResult.selectableCases { if let n = p.results[r] { rows.append(StatRow(title: r.displayName, value: "\(n)", detail: nil)) } }
            out.append(StatSection(title: "Punts", rows: rows, emptyMessage: nil))
        }
        return out
    }

    static func section(_ g: GoalpostSummary) -> StatSection {
        let title = g.kickType == .pat ? "PATs" : "Field goals"
        guard g.overall.attempts > 0 else {
            return StatSection(title: title, rows: [], emptyMessage: "No results recorded (\(g.unrecorded) kick\(g.unrecorded == 1 ? "" : "s") without a result).")
        }
        var rows = [StatRow(title: "Made", value: g.overall.text, detail: g.overall.sampleNote)]
        for b in g.byDistance {
            rows.append(StatRow(title: b.bucket.displayName + " yd", value: b.rate.text, detail: b.rate.sampleNote))
        }
        if let longest = g.longestMake { rows.append(StatRow(title: "Longest make", value: DisplayFormat.yards(longest), detail: nil)) }
        for m in g.misses { rows.append(StatRow(title: m.result.displayName, value: "\(m.count)", detail: nil)) }
        if g.withoutDistance > 0 { rows.append(StatRow(title: "Without a distance", value: "\(g.withoutDistance)", detail: "Not in the distance bands")) }
        if g.unrecorded > 0 { rows.append(StatRow(title: "Result not recorded", value: "\(g.unrecorded)", detail: "Not counted as attempts")) }
        return StatSection(title: title, rows: rows, emptyMessage: nil)
    }

    static func valueRows(_ title: String, _ v: ValueSummary, unit: String) -> [StatRow] {
        guard v.count > 0, let avg = v.average, let best = v.best else { return [] }
        let f = { (x: Double) in unit == "s" ? DisplayFormat.number(x, digits: 2) + " s" : DisplayFormat.number(x, digits: 0) + " yd" }
        return [StatRow(title: "\(title) (average)", value: f(avg), detail: "\(v.count) recorded"),
                StatRow(title: "\(title) (best)", value: f(best), detail: nil)]
    }
}

// MARK: - Progress dashboard

/// Date ranges on the progress dashboard.
enum ProgressRange: String, CaseIterable, Identifiable, Sendable {
    case last30, last90, allTime
    var id: String { rawValue }
    var title: String {
        switch self {
        case .last30: "30 days"
        case .last90: "90 days"
        case .allTime: "All time"
        }
    }
    func range(endingAt now: Date) -> ClosedRange<Date>? {
        switch self {
        case .last30: StatisticsPeriod.last(days: 30, endingAt: now)
        case .last90: StatisticsPeriod.last(days: 90, endingAt: now)
        case .allTime: nil
        }
    }
}

/// One plotted point (always a real recorded value).
struct ProgressPoint: Equatable, Sendable, Identifiable {
    var id: String { "\(series)-\(date.timeIntervalSince1970)-\(value)" }
    var date: Date
    var value: Double
    var series: String
}

struct SessionDigest: Equatable, Sendable, Identifiable {
    var id: UUID
    var date: Date
    var name: String
    var kickCount: Int
    var summary: String
}

/// A stored analysis reduced to what trends may compare.
struct AnalysisTrendRecord: Equatable, Sendable {
    var date: Date
    var kickType: KickType
    var cameraAngle: VideoAngleType
    /// Engine version without the "+assisted" suffix.
    var engineVersion: String
    var isUserAssisted: Bool
    var overallScore: Double?
    var plantToContact: Double?
}

/// Step 12F: what a trend may compare: the same kick type, camera view and engine
/// version. User-assisted analyses are left out (their contact was chosen by a person).
struct AnalysisTrendGroup: Equatable, Sendable, Identifiable {
    var id: String { label }
    var kickType: KickType
    var cameraAngle: VideoAngleType
    var engineVersion: String
    var points: [ProgressPoint]
    var metricTitle: String

    var label: String { "\(kickType.displayName) · \(cameraAngle.displayName) view · \(engineVersion)" }
    static let minimumPoints = 2
    var isChartable: Bool { points.count >= Self.minimumPoints }
}

struct PersonalBest: Equatable, Sendable, Identifiable {
    var id: String { title }
    var title: String
    var value: String
    var date: Date
}

/// Step 12F: the progress dashboard for one athlete, from saved kicks, sessions and
/// analyses only. Nothing is estimated or filled in: empty sections say so.
struct ProgressDashboard: Equatable, Sendable {
    var range: ProgressRange
    var totalKicks: Int
    var kicksByType: [TypeCount]
    var fieldGoals: GoalpostSummary?
    var pats: GoalpostSummary?
    var kickoffs: KickoffSummary?
    var punts: PuntSummary?
    var fieldGoalPoints: [ProgressPoint]
    var kickoffDistancePoints: [ProgressPoint]
    var puntDistancePoints: [ProgressPoint]
    var hangTimePoints: [ProgressPoint]
    var personalBests: [PersonalBest]
    var recentSessions: [SessionDigest]
    var recentVideoKicks: [KickStatRecord]
    var trainingDays: Int
    var sessionsInRange: Int
    var weeksInRange: Double?
    var analysisGroups: [AnalysisTrendGroup]

    var isEmpty: Bool { totalKicks == 0 }

    /// "Trained on 6 days · 4 sessions (1.0 per week)".
    var consistencyText: String {
        guard totalKicks > 0 else { return "No kicks recorded in this period." }
        var s = "Kicked on \(trainingDays) day\(trainingDays == 1 ? "" : "s")"
        s += " · \(sessionsInRange) session\(sessionsInRange == 1 ? "" : "s")"
        if let w = weeksInRange, w >= 1 {
            s += String(format: " (%.1f per week)", Double(sessionsInRange) / w)
        }
        return s
    }

    /// - Parameters:
    ///   - records: all of the athlete's kicks (any date).
    ///   - sessions: (id, date, name) of the athlete's sessions.
    ///   - analyses: the athlete's completed current analyses.
    static func make(records: [KickStatRecord], sessions: [(id: UUID, date: Date, name: String)], analyses: [AnalysisTrendRecord],
                     range: ProgressRange, now: Date, calendar: Calendar = Calendar(identifier: .gregorian)) -> ProgressDashboard {
        let window = range.range(endingAt: now)
        func inRange(_ d: Date) -> Bool { window.map { $0.contains(d) } ?? true }
        let r = records.filter { inRange($0.timestamp) }.sorted { $0.timestamp < $1.timestamp }
        let byType = KickType.selectableCases.map { t in TypeCount(type: t, count: r.filter { $0.kickType == t }.count) }

        // FG make % per session day (dated by the day, sample size kept in the series name).
        var fgPoints: [ProgressPoint] = []
        let fg = r.filter { $0.kickType == .fieldGoal && ($0.result ?? .unknown) != .unknown }
        let fgDays = Dictionary(grouping: fg) { calendar.startOfDay(for: $0.timestamp) }
        for (day, kicks) in fgDays.sorted(by: { $0.key < $1.key }) {
            let made = kicks.filter { $0.result == .made }.count
            fgPoints.append(ProgressPoint(date: day, value: Double(made) / Double(kicks.count) * 100, series: "Make %"))
        }
        func points(_ type: KickType, _ value: (KickStatRecord) -> Double?, _ series: String) -> [ProgressPoint] {
            r.filter { $0.kickType == type }.compactMap { k in value(k).map { ProgressPoint(date: k.timestamp, value: $0, series: series) } }
        }
        let koDistance = points(.kickoff, \.distanceYards, "Kickoff distance")
        let puntDistance = points(.punt, \.distanceYards, "Punt distance")
        let hang = points(.kickoff, \.hangTimeSeconds, "Kickoff hang time") + points(.punt, \.hangTimeSeconds, "Punt hang time")

        // Personal bests (all time, entered values only).
        var bests: [PersonalBest] = []
        func best(_ title: String, _ type: KickType, _ value: (KickStatRecord) -> Double?, filter: (KickStatRecord) -> Bool = { _ in true },
                  format: (Double) -> String) {
            let candidates = records.filter { $0.kickType == type && filter($0) }.compactMap { k in value(k).map { (k, $0) } }
            if let top = candidates.max(by: { $0.1 < $1.1 }) { bests.append(PersonalBest(title: title, value: format(top.1), date: top.0.timestamp)) }
        }
        best("Longest made field goal", .fieldGoal, \.distanceYards, filter: { $0.result == .made }, format: { DisplayFormat.yards($0) })
        best("Longest kickoff", .kickoff, \.distanceYards, format: { DisplayFormat.yards($0) })
        best("Longest kickoff hang time", .kickoff, \.hangTimeSeconds, format: { DisplayFormat.seconds($0) })
        best("Longest punt", .punt, \.distanceYards, format: { DisplayFormat.yards($0) })
        best("Longest punt hang time", .punt, \.hangTimeSeconds, format: { DisplayFormat.seconds($0) })

        // Sessions.
        let sessionsInRange = sessions.filter { inRange($0.date) }.sorted { $0.date > $1.date }
        let digests = sessionsInRange.prefix(5).map { s -> SessionDigest in
            let kicks = records.filter { $0.sessionID == s.id }
            return SessionDigest(id: s.id, date: s.date, name: s.name, kickCount: kicks.count,
                                 summary: SessionPerformanceSummary.make(kicks).shortText)
        }
        let days = Set(r.map { calendar.startOfDay(for: $0.timestamp) }).count
        let span: Double? = {
            if let w = window { return w.upperBound.timeIntervalSince(w.lowerBound) / (7 * 86_400) }
            guard let first = records.map(\.timestamp).min() else { return nil }
            return now.timeIntervalSince(first) / (7 * 86_400)
        }()

        // Analysis trends: comparable groups only.
        var groups: [String: AnalysisTrendGroup] = [:]
        for a in analyses where !a.isUserAssisted && inRange(a.date) {
            let key = "\(a.kickType.rawValue)|\(a.cameraAngle.rawValue)|\(a.engineVersion)"
            let scored = a.overallScore != nil
            let value = scored ? a.overallScore : a.plantToContact
            guard let value else { continue }
            let title = scored ? "Overall score" : "Plant → contact (s)"
            var g = groups[key] ?? AnalysisTrendGroup(kickType: a.kickType, cameraAngle: a.cameraAngle, engineVersion: a.engineVersion,
                                                      points: [], metricTitle: title)
            // One metric per group: a group mixing scored and unscored keeps the score.
            if g.metricTitle == title {
                g.points.append(ProgressPoint(date: a.date, value: value, series: g.label))
            }
            groups[key] = g
        }

        return ProgressDashboard(
            range: range, totalKicks: r.count, kicksByType: byType,
            fieldGoals: .make(r, type: .fieldGoal), pats: .make(r, type: .pat), kickoffs: .make(r), punts: .make(r),
            fieldGoalPoints: fgPoints, kickoffDistancePoints: koDistance, puntDistancePoints: puntDistance, hangTimePoints: hang,
            personalBests: bests,
            recentSessions: Array(digests),
            recentVideoKicks: Array(r.filter(\.hasVideo).sorted { $0.timestamp > $1.timestamp }.prefix(5)),
            trainingDays: days, sessionsInRange: sessionsInRange.count, weeksInRange: span,
            analysisGroups: groups.values.sorted { $0.label < $1.label }.map { g in
                var g = g
                g.points.sort { $0.date < $1.date }
                return g
            }
        )
    }
}
