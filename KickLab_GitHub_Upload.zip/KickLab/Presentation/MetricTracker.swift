import Foundation

// Build 23 — Metric Tracker: every measurement followed kick by kick, from the analyses
// the app already stored. Pure (Linux-tested).
//
// Rules (the same ones the rest of the app compares by):
// - kicks are grouped by kick type AND camera view, never mixed (a side-view knee angle and
//   a rear-view one are different measurements);
// - only completed analyses whose recording is eligible for measurement history, and only
//   values with at least the scoring confidence and the current definition version
//   (`RankingEntry.metrics` already applies both);
// - a target is the provisional band used for grading, shown only where the measurement is
//   graded; "toward target" means the distance from that band is shrinking;
// - a trend needs `minimumForTrend` kicks and a consistent direction (|r| ≥ 0.7), never a
//   single good or bad kick.

struct MetricTrackPoint: Equatable, Sendable, Identifiable {
    /// 1-based position in the group's kicks that have this measurement (chart x).
    var number: Int
    var analysisID: UUID
    var date: Date
    var value: Double
    var valueText: String
    /// nil when the measurement has no target.
    var inTarget: Bool?
    var id: UUID { analysisID }
}

enum MetricTrackTrend: Equatable, Sendable {
    case towardTarget
    case awayFromTarget
    case improving
    case declining
    case steady
    /// No target or better direction: the value moved consistently one way.
    case risingNoDirection
    case fallingNoDirection
    case notEnough(have: Int, need: Int)

    var title: String {
        switch self {
        case .towardTarget: "Moving toward target"
        case .awayFromTarget: "Moving away from target"
        case .improving: "Improving"
        case .declining: "Getting worse"
        case .steady: "Steady"
        case .risingNoDirection: "Rising"
        case .fallingNoDirection: "Falling"
        case .notEnough(let have, let need): "\(have) of \(need) kicks for a trend"
        }
    }

    var symbol: String {
        switch self {
        case .towardTarget, .improving: "arrow.up.right.circle.fill"
        case .awayFromTarget, .declining: "arrow.down.right.circle.fill"
        case .steady: "equal.circle.fill"
        case .risingNoDirection: "arrow.up.circle"
        case .fallingNoDirection: "arrow.down.circle"
        case .notEnough: "hourglass.circle"
        }
    }

    /// Good / bad / neutral, for color (never the only signal: the title says it too).
    var tone: Int {
        switch self {
        case .towardTarget, .improving: 1
        case .awayFromTarget, .declining: -1
        default: 0
        }
    }
}

struct MetricTrack: Equatable, Sendable, Identifiable {
    var key: KickMetricKey
    var name: String
    var definition: String
    var category: AnalysisCategory
    var unit: MetricUnit
    /// Oldest first.
    var points: [MetricTrackPoint]
    var latestText: String
    /// Mean of the last `MetricTracker.recentWindow` kicks.
    var recentAverageText: String
    /// "Range 0.10–0.25 torso lengths over the last 5 kicks" (nil with fewer than 3).
    var rangeText: String?
    /// Provisional target (graded measurements only).
    var targetText: String?
    var targetLow: Double?
    var targetHigh: Double?
    var inTargetCount: Int?
    var trend: MetricTrackTrend
    /// 0–100 against the target for the latest kick (nil: no target).
    var latestBandScore: Double?
    var isGraded: Bool { targetText != nil }
    var id: String { key.rawValue }

    var inTargetText: String? {
        inTargetCount.map { "\($0) of \(points.count) kick\(points.count == 1 ? "" : "s") inside the provisional target" }
    }
}

struct MetricTrackerGroup: Equatable, Sendable, Identifiable {
    var kickType: KickType
    var view: ComparableView
    var kickCount: Int
    var lastDate: Date
    var tracks: [MetricTrack]
    var title: String { "\(kickType.displayName) · \(view.title)" }
    var id: String { "\(kickType.rawValue)-\(view.rawValue)" }

    /// Up to three graded measurements to watch: latest kick outside its target (lowest
    /// band score first), then ones moving away from target.
    var watchList: [MetricTrack] {
        let off = tracks.filter { $0.points.last?.inTarget == false }.sorted { ($0.latestBandScore ?? 100) < ($1.latestBandScore ?? 100) }
        let away = tracks.filter { $0.trend == .awayFromTarget && !off.contains($0) }
        return Array((off + away).prefix(3))
    }
}

enum MetricTracker {
    static let recentWindow = 5
    static let minimumForTrend = 4
    static let minimumTrendCorrelation = PersonalRanking.minimumTrendCorrelation

    /// Groups by kick type and camera view (most recently kicked group first).
    static func groups(_ entries: [RankingEntry]) -> [MetricTrackerGroup] {
        let usable = entries.filter { $0.completed && $0.recording.eligibleForMeasurementHistory && $0.view != .unknown && $0.kickType != .unknown }
        var keys: [String] = []
        var buckets: [String: [RankingEntry]] = [:]
        for e in usable {
            let k = "\(e.kickType.rawValue)|\(e.view.rawValue)"
            if buckets[k] == nil { keys.append(k) }
            buckets[k, default: []].append(e)
        }
        let out: [MetricTrackerGroup] = keys.compactMap { k in
            guard let list = buckets[k]?.sorted(by: { $0.date < $1.date }), let first = list.first, let last = list.last else { return nil }
            let tracks = KickMetricKey.allCases.compactMap { track($0, entries: list, kickType: first.kickType) }
            guard !tracks.isEmpty else { return nil }
            return MetricTrackerGroup(kickType: first.kickType, view: first.view, kickCount: list.count, lastDate: last.date, tracks: tracks)
        }
        return out.sorted { $0.lastDate > $1.lastDate }
    }

    static func track(_ key: KickMetricKey, entries: [RankingEntry], kickType: KickType) -> MetricTrack? {
        let d = key.definition
        let rule = BiomechanicsProfile.standard(for: kickType).scoring[key]
        let band = (rule?.weight ?? 0) > 0 ? rule?.band : nil
        func text(_ v: Double) -> String {
            let t = DisplayFormat.signedLateralMetrics.contains(key) ? DisplayFormat.lateral(v, unit: d.unit) : DisplayFormat.metricValue(v, unit: d.unit)
            return t.hasPrefix("-") ? "−" + t.dropFirst() : t
        }
        let points: [MetricTrackPoint] = entries.compactMap { e -> (UUID, Date, Double)? in
            guard let v = e.metric(key), v.isFinite else { return nil }
            return (e.id, e.date, v)
        }.enumerated().map { i, p in
            MetricTrackPoint(number: i + 1, analysisID: p.0, date: p.1, value: p.2, valueText: text(p.2),
                             inTarget: band.map { p.2 >= $0.idealLow && p.2 <= $0.idealHigh })
        }
        guard let latest = points.last else { return nil }
        let recent = Array(points.suffix(recentWindow))
        let mean = recent.map(\.value).reduce(0, +) / Double(recent.count)
        var range: String?
        if recent.count >= 3, let lo = recent.map(\.value).min(), let hi = recent.map(\.value).max() {
            range = "Range \(text(lo)) to \(text(hi)) over the last \(recent.count) kicks"
        }
        return MetricTrack(
            key: key, name: d.displayName, definition: MetricContext.athleteLine(key), category: d.category, unit: d.unit,
            points: points, latestText: latest.valueText, recentAverageText: text(mean), rangeText: range,
            targetText: band.map { KickBreakdownBuilder.targetText($0, unit: d.unit) },
            targetLow: band.flatMap { $0.zeroLow == nil && $0.idealLow <= 0 ? nil : $0.idealLow },
            targetHigh: band.flatMap { $0.idealHigh >= 999 ? nil : $0.idealHigh },
            inTargetCount: band.map { _ in points.filter { $0.inTarget == true }.count },
            trend: trend(points.map(\.value), band: band, direction: d.betterDirection),
            latestBandScore: band.map { $0.score(latest.value) })
    }

    /// The chart's y range (values and the finite part of the target, with margin) and the
    /// target band clipped to it (open-ended targets run to the edge).
    static func chartScale(_ t: MetricTrack) -> (domain: ClosedRange<Double>, band: ClosedRange<Double>?) {
        let values = t.points.map(\.value)
        var lo = values.min() ?? 0, hi = values.max() ?? 1
        if let l = t.targetLow { lo = min(lo, l) }
        if let h = t.targetHigh { hi = max(hi, h) }
        let pad = max((hi - lo) * 0.12, abs(hi) * 0.02, 1e-3)
        let domain = (lo - pad)...(hi + pad)
        guard t.isGraded else { return (domain, nil) }
        let bandLow = max(domain.lowerBound, t.targetLow ?? domain.lowerBound)
        let bandHigh = min(domain.upperBound, t.targetHigh ?? domain.upperBound)
        return (domain, bandLow < bandHigh ? bandLow...bandHigh : nil)
    }

    /// The direction of the last `recentWindow + 1` kicks (at least `minimumForTrend`).
    static func trend(_ values: [Double], band: ScoreBand?, direction: MetricBetterDirection) -> MetricTrackTrend {
        let v = Array(values.suffix(recentWindow + 1))
        guard v.count >= minimumForTrend else { return .notEnough(have: v.count, need: minimumForTrend) }
        if let band {
            let distance = v.map { band.distanceFromIdeal($0) }
            if distance.allSatisfy({ $0 == 0 }) { return .steady }
            guard let r = correlation(distance), abs(r) >= minimumTrendCorrelation else { return .steady }
            return r < 0 ? .towardTarget : .awayFromTarget
        }
        guard let r = correlation(v), abs(r) >= minimumTrendCorrelation else { return .steady }
        switch direction {
        case .higher: return r > 0 ? .improving : .declining
        case .lower: return r < 0 ? .improving : .declining
        case .towardIdealBand, .none: return r > 0 ? .risingNoDirection : .fallingNoDirection
        }
    }

    /// Pearson correlation of the values with their order (nil when flat).
    static func correlation(_ y: [Double]) -> Double? {
        let n = Double(y.count)
        guard y.count >= 2 else { return nil }
        let xs = y.indices.map(Double.init)
        let mx = xs.reduce(0, +) / n, my = y.reduce(0, +) / n
        var sxy = 0.0, sxx = 0.0, syy = 0.0
        for (x, v) in zip(xs, y) { sxy += (x - mx) * (v - my); sxx += (x - mx) * (x - mx); syy += (v - my) * (v - my) }
        guard sxx > 0, syy > 1e-12 else { return nil }
        return sxy / (sxx * syy).squareRoot()
    }
}
