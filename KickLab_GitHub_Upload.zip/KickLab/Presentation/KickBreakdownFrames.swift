import Foundation

// Build 22: how each Kick Breakdown card frames its video frame — a 4:3 window around the
// kicker (one zoom for the whole kick, so the cards compare), and the tracked skeleton for
// that frame in the window's own coordinates. Pure: tested on Linux; the app crops the
// real frame with `FrameImageLoader` and draws the bones over it.

struct PhaseFrame: Equatable, Sendable {
    /// The crop, in normalized display coordinates of the source frame (y down).
    var crop: NormalizedRect
    /// Bones to draw, in 0…1 coordinates of the crop.
    var bones: [Bone]

    struct Bone: Equatable, Sendable {
        enum Role: String, Equatable, Sendable { case kickingLeg, plantLeg, body }
        var from: NormalizedPoint
        var to: NormalizedPoint
        var role: Role
    }
}

enum PhaseFrameFraming {
    /// Window height = this × the kicker's height at contact (room for the leg swing).
    static let zoom = 1.9
    static let minimumConfidence = 0.3

    static let skeleton: [(PoseJoint, PoseJoint)] = [
        (.leftShoulder, .rightShoulder), (.leftShoulder, .leftHip), (.rightShoulder, .rightHip), (.leftHip, .rightHip),
        (.leftShoulder, .leftElbow), (.leftElbow, .leftWrist), (.rightShoulder, .rightElbow), (.rightElbow, .rightWrist),
        (.leftHip, .leftKnee), (.leftKnee, .leftAnkle), (.rightHip, .rightKnee), (.rightKnee, .rightAnkle),
        (.neck, .nose),
    ]

    /// Frames for the given card times. `aspect` is the display width ÷ height.
    static func make(timeline: KickerPoseTimeline, times: [Double], contactTime: Double?, kickingFoot: KickingFoot,
                     aspect: Double) -> [Double: PhaseFrame] {
        guard !timeline.samples.isEmpty, aspect > 0 else { return [:] }
        // The kicker's height (normalized to the frame height) near contact sets one zoom.
        let reference = contactTime.flatMap { nearest(timeline, $0) } ?? timeline.samples[timeline.samples.count / 2]
        guard let bodyHeight = height(reference), bodyHeight > 0.02 else { return [:] }
        let h = min(1, bodyHeight * zoom)
        let w = min(1, h * 4 / 3 / aspect)
        var out: [Double: PhaseFrame] = [:]
        for t in Set(times) {
            guard let s = nearest(timeline, t) else { continue }
            let pts = points(s)
            guard !pts.isEmpty else { continue }
            let cx = pts.map(\.x).reduce(0, +) / Double(pts.count), cy = pts.map(\.y).reduce(0, +) / Double(pts.count)
            let x0 = min(max(cx - w / 2, 0), 1 - w), y0 = min(max(cy - h / 2, 0), 1 - h)
            let crop = NormalizedRect(minX: x0, minY: y0, maxX: x0 + w, maxY: y0 + h)
            func local(_ p: PosePoint) -> NormalizedPoint { NormalizedPoint(x: (p.x - x0) / w, y: (p.y - y0) / h) }
            let kicking: Set<PoseJoint> = kickingFoot == .left ? [.leftHip, .leftKnee, .leftAnkle] : [.rightHip, .rightKnee, .rightAnkle]
            let plant: Set<PoseJoint> = Set(kicking.map(\.opposite))
            let bones: [PhaseFrame.Bone] = skeleton.compactMap { a, b in
                guard let pa = s.point(a), let pb = s.point(b), pa.confidence >= minimumConfidence, pb.confidence >= minimumConfidence else { return nil }
                let role: PhaseFrame.Bone.Role = kicking.contains(a) && kicking.contains(b) ? .kickingLeg
                    : (plant.contains(a) && plant.contains(b) ? .plantLeg : .body)
                return PhaseFrame.Bone(from: local(pa), to: local(pb), role: role)
            }
            out[t] = PhaseFrame(crop: crop, bones: bones)
        }
        return out
    }

    /// The sample nearest `time`, within 0.1 s.
    static func nearest(_ timeline: KickerPoseTimeline, _ time: Double) -> KickerPoseSample? {
        guard let s = timeline.samples.min(by: { abs($0.timestamp - time) < abs($1.timestamp - time) }), abs(s.timestamp - time) <= 0.1 else { return nil }
        return s
    }

    static func points(_ s: KickerPoseSample) -> [PosePoint] {
        s.joints.values.filter { $0.isAvailable && $0.confidence >= minimumConfidence }
    }

    static func height(_ s: KickerPoseSample) -> Double? {
        let ys = points(s).map(\.y)
        guard let lo = ys.min(), let hi = ys.max() else { return nil }
        return hi - lo
    }
}
