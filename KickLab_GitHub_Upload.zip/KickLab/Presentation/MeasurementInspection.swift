import Foundation

/// Build 19 (Athlete Report 4.0): what to draw over the contact frame so an athlete can SEE
/// a sideways plant measurement — the reference (the kicked football's center, or the hips'
/// center), the plant ankle, and the sideways offset between them.
///
/// Only stored data is used: the processed kicker pose at the contact sample and the
/// football detector's resting box. Both are in app-normalized DISPLAYED coordinates
/// (orientation applied; x across, y down), the same space the Pose Validation overlay
/// draws in, so mapping with `PoseOverlayGeometry.aspectFitRect` is exact. When any input
/// is missing, `make` returns a reason instead of an overlay — nothing is approximated.
struct MeasurementInspection: Equatable, Sendable {
    enum Kind: String, Equatable, Sendable {
        /// `plant.ballLateralOffset`
        case plantToBall
        /// `plant.lateralFootOffset`
        case plantToHips

        init?(metric: KickMetricKey) {
            switch metric {
            case .plantBallLateralOffset: self = .plantToBall
            case .plantFootWidth: self = .plantToHips
            default: return nil
            }
        }

        var metric: KickMetricKey { self == .plantToBall ? .plantBallLateralOffset : .plantFootWidth }
        var referenceLabel: String { self == .plantToBall ? "Football center" : "Hips' center" }
    }

    var kind: Kind
    /// The contact frame shown (seconds).
    var time: Double
    /// Displayed-normalized points.
    var reference: NormalizedPoint
    var ankle: NormalizedPoint
    /// The football's resting box (plant-to-ball only).
    var ball: NormalizedBox?
    /// False when the plant ankle at this frame was filled in rather than detected.
    var ankleMeasured: Bool
    /// The stored measurement and its plain-language reading.
    var valueText: String
    var note: String

    static let provisionalLabel = "Estimated from the video · provisional (no 'ideal' value is implied)"

    enum Failure: Error, Equatable, Sendable {
        case noContact, noPose, noBall, noAnkle, noMeasurement
        var message: String {
            switch self {
            case .noContact: "No contact frame was established for this kick, so there is nothing to show."
            case .noPose: "The analyzed pose for this kick isn't stored on this device."
            case .noBall: "The football detector didn't find the kicked ball, so its position can't be shown."
            case .noAnkle: "The plant ankle wasn't tracked at the contact frame."
            case .noMeasurement: "This measurement wasn't established for this kick."
            }
        }
    }

    static func make(kind: Kind, timeline: KickerPoseTimeline?, football: FootballTrack?, contactTime: Double?,
                     kickingFoot: KickingFoot, storedValue: Double?) -> Result<MeasurementInspection, Failure> {
        guard let storedValue else { return .failure(.noMeasurement) }
        guard let contactTime else { return .failure(.noContact) }
        guard let timeline, let sample = timeline.samples.min(by: { abs($0.timestamp - contactTime) < abs($1.timestamp - contactTime) }),
              abs(sample.timestamp - contactTime) <= 0.02 else { return .failure(.noPose) }
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        guard let plant = sample.point(sides.plantAnkle) else { return .failure(.noAnkle) }
        let reference: NormalizedPoint
        var ball: NormalizedBox?
        switch kind {
        case .plantToBall:
            guard let rest = football.flatMap(FootballTrack.kickedBallRest) else { return .failure(.noBall) }
            ball = rest
            reference = NormalizedPoint(x: rest.cx, y: rest.cy)
        case .plantToHips:
            guard let l = sample.point(.leftHip), let r = sample.point(.rightHip) else { return .failure(.noPose) }
            reference = NormalizedPoint(x: (l.x + r.x) / 2, y: (l.y + r.y) / 2)
        }
        return .success(MeasurementInspection(
            kind: kind, time: sample.timestamp, reference: reference, ankle: NormalizedPoint(x: plant.x, y: plant.y), ball: ball,
            ankleMeasured: plant.status == .measured,
            valueText: DisplayFormat.lateral(storedValue, unit: .bodyLengths),
            note: kind == .plantToBall
                ? "Sideways distance between the football's center and the plant ankle at contact (median of the contact frame and its neighbours), in torso lengths. Distance toward or away from the camera can't be seen."
                : "Sideways distance between the hips' center and the plant ankle at contact, in torso lengths."
        ))
    }
}
