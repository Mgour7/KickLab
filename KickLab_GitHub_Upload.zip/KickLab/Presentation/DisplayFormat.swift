import Foundation

/// A score band shown as text as well as color, so scores never rely on color alone.
enum ScoreGrade: String, Equatable, Sendable {
    case excellent
    case good
    case fair
    case needsWork
    case unavailable

    init(score: Double?) {
        guard let score else { self = .unavailable; return }
        switch score {
        case 85...: self = .excellent
        case 70..<85: self = .good
        case 50..<70: self = .fair
        default: self = .needsWork
        }
    }

    var label: String {
        switch self {
        case .excellent: "Excellent"
        case .good: "Good"
        case .fair: "Fair"
        case .needsWork: "Needs work"
        case .unavailable: "Not scored"
        }
    }
}

extension ScoreGrade {
    /// Step 12C: a grade word is only as strong as the evidence behind it. With low or
    /// insufficient confidence the grade is labeled tentative, so "Excellent" built on
    /// thin evidence never reads as a conclusive verdict.
    func label(confidence: Double?) -> String {
        guard self != .unavailable else { return label }
        switch ConfidenceLevel(confidence) {
        case .high, .medium: return label
        case .low, .insufficient: return "\(label) · tentative"
        }
    }
}

/// Locale-independent, deterministic formatting for user-facing values.
enum DisplayFormat {
    static let missing = "—"

    static func number(_ value: Double, digits: Int) -> String {
        let text = String(format: "%.\(max(0, digits))f", value)
        // Avoid "-0" / "-0.00".
        if text.hasPrefix("-"), let parsed = Double(text), parsed == 0 { return String(text.dropFirst()) }
        return text
    }

    /// 0–100 score as a whole number.
    static func score(_ score: Double?) -> String {
        guard let score, score.isFinite else { return missing }
        return number(score, digits: 0)
    }

    /// A 0...1 fraction as a whole percentage.
    static func percent(fraction: Double?) -> String {
        guard let fraction, fraction.isFinite else { return missing }
        return number(fraction * 100, digits: 0) + "%"
    }

    /// A 0...100 value as a percentage with one decimal when needed.
    static func percentage(_ value: Double?) -> String {
        guard let value, value.isFinite else { return missing }
        let rounded = (value * 10).rounded() / 10
        let digits = rounded == rounded.rounded() ? 0 : 1
        return number(rounded, digits: digits) + "%"
    }

    static func confidenceLabel(_ confidence: Double?) -> String {
        switch ConfidenceLevel(confidence) {
        case .high: "High confidence"
        case .medium: "Medium confidence"
        case .low: "Low confidence"
        case .insufficient: "Not enough data"
        }
    }

    /// "High confidence · 82%".
    static func confidence(_ confidence: Double?) -> String {
        guard let confidence, confidence.isFinite else { return confidenceLabel(nil) }
        return confidenceLabel(confidence) + " · " + percent(fraction: confidence)
    }

    static func statusLabel(_ status: MeasurementStatus) -> String {
        switch status {
        case .measured: "Measured"
        case .estimated: "Estimated"
        case .unavailable: "Not available"
        }
    }

    /// Decimal places shown for each unit.
    static func digits(for unit: MetricUnit) -> Int {
        switch unit {
        case .degrees, .percent, .degreesPerSecond: 0
        case .seconds: 2
        case .milliseconds: 0
        case .bodyLengths: 2
        case .bodyLengthsPerSecond: 1
        case .yards, .inches, .centimeters, .meters, .metersPerSecond, .milesPerHour: 1
        case .ratio, .unitless, .unknown: 2
        }
    }

    /// The unit text shown after a value ("" when none).
    static func unitText(_ unit: MetricUnit) -> String {
        switch unit {
        case .degrees: "°"
        case .percent: "%"
        case .unitless, .ratio, .unknown: ""
        default: unit.displayName
        }
    }

    /// "0.20 s", "35°", "1.6 torso lengths/s", or "—".
    static func metricValue(_ value: Double?, unit: MetricUnit) -> String {
        guard let value, value.isFinite else { return missing }
        let text = number(value, digits: digits(for: unit))
        let suffix = unitText(unit)
        switch unit {
        case .degrees, .percent: return text + suffix
        default: return suffix.isEmpty ? text : text + " " + suffix
        }
    }

    /// Build 19: sideways measurements whose sign is a SIDE, not "more / less".
    static let signedLateralMetrics: Set<KickMetricKey> = [.plantBallLateralOffset, .plantFootWidth, .lateralTrunkLeanAtContact]

    /// "0.71 torso lengths · plant-leg side" — the magnitude with the side in words, so a
    /// negative sign is never shown on its own.
    static func lateral(_ value: Double?, unit: MetricUnit) -> String {
        guard let value, value.isFinite else { return missing }
        let magnitude = metricValue(abs(value), unit: unit)
        if abs(value) < 0.005 { return magnitude + " · centered" }
        return magnitude + (value > 0 ? " · plant-leg side" : " · kicking-leg side")
    }

    static func yards(_ value: Double?) -> String {
        guard let value, value.isFinite else { return missing }
        return number(value, digits: 0) + " yd"
    }

    static func seconds(_ value: Double?) -> String {
        guard let value, value.isFinite else { return missing }
        return number(value, digits: 2) + " s"
    }

    /// "4 of 5" style ratio.
    static func ratio(_ part: Int, of whole: Int) -> String {
        "\(part) of \(whole)"
    }

    /// Fixed, unambiguous date text (yyyy-MM-dd) for logic and tests; views use the
    /// system's localized formatters instead.
    static func isoDay(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}

extension AnalysisCategory {
    /// User-facing category title (the stored `.contact` category scores body position).
    var presentationTitle: String {
        switch self {
        case .contact: "Body Position at Contact"
        default: displayName
        }
    }
}
