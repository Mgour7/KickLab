import Foundation

// Build 18 — Coaching Intelligence: evidence-based coaching insights.
//
// Every insight shown to an athlete is traceable: which measurement supports it, how good
// that measurement was, which kick types and camera views the rule applies to, how the
// measurement is interpreted, the cue, which measurement to monitor next time, and why the
// insight was eligible. Deterministic and local; no cloud service.

/// What an insight is, from strongest to weakest.
enum CoachingInsightClass: String, Equatable, Sendable {
    /// The supporting measurement was high quality (confidence ≥ 0.75).
    case confirmedObservation
    /// Medium-quality supporting measurement (0.5–0.75): shown, labelled provisional,
    /// never phrased as a firm correction.
    case provisionalObservation
    /// Advice about the recording, not the technique.
    case recordingRecommendation
    /// Not enough evidence to say anything (never shown as advice).
    case insufficientEvidence

    var title: String {
        switch self {
        case .confirmedObservation: "Confirmed observation"
        case .provisionalObservation: "Provisional observation"
        case .recordingRecommendation: "Recording recommendation"
        case .insufficientEvidence: "Insufficient evidence"
        }
    }
}

/// What kind of kick a coaching rule — or an analysis goal — applies to.
enum KickGoal: Equatable, Sendable {
    case placeKickAccuracy
    case kickoffDistance
    case puntHangAndPlacement
    case unknown

    init(_ kickType: KickType) {
        switch kickType {
        case .fieldGoal, .pat: self = .placeKickAccuracy
        case .kickoff: self = .kickoffDistance
        case .punt: self = .puntHangAndPlacement
        default: self = .unknown
        }
    }

    /// One line on what the analysis looks for with this kick type.
    var summary: String {
        switch self {
        case .placeKickAccuracy: "Field goals and PATs: a repeatable plant and a body position that keeps the strike consistent."
        case .kickoffDistance: "Kickoffs: a fast, controlled run-up that carries speed into a full swing."
        case .puntHangAndPlacement: "Punts: a full, high leg swing and a finish through the ball (the drop itself isn't measured)."
        case .unknown: "Kick type not set: mechanics are described but not compared with a kick-specific goal."
        }
    }

    /// The areas that matter most for this goal, in order (used to order the report).
    var priorityAreas: [AnalysisCategory] {
        switch self {
        case .placeKickAccuracy: [.plant, .contact, .swing, .approach, .followThrough]
        case .kickoffDistance: [.approach, .swing, .plant, .contact, .followThrough]
        case .puntHangAndPlacement: [.swing, .followThrough, .contact, .approach, .plant]
        case .unknown: KickMetricCatalog.scoredCategories
        }
    }
}

/// One coaching rule's evidence contract.
struct CoachingRuleSpec: Equatable, Sendable {
    var rule: CoachingRuleKey
    var title: String
    var supportingMetric: KickMetricKey
    var kickTypes: Set<KickType>
    var views: Set<ComparableView>
    /// How the measurement is interpreted.
    var interpretation: String
    /// The metric to watch next time.
    var monitor: KickMetricKey
    /// 3 = shapes the whole kick, 1 = finishing detail. Breaks ties after evidence quality.
    var impact: Int
}

struct CoachingInsight: Equatable, Sendable, Identifiable {
    var id: UUID
    var rule: CoachingRuleKey
    var isImprovement: Bool
    var category: AnalysisCategory
    var title: String
    var observed: String
    var interpretation: String
    var cue: String?
    var insightClass: CoachingInsightClass
    var supportingMetricName: String
    var supportingValueText: String?
    var measurementQuality: String
    var monitorMetricName: String
    var eligibility: String
    var impact: Int
}

enum CoachingInsightBuilder {
    static let placeKicks: Set<KickType> = [.fieldGoal, .pat, .kickoff]
    static let allKicks: Set<KickType> = [.fieldGoal, .pat, .kickoff, .punt]

    /// The rules that may be shown. `plantLate` / `plantEarly` are deliberately absent:
    /// no validated criterion supports plant-timing advice (Build 18), so they are never
    /// shown — not even from analyses made before engine 3.0.0 that issued them.
    static let catalog: [CoachingRuleKey: CoachingRuleSpec] = [
        .plantUnstable: CoachingRuleSpec(rule: .plantUnstable, title: "Plant foot moved through the strike", supportingMetric: .plantFootDrift,
                                         kickTypes: placeKicks, views: [.side],
                                         interpretation: "The plant ankle moved more than 0.3 torso lengths within 0.1 s of contact (side view).",
                                         monitor: .plantFootDrift, impact: 3),
        .plantStable: CoachingRuleSpec(rule: .plantStable, title: "Stable plant", supportingMetric: .plantFootDrift,
                                       kickTypes: placeKicks, views: [.side],
                                       interpretation: "The plant ankle stayed within 0.1 torso lengths around contact.",
                                       monitor: .plantFootDrift, impact: 3),
        .limitedKneeExtension: CoachingRuleSpec(rule: .limitedKneeExtension, title: "Kicking knee bent at contact", supportingMetric: .kickingKneeAngleAtContact,
                                                kickTypes: allKicks, views: [.side],
                                                interpretation: "The kicking knee's 2D angle at contact was under 130° (side view).",
                                                monitor: .kickingKneeAngleAtContact, impact: 3),
        .fullKneeExtension: CoachingRuleSpec(rule: .fullKneeExtension, title: "Leg extended through the ball", supportingMetric: .kickingKneeAngleAtContact,
                                             kickTypes: allKicks, views: [.side],
                                             interpretation: "The kicking knee was at least 160° at contact.",
                                             monitor: .kickingKneeAngleAtContact, impact: 3),
        .torsoLeaningBack: CoachingRuleSpec(rule: .torsoLeaningBack, title: "Leaning back at contact", supportingMetric: .torsoLeanAtContact,
                                            kickTypes: placeKicks, views: [.side],
                                            interpretation: "The trunk leaned back more than 25° from vertical at contact (side view; place kicks only).",
                                            monitor: .torsoLeanAtContact, impact: 2),
        .torsoLeaningForward: CoachingRuleSpec(rule: .torsoLeaningForward, title: "Leaning forward at contact", supportingMetric: .torsoLeanAtContact,
                                               kickTypes: placeKicks, views: [.side],
                                               interpretation: "The trunk leaned forward more than 15° at contact (side view; place kicks only).",
                                               monitor: .torsoLeanAtContact, impact: 2),
        .approachSpeedChange: CoachingRuleSpec(rule: .approachSpeedChange, title: "Speed changed sharply into the plant", supportingMetric: .approachLateSpeedChange,
                                               kickTypes: placeKicks, views: [.side, .other],
                                               interpretation: "Approach speed in the last 0.2 s before the plant changed by more than 35% (kickoffs 45%).",
                                               monitor: .approachLateSpeedChange, impact: 2),
        .followThroughShort: CoachingRuleSpec(rule: .followThroughShort, title: "Follow-through stopped early", supportingMetric: .followThroughDuration,
                                              kickTypes: allKicks, views: [.side, .depth, .other],
                                              interpretation: "The kicking foot slowed to a quarter of its peak speed within 0.12 s of contact.",
                                              monitor: .followThroughDuration, impact: 1),
        .highFinish: CoachingRuleSpec(rule: .highFinish, title: "High finish", supportingMetric: .followThroughFootHeight,
                                      kickTypes: allKicks, views: [.side],
                                      interpretation: "The kicking ankle rose at least one torso length above the hip after contact.",
                                      monitor: .followThroughFootHeight, impact: 1),
    ]

    /// Insights from a stored analysis's observations, each checked against its rule's
    /// evidence contract. Ineligible observations are dropped (never softened into advice).
    static func make(observations: [StoredObservationRecord], metrics: [MetricRowPresentation], kickType: KickType,
                     view: ComparableView) -> [CoachingInsight] {
        let cues = observations.filter { $0.kind == .cue }
        var out: [CoachingInsight] = []
        for o in observations where o.kind == .improve || o.kind == .keep {
            guard let key = o.ruleKey.flatMap(CoachingRuleKey.init(rawValue:)), let spec = catalog[key] else { continue }
            guard spec.kickTypes.contains(kickType), spec.views.contains(view) else { continue }
            guard let metric = metrics.first(where: { $0.key == spec.supportingMetric }), metric.isAvailable, let c = metric.confidence else { continue }
            let insightClass: CoachingInsightClass = c >= 0.75 ? .confirmedObservation : (c >= 0.5 ? .provisionalObservation : .insufficientEvidence)
            guard insightClass != .insufficientEvidence else { continue }
            let parts = AnalysisPresentationBuilder.splitMessage(o.message)
            let cue = o.kind == .improve ? cues.first { $0.relatedObservationID == o.id }?.message : nil
            if o.kind == .improve, cue == nil { continue }
            let monitor = spec.monitor.definition.displayName
            out.append(CoachingInsight(
                id: o.id, rule: key, isImprovement: o.kind == .improve, category: o.category, title: spec.title,
                observed: parts.observed, interpretation: spec.interpretation, cue: cue, insightClass: insightClass,
                supportingMetricName: metric.name, supportingValueText: metric.valueText, measurementQuality: PerformanceReport.Quality(confidence: c).title,
                monitorMetricName: monitor,
                eligibility: "Measured \(metric.name.lowercased()) (\(metric.valueText)) with \(PerformanceReport.Quality(confidence: c).title.lowercased()) quality; the rule applies to \(view.title.lowercased()) recordings of this kick type.",
                impact: spec.impact
            ))
        }
        let goal = KickGoal(kickType)
        func areaRank(_ c: AnalysisCategory) -> Int { goal.priorityAreas.firstIndex(of: c) ?? 9 }
        return out.sorted { a, b in
            if a.insightClass != b.insightClass { return a.insightClass == .confirmedObservation }
            if a.impact != b.impact { return a.impact > b.impact }
            if areaRank(a.category) != areaRank(b.category) { return areaRank(a.category) < areaRank(b.category) }
            return a.rule.rawValue < b.rule.rawValue
        }
    }
}
