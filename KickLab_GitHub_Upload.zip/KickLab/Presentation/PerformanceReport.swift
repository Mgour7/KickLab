import Foundation

// Build 16 — Performance Report 2.0 (the athlete-facing Quick Report and its data).
//
// Built only from what the analysis stored. Rules (see Docs/SCORING_AUDIT.md):
// - Scores are PROVISIONAL TECHNIQUE INDICATORS on a 0–100 scale, shown as whole numbers.
//   A score of 97 is not 97% confidence and not the 97th percentile.
// - The overall score is shown only when the engine produced one (≥ 3 scored areas) from a
//   completed analysis whose analysis quality isn't "not available".
// - "Not rated" is never zero, never low and never ranked.
// - Rankings compare only the athlete's own comparable kicks (`PersonalRanking`). No
//   percentiles, population benchmarks or targets: no documented dataset exists for them.
// - The kick's result (made / missed, distance) is what the user entered, labelled as such,
//   and is kept apart from the technique score.

struct PerformanceReport: Equatable, Sendable {
    /// Documented label bands (provisional; the same cut points the app has used since
    /// Step 8): Excellent ≥ 85, Good 70–84, Developing 50–69, Needs Work < 50.
    enum Label: String, Equatable, Sendable, CaseIterable {
        case excellent, good, developing, needsWork

        init(score: Double) {
            switch score.rounded() {
            case 85...: self = .excellent
            case 70..<85: self = .good
            case 50..<70: self = .developing
            default: self = .needsWork
            }
        }

        var title: String {
            switch self {
            case .excellent: "Excellent"
            case .good: "Good"
            case .developing: "Developing"
            case .needsWork: "Needs Work"
            }
        }

        static let criteria = "Excellent 85–100 · Good 70–84 · Developing 50–69 · Needs Work 0–49 (provisional bands)"
    }

    /// How much the analysis could see. Rule-based, never a probability.
    enum Quality: String, Equatable, Sendable {
        case good, fair, limited, unavailable

        init(confidence: Double?) {
            switch ConfidenceLevel(confidence) {
            case .high: self = .good
            case .medium: self = .fair
            case .low: self = .limited
            case .insufficient: self = .unavailable
            }
        }

        var title: String {
            switch self {
            case .good: "Good"
            case .fair: "Fair"
            case .limited: "Limited"
            case .unavailable: "Not available"
            }
        }

        var rank: Int {
            switch self {
            case .good: 3
            case .fair: 2
            case .limited: 1
            case .unavailable: 0
            }
        }
    }

    struct Headline: Equatable, Sendable {
        var kickTypeText: String
        var viewText: String
        var quality: Quality
        /// Rounded overall score, nil when unavailable.
        var score: Int?
        var label: Label?
        /// Shown instead of a score ("Partial Analysis — Overall Score Unavailable", …).
        var unavailableTitle: String?
        var unavailableDetail: String?
        /// "Automatic", "User-assisted" …
        var modeText: String
        var isUserAssisted: Bool
    }

    struct CategoryRow: Equatable, Sendable, Identifiable {
        var category: AnalysisCategory
        var title: String
        var score: Int?
        var label: Label?
        var quality: Quality
        var standing: PersonalRanking.Standing
        /// One short reason when not rated.
        var notRatedReason: String?
        var id: String { category.rawValue }

        var statusText: String { label?.title ?? "Not rated" }
        var accessibilityText: String {
            guard let score, let label else { return "\(title): not rated. \(notRatedReason ?? "")" }
            return "\(title): \(score) out of 100, \(label.title). \(standing.text). Measurement quality \(quality.title)."
        }
    }

    struct Strength: Equatable, Sendable, Identifiable {
        var id: String
        var title: String
        var detail: String
    }

    struct Issue: Equatable, Sendable, Identifiable {
        var id: String
        var title: String
        var observed: String
        var cue: String
    }

    struct TrainingFocus: Equatable, Sendable, Identifiable {
        var id: String
        var title: String
        var practice: String
        var why: String
        var measurement: String
    }

    var headline: Headline
    var categories: [CategoryRow]
    var strengths: [Strength]
    var issues: [Issue]
    var focus: [TrainingFocus]
    /// Set instead of drills when the analysis is too limited to coach from.
    var recordingAdvice: [String]
    var history: PersonalRanking.History?
    /// The user-entered result, kept apart from the technique score.
    var outcomeText: String?
    var strongest: CategoryRow?
    var weakest: CategoryRow?
    var footnote: String

    static let outcomeLabel = "Result (entered by you)"
    static let provisionalNote = "Technique scores are provisional indicators from body-pose measurements — not percentiles, probabilities or predictions of the kick's result."

    struct Input: Sendable {
        var presentation: AnalysisResultsPresentation
        var record: AnalysisRecord
        var view: ComparableView
        /// The other kicks' saved analyses (any type or view; eligibility is applied here).
        var others: [RankingEntry]
        var suitability: [SuitabilityFinding] = []
        /// The user-entered result ("Made · 35 yd"), nil when none was entered.
        var outcomeText: String? = nil
    }

    static let defaultRecordingAdvice = [
        "Film from the side at hip height, 10–15 yards away, with the whole body and ball in frame.",
        "Keep the phone still (a tripod or a friend) from the run-up to the end of the follow-through.",
        "Use the highest frame rate your phone offers (60 fps or more) in good light.",
    ]

    static func make(_ input: Input) -> PerformanceReport {
        let p = input.presentation
        let record = input.record
        let assisted = AnalysisAssistanceLabel.isAssisted(record.engineVersion)
        let current = RankingEntry(id: record.id, kickID: record.kickID, date: record.kickDate ?? record.date, kickType: record.kickType,
                                   view: input.view, engineVersion: record.engineVersion, completed: record.status == .completed,
                                   overallScore: record.status == .completed ? record.overallScore : nil,
                                   categoryScores: Dictionary(uniqueKeysWithValues: p.categories.compactMap { c in c.score.map { (c.category, $0) } }))
        let eligibility = PersonalRanking.eligibility(for: current, among: input.others)

        // Analysis quality.
        var quality = Quality(confidence: p.header.confidence)
        if record.status != .completed { quality = .unavailable }
        if input.suitability.contains(where: { $0.severity == .blocking }) { quality = min(quality, .limited) }
        if quality == .unavailable, record.status == .completed, p.metrics.contains(where: \.isAvailable) { quality = .limited }

        // Overall score gate.
        let scoredCount = p.categories.filter { $0.score != nil }.count
        let minimumAreas = BiomechanicsProfile.standard(for: record.kickType).minimumCategoriesForOverall
        var score: Int?
        var unavailableTitle: String?
        var unavailableDetail: String?
        if record.status != .completed {
            switch p.header.outcome {
            case .noKickDetected?: unavailableTitle = "No Kick Found"
            case .kickDetectedTimingUncertain?: unavailableTitle = "Contact Not Found — No Score"
            case .insufficientEvidence?: unavailableTitle = "Recording Too Limited — No Score"
            case .technicalFailure?: unavailableTitle = "Analysis Didn't Run"
            default: unavailableTitle = record.status == .failed ? "Analysis Incomplete — No Score" : "Analysis In Progress"
            }
            unavailableDetail = p.header.outcome?.explanation ?? p.problem
        } else if let overall = record.overallScore, scoredCount >= minimumAreas, quality != .unavailable {
            score = Int(overall.rounded())
        } else {
            unavailableTitle = "Partial Analysis — Overall Score Unavailable"
            unavailableDetail = "\(scoredCount) of \(p.categories.count) areas rated; an overall score needs at least \(minimumAreas)."
        }
        let headline = Headline(kickTypeText: p.header.kickTypeText, viewText: input.view.title, quality: quality,
                                score: score, label: score.map { Label(score: Double($0)) },
                                unavailableTitle: unavailableTitle, unavailableDetail: unavailableDetail,
                                modeText: assisted ? "User-assisted" : (record.status == .completed ? "Automatic" : "Not completed"),
                                isUserAssisted: assisted)

        // Categories.
        let rows: [CategoryRow] = p.categories.map { c in
            let s = c.score.map { Int($0.rounded()) }
            let reason: String? = {
                guard c.score == nil else { return nil }
                if record.status != .completed { return "Analysis didn't finish" }
                let measured = c.topMetrics.count
                return measured == 0 ? "Not measured from this recording" : "Too few measurements to rate"
            }()
            return CategoryRow(category: c.category, title: c.title, score: s, label: c.score.map { Label(score: $0) },
                               quality: c.score == nil ? .unavailable : Quality(confidence: c.confidence),
                               standing: record.status == .completed ? PersonalRanking.categoryStanding(c.category, current: current, eligibility: eligibility)
                                                                     : PersonalRanking.Standing(rank: nil, outOf: 0, text: "Not rated"),
                               notRatedReason: reason)
        }
        let rated = rows.filter { $0.score != nil && $0.quality.rank >= Quality.fair.rank }
        let strongest = rated.max { ($0.score ?? 0, $1.title) < ($1.score ?? 0, $0.title) }
        let weakest = rated.count >= 2 ? rated.min { ($0.score ?? 0, $0.title) < ($1.score ?? 0, $1.title) } : nil

        // Strengths: measured KEEP findings first, then rated areas scoring Good or better.
        var strengths: [Strength] = p.strengths.prefix(3).map { Strength(id: "keep-\($0.id)", title: $0.categoryTitle, detail: $0.observed) }
        for r in rated.sorted(by: { ($0.score ?? 0) > ($1.score ?? 0) }) where strengths.count < 3 {
            guard let s = r.score, s >= 70, !strengths.contains(where: { $0.title == r.title }) else { continue }
            strengths.append(Strength(id: "area-\(r.id)", title: r.title, detail: "\(s) · \(r.label?.title ?? "")"))
        }
        if record.status != .completed { strengths = [] }

        // Issues: measured IMPROVE findings with a cue.
        let issues: [Issue] = record.status != .completed ? [] : p.priorities.compactMap { item in
            guard let cue = item.cue, !cue.isEmpty else { return nil }
            return Issue(id: "\(item.id)", title: item.categoryTitle, observed: item.observed, cue: cue)
        }.prefix(3).map { $0 }

        // Next training focus.
        var focus: [TrainingFocus] = []
        var advice: [String] = []
        if record.status != .completed || quality == .limited || quality == .unavailable {
            advice = input.suitability.filter { $0.severity != .info }.prefix(3).map(\.message)
            if advice.isEmpty { advice = defaultRecordingAdvice }
        } else {
            for item in p.priorities.prefix(2) {
                guard let drill = DrillLibrary.relatedDrill(for: item.category, kickType: record.kickType) else { continue }
                focus.append(TrainingFocus(id: "\(item.id)", title: drill.title,
                                           practice: drill.instructions.first ?? drill.purpose,
                                           why: item.observed,
                                           measurement: measurementName(item.evidenceMetricKeys, category: item.category, metrics: p.metrics)))
            }
            if focus.isEmpty, let w = weakest, let drill = DrillLibrary.relatedDrill(for: w.category, kickType: record.kickType) {
                focus.append(TrainingFocus(id: "weakest-\(w.id)", title: drill.title, practice: drill.instructions.first ?? drill.purpose,
                                           why: "\(w.title) was your lowest-rated area this kick (\(w.score ?? 0)).",
                                           measurement: measurementName([], category: w.category, metrics: p.metrics)))
            }
        }

        let history: PersonalRanking.History? = record.status == .completed ? PersonalRanking.history(current: current, eligibility: eligibility) : nil
        return PerformanceReport(
            headline: headline, categories: rows, strengths: strengths, issues: issues, focus: Array(focus.prefix(2)),
            recordingAdvice: advice, history: history, outcomeText: input.outcomeText,
            strongest: strongest, weakest: weakest,
            footnote: provisionalNote + " Scoring model \(ScoringModel.version(ofEngine: record.engineVersion) ?? "earlier (not compared)") · \(record.engineVersion)."
        )
    }

    /// The measurement that should change: the finding's first measured metric, else the
    /// category's most confident one.
    static func measurementName(_ keys: [String], category: AnalysisCategory, metrics: [MetricRowPresentation]) -> String {
        for k in keys {
            if let m = metrics.first(where: { $0.key.rawValue == k }) { return m.name }
        }
        return metrics.filter { $0.category == category && $0.isAvailable }
            .max { ($0.confidence ?? 0) < ($1.confidence ?? 0) }?.name ?? "\(category.presentationTitle) score"
    }

    /// The single most useful thing to practice next (the Quick Report's last line).
    var nextStep: String? {
        if let f = focus.first { return f.title }
        if !recordingAdvice.isEmpty { return "Record a clearer clip" }
        return nil
    }
}

extension PerformanceReport.Quality: Comparable {
    static func < (a: Self, b: Self) -> Bool { a.rank < b.rank }
}

// MARK: - Detailed Analysis (level 2)

/// Build 16: everything measured, for the "Detailed Analysis" screen. Short reasons only.
struct DetailedAnalysisReport: Equatable, Sendable {
    struct Area: Equatable, Sendable, Identifiable {
        var row: PerformanceReport.CategoryRow
        var metrics: [MetricRowPresentation]
        var unmeasured: [String]
        var id: String { row.id }
    }

    var areas: [Area]
    var history: PersonalRanking.History?
    var timing: [String]
    var notes: [String]

    static func make(report: PerformanceReport, presentation: AnalysisResultsPresentation, timing: [String]) -> DetailedAnalysisReport {
        let byCategory = Dictionary(grouping: presentation.metrics, by: \.category)
        let cards = Dictionary(uniqueKeysWithValues: presentation.categories.map { ($0.category, $0) })
        return DetailedAnalysisReport(
            areas: report.categories.map { row in
                Area(row: row, metrics: (byCategory[row.category] ?? []).filter(\.isAvailable),
                     unmeasured: cards[row.category]?.unavailableMetricNames ?? [])
            },
            history: report.history, timing: timing,
            notes: presentation.notes + [PerformanceReport.Label.criteria]
        )
    }
}
