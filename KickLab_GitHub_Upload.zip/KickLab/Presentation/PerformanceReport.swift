import Foundation

// Athlete Report 5.0 (Build 20; 3.0 in Build 18) — the athlete-facing Quick Report.
//
// Build 20 separates three independent evaluations that are never combined into one number:
// - TECHNIQUE: the provisional area scores (unchanged rules), or "Not graded" with why;
// - CONSISTENCY: the athlete's own repeatability (`ConsistencyModel`), or "Building baseline";
// - RESULTS: what the athlete recorded (made/missed, distance, sessions) — never inferred.
// Key findings (≤ 3) come from reliable differences from the athlete's usual values,
// repeatable patterns, supported strengths and tracking limits that change interpretation.
//
// Built only from what the analysis stored (read-only). The report ADAPTS to the evidence:
// - the kick's recorded RESULT (entered by the athlete) comes first;
// - a provisional technique score appears only when it is defensible (completed analysis,
//   ≥ 3 rated areas, analysis quality at least Fair); otherwise "Limited Technique Analysis"
//   with the measurements that WERE established and one recording recommendation;
// - rated areas first; useful measurements that don't make a score next; areas that
//   couldn't be rated are collapsed under "Measurements not available";
// - at most two strengths (each with a reason from supported measurements), two
//   improvements (only evidence-backed coaching insights) and ONE training priority;
// - engine/scoring identifiers, disclaimers and methodology live in Detailed Analysis.
// Scores are provisional technique indicators on a 0–100 scale (whole numbers); a score
// of 97 is not 97% confidence or the 97th percentile. No percentiles, benchmarks or
// targets anywhere (no documented dataset exists for them).

struct PerformanceReport: Equatable, Sendable {
    /// Documented label bands (provisional): Excellent ≥ 85, Good 70–84, Developing 50–69,
    /// Needs Work < 50, applied to the rounded score.
    enum Label: String, Equatable, Sendable, CaseIterable {
        case excellent, good, developing, needsWork

        init(score: Double) {
            switch score.rounded() {
            case 85...: self = .excellent
            case 70..<85: self = .good
            case 50..<70: self = .developing
            default: self = .needsWork
            }
        }

        var title: String {
            switch self {
            case .excellent: "Excellent"
            case .good: "Good"
            case .developing: "Developing"
            case .needsWork: "Needs Work"
            }
        }

        static let criteria = "Excellent 85–100 · Good 70–84 · Developing 50–69 · Needs Work 0–49 (provisional bands)"
    }

    /// Measurement / analysis quality. Rule-based levels from confidence, never probabilities.
    enum Quality: String, Equatable, Sendable {
        case good, fair, limited, unavailable

        init(confidence: Double?) {
            switch ConfidenceLevel(confidence) {
            case .high: self = .good
            case .medium: self = .fair
            case .low: self = .limited
            case .insufficient: self = .unavailable
            }
        }

        var title: String {
            switch self {
            case .good: "Good"
            case .fair: "Fair"
            case .limited: "Limited"
            case .unavailable: "Not available"
            }
        }

        var rank: Int {
            switch self {
            case .good: 3
            case .fair: 2
            case .limited: 1
            case .unavailable: 0
            }
        }
    }

    enum AnalysisState: String, Equatable, Sendable {
        case automatic, userAssisted, incomplete

        var title: String {
            switch self {
            case .automatic: "Automatic analysis"
            case .userAssisted: "User-assisted analysis"
            case .incomplete: "Analysis incomplete"
            }
        }
    }

    struct Header: Equatable, Sendable {
        var kickTypeText: String
        /// "Made · 40 yd", or "Outcome not recorded".
        var outcomeText: String
        var outcomeRecorded: Bool
        var viewText: String
        var state: AnalysisState
        /// Build 20: contact detection quality in words ("Contact: high confidence").
        var contactQualityText: String? = nil
    }

    /// Build 20: the Technique summary — a provisional score, or "Not graded" and why.
    struct TechniqueSummary: Equatable, Sendable {
        var graded: Bool
        /// "80 · Good" or "Not graded".
        var text: String
        var detail: String
    }

    /// Build 20: one key finding on the Quick Report.
    struct Finding: Equatable, Sendable, Identifiable {
        enum Kind: String, Equatable, Sendable {
            /// A reliable difference from the athlete's own usual value.
            case differenceFromUsual
            /// A measurement the athlete repeats within its meaningful change.
            case repeatablePattern
            /// A strength supported by measurements.
            case strength
            /// A tracking limit that changes how this kick can be read.
            case trackingLimitation
        }
        var kind: Kind
        var title: String
        var detail: String
        var id: String { "\(kind.rawValue)-\(title)" }
    }

    enum Summary: Equatable, Sendable {
        /// A defensible provisional technique score.
        case technique(score: Int, label: Label, quality: Quality)
        /// Some reliable measurements, but no defensible overall score.
        case limited(detail: String)
        /// The analysis didn't produce mechanics ("No Kick Found", …).
        case incomplete(title: String, detail: String?)

        var title: String {
            switch self {
            case .technique: "Technique score"
            case .limited: "Limited Technique Analysis"
            case .incomplete(let title, _): title
            }
        }
    }

    struct AreaRow: Equatable, Sendable, Identifiable {
        var category: AnalysisCategory
        var title: String
        var score: Int
        var label: Label
        var quality: Quality
        var standing: PersonalRanking.Standing
        var id: String { category.rawValue }

        /// Build 19: what the area actually measures, when its name could be over-read.
        var note: String? {
            category == .contact ? "Posture and body movement at contact — not how the foot struck the ball." : nil
        }

        /// Below medium confidence: shown, but clearly marked and never called a strength.
        var isLimitedConfidence: Bool { quality.rank < Quality.fair.rank }

        var accessibilityText: String {
            "\(title): \(score) out of 100, \(label.title)\(isLimitedConfidence ? ", limited confidence" : ""). \(standing.text).\(note.map { " " + $0 } ?? "")"
        }
    }

    struct MeasurementRow: Equatable, Sendable, Identifiable {
        var key: KickMetricKey
        var name: String
        var valueText: String
        var quality: Quality
        /// "Your usual 0.55 torso lengths (SD 0.04, 4 earlier recordings)" when eligible.
        var personalText: String?
        /// Build 19: one short line on what the number means.
        var context: String = ""
        /// Build 19: can be shown over the contact frame (`MeasurementInspection`).
        var inspectable: Bool = false
        /// Build 20: the athlete's usual value, the difference and what it means.
        var usualText: String? = nil
        var differenceText: String? = nil
        var comparison: UsualComparison? = nil
        var interpretation: String? = nil
        /// "Varied by 0.05 torso lengths across 5 comparable kicks" with its level.
        var spreadText: String? = nil
        var id: String { key.rawValue }
    }

    struct Unavailable: Equatable, Sendable, Identifiable {
        var title: String
        var reason: String
        var id: String { title }
    }

    struct Strength: Equatable, Sendable, Identifiable {
        var id: String
        var title: String
        var reason: String
        /// Build 20: strengths are always evidence-based observations.
        var kindLabel: String { CoachingKind.observation.title }
    }

    /// Build 20: what kind of coaching statement an item is.
    enum CoachingKind: String, Equatable, Sendable {
        case observation, provisionalSuggestion, recording
        var title: String {
            switch self {
            case .observation: "Evidence-based observation"
            case .provisionalSuggestion: "Provisional technique suggestion"
            case .recording: "Recording recommendation"
            }
        }
    }

    struct Improvement: Equatable, Sendable, Identifiable {
        var id: String
        var title: String
        var observed: String
        var cue: String
        var insightClass: CoachingInsightClass
        /// Build 19: what was measured, its quality, and why the rule applies here.
        var evidence: String = ""
        /// Build 19: what to watch on the next kick.
        var watch: String = ""

        /// Build 20: a correction is a provisional technique suggestion unless its
        /// supporting measurement was high quality (then it rests on an evidence-based
        /// observation, still provisional as technique advice).
        var kind: CoachingKind {
            switch insightClass {
            case .recordingRecommendation: .recording
            case .confirmedObservation, .provisionalObservation, .insufficientEvidence: .provisionalSuggestion
            }
        }
    }

    /// The single next training priority.
    enum Focus: Equatable, Sendable {
        /// "Next training focus": one drill backed by a measured coaching insight.
        case practice(title: String, cue: String, monitor: String)
        /// "For a better analysis": shown when no technique correction is supported.
        case recording(String)
        /// Build 20 "Next goal": a measurable goal (e.g. build a consistency baseline) when
        /// no technique correction is supported.
        case goal(String)

        var heading: String {
            switch self {
            case .practice: "Next training focus"
            case .recording: "For a better analysis"
            case .goal: "Next goal"
            }
        }

        var line: String {
            switch self {
            case .practice(let title, _, _): title
            case .recording(let s): s
            case .goal(let s): s
            }
        }
    }

    var header: Header
    var summary: Summary
    var areas: [AreaRow]
    var measurements: [MeasurementRow]
    var unavailable: [Unavailable]
    var strengths: [Strength]
    var improvements: [Improvement]
    /// Set when no reliable technique correction could be established.
    var noCorrectionText: String?
    var focus: Focus?
    var comparisonText: String?
    var history: PersonalRanking.History?
    var consistency: PersonalRanking.Consistency?
    /// Build 20: the one-sentence summary at the top ("Kick detected · 4 measurements · …").
    var headline: String = ""
    var technique = TechniqueSummary(graded: false, text: "Not graded", detail: "")
    var consistencyReport: ConsistencyReport? = nil
    var results: KickResultsSummary? = nil
    var keyFindings: [Finding] = []
    /// Recording advice shown as a coaching item when the focus is something else.
    var recordingAdvice: String? = nil
    /// All eligible insights (Detailed Analysis).
    var insights: [CoachingInsight]
    /// Methodology lines (Detailed Analysis only).
    var methodology: [String]

    var strongest: Strength? { strengths.first }
    var mainImprovement: Improvement? { improvements.first }

    static let noCorrection = "No reliable technique correction identified from this recording."
    static let sideRecording = "Record from the side, with the full kicker and football visible and the camera steady."
    static let provisionalNote = "Technique scores are provisional indicators from body-pose measurements — not percentiles, probabilities or predictions of the kick's result."
    static let outcomeLabel = "Entered by you"

    struct Input: Sendable {
        var presentation: AnalysisResultsPresentation
        var record: AnalysisRecord
        var view: ComparableView
        /// The other kicks' saved analyses (eligibility is applied here).
        var others: [RankingEntry]
        var suitability: [SuitabilityFinding] = []
        /// The user-entered result ("Made · 40 yd"), nil when none was entered.
        var outcomeText: String? = nil
        var sessionID: UUID? = nil
        /// Build 19: this recording's quality flags (cropped / blocking finding).
        var recording = RecordingFlags()
        /// Build 20: the athlete's entered results (all kicks), for the Results layer.
        var results: [KickStatRecord] = []
        /// Build 20: contact detection quality in words (nil until the phase file is read).
        var contactQuality: String? = nil
        /// Build 20: tracking limits that change how this kick can be read.
        var trackingNotes: [String] = []
    }

    static func make(_ input: Input) -> PerformanceReport {
        let p = input.presentation
        let record = input.record
        let completed = record.status == .completed
        let assisted = AnalysisAssistanceLabel.isAssisted(record.engineVersion)
        let goal = KickGoal(record.kickType)
        let profile = BiomechanicsProfile.standard(for: record.kickType)
        var current = RankingEntry(id: record.id, kickID: record.kickID, date: record.kickDate ?? record.date, kickType: record.kickType,
                                   view: input.view, engineVersion: record.engineVersion, completed: completed,
                                   overallScore: completed ? record.overallScore : nil,
                                   categoryScores: Dictionary(uniqueKeysWithValues: p.categories.compactMap { c in c.score.map { (c.category, $0) } }),
                                   sessionID: input.sessionID, recording: input.recording)
        current.recording.blocking = current.recording.blocking || input.suitability.contains { $0.severity == .blocking }
        for m in p.metrics where m.isAvailable && (m.confidence ?? 0) >= PersonalRanking.minimumHistoryConfidence {
            if let v = m.value { current.metrics[RankingEntry.metricKey(m.key)] = v }
        }
        let eligibility = PersonalRanking.eligibility(for: current, among: input.others)

        // Analysis quality: the analysis confidence, capped by blocking recording findings.
        var quality = Quality(confidence: p.header.confidence)
        if !completed { quality = .unavailable }
        if input.suitability.contains(where: { $0.severity == .blocking }), quality.rank > Quality.limited.rank { quality = .limited }
        if quality == .unavailable, completed, p.metrics.contains(where: \.isAvailable) { quality = .limited }

        // Header: the result first.
        let header = Header(kickTypeText: p.header.kickTypeText,
                            outcomeText: input.outcomeText ?? "Outcome not recorded", outcomeRecorded: input.outcomeText != nil,
                            viewText: input.view.title,
                            state: !completed ? .incomplete : (assisted ? .userAssisted : .automatic),
                            contactQualityText: input.contactQuality)

        // Rated areas, ordered by what matters for this kick type.
        let order = goal.priorityAreas
        let areas: [AreaRow] = !completed ? [] : p.categories.compactMap { c in
            guard let s = c.score else { return nil }
            return AreaRow(category: c.category, title: c.title, score: Int(s.rounded()), label: Label(score: s),
                           quality: Quality(confidence: c.confidence),
                           standing: PersonalRanking.categoryStanding(c.category, current: current, eligibility: eligibility))
        }.sorted { (order.firstIndex(of: $0.category) ?? 9) < (order.firstIndex(of: $1.category) ?? 9) }

        // Summary.
        let rated = areas.count
        let minimumAreas = profile.minimumCategoriesForOverall
        let summary: Summary
        if !completed {
            let title: String = switch p.header.outcome {
            case .noKickDetected?: "No Kick Found"
            case .kickDetectedTimingUncertain?: "Contact Not Found"
            case .insufficientEvidence?: "Recording Too Limited"
            case .technicalFailure?: "Analysis Didn't Run"
            default: record.status == .failed ? "Analysis Incomplete" : "Analysis In Progress"
            }
            summary = .incomplete(title: title, detail: p.header.outcome?.explanation ?? p.problem)
        } else if let overall = record.overallScore, rated >= minimumAreas, quality.rank >= Quality.fair.rank {
            summary = .technique(score: Int(overall.rounded()), label: Label(score: overall), quality: quality)
        } else {
            let measured = p.metrics.filter { $0.isAvailable }.count
            summary = .limited(detail: rated > 0
                ? "\(rated) area\(rated == 1 ? "" : "s") rated · \(measured) measurement\(measured == 1 ? "" : "s") established"
                : "\(measured) measurement\(measured == 1 ? "" : "s") established · no area could be rated")
        }

        // Insights (evidence-checked), strengths and improvements.
        let insights = completed ? CoachingInsightBuilder.make(observations: input.record.observations, metrics: p.metrics,
                                                              kickType: record.kickType, view: input.view) : []
        let keeps = insights.filter { !$0.isImprovement }.prefix(2)
        var strengths: [Strength] = keeps.map { Strength(id: "keep-\($0.id)", title: $0.title, reason: $0.observed) }
        var covered = Set(keeps.map(\.category))
        for a in areas.sorted(by: { $0.score > $1.score }) where strengths.count < 2 && !a.isLimitedConfidence && a.score >= 70 && !covered.contains(a.category) {
            guard let reason = areaReason(a.category, metrics: p.metrics, profile: profile) else { continue }
            strengths.append(Strength(id: "area-\(a.id)", title: a.title, reason: reason))
            covered.insert(a.category)
        }
        let improvements: [Improvement] = insights.filter(\.isImprovement).prefix(2).compactMap { i in
            i.cue.map { Improvement(id: "\(i.id)", title: i.title, observed: i.observed, cue: $0, insightClass: i.insightClass,
                                    evidence: "Measured \(i.supportingMetricName.lowercased()) \(i.supportingValueText ?? "") · quality \(i.measurementQuality.lowercased()) · \(input.view.title.lowercased()), \(p.header.kickTypeText.lowercased())",
                                    watch: i.monitorMetricName) }
        }

        // Useful measurements that aren't part of a rated area (or every established one
        // when nothing was rated), best quality first: at most 4 (6 from a rear/front view,
        // where they are the analysis).
        let consistency = completed ? PersonalRanking.consistency(current: current, eligibility: eligibility) : nil
        let consistencyReport = completed ? ConsistencyModel.make(current: current, eligibility: eligibility) : nil
        let ratedSet = Set(areas.map(\.category))
        let rowLimit = input.view == .depth ? 6 : 4
        let measurementRows: [MeasurementRow] = !completed ? [] : p.metrics
            .filter { $0.isAvailable && ($0.confidence ?? 0) >= 0.5 && !ratedSet.contains($0.category) && $0.key != .footSpeedAtContact }
            .sorted { a, b in
                let ra = order.firstIndex(of: a.category) ?? 9, rb = order.firstIndex(of: b.category) ?? 9
                if ra != rb { return ra < rb }
                return (a.confidence ?? 0) > (b.confidence ?? 0)
            }
            .prefix(rowLimit)
            .map { m in
                let c = consistency?.metrics.first { $0.key == m.key }
                let a = consistencyReport?.metrics.first { $0.key == m.key }
                return MeasurementRow(key: m.key, name: m.name, valueText: m.valueText, quality: Quality(confidence: m.confidence),
                                      personalText: c.map { u in
                                          let mean = DisplayFormat.signedLateralMetrics.contains(m.key) ? DisplayFormat.lateral(u.mean, unit: m.unit) : DisplayFormat.metricValue(u.mean, unit: m.unit)
                                          return "Your usual \(mean) (SD \(DisplayFormat.number(u.spread, digits: 2)), \(u.count) earlier recording\(u.count == 1 ? "" : "s"))"
                                      },
                                      context: MetricContext.athleteLine(m.key),
                                      inspectable: MeasurementInspection.Kind(metric: m.key) != nil,
                                      usualText: a?.usualText,
                                      differenceText: a?.difference.map { d in a!.signedDifferenceText(d) + " vs usual" },
                                      comparison: a?.current == nil ? nil : a?.comparison,
                                      // No per-row "building baseline" line: the Consistency tile and the
                                      // goal already say it once.
                                      interpretation: {
                                          guard let a, a.current != nil else { return nil }
                                          if case .noBaseline = a.comparison { return nil }
                                          return a.interpretation
                                      }(),
                                      spreadText: a.flatMap { x in x.spreadText.map { "\($0) · \(x.level?.title ?? "")" } })
            }

        // Areas that couldn't be rated, with a short reason each.
        let unavailable: [Unavailable] = !completed ? [] : p.categories.filter { $0.score == nil }.map { c in
            let keys = KickMetricCatalog.keys(in: c.category).filter { profile.scoring[$0].map { $0.weight > 0 } ?? false }
            let measurable = keys.contains { input.view.supports($0) && profile.supportedMetrics.contains($0) }
            if keys.isEmpty {
                // Build 22: an area the profile doesn't grade (the approach since bands-3).
                let shown = p.metrics.contains { $0.category == c.category && $0.isAvailable }
                return Unavailable(title: c.title, reason: shown ? "Measured, not graded: compared with your own kicks" : "Not graded")
            }
            return Unavailable(title: c.title, reason: !measurable ? "Not measurable from this camera view" : "Too few reliable measurements in this recording")
        }

        // One next step: a measured drill; otherwise a measurable goal (build the
        // consistency baseline); otherwise the most useful recording change.
        let tip = recordingTip(view: input.view, suitability: input.suitability)
        let hasRecordingProblem = input.suitability.contains { $0.severity != .info }
        var focus: Focus?
        if let top = insights.first(where: { $0.isImprovement }), let cue = top.cue {
            let drill = DrillLibrary.relatedDrill(for: top.category, kickType: record.kickType)
            focus = .practice(title: drill?.title ?? top.title, cue: cue, monitor: top.monitorMetricName)
        } else if case .technique = summary {
            focus = nil
        } else if !hasRecordingProblem, let goal = consistencyReport?.baselineGoal {
            focus = .goal(goal)
        } else {
            focus = .recording(tip)
        }
        let recordingAdvice: String? = {
            if case .recording = focus { return nil }
            guard completed, hasRecordingProblem || input.view != .side else { return nil }
            return tip
        }()

        // Personal comparison (only with enough comparable history).
        let history = completed ? PersonalRanking.history(current: current, eligibility: eligibility) : nil
        var comparison: String?
        if case .technique = summary, let h = history, h.hasHistory, h.standing.rank != nil {
            comparison = h.isPersonalBest ? "Personal best · \(h.standing.text)" : h.standing.text
            if let t = h.trend { comparison! += " · \(t.text)" }
        } else if let trend = consistency?.improving {
            comparison = trend.text
        }

        // Build 20: the three independent summaries.
        let technique: TechniqueSummary = {
            switch summary {
            case .technique(let score, let label, let q):
                return TechniqueSummary(graded: true, text: "\(score) · \(label.title)", detail: "Provisional · analysis quality \(q.title.lowercased())")
            case .incomplete(let title, _):
                return TechniqueSummary(graded: false, text: "Not graded", detail: title)
            case .limited:
                if input.view == .depth {
                    return TechniqueSummary(graded: false, text: "Not graded", detail: "Technique areas need a side view; this view gives the measurements below")
                }
                if input.view == .other || input.view == .unknown {
                    return TechniqueSummary(graded: false, text: "Not graded", detail: "Technique areas need a side view")
                }
                return TechniqueSummary(graded: false, text: "Not graded",
                                        detail: "\(areas.filter { profile.expectedCategories.contains($0.category) }.count) of \(profile.expectedCategories.count) areas had enough reliable measurements (\(minimumAreas) needed)")
            }
        }()
        let results = KickResultsSummary.make(kickID: record.kickID, sessionID: input.sessionID, kickType: record.kickType,
                                              thisKick: input.outcomeText, records: input.results)
        let findings = completed ? keyFindings(consistency: consistencyReport, rows: measurementRows, strengths: strengths,
                                               trackingNotes: input.trackingNotes) : []
        let headline = completed ? headline(measured: p.metrics.filter(\.isAvailable).count, rated: rated, consistency: consistencyReport,
                                            rows: measurementRows) : summary.title

        let methodology = [
            provisionalNote,
            Label.criteria,
            "Scores combine each area's measurements weighted by their confidence; an overall score needs at least \(minimumAreas) rated areas and Fair analysis quality.",
            "Comparisons use only your own kicks of the same type, from the same camera view, scored with the same rules for that area.",
            "Consistency compares each measurement with your own earlier eligible kicks: a usual value needs \(ConsistencyModel.minimumBaseline) earlier kicks, a spread \(ConsistencyModel.minimumForSpread) kicks; a difference counts only beyond the measurement's meaningful change and twice your usual spread. Different is not worse.",
            "Results are what you entered; they are never inferred from the video or linked to a measurement as a cause.",
            "Scoring model \(ScoringModel.version(ofEngine: record.engineVersion) ?? "earlier (not compared)") · engine \(record.engineVersion).",
            goal.summary,
        ]

        return PerformanceReport(
            header: header, summary: summary, areas: areas, measurements: measurementRows, unavailable: unavailable,
            strengths: strengths, improvements: improvements,
            noCorrectionText: completed && improvements.isEmpty ? noCorrection : nil,
            focus: focus, comparisonText: comparison, history: history, consistency: consistency,
            headline: headline, technique: technique, consistencyReport: consistencyReport, results: results,
            keyFindings: findings, recordingAdvice: recordingAdvice,
            insights: insights, methodology: methodology
        )
    }

    /// Build 20: one sentence built only from what was measured and compared.
    static func headline(measured: Int, rated: Int, consistency: ConsistencyReport?, rows: [MeasurementRow]) -> String {
        var s = "Kick detected · \(measured) measurement\(measured == 1 ? "" : "s")"
        if rated > 0 { s += " · \(rated) area\(rated == 1 ? "" : "s") rated" }
        let compared = rows.filter { $0.comparison != nil }
        let within = compared.filter { $0.comparison == .withinUsual }.map { $0.name.lowercased() }
        let outside = compared.filter { $0.comparison?.isNotable == true }.map { $0.name.lowercased() }
        var clauses: [String] = []
        if !within.isEmpty { clauses.append(list(within.prefix(2)) + " within your usual range") }
        if !outside.isEmpty { clauses.append(list(outside.prefix(2)) + " outside your usual range") }
        if clauses.isEmpty, case .buildingBaseline(let have, let need)? = consistency?.status {
            clauses.append("building your baseline (\(have) of \(need) comparable kicks)")
        }
        if !clauses.isEmpty { s += ". " + clauses.joined(separator: "; ").prefix(1).uppercased() + String(clauses.joined(separator: "; ").dropFirst()) + "." }
        return s
    }

    private static func list<S: Sequence>(_ items: S) -> String where S.Element == String {
        let a = Array(items)
        return a.count <= 1 ? (a.first ?? "") : a.dropLast().joined(separator: ", ") + " and " + a.last!
    }

    /// Build 20: up to three findings, most informative first: reliable differences from
    /// the athlete's usual values, repeatable patterns, a supported strength, then tracking
    /// limits that change interpretation. Nothing generic is added to fill the list.
    static func keyFindings(consistency: ConsistencyReport?, rows: [MeasurementRow], strengths: [Strength],
                            trackingNotes: [String]) -> [Finding] {
        var out: [Finding] = []
        for a in consistency?.notable ?? [] {
            guard let d = a.difference, let usual = a.usualMean else { continue }
            out.append(Finding(kind: .differenceFromUsual, title: a.name,
                               detail: "\(a.interpretation) (\(a.signedDifferenceText(d)); usual \(a.text(usual)) over \(a.earlier.count) kicks)"))
        }
        let repeatable = (consistency?.assessed ?? []).filter { $0.level != .variable && !$0.comparison.isNotable }
            .sorted { ($0.spreadCount, $0.name) > ($1.spreadCount, $1.name) }
        for a in repeatable.prefix(2) {
            guard let text = a.spreadText else { continue }
            let level = a.level == .withinPrecision ? "within KickLab's measurement precision" : "repeatable"
            out.append(Finding(kind: .repeatablePattern, title: a.name, detail: "\(text) — \(level)."))
        }
        if let s = strengths.first { out.append(Finding(kind: .strength, title: s.title, detail: s.reason)) }
        for note in trackingNotes { out.append(Finding(kind: .trackingLimitation, title: "Tracking", detail: note)) }
        // Keep one of each kind before a second of any.
        var picked: [Finding] = []
        for kind in [Finding.Kind.differenceFromUsual, .repeatablePattern, .strength, .trackingLimitation] {
            if let f = out.first(where: { $0.kind == kind }) { picked.append(f) }
        }
        for f in out where !picked.contains(f) { picked.append(f) }
        let order: [Finding.Kind] = [.differenceFromUsual, .repeatablePattern, .strength, .trackingLimitation]
        return Array(picked.prefix(3)).sorted { order.firstIndex(of: $0.kind)! < order.firstIndex(of: $1.kind)! }
    }

    /// A specific reason an area is strong: its measurements that sit inside the provisional
    /// ranges with at least medium confidence. Nil when no component supports the claim.
    static func areaReason(_ category: AnalysisCategory, metrics: [MetricRowPresentation], profile: BiomechanicsProfile) -> String? {
        let good = metrics.filter { m in
            guard m.category == category, m.isAvailable, let v = m.value, (m.confidence ?? 0) >= 0.5,
                  let rule = profile.scoring[m.key], rule.weight > 0 else { return false }
            return rule.band.score(v) >= 90
        }
        guard !good.isEmpty else { return nil }
        let parts = good.prefix(2).map { "\($0.name.lowercased()) \($0.valueText)" }
        let joined = parts.joined(separator: " and ")
        return joined.prefix(1).uppercased() + String(joined.dropFirst())
            + (parts.count == 1 ? " was" : " were") + " within KickLab's provisional range."
    }

    /// One sentence: the most useful change to the recording.
    static func recordingTip(view: ComparableView, suitability: [SuitabilityFinding]) -> String {
        let kinds = Set(suitability.filter { $0.severity != .info }.map(\.kind))
        if kinds.contains(.kickerTooSmall) || kinds.contains(.kickerSmall) || kinds.contains(.bodyLeavesFrame) {
            return "Record closer, keeping the entire kicker and football visible throughout the kick."
        }
        if kinds.contains(.cameraMoving) { return "Keep the camera still on a tripod from the run-up to the finish." }
        if kinds.contains(.lowFrameRate) || kinds.contains(.frameRateBlursKick) || kinds.contains(.kickingFootBlurred) {
            return "Record at 60 fps or in slow motion, in good light, so the kicking foot isn't blurred."
        }
        return sideRecording
    }

    /// The Quick Report's one-line next step.
    var nextStep: String? { focus?.line }
}

extension PerformanceReport.Quality: Comparable {
    static func < (a: Self, b: Self) -> Bool { a.rank < b.rank }
}

/// Build 19: one short line per measurement on what the number means (athlete wording).
enum MetricContext {
    static func athleteLine(_ key: KickMetricKey) -> String {
        switch key {
        case .plantBallLateralOffset: "How far beside the football your plant foot was at contact (sideways only)."
        case .plantFootWidth: "Where your plant foot was compared with your hips at contact (sideways)."
        case .plantLateralMovement: "How far your plant foot slid sideways after landing."
        case .lateralTrunkLeanAtContact: "How far your trunk tilted sideways at contact."
        case .plantToContactTime: "Time from plant to contact. No 'right' value is known; it is for comparing your own kicks."
        case .followThroughDuration: "How long your kicking foot kept swinging after contact."
        case .kneeSwingAfterContact: "How long your kicking knee kept swinging after contact (the knee, not the foot)."
        case .followThroughFootHeight: "How high your kicking foot finished above your hip."
        case .approachSpeed: "Your run-up speed."
        case .approachSpeedVariation: "How steady your run-up speed was (lower is steadier)."
        case .approachLateSpeedChange: "How much you sped up or slowed in the last steps."
        case .plantFootDrift: "How much your plant foot moved around contact."
        case .plantKneeAngleAtContact: "How bent your plant knee was at contact."
        case .kickingKneeAngleAtContact: "How straight your kicking leg was at contact."
        case .kickingHipAngleAtContact: "Your kicking hip's angle at contact."
        case .backswingDepth: "How far back your kicking foot went before the swing."
        case .peakFootSpeed, .footSpeedAtContact: "How fast your kicking foot moved (in the video, not mph)."
        case .torsoLeanAtContact: "How far your trunk leaned forward or back at contact."
        case .torsoLeanRange: "How much your trunk angle changed through the swing."
        case .bodyForwardSpeedAtContact: "How fast your body moved through the ball."
        case .followThroughBodyTravel: "How far your body carried forward after contact."
        }
    }
}

// MARK: - Detailed Analysis (level 2)

/// Build 18: Detailed Analysis, organized by phase. Each piece of information appears once.
struct DetailedAnalysisReport: Equatable, Sendable {
    struct UnavailableMetric: Equatable, Sendable, Identifiable {
        var name: String
        var reason: String
        var id: String { name }
    }

    struct PhaseSection: Equatable, Sendable, Identifiable {
        var title: String
        var area: PerformanceReport.AreaRow?
        /// Short reason when the area wasn't rated.
        var areaNote: String?
        var metrics: [MetricRowPresentation]
        var unavailable: [UnavailableMetric]
        var id: String { title }
    }

    var phases: [PhaseSection]
    /// Contact and tracking quality, in plain words.
    var contactLines: [String]
    var history: PersonalRanking.History?
    var consistency: PersonalRanking.Consistency?
    var insights: [CoachingInsight]
    var methodology: [String]
    /// Build 20: per-measurement consistency with precision and sample sizes.
    var consistencyReport: ConsistencyReport? = nil

    /// Phases in kick order (Body Position at Contact is the contact phase).
    static let phaseOrder: [(String, AnalysisCategory)] = [
        ("Approach", .approach), ("Plant", .plant), ("Swing", .swing), ("Body Position at Contact", .contact), ("Follow-through", .followThrough),
    ]

    static func make(report: PerformanceReport, presentation: AnalysisResultsPresentation, view: ComparableView, kickType: KickType,
                     contactLines: [String], followThroughNote: String? = nil) -> DetailedAnalysisReport {
        let profile = BiomechanicsProfile.standard(for: kickType)
        let sections = phaseOrder.map { title, category -> PhaseSection in
            let metrics = presentation.metrics.filter { $0.category == category }
            let unavailable = metrics.filter { !$0.isAvailable && view.supports($0.key) && profile.supportedMetrics.contains($0.key) }.map { m in
                UnavailableMetric(name: m.name, reason: category == .followThrough ? (followThroughNote ?? "Not reliable in this recording") : "Not reliable in this recording")
            }
            let notMeasurable = metrics.filter { !$0.isAvailable && (!view.supports($0.key) || !profile.supportedMetrics.contains($0.key)) }.count
            let area = report.areas.first { $0.category == category }
            let note = area == nil ? report.unavailable.first { $0.title == category.presentationTitle }?.reason : nil
            var all = unavailable
            if notMeasurable > 0 { all.append(UnavailableMetric(name: "\(notMeasurable) other measurement\(notMeasurable == 1 ? "" : "s")", reason: "Not measurable from this view")) }
            return PhaseSection(title: title, area: area, areaNote: note, metrics: metrics.filter(\.isAvailable), unavailable: all)
        }
        return DetailedAnalysisReport(phases: sections, contactLines: contactLines, history: report.history,
                                      consistency: report.consistency, insights: report.insights, methodology: report.methodology,
                                      consistencyReport: report.consistencyReport)
    }
}

extension ContactConfidenceBreakdown {
    /// Build 20: one line for the Kick Report's top section.
    var qualityText: String {
        switch finalContact {
        case .strong: "Contact detection: high confidence"
        case .moderate: "Contact detection: moderate confidence"
        case .weak: "Contact detection: low confidence"
        case .unavailable: "Contact not established"
        }
    }

    /// Build 18: the confidence breakdown in plain words for Detailed Analysis.
    var plainLines: [String] {
        func word(_ l: Level) -> String {
            switch l {
            case .strong: "High"
            case .moderate: "Moderate"
            case .weak: "Low"
            case .unavailable: "Not available"
            }
        }
        var out: [String] = []
        if let e = contactEvent { out.append("Contact event: \(word(e))") }
        if let p = timePrecision {
            out.append("Contact timing precision: \(word(p))" + (intervalWidthSeconds.map { String(format: " (%.3f s window)", $0) } ?? ""))
        }
        out.append("Ball tracking: \(word(footballTracking))")
        out.append("Overall contact confidence: \(word(finalContact)) (rule-based, not a probability)")
        return out
    }
}
