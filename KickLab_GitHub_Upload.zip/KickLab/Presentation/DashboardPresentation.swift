import Foundation

/// Plain facts about an athlete, for lists, pickers and headers.
struct AthleteSummary: Equatable, Sendable, Identifiable {
    var id: UUID
    var name: String
    var kickingFoot: KickingFoot
    var playingLevel: PlayingLevel
    var kickCount: Int

    var kickingFootText: String { kickingFoot.displayName + "-footed" }
}

/// Which athlete is selected, given the stored choice and who exists.
enum AthleteSelection {
    /// Keeps the stored selection while that athlete exists; otherwise the first athlete
    /// by name; nil when there are none.
    static func resolve(selected: UUID?, available: [AthleteSummary]) -> UUID? {
        if let selected, available.contains(where: { $0.id == selected }) { return selected }
        return available.sorted { a, b in
            let order = a.name.localizedCaseInsensitiveCompare(b.name)
            if order != .orderedSame { return order == .orderedAscending }
            return a.id.uuidString < b.id.uuidString
        }.first?.id
    }
}

/// The latest completed analysis, condensed for the dashboard.
struct LatestAnalysisSummary: Equatable, Sendable {
    var analysisID: UUID
    var kickID: UUID?
    var kickType: KickType
    var date: Date
    var overallScore: Double?
    var confidence: Double?
    /// The highest-priority IMPROVE observation, if any.
    var topPriority: CoachingItemPresentation?
}

struct DashboardActivity: Equatable, Sendable, Identifiable {
    var id: UUID
    var date: Date
    var title: String
    var detail: String
}

struct DashboardStat: Equatable, Sendable, Identifiable {
    var id: String { title }
    var title: String
    var value: String
    var detail: String?
}

struct DashboardTrendItem: Equatable, Sendable, Identifiable {
    var id: String { title }
    var title: String
    var current: String
    var previous: String
    var change: String
    /// Plain words, not only color.
    var directionText: String
}

/// The home screen for one athlete.
struct DashboardPresentation: Equatable, Sendable {
    var athleteName: String
    var kickingFootText: String
    var totalKicks: Int
    var stats: [DashboardStat]
    var latestScoreText: String?
    var latestScoreGrade: ScoreGrade
    var latestScoreDetail: String?
    var topPriority: CoachingItemPresentation?
    var recentActivity: [DashboardActivity]
    var trend: [DashboardTrendItem]
    /// Shown when there is nothing to report yet.
    var emptyMessage: String?
    var analysisEmptyMessage: String?
    var trendEmptyMessage: String?

    var isEmpty: Bool { totalKicks == 0 }

    static let noKicksMessage = "No kicks yet. Log a kick or import a video to get started."
    static let noAnalysisMessage = "Import a video of a kick and analyze it to see your mechanics score."
    static let noTrendMessage = "Log kicks over a few weeks to see how you're trending."

    static func make(
        athlete: AthleteSummary,
        totalKicks: Int,
        recentFieldGoals: FieldGoalStatistics?,
        recentKickoffs: KickoffStatistics?,
        recentKicks: [KickStatRecord],
        latestAnalysis: LatestAnalysisSummary?,
        trend: PerformanceTrend?
    ) -> DashboardPresentation {
        var stats: [DashboardStat] = [DashboardStat(title: "Total kicks", value: "\(totalKicks)", detail: nil)]
        if let fg = recentFieldGoals, fg.makeRate.attempts > 0 {
            stats.append(DashboardStat(
                title: "Field goals (30 days)",
                value: DisplayFormat.percentage(fg.makeRate.percentage),
                detail: "\(fg.makeRate.successes) of \(fg.makeRate.attempts) made"
            ))
        }
        if let ko = recentKickoffs, ko.kickoffCount > 0 {
            if ko.touchbackRate.attempts > 0 {
                stats.append(DashboardStat(
                    title: "Touchbacks (30 days)",
                    value: DisplayFormat.percentage(ko.touchbackRate.percentage),
                    detail: "\(ko.touchbackRate.successes) of \(ko.touchbackRate.attempts) kickoffs"
                ))
            }
            if let distance = ko.distance.average {
                stats.append(DashboardStat(title: "Kickoff distance", value: DisplayFormat.yards(distance),
                                           detail: "Average of \(ko.distance.sampleCount)"))
            }
            if let hang = ko.hangTime.average {
                stats.append(DashboardStat(title: "Kickoff hang time", value: DisplayFormat.seconds(hang),
                                           detail: "Average of \(ko.hangTime.sampleCount)"))
            }
        }

        let activity = recentKicks.map { record in
            DashboardActivity(id: record.kickID, date: record.timestamp, title: record.kickType.displayName,
                              detail: activityDetail(record))
        }

        var trendItems: [DashboardTrendItem] = []
        if let trend {
            if let item = trendItem("Field goal %", trend.fieldGoalPercentage, format: DisplayFormat.percentage, higherIsBetter: true) {
                trendItems.append(item)
            }
            if let item = trendItem("Touchback %", trend.touchbackPercentage, format: DisplayFormat.percentage, higherIsBetter: true) {
                trendItems.append(item)
            }
            if let item = trendItem("Kickoff distance", trend.averageKickoffDistance, format: DisplayFormat.yards, higherIsBetter: true) {
                trendItems.append(item)
            }
            if let item = trendItem("Kickoff hang time", trend.averageKickoffHangTime, format: DisplayFormat.seconds, higherIsBetter: true) {
                trendItems.append(item)
            }
        }

        var latestDetail: String?
        if let latest = latestAnalysis {
            latestDetail = latest.kickType.displayName + " · " + DisplayFormat.confidence(latest.confidence)
        }
        return DashboardPresentation(
            athleteName: athlete.name,
            kickingFootText: athlete.kickingFootText,
            totalKicks: totalKicks,
            stats: stats,
            latestScoreText: latestAnalysis.map { DisplayFormat.score($0.overallScore) },
            latestScoreGrade: ScoreGrade(score: latestAnalysis?.overallScore),
            latestScoreDetail: latestDetail,
            topPriority: latestAnalysis?.topPriority,
            recentActivity: activity,
            trend: trendItems,
            emptyMessage: totalKicks == 0 ? noKicksMessage : nil,
            analysisEmptyMessage: latestAnalysis == nil ? noAnalysisMessage : nil,
            trendEmptyMessage: trendItems.isEmpty ? noTrendMessage : nil
        )
    }

    static func activityDetail(_ record: KickStatRecord) -> String {
        var parts: [String] = []
        switch record.kickType {
        case .fieldGoal, .pat:
            if let result = record.result, result != .unknown { parts.append(result.displayName) }
            if let d = record.distanceYards { parts.append(DisplayFormat.yards(d)) }
        case .kickoff:
            if record.touchback == true { parts.append("Touchback") }
            if let d = record.distanceYards { parts.append(DisplayFormat.yards(d)) }
            if let h = record.hangTimeSeconds { parts.append(DisplayFormat.seconds(h) + " hang") }
        case .punt:
            if let d = record.distanceYards { parts.append(DisplayFormat.yards(d)) }
            if let h = record.hangTimeSeconds { parts.append(DisplayFormat.seconds(h) + " hang") }
        case .unknown:
            break
        }
        parts.append(record.context.displayName)
        return parts.joined(separator: " · ")
    }

    /// Shown only when both periods have data.
    static func trendItem(
        _ title: String,
        _ trend: MetricTrend,
        format: (Double?) -> String,
        higherIsBetter: Bool
    ) -> DashboardTrendItem? {
        guard let current = trend.current, let previous = trend.previous, let change = trend.change else { return nil }
        let tolerance = max(abs(previous) * 0.02, 1e-9)
        let direction: String
        if abs(change) <= tolerance {
            direction = "About the same"
        } else if (change > 0) == higherIsBetter {
            direction = "Improving"
        } else {
            direction = "Declining"
        }
        let sign = change > 0 ? "+" : ""
        return DashboardTrendItem(title: title, current: format(current), previous: format(previous),
                                  change: sign + format(change), directionText: direction)
    }
}
