import Foundation

/// Build 15: the Video Intelligence debugger's evidence timeline — every layer the contact
/// decision used, on one time axis: the ball's state per examined frame, the kicking ankle's
/// speed, the kicking knee's angle, plant candidates (accepted / rejected), the kick window,
/// the pose strike window, the ball-contact interval and the fusion verdict.
struct EvidenceTimelineModel: Equatable, Sendable {
    struct Series: Equatable, Sendable {
        var title: String
        var unit: String
        var times: [Double]
        var values: [Double?]
        var minimum: Double
        var maximum: Double

        /// 0…1 height of a value inside the series' range.
        func level(_ v: Double) -> Double { maximum > minimum ? min(1, max(0, (v - minimum) / (maximum - minimum))) : 0.5 }
    }

    struct Band: Equatable, Sendable, Identifiable {
        enum Kind: String, Sendable { case kickWindow, poseStrike, ballContact, contactShown }
        var kind: Kind
        var start: Double
        var end: Double
        var label: String
        var id: String { "\(kind.rawValue)-\(start)" }
    }

    struct Mark: Equatable, Sendable, Identifiable {
        enum Kind: String, Sendable { case plantAccepted, plantRejected, ballLastAtRest, ballFirstMovement }
        var kind: Kind
        var time: Double
        var label: String
        var id: String { "\(kind.rawValue)-\(time)" }
    }

    struct BallCell: Equatable, Sendable, Identifiable {
        var time: Double
        var state: FootballFrameState
        var source: FootballObservationSource
        var score: Double?
        var id: Double { time }

        var label: String {
            let s = FootballOverlayModel.title(state)
            switch source {
            case .detected: return "\(s) · detected\(score.map { String(format: " %.2f", $0) } ?? "")"
            case .tracked: return "\(s) · by appearance only (no box)"
            case .interpolated, .unavailable: return s
            }
        }
    }

    var duration: Double
    var ankleSpeed: Series?
    var kneeAngle: Series?
    var ballCells: [BallCell]
    var bands: [Band]
    var marks: [Mark]
    /// One line: accepted / rejected and why, or why there is no ball evidence.
    var fusionVerdict: String

    static func make(signals: PoseSignalSet?, phases: KickPhaseDetectionResult?, football: FootballTrack?) -> EvidenceTimelineModel {
        func series(_ key: PoseSignalKey, _ title: String, _ unit: String) -> Series? {
            guard let s = signals else { return nil }
            let v = s.values(key)
            let finite = v.compactMap { $0 }.filter(\.isFinite)
            guard let lo = finite.min(), let hi = finite.max() else { return nil }
            return Series(title: title, unit: unit, times: s.timestamps, values: v, minimum: lo, maximum: hi)
        }
        let e = phases?.evidence
        var bands: [Band] = []
        if let w = phases?.kickWindows?.selected {
            bands.append(Band(kind: .kickWindow, start: w.strikeStart, end: w.strikeEnd, label: "kick window (\(w.source))"))
        }
        if let f = e?.ballFusion, let a = f.poseStrikeEarliest, let b = f.poseStrikeLatest {
            bands.append(Band(kind: .poseStrike, start: a, end: b, label: "pose strike window"))
        } else if let g = e?.contactEvidenceGroups?.first(where: { $0.name == "kickingLegDrive" }), let a = g.earliestTime, let b = g.latestTime {
            bands.append(Band(kind: .poseStrike, start: a, end: b, label: "pose strike window"))
        }
        if let a = football?.lastStationaryTime, let b = football?.firstPersistentMovementTime {
            bands.append(Band(kind: .ballContact, start: a, end: b, label: "ball-contact interval (contact no earlier, no later)"))
        }
        if let c = phases?.phase(.contact), c.isAvailable, let t = c.representativeTime {
            let lo = e?.contactEarliestTime ?? t, hi = e?.contactLatestTime ?? t
            bands.append(Band(kind: .contactShown, start: min(lo, t), end: max(hi, t),
                              label: "contact \(ContactOutcome.of(phases!).title.lowercased())"))
        }
        var marks: [Mark] = (e?.plantCandidates ?? []).map {
            Mark(kind: $0.accepted ? .plantAccepted : .plantRejected, time: $0.time,
                 label: ($0.accepted ? "plant used" : "plant rejected") + ": " + $0.reason)
        }
        if let t = football?.lastStationaryTime { marks.append(Mark(kind: .ballLastAtRest, time: t, label: "ball last clearly at rest")) }
        if let t = football?.firstPersistentMovementTime { marks.append(Mark(kind: .ballFirstMovement, time: t, label: "ball first seen moving")) }
        let verdict: String = {
            if let f = e?.ballFusion {
                let departure = football?.departure.map { " · departure: \($0.kind.athleteText.lowercased())" } ?? ""
                return (f.accepted ? "Ball evidence ACCEPTED\(f.acceptancePath.map { " via \($0)" } ?? "")" : "Ball evidence REJECTED — \(f.rejectionReason ?? "no reason recorded")") + departure
            }
            if phases?.isUserAssisted == true { return "User-assisted analysis: ball fusion not used" }
            if let football { return "Ball evidence: \(football.method.rawValue) — \(football.note)" }
            return "No football analysis for this run"
        }()
        let end = max(signals?.timestamps.last ?? 0, football?.observations.last?.time ?? 0)
        return EvidenceTimelineModel(
            duration: end,
            ankleSpeed: series(.kickingAnkleSpeed, "Kicking-ankle speed", "TL/s"),
            kneeAngle: series(.kickingKneeAngle, "Kicking-knee angle", "°"),
            ballCells: (football?.observations ?? []).map { BallCell(time: $0.time, state: $0.state, source: $0.source, score: $0.score) },
            bands: bands, marks: marks.sorted { $0.time < $1.time }, fusionVerdict: verdict
        )
    }

    /// The time range shown: the whole clip, or `span` seconds centered on `time` (clamped).
    func visibleRange(around time: Double, span: Double?) -> ClosedRange<Double> {
        guard let span, span < duration, span > 0 else { return 0...max(duration, 0.001) }
        let start = min(max(0, time - span / 2), max(0, duration - span))
        return start...(start + span)
    }

    static func fraction(_ t: Double, in r: ClosedRange<Double>) -> Double {
        let w = r.upperBound - r.lowerBound
        return w > 0 ? min(1, max(0, (t - r.lowerBound) / w)) : 0
    }
}

/// Build 15: automatic results next to what the user verified — compared, never merged.
struct VerificationComparisonRow: Equatable, Sendable, Identifiable {
    var title: String
    var automatic: String
    var yours: String
    var verdict: String
    var id: String { title }
}

enum VerificationComparison {
    static func rows(phases: KickPhaseDetectionResult?, football: FootballTrack?, verification v: VideoVerification,
                     annotation: ContactAnnotation, frame: Double) -> [VerificationComparisonRow] {
        func t(_ x: Double?) -> String { x.map { String(format: "%.3f s", $0) } ?? "—" }
        func frames(_ d: Double) -> String {
            let n = Int((abs(d) / frame).rounded())
            return n == 0 ? "same frame" : "\(n) frame\(n == 1 ? "" : "s") \(d < 0 ? "earlier" : "later")"
        }
        var rows: [VerificationComparisonRow] = []
        // Contact.
        let c = phases?.phase(.contact)
        let auto: ClosedRange<Double>? = c.flatMap { c in
            guard c.isAvailable, let rt = c.representativeTime else { return nil }
            let lo = phases?.evidence?.contactEarliestTime ?? rt, hi = phases?.evidence?.contactLatestTime ?? rt
            return min(lo, rt)...max(hi, rt)
        }
        let autoText = auto.map { $0.lowerBound == $0.upperBound ? t($0.lowerBound) : "\(t($0.lowerBound))–\(t($0.upperBound))" } ?? "not found"
        var yoursText = "—", verdict = "nothing to compare"
        if case .contact(let u) = annotation {
            yoursText = t(u)
            if let a = auto {
                verdict = a.contains(u) || abs(u - a.lowerBound) < 1e-3 || abs(u - a.upperBound) < 1e-3
                    ? "inside the automatic interval" : (u < a.lowerBound ? frames(u - a.lowerBound) : frames(u - a.upperBound)) + " than the automatic interval"
            }
        } else if case .cannotTell = annotation {
            yoursText = "can't tell"
        }
        if let r = v.contactRange {
            yoursText = "\(t(r.start))–\(t(r.end))"
            if let a = auto {
                verdict = max(a.lowerBound, r.start) <= min(a.upperBound, r.end) + 1e-3 ? "your range overlaps the automatic interval" : "your range doesn't overlap the automatic interval"
            }
        }
        rows.append(VerificationComparisonRow(title: "Contact", automatic: autoText, yours: yoursText, verdict: auto == nil && yoursText != "—" ? "no automatic contact" : verdict))
        // Plant.
        let plant = phases?.plantTime
        switch v.plant {
        case .frame(let u)?:
            rows.append(VerificationComparisonRow(title: "Plant", automatic: t(plant), yours: t(u),
                                                  verdict: plant.map { frames($0 - u) + " (automatic vs yours)" } ?? "no automatic plant"))
        case .cannotTell?:
            rows.append(VerificationComparisonRow(title: "Plant", automatic: t(plant), yours: "can't tell", verdict: "nothing to compare"))
        case nil:
            rows.append(VerificationComparisonRow(title: "Plant", automatic: t(plant), yours: "—", verdict: "not verified"))
        }
        // First ball movement.
        let move = football?.firstPersistentMovementTime
        if case .frame(let u)? = v.firstBallMovement {
            rows.append(VerificationComparisonRow(title: "First ball movement", automatic: t(move), yours: t(u),
                                                  verdict: move.map { frames($0 - u) + " (automatic vs yours)" } ?? "the detector found no departure"))
        } else {
            rows.append(VerificationComparisonRow(title: "First ball movement", automatic: t(move), yours: "—", verdict: "not verified"))
        }
        // Which football.
        let site = football?.sites.first(where: \.selected)
        let autoBall = site.flatMap { s in football?.sites.firstIndex(of: s).map { "ball \($0 + 1)" } } ?? "none selected"
        if let k = v.kickedBall {
            let same = site.map { s in hypot(s.center.x - k.x, s.center.y - k.y) <= max(s.size, k.size) * 1.5 } ?? false
            rows.append(VerificationComparisonRow(title: "Kicked football", automatic: autoBall,
                                                  yours: k.detectedBallNumber.map { "ball \($0)" } ?? "marked by tap",
                                                  verdict: site == nil ? "the detector selected none" : (same ? "same ball" : "DIFFERENT ball")))
        } else {
            rows.append(VerificationComparisonRow(title: "Kicked football", automatic: autoBall, yours: "—", verdict: "not verified"))
        }
        return rows
    }
}
