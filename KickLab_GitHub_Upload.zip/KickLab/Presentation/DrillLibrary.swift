import Foundation

/// Step 12E: a curated library of general kicking drills.
///
/// These are standard coaching drills written for KickLab, not individually prescribed:
/// the app links a drill to a mechanics AREA where an analysis found something to work
/// on, and always says the drill is general. Nothing here diagnoses injury, and every
/// drill carries the same basic safety cautions.
enum DrillFocus: String, CaseIterable, Sendable, Identifiable {
    case approachConsistency, lastStepControl, plantFootPosition, balance, backswing, legSwing
    case contactConsistency, followThrough, fieldGoalAccuracy, kickoffDevelopment, puntingFundamentals

    var id: String { rawValue }

    var title: String {
        switch self {
        case .approachConsistency: "Approach consistency"
        case .lastStepControl: "Last-step control"
        case .plantFootPosition: "Plant-foot positioning"
        case .balance: "Balance"
        case .backswing: "Backswing mechanics"
        case .legSwing: "Leg swing"
        case .contactConsistency: "Contact consistency"
        case .followThrough: "Follow-through"
        case .fieldGoalAccuracy: "Field-goal accuracy practice"
        case .kickoffDevelopment: "Kickoff development"
        case .puntingFundamentals: "Punting fundamentals"
        }
    }
}

struct Drill: Equatable, Sendable, Identifiable {
    var id: String
    var title: String
    var focus: DrillFocus
    var purpose: String
    var instructions: [String]
    var repetitions: String
    var equipment: [String]
    var commonMistakes: [String]
    var kickTypes: [KickType]
    var cautions: [String]
}

enum DrillLibrary {
    /// Shown with every drill.
    static let generalCaution = "General drill, not individually prescribed. Warm up first, stop if anything hurts, and don't train through pain."
    static let standardCautions = [
        "Warm up before kicking and build up to full effort.",
        "Stop if you feel pain; see a qualified professional for any injury.",
    ]

    static let all: [Drill] = [
        Drill(id: "approach-chalk-steps", title: "Marked-step approach", focus: .approachConsistency,
              purpose: "Make every approach the same length and rhythm so the plant lands in the same place.",
              instructions: ["Mark your start spot with a cone.", "Take your normal approach without a ball; have a partner mark where your plant foot lands.",
                             "Repeat; adjust your start spot until the plant mark is the same every rep.", "Then add the ball and keep the same count and rhythm."],
              repetitions: "3 sets of 5 approaches", equipment: ["Cones or chalk", "A partner (optional)"],
              commonMistakes: ["Changing step length on the last two steps", "Speeding up to 'help' the kick"],
              kickTypes: [.fieldGoal, .pat, .kickoff], cautions: standardCautions),
        Drill(id: "two-step-plant", title: "Two-step plant and hold", focus: .lastStepControl,
              purpose: "Control the last step so the body arrives balanced over the plant.",
              instructions: ["Start two steps from the ball.", "Take the two steps and plant; freeze for two seconds without kicking.",
                             "Check the plant foot points at the target and you're balanced.", "After 5 good holds, kick from the same two steps."],
              repetitions: "2 sets of 5 holds, then 5 kicks", equipment: ["Ball", "Tee or holder"],
              commonMistakes: ["Over-striding into the plant", "Leaning back while holding"],
              kickTypes: [.fieldGoal, .pat], cautions: standardCautions),
        Drill(id: "plant-target-line", title: "Plant beside the line", focus: .plantFootPosition,
              purpose: "Place the plant foot consistently beside and slightly behind the ball.",
              instructions: ["Lay a line (rope or tape) through the ball toward the target.", "Approach and plant with your foot a hand-width beside the ball.",
                             "Have a partner check the distance from the ball each rep.", "Kick only when the plant is consistent."],
              repetitions: "3 sets of 5", equipment: ["Rope or tape", "Ball", "Tee or holder"],
              commonMistakes: ["Planting too far from the ball", "Plant foot pointing away from the target"],
              kickTypes: [.fieldGoal, .pat, .kickoff], cautions: standardCautions),
        Drill(id: "one-leg-balance", title: "Single-leg balance swings", focus: .balance,
              purpose: "Build balance on the plant leg through and after the swing.",
              instructions: ["Stand on your plant leg, slight knee bend.", "Swing the kicking leg slowly through a full kicking motion.",
                             "Hold the finish for two seconds without touching down.", "Progress to faster swings when steady."],
              repetitions: "2 sets of 10 swings each side", equipment: ["None"],
              commonMistakes: ["Locking the plant knee", "Throwing the arms to stay up"],
              kickTypes: [.fieldGoal, .pat, .kickoff, .punt], cautions: standardCautions),
        Drill(id: "wall-backswing", title: "Wall backswing", focus: .backswing,
              purpose: "Feel a loaded backswing (hip back, knee bent) before the strike.",
              instructions: ["Stand on your plant leg facing a wall, one hand on it.", "Draw the kicking leg back, heel toward your hip, and pause.",
                             "Swing through slowly, keeping the knee bent until the end.", "Repeat with a smooth, unhurried rhythm."],
              repetitions: "2 sets of 10", equipment: ["A wall or fence"],
              commonMistakes: ["Swinging from the knee only", "Twisting the hips early"],
              kickTypes: [.fieldGoal, .pat, .kickoff], cautions: standardCautions),
        Drill(id: "pendulum-swings", title: "Pendulum leg swings", focus: .legSwing,
              purpose: "Groove a relaxed swing that accelerates through the bottom of the arc.",
              instructions: ["Hold a post for balance.", "Swing the kicking leg forward and back like a pendulum, relaxed.",
                             "Gradually increase range; feel the leg speed up at the bottom.", "Finish each set with three full-speed swings."],
              repetitions: "3 sets of 15", equipment: ["Post or partner for balance"],
              commonMistakes: ["Forcing the range", "Tensing the leg"],
              kickTypes: [.fieldGoal, .pat, .kickoff, .punt], cautions: standardCautions),
        Drill(id: "spot-strike", title: "Spot strike", focus: .contactConsistency,
              purpose: "Strike the same spot on the ball with the same part of the foot.",
              instructions: ["Mark a small dot on the ball's sweet spot.", "Kick short (10–15 yards) at 60% effort.",
                             "Check the ball spins end over end straight; adjust until it does.", "Increase distance only when contact is repeatable."],
              repetitions: "3 sets of 6", equipment: ["Ball", "Marker", "Tee or holder"],
              commonMistakes: ["Kicking hard before contact is consistent", "Looking up before contact"],
              kickTypes: [.fieldGoal, .pat, .kickoff], cautions: standardCautions),
        Drill(id: "finish-to-target", title: "Finish to target", focus: .followThrough,
              purpose: "Let the leg finish through the ball toward the target.",
              instructions: ["Kick at 70% effort.", "After contact, let the leg swing through and land a step toward the target.",
                             "Hold the finish and check the hips face the target.", "Repeat; don't stop the leg at contact."],
              repetitions: "3 sets of 5", equipment: ["Ball", "Tee or holder"],
              commonMistakes: ["Stopping the leg at the ball", "Falling away from the target"],
              kickTypes: [.fieldGoal, .pat, .kickoff], cautions: standardCautions),
        Drill(id: "hash-ladder", title: "Hash ladder", focus: .fieldGoalAccuracy,
              purpose: "Practise accuracy from each hash at increasing distances.",
              instructions: ["Start at a short distance from the left hash.", "Kick 2 from left, middle and right hash.",
                             "Move back 5 yards after making at least 4 of 6.", "Record makes and misses in KickLab (entered, not measured)."],
              repetitions: "18–24 kicks", equipment: ["Balls", "Tee or holder", "Goalposts"],
              commonMistakes: ["Changing technique for distance", "Rushing between kicks"],
              kickTypes: [.fieldGoal, .pat], cautions: standardCautions),
        Drill(id: "kickoff-rhythm", title: "Kickoff run-up rhythm", focus: .kickoffDevelopment,
              purpose: "Build a repeatable, faster run-up that stays controlled into the plant.",
              instructions: ["Mark your kickoff run-up start.", "Run through at 70% to the ball without kicking; check the plant spot.",
                             "Add the kick at 70%, then 85%.", "Keep the same step count every rep."],
              repetitions: "2 sets of 4", equipment: ["Ball", "Kickoff tee", "Cones"],
              commonMistakes: ["Decelerating into the plant", "Changing the run-up length"],
              kickTypes: [.kickoff], cautions: standardCautions),
        Drill(id: "drop-only", title: "Drop-only reps", focus: .puntingFundamentals,
              purpose: "Make the drop consistent before adding the swing.",
              instructions: ["Hold the ball as you would to punt.", "Take your steps and drop the ball without kicking; let it land.",
                             "The ball should land nose-down on the same spot each time.", "Add a light kick once 4 of 5 drops are consistent."],
              repetitions: "3 sets of 5 drops", equipment: ["Ball"],
              commonMistakes: ["Tossing the ball up", "Dropping from too high"],
              kickTypes: [.punt], cautions: standardCautions),
    ]

    static func drills(for focus: DrillFocus) -> [Drill] { all.filter { $0.focus == focus } }

    static func drill(id: String) -> Drill? { all.first { $0.id == id } }

    /// The focus area for a scored mechanics category, so a coaching priority can point
    /// to a related general drill.
    static func focus(for category: AnalysisCategory) -> DrillFocus? {
        switch category {
        case .approach: .approachConsistency
        case .plant: .plantFootPosition
        case .swing: .legSwing
        case .contact: .contactConsistency
        case .followThrough: .followThrough
        default: nil
        }
    }

    /// A related general drill for a coaching priority (nil when none fits).
    static func relatedDrill(for category: AnalysisCategory, kickType: KickType) -> Drill? {
        guard let focus = focus(for: category) else { return nil }
        return drills(for: focus).first { $0.kickTypes.contains(kickType) } ?? drills(for: focus).first
    }
}

/// Related drills for the areas an analysis flagged (in order, no duplicates, at most 3,
/// matching the three-priority limit). Linked by mechanics area only.
enum DrillSuggestions {
    static func drills(for categories: [AnalysisCategory], kickType: KickType) -> [Drill] {
        var seen = Set<String>()
        var out: [Drill] = []
        for category in categories {
            guard let drill = DrillLibrary.relatedDrill(for: category, kickType: kickType), seen.insert(drill.id).inserted else { continue }
            out.append(drill)
            if out.count == 3 { break }
        }
        return out
    }
}
