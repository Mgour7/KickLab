import Foundation

// Build 16 — Performance Report 2.0: personal rankings and history.
//
// Rankings compare a kick ONLY with the same athlete's own earlier kicks that were measured
// the same way. Nothing here is a percentile, a population benchmark or a target: no
// documented reference dataset exists, so none is shown.

/// How a kick was filmed, grouped by what the engine can measure from it.
enum ComparableView: String, Codable, Equatable, Sendable {
    /// Side view: sagittal-plane mechanics.
    case side
    /// Rear or front view (depth view): different metrics, not comparable with side.
    case depth
    /// Diagonal or behind-the-goal recordings.
    case other
    /// The camera view wasn't recorded: never compared.
    case unknown

    init(angle: VideoAngleType?) {
        switch angle {
        case .side?: self = .side
        case .rear?, .front?: self = .depth
        case .oblique?, .behindGoal?: self = .other
        case .unknown?, nil: self = .unknown
        }
    }

    var title: String {
        switch self {
        case .side: "Side view"
        case .depth: "Rear/front view"
        case .other: "Angled view"
        case .unknown: "View not recorded"
        }
    }
}

/// The scoring model a stored analysis was scored with.
enum ScoringModel {
    /// Build 16: the provisional technique bands (`BiomechanicsProfile`), unchanged from
    /// engine 2.8.0 through 2.9.0 — 2.9.0 changed contact fusion only, no metric definition,
    /// band, weight or gate. Earlier engines are never compared with these.
    static let current = "provisional-bands-1"
    static let familiesUsingCurrent: Set<String> = ["2.8", "2.9"]

    /// "2.9" from "pose-biomechanics-2.9.0" or "pose-biomechanics-2.9.0+assisted".
    static func family(of engine: String) -> String? {
        guard let range = engine.range(of: "pose-biomechanics-") else { return nil }
        let rest = engine[range.upperBound...].split(separator: "+").first.map(String.init) ?? ""
        let parts = rest.split(separator: ".")
        guard parts.count >= 2, Int(parts[0]) != nil, Int(parts[1]) != nil else { return nil }
        return "\(parts[0]).\(parts[1])"
    }

    static func version(ofEngine engine: String) -> String? {
        family(of: engine).flatMap { familiesUsingCurrent.contains($0) ? current : nil }
    }
}

/// One scored analysis as the ranking sees it (built from saved data; nothing new stored).
struct RankingEntry: Equatable, Sendable, Identifiable {
    var id: UUID
    var kickID: UUID?
    var date: Date
    var kickType: KickType
    var view: ComparableView
    var engineVersion: String
    var completed: Bool
    var overallScore: Double?
    var categoryScores: [AnalysisCategory: Double]

    var isAssisted: Bool { AnalysisAssistanceLabel.isAssisted(engineVersion) }
    var scoringModel: String? { ScoringModel.version(ofEngine: engineVersion) }
}

enum PersonalRanking {
    /// A rank needs at least this many comparable kicks, the current one included.
    static let minimumComparableKicks = 3
    /// "Recent average": the last this many comparable kicks before this one.
    static let recentWindow = 5
    /// Trend: least-squares slope over the last `recentWindow` comparable kicks (this one
    /// included), in points per kick. Beyond ±`trendThreshold` it is up or down.
    static let trendThreshold = 2.0
    static let notEnoughText = "Not enough comparable kicks to rank"

    struct Eligibility: Equatable, Sendable {
        /// Earlier comparable kicks (not including the current one), oldest first.
        var comparable: [RankingEntry]
        var excludedOtherKickType = 0
        var excludedOtherView = 0
        var excludedOlderScoring = 0
        var excludedAssistance = 0
        var excludedIncomplete = 0

        /// Short reasons other kicks weren't compared (nil when none were excluded for a
        /// reason worth mentioning).
        var exclusionNote: String? {
            var parts: [String] = []
            if excludedOlderScoring > 0 { parts.append("\(excludedOlderScoring) scored by an older engine") }
            if excludedOtherView > 0 { parts.append("\(excludedOtherView) filmed from another view") }
            if excludedAssistance > 0 { parts.append("\(excludedAssistance) with a different analysis type (user-assisted vs automatic)") }
            return parts.isEmpty ? nil : "Not compared: " + parts.joined(separator: ", ") + "."
        }
    }

    /// The rules: same kick type; same view group (an unrecorded view is never compared);
    /// the same scoring model; the same kind of analysis (user-assisted results only with
    /// user-assisted ones); completed; a different kick (re-analyses of the same kick don't
    /// count twice). Only earlier kicks count, so a rank never changes when later kicks are added.
    static func eligibility(for current: RankingEntry, among all: [RankingEntry]) -> Eligibility {
        var e = Eligibility(comparable: [])
        guard current.scoringModel != nil, current.view != .unknown else { return e }
        for other in all where other.id != current.id && (other.kickID == nil || other.kickID != current.kickID) && other.date <= current.date {
            if !other.completed { e.excludedIncomplete += 1; continue }
            if other.kickType != current.kickType { e.excludedOtherKickType += 1; continue }
            if other.view != current.view { e.excludedOtherView += 1; continue }
            if other.scoringModel != current.scoringModel { e.excludedOlderScoring += 1; continue }
            if other.isAssisted != current.isAssisted { e.excludedAssistance += 1; continue }
            e.comparable.append(other)
        }
        e.comparable.sort { $0.date < $1.date }
        return e
    }

    struct Standing: Equatable, Sendable {
        /// 1 = best. Nil when not ranked.
        var rank: Int?
        /// Comparable kicks with a value, the current one included.
        var outOf: Int
        var text: String
    }

    /// Ties share the better rank. A kick without a value is never ranked (missing is not zero).
    static func standing(_ value: Double?, others: [Double]) -> Standing {
        guard let value else { return Standing(rank: nil, outOf: others.count, text: "Not rated") }
        let n = others.count + 1
        guard n >= minimumComparableKicks else { return Standing(rank: nil, outOf: n, text: notEnoughText) }
        let rank = 1 + others.filter { $0 > value + 1e-9 }.count
        return Standing(rank: rank, outOf: n, text: rank == 1 ? "Personal best of \(n) comparable kicks" : "#\(rank) of \(n) comparable kicks")
    }

    static func categoryStanding(_ category: AnalysisCategory, current: RankingEntry, eligibility: Eligibility) -> Standing {
        standing(current.categoryScores[category], others: eligibility.comparable.compactMap { $0.categoryScores[category] })
    }

    enum Trend: String, Equatable, Sendable {
        case improving, steady, declining
        var text: String {
            switch self {
            case .improving: "Improving"
            case .steady: "Steady"
            case .declining: "Declining"
            }
        }
    }

    struct History: Equatable, Sendable {
        var previous: Double?
        var best: Double?
        var isPersonalBest: Bool
        var recentAverage: Double?
        var change: Double?
        var trend: Trend?
        var standing: Standing
        var comparableCount: Int
        /// Shown when there isn't enough history yet.
        var message: String?
        var exclusionNote: String?

        var hasHistory: Bool { previous != nil }
    }

    static let historyWillPopulate = "Your history will build as you analyze more kicks of this type from the same view."

    /// Like-for-like overall-score history. Kicks without an overall score are skipped,
    /// never counted as zero.
    static func history(current: RankingEntry, eligibility: Eligibility) -> History {
        let earlier = eligibility.comparable.compactMap { e in e.overallScore.map { (e.date, $0) } }
        let values = earlier.map(\.1)
        let standing = standing(current.overallScore, others: values)
        guard let now = current.overallScore, !values.isEmpty else {
            return History(previous: nil, best: nil, isPersonalBest: false, recentAverage: nil, change: nil, trend: nil,
                           standing: standing, comparableCount: values.count + (current.overallScore == nil ? 0 : 1),
                           message: historyWillPopulate, exclusionNote: eligibility.exclusionNote)
        }
        let previous = values.last!
        let recent = Array(values.suffix(recentWindow))
        let best = max(values.max()!, now)
        let series = Array((values + [now]).suffix(recentWindow))
        return History(previous: previous, best: best, isPersonalBest: now >= values.max()! - 1e-9 && values.count + 1 >= minimumComparableKicks,
                       recentAverage: recent.reduce(0, +) / Double(recent.count), change: now - previous,
                       trend: series.count >= minimumComparableKicks ? trend(series) : nil,
                       standing: standing, comparableCount: values.count + 1,
                       message: values.count + 1 < minimumComparableKicks ? historyWillPopulate : nil,
                       exclusionNote: eligibility.exclusionNote)
    }

    static func trend(_ series: [Double]) -> Trend {
        let n = Double(series.count)
        let xs = series.indices.map(Double.init)
        let mx = xs.reduce(0, +) / n, my = series.reduce(0, +) / n
        let den = xs.map { ($0 - mx) * ($0 - mx) }.reduce(0, +)
        guard den > 0 else { return .steady }
        let slope = zip(xs, series).map { ($0 - mx) * ($1 - my) }.reduce(0, +) / den
        return slope > trendThreshold ? .improving : (slope < -trendThreshold ? .declining : .steady)
    }
}
