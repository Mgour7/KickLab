import Foundation

// Personal rankings, history and consistency (Build 16, extended in Build 18).
//
// A kick is compared ONLY with the same athlete's own earlier kicks that were measured the
// same way. Nothing here is a percentile, a population benchmark or a target: no
// documented reference dataset exists, so none is shown.

/// How a kick was filmed, grouped by what the engine can measure from it.
enum ComparableView: String, Codable, Equatable, Sendable {
    /// Side view: sagittal-plane mechanics.
    case side
    /// Rear or front view (depth view): different metrics, not comparable with side.
    case depth
    /// Diagonal or behind-the-goal recordings.
    case other
    /// The camera view wasn't recorded: never compared.
    case unknown

    init(angle: VideoAngleType?) {
        switch angle {
        case .side?: self = .side
        case .rear?, .front?: self = .depth
        case .oblique?, .behindGoal?: self = .other
        case .unknown?, nil: self = .unknown
        }
    }

    var title: String {
        switch self {
        case .side: "Side view"
        case .depth: "Rear/front view"
        case .other: "Angled view"
        case .unknown: "View not recorded"
        }
    }

    /// The metrics this view group can measure at all.
    func supports(_ key: KickMetricKey) -> Bool {
        switch self {
        case .side: !PerspectiveMetricSupport.frontalPlaneMetrics.contains(key)
        case .depth: PerspectiveMetricSupport.depthViewMetrics.contains(key)
        case .other: !PerspectiveMetricSupport.frontalPlaneMetrics.contains(key) && (key.definition.timing == .interval || key.definition.unit == .percent)
        case .unknown: false
        }
    }
}

/// Which scoring rules a stored analysis was scored with, overall and per area.
///
/// - `provisional-bands-1`: engines 2.8.x–2.9.x.
/// - `provisional-bands-2`: engine 3.0.x. Only the Plant area changed (plant-to-contact
///   time is no longer scored), so Plant and the overall score are compared only within the
///   same model; Approach, Swing, Body Position at Contact and Follow-Through are unchanged
///   since 2.8.0 and stay comparable across both.
enum ScoringModel {
    static let current = "provisional-bands-2"
    static let modelsByFamily: [String: String] = ["2.8": "provisional-bands-1", "2.9": "provisional-bands-1", "3.0": "provisional-bands-2"]
    /// Areas whose scoring rules changed in `provisional-bands-2`.
    static let changedInBands2: Set<AnalysisCategory> = [.plant, .overall]

    /// "2.9" from "pose-biomechanics-2.9.0" or "pose-biomechanics-2.9.0+assisted".
    static func family(of engine: String) -> String? {
        guard let range = engine.range(of: "pose-biomechanics-") else { return nil }
        let rest = engine[range.upperBound...].split(separator: "+").first.map(String.init) ?? ""
        let parts = rest.split(separator: ".")
        guard parts.count >= 2, Int(parts[0]) != nil, Int(parts[1]) != nil else { return nil }
        return "\(parts[0]).\(parts[1])"
    }

    static func version(ofEngine engine: String) -> String? {
        family(of: engine).flatMap { modelsByFamily[$0] }
    }

    /// The scoring rules of one area (or `.overall`) as used by this engine; equal strings
    /// are comparable.
    static func version(of category: AnalysisCategory, engine: String) -> String? {
        guard let model = version(ofEngine: engine) else { return nil }
        if model == "provisional-bands-1" || changedInBands2.contains(category) { return "\(category.rawValue)@\(model)" }
        return "\(category.rawValue)@provisional-bands-1"
    }
}

/// One scored analysis as the ranking sees it (built from saved data; nothing new stored).
struct RankingEntry: Equatable, Sendable, Identifiable {
    var id: UUID
    var kickID: UUID?
    var date: Date
    var kickType: KickType
    var view: ComparableView
    var engineVersion: String
    var completed: Bool
    var overallScore: Double?
    var categoryScores: [AnalysisCategory: Double]
    /// Build 18: available metric values (confidence ≥ the scoring threshold), keyed by
    /// "metricKey@definitionVersion" so only like-for-like definitions are compared.
    var metrics: [String: Double] = [:]
    /// Build 18: the kicking session, for same-session consistency.
    var sessionID: UUID? = nil

    var isAssisted: Bool { AnalysisAssistanceLabel.isAssisted(engineVersion) }
    var scoringModel: String? { ScoringModel.version(ofEngine: engineVersion) }

    static func metricKey(_ key: KickMetricKey) -> String { "\(key.rawValue)@\(key.definition.definitionVersion)" }
    func metric(_ key: KickMetricKey) -> Double? { metrics[Self.metricKey(key)] }
}

enum PersonalRanking {
    /// A rank needs at least this many comparable kicks, the current one included.
    static let minimumComparableKicks = 3
    /// "Recent average": the last this many comparable kicks before this one.
    static let recentWindow = 5
    /// Trend: least-squares slope over the last `recentWindow` comparable kicks (this one
    /// included), in points per kick. Beyond ±`trendThreshold` it is up or down.
    static let trendThreshold = 2.0
    /// Build 18: spread and metric trends need at least this many comparable kicks.
    static let minimumForConsistency = 4
    static let minimumForMetricTrend = 5
    /// A metric "appears to be improving" only with a strong, consistent trend: the
    /// correlation of value with kick order is at least this strong in the better direction.
    static let minimumTrendCorrelation = 0.7
    static let notEnoughText = "Not enough comparable kicks to rank"

    struct Eligibility: Equatable, Sendable {
        /// Earlier comparable kicks (not including the current one), oldest first.
        var comparable: [RankingEntry]
        var excludedOtherKickType = 0
        var excludedOtherView = 0
        var excludedOlderScoring = 0
        var excludedAssistance = 0
        var excludedIncomplete = 0

        /// Short reasons other kicks weren't compared (nil when none were excluded for a
        /// reason worth mentioning).
        var exclusionNote: String? {
            var parts: [String] = []
            if excludedOlderScoring > 0 { parts.append("\(excludedOlderScoring) scored by an older engine") }
            if excludedOtherView > 0 { parts.append("\(excludedOtherView) filmed from another view") }
            if excludedAssistance > 0 { parts.append("\(excludedAssistance) with a different analysis type (user-assisted vs automatic)") }
            return parts.isEmpty ? nil : "Not compared: " + parts.joined(separator: ", ") + "."
        }
    }

    /// The rules: same kick type; same view group (an unrecorded view is never compared);
    /// an engine with a known scoring model; the same kind of analysis (user-assisted
    /// results only with user-assisted ones); completed; a different kick (re-analyses of
    /// the same kick don't count twice). Only earlier kicks count, so a rank never changes
    /// when later kicks are added. Each comparison then also requires the same scoring
    /// model for that area (`ScoringModel.version(of:engine:)`).
    static func eligibility(for current: RankingEntry, among all: [RankingEntry]) -> Eligibility {
        var e = Eligibility(comparable: [])
        guard current.scoringModel != nil, current.view != .unknown else { return e }
        for other in all where other.id != current.id && (other.kickID == nil || other.kickID != current.kickID) && other.date <= current.date {
            if !other.completed { e.excludedIncomplete += 1; continue }
            if other.kickType != current.kickType { e.excludedOtherKickType += 1; continue }
            if other.view != current.view { e.excludedOtherView += 1; continue }
            if other.scoringModel == nil { e.excludedOlderScoring += 1; continue }
            if other.isAssisted != current.isAssisted { e.excludedAssistance += 1; continue }
            e.comparable.append(other)
        }
        e.comparable.sort { $0.date < $1.date }
        return e
    }

    /// The comparable kicks whose scoring of `category` matches the current kick's.
    static func comparable(_ category: AnalysisCategory, current: RankingEntry, eligibility: Eligibility) -> [RankingEntry] {
        let model = ScoringModel.version(of: category, engine: current.engineVersion)
        return eligibility.comparable.filter { ScoringModel.version(of: category, engine: $0.engineVersion) == model }
    }

    struct Standing: Equatable, Sendable {
        /// 1 = best. Nil when not ranked.
        var rank: Int?
        /// Comparable kicks with a value, the current one included.
        var outOf: Int
        var text: String
    }

    /// Ties share the better rank. A kick without a value is never ranked (missing is not zero).
    static func standing(_ value: Double?, others: [Double]) -> Standing {
        guard let value else { return Standing(rank: nil, outOf: others.count, text: "Not rated") }
        let n = others.count + 1
        guard n >= minimumComparableKicks else { return Standing(rank: nil, outOf: n, text: notEnoughText) }
        let rank = 1 + others.filter { $0 > value + 1e-9 }.count
        return Standing(rank: rank, outOf: n, text: rank == 1 ? "Personal best of \(n) comparable kicks" : "#\(rank) of \(n) comparable kicks")
    }

    static func categoryStanding(_ category: AnalysisCategory, current: RankingEntry, eligibility: Eligibility) -> Standing {
        standing(current.categoryScores[category],
                 others: comparable(category, current: current, eligibility: eligibility).compactMap { $0.categoryScores[category] })
    }

    enum Trend: String, Equatable, Sendable {
        case improving, steady, declining
        var text: String {
            switch self {
            case .improving: "Improving"
            case .steady: "Steady"
            case .declining: "Declining"
            }
        }
    }

    struct History: Equatable, Sendable {
        var previous: Double?
        var best: Double?
        var isPersonalBest: Bool
        var recentAverage: Double?
        var change: Double?
        var trend: Trend?
        var standing: Standing
        var comparableCount: Int
        /// Build 18: the spread (standard deviation) of the overall score over the last
        /// comparable kicks, this one included (≥ `minimumForConsistency`).
        var spread: Double? = nil
        /// Shown when there isn't enough history yet.
        var message: String?
        var exclusionNote: String?

        var hasHistory: Bool { previous != nil }
    }

    static let historyWillPopulate = "Your history will build as you analyze more kicks of this type from the same view."

    /// Like-for-like overall-score history. Kicks without an overall score are skipped,
    /// never counted as zero.
    static func history(current: RankingEntry, eligibility: Eligibility) -> History {
        let same = comparable(.overall, current: current, eligibility: eligibility)
        var note = eligibility.exclusionNote
        let olderModel = eligibility.comparable.count - same.count
        if olderModel > 0 {
            note = (note.map { $0 + " " } ?? "") + "\(olderModel) earlier kick\(olderModel == 1 ? "" : "s") used an earlier overall scoring model; their area scores are compared where unchanged."
        }
        let values = same.compactMap(\.overallScore)
        let standing = standing(current.overallScore, others: values)
        guard let now = current.overallScore, !values.isEmpty else {
            return History(previous: nil, best: nil, isPersonalBest: false, recentAverage: nil, change: nil, trend: nil,
                           standing: standing, comparableCount: values.count + (current.overallScore == nil ? 0 : 1),
                           message: historyWillPopulate, exclusionNote: note)
        }
        let previous = values.last!
        let recent = Array(values.suffix(recentWindow))
        let best = max(values.max()!, now)
        let series = Array((values + [now]).suffix(recentWindow))
        return History(previous: previous, best: best, isPersonalBest: now >= values.max()! - 1e-9 && values.count + 1 >= minimumComparableKicks,
                       recentAverage: recent.reduce(0, +) / Double(recent.count), change: now - previous,
                       trend: series.count >= minimumComparableKicks ? trend(series) : nil,
                       standing: standing, comparableCount: values.count + 1,
                       spread: series.count >= minimumForConsistency ? standardDeviation(series) : nil,
                       message: values.count + 1 < minimumComparableKicks ? historyWillPopulate : nil,
                       exclusionNote: note)
    }

    static func trend(_ series: [Double]) -> Trend {
        let s = slope(series)
        return s > trendThreshold ? .improving : (s < -trendThreshold ? .declining : .steady)
    }

    static func slope(_ series: [Double]) -> Double {
        let n = Double(series.count)
        let xs = series.indices.map(Double.init)
        let mx = xs.reduce(0, +) / n, my = series.reduce(0, +) / n
        let den = xs.map { ($0 - mx) * ($0 - mx) }.reduce(0, +)
        guard den > 0 else { return 0 }
        return zip(xs, series).map { ($0 - mx) * ($1 - my) }.reduce(0, +) / den
    }

    static func correlation(_ series: [Double]) -> Double {
        let n = Double(series.count)
        guard n >= 2 else { return 0 }
        let xs = series.indices.map(Double.init)
        let mx = xs.reduce(0, +) / n, my = series.reduce(0, +) / n
        let sxy = zip(xs, series).map { ($0 - mx) * ($1 - my) }.reduce(0, +)
        let sxx = xs.map { ($0 - mx) * ($0 - mx) }.reduce(0, +)
        let syy = series.map { ($0 - my) * ($0 - my) }.reduce(0, +)
        guard sxx > 0, syy > 0 else { return 0 }
        return sxy / (sxx * syy).squareRoot()
    }

    static func standardDeviation(_ v: [Double]) -> Double {
        guard v.count >= 2 else { return 0 }
        let m = v.reduce(0, +) / Double(v.count)
        return (v.map { ($0 - m) * ($0 - m) }.reduce(0, +) / Double(v.count - 1)).squareRoot()
    }

    // MARK: Build 18 — consistency of measured mechanics

    struct MetricConsistency: Equatable, Sendable, Identifiable {
        var key: KickMetricKey
        var name: String
        var count: Int
        var mean: Double
        var spread: Double
        var id: String { key.rawValue }
    }

    struct MetricTrend: Equatable, Sendable {
        var key: KickMetricKey
        var name: String
        var count: Int
        var text: String
    }

    struct SessionConsistency: Equatable, Sendable {
        var kicks: Int
        var scoreRange: ClosedRange<Double>?
        var text: String
    }

    struct Consistency: Equatable, Sendable {
        /// Long-term: every like-for-like metric with enough comparable kicks.
        var metrics: [MetricConsistency]
        /// A metric that appears to be improving (strong, consistent trend), if any.
        var improving: MetricTrend?
        /// Same-session consistency (kicks in this kick's session), kept apart from long-term change.
        var session: SessionConsistency?
    }

    /// Spread of every metric this view can measure, over the comparable kicks (this one
    /// included). A metric appears to be improving only when it has a better direction,
    /// ≥ `minimumForMetricTrend` values and |correlation with kick order| ≥ 0.7 in that
    /// direction; descriptive metrics (no better direction) are never called improving.
    static func consistency(current: RankingEntry, eligibility: Eligibility) -> Consistency {
        let all = eligibility.comparable + [current]
        var metrics: [MetricConsistency] = []
        var best: (trend: MetricTrend, strength: Double)?
        for key in KickMetricKey.allCases where current.view.supports(key) {
            let values = all.compactMap { $0.metric(key) }
            guard values.count >= minimumForConsistency else { continue }
            metrics.append(MetricConsistency(key: key, name: key.definition.displayName, count: values.count,
                                             mean: values.reduce(0, +) / Double(values.count), spread: standardDeviation(values)))
            let recent = Array(values.suffix(8))
            guard recent.count >= minimumForMetricTrend else { continue }
            let r = correlation(recent)
            let better: Double
            switch key.definition.betterDirection {
            case .higher: better = r
            case .lower: better = -r
            case .towardIdealBand, .none: continue
            }
            guard better >= minimumTrendCorrelation, current.metric(key) != nil else { continue }
            let verb = key.definition.betterDirection == .higher ? "increased" : "decreased"
            let trend = MetricTrend(key: key, name: key.definition.displayName, count: recent.count,
                                    text: "\(key.definition.displayName) has \(verb) steadily across your last \(recent.count) comparable kicks.")
            if best == nil || better > best!.strength { best = (trend, better) }
        }
        var session: SessionConsistency?
        if let sid = current.sessionID {
            let same = all.filter { $0.sessionID == sid }
            if same.count >= minimumComparableKicks {
                let scores = same.compactMap(\.overallScore)
                let range = scores.count >= minimumComparableKicks ? (scores.min()!...scores.max()!) : nil
                session = SessionConsistency(kicks: same.count, scoreRange: range,
                                             text: range.map { "This session: \(same.count) comparable kicks, technique score \(DisplayFormat.score($0.lowerBound))–\(DisplayFormat.score($0.upperBound))." }
                                                ?? "This session: \(same.count) comparable kicks.")
            }
        }
        return Consistency(metrics: metrics, improving: best?.trend, session: session)
    }
}
