import Foundation

/// Step 12G: third-party components shipped in the app (shown in Profile → Acknowledgements).
/// The full Apache-2.0 text is in the repository (`THIRD_PARTY_NOTICES.md`); the license
/// requires the notice to travel with the app, which this screen does.
enum ThirdPartyNotices {
    struct Entry: Equatable, Sendable, Identifiable {
        var name: String
        var detail: String
        var id: String { name }
    }

    static let entries: [Entry] = [
        Entry(name: "YOLOX (football detector)",
              detail: "KickLab's football detector is the YOLOX-S model by Megvii (Copyright (c) 2021-2022 Megvii Inc.), licensed under the Apache License, Version 2.0, converted to Core ML by KickLab without changing its weights. Source: github.com/Megvii-BaseDetection/YOLOX. The model was trained by its authors on the COCO 2017 dataset (annotations CC BY 4.0, COCO Consortium). KickLab uses its \"sports ball\" class to find the football. Distributed on an \"AS IS\" basis, without warranties or conditions of any kind."),
    ]

    static let apacheLicenseURL = "https://www.apache.org/licenses/LICENSE-2.0"
}
