import Foundation

/// Step 12G: pure helpers for reviewing real frames in Verify Contact.
enum FrameReview {
    /// A tap in a view showing the frame aspect-fit → app-normalized frame coordinates
    /// (nil when the tap is outside the picture).
    static func normalizedPoint(tapX: Double, tapY: Double, containerWidth: Double, containerHeight: Double,
                                frameAspect: Double) -> NormalizedPoint? {
        let r = PoseOverlayGeometry.aspectFitRect(containerWidth: containerWidth, containerHeight: containerHeight, contentAspect: frameAspect)
        guard r.width > 0, r.height > 0 else { return nil }
        let x = (tapX - r.x) / r.width, y = (tapY - r.y) / r.height
        guard (0...1).contains(x), (0...1).contains(y) else { return nil }
        return NormalizedPoint(x: x, y: y)
    }

    /// The square region (app-normalized) to magnify around a point: `span` × the ball
    /// radius on each side, kept inside the frame. `radius` is a fraction of frame height.
    static func zoomRect(around p: NormalizedPoint, radius: Double, frameAspect: Double, span: Double = 4) -> NormalizedRect {
        let halfH = min(0.5, max(0.02, radius * span))
        let halfW = min(0.5, halfH / max(frameAspect, 0.01))
        let cx = min(max(p.x, halfW), 1 - halfW), cy = min(max(p.y, halfH), 1 - halfH)
        return NormalizedRect(minX: cx - halfW, minY: cy - halfH, maxX: cx + halfW, maxY: cy + halfH)
    }

    static let defaultBallRadius = 0.018
    static let ballRadiusRange: ClosedRange<Double> = 0.006...0.06

    /// "2 frames (67 ms) earlier than the automatic plant" — frames from the video's own
    /// timestamps when available.
    static func difference(user: Double, automatic: Double?, what: String, table: SourceFrameTable) -> String {
        guard let automatic else { return "There is no automatic \(what) to compare with." }
        let ms = Int(((user - automatic) * 1000).rounded())
        if abs(ms) < 1 { return "Same frame as the automatic \(what)." }
        let frames = table.frameDifference(from: automatic, to: user).map { abs($0) }
        let frameText = frames.map { "\($0) frame\($0 == 1 ? "" : "s") " } ?? ""
        return "\(frameText)(\(abs(ms)) ms) \(ms < 0 ? "earlier" : "later") than the automatic \(what)."
    }
}
