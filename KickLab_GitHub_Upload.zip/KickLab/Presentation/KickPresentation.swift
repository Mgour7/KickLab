import Foundation

/// One kick in a list.
struct KickRowPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var date: Date
    var kickType: KickType
    var title: String
    var detail: String
    var videoCount: Int
    var hasCurrentAnalysis: Bool
    var scoreText: String?
}

/// One session in a list.
struct SessionRowPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var name: String
    var date: Date
    var typeText: String
    var kickCount: Int
}

/// One video of a kick.
struct VideoRowPresentation: Equatable, Sendable, Identifiable {
    var id: UUID
    var angle: VideoAngleType
    var angleText: String
    var isPrimary: Bool
    var status: VideoStorageStatus
    var statusText: String
    var durationText: String?
    var frameRateText: String?
    /// The file is on this device and can be played or analyzed.
    var isPlayable: Bool

    static func make(id: UUID, angle: VideoAngleType, isPrimary: Bool, status: VideoStorageStatus,
                     durationSeconds: Double?, frameRate: Double?) -> VideoRowPresentation {
        VideoRowPresentation(
            id: id,
            angle: angle,
            angleText: angle == .unknown ? "Angle not set" : angle.displayName + " view",
            isPrimary: isPrimary,
            status: status,
            statusText: statusText(status),
            durationText: durationSeconds.map { DisplayFormat.number($0, digits: 1) + " s" },
            frameRateText: frameRate.map { DisplayFormat.number($0, digits: 0) + " fps" },
            isPlayable: status == .local
        )
    }

    static func statusText(_ status: VideoStorageStatus) -> String {
        switch status {
        case .local: "On this device"
        case .photosLibrary: "Only in Photos — import again to analyze"
        case .offloaded: "Offloaded"
        case .missing: "File missing — import again to analyze"
        }
    }

    /// Angles a person can choose.
    static let selectableAngles: [VideoAngleType] = [.side, .rear, .oblique, .front, .behindGoal]
}

/// A jump point in the analyzed video.
struct PhaseMarker: Equatable, Sendable, Identifiable {
    /// Step 12E: where the time came from, shown with the marker.
    enum Source: String, Sendable {
        case detected, estimated, ambiguous
        /// Chosen by the user (a user-assisted analysis).
        case userSupplied

        var label: String {
            switch self {
            case .detected: "detected"
            case .estimated: "estimated"
            case .ambiguous: "uncertain"
            case .userSupplied: "chosen by you"
            }
        }
    }

    var id: String { phase.rawValue }
    var phase: KickPhase
    var title: String
    var time: Double
    var isEstimated: Bool
    var source: Source = .estimated

    /// Markers for the phases that were found, in kick order. Contact is labeled as
    /// estimated because it comes from body motion, not the ball — or as chosen by the
    /// user in a user-assisted analysis.
    static func markers(from result: KickPhaseDetectionResult) -> [PhaseMarker] {
        KickPhase.allCases.compactMap { phase in
            let detected = result.phase(phase)
            guard detected.isAvailable, let time = detected.startTime ?? detected.representativeTime else { return nil }
            let at = phase == .contact || phase == .plant ? (detected.representativeTime ?? time) : time
            let userContact = phase == .contact && result.assistance?.effectiveContactTime != nil
            let source: Source = userContact ? .userSupplied
                : (detected.status == .detected ? .detected : (detected.status == .ambiguous ? .ambiguous : .estimated))
            return PhaseMarker(phase: phase, title: userContact ? "Your Contact" : title(phase), time: at,
                               isEstimated: detected.status != .detected, source: source)
        }
    }

    static func title(_ phase: KickPhase) -> String {
        switch phase {
        case .setup: "Setup"
        case .approach: "Approach"
        case .plant: "Plant"
        case .contact: "Estimated Contact"
        case .followThrough: "Follow-Through"
        }
    }
}

enum KickPresentation {
    /// "Made · 40 yd · Training" style summary of a kick's outcome.
    static func detail(outcome: KickOutcome?, context: KickContext, hash: HashLocation) -> String {
        var parts: [String] = []
        switch outcome {
        case .fieldGoal(let fg)?, .pat(let fg)?:
            if fg.result != .unknown { parts.append(fg.result.displayName) }
            if let d = fg.distance?.value { parts.append(DisplayFormat.yards(d)) }
            if hash != .notApplicable { parts.append(hash.displayName) }
        case .kickoff(let ko)?:
            if ko.touchback == true { parts.append("Touchback") }
            if ko.outOfBounds == true { parts.append("Out of bounds") }
            if let d = ko.distance?.value { parts.append(DisplayFormat.yards(d)) }
            if let h = ko.hangTime?.value { parts.append(DisplayFormat.seconds(h) + " hang") }
        case .punt(let p)?:
            if let d = p.distance?.value { parts.append(DisplayFormat.yards(d)) }
            if let h = p.hangTime?.value { parts.append(DisplayFormat.seconds(h) + " hang") }
        case nil:
            break
        }
        parts.append(context.displayName)
        return parts.joined(separator: " · ")
    }
}

/// Turns errors into text people can act on. Raw error descriptions are never shown.
enum UserFacingError {
    static func message(for error: any Error) -> String {
        if isOutOfSpace(error) { return outOfSpaceMessage }
        if let e = error as? KickValidationError {
            return e.issues.first?.description ?? "Some values aren't valid."
        }
        if let e = error as? VideoStorageError, let text = e.errorDescription { return text }
        if let e = error as? AthleteServiceError, let text = e.errorDescription { return text }
        if let e = error as? KickServiceError, let text = e.errorDescription { return text }
        if let e = error as? KickingSessionServiceError, let text = e.errorDescription { return text }
        if let e = error as? AnalysisServiceError, let text = e.errorDescription { return text }
        if let e = error as? VideoAnalysisError {
            return AnalysisProblem.from(engineError: e).message
        }
        return "Something went wrong. Please try again."
    }
}

/// Step 12E: replay speeds. Slow motion plays the video's real frames more slowly; it
/// never invents frames between them.
enum PlaybackRate: Float, CaseIterable, Sendable, Identifiable {
    case full = 1
    case half = 0.5
    case quarter = 0.25

    var id: Float { rawValue }
    var title: String {
        switch self {
        case .full: "1×"
        case .half: "½×"
        case .quarter: "¼×"
        }
    }
}

/// Loading / loaded / failed state for a screen.
enum LoadState<Value: Equatable & Sendable>: Equatable, Sendable {
    case loading
    case loaded(Value)
    case failed(String)

    var value: Value? {
        if case .loaded(let value) = self { return value }
        return nil
    }
}
