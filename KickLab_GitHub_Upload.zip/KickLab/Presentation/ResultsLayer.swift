import Foundation

/// Build 20 — the RESULTS layer: what actually happened to the kicks, as entered by the
/// athlete. Kept entirely separate from technique and consistency: nothing here is
/// inferred from pose, and no biomechanical measurement is said to have caused a result.
///
/// Wind and weather: only the athlete's free-text conditions note (`Kick.conditionsNote`,
/// Step 12F) exists. Results are grouped by identical notes; KickLab never infers wind or
/// weather, and structured wind fields would need a schema migration (not done).
struct KickResultsSummary: Equatable, Sendable {
    struct Line: Equatable, Sendable, Identifiable {
        var title: String
        var value: String
        var detail: String?
        var id: String { title }
    }

    var kickType: KickType
    /// This kick: "Made · 40 yd", or nil when nothing was entered.
    var thisKick: String?
    /// This kick's session, when it has one with recorded results ("FG 3 of 4").
    var session: String?
    /// All recorded kicks of this type.
    var overall: GoalpostSummary?
    /// Recent sessions (newest first) with recorded kicks of this type.
    var recentSessions: [Line]
    /// Distance bands, longest make, miss directions — each with its sample size.
    var lines: [Line]

    /// The one-line Results summary for the report.
    var summaryText: String {
        var parts: [String] = [thisKick ?? "Result not recorded"]
        if let session { parts.append("this session \(session)") }
        if let o = overall, o.overall.attempts > 0 {
            parts.append("all \(kickType == .pat ? "PATs" : "field goals") \(o.overall.text)")
        }
        return parts.joined(separator: " · ")
    }

    static func make(kickID: UUID?, sessionID: UUID?, kickType: KickType, thisKick: String?, records: [KickStatRecord]) -> KickResultsSummary {
        let sameType = records.filter { $0.kickType == kickType }
        var session: String?
        if let sessionID {
            let s = SessionPerformanceSummary.make(sameType.filter { $0.sessionID == sessionID })
            if let g = (kickType == .pat ? s.pats : s.fieldGoals), g.overall.attempts > 0 {
                session = "\(g.overall.successes) of \(g.overall.attempts) made"
            } else if !s.isEmpty, kickType == .kickoff || kickType == .punt {
                session = s.shortText
            }
        }
        let overall: GoalpostSummary? = (kickType == .fieldGoal || kickType == .pat) ? GoalpostSummary.make(sameType, type: kickType) : nil

        var lines: [Line] = []
        if let g = overall, g.overall.attempts > 0 {
            for b in g.byDistance {
                lines.append(Line(title: "\(b.bucket.displayName) yd", value: b.rate.text, detail: b.rate.sampleNote))
            }
            if let longest = g.longestMake { lines.append(Line(title: "Longest recorded make", value: DisplayFormat.yards(longest), detail: nil)) }
            let missTotal = g.misses.map(\.count).reduce(0, +)
            if missTotal > 0 {
                lines.append(Line(title: "Misses", value: g.misses.map { "\($0.result.displayName.lowercased()) \($0.count)" }.joined(separator: ", "),
                                  detail: "\(missTotal) recorded miss\(missTotal == 1 ? "" : "es")"))
            }
            if g.unrecorded > 0 { lines.append(Line(title: "Result not recorded", value: "\(g.unrecorded)", detail: "Not counted as attempts")) }
            // Results by the conditions the athlete entered (identical notes only).
            let decided = sameType.filter { ($0.result ?? .unknown) != .unknown }
            let noted = Dictionary(grouping: decided.compactMap { r -> (String, KickStatRecord)? in
                guard let c = r.conditions?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(), !c.isEmpty else { return nil }
                return (c, r)
            }, by: \.0)
            for (note, group) in noted.sorted(by: { $0.key < $1.key }) {
                let rate = RateSummary(successes: group.filter { $0.1.result == .made }.count, attempts: group.count)
                lines.append(Line(title: "Conditions: \(note)", value: rate.text, detail: rate.sampleNote))
            }
        }

        // Recent sessions with recorded kicks of this type (newest first, at most 3).
        let bySession = Dictionary(grouping: sameType.filter { $0.sessionID != nil }) { $0.sessionID! }
        let recent = bySession.map { (id: $0.key, kicks: $0.value, date: $0.value.map(\.timestamp).max() ?? .distantPast) }
            .sorted { $0.date > $1.date }
            .prefix(3)
            .map { s -> Line in
                let summary = SessionPerformanceSummary.make(s.kicks)
                return Line(title: DisplayFormat.shortDate(s.date) + (s.id == sessionID ? " (this session)" : ""),
                            value: summary.shortText, detail: nil)
            }
        return KickResultsSummary(kickType: kickType, thisKick: thisKick, session: session, overall: overall,
                                  recentSessions: Array(recent), lines: lines)
    }
}
