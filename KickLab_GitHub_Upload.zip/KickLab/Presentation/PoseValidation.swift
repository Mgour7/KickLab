import Foundation

// Step 12C: the pure part of the developer Pose Validation player — overlay geometry,
// skeleton styling, pose sources and markers. Platform-independent and fully tested;
// the SwiftUI/AVFoundation view only draws what this computes.

/// A rectangle in view points.
struct OverlayRect: Equatable, Sendable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double
}

enum PoseOverlayGeometry {
    /// Where an aspect-fit video sits inside a container: centered, letterboxed or
    /// pillarboxed, never stretched. `contentAspect` is the DISPLAYED width ÷ height
    /// (orientation already applied), as stored with the pose.
    static func aspectFitRect(containerWidth: Double, containerHeight: Double, contentAspect: Double) -> OverlayRect {
        guard containerWidth > 0, containerHeight > 0, contentAspect > 0, contentAspect.isFinite else {
            return OverlayRect(x: 0, y: 0, width: max(0, containerWidth), height: max(0, containerHeight))
        }
        let containerAspect = containerWidth / containerHeight
        if contentAspect > containerAspect {
            let height = containerWidth / contentAspect
            return OverlayRect(x: 0, y: (containerHeight - height) / 2, width: containerWidth, height: height)
        }
        let width = containerHeight * contentAspect
        return OverlayRect(x: (containerWidth - width) / 2, y: 0, width: width, height: containerHeight)
    }

    /// An app-normalized pose point (upright, top-left origin, already mirrored to match
    /// the displayed video) in view points inside the video rect.
    static func point(x: Double, y: Double, in rect: OverlayRect) -> (x: Double, y: Double) {
        (rect.x + x * rect.width, rect.y + y * rect.height)
    }
}

/// Which pose to draw.
enum PoseOverlaySource: String, CaseIterable, Sendable {
    /// Exactly what Vision reported for the kicker (before any processing).
    case raw
    /// The processed pose stored with the analysis (the analyzing build's processing).
    case stored
    /// The current build's processing (with leg repair), replayed on the stored pose.
    case current

    var title: String {
        switch self {
        case .raw: "Raw (Vision)"
        case .stored: "As analyzed"
        case .current: "Current repair"
        }
    }
}

enum OverlayLimbRole: String, Sendable {
    case kickingLeg, plantLeg, torso, arm, head
}

struct OverlayBone: Equatable, Sendable {
    var from: PoseJoint
    var to: PoseJoint
    var role: OverlayLimbRole
}

/// One joint as drawn.
struct OverlayJoint: Equatable, Sendable {
    var joint: PoseJoint
    var x: Double
    var y: Double
    var confidence: Double
    var status: PosePointStatus
    var role: OverlayLimbRole
    /// Leg repair changed this joint's label or rejected a jump here.
    var repaired: Bool
}

enum ValidationMarkerKind: String, Sendable {
    case contact, contactCandidate, plant, followThroughEnd, markedContact, storedContact
    /// Step 12G: the football detector's last clear resting frame and first persistent movement.
    case ballLastAtRest, ballFirstMovement
}

struct ValidationMarker: Equatable, Sendable, Identifiable {
    var kind: ValidationMarkerKind
    var title: String
    var time: Double
    /// Step 12D: the evidence behind the event (candidates), shown when selected.
    var detail: String? = nil
    var id: String { "\(kind.rawValue)-\(String(format: "%.4f", time))" }
}

/// Step 12D: one bar on the phase timeline.
struct TimelineSegment: Equatable, Sendable, Identifiable {
    enum Kind: String, Sendable { case kickWindow, setup, approach, plant, contact, followThrough, recovery }
    var kind: Kind
    var title: String
    var start: Double
    var end: Double
    /// nil for the kick window and recovery (not phases).
    var status: PhaseDetectionStatus?
    var id: String { "\(kind.rawValue)-\(String(format: "%.4f", start))" }
}

enum PhaseTimelineModel {
    /// The bars to draw: the selected kick window, every available phase (contact is a
    /// thin bar of one frame), and recovery after the follow-through.
    static func segments(phases: KickPhaseDetectionResult?, windows: KickWindowAnalysis?, frame: Double) -> [TimelineSegment] {
        var out: [TimelineSegment] = []
        if let w = windows?.selected {
            out.append(TimelineSegment(kind: .kickWindow, title: "Kick window", start: w.preparationStart, end: w.movementEnd, status: nil))
        }
        guard let phases else { return out }
        let kinds: [(KickPhase, TimelineSegment.Kind, String)] = [
            (.setup, .setup, "Setup"), (.approach, .approach, "Approach"), (.plant, .plant, "Plant"),
            (.contact, .contact, "Contact"), (.followThrough, .followThrough, "Follow-through"),
        ]
        for (phase, kind, title) in kinds {
            let p = phases.phase(phase)
            guard p.isAvailable, let start = p.startTime else { continue }
            let end = max(p.endTime ?? start, start + (phase == .contact ? frame : 0))
            out.append(TimelineSegment(kind: kind, title: title, start: start, end: end, status: p.status))
        }
        if let w = windows?.selected {
            let follow = phases.phase(.followThrough)
            let recoveryStart = follow.isAvailable ? (follow.endTime ?? w.followThroughEnd) : w.followThroughEnd
            if w.movementEnd > recoveryStart {
                out.append(TimelineSegment(kind: .recovery, title: "Recovery", start: recoveryStart, end: w.movementEnd, status: nil))
            }
        }
        return out
    }

    /// Position of `t` across the clip, 0…1.
    static func fraction(_ t: Double, duration: Double) -> Double {
        duration > 0 ? min(1, max(0, t / duration)) : 0
    }

    /// How a status is drawn: detected = solid, estimated = lighter, ambiguous = striped
    /// (shown as dashed outline), unavailable = not drawn.
    static func style(_ status: PhaseDetectionStatus?) -> String {
        switch status {
        case .detected: "solid"
        case .estimated: "light"
        case .ambiguous: "dashed"
        case .unavailable: "none"
        case nil: "outline"
        }
    }
}

/// Everything the player needs, built from stored artifacts plus a replay.
struct PoseValidationTimeline: Equatable, Sendable {
    var timestamps: [Double]
    var displayAspectRatio: Double
    var isMirrored: Bool
    var kickingFoot: KickingFoot
    /// Per source, one joint map per sample (nil when that source isn't available).
    var raw: [[PoseJoint: PosePoint]]
    var stored: [[PoseJoint: PosePoint]]?
    var current: [[PoseJoint: PosePoint]]?
    var legSwapSamples: Set<Int>
    var outlierSamples: Set<Int>
    var markers: [ValidationMarker]
    /// Plain-language limitations (e.g. no stored processed pose).
    var limitations: [String]
    /// Step 12D: the phase timeline and the kick windows it was built from.
    var segments: [TimelineSegment] = []
    var kickWindows: KickWindowAnalysis? = nil
    /// Step 12G: the football detector's per-frame observations (nil when it didn't run).
    var football: FootballOverlayModel? = nil
    var duration: Double { timestamps.last ?? 0 }

    static let bones: [(PoseJoint, PoseJoint)] = [
        (.leftHip, .leftKnee), (.leftKnee, .leftAnkle), (.rightHip, .rightKnee), (.rightKnee, .rightAnkle),
        (.leftShoulder, .rightShoulder), (.leftHip, .rightHip), (.leftShoulder, .leftHip), (.rightShoulder, .rightHip),
        (.leftShoulder, .leftElbow), (.leftElbow, .leftWrist), (.rightShoulder, .rightElbow), (.rightElbow, .rightWrist),
        (.neck, .nose),
    ]

    func role(of joint: PoseJoint) -> OverlayLimbRole {
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        if [sides.kickingHip, sides.kickingKnee, sides.kickingAnkle].contains(joint) { return .kickingLeg }
        if [sides.plantHip, sides.plantKnee, sides.plantAnkle].contains(joint) { return .plantLeg }
        switch joint {
        case .leftShoulder, .rightShoulder, .neck, .root: return .torso
        case .leftElbow, .rightElbow, .leftWrist, .rightWrist: return .arm
        default: return .head
        }
    }

    /// Bones colored by role: a bone belongs to a leg only when both ends do.
    func bones() -> [OverlayBone] {
        Self.bones.map { a, b in
            let ra = role(of: a), rb = role(of: b)
            return OverlayBone(from: a, to: b, role: ra == rb ? ra : .torso)
        }
    }

    func frames(_ source: PoseOverlaySource) -> [[PoseJoint: PosePoint]]? {
        switch source {
        case .raw: raw
        case .stored: stored
        case .current: current
        }
    }

    var availableSources: [PoseOverlaySource] {
        PoseOverlaySource.allCases.filter { frames($0) != nil }
    }

    /// Typical spacing of analyzed samples.
    var sampleInterval: Double {
        1 / KickPhaseDetector.framesPerSecond(timestamps)
    }

    /// The analyzed sample shown at `time`: the nearest one, if within half an interval.
    func sampleIndex(at time: Double) -> Int? {
        guard !timestamps.isEmpty else { return nil }
        var low = 0
        var high = timestamps.count - 1
        while low < high {
            let mid = (low + high) / 2
            if timestamps[mid] < time { low = mid + 1 } else { high = mid }
        }
        var best = low
        if low > 0, abs(timestamps[low - 1] - time) <= abs(timestamps[low] - time) { best = low - 1 }
        return abs(timestamps[best] - time) <= sampleInterval / 2 + 1e-6 ? best : nil
    }

    /// The time of the analyzed sample `delta` steps from the one nearest `time`. Steps
    /// are taken on the stored timestamps themselves, so repeated stepping never drifts.
    func steppedTime(from time: Double, by delta: Int) -> Double? {
        guard !timestamps.isEmpty else { return nil }
        let nearest = timestamps.indices.min { abs(timestamps[$0] - time) < abs(timestamps[$1] - time) } ?? 0
        let target = min(timestamps.count - 1, max(0, nearest + delta))
        return timestamps[target]
    }

    /// The joints to draw at a sample, for a source.
    func overlay(at index: Int, source: PoseOverlaySource) -> [OverlayJoint] {
        guard let frames = frames(source), frames.indices.contains(index) else { return [] }
        let repaired = source == .current && (legSwapSamples.contains(index) || outlierSamples.contains(index))
        return PoseJoint.allCases.compactMap { joint in
            guard let p = frames[index][joint], p.isAvailable else { return nil }
            let r = role(of: joint)
            let legJoint = [.leftKnee, .rightKnee, .leftAnkle, .rightAnkle].contains(joint)
            return OverlayJoint(joint: joint, x: p.x, y: p.y, confidence: p.confidence, status: p.status, role: r,
                                repaired: repaired && legJoint)
        }
    }

    /// Builds the timeline. `raw` comes from the stored Vision sequence; `stored` from
    /// the stored processed timeline; `current` from the replay. Missing ones are listed
    /// in `limitations`.
    static func make(
        sequence: PoseSequence,
        storedTimeline: KickerPoseTimeline?,
        currentTimeline: KickerPoseTimeline?,
        repair: PoseRepairReport?,
        kickingFoot: KickingFoot,
        storedPhases: KickPhaseDetectionResult?,
        currentPhases: KickPhaseDetectionResult?,
        markedContact: Double?,
        football: FootballTrack? = nil
    ) -> PoseValidationTimeline? {
        guard let id = sequence.kickerTrackID else { return nil }
        let rawTimeline = KickerPoseTimeline.make(from: sequence.frames, trackID: id, displayAspectRatio: sequence.displayAspectRatio)
        let times = rawTimeline.samples.map(\.timestamp)
        func aligned(_ t: KickerPoseTimeline?) -> [[PoseJoint: PosePoint]]? {
            guard let t, t.samples.map(\.timestamp) == times else { return nil }
            return t.samples.map(\.joints)
        }
        var limitations: [String] = []
        let stored = aligned(storedTimeline)
        if stored == nil { limitations.append("This analysis has no stored processed pose that lines up with its frames; only raw and current are shown.") }
        let current = aligned(currentTimeline)
        if current == nil { limitations.append("The current processing couldn't be replayed on this pose.") }
        if storedTimeline != nil, repair != nil {
            limitations.append("Leg-repair markers show what the CURRENT build repairs; analyses made before engine 2.1.0 stored no repair.")
        }

        var markers: [ValidationMarker] = []
        if let phases = currentPhases {
            if let t = phases.estimatedContactTime { markers.append(ValidationMarker(kind: .contact, title: "Estimated contact", time: t)) }
            if let t = phases.plantTime { markers.append(ValidationMarker(kind: .plant, title: "Plant touchdown", time: t)) }
            let follow = phases.phase(.followThrough)
            if follow.isAvailable, let t = follow.endTime { markers.append(ValidationMarker(kind: .followThroughEnd, title: "Follow-through end", time: t)) }
            for c in phases.evidence?.contactCandidates ?? [] where !c.selected {
                markers.append(ValidationMarker(kind: .contactCandidate, title: String(format: "Candidate %.2f s", c.time), time: c.time,
                                                detail: candidateDetail(c)))
            }
            if let c = phases.evidence?.contactCandidates?.first(where: \.selected),
               let i = markers.firstIndex(where: { $0.kind == .contact }) {
                markers[i].detail = candidateDetail(c)
            }
        }
        if let t = storedPhases?.estimatedContactTime, t != currentPhases?.estimatedContactTime {
            markers.append(ValidationMarker(kind: .storedContact, title: "Contact (as analyzed)", time: t))
        }
        if let t = markedContact { markers.append(ValidationMarker(kind: .markedContact, title: "Marked contact", time: t)) }
        let ball = FootballOverlayModel(track: football)
        if let t = ball?.lastStationaryTime {
            markers.append(ValidationMarker(kind: .ballLastAtRest, title: "Ball last at rest", time: t, detail: ball?.note))
        }
        if let t = ball?.firstMovementTime {
            markers.append(ValidationMarker(kind: .ballFirstMovement, title: "Ball first moved", time: t, detail: ball?.note))
        }
        markers.sort { $0.time < $1.time }

        let frame = times.count > 1 ? 1 / KickPhaseDetector.framesPerSecond(times) : 1.0 / 30
        return PoseValidationTimeline(
            timestamps: times, displayAspectRatio: sequence.displayAspectRatio ?? 9.0 / 16.0, isMirrored: sequence.isMirrored,
            kickingFoot: kickingFoot, raw: rawTimeline.samples.map(\.joints), stored: stored, current: current,
            legSwapSamples: Set(repair?.legSwapSamples ?? []), outlierSamples: Set(repair?.outlierSamples ?? []),
            markers: markers, limitations: limitations,
            segments: PhaseTimelineModel.segments(phases: currentPhases ?? storedPhases,
                                                  windows: (currentPhases ?? storedPhases)?.kickWindows, frame: frame),
            kickWindows: (currentPhases ?? storedPhases)?.kickWindows,
            football: ball
        )
    }

    /// Plain-language evidence for a contact candidate.
    static func candidateDetail(_ c: ContactCandidate) -> String {
        func n(_ v: Double?) -> String { v.map { String(format: "%.2f", $0) } ?? "—" }
        var parts = [String(format: "Speed %.1f TL/s · score %.2f · independent lines %.1f", c.peakSpeed, c.score, c.independentSupport),
                     "swing \(n(c.swingSupport)) · forward \(n(c.forwardDirection)) · plant \(n(c.plantSupport)) · passing \(n(c.passTiming)) · hips \(n(c.bodyTransition)) · follow \(n(c.followThrough))"]
        if let strike = c.strikeTime, abs(strike - c.time) > 1e-6 {
            parts.append(String(format: "contact timed at %.3f s (%@)", strike, c.timingBasis ?? ""))
        }
        if !c.supportingSignals.isEmpty { parts.append("supported by: " + c.supportingSignals.joined(separator: ", ")) }
        parts.append(contentsOf: c.rejectionReasons.map { "rejected: " + $0 })
        return parts.joined(separator: "\n")
    }
}

/// Estimated vs. marked contact, as the player shows it.
struct ContactComparison: Equatable, Sendable {
    var marked: Double
    var estimated: Double?
    var signedMilliseconds: Double?
    var absoluteMilliseconds: Double?
    var frames: Double?

    init(marked: Double, estimated: Double?, framesPerSecond: Double) {
        self.marked = marked
        self.estimated = estimated
        let error = estimated.map { $0 - marked }
        signedMilliseconds = error.map { ($0 * 1000).rounded() }
        absoluteMilliseconds = signedMilliseconds.map(abs)
        frames = error.map { (($0 * framesPerSecond) * 100).rounded() / 100 }
    }

    var text: String {
        guard let signed = signedMilliseconds, let frames else { return "No automatic contact estimate to compare." }
        let direction = signed > 0 ? "after" : (signed < 0 ? "before" : "at")
        return String(format: "Estimate is %.0f ms %@ the marked contact (%+.0f ms, %+.2f frames).", abs(signed), direction, signed, frames)
    }
}
