import Foundation

// Build 20 — Kick Comparison 1.0 (pure logic; the screens are in UI/CompareKicksView.swift).
//
// Two previously analyzed kicks are reviewed together: videos synchronized relative to
// each kick's CONTACT (not the video start), with the contact precision shown, an optional
// manual alignment nudge that is never written back to either analysis, and a table of
// measurements compared only where definitions and camera views match. Unavailable values
// are shown as "—", never as zero. See Docs/COMPARISON_FEATURE.md.

/// How a kick's contact time was established (provenance is shown, never changed here).
enum ContactProvenanceKind: String, Equatable, Sendable {
    case automatic
    case userAssisted
    case notEstablished
    /// Build 21: a second camera's contact, from camera A's contact and the sync offset.
    case cameraSync

    var title: String {
        switch self {
        case .automatic: "Automatic contact"
        case .userAssisted: "Contact chosen by you"
        case .notEstablished: "Contact not established"
        case .cameraSync: "Contact from camera A + your sync"
        }
    }
}

/// One stored metric value as the comparison sees it.
struct ComparisonMetric: Equatable, Sendable {
    var value: Double
    var definitionVersion: Int
    var confidence: Double?
}

/// A previously analyzed kick that can be compared.
struct ComparisonKick: Equatable, Sendable, Identifiable {
    var analysisID: UUID
    var kickID: UUID
    var athleteID: UUID?
    var date: Date
    var kickType: KickType
    var view: ComparableView
    var result: KickResult?
    var distanceYards: Double?
    var sessionID: UUID?
    var isReference: Bool
    var hasVideo: Bool
    var engineVersion: String
    /// Reliable available metrics (confidence ≥ `KickComparison.minimumConfidence`).
    var metrics: [KickMetricKey: ComparisonMetric]
    var categoryScores: [AnalysisCategory: Double] = [:]
    var id: UUID { analysisID }

    var isAssisted: Bool { AnalysisAssistanceLabel.isAssisted(engineVersion) }
    var isMade: Bool? { result.flatMap { $0 == .unknown ? nil : $0.isMake } }

    /// "Oct 10 · Field Goal · Made · 40 yd".
    var title: String {
        var parts = [DisplayFormat.shortDate(date), kickType.displayName]
        if let r = result, r != .unknown { parts.append(r.displayName) }
        if let d = distanceYards { parts.append(DisplayFormat.yards(d)) }
        return parts.joined(separator: " · ")
    }

    var badges: [String] {
        var out: [String] = [view.title]
        if isReference { out.append("Reference kick") }
        if isAssisted { out.append("User-assisted") }
        if !hasVideo { out.append("Video not on this device") }
        return out
    }
}

/// One side of the synchronized playback.
struct ComparisonSide: Equatable, Sendable {
    /// The analysis's own contact time (seconds into the video), nil when not established.
    var contactTime: Double?
    /// The stored contact interval, when the engine recorded one.
    var contactEarliest: Double?
    var contactLatest: Double?
    var provenance: ContactProvenanceKind
    var duration: Double
    /// Seconds per analyzed/source frame (1 / frame rate).
    var frameInterval: Double

    /// Width of the contact interval; one frame when no interval was stored.
    var contactWidth: Double? {
        guard contactTime != nil else { return nil }
        if let a = contactEarliest, let b = contactLatest, b >= a { return max(b - a, 0) }
        return frameInterval
    }
}

/// Maps a shared "time relative to contact" to each video's own time.
struct ComparisonAlignment: Equatable, Sendable {
    enum Status: Equatable, Sendable {
        /// Both contacts established and precise enough to call the videos synchronized.
        case aligned(uncertainty: Double)
        /// Both established, but the combined contact uncertainty is too wide.
        case uncertain(uncertainty: Double)
        /// At least one contact is missing: the videos start together instead.
        case notAligned(reason: String)
    }

    var a: ComparisonSide
    var b: ComparisonSide
    /// A manual nudge applied to Kick B's time (seconds). Comparison only: never saved
    /// to either analysis and never changes its provenance.
    var manualOffset: Double = 0

    /// Synchronization within this (±, seconds) is called "aligned at contact".
    static let alignedTolerance = 0.07
    /// The nudge is limited to this many seconds either way.
    static let maximumOffset = 1.0

    var isContactAligned: Bool { a.contactTime != nil && b.contactTime != nil }
    private var anchorA: Double { isContactAligned ? a.contactTime! : 0 }
    private var anchorB: Double { isContactAligned ? b.contactTime! : 0 }

    func timeA(_ relative: Double) -> Double { anchorA + relative }
    func timeB(_ relative: Double) -> Double { anchorB + relative + manualOffset }
    func relative(fromA t: Double) -> Double { t - anchorA }

    /// Relative times where BOTH videos have footage (nil when they don't overlap).
    var range: ClosedRange<Double>? {
        let lower = max(-anchorA, -(anchorB + manualOffset))
        let upper = min(a.duration - anchorA, b.duration - anchorB - manualOffset)
        return upper > lower ? lower...upper : nil
    }

    /// Frame stepping moves by the coarser of the two frame intervals, so each press
    /// shows a new frame in both videos.
    var step: Double { max(a.frameInterval, b.frameInterval) }

    /// Half of each contact interval, added: how far apart the two contacts could truly be.
    var uncertainty: Double? {
        guard let wa = a.contactWidth, let wb = b.contactWidth else { return nil }
        return (wa + wb) / 2
    }

    var status: Status {
        guard isContactAligned, let u = uncertainty else {
            let missing = a.contactTime == nil && b.contactTime == nil ? "either kick" : (a.contactTime == nil ? "Kick A" : "Kick B")
            return .notAligned(reason: "Contact wasn't established for \(missing), so the videos start together and are not synchronized at contact.")
        }
        return u <= Self.alignedTolerance + 1e-9 ? .aligned(uncertainty: u) : .uncertain(uncertainty: u)
    }

    var statusText: String {
        var text: String
        switch status {
        case .aligned(let u): text = String(format: "Aligned at contact (±%.3f s)", u)
        case .uncertain(let u): text = String(format: "Contact timing is uncertain: the videos may be out of sync by up to ±%.2f s", u)
        case .notAligned(let reason): text = reason
        }
        if abs(manualOffset) > 1e-9 { text += String(format: " · Kick B shifted %@%.3f s by you (this comparison only)", manualOffset > 0 ? "+" : "−", abs(manualOffset)) }
        return text
    }

    /// Nudges Kick B by whole frames, within ±`maximumOffset`.
    func nudged(frames: Int) -> ComparisonAlignment {
        var copy = self
        copy.manualOffset = min(Self.maximumOffset, max(-Self.maximumOffset, manualOffset + Double(frames) * step))
        if abs(copy.manualOffset) < 1e-9 { copy.manualOffset = 0 }
        return copy
    }

    /// The starting point: shortly before contact when possible.
    var initialRelativeTime: Double {
        guard let range else { return 0 }
        let preferred = isContactAligned ? -1.0 : 0
        return min(max(preferred, range.lowerBound), range.upperBound)
    }

    /// Snaps a relative time onto the shared range.
    func clamp(_ relative: Double) -> Double {
        guard let range else { return 0 }
        return min(max(relative, range.lowerBound), range.upperBound)
    }
}

/// One row of the measurement table.
struct ComparisonRow: Equatable, Sendable, Identifiable {
    var key: String
    var name: String
    var a: String
    var b: String
    /// "B − A", nil when either value is missing or the definitions differ.
    var difference: String?
    var note: String?
    var id: String { key }
}

enum ComparisonFilter: Equatable, Sendable, Hashable {
    case all
    case made
    case missed
    /// Same distance band as the given distance.
    case sameDistance(Double)
    case sameSession(UUID)
    case reference
    case sameView(ComparableView)

    var title: String {
        switch self {
        case .all: "All"
        case .made: "Made"
        case .missed: "Missed"
        case .sameDistance: "Same distance"
        case .sameSession: "Same session"
        case .reference: "Reference"
        case .sameView: "Same view"
        }
    }
}

enum ComparisonSort: String, CaseIterable, Sendable {
    case newest, oldest, distance
    var title: String {
        switch self {
        case .newest: "Newest"
        case .oldest: "Oldest"
        case .distance: "Distance"
        }
    }
}

enum KickComparison {
    /// Measurements below this confidence aren't compared (same as personal history).
    static let minimumConfidence = PersonalRanking.minimumHistoryConfidence

    static func filter(_ kicks: [ComparisonKick], by filter: ComparisonFilter, excluding: UUID? = nil, sort: ComparisonSort = .newest) -> [ComparisonKick] {
        let kept = kicks.filter { k in
            guard k.analysisID != excluding else { return false }
            switch filter {
            case .all: return true
            case .made: return k.isMade == true
            case .missed: return k.isMade == false
            case .sameDistance(let yards):
                guard let d = k.distanceYards, let band = DistanceBucket.bucket(forYards: yards) else { return false }
                return DistanceBucket.bucket(forYards: d) == band
            case .sameSession(let id): return k.sessionID == id
            case .reference: return k.isReference
            case .sameView(let v): return k.view == v
            }
        }
        switch sort {
        case .newest: return kept.sorted { $0.date > $1.date }
        case .oldest: return kept.sorted { $0.date < $1.date }
        case .distance: return kept.sorted { ($0.distanceYards ?? -1, $0.date) > ($1.distanceYards ?? -1, $1.date) }
        }
    }

    /// A sensible partner for `kick`: the athlete's reference kick of the same type and
    /// view, else the most recent earlier kick of the same type and view.
    static func suggestedPartner(for kick: ComparisonKick, among kicks: [ComparisonKick]) -> ComparisonKick? {
        let compatible = kicks.filter { $0.analysisID != kick.analysisID && $0.kickID != kick.kickID && $0.kickType == kick.kickType && $0.view == kick.view }
        if let ref = compatible.first(where: \.isReference) { return ref }
        return compatible.filter { $0.date <= kick.date }.max { $0.date < $1.date } ?? compatible.max { $0.date < $1.date }
    }

    /// Why measurements can't be compared, or nil when they can.
    static func incompatibility(_ a: ComparisonKick, _ b: ComparisonKick) -> String? {
        if a.kickID == b.kickID { return "These are two analyses of the same kick." }
        if a.view == .unknown || b.view == .unknown { return "A camera view wasn't recorded, so measurements aren't compared. The videos can still be watched together." }
        if a.view != b.view { return "Filmed from different camera views (\(a.view.title.lowercased()) and \(b.view.title.lowercased())), which measure different things. The videos can still be watched together." }
        return nil
    }

    /// Notes that don't block the table but change how it reads.
    static func notes(_ a: ComparisonKick, _ b: ComparisonKick) -> [String] {
        var out: [String] = []
        if a.kickType != b.kickType { out.append("Different kick types (\(a.kickType.displayName) and \(b.kickType.displayName)).") }
        if a.isAssisted != b.isAssisted { out.append("One analysis used a contact time you chose; its timing-based values rest on that choice.") }
        return out
    }

    /// The measurement table: compatible metrics only; "—" for a missing value.
    static func rows(_ a: ComparisonKick, _ b: ComparisonKick) -> [ComparisonRow] {
        guard incompatibility(a, b) == nil else { return [] }
        var rows: [ComparisonRow] = []
        for key in KickMetricKey.allCases where a.view.supports(key) && key != .footSpeedAtContact {
            let ma = a.metrics[key], mb = b.metrics[key]
            guard ma != nil || mb != nil else { continue }
            let unit = key.definition.unit
            func text(_ m: ComparisonMetric?) -> String {
                guard let m else { return "—" }
                return DisplayFormat.signedLateralMetrics.contains(key) ? DisplayFormat.lateral(m.value, unit: unit) : DisplayFormat.metricValue(m.value, unit: unit)
            }
            var difference: String?
            var note: String?
            if let ma, let mb {
                if ma.definitionVersion != mb.definitionVersion {
                    note = "Measured with different definitions — not compared"
                } else {
                    let d = mb.value - ma.value
                    let precision = MeasurementPrecision.of(key)
                    difference = DisplayFormat.signedDifference(d, unit: unit)
                    if abs(d) < precision.meaningfulChange { note = "Within measurement precision" }
                }
            } else {
                note = "Not measured reliably in Kick \(ma == nil ? "A" : "B")"
            }
            rows.append(ComparisonRow(key: key.rawValue, name: key.definition.displayName, a: text(ma), b: text(mb), difference: difference, note: note))
        }
        // Area scores only where both were scored with the same rules for that area.
        for category in KickMetricCatalog.scoredCategories {
            guard let sa = a.categoryScores[category], let sb = b.categoryScores[category],
                  let va = ScoringModel.version(of: category, engine: a.engineVersion),
                  va == ScoringModel.version(of: category, engine: b.engineVersion) else { continue }
            let d = sb.rounded() - sa.rounded()
            rows.append(ComparisonRow(key: "area.\(category.rawValue)", name: "\(category.presentationTitle) (provisional score)",
                                      a: DisplayFormat.score(sa), b: DisplayFormat.score(sb),
                                      difference: (d >= 0 ? "+" : "−") + DisplayFormat.number(abs(d), digits: 0), note: nil))
        }
        return rows
    }
}

/// Build 20: the Personal Reference Kick — chosen by the athlete, never declared ideal by
/// KickLab. One per athlete and kick type; choosing another clears the previous one.
enum PersonalReferencePolicy {
    static let explanation = "Your reference kick is one you chose to compare against. KickLab doesn't judge it as ideal."

    /// The kicks whose reference flag must be cleared when `selected` becomes the reference.
    static func kicksToClear(selected: UUID, kickType: KickType, kicks: [(id: UUID, kickType: KickType, isReference: Bool)]) -> [UUID] {
        kicks.filter { $0.id != selected && $0.kickType == kickType && $0.isReference }.map(\.id)
    }
}

/// Build 20: what the comparison overlays may draw at a playback time — only stored
/// evidence, only on the frame it belongs to. A filled-in point is flagged so it is drawn
/// hollow ("not directly detected"), never like a detected joint.
enum ComparisonOverlay {
    struct Point: Equatable, Sendable {
        var x: Double
        var y: Double
        var measured: Bool
    }

    /// The stored sample shown at `time`, when one lies within half a frame.
    static func sample(_ timeline: KickerPoseTimeline?, at time: Double, frame: Double) -> KickerPoseSample? {
        guard let timeline, let s = timeline.samples.min(by: { abs($0.timestamp - time) < abs($1.timestamp - time) }),
              abs(s.timestamp - time) <= frame / 2 + 1e-6 else { return nil }
        return s
    }

    /// The plant ankle at `time` (nil when not tracked on that frame).
    static func plantFoot(_ timeline: KickerPoseTimeline?, at time: Double, frame: Double, kickingFoot: KickingFoot) -> Point? {
        guard let s = sample(timeline, at: time, frame: frame),
              let p = s.point(KickingSideJoints(kickingFoot: kickingFoot).plantAnkle) else { return nil }
        return Point(x: p.x, y: p.y, measured: p.status == .measured)
    }

    /// True on the frame(s) within half a frame of the analysis's contact time.
    static func isContactFrame(time: Double, contact: Double?, frame: Double) -> Bool {
        guard let contact else { return false }
        return abs(time - contact) <= frame / 2 + 1e-6
    }

    /// The sideways plant measurement drawn at contact (rear/front views only, where it is
    /// measured), from the same stored data as the measurement inspector.
    static func measurementLine(view: ComparableView, timeline: KickerPoseTimeline?, football: FootballTrack?, contact: Double?,
                                time: Double, frame: Double, kickingFoot: KickingFoot, storedValue: Double?) -> MeasurementInspection? {
        guard view == .depth, isContactFrame(time: time, contact: contact, frame: frame) else { return nil }
        if case .success(let i) = MeasurementInspection.make(kind: .plantToBall, timeline: timeline, football: football, contactTime: contact,
                                                              kickingFoot: kickingFoot, storedValue: storedValue) { return i }
        return nil
    }
}

/// Build 21 (Compare 1.1): what is drawn over the two videos. Everything starts OFF every
/// time a comparison opens — two clean videos synchronized at contact. Overlays live
/// behind "Advanced Analysis".
struct CompareOverlaySettings: Equatable, Sendable {
    var skeleton = false
    var plantFoot = false
    var football = false
    var measurementLines = false
    var contactBadge = false
    /// Experimental ball-flight path (separate optional mode).
    var ballFlight = false
    /// Athlete-centred framing (aspect kept; overlays stay registered).
    var zoomToAthlete = false

    var anyVisible: Bool { skeleton || plantFoot || football || measurementLines || contactBadge || ballFlight }
}
