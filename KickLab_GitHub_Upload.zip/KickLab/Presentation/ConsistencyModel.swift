import Foundation

// Build 20 — Performance Intelligence 4.0: the CONSISTENCY layer.
//
// How repeatably an athlete reproduces measurable mechanics, judged only against their own
// eligible kicks (same kick type, same camera-view group, same analysis kind, same metric
// definition, one analysis per physical kick, Build 19 recording exclusions applied).
// Nothing here is a technique judgement: a repeatable habit can still be mechanically
// poor, and a value away from the usual one is described, never called worse.
// See Docs/CONSISTENCY_MODEL.md.

/// How precisely KickLab measures one metric, and the smallest change worth reporting.
///
/// - `resolution`: the typical size of measurement noise for a single kick (metric units).
/// - `meaningfulChange`: the smallest difference ever called out (≥ 2 × resolution).
/// Both are provisional engineering estimates, documented with their source; none is a
/// validated coaching standard.
struct MeasurementPrecision: Equatable, Sendable {
    var resolution: Double
    var meaningfulChange: Double
    var source: String

    /// One analyzed frame at 30 fps: timing metrics can't resolve less.
    static let frame30 = 1.0 / 30

    static func of(_ key: KickMetricKey) -> MeasurementPrecision {
        if let p = estimated[key] { return p }
        if key.definition.timing == .interval || key.definition.unit == .seconds {
            return MeasurementPrecision(resolution: frame30, meaningfulChange: 2 * frame30,
                                        source: "Timing: one analyzed frame at 30 fps; meaningful change = two frames.")
        }
        if let mmd = PersonalizationConfiguration.standardTraits[key]?.minimumMeaningfulDifference {
            return MeasurementPrecision(resolution: mmd / 2, meaningfulChange: mmd,
                                        source: "Step 10 minimum meaningful difference (expert-set, unvalidated); resolution assumed to be half of it.")
        }
        // Unknown precision: a conservative unit-based fallback (never used to praise).
        let r: Double = switch key.definition.unit {
        case .degrees: 3
        case .bodyLengths: 0.05
        case .bodyLengthsPerSecond: 0.5
        case .percent: 5
        default: 0.05
        }
        return MeasurementPrecision(resolution: r, meaningfulChange: 2 * r, source: "No estimate; conservative unit default.")
    }

    /// Rear/front-view measurements, estimated from REAL Apple Vision data: the rear 7.602 s
    /// reference clip's exported plant-ankle offset and sideways trunk lean between the plant
    /// (3.767 s) and contact + 0.1 s. Frame-to-frame jitter of the plant offset was
    /// 0.015–0.02 torso lengths and its spread over contact ± 1 frame 0.03; trunk lean
    /// jittered ≈ 1° per frame. One recording, one device: provisional.
    static let estimated: [KickMetricKey: MeasurementPrecision] = [
        .plantBallLateralOffset: .init(resolution: 0.03, meaningfulChange: 0.06,
                                       source: "Rear 7.602 s Apple Vision series: plant-ankle offset spread over contact ± 1 frame ≈ 0.03 torso lengths."),
        .plantFootWidth: .init(resolution: 0.03, meaningfulChange: 0.06,
                               source: "Rear 7.602 s Apple Vision series: plant-ankle offset spread over contact ± 1 frame ≈ 0.03 torso lengths."),
        .plantLateralMovement: .init(resolution: 0.03, meaningfulChange: 0.06,
                                     source: "Rear 7.602 s Apple Vision series: frame-to-frame plant-ankle jitter 0.015–0.02 torso lengths (a maximum displacement carries that noise)."),
        .lateralTrunkLeanAtContact: .init(resolution: 1, meaningfulChange: 3,
                                          source: "Rear 7.602 s Apple Vision series: sideways trunk lean jitter ≈ 1° per frame."),
    ]
}

/// A descriptive (not numeric) consistency level for one metric's spread.
enum RepeatabilityLevel: String, Equatable, Sendable, CaseIterable {
    /// Spread (SD) within the measurement resolution: KickLab can't tell the kicks apart.
    case withinPrecision
    /// Spread at most the meaningful change.
    case repeatable
    /// Spread above the meaningful change.
    case variable

    var title: String {
        switch self {
        case .withinPrecision: "As repeatable as KickLab can measure"
        case .repeatable: "Repeatable"
        case .variable: "Variable"
        }
    }

    static func of(spread: Double, precision: MeasurementPrecision) -> RepeatabilityLevel {
        if spread <= precision.resolution + 1e-9 { return .withinPrecision }
        if spread <= precision.meaningfulChange + 1e-9 { return .repeatable }
        return .variable
    }
}

/// This kick compared with the athlete's usual value.
enum UsualComparison: Equatable, Sendable {
    /// Fewer than `ConsistencyModel.minimumBaseline` earlier eligible values.
    case noBaseline(have: Int)
    /// The difference is within measurement precision and the athlete's usual spread.
    case withinUsual
    /// Larger than both the meaningful change and 2 × the usual spread.
    case higherThanUsual
    case lowerThanUsual

    var isNotable: Bool { self == .higherThanUsual || self == .lowerThanUsual }
}

/// One metric's consistency assessment for the current kick.
struct MetricConsistencyAssessment: Equatable, Sendable, Identifiable {
    var key: KickMetricKey
    var name: String
    var unit: MetricUnit
    /// This kick's value (nil when it wasn't measured reliably or isn't eligible).
    var current: Double?
    /// Earlier eligible values, oldest first.
    var earlier: [Double]
    var usualMean: Double?
    var usualSpread: Double?
    var difference: Double?
    var comparison: UsualComparison
    /// Spread across the recent eligible kicks INCLUDING this one (≥ `minimumForSpread`).
    var spreadCount: Int
    var spread: Double?
    var range: Double?
    var level: RepeatabilityLevel?
    var precision: MeasurementPrecision
    var id: String { key.rawValue }

    /// "0.70 torso lengths · plant-leg side" style value text.
    func text(_ v: Double) -> String {
        DisplayFormat.signedLateralMetrics.contains(key) ? DisplayFormat.lateral(v, unit: unit) : DisplayFormat.metricValue(v, unit: unit)
    }

    func signedDifferenceText(_ d: Double) -> String {
        DisplayFormat.signedDifference(d, unit: unit)
    }

    /// "Usual 0.62 torso lengths · plant-leg side (SD 0.04, 3 earlier kicks)".
    var usualText: String? {
        guard let m = usualMean, let s = usualSpread else { return nil }
        return "Usual \(text(m)) (SD \(DisplayFormat.number(s, digits: 2)), \(earlier.count) earlier kick\(earlier.count == 1 ? "" : "s"))"
    }

    /// The athlete-facing reading of this kick against the usual value. Describes the
    /// direction only; never says better or worse.
    var interpretation: String {
        switch comparison {
        case .noBaseline(let have):
            let need = ConsistencyModel.minimumBaseline - have
            return "Building your baseline: \(need) more comparable kick\(need == 1 ? "" : "s") needed."
        case .withinUsual:
            return "Within your usual range."
        case .higherThanUsual, .lowerThanUsual:
            let higher = comparison == .higherThanUsual
            let phrase = ConsistencyModel.directionPhrase(key, higher: higher, current: current, usual: usualMean)
            return "\(phrase) than on your recent comparable kicks."
        }
    }

    /// "Varied by 0.09 torso lengths across 4 comparable kicks."
    var spreadText: String? {
        guard let range, spreadCount >= ConsistencyModel.minimumForSpread else { return nil }
        return "Varied by \(DisplayFormat.metricValue(range, unit: unit)) across \(spreadCount) comparable kicks"
    }
}

/// Consistency of the current kick against the athlete's own eligible history.
struct ConsistencyReport: Equatable, Sendable {
    enum Status: Equatable, Sendable {
        /// Not enough eligible comparable kicks for any spread.
        case buildingBaseline(have: Int, need: Int)
        /// At least one metric has a spread.
        case assessed
        /// This kick can't be assessed (wrong view, cropped, blocking quality, incomplete).
        case notApplicable(reason: String)
    }

    var status: Status
    var metrics: [MetricConsistencyAssessment]
    /// Eligible comparable kicks, this one included.
    var comparableKicks: Int
    var excluded: [String: Int]

    var assessed: [MetricConsistencyAssessment] { metrics.filter { $0.level != nil } }
    var notable: [MetricConsistencyAssessment] { metrics.filter(\.comparison.isNotable) }

    /// The Consistency summary line ("Building baseline" until enough kicks exist).
    var summaryText: String {
        switch status {
        case .buildingBaseline(let have, let need):
            return "Building baseline · \(have) of \(need) comparable kicks"
        case .notApplicable(let reason):
            return "Not assessed · \(reason)"
        case .assessed:
            let a = assessed
            let steady = a.filter { $0.level != .variable }.count
            return "Repeatable on \(steady) of \(a.count) measurement\(a.count == 1 ? "" : "s") · \(comparableKicks) comparable kicks"
        }
    }

    /// The measurable goal offered when no technique correction is supported.
    var baselineGoal: String? {
        guard case .buildingBaseline(let have, let need) = status else { return nil }
        let more = need - have
        return "Record \(more) more comparable kick\(more == 1 ? "" : "s") (same kick type and camera view) to build your consistency baseline."
    }
}

enum ConsistencyModel {
    /// "Usual" needs at least this many EARLIER eligible values (Build 19 rule).
    static let minimumBaseline = PersonalRanking.minimumUsualRecordings
    /// A spread (and a consistency level) needs at least this many eligible values,
    /// this kick included. Never from one recording.
    static let minimumForSpread = 4
    /// The spread is taken over at most this many recent eligible kicks.
    static let recentWindow = 10
    /// A difference from the usual value is notable only beyond this many usual SDs (and
    /// beyond the metric's meaningful change).
    static let spreadMultiple = 2.0

    /// Metrics worth assessing for a view group (descriptive and scored alike).
    static func keys(for view: ComparableView) -> [KickMetricKey] {
        KickMetricKey.allCases.filter { view.supports($0) && $0 != .footSpeedAtContact }
    }

    static func make(current: RankingEntry, eligibility: PersonalRanking.Eligibility) -> ConsistencyReport {
        var excluded: [String: Int] = [:]
        // One value per physical kick (eligibility already drops the current kick's other
        // analyses; duplicates of another kick keep the latest).
        var byKick: [UUID: RankingEntry] = [:]
        var loose: [RankingEntry] = []
        for e in eligibility.comparable {
            if let r = e.recording.exclusionReason { excluded[r, default: 0] += 1; continue }
            if let k = e.kickID {
                if let prior = byKick[k], prior.date >= e.date { continue }
                byKick[k] = e
            } else { loose.append(e) }
        }
        let earlier = (Array(byKick.values) + loose).sorted { $0.date < $1.date }

        if current.view == .unknown { return ConsistencyReport(status: .notApplicable(reason: "camera view not recorded"), metrics: [], comparableKicks: 0, excluded: excluded) }
        if !current.completed { return ConsistencyReport(status: .notApplicable(reason: "analysis incomplete"), metrics: [], comparableKicks: 0, excluded: excluded) }
        let currentEligible = current.recording.eligibleForMeasurementHistory

        var metrics: [MetricConsistencyAssessment] = []
        for key in keys(for: current.view) {
            let values = earlier.compactMap { $0.metric(key) }
            let now = currentEligible ? current.metric(key) : nil
            guard !values.isEmpty || now != nil else { continue }
            let precision = MeasurementPrecision.of(key)
            var mean: Double?, sd: Double?, diff: Double?
            var comparison = UsualComparison.noBaseline(have: values.count)
            if values.count >= minimumBaseline {
                let m = values.reduce(0, +) / Double(values.count)
                let s = PersonalRanking.standardDeviation(values)
                mean = m; sd = s
                if let now {
                    let d = now - m
                    diff = d
                    let threshold = max(precision.meaningfulChange, spreadMultiple * s)
                    comparison = abs(d) > threshold + 1e-9 ? (d > 0 ? .higherThanUsual : .lowerThanUsual) : .withinUsual
                }
            }
            let window = Array((values + (now.map { [$0] } ?? [])).suffix(recentWindow))
            var spread: Double?, range: Double?, level: RepeatabilityLevel?
            if window.count >= minimumForSpread {
                let s = PersonalRanking.standardDeviation(window)
                spread = s
                range = (window.max() ?? 0) - (window.min() ?? 0)
                level = RepeatabilityLevel.of(spread: s, precision: precision)
            }
            metrics.append(MetricConsistencyAssessment(
                key: key, name: key.definition.displayName, unit: key.definition.unit, current: now, earlier: values,
                usualMean: mean, usualSpread: sd, difference: diff, comparison: comparison,
                spreadCount: window.count, spread: spread, range: range, level: level, precision: precision))
        }

        let kicks = earlier.count + (currentEligible ? 1 : 0)
        let status: ConsistencyReport.Status
        if !currentEligible, let reason = current.recording.exclusionReason {
            status = metrics.contains { $0.level != nil } ? .assessed : .notApplicable(reason: reason)
        } else if metrics.contains(where: { $0.level != nil }) {
            status = .assessed
        } else {
            // The best-covered metric decides how far the baseline is.
            let have = metrics.map { $0.earlier.count + ($0.current == nil ? 0 : 1) }.max() ?? kicks
            status = .buildingBaseline(have: min(have, minimumForSpread - 1), need: minimumForSpread)
        }
        return ConsistencyReport(status: status, metrics: metrics, comparableKicks: kicks, excluded: excluded)
    }

    /// Direction wording, never evaluative. Sideways metrics name the side.
    static func directionPhrase(_ key: KickMetricKey, higher: Bool, current: Double?, usual: Double?) -> String {
        switch key {
        case .plantBallLateralOffset:
            if let c = current, let u = usual, c > 0, u > 0 {
                return higher ? "Your plant foot was farther to the side of the football" : "Your plant foot was closer to the football (sideways)"
            }
            return higher ? "Your plant foot was more toward the plant-leg side of the football" : "Your plant foot was more toward the kicking-leg side of the football"
        case .plantFootWidth:
            return higher ? "Your plant foot was farther out to the plant-leg side of your hips" : "Your plant foot was more under your body (toward the kicking-leg side)"
        case .plantLateralMovement:
            return higher ? "Your plant foot slid more sideways" : "Your plant foot slid less sideways"
        case .lateralTrunkLeanAtContact:
            return higher ? "Your trunk tilted more toward your plant side" : "Your trunk tilted less toward your plant side"
        case .plantToContactTime:
            return higher ? "The time from plant to contact was longer" : "The time from plant to contact was shorter"
        case .followThroughDuration:
            return higher ? "Your kicking foot kept swinging longer after contact" : "Your kicking foot's swing after contact was shorter"
        case .kneeSwingAfterContact:
            return higher ? "Your kicking knee kept swinging longer after contact" : "Your kicking knee's swing after contact was shorter"
        case .approachSpeed:
            return higher ? "Your run-up was faster" : "Your run-up was slower"
        case .torsoLeanAtContact:
            // Positive = leaning toward the target, negative = leaning back.
            return higher ? "Your trunk leaned more toward the target" : "Your trunk leaned further back"
        default:
            return "\(key.definition.displayName) was \(higher ? "higher" : "lower")"
        }
    }
}

/// Build 20: consistency per comparable group (kick type × camera view) for the progress
/// screen, judged at each group's most recent eligible kick. Groups never mix.
struct ProgressConsistencyGroup: Equatable, Sendable, Identifiable {
    var kickType: KickType
    var view: ComparableView
    var report: ConsistencyReport
    /// Kicks in the group (one per physical kick), the latest included.
    var kicks: Int
    var id: String { "\(kickType.rawValue)|\(view.rawValue)" }
    var title: String { "\(kickType.displayName) · \(view.title)" }

    /// Measurements outside the usual range on the latest kick.
    var recentDeviations: [MetricConsistencyAssessment] { report.notable }

    static func make(entries: [RankingEntry]) -> [ProgressConsistencyGroup] {
        // One (current) entry per kick; completed, known view.
        var latestPerKick: [UUID: RankingEntry] = [:]
        var loose: [RankingEntry] = []
        for e in entries where e.completed && e.view != .unknown && e.kickType != .unknown {
            guard let k = e.kickID else { loose.append(e); continue }
            if let prior = latestPerKick[k], prior.date >= e.date { continue }
            latestPerKick[k] = e
        }
        let all = Array(latestPerKick.values) + loose
        let groups = Dictionary(grouping: all) { "\($0.kickType.rawValue)|\($0.view.rawValue)|\($0.isAssisted)" }
        var out: [ProgressConsistencyGroup] = []
        for (_, members) in groups {
            // The most recent kick that may feed history is the one assessed.
            guard let current = members.filter({ $0.recording.eligibleForMeasurementHistory }).max(by: { $0.date < $1.date }) else { continue }
            let report = ConsistencyModel.make(current: current, eligibility: PersonalRanking.eligibility(for: current, among: members))
            out.append(ProgressConsistencyGroup(kickType: current.kickType, view: current.view, report: report, kicks: members.count))
        }
        return out.sorted { ($0.kicks, $0.title) > ($1.kicks, $1.title) }
    }
}
