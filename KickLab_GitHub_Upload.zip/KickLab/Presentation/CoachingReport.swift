import Foundation

/// Step 12F: the top of the coaching report — what was analyzed, whether a kick was found,
/// what the camera angle allows, how contact was timed, the phase timeline and which
/// measurements exist from this view. Coaching, drills and comparisons follow below it.
/// Plain language; nothing is called good or bad because of a number alone.
struct CoachingReportOverview: Equatable, Sendable {
    struct Item: Equatable, Sendable, Identifiable {
        var id: Int { number }
        var number: Int
        var title: String
        var lines: [String]
    }

    var items: [Item]
    /// True when contact timing is too uncertain for precise contact-specific advice.
    var contactUncertain: Bool
    /// Coaching priorities hidden because they depend on an uncertain contact.
    var suppressedContactAdvice: Bool

    static let evidenceLegend = "Measured: from clearly tracked body points. Estimated: inferred from several motion signals. User-entered: you provided it. Unavailable: not enough evidence. Not validated: calculated, but not shown to relate to kicking results."

    struct Input: Equatable, Sendable {
        var kickType: KickType
        var date: Date
        var engineVersion: String
        var perspective: PerspectiveDecision?
        var outcome: AnalysisOutcome?
        var phases: KickPhaseDetectionResult?
        var metrics: [MetricRowPresentation]
        var annotation: ContactAnnotation
        var nominalFrameRate: Double?
        var hasContactPriorities: Bool
    }

    static func make(_ i: Input) -> CoachingReportOverview {
        var items: [Item] = []
        // 1. What was analyzed.
        var what = ["\(i.kickType.displayName), \(DisplayFormat.isoDay(i.date))."]
        if let p = i.perspective {
            var view = "Camera: \(p.declared.displayName.lowercased()) view as selected"
            if p.declaredContradicted { view += ", but the movement looked like a \(CameraPerspectiveResolver.name(p.used)) — analyzed as that" }
            what.append(view + ".")
        }
        what.append("Engine \(i.engineVersion).")
        items.append(Item(number: 1, title: "What was analyzed", lines: what))

        // 2. Kick detected.
        let outcome = i.outcome
        items.append(Item(number: 2, title: "Kick found?", lines: [outcome.map { "\($0.title). \($0.explanation)" } ?? "Not finished."]))

        // 3. Camera and limits.
        let used = i.perspective?.used ?? .side
        let limits: String
        switch used {
        case .side: limits = "Side view: approach, plant, swing and contact timing can be measured."
        case .oblique: limits = "Diagonal view: only timings and speed ratios are measured; angles are distorted from this view."
        case .depthAway, .depthToward:
            limits = "Filmed from \(used == .depthAway ? "behind" : "in front"): timing, sideways trunk lean and plant-foot width only. Knee and hip angles can't be measured from this view, so none are reported and no score is given."
        }
        items.append(Item(number: 3, title: "Camera angle and limits", lines: [limits]))

        // 4. Contact timing.
        let contact = contactLines(i)
        items.append(Item(number: 4, title: "Contact timing", lines: contact.lines))

        // 5. Phase timeline.
        var timeline: [String] = []
        if let phases = i.phases {
            for marker in PhaseMarker.markers(from: phases) {
                timeline.append(String(format: "%@ %.3f s (%@)", marker.title, marker.time, marker.source.label))
            }
        }
        items.append(Item(number: 5, title: "Phase timeline", lines: timeline.isEmpty ? ["No phases were found."] : timeline))

        // 6. Measurements from this angle.
        let measured = i.metrics.filter(\.isAvailable)
        let notFromAngle = i.metrics.filter { !$0.isAvailable }.count
        var m = ["\(measured.count) measurement\(measured.count == 1 ? "" : "s") available; \(notFromAngle) not available from this recording."]
        let unvalidated = measured.filter { $0.key.definition.betterDirection == .none }.map(\.name)
        if !unvalidated.isEmpty {
            m.append("Not validated (shown for reference only): " + unvalidated.joined(separator: ", ") + ".")
        }
        items.append(Item(number: 6, title: "Measurements from this angle", lines: m))

        return CoachingReportOverview(items: items, contactUncertain: contact.uncertain,
                                      suppressedContactAdvice: contact.uncertain && i.hasContactPriorities)
    }

    static func contactLines(_ i: Input) -> (lines: [String], uncertain: Bool) {
        guard let phases = i.phases else { return (["Contact timing isn't available for this analysis."], true) }
        let c = phases.phase(.contact)
        let e = phases.evidence
        var lines: [String] = []
        var uncertain = false
        if phases.isUserAssisted, let t = c.representativeTime {
            lines.append(String(format: "You chose contact at %.3f s (user-assisted analysis).", t))
        } else if c.isAvailable, let t = c.representativeTime {
            let ball = e?.contactProvenance == "ballAware"
            var s = String(format: "Automatic estimate %.3f s", t)
            if let lo = e?.contactEarliestTime, let hi = e?.contactLatestTime, hi - lo > 1e-6 {
                s += String(format: " (possible %.3f–%.3f s)", lo, hi)
            }
            s += ball ? ", from body pose and the ball." : ", from body pose only — the ball isn't tracked."
            lines.append(s)
            if let groups = e?.contactEvidenceGroups {
                let agree = groups.filter { $0.agrees == true }.count
                lines.append("\(agree) independent line\(agree == 1 ? "" : "s") of evidence agreed.")
            }
            let width = (e?.contactLatestTime ?? t) - (e?.contactEarliestTime ?? t)
            uncertain = c.status == .ambiguous || !ball && (i.perspective?.used.isDepthView ?? false) || width > 0.07
        } else {
            lines.append("Contact wasn't established automatically; any contact-specific advice is withheld.")
            uncertain = true
        }
        switch i.annotation {
        case .contact(let user):
            var s = String(format: "You verified first contact at %.3f s", user)
            if !phases.isUserAssisted, c.isAvailable, let t = c.representativeTime {
                let d = user - t
                if abs(d) < 1e-4 { s += " — the same as the automatic estimate." }
                else {
                    s += String(format: " — %.3f s %@ than the automatic estimate", abs(d), d < 0 ? "earlier" : "later")
                    if let fps = i.nominalFrameRate, fps > 0 { s += String(format: " (about %d frames)", Int((abs(d) * fps).rounded())) }
                    s += "."
                }
            } else {
                s += "."
            }
            lines.append(s)
        case .cannotTell:
            lines.append("You reviewed the frames and couldn't tell when contact happened.")
        case .none:
            lines.append("Not verified by you yet — use Verify Contact to step through the frames.")
        }
        if uncertain { lines.append("Contact timing is uncertain, so precise contact-specific advice isn't given.") }
        return (lines, uncertain)
    }
}
