import Foundation

/// Step 12F: the top of the coaching report — what was analyzed, whether a kick was found,
/// what the camera angle allows, how contact was timed, the phase timeline and which
/// measurements exist from this view. Coaching, drills and comparisons follow below it.
/// Plain language; nothing is called good or bad because of a number alone.
struct CoachingReportOverview: Equatable, Sendable {
    struct Item: Equatable, Sendable, Identifiable {
        var id: Int { number }
        var number: Int
        var title: String
        var lines: [String]
    }

    var items: [Item]
    /// True when contact timing is too uncertain for precise contact-specific advice.
    var contactUncertain: Bool
    /// Coaching priorities hidden because they depend on an uncertain contact.
    var suppressedContactAdvice: Bool

    static let evidenceLegend = "Measured: from clearly tracked body points. Estimated: inferred from several motion signals. User-entered: you provided it. Unavailable: not enough evidence. Not validated: calculated, but not shown to relate to kicking results."

    struct Input: Equatable, Sendable {
        var kickType: KickType
        var date: Date
        var engineVersion: String
        var perspective: PerspectiveDecision?
        var outcome: AnalysisOutcome?
        var phases: KickPhaseDetectionResult?
        var metrics: [MetricRowPresentation]
        var annotation: ContactAnnotation
        var nominalFrameRate: Double?
        var hasContactPriorities: Bool
    }

    static func make(_ i: Input) -> CoachingReportOverview {
        var items: [Item] = []
        // 1. What was analyzed.
        var what = ["\(i.kickType.displayName), \(DisplayFormat.isoDay(i.date))."]
        if let p = i.perspective {
            var view = "Camera: \(p.declared.displayName.lowercased()) view as selected"
            if p.declaredContradicted { view += ", but the movement looked like a \(CameraPerspectiveResolver.name(p.used)) — analyzed as that" }
            what.append(view + ".")
        }
        what.append("Engine \(i.engineVersion).")
        items.append(Item(number: 1, title: "What was analyzed", lines: what))

        // 2. Kick detected.
        let outcome = i.outcome
        items.append(Item(number: 2, title: "Kick found?", lines: [outcome.map { "\($0.title). \($0.explanation)" } ?? "Not finished."]))

        // 3. Camera and limits.
        let used = i.perspective?.used ?? .side
        let limits: String
        switch used {
        case .side: limits = "Side view: approach, plant, swing and contact timing can be measured."
        case .oblique: limits = "Diagonal view: only timings and speed ratios are measured; angles are distorted from this view."
        case .depthAway, .depthToward:
            limits = "Filmed from \(used == .depthAway ? "behind" : "in front"): timing, sideways trunk lean and plant-foot width only. Knee and hip angles can't be measured from this view, so none are reported and no score is given."
        }
        items.append(Item(number: 3, title: "Camera angle and limits", lines: [limits]))

        // 4. Contact timing.
        let contact = contactLines(i)
        items.append(Item(number: 4, title: "Contact timing", lines: contact.lines))

        // 5. Phase timeline.
        var timeline: [String] = []
        if let phases = i.phases {
            for marker in PhaseMarker.markers(from: phases) {
                timeline.append(String(format: "%@ %.3f s (%@)", marker.title, marker.time, marker.source.label))
            }
        }
        items.append(Item(number: 5, title: "Phase timeline", lines: timeline.isEmpty ? ["No phases were found."] : timeline))

        // Plant status.
        if let phases = i.phases {
            let plant = phases.phase(.plant)
            let state = phases.evidence?.plantState
            items[items.count - 1].lines.append(plant.isAvailable
                ? String(format: "Plant %@ at %.3f s.", state == .userSupplied ? "chosen by you" : "estimated", plant.representativeTime ?? 0)
                : "Plant not established.")
        }

        // 6. Measurements from this angle.
        let measured = i.metrics.filter(\.isAvailable)
        let notFromAngle = i.metrics.filter { !$0.isAvailable }.count
        var m = ["\(measured.count) measurement\(measured.count == 1 ? "" : "s") available; \(notFromAngle) not available from this recording."]
        let unvalidated = measured.filter { $0.key.definition.betterDirection == .none }.map(\.name)
        if !unvalidated.isEmpty {
            m.append("Not validated (shown for reference only): " + unvalidated.joined(separator: ", ") + ".")
        }
        items.append(Item(number: 6, title: "Measurements from this angle", lines: m))

        return CoachingReportOverview(items: items, contactUncertain: contact.uncertain,
                                      suppressedContactAdvice: contact.uncertain && i.hasContactPriorities)
    }

    static func contactLines(_ i: Input) -> (lines: [String], uncertain: Bool) {
        guard let phases = i.phases else { return (["Contact timing isn't available for this analysis."], true) }
        let c = phases.phase(.contact)
        let e = phases.evidence
        var lines: [String] = []
        var uncertain = false
        let method = e?.contactTimingMethodResolved
        if phases.isUserAssisted, let t = c.representativeTime {
            if e?.contactProvenance == "ballMotionUserMarked" {
                lines.append(String(format: "Ball contact visually verified: the ball you marked was at rest through %.3f s and disturbed at %.3f s (measured from the video's frames).",
                                    e?.contactEarliestTime ?? t, t))
            } else {
                lines.append(String(format: "You chose contact at %.3f s (user-assisted analysis).", t))
            }
        } else if c.isAvailable, let t = c.representativeTime, method == "ballDetector" {
            // Step 12G: the football detector followed the kicked ball on the frames.
            let outcome = ContactOutcome.of(phases)
            let b = e?.ballEvidence
            lines.append(String(format: "%@: the ball was clearly at rest through %.3f s and first seen moving at %.3f s, so contact happened between those frames (possible contact frames %.3f–%.3f s; shown at %.3f s).",
                                outcome.title, b?.lastStationaryTime ?? t, b?.firstDisplacementTime ?? t,
                                e?.contactEarliestTime ?? t, e?.contactLatestTime ?? t, t))
            lines.append("Found automatically by the football detector on the video's frames. At this frame rate the exact moment between those frames can't be seen.")
            uncertain = c.status == .ambiguous
        } else if c.isAvailable, let t = c.representativeTime, method == "strikeWindow" {
            lines.append(String(format: "Strike window identified (%.3f–%.3f s), but contact timing is uncertain: body pose alone can't place the moment the foot meets the ball.",
                                e?.contactEarliestTime ?? t, e?.contactLatestTime ?? t))
            lines.append("Verify Contact (step through the frames, or mark the ball) to get timing measurements.")
            uncertain = true
        } else if c.isAvailable, let t = c.representativeTime {
            let ball = e?.contactProvenance == "ballAware"
            var s = String(format: "Contact estimated from body pose: %.3f s", t)
            if let lo = e?.contactEarliestTime, let hi = e?.contactLatestTime, hi - lo > 1e-6 {
                s += String(format: " (possible %.3f–%.3f s)", lo, hi)
            }
            s += ball ? ", checked against the ball." : " — the ball isn't tracked."
            lines.append(s)
            let width = (e?.contactLatestTime ?? t) - (e?.contactEarliestTime ?? t)
            uncertain = c.status == .ambiguous || !ball && (i.perspective?.used.isDepthView ?? false) || width > 0.07
        } else {
            lines.append("Contact wasn't established automatically; any contact-specific advice is withheld.")
            uncertain = true
        }
        switch i.annotation {
        case .contact(let user):
            var s = String(format: "You verified first contact at %.3f s", user)
            if !phases.isUserAssisted, c.isAvailable, let t = c.representativeTime {
                let d = user - t
                if abs(d) < 1e-4 { s += " — the same as the automatic estimate." }
                else {
                    s += String(format: " — %.3f s %@ than the automatic estimate", abs(d), d < 0 ? "earlier" : "later")
                    if let fps = i.nominalFrameRate, fps > 0 { let n = Int((abs(d) * fps).rounded()); s += " (about \(n) frame\(n == 1 ? "" : "s"))" }
                    s += "."
                }
            } else {
                s += "."
            }
            lines.append(s)
        case .cannotTell:
            lines.append("You reviewed the frames and couldn't tell when contact happened.")
        case .none:
            lines.append("Not verified by you yet — use Verify Contact to step through the frames.")
        }
        if uncertain { lines.append("Contact timing is uncertain, so precise contact-specific advice isn't given.") }
        return (lines, uncertain)
    }
}
