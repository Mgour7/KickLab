import Foundation

/// Build 21 — "Zoom to athlete" for Compare Kicks. A uniform scale (aspect ratio kept, no
/// distortion) plus a translation, applied to the video AND its overlays together so they
/// stay registered. The athlete's box comes from STORED tracked joints over the whole
/// compared window, so the framing doesn't jump and no tracked body part is cropped.
struct ZoomTransform: Equatable, Sendable {
    /// Points map as `p' = scale × p + (offsetX, offsetY)` (container coordinates, top-left anchor).
    var scale: Double
    var offsetX: Double
    var offsetY: Double

    static let identity = ZoomTransform(scale: 1, offsetX: 0, offsetY: 0)

    func apply(x: Double, y: Double) -> (x: Double, y: Double) { (scale * x + offsetX, scale * y + offsetY) }
}

enum AthleteFraming {
    static let maximumScale = 4.0
    /// Padding around the athlete's box, as a fraction of its size on each side.
    static let margin = 0.15

    /// The union of every tracked (detected or filled-in) joint of the stored timeline in
    /// `window`, in content-normalized coordinates, padded and clipped to the frame.
    static func athleteBox(_ timeline: KickerPoseTimeline?, window: ClosedRange<Double>) -> NormalizedBox? {
        guard let timeline else { return nil }
        var xs: [Double] = [], ys: [Double] = []
        for s in timeline.samples where window.contains(s.timestamp) {
            for joint in PoseJoint.allCases {
                guard let p = s.point(joint) else { continue }
                xs.append(p.x); ys.append(p.y)
            }
        }
        guard let x0 = xs.min(), let x1 = xs.max(), let y0 = ys.min(), let y1 = ys.max(), x1 > x0, y1 > y0 else { return nil }
        let w = x1 - x0, h = y1 - y0
        let a = max(0, x0 - margin * w), b = min(1, x1 + margin * w)
        let c = max(0, y0 - margin * h), d = min(1, y1 + margin * h)
        return NormalizedBox(cx: (a + b) / 2, cy: (c + d) / 2, w: b - a, h: d - c)
    }

    /// Frames `box` (content-normalized) inside the container: the largest uniform scale
    /// that keeps the whole box visible (≤ `maximumScale`, ≥ 1), centred on the box, then
    /// moved as little as needed to avoid showing beyond the video's edges.
    static func transform(box: NormalizedBox, content: OverlayRect, containerWidth: Double, containerHeight: Double) -> ZoomTransform {
        guard containerWidth > 0, containerHeight > 0, content.width > 0, content.height > 0 else { return .identity }
        let bw = box.w * content.width, bh = box.h * content.height
        let bx = content.x + box.cx * content.width, by = content.y + box.cy * content.height
        let scale = min(maximumScale, max(1, min(containerWidth / max(bw, 1e-6), containerHeight / max(bh, 1e-6))))
        let ideal = ZoomTransform(scale: scale, offsetX: containerWidth / 2 - scale * bx, offsetY: containerHeight / 2 - scale * by)
        return clamp(ideal, content: content, containerWidth: containerWidth, containerHeight: containerHeight)
    }

    /// Keeps the zoomed video covering the container where it can (no empty borders beyond
    /// the video's own letterboxing), for automatic and manual zoom alike.
    static func clamp(_ t: ZoomTransform, content: OverlayRect, containerWidth: Double, containerHeight: Double) -> ZoomTransform {
        var c = t
        c.scale = min(maximumScale, max(1, t.scale))
        func axis(_ offset: Double, start: Double, length: Double, container: Double) -> Double {
            let lo = container - c.scale * (start + length), hi = -c.scale * start
            // Content narrower than the container: centre it.
            guard lo <= hi else { return (container - c.scale * (2 * start + length)) / 2 }
            return min(max(offset, lo), hi)
        }
        c.offsetX = axis(t.offsetX, start: content.x, length: content.width, container: containerWidth)
        c.offsetY = axis(t.offsetY, start: content.y, length: content.height, container: containerHeight)
        return c
    }
}
