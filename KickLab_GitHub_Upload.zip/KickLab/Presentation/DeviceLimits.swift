import Foundation

/// Limits that protect a real iPhone during analysis. Provisional: to be tuned with
/// real footage during the first TestFlight beta.
enum AnalysisLimits {
    /// The longest video KickLab analyzes. A kick clip is a few seconds; much longer
    /// videos take minutes of pose detection and a lot of memory on a phone.
    static let maximumVideoSeconds: Double = 60

    /// The problem to show before starting, or nil when the video can be analyzed.
    /// An unknown duration is allowed (the engine reads the file itself).
    static func problem(forDurationSeconds duration: Double?) -> AnalysisProblem? {
        guard let duration, duration.isFinite, duration > maximumVideoSeconds else { return nil }
        return .videoTooLong(seconds: duration)
    }
}

/// Free space needed before importing a video.
enum StorageSpacePolicy {
    /// Room left over after the copy, so the phone (and SwiftData) can keep working.
    static let safetyMarginBytes: Int64 = 200 * 1024 * 1024

    /// True when the copy fits. Unknown sizes or capacity never block an import; the
    /// copy itself then reports any failure.
    static func hasRoom(forFileOfSize size: Int64?, availableBytes: Int64?) -> Bool {
        guard let size, let availableBytes, size >= 0 else { return true }
        return availableBytes >= size + safetyMarginBytes
    }

    static func notEnoughSpaceMessage(fileSize: Int64?) -> String {
        let needed = (fileSize ?? 0) + safetyMarginBytes
        let megabytes = Int((Double(needed) / 1_048_576).rounded(.up))
        return "There isn't enough free space on this iPhone to import this video (about \(megabytes) MB is needed). Free up some space and try again."
    }
}

extension UserFacingError {
    /// Shown instead of crashing when the data store can't be opened at launch.
    /// The underlying error isn't shown to the user.
    static func startupMessage(for error: any Error) -> String {
        if isOutOfSpace(error) {
            return "KickLab couldn't open its data because your iPhone is out of storage space. Free up some space, then close and reopen KickLab."
        }
        return "KickLab couldn't open its data. Close KickLab completely and open it again. If this keeps happening, please report it through TestFlight."
    }

    static let outOfSpaceMessage = "Your iPhone is out of storage space. Free up some space and try again."

    /// True for "disk full" errors, including ones wrapped as an underlying error.
    static func isOutOfSpace(_ error: any Error) -> Bool {
        var current: NSError? = error as NSError
        var depth = 0
        while let e = current, depth < 5 {
            if e.domain == NSCocoaErrorDomain && e.code == NSFileWriteOutOfSpaceError { return true }
            if e.domain == NSPOSIXErrorDomain && e.code == Int(ENOSPC) { return true }
            current = e.userInfo[NSUnderlyingErrorKey] as? NSError
            depth += 1
        }
        return false
    }
}
