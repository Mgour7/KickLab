import Foundation

// Build 22 — the Kick Breakdown: the athlete-facing, phase-by-phase reading of one kick.
//
// One card per phase (Setup, Approach, Plant, Swing, Contact, Follow-through). Every card is
// built from the SAME stored numbers the rest of the report uses, and its parts cannot
// disagree (checked by `KickBreakdownCheck`, which the tests run on every case):
// - the status pill comes from the area's provisional score band (Strength 85+, Solid 70–84,
//   Work on 50–69, Priority < 50) or says why the area wasn't graded;
// - the headline measurement is the one that explains the status (the weakest scored
//   measurement when the area needs work, the strongest when it is good);
// - the sentence states that measurement's value, unit and where it sits relative to the
//   provisional target, word for word from the same numbers;
// - the one priority fix is an evidence-backed coaching finding in an area marked
//   Work on / Priority, with its cue, a related drill and what to check on the next kick.
// Nothing is shown that the camera view can't measure; targets are labelled provisional
// (no sourced elite benchmark exists — Docs/BENCHMARK_AUDIT_BUILD22.md).

enum BreakdownPhase: String, CaseIterable, Equatable, Sendable, Identifiable {
    case setup, approach, plant, swing, contact, followThrough
    var id: String { rawValue }

    var title: String {
        switch self {
        case .setup: "Setup"
        case .approach: "Approach"
        case .plant: "Plant"
        case .swing: "Swing"
        case .contact: "Contact"
        case .followThrough: "Follow-through"
        }
    }

    /// The scoring area behind the phase (nil: not a scored area).
    var category: AnalysisCategory? {
        switch self {
        case .setup: nil
        case .approach: .approach
        case .plant: .plant
        case .swing: .swing
        case .contact: .contact
        case .followThrough: .followThrough
        }
    }

    /// The kick phase whose frame illustrates the card.
    var kickPhase: KickPhase {
        switch self {
        case .setup: .setup
        case .approach: .approach
        case .plant: .plant
        case .swing, .contact: .contact
        case .followThrough: .followThrough
        }
    }

    /// What the phase is about, in a few words (shown under the title).
    var subtitle: String {
        switch self {
        case .setup: "Stance before the run-up"
        case .approach: "Run-up speed and rhythm"
        case .plant: "Plant foot: timing, position, stability"
        case .swing: "Backswing and kicking leg"
        case .contact: "Body position as the foot meets the ball"
        case .followThrough: "Finish after contact"
        }
    }
}

struct KickBreakdown: Equatable, Sendable {
    enum Status: String, Equatable, Sendable {
        case strength, solid, workOn, priority
        /// Measured, but the area isn't graded (too few reliable measurements, or no target).
        case notGraded
        /// Nothing in this phase could be measured from this recording.
        case notMeasured

        init(label: PerformanceReport.Label) {
            switch label {
            case .excellent: self = .strength
            case .good: self = .solid
            case .developing: self = .workOn
            case .needsWork: self = .priority
            }
        }

        var title: String {
            switch self {
            case .strength: "Strength"
            case .solid: "Solid"
            case .workOn: "Work on"
            case .priority: "Priority"
            case .notGraded: "Not graded"
            case .notMeasured: "Not measured"
            }
        }

        var isGraded: Bool { self == .strength || self == .solid || self == .workOn || self == .priority }
        var needsWork: Bool { self == .workOn || self == .priority }
    }

    /// Where a value sits relative to its provisional target.
    enum Verdict: String, Equatable, Sendable {
        case inside, below, above, noTarget

        var phrase: String {
            switch self {
            case .inside: "inside the provisional target"
            case .below: "below the provisional target"
            case .above: "above the provisional target"
            case .noTarget: "no target is set for this measurement"
            }
        }
    }

    struct Measurement: Equatable, Sendable, Identifiable {
        var key: KickMetricKey
        var name: String
        var value: Double
        var valueText: String
        /// "0.50–3.00 torso lengths" in the SAME unit as the value (nil when none).
        var targetText: String?
        var verdict: Verdict
        /// 0–100 against the provisional band (nil when not scored).
        var bandScore: Double?
        var weight: Double
        var definition: String
        var qualityText: String
        /// The athlete's usual value, when a personal baseline exists.
        var usualText: String?
        /// Where the value and the provisional target sit on one scale (nil: no target).
        var gauge: Gauge? = nil
        var id: String { key.rawValue }
    }

    /// A value against its provisional target on one linear scale, as fractions 0…1 of
    /// the drawn range — so a bar can't place the value differently from the verdict.
    struct Gauge: Equatable, Sendable {
        var targetStart: Double
        var targetEnd: Double
        var value: Double
        /// Open-ended targets ("≥ 20", "≤ 0.10") run to the bar's end.
        var openLow: Bool
        var openHigh: Bool
    }

    struct PhaseCard: Equatable, Sendable, Identifiable {
        var phase: BreakdownPhase
        var status: Status
        /// Whole-number area score (nil when not graded).
        var score: Int?
        var headline: Measurement?
        var others: [Measurement]
        /// One or two sentences, built only from `headline` (and the status).
        var explanation: String
        /// The frame that shows the phase (video time, seconds) and how it was found.
        var frameTime: Double?
        var frameSource: String?
        /// Why nothing is graded / measured, in plain words.
        var reason: String?
        var id: String { phase.rawValue }
    }

    struct Grade: Equatable, Sendable {
        var score: Int?
        var label: PerformanceReport.Label?
        /// "Technique 78 · Good" or "Not graded".
        var text: String
        /// What the grade rests on: areas graded, view, contact source.
        var basis: String
    }

    struct Priority: Equatable, Sendable {
        var phase: BreakdownPhase
        var title: String
        var observed: String
        var cue: String
        /// The measurement it rests on (also the phase card's headline or one of its others).
        var metricKey: KickMetricKey?
        var drillTitle: String?
        var drillID: String?
        var checkNextKick: String
    }

    /// With no priority: the graded measurement furthest outside its target in an area
    /// that is still good overall — worth watching, not a correction.
    struct Watch: Equatable, Sendable {
        var phase: BreakdownPhase
        var measurement: Measurement
        var text: String
    }

    var grade: Grade
    var phases: [PhaseCard]
    var priority: Priority?
    var watch: Watch? = nil
    /// When no technique correction is supported (and why).
    var noPriorityText: String?
    /// The coach's summary paragraph, assembled from the cards above.
    var coachSummary: String
    /// "Contact verified from the ball at 3.937 s" etc.
    var contactText: String
    var viewText: String

    var strongest: PhaseCard? {
        phases.filter { $0.status.isGraded }.max { ($0.score ?? 0, -$0.phase.index) < ($1.score ?? 0, -$1.phase.index) }
    }
}

extension BreakdownPhase {
    var index: Int { BreakdownPhase.allCases.firstIndex(of: self) ?? 0 }
}

enum KickBreakdownBuilder {
    struct Input: Sendable {
        var kickType: KickType
        var metrics: [MetricRowPresentation]
        var categories: [CategoryCardPresentation]
        var coaching: [CoachingItemPresentation]
        var markers: [PhaseMarker]
        var viewText: String
        var contactOutcome: ContactOutcome?
        var contactTime: Double?
        /// The athlete's usual value per measurement, already formatted (personal baseline).
        var usual: [KickMetricKey: String] = [:]
        /// The overall provisional technique score, when the report could grade the kick.
        var overallScore: Double?
        /// A recording recommendation for when nothing can be corrected.
        var recordingAdvice: String?
        /// How the camera saw the kick (nil: assume side). Phases the view can't measure
        /// say so instead of "not enough measurements".
        var perspective: CameraPerspective? = nil
        /// Better frames for a phase than its marker (e.g. the follow-through's highest
        /// point), with how they were found.
        var frames: [BreakdownPhase: FrameChoice] = [:]
    }

    struct FrameChoice: Equatable, Sendable {
        var time: Double
        var label: String
    }

    /// A measured value and the moment it describes.
    struct Sample: Equatable, Sendable {
        var value: Double
        var time: Double
    }

    /// The follow-through card shows the highest point of the kicking foot when that was
    /// measured, otherwise the end of the measured swing (contact + duration) — not the
    /// contact frame where the phase begins.
    static func frames(samples: [KickMetricKey: Sample]) -> [BreakdownPhase: FrameChoice] {
        var out: [BreakdownPhase: FrameChoice] = [:]
        if let h = samples[.followThroughFootHeight] {
            out[.followThrough] = FrameChoice(time: h.time, label: "Follow-through · highest foot point")
        } else if let d = samples[.followThroughDuration], d.value > 0 {
            out[.followThrough] = FrameChoice(time: d.time + d.value, label: "Follow-through · end of the swing")
        }
        return out
    }

    /// The app's input for one stored analysis: the same presentation rows, categories and
    /// coaching the rest of the report uses, the phase markers and contact evidence from the
    /// phase file, and the report's own grade (so the two can never disagree).
    static func input(presentation p: AnalysisResultsPresentation, record: AnalysisRecord, report: PerformanceReport?,
                      markers: [PhaseMarker], phases: KickPhaseDetectionResult?, perspective: CameraPerspective?) -> Input {
        var overall: Double?
        if case .technique(let score, _, _)? = report?.summary { overall = Double(score) }
        var usual: [KickMetricKey: String] = [:]
        for m in report?.measurements ?? [] { if let u = m.usualText { usual[m.key] = u } }
        var samples: [KickMetricKey: Sample] = [:]
        for m in record.metrics where m.status != .unavailable {
            guard let key = KickMetricKey(rawValue: m.key), let v = m.value, let t = m.sampleTime, v.isFinite, t.isFinite else { continue }
            samples[key] = Sample(value: v, time: t)
        }
        return Input(kickType: record.kickType, metrics: p.metrics, categories: p.categories, coaching: p.priorities,
                     markers: markers, viewText: viewText(perspective) ?? report?.header.viewText ?? "Side view",
                     contactOutcome: phases.map(ContactOutcome.of), contactTime: phases?.estimatedContactTime,
                     usual: usual, overallScore: overall, recordingAdvice: report?.recordingAdvice ?? PerformanceReport.sideRecording,
                     perspective: perspective, frames: frames(samples: samples))
    }

    static func viewText(_ p: CameraPerspective?) -> String? {
        switch p {
        case .depthAway?: "View from behind"
        case .depthToward?: "View from in front"
        case .oblique?: "Diagonal view"
        case .side?: "Side view"
        case nil: nil
        }
    }

    /// Measurements per phase, in order of importance for the headline.
    static func keys(_ phase: BreakdownPhase) -> [KickMetricKey] {
        switch phase {
        case .setup: []
        case .approach: [.approachLateSpeedChange, .approachSpeedVariation, .approachSpeed]
        case .plant: [.plantFootDrift, .plantKneeAngleAtContact, .plantToContactTime, .plantBallLateralOffset, .plantFootWidth, .plantLateralMovement]
        case .swing: [.kickingKneeAngleAtContact, .backswingDepth, .peakFootSpeed, .kickingHipAngleAtContact, .footSpeedAtContact]
        case .contact: [.torsoLeanAtContact, .torsoLeanRange, .bodyForwardSpeedAtContact, .lateralTrunkLeanAtContact]
        case .followThrough: [.followThroughFootHeight, .followThroughDuration, .followThroughBodyTravel, .kneeSwingAfterContact]
        }
    }

    static func make(_ input: Input) -> KickBreakdown {
        let profile = BiomechanicsProfile.standard(for: input.kickType)
        let rows = Dictionary(input.metrics.filter(\.isAvailable).map { ($0.key, $0) }, uniquingKeysWith: { a, _ in a })

        func measurement(_ key: KickMetricKey) -> KickBreakdown.Measurement? {
            guard let row = rows[key], let value = row.value else { return nil }
            let rule = profile.scoring[key]
            let scored = (rule?.weight ?? 0) > 0
            let band = scored ? rule?.band : nil
            let verdict: KickBreakdown.Verdict
            if let band {
                verdict = value < band.idealLow ? .below : (value > band.idealHigh ? .above : .inside)
            } else {
                verdict = .noTarget
            }
            var valueText = DisplayFormat.signedLateralMetrics.contains(key) ? DisplayFormat.lateral(value, unit: row.unit)
                                                                            : DisplayFormat.metricValue(value, unit: row.unit)
            // One minus sign everywhere (the targets use "−").
            if valueText.hasPrefix("-") { valueText = "−" + valueText.dropFirst() }
            return KickBreakdown.Measurement(
                key: key, name: row.name, value: value, valueText: valueText,
                targetText: band.map { Self.targetText($0, unit: row.unit) },
                verdict: verdict, bandScore: band.map { $0.score(value) }, weight: rule?.weight ?? 0,
                definition: MetricContext.athleteLine(key), qualityText: row.confidenceText, usualText: input.usual[key],
                gauge: band.flatMap { Self.gauge($0, value: value) })
        }

        let markers = Dictionary(input.markers.map { ($0.phase, $0) }, uniquingKeysWith: { a, _ in a })
        var cards: [KickBreakdown.PhaseCard] = []
        for phase in BreakdownPhase.allCases {
            let measured = keys(phase).compactMap(measurement)
            let card = input.categories.first { $0.category == phase.category }
            let marker = markers[phase.kickPhase]
            var status: KickBreakdown.Status
            var score: Int?
            if let s = card?.score {
                score = Int(s.rounded())
                status = KickBreakdown.Status(label: PerformanceReport.Label(score: s))
            } else {
                status = measured.isEmpty ? .notMeasured : .notGraded
            }
            // The headline explains the status.
            let scoredOnes = measured.filter { $0.bandScore != nil }
            let headline: KickBreakdown.Measurement?
            switch status {
            case .workOn, .priority:
                headline = scoredOnes.min { ($0.bandScore ?? 100, -$0.weight) < ($1.bandScore ?? 100, -$1.weight) } ?? measured.first
            case .strength, .solid:
                headline = scoredOnes.max { ($0.bandScore ?? 0, $0.weight) < ($1.bandScore ?? 0, $1.weight) } ?? measured.first
            case .notGraded, .notMeasured:
                headline = measured.first
            }
            let others = measured.filter { $0.key != headline?.key }
            let reason: String?
            switch status {
            case .notMeasured:
                if phase == .setup {
                    reason = "KickLab doesn't grade the setup stance yet; it marks where the run-up starts."
                } else if let p = input.perspective, keys(phase).allSatisfy({ !Self.viewSupports($0, perspective: p) }) {
                    reason = "The \(input.viewText.lowercased()) can't show the \(phase.title.lowercased()): \(Self.viewLimit(p, phase: phase)) Film from the side to measure it."
                } else {
                    reason = card?.summary ?? "Nothing in this phase could be measured reliably from this recording and camera view."
                }
            case .notGraded:
                if let c = phase.category, !Self.isGradedArea(c, kickType: input.kickType) {
                    // Build 22 (provisional-bands-3): an area the profile deliberately doesn't grade.
                    reason = "KickLab doesn't grade the \(phase.title.lowercased()) yet: no outcome evidence supports a target. Use it to compare with your own kicks."
                } else {
                    // Say which graded measurements were missing — never "0 available" next to
                    // values the card shows (those are ungraded ones).
                    let graded = keys(phase).filter { (profile.scoring[$0]?.weight ?? 0) > 0 }
                    let have = graded.filter { k in measured.contains { $0.key == k } }
                    let names = graded.filter { !have.contains($0) }.map { $0.definition.displayName.lowercased() }
                    if let p = input.perspective, !graded.isEmpty, graded.allSatisfy({ !Self.viewSupports($0, perspective: p) }) {
                        reason = "Not graded from the \(input.viewText.lowercased()): the graded measurements (\(Self.list(names))) need a side view."
                    } else {
                        reason = "Not graded: \(have.count) of \(graded.count) graded measurements \(have.count == 1 ? "was" : "were") reliable on this kick"
                            + (names.isEmpty ? "." : " (missing: \(Self.list(names))).")
                    }
                }
            default:
                reason = nil
            }
            cards.append(KickBreakdown.PhaseCard(
                phase: phase, status: status, score: score, headline: headline, others: others,
                explanation: explanation(status: status, headline: headline, reason: reason),
                frameTime: input.frames[phase]?.time ?? marker?.time,
                frameSource: input.frames[phase]?.label ?? marker.map { "\($0.title) · \($0.source.label)" }, reason: reason))
        }

        // The single priority: the highest-priority evidence-backed finding (with a cue) in
        // a phase that needs work, resting on a measurement shown on that card.
        var priority: KickBreakdown.Priority?
        for item in input.coaching.sorted(by: { $0.priority < $1.priority }) {
            guard let cue = item.cue, !cue.isEmpty,
                  let phase = BreakdownPhase.allCases.first(where: { $0.category == item.category }),
                  let card = cards.first(where: { $0.phase == phase }), card.status.needsWork else { continue }
            let shown = [card.headline].compactMap { $0 } + card.others
            let key = item.evidenceMetricKeys.compactMap(KickMetricKey.init(rawValue:)).first { k in shown.contains { $0.key == k } }
            guard key != nil || item.evidenceMetricKeys.isEmpty else { continue }
            let drill = DrillLibrary.relatedDrill(for: item.category, kickType: input.kickType)
            let m = key.flatMap { k in shown.first { $0.key == k } } ?? card.headline
            priority = KickBreakdown.Priority(
                phase: phase, title: "\(phase.title): \(cue)", observed: item.observed, cue: cue, metricKey: key ?? card.headline?.key,
                drillTitle: drill?.title, drillID: drill?.id,
                checkNextKick: m.map { "On your next kick, check \($0.name.lowercased()) (this kick: \($0.valueText)\($0.targetText.map { "; provisional target \($0)" } ?? ""))." }
                    ?? "On your next kick, check the \(phase.title.lowercased()) again.")
            break
        }
        let gradedCards = cards.filter { $0.status.isGraded }
        let noPriority: String? = priority != nil ? nil
            : (gradedCards.isEmpty
               ? "No technique correction can be supported from this recording. \(input.recordingAdvice ?? PerformanceReport.sideRecording)"
               : (gradedCards.contains { $0.status.needsWork }
                  ? "An area needs work, but no single correction is reliable enough to recommend from this kick."
                  : "No area needs correcting on this kick — keep repeating it."))

        // Overall grade.
        let grade: KickBreakdown.Grade
        let contactText = Self.contactText(input.contactOutcome, time: input.contactTime)
        let gradable = cards.filter { $0.phase.category.map { Self.isGradedArea($0, kickType: input.kickType) } ?? false }
        let basis = "\(gradedCards.count) of \(gradable.count) areas graded · \(input.viewText) · \(contactText)"
        if let s = input.overallScore {
            let label = PerformanceReport.Label(score: s)
            grade = KickBreakdown.Grade(score: Int(s.rounded()), label: label, text: "Technique \(Int(s.rounded())) · \(label.title)", basis: basis)
        } else {
            grade = KickBreakdown.Grade(score: nil, label: nil, text: "Not graded",
                                        basis: gradedCards.count < 3 ? "Fewer than 3 areas could be graded · \(input.viewText) · \(contactText)" : basis)
        }

        var breakdown = KickBreakdown(grade: grade, phases: cards, priority: priority, noPriorityText: noPriority,
                                      coachSummary: "", contactText: contactText, viewText: input.viewText)
        if priority == nil { breakdown.watch = Self.watch(cards) }
        breakdown.coachSummary = summary(breakdown)
        return breakdown
    }

    /// Whether the camera perspective can measure a metric at all (same rules as the engine).
    static func viewSupports(_ key: KickMetricKey, perspective: CameraPerspective) -> Bool {
        let context = BiomechanicsContext(kickType: .fieldGoal, kickingFoot: .right, cameraAngle: .side, perspective: perspective)
        if case .supported = PerspectiveMetricSupport.support(key, context: context) { return true }
        return false
    }

    static func viewLimit(_ p: CameraPerspective, phase: BreakdownPhase? = nil) -> String {
        switch p {
        case .depthAway, .depthToward:
            phase == .approach
                ? "from behind or in front, the run-up moves along the line of sight, so its speed isn't measured."
                : "from behind or in front, the leg swings along the line of sight, so its angles and speeds aren't measured."
        case .oblique: "from a diagonal, angles and lengths are shortened by an unknown amount, so only timings and speed ratios are measured."
        case .side: "the side view shows forward and up-down motion but not sideways placement."
        }
    }

    /// "0.50–3.00 torso lengths", "135–170°", "≥ 20 torso lengths/s", "≤ 20%".
    static func targetText(_ band: ScoreBand, unit: MetricUnit) -> String {
        let digits = DisplayFormat.digits(for: unit)
        let suffix = DisplayFormat.unitText(unit)
        let tight = unit == .degrees || unit == .percent
        func n(_ v: Double) -> String { (v < 0 ? "−" : "") + DisplayFormat.number(abs(v), digits: digits) }
        func withUnit(_ s: String) -> String { suffix.isEmpty ? s : (tight ? s + suffix : s + " " + suffix) }
        if band.idealHigh >= 999 { return "≥ " + withUnit(n(band.idealLow)) }
        if band.zeroLow == nil && band.idealLow <= 0 { return "≤ " + withUnit(n(band.idealHigh)) }
        // A range that crosses zero reads "−15% to 25%", never "-15–25%".
        if band.idealLow < 0 { return withUnit(n(band.idealLow)) + " to " + withUnit(n(band.idealHigh)) }
        return withUnit(n(band.idealLow) + "–" + n(band.idealHigh))
    }

    static func watch(_ cards: [KickBreakdown.PhaseCard]) -> KickBreakdown.Watch? {
        var best: (phase: BreakdownPhase, m: KickBreakdown.Measurement)?
        for c in cards where c.status == .strength || c.status == .solid {
            let all: [KickBreakdown.Measurement] = [c.headline].compactMap { $0 } + c.others
            for m in all where (m.verdict == .below || m.verdict == .above) && m.weight > 0 {
                let score: Double = m.bandScore ?? 100
                if best == nil || score < (best!.m.bandScore ?? 100) { best = (c.phase, m) }
            }
        }
        guard let (phase, m) = best else { return nil }
        let target: String = m.targetText.map { " (\($0))" } ?? ""
        let text = "Watch: \(m.name.lowercased()) \(m.valueText), \(m.verdict.phrase)\(target)."
        return KickBreakdown.Watch(phase: phase, measurement: m, text: text)
    }

    static func list(_ items: [String]) -> String {
        switch items.count {
        case 0: ""
        case 1: items[0]
        case 2: "\(items[0]) and \(items[1])"
        default: items.dropLast().joined(separator: ", ") + " and " + items[items.count - 1]
        }
    }

    /// The drawn range: the target plus room on each side (to where the score reaches 0
    /// when that is defined), always wide enough to include the value.
    static func gauge(_ band: ScoreBand, value: Double) -> KickBreakdown.Gauge? {
        let openHigh = band.idealHigh >= 999
        let openLow = !openHigh && band.zeroLow == nil && band.idealLow <= 0
        let low = openLow ? min(0, band.idealHigh) : band.idealLow
        let high = openHigh ? band.idealLow : band.idealHigh
        let span = max(high - low, abs(high) * 0.5, 1e-6)
        var lo = openLow ? low : (band.zeroLow ?? (low - 0.75 * span))
        var hi = openHigh ? high + span : (band.zeroHigh ?? (high + 0.75 * span))
        lo = min(lo, value - 0.05 * span)
        hi = max(hi, value + 0.05 * span)
        guard hi > lo, value.isFinite else { return nil }
        func f(_ v: Double) -> Double { min(1, max(0, (v - lo) / (hi - lo))) }
        return KickBreakdown.Gauge(targetStart: openLow ? 0 : f(low), targetEnd: openHigh ? 1 : f(high), value: f(value),
                                   openLow: openLow, openHigh: openHigh)
    }

    /// Whether the kick type's profile grades this area at all (any weighted measurement).
    static func isGradedArea(_ category: AnalysisCategory, kickType: KickType) -> Bool {
        let scoring = BiomechanicsProfile.standard(for: kickType).scoring
        return KickMetricCatalog.keys(in: category).contains { (scoring[$0]?.weight ?? 0) > 0 }
    }

    static func explanation(status: KickBreakdown.Status, headline: KickBreakdown.Measurement?, reason: String?) -> String {
        guard let m = headline else { return reason ?? "Not measured." }
        var text = "\(m.name): \(m.valueText)"
        if let target = m.targetText, m.verdict != .noTarget {
            text += " — \(m.verdict.phrase) (\(target))."
        } else {
            text += ". \(KickBreakdown.Verdict.noTarget.phrase.prefix(1).uppercased() + KickBreakdown.Verdict.noTarget.phrase.dropFirst())."
        }
        if let usual = m.usualText { text += " Your usual: \(usual)." }
        text += " " + m.definition
        if status == .notGraded, let reason { text += " " + reason }
        return text
    }

    static func contactText(_ outcome: ContactOutcome?, time: Double?) -> String {
        let at = time.map { String(format: " at %.2f s", $0) } ?? ""
        switch outcome {
        case .ballVerifiedContact?: return "contact verified from the ball\(at)"
        case .ballConstrainedContactInterval?: return "contact timed from the ball\(at)"
        case .poseEstimatedContact?: return "contact estimated from body pose\(at)"
        case .strikeWindowOnly?: return "strike window only (contact time uncertain)"
        case .contactUncertain?: return "contact uncertain"
        case .userSelectedContact?: return "contact chosen by you\(at)"
        case .contactUnavailable?, nil: return "contact not found"
        }
    }

    /// The coach's summary: strongest graded area, the priority (or why there is none),
    /// and what was measured when nothing was graded — every number from the cards.
    static func summary(_ b: KickBreakdown) -> String {
        var parts: [String] = []
        if let best = b.strongest, let m = best.headline, best.status == .strength || best.status == .solid {
            parts.append("Strongest area: \(best.phase.title.lowercased()) — \(m.name.lowercased()) \(m.valueText), \(m.verdict.phrase).")
        }
        if let p = b.priority, let card = b.phases.first(where: { $0.phase == p.phase }), let m = card.headline {
            parts.append("Biggest gain: \(p.phase.title.lowercased()) — \(m.name.lowercased()) \(m.valueText), \(m.verdict.phrase). \(p.cue)")
        } else if let text = b.noPriorityText {
            parts.append(text)
            if let w = b.watch { parts.append(w.text) }
        }
        if !b.phases.contains(where: { $0.status.isGraded }) {
            let measured = b.phases.compactMap(\.headline).prefix(3).map { "\($0.name.lowercased()) \($0.valueText)" }
            if !measured.isEmpty { parts.insert("Measured on this kick: " + measured.joined(separator: "; ") + ".", at: 0) }
        }
        return parts.joined(separator: " ")
    }
}

/// Build 22: the Kick Breakdown's internal consistency rules. Every rule names the card
/// and what disagreed; an empty list means labels, numbers and text agree.
enum KickBreakdownCheck {
    static func issues(_ b: KickBreakdown) -> [String] {
        var out: [String] = []
        for c in b.phases {
            let name = c.phase.title
            // 1. The pill matches the score band.
            if let s = c.score {
                let expected = KickBreakdown.Status(label: PerformanceReport.Label(score: Double(s)))
                if c.status != expected { out.append("\(name): status \(c.status.title) but score \(s) is \(expected.title)") }
            } else if c.status.isGraded {
                out.append("\(name): graded status without a score")
            }
            // 2. The sentence states the headline's own value and verdict.
            if let m = c.headline {
                if !c.explanation.contains(m.valueText) { out.append("\(name): explanation doesn't state \(m.valueText)") }
                if m.verdict != .noTarget, !c.explanation.contains(m.verdict.phrase) { out.append("\(name): explanation contradicts the verdict") }
                if let t = m.targetText, m.verdict != .noTarget, !c.explanation.contains(t) { out.append("\(name): target \(t) not shown with the value") }
                // A good status isn't explained by a measurement outside its target, and a
                // needs-work status isn't explained by one inside it, when another measurement
                // on the card is the real reason.
                let all = [m] + c.others
                if c.status.needsWork, m.verdict == .inside, all.contains(where: { $0.verdict == .below || $0.verdict == .above }) {
                    out.append("\(name): needs work, but its headline is inside target while another measurement isn't")
                }
                if c.status == .strength || c.status == .solid, m.verdict != .inside, all.contains(where: { $0.verdict == .inside }) {
                    out.append("\(name): good status, but its headline is outside target while another measurement is inside")
                }
            }
            if c.status == .notMeasured, c.headline != nil { out.append("\(name): 'not measured' with a measurement") }
            // 2b. Every target bar places the value on the side its verdict says.
            for m in [c.headline].compactMap({ $0 }) + c.others {
                guard let g = m.gauge else {
                    if m.verdict != .noTarget { out.append("\(name): \(m.name) has a target but no bar") }
                    continue
                }
                let eps = 1e-9
                let ok: Bool = switch m.verdict {
                case .inside: g.value >= g.targetStart - eps && g.value <= g.targetEnd + eps
                case .below: g.value <= g.targetStart + eps
                case .above: g.value >= g.targetEnd - eps
                case .noTarget: false
                }
                if !ok { out.append("\(name): \(m.name) bar disagrees with '\(m.verdict.rawValue)'") }
            }
        }
        // 3. The priority is in an area that needs work and names a measurement shown there.
        if let p = b.priority {
            if let card = b.phases.first(where: { $0.phase == p.phase }) {
                if !card.status.needsWork { out.append("Priority in \(p.phase.title), which is \(card.status.title)") }
                if let k = p.metricKey, !([card.headline].compactMap { $0 } + card.others).contains(where: { $0.key == k }) {
                    out.append("Priority rests on a measurement not shown on the \(p.phase.title) card")
                }
            }
            if b.noPriorityText != nil { out.append("Both a priority and 'no priority'") }
        } else if b.noPriorityText == nil {
            out.append("Neither a priority nor a reason for none")
        }
        // 4. The grade's word matches its number.
        if let s = b.grade.score, let l = b.grade.label, PerformanceReport.Label(score: Double(s)) != l {
            out.append("Grade \(s) labelled \(l.title)")
        }
        return out
    }
}
