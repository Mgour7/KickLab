import Foundation

/// Date ranges offered on the statistics screen. Fixed-length periods (24-hour days).
enum StatsDatePreset: String, CaseIterable, Identifiable, Sendable {
    case last7
    case last30
    case last90
    case allTime

    var id: String { rawValue }

    var title: String {
        switch self {
        case .last7: "7 days"
        case .last30: "30 days"
        case .last90: "90 days"
        case .allTime: "All time"
        }
    }

    func range(endingAt now: Date) -> ClosedRange<Date>? {
        switch self {
        case .last7: StatisticsPeriod.last(days: 7, endingAt: now)
        case .last30: StatisticsPeriod.last(days: 30, endingAt: now)
        case .last90: StatisticsPeriod.last(days: 90, endingAt: now)
        case .allTime: nil
        }
    }
}

/// Kick types offered on the statistics screen.
enum StatsKickTypeFilter: String, CaseIterable, Identifiable, Sendable {
    case fieldGoal
    case pat
    case kickoff
    case punt

    var id: String { rawValue }
    var title: String { kickType.displayName }

    var kickType: KickType {
        switch self {
        case .fieldGoal: .fieldGoal
        case .pat: .pat
        case .kickoff: .kickoff
        case .punt: .punt
        }
    }
}

struct StatRow: Equatable, Sendable, Identifiable {
    var id: String { title }
    var title: String
    var value: String
    var detail: String?
}

struct StatSection: Equatable, Sendable, Identifiable {
    var id: String { title }
    var title: String
    var rows: [StatRow]
    /// Shown instead of rows when there is nothing to show.
    var emptyMessage: String?
}

enum StatisticsPresentation {
    /// Accuracy dispersion is shown only with at least this many recorded crossing points.
    static let minimumAccuracySamples = 5

    static func noKicksMessage(_ type: KickType) -> String {
        "No \(type.displayName.lowercased()) kicks in this period."
    }

    static func fieldGoalSections(_ s: FieldGoalStatistics) -> [StatSection] {
        guard s.kickCount > 0 else {
            return [StatSection(title: s.kickType.displayName, rows: [], emptyMessage: noKicksMessage(s.kickType))]
        }
        var overview = [
            StatRow(title: "Made", value: "\(s.makeRate.successes) of \(s.makeRate.attempts)", detail: nil),
            StatRow(title: "Make %", value: DisplayFormat.percentage(s.makeRate.percentage), detail: nil),
        ]
        let misses: [(String, Int)] = [
            ("Missed left", s.results.missedLeft), ("Missed right", s.results.missedRight),
            ("Short", s.results.short), ("Blocked", s.results.blocked),
            ("Missed (other)", s.results.missedOther),
        ]
        for (title, count) in misses where count > 0 {
            overview.append(StatRow(title: title, value: "\(count)", detail: nil))
        }
        if s.results.unknown > 0 {
            overview.append(StatRow(title: "Result not recorded", value: "\(s.results.unknown)", detail: "Not counted as attempts"))
        }

        let distanceRows = s.byDistance.filter { $0.makeRate.attempts > 0 }.map { bucket in
            StatRow(title: bucket.bucket.displayName + " yd",
                    value: DisplayFormat.percentage(bucket.makeRate.percentage),
                    detail: "\(bucket.makeRate.successes) of \(bucket.makeRate.attempts)")
        }
        let hashRows = s.byHash.filter { $0.makeRate.attempts > 0 && $0.hash != .notApplicable }.map { hash in
            StatRow(title: hash.hash.displayName,
                    value: DisplayFormat.percentage(hash.makeRate.percentage),
                    detail: "\(hash.makeRate.successes) of \(hash.makeRate.attempts)")
        }

        var sections = [
            StatSection(title: "Overview", rows: overview, emptyMessage: nil),
            StatSection(title: "By distance", rows: distanceRows,
                        emptyMessage: distanceRows.isEmpty ? "Record distances to see make % by distance." : nil),
            StatSection(title: "By hash", rows: hashRows,
                        emptyMessage: hashRows.isEmpty ? "Record the hash to see make % by hash." : nil),
        ]
        sections.append(accuracySection(s.accuracy))
        return sections
    }

    static func accuracySection(_ a: AccuracyStatistics) -> StatSection {
        guard a.sampleCount >= minimumAccuracySamples else {
            return StatSection(
                title: "Accuracy", rows: [],
                emptyMessage: "Mark where at least \(minimumAccuracySamples) kicks crossed the goal to see your accuracy pattern (\(a.sampleCount) so far)."
            )
        }
        var rows: [StatRow] = []
        if let x = a.averageX {
            rows.append(StatRow(title: "Average crossing point", value: horizontalText(x), detail: "\(a.sampleCount) kicks"))
        }
        if let spread = a.averageAbsoluteDeviation {
            rows.append(StatRow(title: "Spread", value: DisplayFormat.number(spread, digits: 2),
                                detail: "Average distance from your average point, in half-goal widths"))
        }
        for band in a.allDistribution where band.count > 0 {
            rows.append(StatRow(title: bandTitle(band.band), value: "\(band.count)", detail: nil))
        }
        return StatSection(title: "Accuracy", rows: rows, emptyMessage: nil)
    }

    static func bandTitle(_ band: HorizontalBand) -> String {
        switch band {
        case .outsideLeft: "Wide left"
        case .left: "Left third"
        case .center: "Middle third"
        case .right: "Right third"
        case .outsideRight: "Wide right"
        }
    }

    /// "Center", "0.30 left of center", in half-goal widths (1 = an upright).
    static func horizontalText(_ x: Double) -> String {
        if abs(x) < 0.05 { return "Center" }
        return DisplayFormat.number(abs(x), digits: 2) + (x < 0 ? " left of center" : " right of center")
    }

    static func kickoffSections(_ s: KickoffStatistics) -> [StatSection] {
        guard s.kickoffCount > 0 else {
            return [StatSection(title: "Kickoffs", rows: [], emptyMessage: noKicksMessage(.kickoff))]
        }
        var rows = [StatRow(title: "Kickoffs", value: "\(s.kickoffCount)", detail: nil)]
        if s.touchbackRate.attempts > 0 {
            rows.append(StatRow(title: "Touchback %", value: DisplayFormat.percentage(s.touchbackRate.percentage),
                                detail: "\(s.touchbackRate.successes) of \(s.touchbackRate.attempts)"))
        }
        if s.outOfBoundsCount > 0 {
            rows.append(StatRow(title: "Out of bounds", value: "\(s.outOfBoundsCount)", detail: nil))
        }
        var sections = [StatSection(title: "Overview", rows: rows, emptyMessage: nil)]
        sections.append(measurementSection("Distance", s.distance, format: DisplayFormat.yards))
        sections.append(measurementSection("Hang time", s.hangTime, format: DisplayFormat.seconds))
        let zones = s.landingZones.filter { $0.count > 0 && $0.zone != .unknown }.map {
            StatRow(title: $0.zone.displayName, value: "\($0.count)", detail: nil)
        }
        var landingRows = zones
        if let line = s.landingYardLine.average {
            landingRows.insert(StatRow(title: "Average landing spot", value: "\(DisplayFormat.number(line, digits: 0)) yd line",
                                       detail: "\(s.landingYardLine.sampleCount) kickoffs"), at: 0)
        }
        sections.append(StatSection(title: "Landing zone", rows: landingRows,
                                    emptyMessage: landingRows.isEmpty ? "Record where kickoffs land to see this." : nil))
        return sections
    }

    static func puntSections(_ s: PuntStatistics) -> [StatSection] {
        guard s.puntCount > 0 else {
            return [StatSection(title: "Punts", rows: [], emptyMessage: noKicksMessage(.punt))]
        }
        return [
            StatSection(title: "Overview", rows: [StatRow(title: "Punts", value: "\(s.puntCount)", detail: nil)], emptyMessage: nil),
            measurementSection("Distance", s.distance, format: DisplayFormat.yards),
            measurementSection("Hang time", s.hangTime, format: DisplayFormat.seconds),
        ]
    }

    static func measurementSection(_ title: String, _ m: MeasurementSummary, format: (Double?) -> String) -> StatSection {
        guard m.sampleCount > 0 else {
            return StatSection(title: title, rows: [], emptyMessage: "No \(title.lowercased()) recorded yet.")
        }
        return StatSection(title: title, rows: [
            StatRow(title: "Average", value: format(m.average), detail: "\(m.sampleCount) recorded"),
            StatRow(title: "Best", value: format(m.maximum), detail: nil),
        ], emptyMessage: nil)
    }
}
