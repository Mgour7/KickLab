import Foundation

/// Field-position helpers. Nothing here is persisted or applied automatically.
///
/// KickLab stores field position as an analytical 0–100 coordinate:
/// yards from the goal line the kick travels toward (`spotDistanceToTargetGoalLine`).
///
/// | Coordinate | Football notation |
/// |---|---|
/// | 30 | Opp 30 |
/// | 50 | 50 |
/// | 60 | Own 40 |
/// | 80 | Own 20 |
///
/// People never see the raw coordinate; the UI shows `footballNotation(...)`.
enum FieldGeometry {
    /// Depth of a standard end zone. Goalposts sit on the end line behind it.
    static let standardEndZoneDepthYards: Double = 10

    /// The valid coordinate range: 0 = target goal line, 100 = the kicking team's goal line.
    static let coordinateRange: ClosedRange<Int> = 0...100

    /// Converts a 0–100 coordinate into football notation.
    /// - 0...49 → "Opp N" (e.g. 30 → "Opp 30")
    /// - 50 → "50"
    /// - 51...100 → "Own (100 − N)" (e.g. 60 → "Own 40", 80 → "Own 20")
    ///
    /// Returns nil for values outside 0...100.
    static func footballNotation(spotDistanceToTargetGoalLine spot: Int) -> String? {
        guard coordinateRange.contains(spot) else { return nil }
        switch spot {
        case 50:
            return "50"
        case ..<50:
            return "Opp \(spot)"
        default:
            return "Own \(100 - spot)"
        }
    }

    /// Converts football notation back to the 0–100 coordinate.
    /// - Parameters:
    ///   - yardLine: the painted yard line, 0...50.
    ///   - side: which half of the field; ignored when `yardLine` is 50.
    /// - Returns: nil for yard lines outside 0...50.
    static func spotDistanceToTargetGoalLine(yardLine: Int, side: FieldSide) -> Int? {
        guard (0...50).contains(yardLine) else { return nil }
        if yardLine == 50 { return 50 }
        switch side {
        case .opponent: return yardLine
        case .own: return 100 - yardLine
        }
    }

    /// Estimated field-goal distance for a hold spot: spot coordinate + end-zone depth.
    /// A hold at Opp 30 (coordinate 30) is about a 40-yard field goal.
    ///
    /// An estimate only. It is never written into `Kick.distanceYards`, which stores
    /// the actual kick distance; the UI shows "Hold: Opp 30" and "Distance: 40 yd"
    /// as separate facts.
    static func estimatedFieldGoalDistance(
        spotDistanceToTargetGoalLine spot: Int,
        endZoneDepthYards: Double = FieldGeometry.standardEndZoneDepthYards
    ) -> Double {
        Double(spot) + endZoneDepthYards
    }
}

/// Which half of the field a painted yard line is on, from the kicking team's view.
enum FieldSide: Sendable {
    /// The half the kick travels toward ("Opp").
    case opponent
    /// The kicking team's own half ("Own").
    case own
}
