import SwiftUI

/// Kicks that have video, ready to analyze.
struct AnalyzeView: View {
    @Environment(AppModel.self) private var app
    @State private var model = AnalyzeListViewModel()

    init() {}

    var body: some View {
        content
            .navigationTitle("Analyze")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { AthleteSwitcherMenu() }
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink(value: AppRoute.athleteHistory) {
                        Label("History", systemImage: "clock.arrow.circlepath")
                    }
                }
            }
            .task(id: app.revision) { model.load(app: app) }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let kicks):
            if kicks.isEmpty {
                EmptyStateView(
                    title: "No videos yet",
                    systemImage: "video.slash",
                    message: "Open a kick in the Kicks tab and add a video. Kicks with video show up here for analysis."
                )
            } else {
                List {
                    Section {
                        ForEach(kicks) { kick in
                            NavigationLink(value: AppRoute.analyze(kick.id)) { KickRow(kick: kick) }
                        }
                    } footer: {
                        Text("Analysis runs on this iPhone. Videos are never uploaded.")
                    }
                }
            }
        }
    }
}

/// Runs and monitors the analysis of one kick. The run's state lives in `AppModel`, so
/// leaving and returning to this screen shows the same run.
struct AnalysisRunView: View {
    @Environment(AppModel.self) private var app
    let kickID: UUID
    @State private var model: AnalysisRunViewModel?

    init(kickID: UUID) {
        self.kickID = kickID
    }

    var body: some View {
        Group {
            if let model {
                AnalysisRunContent(model: model)
            } else {
                LoadingStateView()
            }
        }
        .task { model = app.analysisRun(for: kickID) }
    }
}

private struct AnalysisRunContent: View {
    @Environment(AppModel.self) private var app
    let model: AnalysisRunViewModel
    @State private var selectingKicker = false

    init(model: AnalysisRunViewModel) {
        self.model = model
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                stateContent
            }
            .padding()
        }
        .navigationTitle("Analyze Kick")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $selectingKicker) {
            if let source = model.kickerSelectionSource(app: app) {
                KickerSelectionView(source: source) { point in
                    model.chooseKicker(at: point, source: source)
                    selectingKicker = false
                    model.retry(app: app)
                }
            } else {
                EmptyStateView(title: "No preview available", systemImage: "photo",
                               message: "This video has no preview image to tap on. Try importing it again.")
            }
        }
    }

    @ViewBuilder
    private var stateContent: some View {
        switch model.state {
        case .idle:
            CardView {
                Text("Analyze this kick").font(.headline)
                Text("KickLab finds the kicker, follows their body through the kick, and measures approach, plant, swing, body position and follow-through. It takes about as long as the video.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                if model.kickerSeed != nil {
                    Label("Kicker selected by tap", systemImage: "hand.tap")
                        .font(.subheadline)
                }
            }
            Button {
                model.start(app: app)
            } label: {
                Label("Start Analysis", systemImage: "play.fill")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            Button("Choose the kicker first") { selectingKicker = true }
                .font(.subheadline)
        case .running(_, let fraction):
            CardView {
                Text(model.state.stageText ?? "Analyzing").font(.headline)
                ProgressView(value: fraction)
                    .accessibilityValue(DisplayFormat.percent(fraction: fraction))
                Text("You can leave this screen; the analysis keeps running.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Button(role: .cancel) {
                model.cancel()
            } label: {
                Text("Cancel").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
        case .cancelling:
            LoadingStateView(text: "Cancelling…")
        case .completed(let analysisID):
            CardView {
                Label("Analysis complete", systemImage: "checkmark.circle.fill").font(.headline)
                Text("Your results and coaching are ready.").font(.subheadline)
            }
            NavigationLink(value: AppRoute.analysis(analysisID)) {
                Text("View Results").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
        case .failed(let problem):
            problemView(problem)
        case .cancelled:
            CardView {
                Label("Analysis cancelled", systemImage: "xmark.circle").font(.headline)
                Text("Nothing was changed. You can start again any time.").font(.subheadline)
            }
            Button {
                model.retry(app: app)
            } label: {
                Text("Start Again").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private func problemView(_ problem: AnalysisProblem) -> some View {
        VStack(spacing: 16) {
            CardView {
                Label(problem.title, systemImage: "exclamationmark.triangle").font(.headline)
                Text(problem.message).font(.subheadline)
            }
            if problem.suggestsKickerSelection {
                Button {
                    selectingKicker = true
                } label: {
                    Label("Tap the Kicker", systemImage: "hand.tap")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
            }
            if problem.canRetry {
                Button {
                    model.retry(app: app)
                } label: {
                    Text("Try Again").frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered)
            }
        }
    }
}

/// Tap the kicker on the video's preview frame. The tap becomes a `KickerSeed`, which
/// always wins over automatic selection.
struct KickerSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    let source: AnalysisRunViewModel.KickerSelectionSource
    let onSelect: (NormalizedPoint) -> Void

    @State private var image: UIImage?
    @State private var tapped: CGPoint?

    init(source: AnalysisRunViewModel.KickerSelectionSource, onSelect: @escaping (NormalizedPoint) -> Void) {
        self.source = source
        self.onSelect = onSelect
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Tap the kicker").font(.title3.bold())
                Text("Tap on the kicker's body in this frame from the video.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .overlay {
                            GeometryReader { proxy in
                                ZStack {
                                    Color.clear
                                        .contentShape(Rectangle())
                                        .onTapGesture { location in
                                            select(location, in: proxy.size)
                                        }
                                    if let tapped {
                                        Circle()
                                            .stroke(Color.orange, lineWidth: 3)
                                            .frame(width: 36, height: 36)
                                            .position(tapped)
                                    }
                                }
                            }
                        }
                        .accessibilityLabel("Video frame. Tap the kicker.")
                } else {
                    LoadingStateView(text: "Loading frame…")
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Choose Kicker")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
            .task {
                image = await ThumbnailView.load(source.thumbnailURL)
            }
        }
    }

    private func select(_ location: CGPoint, in size: CGSize) {
        guard size.width > 0, size.height > 0 else { return }
        tapped = location
        let point = NormalizedPoint(x: Double(location.x / size.width), y: Double(location.y / size.height))
        onSelect(point)
    }
}
