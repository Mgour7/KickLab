import SwiftUI

/// Kicks that have video, ready to analyze.
struct AnalyzeView: View {
    @Environment(AppModel.self) private var app
    @State private var model = AnalyzeListViewModel()
    /// Build 21: capture and session entry points.
    @State private var recordingSingleKick = false
    @State private var settingUpSession = false
    @State private var importingSession = false
    @State private var addingKick = false
    @State private var recordingSessionID: UUID?
    @State private var openedKick: UUID?
    @State private var openedSession: UUID?
    @State private var sessions: [TrainingSessionManifest] = []
    @State private var importProblem: String?
    /// Where to go once the sheet/cover that produced it has finished dismissing (presenting
    /// a full-screen cover or pushing while a sheet is still animating away is unreliable).
    @State private var pendingRecordingSessionID: UUID?
    @State private var pendingOpenedKick: UUID?
    @State private var pendingOpenedSession: UUID?

    init() {}

    var body: some View {
        content
            .navigationTitle("Analyze")
            .navigationDestination(item: $openedKick) { AnalysisRunView(kickID: $0, startsAutomatically: true) }
            .navigationDestination(item: $openedSession) { SessionReviewView(sessionID: $0) }
            .fullScreenCover(isPresented: $recordingSingleKick, onDismiss: {
                if let id = pendingOpenedKick { pendingOpenedKick = nil; openedKick = id }
            }) {
                RecordKickView { pendingOpenedKick = $0 }
            }
            .sheet(isPresented: $settingUpSession, onDismiss: {
                if let id = pendingRecordingSessionID { pendingRecordingSessionID = nil; recordingSessionID = id }
            }) {
                TrainingSessionSetupView { id, _ in pendingRecordingSessionID = id }
            }
            .sheet(isPresented: $importingSession) {
                TrainingSessionSetupView(importsVideo: true) { id, url in
                    guard let url else { return }
                    Task {
                        do {
                            let planned = (try? app.services.trainingSessions.load(id))?.plannedCameraRole ?? .unspecified
                            _ = try await TrainingSessionImport.importSource(app: app, sessionID: id, from: url, role: planned)
                        } catch {
                            importProblem = "The practice video couldn't be imported (\(error.localizedDescription))."
                        }
                        openedSession = id
                    }
                }
            }
            .sheet(isPresented: $addingKick) { KickEntryView(sessionID: nil) }
            .fullScreenCover(item: Binding(get: { recordingSessionID.map(IdentifiedID.init) }, set: { recordingSessionID = $0?.id }), onDismiss: {
                if let id = pendingOpenedSession { pendingOpenedSession = nil; openedSession = id }
            }) { item in
                TrainingSessionRecordView(sessionID: item.id) { pendingOpenedSession = item.id }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { AthleteSwitcherMenu() }
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink(value: AppRoute.athleteHistory) {
                        Label("History", systemImage: "clock.arrow.circlepath")
                    }
                }
            }
            .task(id: app.revision) {
                model.load(app: app)
                sessions = TrainingSessionLibrary.sessions(app: app)
            }
    }

    /// Build 21: record, start a session, or import.
    private var captureSection: some View {
        Section {
            Button { recordingSingleKick = true } label: { Label("Record Single Kick", systemImage: "video.circle") }
            Button { settingUpSession = true } label: { Label("Start Training Session", systemImage: "record.circle") }
            Button { addingKick = true } label: { Label("Import Video", systemImage: "square.and.arrow.down") }
            Button { importingSession = true } label: { Label("Import Training Session Video", systemImage: "film.stack") }
            if let importProblem { Text(importProblem).font(.caption).foregroundStyle(.red) }
        } footer: {
            Text("Import Video creates a kick; add its video on the kick's page. Recording and analysis stay on this iPhone; videos are never uploaded.")
        }
    }

    @ViewBuilder
    private var sessionsSection: some View {
        if !sessions.isEmpty {
            Section("Training sessions") {
                ForEach(sessions.prefix(10)) { s in
                    NavigationLink(value: AppRoute.trainingSession(s.id)) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(s.name).font(.subheadline.weight(.semibold))
                            Text("\(DisplayFormat.shortDate(s.createdAt)) · \(s.attempts.count) kick\(s.attempts.count == 1 ? "" : "s") · \(s.sources.count) recording\(s.sources.count == 1 ? "" : "s")")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let kicks):
            if kicks.isEmpty {
                List {
                    captureSection
                    sessionsSection
                    Section {
                        Text("No kick videos yet. Record one above, or open a kick in the Kicks tab and add a video.").foregroundStyle(.secondary)
                    }
                }
            } else {
                List {
                    captureSection
                    sessionsSection
                    Section {
                        ForEach(kicks) { kick in
                            NavigationLink(value: AppRoute.analyze(kick.id)) { KickRow(kick: kick) }
                        }
                    } footer: {
                        Text("Analysis runs on this iPhone. Videos are never uploaded.")
                    }
                }
            }
        }
    }
}

/// An identifiable UUID wrapper for item-driven presentation.
struct IdentifiedID: Identifiable, Hashable {
    let id: UUID
}

/// Runs and monitors the analysis of one kick. The run's state lives in `AppModel`, so
/// leaving and returning to this screen shows the same run.
struct AnalysisRunView: View {
    @Environment(AppModel.self) private var app
    let kickID: UUID
    /// Starts a new automatic analysis as soon as the screen opens ("Reanalyze Automatically").
    let startsAutomatically: Bool
    @State private var model: AnalysisRunViewModel?
    @State private var didAutoStart = false

    init(kickID: UUID, startsAutomatically: Bool = false) {
        self.kickID = kickID
        self.startsAutomatically = startsAutomatically
    }

    var body: some View {
        Group {
            if let model {
                AnalysisRunContent(model: model)
            } else {
                LoadingStateView()
            }
        }
        .task {
            let run = app.analysisRun(for: kickID)
            // A finished run whose analysis was deleted, or whose videos changed, is stale.
            run.refresh(app: app)
            if startsAutomatically, !didAutoStart {
                didAutoStart = true
                run.startAutomatic(app: app)
            }
            model = run
        }
    }
}

private struct AnalysisRunContent: View {
    @Environment(AppModel.self) private var app
    let model: AnalysisRunViewModel
    @State private var selectingKicker = false

    init(model: AnalysisRunViewModel) {
        self.model = model
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                stateContent
            }
            .padding()
        }
        .navigationTitle("Analyze Kick")
        .navigationBarTitleDisplayMode(.inline)
        // Keep the screen awake while analyzing; iOS limits work once KickLab is in the background.
        .onChange(of: model.state.isBusy, initial: true) { _, busy in IdleTimer.setDisabled(busy) }
        .onDisappear { IdleTimer.setDisabled(false) }
        .sheet(isPresented: $selectingKicker) {
            if let source = model.kickerSelectionSource(app: app) {
                KickerSelectionView(source: source) { point in
                    model.chooseKicker(at: point, source: source)
                    selectingKicker = false
                    model.retry(app: app)
                }
            } else {
                EmptyStateView(title: "No preview available", systemImage: "photo",
                               message: "This video has no preview image to tap on. Try importing it again.")
            }
        }
    }

    @ViewBuilder
    private var stateContent: some View {
        switch model.state {
        case .idle:
            CardView {
                Text("Analyze this kick").font(.headline)
                Text("KickLab finds the kicker, follows their body through the kick, and measures approach, plant, swing, body position and follow-through. It takes about as long as the video.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                if model.kickerSeed != nil {
                    Label("Kicker selected by tap", systemImage: "hand.tap")
                        .font(.subheadline)
                }
            }
            Button {
                model.start(app: app)
            } label: {
                Label("Start Automatic Analysis", systemImage: "play.fill")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            Button("Choose the kicker first") { selectingKicker = true }
                .font(.subheadline)
        case .running(_, let fraction):
            CardView {
                Text(model.state.stageText ?? "Analyzing").font(.headline)
                ProgressView(value: fraction)
                    .accessibilityValue(DisplayFormat.percent(fraction: fraction))
                Text("Keep KickLab open until it finishes. If KickLab goes to the background, the analysis stops and you can try again.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Button(role: .cancel) {
                model.cancel()
            } label: {
                Text("Cancel").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
        case .cancelling:
            LoadingStateView(text: "Cancelling…")
        case .completed(let analysisID):
            CardView {
                Label("Analysis complete", systemImage: "checkmark.circle.fill").font(.headline)
                Text("Your results and coaching are ready.").font(.subheadline)
                runDescription
            }
            NavigationLink(value: AppRoute.analysis(analysisID)) {
                Text("View Results").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            reanalyzeButtons(analysisID: analysisID, offersManualContact: true)
        case .failed(let problem):
            problemView(problem)
        case .cancelled:
            CardView {
                Label("Analysis cancelled", systemImage: "xmark.circle").font(.headline)
                Text("Nothing was changed. You can start again any time.").font(.subheadline)
            }
            Button {
                model.startAutomatic(app: app)
            } label: {
                Text("Start Automatic Analysis").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private func problemView(_ problem: AnalysisProblem) -> some View {
        VStack(spacing: 16) {
            CardView {
                Label(problem.title, systemImage: "exclamationmark.triangle").font(.headline)
                Text(problem.message).font(.subheadline)
                runDescription
            }
            if problem.suggestsKickerSelection {
                Button {
                    selectingKicker = true
                } label: {
                    Label("Tap the Kicker", systemImage: "hand.tap")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
            }
            if problem.canRetry {
                // Always automatic: a manual choice from an earlier run is never reused.
                Button {
                    model.startAutomatic(app: app)
                } label: {
                    Text(model.lastRunMode?.isUserAssisted == true ? "Reanalyze Automatically" : "Try Again")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered)
            }
            // Step 12D: user-assisted recovery instead of a dead end.
            if let id = model.lastAnalysisID, problem.offersContactSelection || problem.offersKickSelection {
                if problem.offersKickSelection {
                    NavigationLink(value: AppRoute.assistKick(kick: model.kickID, analysis: id)) {
                        Label("Choose the Kick", systemImage: "scissors").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.borderedProminent)
                }
                if problem.offersContactSelection {
                    NavigationLink(value: AppRoute.assistContact(kick: model.kickID, analysis: id)) {
                        Label("Reanalyze With Manual Contact", systemImage: "hand.tap").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                }
            }
            if let id = model.lastAnalysisID, !problem.offersContactSelection, model.lastRunMode?.isUserAssisted == true {
                reanalyzeButtons(analysisID: id, offersManualContact: true, offersAutomatic: false)
            }
            if app.showsAnalysisDiagnostics, let id = model.lastAnalysisID {
                NavigationLink(value: AppRoute.diagnostics(id)) {
                    Label("Diagnostics", systemImage: "stethoscope").frame(maxWidth: .infinity, minHeight: 44)
                }
                NavigationLink(value: AppRoute.poseValidation(id)) {
                    Label("Pose Validation", systemImage: "figure.walk.motion").frame(maxWidth: .infinity, minHeight: 44)
                }
            }
        }
    }
}

extension AnalysisRunContent {
    /// Which kind of run produced the result shown, and the engine version recorded on it.
    @ViewBuilder
    var runDescription: some View {
        if let mode = model.lastRunMode {
            Label(mode.title, systemImage: mode.isUserAssisted ? "hand.tap" : "gearshape")
                .font(.caption.weight(.semibold))
        }
        if let version = model.lastAnalysisVersion {
            Text("Engine \(version)").font(.caption).foregroundStyle(.secondary)
        }
    }

    /// The two explicit reanalysis actions. Each creates a NEW analysis; earlier ones stay.
    @ViewBuilder
    func reanalyzeButtons(analysisID: UUID, offersManualContact: Bool, offersAutomatic: Bool = true) -> some View {
        if offersAutomatic {
            Button {
                model.startAutomatic(app: app)
            } label: {
                Label("Reanalyze Automatically", systemImage: "arrow.clockwise")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
        }
        if offersManualContact {
            NavigationLink(value: AppRoute.assistContact(kick: model.kickID, analysis: analysisID)) {
                Label("Reanalyze With Manual Contact", systemImage: "hand.tap")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
        }
        Text("Reanalyzing creates a new analysis and keeps the earlier ones. Automatic reanalysis never uses a contact frame chosen before.")
            .font(.caption).foregroundStyle(.secondary)
    }
}

/// Tap the kicker on the video's preview frame. The tap becomes a `KickerSeed`, which
/// always wins over automatic selection.
struct KickerSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    let source: AnalysisRunViewModel.KickerSelectionSource
    let onSelect: (NormalizedPoint) -> Void

    @State private var image: UIImage?
    @State private var tapped: CGPoint?

    init(source: AnalysisRunViewModel.KickerSelectionSource, onSelect: @escaping (NormalizedPoint) -> Void) {
        self.source = source
        self.onSelect = onSelect
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Tap the kicker").font(.title3.bold())
                Text("Tap on the kicker's body in this frame from the video.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .overlay {
                            GeometryReader { proxy in
                                ZStack {
                                    Color.clear
                                        .contentShape(Rectangle())
                                        .onTapGesture { location in
                                            select(location, in: proxy.size)
                                        }
                                    if let tapped {
                                        Circle()
                                            .stroke(Color.orange, lineWidth: 3)
                                            .frame(width: 36, height: 36)
                                            .position(tapped)
                                    }
                                }
                            }
                        }
                        .accessibilityLabel("Video frame. Tap the kicker.")
                } else {
                    LoadingStateView(text: "Loading frame…")
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Choose Kicker")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
            .task {
                image = await ThumbnailView.load(source.thumbnailURL)
            }
        }
    }

    private func select(_ location: CGPoint, in size: CGSize) {
        guard size.width > 0, size.height > 0 else { return }
        tapped = location
        let point = NormalizedPoint(x: Double(location.x / size.width), y: Double(location.y / size.height))
        onSelect(point)
    }
}
