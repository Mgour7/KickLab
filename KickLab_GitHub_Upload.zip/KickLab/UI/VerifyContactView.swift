import AVKit
import SwiftUI
#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
#endif

/// Step 12F/12G: Verify Contact — step through the original video frame by frame, look at
/// close-ups of the ball and foot, and mark first contact, the first ball movement and the
/// plant frame; or mark the ball once and let the app measure when it leaves its spot.
/// Everything here is the user's input: it never changes the existing analysis.
struct VerifyContactView: View {
    @Environment(AppModel.self) private var app
    @State private var model: VerifyContactViewModel
    @State private var player: ValidationPlayer?
    @State private var frameIndex = 0
    @State private var closeUp: UIImage?
    @State private var strip: [(index: Int, image: UIImage?)] = []
    @State private var markingBall = false
    @State private var started = false

    init(analysisID: UUID) {
        _model = State(initialValue: VerifyContactViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Verify Contact")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
                let start: Double? = {
                    if case .contact(let t) = model.annotation { return t }
                    return model.state.value?.automaticTime
                }()
                if let start { go(to: start) }
            }
            .task(id: frameIndex) { await loadImages() }
            .onDisappear { player?.stop() }
            .sheet(isPresented: $markingBall) {
                if let url = model.state.value?.videoURL, let t = currentTime {
                    BallMarkingSheet(url: url, time: t, aspect: model.state.value?.frameAspect ?? 9.0 / 16.0,
                                     initial: model.verification.ballMark) { point, radius in
                        model.markBall(at: point, radius: radius, time: t, app: app)
                        Task { await loadImages() }
                    }
                }
            }
    }

    private var currentTime: Double? { model.table.time(at: frameIndex) ?? player?.currentTime }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading the video…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Step one frame at a time. Mark the FIRST frame where the foot touches the ball, and the plant frame if you can see it. Your marks are kept with the video; they never change this analysis.")
                        .font(.subheadline)
                    if let player {
                        VideoPlayer(player: player.player)
                            .frame(minHeight: 240)
                        frameControls(player)
                        closeUpSection
                    } else {
                        Text("The video file isn't on this device, so frames can't be shown.").font(.subheadline)
                    }
                    automaticSection(c)
                    contactSection(c)
                    plantAndBallSection(c)
                    ballMeasurementSection(c)
                    reanalysisSection(c)
                    Text("Your marks are never counted as automatic detection and aren't used to train or tune it.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding()
            }
        }
    }

    // MARK: Frames

    private func frameControls(_ player: ValidationPlayer) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(model.frameLabel(time: currentTime ?? 0))
                .font(.headline).monospacedDigit()
                .accessibilityLabel("Current frame")
            HStack(spacing: 12) {
                stepButton(-5, "Back five frames", "chevron.backward.2")
                stepButton(-1, "Back one frame", "chevron.backward")
                Spacer()
                stepButton(1, "Forward one frame", "chevron.forward")
                stepButton(5, "Forward five frames", "chevron.forward.2")
            }
            if model.table.count > 1 {
                Slider(value: Binding(get: { Double(frameIndex) }, set: { go(index: Int($0.rounded())) }),
                       in: 0...Double(model.table.count - 1), step: 1)
                    .accessibilityLabel("Frame")
            }
            if let problem = model.tableProblem {
                Text(problem).font(.caption).foregroundStyle(.secondary)
            } else if model.table.isVariableFrameRate {
                Text("This video has a variable frame rate; the times shown are each frame's own.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func stepButton(_ count: Int, _ label: String, _ symbol: String) -> some View {
        Button { step(count) } label: { Label(label, systemImage: symbol) }
            .labelStyle(.iconOnly)
            .frame(minWidth: 44, minHeight: 44)
            .buttonStyle(.bordered)
    }

    private func step(_ count: Int) {
        if model.table.isEmpty { player?.stepSourceFrame(count) } else { go(index: frameIndex + count) }
    }

    private func go(index: Int) {
        let i = model.table.clamped(index)
        frameIndex = i
        if let t = model.table.time(at: i) { player?.seek(to: t) }
    }

    private func go(to time: Double) {
        if let i = model.table.nearestIndex(to: time) { go(index: i) } else { player?.seek(to: time) }
    }

    // MARK: Close-up and neighbouring frames (full-resolution crops of the real frames)

    private var closeUpSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Close-up").font(.headline)
            if let closeUp {
                Image(uiImage: closeUp)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 280)
                    .accessibilityLabel("Close-up of the ball area in this frame")
            } else {
                Text(model.verification.ballMark == nil ? "Mark the ball to see a close-up of the ball and foot." : "Loading close-up…")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if !strip.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(strip, id: \.index) { item in
                            Button { go(index: item.index) } label: {
                                VStack(spacing: 2) {
                                    if let image = item.image {
                                        Image(uiImage: image).resizable().scaledToFit().frame(width: 72, height: 72)
                                    } else {
                                        Color.gray.frame(width: 72, height: 72)
                                    }
                                    Text((item.index == frameIndex ? "▸ " : "") + String(format: "%.3f", model.table.time(at: item.index) ?? 0))
                                        .font(.caption2).monospacedDigit()
                                }
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Frame \(item.index + 1)")
                        }
                    }
                }
            }
            HStack {
                Button(model.verification.ballMark == nil ? "Mark the Ball" : "Mark the Ball Again") { markingBall = true }
                    .frame(minHeight: 44)
                if model.verification.ballMark != nil {
                    Spacer()
                    Button("Clear Ball Mark", role: .destructive) { model.clearBall(app: app) }
                        .frame(minHeight: 44)
                }
            }
        }
    }

    private func loadImages() async {
        guard let url = model.state.value?.videoURL, let mark = model.verification.ballMark else {
            closeUp = nil
            strip = []
            return
        }
        let aspect = model.state.value?.frameAspect ?? 9.0 / 16.0
        let zoom = FrameReview.zoomRect(around: NormalizedPoint(x: mark.x, y: mark.y), radius: mark.radius, frameAspect: aspect)
        if let t = model.table.time(at: frameIndex) {
            closeUp = await FrameImageLoader.image(url: url, time: t, crop: zoom)
        }
        var items: [(index: Int, image: UIImage?)] = []
        for i in (frameIndex - 2)...(frameIndex + 2) where model.table.time(at: i) != nil {
            items.append((i, await FrameImageLoader.image(url: url, time: model.table.time(at: i) ?? 0, crop: zoom)))
        }
        strip = items
    }

    // MARK: Automatic estimate

    private func automaticSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Automatic analysis").font(.headline)
            if c.isUserAssisted {
                Text("This analysis used frames you chose, so it has no automatic estimate.")
                    .font(.subheadline).foregroundStyle(.secondary)
            } else if let t = c.automaticTime, let r = c.automaticInterval {
                if c.strikeWindowOnly {
                    Text(String(format: "Strike window %.3f–%.3f s — contact timing uncertain (body pose only).", r.lowerBound, r.upperBound))
                        .font(.subheadline)
                } else {
                    Text("Contact estimate: " + model.frameLabel(time: t)).monospacedDigit()
                    if r.upperBound - r.lowerBound > 1e-6 {
                        Text(String(format: "Possible %.3f–%.3f s (%@)", r.lowerBound, r.upperBound,
                                    c.provenance == "ballAware" ? "football detector and body pose" : "body pose only")).font(.caption).foregroundStyle(.secondary)
                    }
                }
                Button("Go to the Estimate") { go(to: t) }.frame(minHeight: 44)
            } else {
                Text("The automatic analysis didn't establish contact for this video.").font(.subheadline).foregroundStyle(.secondary)
            }
            if let p = c.automaticPlant {
                Text("Plant estimate: " + model.frameLabel(time: p)).font(.subheadline).monospacedDigit()
            } else if !c.isUserAssisted {
                Text("Plant: not established automatically.").font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: Marks

    private func contactSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("First foot–ball contact").font(.headline)
            switch model.annotation {
            case .none: Text("Not marked yet.").foregroundStyle(.secondary)
            case .cannotTell: Text("You couldn't tell which frame shows contact.")
            case .contact(let t):
                Text(model.frameLabel(time: t)).monospacedDigit()
                Text(FrameReview.difference(user: t, automatic: c.automaticTime, what: "estimate", table: model.table)).font(.subheadline)
            }
            Button {
                if let t = currentTime { model.saveFrame(t, app: app) }
            } label: {
                Text("This Frame Is First Contact").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .disabled(currentTime == nil)
            HStack {
                Button("I Can't Tell") { model.saveCannotTell(app: app) }.frame(minHeight: 44)
                Spacer()
                if model.annotation != .none {
                    Button("Clear", role: .destructive) { model.clear(app: app) }.frame(minHeight: 44)
                }
            }
        }
    }

    private func plantAndBallSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Plant and ball movement (optional)").font(.headline)
            markRow(title: "Plant frame", mark: model.verification.plant, automatic: c.automaticPlant, what: "plant",
                    set: { model.markPlant(currentTime, app: app) },
                    cannotTell: { model.markPlant(nil, cannotTell: true, app: app) },
                    clear: { model.markPlant(nil, app: app) })
            markRow(title: "First frame the ball moves", mark: model.verification.firstBallMovement, automatic: c.automaticTime,
                    what: "contact estimate",
                    set: { model.markFirstBallMovement(currentTime, app: app) }, cannotTell: nil,
                    clear: { model.markFirstBallMovement(nil, app: app) })
        }
    }

    private func markRow(title: String, mark: VideoVerification.Mark?, automatic: Double?, what: String,
                         set: @escaping () -> Void, cannotTell: (() -> Void)?, clear: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            switch mark {
            case .none: Text("\(title): not marked").font(.subheadline).foregroundStyle(.secondary)
            case .cannotTell: Text("\(title): you couldn't tell").font(.subheadline)
            case .frame(let t):
                Text("\(title): " + model.frameLabel(time: t)).font(.subheadline).monospacedDigit()
                Text(FrameReview.difference(user: t, automatic: automatic, what: what, table: model.table)).font(.caption)
            }
            HStack {
                Button("Mark This Frame") { set() }.frame(minHeight: 44).disabled(currentTime == nil)
                if let cannotTell { Button("Can't Tell") { cannotTell() }.frame(minHeight: 44) }
                Spacer()
                if mark != nil { Button("Clear", role: .destructive) { clear() }.frame(minHeight: 44) }
            }
        }
    }

    // MARK: Ball movement measured from the frames

    private func ballMeasurementSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Ball movement from the video").font(.headline)
            Text("KickLab can't recognize a football by itself. Mark the ball once (on a frame before the kick) and it measures, frame by frame, when the ball leaves its spot.")
                .font(.caption).foregroundStyle(.secondary)
            if let r = model.verification.ballMotion {
                Text(r.note).font(.subheadline)
                if let t = r.firstDisturbedTime {
                    Text("Ball first disturbed: " + model.frameLabel(time: t)).font(.subheadline).monospacedDigit()
                    Text(FrameReview.difference(user: t, automatic: c.automaticTime, what: "estimate", table: model.table)).font(.caption)
                    Button("Go to That Frame") { go(to: t) }.frame(minHeight: 44)
                }
            }
            Button {
                Task { await model.measureBallMovement(app: app) }
            } label: {
                Label(model.isMeasuringBall ? "Measuring…" : "Measure Ball Movement", systemImage: "scope")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            .disabled(model.verification.ballMark == nil || model.isMeasuringBall)
            if let message = model.message {
                Text(message).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: New analysis from the verified frames

    @ViewBuilder
    private func reanalysisSection(_ c: VerifyContactViewModel.Content) -> some View {
        if let kickID = c.kickID {
            VStack(alignment: .leading, spacing: 8) {
                Text("Analyze with your verified frames").font(.headline)
                if started {
                    let run = app.analysisRun(for: kickID)
                    switch run.state {
                    case .running(_, let fraction): ProgressView(value: fraction) { Text(run.state.stageText ?? "Analyzing") }
                    case .completed(let id):
                        NavigationLink(value: AppRoute.analysis(id)) {
                            Text("View the New Analysis").frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.borderedProminent)
                    case .failed(let problem): Text(problem.message).font(.subheadline)
                    default: ProgressView()
                    }
                } else {
                    Button {
                        started = model.reanalyzeWithVerifiedFrames(app: app)
                    } label: {
                        Text("Reanalyze With Verified Frames").frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .disabled(model.verifiedAssistance() == nil)
                    Text("Creates a NEW analysis labeled user-assisted. This one stays as it is.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }
}

/// Step 12G: tap the ball on a still frame and size the circle to it.
struct BallMarkingSheet: View {
    @Environment(\.dismiss) private var dismiss
    let url: URL
    let time: Double
    let aspect: Double
    let initial: VideoVerification.BallMark?
    let save: (NormalizedPoint, Double) -> Void
    @State private var image: UIImage?
    @State private var point: NormalizedPoint?
    @State private var radius = FrameReview.defaultBallRadius

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Tap the center of the ball that will be kicked, then size the circle to the ball.")
                    .font(.subheadline)
                GeometryReader { geo in
                    let fit = PoseOverlayGeometry.aspectFitRect(containerWidth: geo.size.width, containerHeight: geo.size.height, contentAspect: aspect)
                    ZStack(alignment: .topLeading) {
                        if let image {
                            Image(uiImage: image).resizable().scaledToFit()
                                .frame(width: geo.size.width, height: geo.size.height)
                        } else {
                            ProgressView().frame(width: geo.size.width, height: geo.size.height)
                        }
                        if let point {
                            Circle()
                                .stroke(Color.yellow, lineWidth: 2)
                                .frame(width: 2 * radius * fit.height, height: 2 * radius * fit.height)
                                .position(x: fit.x + point.x * fit.width, y: fit.y + point.y * fit.height)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture(coordinateSpace: .local) { location in
                        if let p = FrameReview.normalizedPoint(tapX: Double(location.x), tapY: Double(location.y),
                                                               containerWidth: Double(geo.size.width), containerHeight: Double(geo.size.height),
                                                               frameAspect: aspect) {
                            point = p
                        }
                    }
                }
                Slider(value: $radius, in: FrameReview.ballRadiusRange)
                    .accessibilityLabel("Ball size")
            }
            .padding()
            .navigationTitle("Mark the Ball")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if let point { save(point, radius) }
                        dismiss()
                    }
                    .disabled(point == nil)
                }
            }
            .task {
                if let initial {
                    point = NormalizedPoint(x: initial.x, y: initial.y)
                    radius = initial.radius
                }
                image = await FrameImageLoader.image(url: url, time: time, crop: nil)
            }
        }
    }
}

/// Step 12G: one real frame of the video at its exact presentation time (no tolerance),
/// optionally cropped at full resolution.
enum FrameImageLoader {
    static func image(url: URL, time: Double, crop: NormalizedRect?) async -> UIImage? {
        #if canImport(AVFoundation) && canImport(UIKit)
        let generator = AVAssetImageGenerator(asset: AVURLAsset(url: url))
        generator.appliesPreferredTrackTransform = true
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        do {
            // A hair after the frame's own timestamp, so this frame (not the previous one)
            // is the one on screen.
            let result = try await generator.image(at: CMTime(seconds: time + 0.001, preferredTimescale: 60_000))
            var cgImage = result.image
            if let crop {
                let w = Double(cgImage.width), h = Double(cgImage.height)
                let rect = CGRect(x: crop.minX * w, y: crop.minY * h, width: crop.width * w, height: crop.height * h).integral
                if let cropped = cgImage.cropping(to: rect) { cgImage = cropped }
            }
            return UIImage(cgImage: cgImage)
        } catch {
            return nil
        }
        #else
        return nil
        #endif
    }
}
