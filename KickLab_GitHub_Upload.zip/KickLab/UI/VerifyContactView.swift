import AVKit
import SwiftUI

/// Step 12F: Verify Contact — step through the original video frame by frame and mark the
/// first frame where the foot touches the ball (or say you can't tell).
struct VerifyContactView: View {
    @Environment(AppModel.self) private var app
    @State private var model: VerifyContactViewModel
    @State private var player: ValidationPlayer?
    @State private var frameIndex = 0

    init(analysisID: UUID) {
        _model = State(initialValue: VerifyContactViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Verify Contact")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
                let start: Double? = {
                    if case .contact(let t) = model.annotation { return t }
                    return model.state.value?.automaticTime
                }()
                if let start { go(to: start) }
            }
            .onDisappear { player?.stop() }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading the video…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Step one frame at a time and choose the FIRST frame where the foot touches the ball. Your answer is kept with the video as a reference; it doesn't change this analysis.")
                        .font(.subheadline)
                    if let player {
                        VideoPlayer(player: player.player)
                            .frame(minHeight: 260)
                        frameControls(player)
                    } else {
                        Text("The video file isn't on this device, so frames can't be shown.").font(.subheadline)
                    }
                    automaticSection(c)
                    answerSection(c)
                    Text("Your answer is never counted as an automatic detection and isn't used to train or tune detection.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding()
            }
        }
    }

    // MARK: Frames

    private func frameControls(_ player: ValidationPlayer) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(model.frameLabel(time: currentTime(player)))
                .font(.headline).monospacedDigit()
                .accessibilityLabel("Current frame")
            HStack(spacing: 12) {
                stepButton(-5, "Back five frames", "chevron.backward.2")
                stepButton(-1, "Back one frame", "chevron.backward")
                Spacer()
                stepButton(1, "Forward one frame", "chevron.forward")
                stepButton(5, "Forward five frames", "chevron.forward.2")
            }
            if model.table.count > 1 {
                Slider(value: Binding(get: { Double(frameIndex) }, set: { go(index: Int($0.rounded())) }),
                       in: 0...Double(model.table.count - 1), step: 1)
                    .accessibilityLabel("Frame")
            }
            if let problem = model.tableProblem {
                Text(problem).font(.caption).foregroundStyle(.secondary)
            } else if model.table.isVariableFrameRate {
                Text("This video has a variable frame rate; frame times shown are the video's own.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func stepButton(_ count: Int, _ label: String, _ symbol: String) -> some View {
        Button { step(count) } label: { Label(label, systemImage: symbol) }
            .labelStyle(.iconOnly)
            .frame(minWidth: 44, minHeight: 44)
            .buttonStyle(.bordered)
    }

    private func currentTime(_ player: ValidationPlayer) -> Double {
        model.table.time(at: frameIndex) ?? player.currentTime
    }

    private func step(_ count: Int) {
        if model.table.isEmpty {
            player?.stepSourceFrame(count)
        } else {
            go(index: frameIndex + count)
        }
    }

    private func go(index: Int) {
        let i = model.table.clamped(index)
        frameIndex = i
        if let t = model.table.time(at: i) { player?.seek(to: t) }
    }

    private func go(to time: Double) {
        if let i = model.table.nearestIndex(to: time) { go(index: i) } else { player?.seek(to: time) }
    }

    // MARK: Automatic estimate

    private func automaticSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Automatic estimate").font(.headline)
            if let t = c.automaticTime {
                Text(model.frameLabel(time: t)).monospacedDigit()
                if let r = c.automaticInterval, r.upperBound - r.lowerBound > 1e-6 {
                    Text(String(format: "Possible range %.3f–%.3f s (%@)", r.lowerBound, r.upperBound,
                                c.provenance == "ballAware" ? "body pose and ball" : "body pose only, no ball tracking"))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Button("Go to Automatic Estimate") { go(to: t) }
                    .frame(minHeight: 44)
            } else if c.isUserAssisted {
                Text("This analysis used a contact frame you chose, so it has no automatic estimate.")
                    .font(.subheadline).foregroundStyle(.secondary)
            } else {
                Text("The automatic analysis didn't establish contact for this video.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: Answer

    private func answerSection(_ c: VerifyContactViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your answer").font(.headline)
            switch model.annotation {
            case .none:
                Text("Not verified yet.").foregroundStyle(.secondary)
            case .cannotTell:
                Text("You couldn't tell which frame shows contact.")
            case .contact(let t):
                Text(model.frameLabel(time: t)).monospacedDigit()
                Text(model.comparison.text).font(.subheadline)
            }
            Button {
                if let player { model.saveFrame(currentTime(player), app: app) }
            } label: {
                Text("This Frame Is First Contact").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .disabled(player == nil)
            HStack {
                Button("I Can't Tell") { model.saveCannotTell(app: app) }
                    .frame(minHeight: 44)
                Spacer()
                if model.annotation != .none {
                    Button("Clear My Answer", role: .destructive) { model.clear(app: app) }
                        .frame(minHeight: 44)
                }
            }
            if let message = model.message {
                Text(message).font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
