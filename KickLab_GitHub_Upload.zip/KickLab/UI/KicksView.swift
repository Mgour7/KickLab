import SwiftUI

/// Sessions and kicks for the selected athlete.
struct KicksView: View {
    @Environment(AppModel.self) private var app
    @State private var model = KicksViewModel()
    @State private var showingKickEntry = false
    @State private var showingSessionEditor = false

    init() {}

    var body: some View {
        content
            .navigationTitle("Kicks")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { AthleteSwitcherMenu() }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { showingKickEntry = true } label: { Label("Log Kick", systemImage: "plus.circle") }
                        Button { showingSessionEditor = true } label: { Label("New Session", systemImage: "calendar.badge.plus") }
                    } label: {
                        Label("Add", systemImage: "plus")
                    }
                }
            }
            .task(id: app.revision) { model.load(app: app) }
            .sheet(isPresented: $showingKickEntry) { KickEntryView(sessionID: nil) }
            .sheet(isPresented: $showingSessionEditor) { SessionEditorView(sessionID: nil) }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let content):
            if content.isEmpty {
                EmptyStateView(
                    title: "No kicks yet",
                    systemImage: "football",
                    message: "Start a session for practice or a game, or log a single kick.",
                    actionTitle: "Log a Kick",
                    action: { showingKickEntry = true }
                )
            } else {
                List {
                    if !content.sessions.isEmpty {
                        Section("Sessions") {
                            ForEach(content.sessions) { session in
                                NavigationLink(value: AppRoute.session(session.id)) {
                                    SessionRow(session: session)
                                }
                            }
                        }
                    }
                    if !content.unassignedKicks.isEmpty {
                        Section("Kicks without a session") {
                            ForEach(content.unassignedKicks) { kick in
                                NavigationLink(value: AppRoute.kick(kick.id)) { KickRow(kick: kick) }
                            }
                        }
                    }
                }
            }
        }
    }
}

struct SessionRow: View {
    let session: SessionRowPresentation

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "calendar")
                .font(.headline)
                .foregroundStyle(KickTheme.brand)
                .frame(width: 40, height: 40)
                .background(RoundedRectangle(cornerRadius: 10).fill(KickTheme.brandSoft))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(session.name).font(.headline)
                HStack(spacing: 4) {
                    Text(session.date, style: .date)
                    Text("·")
                    Text(session.typeText)
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            Text(session.kickCount == 1 ? "1 kick" : "\(session.kickCount) kicks")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(Capsule().fill(Color.secondary.opacity(0.12)))
        }
        .frame(minHeight: 52)
        .accessibilityElement(children: .combine)
    }
}

struct KickRow: View {
    let kick: KickRowPresentation

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: kick.videoCount > 0 ? "video.fill" : "football")
                .font(.subheadline)
                .foregroundStyle(kick.videoCount > 0 ? KickTheme.brand : Color.secondary)
                .frame(width: 40, height: 40)
                .background(RoundedRectangle(cornerRadius: 10).fill(kick.videoCount > 0 ? KickTheme.brandSoft : Color.secondary.opacity(0.12)))
                .accessibilityLabel(kick.videoCount == 0 ? "No video" : (kick.videoCount == 1 ? "1 video" : "\(kick.videoCount) videos"))
            VStack(alignment: .leading, spacing: 2) {
                Text(kick.title).font(.headline)
                Text(kick.detail).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                Text(kick.date, style: .date).font(.caption2).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if let score = kick.scoreText {
                let grade = ScoreGrade(score: Double(score))
                VStack(spacing: 1) {
                    Text(score).font(.headline).monospacedDigit()
                    Text(grade.label).font(.caption2.weight(.semibold))
                }
                .foregroundStyle(grade.color)
                .frame(minWidth: 52)
                .padding(.vertical, 4)
                .background(RoundedRectangle(cornerRadius: 10).fill(grade.color.opacity(0.12)))
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Technique score \(score), \(grade.label)")
            }
        }
        .frame(minHeight: 52)
        .accessibilityElement(children: .combine)
    }
}

/// One session and its kicks.
struct SessionDetailView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: SessionViewModel
    @State private var showingKickEntry = false
    @State private var showingEditor = false
    @State private var confirmingDelete = false

    init(sessionID: UUID) {
        _model = State(initialValue: SessionViewModel(sessionID: sessionID))
    }

    var body: some View {
        content
            .navigationTitle(model.state.value?.session.name ?? "Session")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { showingEditor = true } label: { Label("Edit Session", systemImage: "pencil") }
                        Button(role: .destructive) { confirmingDelete = true } label: { Label("Delete Session", systemImage: "trash") }
                    } label: {
                        Label("More", systemImage: "ellipsis.circle")
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    showingKickEntry = true
                } label: {
                    Label("Log Kick", systemImage: "plus.circle.fill")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .task(id: app.revision) { model.load(app: app) }
            .sheet(isPresented: $showingKickEntry) { KickEntryView(sessionID: model.sessionID) }
            .sheet(isPresented: $showingEditor) { SessionEditorView(sessionID: model.sessionID) }
            .confirmationDialog("Delete this session?", isPresented: $confirmingDelete, titleVisibility: .visible) {
                Button("Delete Session", role: .destructive) {
                    if model.delete(app: app) { dismiss() }
                }
            } message: {
                Text(model.deletionMessage(app: app))
            }
            .alert("Couldn't complete that", isPresented: errorBinding) {
                Button("OK", role: .cancel) { model.errorMessage = nil }
            } message: {
                Text(model.errorMessage ?? "")
            }
    }

    private var errorBinding: Binding<Bool> {
        Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let content):
            List {
                Section {
                    LabeledContent("Date") { Text(content.session.date, style: .date) }
                    LabeledContent("Type", value: content.session.typeText)
                    if let location = content.location {
                        LabeledContent("Location", value: location)
                    }
                    if let notes = content.notes, !notes.isEmpty {
                        Text(notes).font(.subheadline)
                    }
                }
                ForEach(content.performance.sections) { section in
                    Section {
                        if let message = section.emptyMessage { Text(message).foregroundStyle(.secondary) }
                        ForEach(section.rows) { row in
                            LabeledContent {
                                VStack(alignment: .trailing) {
                                    Text(row.value).monospacedDigit()
                                    if let detail = row.detail { Text(detail).font(.caption).foregroundStyle(.secondary) }
                                }
                            } label: { Text(row.title) }
                        }
                    } header: {
                        Text(section.title)
                    } footer: {
                        Text("From the results you entered. Edit a kick to correct it.")
                    }
                }
                Section("Kicks") {
                    if content.kicks.isEmpty {
                        Text("No kicks in this session yet. Tap Log Kick to add one.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(content.kicks) { kick in
                        NavigationLink(value: AppRoute.kick(kick.id)) { KickRow(kick: kick) }
                    }
                }
            }
        }
    }
}

/// Create or edit a session.
struct SessionEditorView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: SessionEditorViewModel?
    let sessionID: UUID?

    init(sessionID: UUID?) {
        self.sessionID = sessionID
    }

    var body: some View {
        NavigationStack {
            Group {
                if let model {
                    SessionEditorForm(model: model)
                } else {
                    LoadingStateView()
                }
            }
            .navigationTitle(sessionID == nil ? "New Session" : "Edit Session")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if model?.save(app: app) != nil { dismiss() }
                    }
                    .disabled(!(model?.canSave ?? false))
                }
            }
        }
        .task {
            if model == nil { model = SessionEditorViewModel(sessionID: sessionID, app: app) }
        }
    }
}

private struct SessionEditorForm: View {
    @Bindable var model: SessionEditorViewModel

    var body: some View {
        Form {
            TextField("Name", text: $model.name)
            DatePicker("Date", selection: $model.date, displayedComponents: [.date])
            Picker("Type", selection: $model.sessionType) {
                ForEach(KickingSessionType.selectableCases, id: \.self) { type in
                    Text(type.displayName).tag(type)
                }
            }
            TextField("Location (optional)", text: $model.location)
            if let error = model.errorMessage {
                Text(error).foregroundStyle(.red)
            }
        }
    }
}
