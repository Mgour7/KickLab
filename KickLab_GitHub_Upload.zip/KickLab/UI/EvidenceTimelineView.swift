import SwiftUI

/// Build 15: the evidence timeline under the debugger's video — ball state per examined
/// frame, kicking-ankle speed, kicking-knee angle, kick window / pose strike / ball-contact
/// bands, plant and ball marks, the fusion verdict, and the playhead. Tap to seek; zoom to
/// 2 s or 0.5 s around the playhead to read single frames on a phone.
struct EvidenceTimelineView: View {
    let model: EvidenceTimelineModel
    let currentTime: Double
    let seek: (Double) -> Void
    @State private var span: Double = 2

    static let spans: [Double] = [0, 2, 0.5]   // 0 = whole clip

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Evidence timeline").font(.headline)
                Spacer()
                Picker("Range", selection: $span) {
                    ForEach(Self.spans, id: \.self) { s in Text(s == 0 ? "Clip" : String(format: "%g s", s)).tag(s) }
                }
                .pickerStyle(.segmented)
                .frame(maxWidth: 200)
            }
            GeometryReader { geometry in
                let width = Double(geometry.size.width)
                let range = model.visibleRange(around: currentTime, span: span == 0 ? nil : span)
                ZStack(alignment: .topLeading) {
                    Rectangle().fill(Color.gray.opacity(0.12)).frame(height: 160)
                    ballLane(range, width)
                    if let s = model.ankleSpeed { seriesPath(s, range, width, top: 26, height: 40).stroke(Color.orange, lineWidth: 1.5) }
                    if let s = model.kneeAngle { seriesPath(s, range, width, top: 70, height: 40).stroke(Color.purple, lineWidth: 1.5) }
                    ForEach(model.bands) { band in
                        let x = EvidenceTimelineModel.fraction(band.start, in: range) * width
                        let w = max(2, EvidenceTimelineModel.fraction(band.end, in: range) * width - x)
                        bandShape(band)
                            .frame(width: CGFloat(w), height: 10)
                            .offset(x: CGFloat(x), y: CGFloat(bandRow(band.kind)))
                    }
                    ForEach(model.marks) { mark in
                        Rectangle().fill(markColor(mark.kind)).opacity(mark.kind == .plantRejected ? 0.5 : 1)
                            .frame(width: 2, height: 160)
                            .offset(x: CGFloat(EvidenceTimelineModel.fraction(mark.time, in: range) * width), y: 0)
                    }
                    Rectangle().fill(Color.primary)
                        .frame(width: 2, height: 168)
                        .offset(x: CGFloat(EvidenceTimelineModel.fraction(currentTime, in: range) * width), y: -4)
                }
                .contentShape(Rectangle())
                .onTapGesture { location in
                    seek(range.lowerBound + Double(location.x) / max(1, width) * (range.upperBound - range.lowerBound))
                }
            }
            .frame(height: 168)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Evidence timeline. " + model.fusionVerdict)
            if let cell = model.ballCells.min(by: { abs($0.time - currentTime) < abs($1.time - currentTime) }), abs(cell.time - currentTime) < 0.02 {
                Text(String(format: "%.3f s: ", cell.time) + cell.label).font(.caption).monospacedDigit()
            }
            Text(model.fusionVerdict).font(.caption)
            ForEach(model.marks.filter { abs($0.time - currentTime) < 0.02 }) { Text($0.label).font(.caption2).foregroundStyle(.secondary) }
            Text("Top row: the ball on each examined frame — green at rest (detected), light green at rest by appearance only, yellow obscured, orange moving, grey another ball, empty = not seen (nothing is filled in). Orange line: kicking-ankle speed; purple: kicking-knee angle. Bands: yellow kick window, blue pose strike window, orange ball-contact interval, red the contact shown. Ticks: cyan plant used, faded grey plant rejected, mint ball last at rest, pink ball first moving.")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private func ballLane(_ range: ClosedRange<Double>, _ width: Double) -> some View {
        let frame = model.ballCells.count > 1 ? (model.ballCells[1].time - model.ballCells[0].time) : 1.0 / 30
        ForEach(model.ballCells.filter { $0.time >= range.lowerBound - frame && $0.time <= range.upperBound + frame }) { cell in
            let x = EvidenceTimelineModel.fraction(cell.time - frame / 2, in: range) * width
            let w = max(1, EvidenceTimelineModel.fraction(cell.time + frame / 2, in: range) * width - x)
            Rectangle().fill(cellColor(cell)).frame(width: CGFloat(max(1, w - 1)), height: 18).offset(x: CGFloat(x), y: 2)
        }
    }

    private func seriesPath(_ s: EvidenceTimelineModel.Series, _ range: ClosedRange<Double>, _ width: Double, top: Double, height: Double) -> Path {
        Path { path in
            var started = false
            for (t, v) in zip(s.times, s.values) {
                guard t >= range.lowerBound, t <= range.upperBound, let v, v.isFinite else { started = false; continue }
                let p = CGPoint(x: EvidenceTimelineModel.fraction(t, in: range) * width, y: top + (1 - s.level(v)) * height)
                if started { path.addLine(to: p) } else { path.move(to: p); started = true }
            }
        }
    }

    @ViewBuilder
    private func bandShape(_ band: EvidenceTimelineModel.Band) -> some View {
        switch band.kind {
        case .kickWindow: Rectangle().fill(Color.yellow.opacity(0.35))
        case .poseStrike: Rectangle().fill(Color.blue.opacity(0.6))
        case .ballContact: Rectangle().fill(Color.orange)
        case .contactShown: Rectangle().stroke(Color.red, lineWidth: 2)
        }
    }

    private func bandRow(_ kind: EvidenceTimelineModel.Band.Kind) -> Double {
        switch kind {
        case .kickWindow: 114
        case .poseStrike: 126
        case .ballContact: 138
        case .contactShown: 150
        }
    }

    private func cellColor(_ c: EvidenceTimelineModel.BallCell) -> Color {
        switch c.state {
        case .atRest: c.source == .tracked ? Color.green.opacity(0.4) : .green
        case .obscured: .yellow
        case .moving: .orange
        case .otherFootball: .gray
        case .notSeen: .clear
        }
    }

    private func markColor(_ k: EvidenceTimelineModel.Mark.Kind) -> Color {
        switch k {
        case .plantAccepted: .cyan
        case .plantRejected: .gray
        case .ballLastAtRest: .mint
        case .ballFirstMovement: .pink
        }
    }
}
