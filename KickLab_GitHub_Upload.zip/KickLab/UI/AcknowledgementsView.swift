import SwiftUI

/// Step 12G: third-party notices (the bundled football detector).
struct AcknowledgementsView: View {
    var body: some View {
        List {
            ForEach(ThirdPartyNotices.entries) { entry in
                Section(entry.name) {
                    Text(entry.detail).font(.footnote)
                }
            }
            Section {
                Text("Apache License 2.0: \(ThirdPartyNotices.apacheLicenseURL)").font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Acknowledgements")
    }
}
