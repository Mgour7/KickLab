import SwiftUI

/// Fast manual kick entry: one screen, sensible defaults, "Save & Add Another".
struct KickEntryView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: KickEntryViewModel
    @State private var confirmation: String?

    /// New kick, optionally in a session.
    init(sessionID: UUID?) {
        _model = State(initialValue: KickEntryViewModel(sessionID: sessionID))
    }

    /// Editing an existing kick.
    init(editing model: KickEntryViewModel) {
        _model = State(initialValue: model)
    }

    var body: some View {
        NavigationStack {
            KickEntryForm_(model: model)
                .navigationTitle(model.isEditing ? "Edit Kick" : "Log Kick")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            if model.save(app: app) != nil { dismiss() }
                        }
                    }
                }
                .safeAreaInset(edge: .bottom) {
                    if !model.isEditing {
                        VStack(spacing: 6) {
                            if let confirmation {
                                Text(confirmation).font(.footnote).foregroundStyle(.secondary)
                            }
                            Button {
                                if model.save(app: app, addAnother: true) != nil {
                                    confirmation = model.savedCount == 1 ? "1 kick saved" : "\(model.savedCount) kicks saved"
                                }
                            } label: {
                                Label("Save & Add Another", systemImage: "plus.circle.fill")
                                    .frame(maxWidth: .infinity, minHeight: 44)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        .padding()
                        .background(.bar)
                    }
                }
        }
    }
}

/// The form body (named with a trailing underscore to avoid clashing with `KickEntryForm`).
private struct KickEntryForm_: View {
    @Bindable var model: KickEntryViewModel

    var body: some View {
        Form {
            Section {
                Picker("Kick type", selection: kickTypeBinding) {
                    ForEach(KickEntryForm.selectableKickTypes, id: \.self) { type in
                        Text(type.displayName).tag(type)
                    }
                }
                .pickerStyle(.segmented)
                DatePicker("When", selection: $model.form.timestamp)
                Picker("Context", selection: $model.form.context) {
                    Text("Session default").tag(KickContext?.none)
                    ForEach(KickContext.selectableCases, id: \.self) { context in
                        Text(context.displayName).tag(KickContext?.some(context))
                    }
                }
            }

            if model.form.showsResult {
                Section("Result") {
                    Picker("Result", selection: $model.form.result) {
                        ForEach(KickEntryForm.selectableResults, id: \.self) { result in
                            Text(result.displayName).tag(result)
                        }
                    }
                    numberField("Distance (yards)", text: $model.form.distanceText)
                    Picker("Hash", selection: $model.form.hash) {
                        ForEach(HashLocation.selectableCases, id: \.self) { hash in
                            Text(hash.displayName).tag(hash)
                        }
                    }
                }
                Section {
                    GoalpostAccuracyPad(accuracy: $model.form.accuracy)
                } header: {
                    Text("Where it crossed")
                } footer: {
                    Text(GoalpostPadGeometry.describe(model.form.accuracy))
                }
            }

            if model.form.showsKickoffFields {
                Section("Kickoff") {
                    numberField("Distance (yards)", text: $model.form.distanceText)
                    Toggle("Touchback", isOn: $model.form.touchback)
                    Toggle("Out of bounds", isOn: $model.form.outOfBounds)
                    numberField("Landing yard line (optional)", text: $model.form.landingYardLineText)
                    Picker("Landing zone", selection: $model.form.landingZone) {
                        Text("Not recorded").tag(LandingZone?.none)
                        ForEach(LandingZone.selectableCases, id: \.self) { zone in
                            Text(zone.displayName).tag(LandingZone?.some(zone))
                        }
                    }
                    numberField("Hang time (seconds)", text: $model.form.hangTimeText)
                }
            }

            if model.form.kickType == .punt {
                Section("Punt") {
                    numberField("Distance (yards)", text: $model.form.distanceText)
                    numberField("Hang time (seconds)", text: $model.form.hangTimeText)
                }
            }

            Section("Notes") {
                TextField("Optional", text: $model.form.notes, axis: .vertical)
                    .lineLimit(1...4)
            }

            if !model.issues.isEmpty || model.errorMessage != nil {
                Section {
                    ForEach(model.issues.map(\.message), id: \.self) { message in
                        Label(message, systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.red)
                    }
                    if let error = model.errorMessage {
                        Label(error, systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.red)
                    }
                }
            }
        }
    }

    private var kickTypeBinding: Binding<KickType> {
        Binding(get: { model.form.kickType }, set: { model.form.setKickType($0) })
    }

    private func numberField(_ title: String, text: Binding<String>) -> some View {
        TextField(title, text: text)
            .keyboardType(.decimalPad)
    }
}

/// Tap where the ball crossed, relative to the uprights.
struct GoalpostAccuracyPad: View {
    @Binding var accuracy: AccuracyCoordinate?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            GeometryReader { proxy in
                let width = Double(proxy.size.width)
                let height = Double(proxy.size.height)
                ZStack {
                    goalpost(width: width, height: height)
                    if let accuracy {
                        let point = GoalpostPadGeometry.point(for: accuracy, width: width, height: height)
                        Circle()
                            .fill(Color.orange)
                            .frame(width: 18, height: 18)
                            .position(x: point.x, y: point.y)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture { location in
                    accuracy = GoalpostPadGeometry.coordinate(
                        x: Double(location.x), y: Double(location.y), width: width, height: height
                    )
                }
            }
            .frame(height: 170)
            .accessibilityElement()
            .accessibilityLabel("Goalpost crossing point")
            .accessibilityValue(GoalpostPadGeometry.describe(accuracy))
            .accessibilityHint("Tap where the ball crossed the goal.")

            if accuracy != nil {
                Button("Clear crossing point", role: .destructive) { accuracy = nil }
                    .font(.footnote)
            }
        }
    }

    private func goalpost(width: Double, height: Double) -> some View {
        let left = GoalpostPadGeometry.point(for: AccuracyCoordinate(x: -1, y: 2), width: width, height: height)
        let right = GoalpostPadGeometry.point(for: AccuracyCoordinate(x: 1, y: 2), width: width, height: height)
        let bar = GoalpostPadGeometry.point(for: AccuracyCoordinate(x: 0, y: 0), width: width, height: height)
        return Path { path in
            path.move(to: CGPoint(x: left.x, y: left.y))
            path.addLine(to: CGPoint(x: left.x, y: bar.y))
            path.addLine(to: CGPoint(x: right.x, y: bar.y))
            path.addLine(to: CGPoint(x: right.x, y: right.y))
            path.move(to: CGPoint(x: width / 2, y: bar.y))
            path.addLine(to: CGPoint(x: width / 2, y: height))
        }
        .stroke(Color.yellow, lineWidth: 4)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.green.opacity(0.15)))
    }
}
