import SwiftUI

/// The mechanics results of one analysis. Build 16: opens on the Quick Report (Performance
/// Report 2.0); "Detailed Analysis" pushes the full breakdown (score, personalized coaching,
/// categories, comparisons, metrics and video); Developer Diagnostics stay in the toolbar
/// behind the diagnostics setting.
struct AnalysisResultsView: View {
    enum Level: Hashable { case quick, detailed }
    let level: Level
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisResultsViewModel
    @State private var showingVideo = false
    @State private var showingComparisonPicker = false
    @State private var confirmingDelete = false
    @Environment(\.dismiss) private var dismiss

    init(analysisID: UUID, level: Level = .quick) {
        self.level = level
        _model = State(initialValue: AnalysisResultsViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle(level == .quick ? "Kick Report" : "Detailed Analysis")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if app.showsAnalysisDiagnostics {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(value: AppRoute.diagnostics(model.analysisID)) {
                            Label("Diagnostics", systemImage: "stethoscope")
                        }
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(value: AppRoute.poseValidation(model.analysisID)) {
                            Label("Pose Validation", systemImage: "figure.walk.motion")
                        }
                    }
                }
            }
            .task(id: app.revision) {
                model.load(app: app)
                await model.loadSnapshot(app: app)
                await model.loadVideo(app: app)
            }
            .sheet(isPresented: $showingVideo) {
                if let url = model.videoURL {
                    VideoPlayerSheet(url: url, markers: model.phaseMarkers)
                }
            }
            .confirmationDialog("Delete this analysis?", isPresented: $confirmingDelete, titleVisibility: .visible) {
                Button("Delete Analysis", role: .destructive) {
                    if model.deleteAnalysis(app: app) { dismiss() }
                }
            } message: {
                Text("Its results, its files and any contact frame chosen for it are deleted. The kick, its video (including your Photos library) and other analyses stay.")
            }
            .alert("Couldn't complete that", isPresented: deletionErrorBinding) {
                Button("OK", role: .cancel) { model.deletionError = nil }
            } message: {
                Text(model.deletionError ?? "")
            }
    }

    private var deletionErrorBinding: Binding<Bool> {
        Binding(get: { model.deletionError != nil }, set: { if !$0 { model.deletionError = nil } })
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let c):
            if level == .quick {
                quickContent(c)
            } else {
                detailedContent(c)
            }
        }
    }

    /// Build 18, level 1: the Quick Report (Athlete Report 3.0). Falls back to the classic
    /// header if the report couldn't be built (never touches the saved analysis).
    private func quickContent(_ c: AnalysisResultsViewModel.Content) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let report = model.performance {
                    QuickReportView(report: report)
                } else {
                    ResultsHeaderView(header: c.presentation.header)
                }
                if model.assistanceOffer == .chooseContact {
                    NavigationLink(value: AppRoute.verifyContact(model.analysisID)) {
                        Label("Verify contact", systemImage: "scope").font(.subheadline)
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                }
                HStack(spacing: 10) {
                    if model.videoURL != nil {
                        Button {
                            showingVideo = true
                        } label: {
                            Label("Review Video", systemImage: "play.rectangle").font(.subheadline)
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.bordered)
                    }
                    NavigationLink(value: AppRoute.detailedAnalysis(model.analysisID)) {
                        Label("Detailed Analysis", systemImage: "list.bullet.rectangle").font(.subheadline)
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .accessibilityHint("Every measurement by phase, contact quality, coaching evidence and history")
                }
                // Clears the tab bar so the last card is never hidden behind it.
                Color.clear.frame(height: 72).accessibilityHidden(true)
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
    }

    /// Build 18, level 2: Detailed Analysis — by phase in expandable sections, then the
    /// kick timeline, actions, personal coaching, comparisons and analysis management.
    /// Each piece of information appears once.
    @ViewBuilder
    private func detailedContent(_ c: AnalysisResultsViewModel.Content) -> some View {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let problem = c.presentation.problem {
                        CardView {
                            Label(problem, systemImage: "info.circle").font(.subheadline)
                        }
                    }
                    if let detailed = model.detailed {
                        DetailedBreakdownView(detailed: detailed)
                    } else {
                        ResultsHeaderView(header: c.presentation.header)
                    }
                    if let report = model.report {
                        DisclosureGroup("Kick timeline and contact") {
                            reportOverview(report).padding(.top, 4)
                        }
                        .font(.headline)
                    }
                    if model.assistanceOffer != .none, let kickID = c.record.kickID {
                        CardView {
                            Text(model.assistanceOffer.title).font(.headline)
                            Text(model.assistanceOffer.message).font(.subheadline).foregroundStyle(.secondary)
                            if model.assistanceOffer == .chooseContact {
                                NavigationLink(value: AppRoute.verifyContact(model.analysisID)) {
                                    Label("Verify Contact (frames or ball)", systemImage: "scope")
                                        .frame(maxWidth: .infinity, minHeight: 44)
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            NavigationLink(value: model.assistanceOffer == .chooseKick
                                           ? AppRoute.assistKick(kick: kickID, analysis: model.analysisID)
                                           : AppRoute.assistContact(kick: kickID, analysis: model.analysisID)) {
                                Text(model.assistanceOffer == .chooseKick ? "Choose the Kick" : "Reanalyze With Manual Contact")
                                    .frame(maxWidth: .infinity, minHeight: 44)
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    if !model.suitability.isEmpty {
                        DisclosureGroup("Recording notes (\(model.suitability.count))") {
                            VStack(alignment: .leading, spacing: 6) {
                                ForEach(model.suitability) { finding in
                                    Label(finding.message, systemImage: finding.severity == .blocking ? "exclamationmark.triangle" : "lightbulb")
                                        .font(.subheadline)
                                }
                            }
                            .padding(.top, 4)
                        }
                        .font(.headline)
                    }
                    videoCard
                    if c.presentation.hasMechanics {
                        if let coach = c.coach, model.report?.suppressedContactAdvice != true {
                            DisclosureGroup("Personal coaching") {
                                CoachSectionView(coach: coach, snapshotNote: model.snapshotNote).padding(.top, 4)
                            }
                            .font(.headline)
                        }
                        let insightAreas = model.performance?.insights.filter(\.isImprovement).map(\.category) ?? []
                        if !insightAreas.isEmpty {
                            DisclosureGroup("Suggested drills") {
                                DrillSuggestionsView(categories: insightAreas, kickType: c.record.kickType).padding(.top, 4)
                            }
                            .font(.headline)
                        }
                        DisclosureGroup("Compare with another kick") {
                            comparisonsSection(c).padding(.top, 4)
                        }
                        .font(.headline)
                    }
                    if let kickID = c.record.kickID {
                        reanalysisSection(kickID: kickID)
                    }
                    NavigationLink(value: AppRoute.kickHistory(c.record.kickID ?? c.record.id)) {
                        Label("All analyses of this kick", systemImage: "clock.arrow.circlepath")
                    }
                    .disabled(c.record.kickID == nil)
                    if app.showsAnalysisDiagnostics {
                        NavigationLink(value: AppRoute.diagnostics(model.analysisID)) {
                            Label("Developer diagnostics and evidence export", systemImage: "stethoscope")
                        }
                        NavigationLink(value: AppRoute.poseValidation(model.analysisID)) {
                            Label("Visual evidence (Pose Validation)", systemImage: "figure.walk.motion")
                        }
                    }
                    Button(role: .destructive) {
                        confirmingDelete = true
                    } label: {
                        Label("Delete Analysis", systemImage: "trash")
                    }
                    .frame(minHeight: 44)
                    Color.clear.frame(height: 72).accessibilityHidden(true)
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
            }
            .sheet(isPresented: $showingComparisonPicker) {
                EarlierKickPicker(entries: c.earlierKicks) { entry in
                    model.compare(with: entry, app: app)
                    showingComparisonPicker = false
                }
            }
    }

    // MARK: Step 12F coaching report

    private func reportOverview(_ report: CoachingReportOverview) -> some View {
        CardView {
            Text("Coaching report").font(.title3.bold())
            ForEach(report.items) { item in
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(item.number). \(item.title)").font(.headline)
                    ForEach(item.lines, id: \.self) { line in
                        Text(line).font(.subheadline)
                    }
                    if item.number == 4 {
                        NavigationLink(value: AppRoute.verifyContact(model.analysisID)) {
                            Label("Verify Contact", systemImage: "scope")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }
            NavigationLink(value: AppRoute.captureGuide) {
                Label("How to film the next kick", systemImage: "video.badge.checkmark")
            }
            .font(.subheadline)
        }
    }

    /// The explicit reanalysis actions. Each creates a NEW analysis; this one is kept.
    private func reanalysisSection(kickID: UUID) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Reanalyze").font(.title3.bold())
            NavigationLink(value: AppRoute.reanalyzeAutomatically(kickID)) {
                Label("Reanalyze Automatically", systemImage: "arrow.clockwise")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            NavigationLink(value: AppRoute.assistContact(kick: kickID, analysis: model.analysisID)) {
                Label("Reanalyze With Manual Contact", systemImage: "hand.tap")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            Text("Automatic reanalysis runs the current engine on the original video and never uses a contact frame chosen before.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var videoCard: some View {
        if model.videoURL != nil {
            Button {
                showingVideo = true
            } label: {
                Label("Review video", systemImage: "play.rectangle")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            if let message = model.phasesMessage {
                Text(message).font(.caption).foregroundStyle(.secondary)
            }
        } else {
            Text("The analyzed video isn't on this device.").font(.caption).foregroundStyle(.secondary)
        }
    }

    private func comparisonsSection(_ c: AnalysisResultsViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Comparisons").font(.title3.bold())
            ComparisonCardView(comparison: c.baselineComparison)
            ComparisonCardView(comparison: c.previousAnalysis)
            if let selected = model.selectedComparison {
                ComparisonCardView(comparison: selected)
            }
            if !c.earlierKicks.isEmpty {
                Button("Compare with an earlier kick") { showingComparisonPicker = true }
                    .frame(minHeight: 44)
            }
        }
    }

}

struct ResultsHeaderView: View {
    let header: AnalysisHeaderPresentation

    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            ScoreBadge(scoreText: header.overallScoreText, grade: header.grade, caption: "Overall", gradeText: header.gradeText)
            VStack(alignment: .leading, spacing: 4) {
                Text(header.kickTypeText).font(.title2.bold())
                Text(header.date, style: .date).font(.subheadline).foregroundStyle(.secondary)
                Label(header.statusText, systemImage: header.isCurrent ? "star.fill" : "clock")
                    .font(.subheadline)
                if let outcome = header.outcome {
                    Label(outcome.title, systemImage: Self.symbol(outcome))
                        .font(.subheadline.weight(.semibold))
                    Text(outcome.explanation).font(.caption).foregroundStyle(.secondary)
                }
                Label(header.mode.title, systemImage: header.mode == .userAssisted ? "hand.tap" : "gearshape")
                    .font(.caption)
                ConfidenceText(text: header.confidenceText, confidence: header.confidence)
            }
        }
        .accessibilityElement(children: .combine)
    }

    static func symbol(_ outcome: AnalysisOutcome) -> String {
        switch outcome {
        case .fullySupported: "checkmark.seal"
        case .partialMeasurements: "chart.bar.doc.horizontal"
        case .kickDetectedTimingUncertain: "clock.badge.questionmark"
        case .insufficientEvidence: "eye.slash"
        case .noKickDetected: "figure.stand"
        case .technicalFailure: "exclamationmark.triangle"
        }
    }
}

/// Top priorities (with cues) and strengths.
struct CoachingSectionView: View {
    let priorities: [CoachingItemPresentation]
    let strengths: [CoachingItemPresentation]
    /// Step 12C: says when "no corrections" rests on partial or low-confidence evidence.
    var noCorrectionsDetail = "KickLab only suggests a change when it measured the evidence confidently."

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Coaching").font(.title3.bold())
            if priorities.isEmpty {
                CardView {
                    Text("No corrections flagged.").font(.headline)
                    Text(noCorrectionsDetail)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            ForEach(priorities) { item in
                CoachingItemView(item: item, isStrength: false)
            }
            if !strengths.isEmpty {
                Text("Strengths").font(.headline)
                ForEach(strengths) { item in
                    CoachingItemView(item: item, isStrength: true)
                }
            }
        }
    }
}

struct CoachingItemView: View {
    let item: CoachingItemPresentation
    let isStrength: Bool

    var body: some View {
        CardView {
            HStack {
                Label(item.categoryTitle, systemImage: isStrength ? "hand.thumbsup" : "target")
                    .font(.caption.weight(.semibold))
                Spacer()
                if let severity = item.severityText {
                    Text(severity).font(.caption.weight(.semibold))
                }
            }
            Text(item.observed).font(.headline)
            if let why = item.whyItMatters {
                Text(why).font(.subheadline).foregroundStyle(.secondary)
            }
            if let cue = item.cue {
                Label(cue, systemImage: "quote.bubble.fill")
                    .font(.subheadline.weight(.semibold))
            }
            ConfidenceText(text: item.confidenceText, confidence: item.confidence)
        }
        .accessibilityElement(children: .combine)
    }
}

struct CategoryCardView: View {
    let card: CategoryCardPresentation

    var body: some View {
        CardView {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(card.title).font(.headline)
                    ConfidenceText(text: card.confidenceText, confidence: card.confidence)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text(card.scoreText).font(.title2.bold()).monospacedDigit()
                    Text(card.gradeText).font(.caption)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(card.topMetrics) { metric in
                HStack {
                    Text(metric.name).font(.subheadline)
                    Spacer()
                    Text(metric.valueText).font(.subheadline.weight(.semibold)).monospacedDigit()
                }
                .accessibilityElement(children: .combine)
            }
            if !card.unavailableMetricNames.isEmpty {
                Text("Not measured this time: " + card.unavailableMetricNames.joined(separator: ", "))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

/// Every metric with value, unit, status and confidence.
struct MetricsListView: View {
    let metrics: [MetricRowPresentation]
    @State private var expanded = false

    init(metrics: [MetricRowPresentation]) {
        self.metrics = metrics
    }

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(metrics) { metric in
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text(metric.name).font(.subheadline.weight(.semibold))
                            Spacer()
                            Text(metric.valueText).font(.subheadline).monospacedDigit()
                        }
                        Text((metric.provenanceText.isEmpty ? metric.statusText : metric.provenanceText) + " · " + metric.confidenceText)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(metric.explanation)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
            .padding(.top, 8)
        } label: {
            Text("All measurements").font(.title3.bold())
        }
    }
}

/// General target vs. your baseline, your successful kicks and your trend.
struct PersonalReferencesView: View {
    let insights: PersonalInsights
    let references: [MetricReferencePresentation]
    @State private var expanded = false

    init(insights: PersonalInsights, references: [MetricReferencePresentation]) {
        self.insights = insights
        self.references = references
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your references").font(.title3.bold())
            if !insights.baselineAvailability.isAvailable {
                Label(PersonalInsights.baselineNeededMessage, systemImage: "person.badge.clock")
                    .font(.subheadline)
            }
            Text(insights.methodDescription).font(.caption).foregroundStyle(.secondary)
            DisclosureGroup("Compare each measurement", isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 14) {
                    ForEach(references) { reference in
                        ReferenceRow(reference: reference)
                    }
                }
                .padding(.top, 8)
            }
        }
    }
}

private struct ReferenceRow: View {
    let reference: MetricReferencePresentation

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(reference.name).font(.subheadline.weight(.semibold))
                Spacer()
                Text(reference.currentText).font(.subheadline).monospacedDigit()
            }
            line("General technique target", reference.generalTarget, fallback: "No target for this measurement")
            line("Your baseline", reference.baseline, fallback: reference.baselineMessage)
            line("Your best kicks", reference.bestKicks, fallback: reference.bestKicksMessage)
            line("Your recent trend", reference.trend, fallback: reference.trendMessage)
        }
        .accessibilityElement(children: .combine)
    }

    private func line(_ title: String, _ value: String?, fallback: String?) -> some View {
        HStack(alignment: .top) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Spacer()
            Text(value ?? fallback ?? DisplayFormat.missing)
                .font(.caption)
                .multilineTextAlignment(.trailing)
        }
    }
}

struct ComparisonCardView: View {
    let comparison: ComparisonPresentation

    var body: some View {
        CardView {
            Text(comparison.target.title).font(.headline)
            if let message = comparison.emptyMessage {
                Text(message).font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(comparison.rows) { row in
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(row.name).font(.subheadline)
                        Spacer()
                        Text(row.directionText).font(.subheadline.weight(.semibold))
                    }
                    Text("\(row.referenceText) → \(row.currentText) (\(row.differenceText))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }
}

struct EarlierKickPicker: View {
    @Environment(\.dismiss) private var dismiss
    let entries: [KickHistoryEntry]
    let onPick: (KickHistoryEntry) -> Void

    init(entries: [KickHistoryEntry], onPick: @escaping (KickHistoryEntry) -> Void) {
        self.entries = entries
        self.onPick = onPick
    }

    var body: some View {
        NavigationStack {
            List(entries) { entry in
                Button {
                    onPick(entry)
                } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(entry.kickType.displayName).font(.headline)
                            Text(entry.date, style: .date).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(DisplayFormat.score(entry.overallScore)).font(.headline).monospacedDigit()
                    }
                    .frame(minHeight: 44)
                }
            }
            .navigationTitle("Earlier Kicks")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
        }
    }
}

/// Analyses of a kick or of the athlete, newest first; the current one is marked and
/// older ones are kept.
struct AnalysisHistoryView: View {
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisHistoryViewModel

    init(scope: AnalysisHistoryViewModel.Scope) {
        _model = State(initialValue: AnalysisHistoryViewModel(scope: scope))
    }

    var body: some View {
        content
            .navigationTitle("Analysis History")
            .task(id: app.revision) { model.load(app: app) }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let records):
            if records.isEmpty {
                EmptyStateView(title: "No analyses yet", systemImage: "clock",
                               message: "Analyze a kick with video to start your history.")
            } else {
                List(records) { record in
                    NavigationLink(value: AppRoute.analysis(record.id)) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(record.kickType.displayName).font(.headline)
                                Text(record.date, style: .date).font(.caption).foregroundStyle(.secondary)
                                Text(AnalysisPresentationBuilder.statusText(record))
                                    .font(.caption.weight(record.isCurrent ? .semibold : .regular))
                                Text(AnalysisAssistanceLabel.isAssisted(record.engineVersion) ? "User-assisted · \(record.engineVersion)" : "Automatic · \(record.engineVersion)")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if record.isCurrent {
                                Image(systemName: "star.fill").accessibilityLabel("Current analysis")
                            }
                            Text(DisplayFormat.score(record.overallScore)).font(.headline).monospacedDigit()
                        }
                        .frame(minHeight: 44)
                        .accessibilityElement(children: .combine)
                    }
                }
            }
        }
    }
}
