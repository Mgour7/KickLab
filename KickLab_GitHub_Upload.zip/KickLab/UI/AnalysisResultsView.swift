import SwiftUI

/// The mechanics results of one analysis: score, personalized coaching, categories,
/// comparisons, metrics and video.
struct AnalysisResultsView: View {
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisResultsViewModel
    @State private var showingVideo = false
    @State private var showingComparisonPicker = false

    init(analysisID: UUID) {
        _model = State(initialValue: AnalysisResultsViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Results")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if app.showsAnalysisDiagnostics {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(value: AppRoute.diagnostics(model.analysisID)) {
                            Label("Diagnostics", systemImage: "stethoscope")
                        }
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(value: AppRoute.poseValidation(model.analysisID)) {
                            Label("Pose Validation", systemImage: "figure.walk.motion")
                        }
                    }
                }
            }
            .task(id: app.revision) {
                model.load(app: app)
                await model.loadSnapshot(app: app)
                await model.loadVideo(app: app)
            }
            .sheet(isPresented: $showingVideo) {
                if let url = model.videoURL {
                    VideoPlayerSheet(url: url, markers: model.phaseMarkers)
                }
            }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ResultsHeaderView(header: c.presentation.header)
                    if let problem = c.presentation.problem {
                        CardView {
                            Label(problem, systemImage: "info.circle").font(.subheadline)
                        }
                    }
                    videoCard
                    if c.presentation.hasMechanics {
                        if let coach = c.coach {
                            CoachSectionView(coach: coach, snapshotNote: model.snapshotNote)
                        } else {
                            CoachingSectionView(priorities: c.presentation.priorities, strengths: c.presentation.strengths,
                                                noCorrectionsDetail: c.presentation.noCorrectionsDetail)
                        }
                        categoriesSection(c.presentation.categories)
                        comparisonsSection(c)
                        MetricsListView(metrics: c.presentation.metrics)
                    } else if c.presentation.problem == nil {
                        EmptyStateView(title: "No measurements", systemImage: "ruler",
                                       message: "Not enough of the kick was visible to measure its mechanics.")
                    }
                    notesSection(c.presentation.notes)
                    NavigationLink(value: AppRoute.kickHistory(c.record.kickID ?? c.record.id)) {
                        Label("All analyses of this kick", systemImage: "clock.arrow.circlepath")
                    }
                    .disabled(c.record.kickID == nil)
                }
                .padding()
            }
            .sheet(isPresented: $showingComparisonPicker) {
                EarlierKickPicker(entries: c.earlierKicks) { entry in
                    model.compare(with: entry, app: app)
                    showingComparisonPicker = false
                }
            }
        }
    }

    @ViewBuilder
    private var videoCard: some View {
        if model.videoURL != nil {
            Button {
                showingVideo = true
            } label: {
                Label("Review video", systemImage: "play.rectangle")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            if let message = model.phasesMessage {
                Text(message).font(.caption).foregroundStyle(.secondary)
            }
        } else {
            Text("The analyzed video isn't on this device.").font(.caption).foregroundStyle(.secondary)
        }
    }

    private func categoriesSection(_ categories: [CategoryCardPresentation]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mechanics by phase").font(.title3.bold())
            ForEach(categories) { card in
                CategoryCardView(card: card)
            }
        }
    }

    private func comparisonsSection(_ c: AnalysisResultsViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Comparisons").font(.title3.bold())
            ComparisonCardView(comparison: c.baselineComparison)
            ComparisonCardView(comparison: c.previousAnalysis)
            if let selected = model.selectedComparison {
                ComparisonCardView(comparison: selected)
            }
            if !c.earlierKicks.isEmpty {
                Button("Compare with an earlier kick") { showingComparisonPicker = true }
                    .frame(minHeight: 44)
            }
        }
    }

    private func notesSection(_ notes: [String]) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(notes, id: \.self) { note in
                Label(note, systemImage: "info.circle")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct ResultsHeaderView: View {
    let header: AnalysisHeaderPresentation

    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            ScoreBadge(scoreText: header.overallScoreText, grade: header.grade, caption: "Overall", gradeText: header.gradeText)
            VStack(alignment: .leading, spacing: 4) {
                Text(header.kickTypeText).font(.title2.bold())
                Text(header.date, style: .date).font(.subheadline).foregroundStyle(.secondary)
                Label(header.statusText, systemImage: header.isCurrent ? "star.fill" : "clock")
                    .font(.subheadline)
                ConfidenceText(text: header.confidenceText, confidence: header.confidence)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

/// Top priorities (with cues) and strengths.
struct CoachingSectionView: View {
    let priorities: [CoachingItemPresentation]
    let strengths: [CoachingItemPresentation]
    /// Step 12C: says when "no corrections" rests on partial or low-confidence evidence.
    var noCorrectionsDetail = "KickLab only suggests a change when it measured the evidence confidently."

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Coaching").font(.title3.bold())
            if priorities.isEmpty {
                CardView {
                    Text("No corrections flagged.").font(.headline)
                    Text(noCorrectionsDetail)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            ForEach(priorities) { item in
                CoachingItemView(item: item, isStrength: false)
            }
            if !strengths.isEmpty {
                Text("Strengths").font(.headline)
                ForEach(strengths) { item in
                    CoachingItemView(item: item, isStrength: true)
                }
            }
        }
    }
}

struct CoachingItemView: View {
    let item: CoachingItemPresentation
    let isStrength: Bool

    var body: some View {
        CardView {
            HStack {
                Label(item.categoryTitle, systemImage: isStrength ? "hand.thumbsup" : "target")
                    .font(.caption.weight(.semibold))
                Spacer()
                if let severity = item.severityText {
                    Text(severity).font(.caption.weight(.semibold))
                }
            }
            Text(item.observed).font(.headline)
            if let why = item.whyItMatters {
                Text(why).font(.subheadline).foregroundStyle(.secondary)
            }
            if let cue = item.cue {
                Label(cue, systemImage: "quote.bubble.fill")
                    .font(.subheadline.weight(.semibold))
            }
            ConfidenceText(text: item.confidenceText, confidence: item.confidence)
        }
        .accessibilityElement(children: .combine)
    }
}

struct CategoryCardView: View {
    let card: CategoryCardPresentation

    var body: some View {
        CardView {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(card.title).font(.headline)
                    ConfidenceText(text: card.confidenceText, confidence: card.confidence)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text(card.scoreText).font(.title2.bold()).monospacedDigit()
                    Text(card.gradeText).font(.caption)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(card.topMetrics) { metric in
                HStack {
                    Text(metric.name).font(.subheadline)
                    Spacer()
                    Text(metric.valueText).font(.subheadline.weight(.semibold)).monospacedDigit()
                }
                .accessibilityElement(children: .combine)
            }
            if !card.unavailableMetricNames.isEmpty {
                Text("Not measured this time: " + card.unavailableMetricNames.joined(separator: ", "))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

/// Every metric with value, unit, status and confidence.
struct MetricsListView: View {
    let metrics: [MetricRowPresentation]
    @State private var expanded = false

    init(metrics: [MetricRowPresentation]) {
        self.metrics = metrics
    }

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(metrics) { metric in
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text(metric.name).font(.subheadline.weight(.semibold))
                            Spacer()
                            Text(metric.valueText).font(.subheadline).monospacedDigit()
                        }
                        Text(metric.statusText + " · " + metric.confidenceText)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(metric.explanation)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
            .padding(.top, 8)
        } label: {
            Text("All measurements").font(.title3.bold())
        }
    }
}

/// General target vs. your baseline, your successful kicks and your trend.
struct PersonalReferencesView: View {
    let insights: PersonalInsights
    let references: [MetricReferencePresentation]
    @State private var expanded = false

    init(insights: PersonalInsights, references: [MetricReferencePresentation]) {
        self.insights = insights
        self.references = references
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your references").font(.title3.bold())
            if !insights.baselineAvailability.isAvailable {
                Label(PersonalInsights.baselineNeededMessage, systemImage: "person.badge.clock")
                    .font(.subheadline)
            }
            Text(insights.methodDescription).font(.caption).foregroundStyle(.secondary)
            DisclosureGroup("Compare each measurement", isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 14) {
                    ForEach(references) { reference in
                        ReferenceRow(reference: reference)
                    }
                }
                .padding(.top, 8)
            }
        }
    }
}

private struct ReferenceRow: View {
    let reference: MetricReferencePresentation

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(reference.name).font(.subheadline.weight(.semibold))
                Spacer()
                Text(reference.currentText).font(.subheadline).monospacedDigit()
            }
            line("General technique target", reference.generalTarget, fallback: "No target for this measurement")
            line("Your baseline", reference.baseline, fallback: reference.baselineMessage)
            line("Your best kicks", reference.bestKicks, fallback: reference.bestKicksMessage)
            line("Your recent trend", reference.trend, fallback: reference.trendMessage)
        }
        .accessibilityElement(children: .combine)
    }

    private func line(_ title: String, _ value: String?, fallback: String?) -> some View {
        HStack(alignment: .top) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Spacer()
            Text(value ?? fallback ?? DisplayFormat.missing)
                .font(.caption)
                .multilineTextAlignment(.trailing)
        }
    }
}

struct ComparisonCardView: View {
    let comparison: ComparisonPresentation

    var body: some View {
        CardView {
            Text(comparison.target.title).font(.headline)
            if let message = comparison.emptyMessage {
                Text(message).font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(comparison.rows) { row in
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(row.name).font(.subheadline)
                        Spacer()
                        Text(row.directionText).font(.subheadline.weight(.semibold))
                    }
                    Text("\(row.referenceText) → \(row.currentText) (\(row.differenceText))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }
}

struct EarlierKickPicker: View {
    @Environment(\.dismiss) private var dismiss
    let entries: [KickHistoryEntry]
    let onPick: (KickHistoryEntry) -> Void

    init(entries: [KickHistoryEntry], onPick: @escaping (KickHistoryEntry) -> Void) {
        self.entries = entries
        self.onPick = onPick
    }

    var body: some View {
        NavigationStack {
            List(entries) { entry in
                Button {
                    onPick(entry)
                } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(entry.kickType.displayName).font(.headline)
                            Text(entry.date, style: .date).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(DisplayFormat.score(entry.overallScore)).font(.headline).monospacedDigit()
                    }
                    .frame(minHeight: 44)
                }
            }
            .navigationTitle("Earlier Kicks")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
        }
    }
}

/// Analyses of a kick or of the athlete, newest first; the current one is marked and
/// older ones are kept.
struct AnalysisHistoryView: View {
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisHistoryViewModel

    init(scope: AnalysisHistoryViewModel.Scope) {
        _model = State(initialValue: AnalysisHistoryViewModel(scope: scope))
    }

    var body: some View {
        content
            .navigationTitle("Analysis History")
            .task(id: app.revision) { model.load(app: app) }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let records):
            if records.isEmpty {
                EmptyStateView(title: "No analyses yet", systemImage: "clock",
                               message: "Analyze a kick with video to start your history.")
            } else {
                List(records) { record in
                    NavigationLink(value: AppRoute.analysis(record.id)) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(record.kickType.displayName).font(.headline)
                                Text(record.date, style: .date).font(.caption).foregroundStyle(.secondary)
                                Text(AnalysisPresentationBuilder.statusText(record))
                                    .font(.caption.weight(record.isCurrent ? .semibold : .regular))
                            }
                            Spacer()
                            if record.isCurrent {
                                Image(systemName: "star.fill").accessibilityLabel("Current analysis")
                            }
                            Text(DisplayFormat.score(record.overallScore)).font(.headline).monospacedDigit()
                        }
                        .frame(minHeight: 44)
                        .accessibilityElement(children: .combine)
                    }
                }
            }
        }
    }
}
