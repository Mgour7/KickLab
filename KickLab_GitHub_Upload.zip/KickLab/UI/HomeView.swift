import SwiftUI

struct HomeView: View {
    @Binding var selectedTab: AppTab
    @Environment(AppModel.self) private var app
    @State private var model = HomeViewModel()
    @State private var showingKickEntry = false
    @State private var showingSessionEditor = false

    init(selectedTab: Binding<AppTab>) {
        _selectedTab = selectedTab
    }

    var body: some View {
        content
            .navigationTitle(app.selectedAthlete?.name ?? "KickLab")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { AthleteSwitcherMenu() }
            }
            .task(id: app.revision) { model.load(app: app) }
            .sheet(isPresented: $showingKickEntry) {
                KickEntryView(sessionID: nil)
            }
            .sheet(isPresented: $showingSessionEditor) {
                SessionEditorView(sessionID: nil)
            }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let dashboard):
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header(dashboard)
                    quickActions
                    if dashboard.isEmpty {
                        EmptyStateView(title: "No kicks yet", systemImage: "football",
                                       message: DashboardPresentation.noKicksMessage)
                    } else {
                        statsGrid(dashboard)
                        mechanicsCard(dashboard)
                        trendCard(dashboard)
                        activityCard(dashboard)
                    }
                }
                .padding()
            }
        }
    }

    private func header(_ d: DashboardPresentation) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(d.athleteName).font(.title2.bold())
            Text(d.kickingFootText).font(.subheadline).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private var quickActions: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                quickAction("Log Kick", systemImage: "plus.circle") { showingKickEntry = true }
                quickAction("Start Session", systemImage: "calendar.badge.plus") { showingSessionEditor = true }
            }
            HStack(spacing: 10) {
                quickAction("Add Video", systemImage: "video.badge.plus") { selectedTab = .kicks }
                quickAction("Analyze", systemImage: "figure.run") { selectedTab = .analyze }
            }
        }
    }

    private func quickAction(_ title: String, systemImage: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .frame(maxWidth: .infinity, minHeight: 44)
        }
        .buttonStyle(.bordered)
    }

    private func statsGrid(_ d: DashboardPresentation) -> some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            ForEach(d.stats) { stat in
                StatTileView(title: stat.title, value: stat.value, detail: stat.detail)
            }
        }
    }

    private func mechanicsCard(_ d: DashboardPresentation) -> some View {
        CardView {
            Text("Latest mechanics").font(.headline)
            if let score = d.latestScoreText {
                HStack(alignment: .top, spacing: 16) {
                    ScoreBadge(scoreText: score, grade: d.latestScoreGrade)
                    VStack(alignment: .leading, spacing: 6) {
                        if let detail = d.latestScoreDetail {
                            Text(detail).font(.subheadline).foregroundStyle(.secondary)
                        }
                        if let priority = d.topPriority {
                            Text("Top priority").font(.caption.weight(.semibold))
                            Text(priority.observed).font(.subheadline)
                            if let cue = priority.cue {
                                Label(cue, systemImage: "quote.bubble").font(.subheadline)
                            }
                        } else {
                            Text("No corrections flagged from what the latest analysis could measure.").font(.subheadline)
                        }
                    }
                }
            } else {
                Text(d.analysisEmptyMessage ?? DashboardPresentation.noAnalysisMessage)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func trendCard(_ d: DashboardPresentation) -> some View {
        CardView {
            Text("Last 30 days vs. the 30 before").font(.headline)
            if d.trend.isEmpty {
                Text(d.trendEmptyMessage ?? DashboardPresentation.noTrendMessage)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(d.trend) { item in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(item.title).font(.subheadline)
                            Text("\(item.previous) → \(item.current)").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(item.directionText).font(.subheadline.weight(.semibold))
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    private func activityCard(_ d: DashboardPresentation) -> some View {
        CardView {
            Text("Recent activity").font(.headline)
            ForEach(d.recentActivity) { activity in
                NavigationLink(value: AppRoute.kick(activity.id)) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(activity.title).font(.subheadline.weight(.semibold))
                            Text(activity.detail).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(activity.date, style: .date).font(.caption).foregroundStyle(.secondary)
                    }
                    .frame(minHeight: 44)
                }
                .buttonStyle(.plain)
            }
        }
    }
}
