import SwiftUI

struct HomeView: View {
    @Binding var selectedTab: AppTab
    @Environment(AppModel.self) private var app
    @State private var model = HomeViewModel()
    @State private var metrics = MetricTrackerViewModel()
    @State private var showingKickEntry = false
    @State private var showingSessionEditor = false

    init(selectedTab: Binding<AppTab>) {
        _selectedTab = selectedTab
    }

    var body: some View {
        content
            .navigationTitle("Home")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { AthleteSwitcherMenu() }
            }
            .task(id: app.revision) {
                model.load(app: app)
                metrics.load(app: app)
            }
            .sheet(isPresented: $showingKickEntry) {
                KickEntryView(sessionID: nil)
            }
            .sheet(isPresented: $showingSessionEditor) {
                SessionEditorView(sessionID: nil)
            }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message) { model.load(app: app) }
        case .loaded(let dashboard):
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    hero(dashboard)
                    quickActions
                    if dashboard.isEmpty {
                        EmptyStateView(title: "No kicks yet", systemImage: "football",
                                       message: DashboardPresentation.noKicksMessage)
                    } else {
                        SectionHeader(title: "At a glance")
                        statsGrid(dashboard)
                        metricsSection
                        trendCard(dashboard)
                        activityCard(dashboard)
                    }
                }
                .padding(16)
            }
            .background(KickTheme.canvas)
        }
    }

    /// Who, the latest technique grade and the one thing to work on.
    private func hero(_ d: DashboardPresentation) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center, spacing: 12) {
                Image(systemName: "figure.american.football")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(Circle().fill(KickTheme.brand))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text(d.athleteName).font(.title2.bold())
                    Text(d.kickingFootText).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .accessibilityElement(children: .combine)
            Divider()
            if let score = d.latestScoreText {
                HStack(alignment: .top, spacing: 16) {
                    ScoreBadge(scoreText: score, grade: d.latestScoreGrade, caption: "Latest technique")
                    VStack(alignment: .leading, spacing: 6) {
                        if let priority = d.topPriority {
                            Text("WORK ON").font(.caption2.weight(.bold)).foregroundStyle(KickTheme.workOn)
                            Text(priority.cue ?? priority.observed).font(.subheadline.weight(.semibold))
                            if priority.cue != nil { Text(priority.observed).font(.caption).foregroundStyle(.secondary) }
                        } else if d.latestScoreGrade == .unavailable {
                            // Nothing graded (e.g. filmed from behind): no "all good" claim.
                            Text("NOT GRADED").font(.caption2.weight(.bold)).foregroundStyle(KickTheme.notGraded)
                            Text("The latest video was measured but couldn't be graded. Film from the side, whole body in frame, to grade every phase.")
                                .font(.subheadline)
                        } else {
                            Text("NO FIX FLAGGED").font(.caption2.weight(.bold)).foregroundStyle(KickTheme.strength)
                            Text("Nothing to correct from what the latest analysis could measure.").font(.subheadline)
                        }
                        if let detail = d.latestScoreDetail {
                            Text(detail).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            } else {
                Label(d.analysisEmptyMessage ?? DashboardPresentation.noAnalysisMessage, systemImage: "camera.on.rectangle")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: KickTheme.cardRadius).fill(KickTheme.surface))
        .overlay(alignment: .top) {
            UnevenTopStripe()
        }
        .clipShape(RoundedRectangle(cornerRadius: KickTheme.cardRadius))
    }

    private var quickActions: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            ActionTile(title: "Log Kick", systemImage: "plus") { showingKickEntry = true }
            ActionTile(title: "Start Session", systemImage: "calendar.badge.plus") { showingSessionEditor = true }
            ActionTile(title: "Add Video", systemImage: "video.badge.plus") { selectedTab = .kicks }
            ActionTile(title: "Analyze", systemImage: "waveform.path.ecg") { selectedTab = .analyze }
        }
    }

    /// Build 23: the measurements to watch, from the Metric Tracker.
    @ViewBuilder
    private var metricsSection: some View {
        if let group = metrics.selectedGroup {
            SectionHeader(title: "Metrics", subtitle: group.title) {
                NavigationLink(value: AppRoute.metricTracker) { Text("See all") }
            }
            let watch = group.watchList
            if !group.tracks.contains(where: \.isGraded) {
                // Build 23.1: nothing graded from this view (e.g. filmed from behind).
                CardView {
                    Label("Measured, not graded: these measurements have no target from this camera view. Compare them with your own kicks.", systemImage: "ruler")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                ForEach(group.tracks.prefix(2)) { t in
                    NavigationLink(value: AppRoute.metricDetail(group: group.id, metric: t.key.rawValue)) { MetricTrackCard(track: t) }
                        .buttonStyle(.plain)
                }
            } else if watch.isEmpty {
                CardView {
                    Label("Every graded measurement on the latest kick is inside its provisional target.", systemImage: "checkmark.seal.fill")
                        .font(.subheadline)
                        .foregroundStyle(KickTheme.strength)
                }
                ForEach(group.tracks.filter(\.isGraded).prefix(2)) { t in
                    NavigationLink(value: AppRoute.metricDetail(group: group.id, metric: t.key.rawValue)) { MetricTrackCard(track: t) }
                        .buttonStyle(.plain)
                }
            } else {
                ForEach(watch) { t in
                    NavigationLink(value: AppRoute.metricDetail(group: group.id, metric: t.key.rawValue)) { MetricTrackCard(track: t) }
                        .buttonStyle(.plain)
                }
            }
        }
    }

    private func statsGrid(_ d: DashboardPresentation) -> some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            ForEach(d.stats) { stat in
                StatTileView(title: stat.title, value: stat.value, detail: stat.detail, systemImage: Self.symbol(for: stat.title))
            }
        }
    }

    static func symbol(for title: String) -> String {
        let t = title.lowercased()
        if t.contains("field goal") { return "scope" }
        if t.contains("kickoff") || t.contains("touchback") { return "arrow.up.right" }
        if t.contains("punt") || t.contains("hang") { return "timer" }
        if t.contains("session") { return "calendar" }
        return "football"
    }

    private func trendCard(_ d: DashboardPresentation) -> some View {
        CardView {
            Label("Last 30 days vs. the 30 before", systemImage: "chart.line.uptrend.xyaxis").font(.headline)
            if d.trend.isEmpty {
                Text(d.trendEmptyMessage ?? DashboardPresentation.noTrendMessage)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(d.trend) { item in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(item.title).font(.subheadline)
                            Text("\(item.previous) → \(item.current)").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(item.directionText).font(.subheadline.weight(.semibold))
                    }
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }

    private func activityCard(_ d: DashboardPresentation) -> some View {
        CardView {
            Label("Recent activity", systemImage: "clock.arrow.circlepath").font(.headline)
            ForEach(d.recentActivity) { activity in
                NavigationLink(value: AppRoute.kick(activity.id)) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(activity.title).font(.subheadline.weight(.semibold))
                            Text(activity.detail).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(activity.date, style: .date).font(.caption).foregroundStyle(.secondary)
                    }
                    .frame(minHeight: 44)
                }
                .buttonStyle(.plain)
            }
        }
    }
}

/// A thin brand-colored stripe along the top edge of the home card.
private struct UnevenTopStripe: View {
    var body: some View {
        Rectangle().fill(KickTheme.brand).frame(height: 4).accessibilityHidden(true)
    }
}
