import Charts
import SwiftUI

// Build 23: the Metric Tracker — each measurement kick by kick, against its provisional
// target, grouped by kick type and camera view (never mixed). Data: `MetricTracker`.

struct MetricTrackerView: View {
    @Environment(AppModel.self) private var app
    @State private var model = MetricTrackerViewModel()

    init() {}

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if !model.hasLoaded {
                    LoadingStateView()
                } else if let group = model.selectedGroup {
                    if model.groups.count > 1 { groupPicker }
                    summary(group)
                    if !group.watchList.isEmpty {
                        SectionHeader(title: "Watch", subtitle: "Outside the provisional target on the latest kick, or moving away from it")
                        ForEach(group.watchList) { t in trackLink(t, group: group) }
                    }
                    ForEach(categories(group), id: \.self) { c in
                        SectionHeader(title: c.presentationTitle)
                        ForEach(group.tracks.filter { $0.category == c }) { t in trackLink(t, group: group) }
                    }
                    Text("Only kicks with the same kick type and camera view are compared. Targets are provisional, not elite benchmarks; a trend needs \(MetricTracker.minimumForTrend) kicks moving the same way.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                } else {
                    EmptyStateView(title: "No measurements yet", systemImage: "chart.xyaxis.line",
                                   message: "Analyze a kick video and every measurement starts its own history here.")
                }
            }
            .padding(16)
        }
        .background(KickTheme.canvas)
        .navigationTitle("Metric Tracker")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { AthleteSwitcherMenu() } }
        .task(id: app.revision) { model.load(app: app) }
    }

    private var groupPicker: some View {
        Picker("Kicks", selection: Binding(get: { model.selectedGroup?.id ?? "" }, set: { model.selectedGroupID = $0 })) {
            ForEach(model.groups) { g in Text(g.title).tag(g.id) }
        }
        .pickerStyle(.menu)
        .tint(KickTheme.brand)
    }

    private func summary(_ g: MetricTrackerGroup) -> some View {
        HStack(spacing: 12) {
            StatTileView(title: "Kicks", value: "\(g.kickCount)", detail: g.title, systemImage: "football")
            StatTileView(title: "Last kick", value: g.lastDate.formatted(.dateTime.month(.abbreviated).day()),
                         detail: "\(g.tracks.count) measurements tracked", systemImage: "calendar")
        }
    }

    private func categories(_ g: MetricTrackerGroup) -> [AnalysisCategory] {
        [.plant, .swing, .contact, .followThrough, .approach].filter { c in g.tracks.contains { $0.category == c } }
    }

    private func trackLink(_ t: MetricTrack, group: MetricTrackerGroup) -> some View {
        NavigationLink(value: AppRoute.metricDetail(group: group.id, metric: t.key.rawValue)) {
            MetricTrackCard(track: t)
        }
        .buttonStyle(.plain)
    }
}

/// One measurement: latest value, trend, a small chart with the target band.
struct MetricTrackCard: View {
    let track: MetricTrack

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(track.name).font(.subheadline.weight(.semibold)).foregroundStyle(Color.primary)
                Spacer(minLength: 8)
                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline) {
                    value
                    Spacer(minLength: 8)
                    TrendBadge(trend: track.trend)
                }
                VStack(alignment: .leading, spacing: 4) {
                    value
                    TrendBadge(trend: track.trend)
                }
            }
            if track.points.count >= 2 {
                MetricSparkline(track: track).frame(height: 48)
            }
            Text(footer).font(.caption).foregroundStyle(.secondary)
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: KickTheme.cardRadius).fill(KickTheme.surface))
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(track.name): latest \(track.latestText). \(track.trend.title).\(track.targetText.map { " Provisional target \($0)." } ?? "")")
    }

    private var value: some View {
        Text(track.latestText).font(.title2.bold()).monospacedDigit().foregroundStyle(Color.primary)
            .lineLimit(1).minimumScaleFactor(0.7)
    }

    private var footer: String {
        guard let target = track.targetText else { return "No target · compare with your own kicks" }
        let n = track.points.count, inside = track.inTargetCount ?? 0
        return "Provisional target \(target) · \(inside) of \(n) kick\(n == 1 ? "" : "s") in target"
    }
}

/// The values kick by kick over the shaded target band (no axes).
struct MetricSparkline: View {
    let track: MetricTrack

    var body: some View {
        let scale = MetricTracker.chartScale(track)
        Chart(track.points) { p in
            if let band = scale.band {
                AreaMark(x: .value("Kick", p.number), yStart: .value("Target low", band.lowerBound), yEnd: .value("Target high", band.upperBound))
                    .foregroundStyle(KickTheme.target)
            }
            LineMark(x: .value("Kick", p.number), y: .value(track.name, p.value))
                .foregroundStyle(KickTheme.brand)
                .interpolationMethod(.monotone)
            PointMark(x: .value("Kick", p.number), y: .value(track.name, p.value))
                .foregroundStyle(p.inTarget == false ? KickTheme.workOn : KickTheme.brand)
                .symbolSize(p.number == track.points.count ? 60 : 20)
        }
        .chartYScale(domain: scale.domain)
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .accessibilityHidden(true)
    }
}

/// One measurement in full: chart with axes, summary, every kick.
struct MetricDetailView: View {
    let groupID: String
    let metric: String
    @Environment(AppModel.self) private var app
    @State private var model = MetricTrackerViewModel()

    init(groupID: String, metric: String) {
        self.groupID = groupID
        self.metric = metric
    }

    var body: some View {
        ScrollView {
            if let t = model.track(group: groupID, key: metric) {
                content(t)
            } else if model.hasLoaded {
                EmptyStateView(title: "Not available", systemImage: "chart.xyaxis.line", message: "This measurement has no saved kicks for this athlete.")
            } else {
                LoadingStateView()
            }
        }
        .background(KickTheme.canvas)
        .navigationTitle(model.track(group: groupID, key: metric)?.name ?? "Measurement")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: app.revision) { model.load(app: app) }
    }

    private func content(_ t: MetricTrack) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            CardView {
                Text(t.definition).font(.subheadline).foregroundStyle(.secondary)
                chart(t).frame(height: 220)
                HStack(spacing: 16) {
                    legend(color: KickTheme.brand, "Your kicks")
                    if t.isGraded { legend(color: KickTheme.target, "Provisional target") }
                    if t.points.contains(where: { $0.inTarget == false }) { legend(color: KickTheme.workOn, "Outside target") }
                }
            }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                StatTileView(title: "Latest", value: t.latestText, detail: t.points.last.map { $0.date.formatted(date: .abbreviated, time: .omitted) })
                StatTileView(title: "Recent average", value: t.recentAverageText, detail: "Last \(min(MetricTracker.recentWindow, t.points.count)) kicks")
                StatTileView(title: "Target", value: t.targetText ?? "None", detail: t.inTargetText ?? "Measured, not graded")
                StatTileView(title: "Trend", value: t.trend.title, detail: t.rangeText, systemImage: t.trend.symbol, tint: KickTheme.color(t.trend))
            }
            SectionHeader(title: "Every kick")
            CardView {
                ForEach(t.points.reversed()) { p in
                    NavigationLink(value: AppRoute.analysis(p.analysisID)) {
                        HStack {
                            Image(systemName: p.inTarget == nil ? "circle" : (p.inTarget == true ? "checkmark.circle.fill" : "exclamationmark.circle.fill"))
                                .foregroundStyle(p.inTarget == false ? KickTheme.workOn : (p.inTarget == true ? KickTheme.strength : Color.secondary))
                            Text("Kick \(p.number)").font(.subheadline.weight(.semibold))
                            Text(p.date.formatted(date: .abbreviated, time: .omitted)).font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            Text(p.valueText).font(.subheadline).monospacedDigit()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                        .frame(minHeight: 40)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Kick \(p.number), \(p.valueText)\(p.inTarget == nil ? "" : (p.inTarget == true ? ", inside target" : ", outside target"))")
                }
            }
        }
        .padding(16)
    }

    private func chart(_ t: MetricTrack) -> some View {
        let scale = MetricTracker.chartScale(t)
        return Chart(t.points) { p in
            if let band = scale.band {
                AreaMark(x: .value("Kick", p.number), yStart: .value("Target low", band.lowerBound), yEnd: .value("Target high", band.upperBound))
                    .foregroundStyle(KickTheme.target)
            }
            LineMark(x: .value("Kick", p.number), y: .value(t.name, p.value))
                .foregroundStyle(KickTheme.brand)
                .interpolationMethod(.monotone)
            PointMark(x: .value("Kick", p.number), y: .value(t.name, p.value))
                .foregroundStyle(p.inTarget == false ? KickTheme.workOn : KickTheme.brand)
                .symbolSize(50)
        }
        .chartYScale(domain: scale.domain)
        .chartXAxisLabel("Kick")
        .accessibilityLabel("\(t.name) for each kick")
    }

    private func legend(color: Color, _ text: String) -> some View {
        HStack(spacing: 6) {
            RoundedRectangle(cornerRadius: 3).fill(color).frame(width: 12, height: 12)
            Text(text).font(.caption).foregroundStyle(.secondary)
        }
    }
}
