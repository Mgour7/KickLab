import Charts
import SwiftUI

/// Step 12F: progress dashboard — every number and point comes from what was saved.
struct ProgressDashboardView: View {
    @Environment(AppModel.self) private var app
    @State private var model = ProgressDashboardViewModel()

    init() {}

    var body: some View {
        List {
            Section {
                Picker("Period", selection: $model.range) {
                    ForEach(ProgressRange.allCases) { r in Text(r.title).tag(r) }
                }
                .pickerStyle(.segmented)
            }
            content
        }
        .navigationTitle("Progress")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { AthleteSwitcherMenu() }
        }
        .task(id: "\(app.revision)-\(model.range.rawValue)") { model.load(app: app) }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            Section { LoadingStateView() }
        case .failed(let message):
            Section { ErrorStateView(message: message) { model.load(app: app) } }
        case .loaded(let d):
            if d.isEmpty {
                Section {
                    Text("No kicks recorded in this period. Log kicks in a session and your progress appears here.")
                        .foregroundStyle(.secondary)
                }
            } else {
                overview(d)
                fieldGoals(d)
                kickoffsAndPunts(d)
            }
            bests(d)
            sessions(d)
            videos(d)
            analysisTrends(d)
            mechanicsConsistency
            compareAndReference
        }
    }

    // MARK: Build 20

    /// Personal mechanics consistency, per kick type and camera view (never mixed).
    private var mechanicsConsistency: some View {
        Section {
            if model.consistency.isEmpty {
                Text("Analyze kicks to start your consistency baseline (\(ConsistencyModel.minimumForSpread) comparable kicks per kick type and camera view).")
                    .foregroundStyle(.secondary)
            }
            ForEach(model.consistency) { g in
                VStack(alignment: .leading, spacing: 4) {
                    Text(g.title).font(.subheadline.weight(.semibold))
                    Text(g.report.summaryText).font(.caption).foregroundStyle(.secondary)
                    ForEach(g.report.assessed) { m in
                        if let spread = m.spreadText {
                            Text("\(m.name): \(spread.prefix(1).lowercased() + spread.dropFirst()) — \(m.level?.title.lowercased() ?? "")").font(.caption)
                        }
                    }
                    ForEach(g.recentDeviations) { m in
                        Text("Latest kick · \(m.name): \(m.interpretation)").font(.caption.weight(.semibold))
                    }
                    if let goal = g.report.baselineGoal { Text(goal).font(.caption).foregroundStyle(.secondary) }
                }
                .accessibilityElement(children: .combine)
            }
        } header: {
            Text("Mechanics consistency")
        } footer: {
            Text("Compared only with your own kicks of the same type, from the same camera view. Repeatable isn't the same as correct, and different from usual isn't the same as worse.")
        }
    }

    private var compareAndReference: some View {
        Section {
            ForEach(model.references) { r in
                LabeledContent("Reference · \(r.kickType.displayName)", value: r.title)
            }
            if model.references.isEmpty {
                Text("No reference kick chosen. Pick one from a kick's page or from Compare Kicks.").font(.caption).foregroundStyle(.secondary)
            }
            NavigationLink(value: AppRoute.compareKicks(nil)) {
                Label("Compare kicks side by side", systemImage: "rectangle.split.2x1")
            }
            .disabled(model.analyzedKicks < 2)
        } header: {
            Text("Compare")
        } footer: {
            Text(model.analyzedKicks < 2 ? "Analyze at least two kicks to compare them." : PersonalReferencePolicy.explanation)
        }
    }

    // MARK: Sections

    private func overview(_ d: ProgressDashboard) -> some View {
        Section("Overview") {
            LabeledContent("Kicks recorded", value: "\(d.totalKicks)")
            ForEach(d.kicksByType.filter { $0.count > 0 }, id: \.type) { item in
                LabeledContent(item.type.displayName, value: "\(item.count)")
            }
            Text(d.consistencyText).font(.subheadline)
        }
    }

    @ViewBuilder
    private func fieldGoals(_ d: ProgressDashboard) -> some View {
        if let fg = d.fieldGoals {
            Section {
                LabeledContent("Made") {
                    VStack(alignment: .trailing) {
                        Text(fg.overall.text).monospacedDigit()
                        if let note = fg.overall.sampleNote { Text(note).font(.caption).foregroundStyle(.secondary) }
                    }
                }
                ForEach(fg.byDistance, id: \.bucket) { b in
                    LabeledContent(b.bucket.displayName + " yd") {
                        VStack(alignment: .trailing) {
                            Text(b.rate.text).monospacedDigit()
                            if let note = b.rate.sampleNote { Text(note).font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                }
                if let longest = fg.longestMake { LabeledContent("Longest make", value: DisplayFormat.yards(longest)) }
                if d.fieldGoalPoints.count >= 2 {
                    Chart(d.fieldGoalPoints) { p in
                        LineMark(x: .value("Day", p.date), y: .value("Make %", p.value))
                        PointMark(x: .value("Day", p.date), y: .value("Make %", p.value))
                    }
                    .chartYScale(domain: 0...100)
                    .chartYAxisLabel("Make % per day")
                    .frame(height: 180)
                    .accessibilityLabel("Field goal make percentage per day")
                }
            } header: {
                Text("Field goals")
            } footer: {
                Text("Percentages show attempts so a small sample isn't mistaken for a trend. Kicks without a result aren't attempts.")
            }
        }
    }

    @ViewBuilder
    private func kickoffsAndPunts(_ d: ProgressDashboard) -> some View {
        if let ko = d.kickoffs {
            Section("Kickoffs") {
                LabeledContent("Kickoffs", value: "\(ko.count)")
                valueRow("Average distance", ko.distance.average, count: ko.distance.count, unit: .yards)
                if ko.touchbacks.attempts > 0 { LabeledContent("Touchbacks", value: ko.touchbacks.text) }
                pointsChart(d.kickoffDistancePoints, label: "Distance (yd)")
            }
        }
        if let p = d.punts {
            Section("Punts") {
                LabeledContent("Punts", value: "\(p.count)")
                valueRow("Average distance", p.distance.average, count: p.distance.count, unit: .yards)
                valueRow("Average hang time", p.hangTime.average, count: p.hangTime.count, unit: .seconds)
                if p.insideTwenty.attempts > 0 { LabeledContent("Inside the 20", value: p.insideTwenty.text) }
                pointsChart(d.puntDistancePoints, label: "Distance (yd)")
            }
        }
        if d.hangTimePoints.count >= 2 {
            Section("Hang time") {
                Chart(d.hangTimePoints) { p in
                    PointMark(x: .value("Date", p.date), y: .value("Seconds", p.value))
                        .foregroundStyle(by: .value("Kick", p.series))
                }
                .chartYAxisLabel("Seconds")
                .frame(height: 180)
            }
        }
    }

    private enum ValueUnit { case yards, seconds }

    @ViewBuilder
    private func valueRow(_ title: String, _ value: Double?, count: Int, unit: ValueUnit) -> some View {
        if let value {
            LabeledContent(title) {
                VStack(alignment: .trailing) {
                    Text(unit == .yards ? DisplayFormat.yards(value) : DisplayFormat.seconds(value)).monospacedDigit()
                    Text("\(count) recorded").font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }

    @ViewBuilder
    private func pointsChart(_ points: [ProgressPoint], label: String) -> some View {
        if points.count >= 2 {
            Chart(points) { p in
                LineMark(x: .value("Date", p.date), y: .value(label, p.value))
                PointMark(x: .value("Date", p.date), y: .value(label, p.value))
            }
            .chartYAxisLabel(label)
            .frame(height: 160)
        } else if points.count == 1 {
            Text("Record at least two to see a trend.").font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private func bests(_ d: ProgressDashboard) -> some View {
        if !d.personalBests.isEmpty {
            Section("Personal bests (all time)") {
                ForEach(d.personalBests) { b in
                    LabeledContent {
                        VStack(alignment: .trailing) {
                            Text(b.value).monospacedDigit()
                            Text(b.date, style: .date).font(.caption).foregroundStyle(.secondary)
                        }
                    } label: { Text(b.title) }
                }
            }
        }
    }

    @ViewBuilder
    private func sessions(_ d: ProgressDashboard) -> some View {
        if !d.recentSessions.isEmpty {
            Section("Recent sessions") {
                ForEach(d.recentSessions) { s in
                    NavigationLink(value: AppRoute.session(s.id)) {
                        VStack(alignment: .leading) {
                            Text(s.name.isEmpty ? "Session" : s.name).font(.subheadline)
                            Text(s.date, style: .date).font(.caption).foregroundStyle(.secondary)
                            Text(s.summary).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func videos(_ d: ProgressDashboard) -> some View {
        if !d.recentVideoKicks.isEmpty {
            Section("Recent videos") {
                ForEach(d.recentVideoKicks, id: \.kickID) { k in
                    NavigationLink(value: AppRoute.kick(k.kickID)) {
                        HStack {
                            Text(k.kickType.displayName)
                            Spacer()
                            Text(k.timestamp, style: .date).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func analysisTrends(_ d: ProgressDashboard) -> some View {
        if !d.analysisGroups.isEmpty {
            Section {
                ForEach(d.analysisGroups) { g in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(g.label).font(.subheadline)
                        Text("\(g.metricTitle) · \(g.points.count) analysis\(g.points.count == 1 ? "" : "es")")
                            .font(.caption).foregroundStyle(.secondary)
                        if g.isChartable {
                            Chart(g.points) { p in
                                LineMark(x: .value("Date", p.date), y: .value(g.metricTitle, p.value))
                                PointMark(x: .value("Date", p.date), y: .value(g.metricTitle, p.value))
                            }
                            .frame(height: 140)
                        } else {
                            Text("Needs \(AnalysisTrendGroup.minimumPoints) comparable analyses for a trend.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            } header: {
                Text("Analysis trends")
            } footer: {
                Text("Only analyses with the same kick type, camera view and engine version are compared. A new engine version starts a new line. Analyses where you chose the contact aren't included.")
            }
        }
    }
}
