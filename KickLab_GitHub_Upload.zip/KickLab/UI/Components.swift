import SwiftUI

// Small reusable building blocks. Scores always show a text label as well as a color.

// Build 22: ScoreGrade colors live in KickTheme.swift.

/// A score in a ring with its grade written underneath.
struct ScoreBadge: View {
    let scoreText: String
    let grade: ScoreGrade
    var caption: String?
    /// Step 12C: overrides the grade word (e.g. "Excellent · tentative").
    var gradeText: String?

    var body: some View {
        VStack(spacing: 4) {
            Text(scoreText)
                .font(.title.bold())
                .monospacedDigit()
                .frame(minWidth: 68, minHeight: 68)
                .padding(4)
                .background(Circle().fill(grade.color.opacity(0.12)))
                .overlay(Circle().stroke(grade.color.opacity(0.2), lineWidth: 5))
                .overlay(Circle().trim(from: 0, to: CGFloat(min(100, max(0, Double(scoreText) ?? 0)) / 100))
                    .stroke(grade.color, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(-90)))
            Text(gradeText ?? grade.label)
                .font(.caption.weight(.semibold))
            if let caption {
                Text(caption)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(accessibilityText)
    }

    private var accessibilityText: String {
        let base = grade == .unavailable ? "Not scored" : "Score \(scoreText) out of 100, \(gradeText ?? grade.label)"
        return caption.map { base + ", " + $0 } ?? base
    }
}

/// "High confidence · 82%" with an icon that also differs by level.
struct ConfidenceText: View {
    let text: String
    let confidence: Double?

    var body: some View {
        Label(text, systemImage: symbol)
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    private var symbol: String {
        switch ConfidenceLevel(confidence) {
        case .high: "checkmark.seal"
        case .medium: "circle.lefthalf.filled"
        case .low: "exclamationmark.circle"
        case .insufficient: "questionmark.circle"
        }
    }
}

/// Loading indicator with a label.
struct LoadingStateView: View {
    var text = "Loading…"

    var body: some View {
        ProgressView(text)
            .frame(maxWidth: .infinity, minHeight: 160)
    }
}

/// An empty state with an optional call to action.
struct EmptyStateView: View {
    let title: String
    let systemImage: String
    let message: String
    var actionTitle: String?
    var action: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label(title, systemImage: systemImage)
        } description: {
            Text(message)
        } actions: {
            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

/// A recoverable error with a retry button.
struct ErrorStateView: View {
    let message: String
    var retry: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label("Something went wrong", systemImage: "exclamationmark.triangle")
        } description: {
            Text(message)
        } actions: {
            if let retry {
                Button("Try Again", action: retry)
                    .buttonStyle(.bordered)
            }
        }
    }
}

/// A compact titled value, with an optional icon and a colored accent.
struct StatTileView: View {
    let title: String
    let value: String
    var detail: String?
    var systemImage: String?
    var tint: Color = KickTheme.brand

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                if let systemImage {
                    Image(systemName: systemImage).font(.caption.weight(.semibold)).foregroundStyle(tint)
                }
                Text(title)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Text(value)
                .font(.title2.bold())
                .monospacedDigit()
                .lineLimit(2)
                .minimumScaleFactor(0.75)
            if let detail {
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 16).fill(KickTheme.surface))
        .accessibilityElement(children: .combine)
    }
}

/// A rounded card container on the grouped surface color.
struct CardView<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(RoundedRectangle(cornerRadius: KickTheme.cardRadius).fill(KickTheme.surface))
    }
}

/// A section title above cards: a bold heading, an optional one-line explanation and an
/// optional trailing link.
struct SectionHeader<Trailing: View>: View {
    let title: String
    var subtitle: String?
    @ViewBuilder var trailing: Trailing

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.title3.bold())
                if let subtitle { Text(subtitle).font(.footnote).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 8)
            trailing.font(.subheadline.weight(.semibold))
        }
        .padding(.horizontal, 4)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }
}

extension SectionHeader where Trailing == EmptyView {
    init(title: String, subtitle: String? = nil) {
        self.title = title
        self.subtitle = subtitle
        self.trailing = EmptyView()
    }
}

/// A large, tappable action: an icon in a tinted circle above its title.
struct ActionTile: View {
    let title: String
    let systemImage: String
    var tint: Color = KickTheme.brand
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: systemImage)
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(tint)
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(tint.opacity(0.14)))
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity, minHeight: 88, alignment: .leading)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 18).fill(KickTheme.surface))
            .contentShape(RoundedRectangle(cornerRadius: 18))
        }
        .buttonStyle(.plain)
    }
}

/// "Moving toward target" with its icon, colored by whether that's good.
struct TrendBadge: View {
    let trend: MetricTrackTrend

    var body: some View {
        Label(trend.title, systemImage: trend.symbol)
            .font(.caption.weight(.semibold))
            .foregroundStyle(KickTheme.color(trend))
            .lineLimit(1)
    }
}

/// Switches the selected athlete from any tab.
struct AthleteSwitcherMenu: View {
    @Environment(AppModel.self) private var app

    init() {}

    var body: some View {
        Menu {
            ForEach(app.athletes) { athlete in
                Button {
                    app.select(athlete.id)
                } label: {
                    if athlete.id == app.selectedAthleteID {
                        Label(athlete.name, systemImage: "checkmark")
                    } else {
                        Text(athlete.name)
                    }
                }
            }
        } label: {
            Label(app.selectedAthlete?.name ?? "Athlete", systemImage: "person.crop.circle")
        }
        .accessibilityLabel("Switch athlete. Current: \(app.selectedAthlete?.name ?? "none")")
    }
}

/// Loads a thumbnail image from a local file URL off the main thread.
struct ThumbnailView: View {
    let url: URL?

    @State private var image: UIImage?

    init(url: URL?) {
        self.url = url
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8).fill(Color.secondary.opacity(0.15))
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "video")
                    .foregroundStyle(.secondary)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .accessibilityHidden(true)
        .task(id: url) {
            image = await Self.load(url)
        }
    }

    static func load(_ url: URL?) async -> UIImage? {
        guard let path = url?.path else { return nil }
        let data = await Task.detached { FileManager.default.contents(atPath: path) }.value
        return data.flatMap { UIImage(data: $0) }
    }
}
