import SwiftUI

// Small reusable building blocks. Scores always show a text label as well as a color.

extension ScoreGrade {
    var color: Color {
        switch self {
        case .excellent: .green
        case .good: .blue
        case .fair: .orange
        case .needsWork: .red
        case .unavailable: .gray
        }
    }
}

/// A score in a ring with its grade written underneath.
struct ScoreBadge: View {
    let scoreText: String
    let grade: ScoreGrade
    var caption: String?

    var body: some View {
        VStack(spacing: 4) {
            Text(scoreText)
                .font(.title.bold())
                .monospacedDigit()
                .frame(minWidth: 64, minHeight: 64)
                .padding(4)
                .background(Circle().fill(grade.color.opacity(0.15)))
                .overlay(Circle().stroke(grade.color, lineWidth: 3))
            Text(grade.label)
                .font(.caption.weight(.semibold))
            if let caption {
                Text(caption)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(accessibilityText)
    }

    private var accessibilityText: String {
        let base = grade == .unavailable ? "Not scored" : "Score \(scoreText) out of 100, \(grade.label)"
        return caption.map { base + ", " + $0 } ?? base
    }
}

/// "High confidence · 82%" with an icon that also differs by level.
struct ConfidenceText: View {
    let text: String
    let confidence: Double?

    var body: some View {
        Label(text, systemImage: symbol)
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    private var symbol: String {
        switch ConfidenceLevel(confidence) {
        case .high: "checkmark.seal"
        case .medium: "circle.lefthalf.filled"
        case .low: "exclamationmark.circle"
        case .insufficient: "questionmark.circle"
        }
    }
}

/// Loading indicator with a label.
struct LoadingStateView: View {
    var text = "Loading…"

    var body: some View {
        ProgressView(text)
            .frame(maxWidth: .infinity, minHeight: 160)
    }
}

/// An empty state with an optional call to action.
struct EmptyStateView: View {
    let title: String
    let systemImage: String
    let message: String
    var actionTitle: String?
    var action: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label(title, systemImage: systemImage)
        } description: {
            Text(message)
        } actions: {
            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

/// A recoverable error with a retry button.
struct ErrorStateView: View {
    let message: String
    var retry: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label("Something went wrong", systemImage: "exclamationmark.triangle")
        } description: {
            Text(message)
        } actions: {
            if let retry {
                Button("Try Again", action: retry)
                    .buttonStyle(.bordered)
            }
        }
    }
}

/// A compact titled value.
struct StatTileView: View {
    let title: String
    let value: String
    var detail: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title3.bold())
                .monospacedDigit()
            if let detail {
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.secondary.opacity(0.1)))
        .accessibilityElement(children: .combine)
    }
}

/// A rounded card container.
struct CardView<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.secondary.opacity(0.08)))
    }
}

/// Switches the selected athlete from any tab.
struct AthleteSwitcherMenu: View {
    @Environment(AppModel.self) private var app

    init() {}

    var body: some View {
        Menu {
            ForEach(app.athletes) { athlete in
                Button {
                    app.select(athlete.id)
                } label: {
                    if athlete.id == app.selectedAthleteID {
                        Label(athlete.name, systemImage: "checkmark")
                    } else {
                        Text(athlete.name)
                    }
                }
            }
        } label: {
            Label(app.selectedAthlete?.name ?? "Athlete", systemImage: "person.crop.circle")
        }
        .accessibilityLabel("Switch athlete. Current: \(app.selectedAthlete?.name ?? "none")")
    }
}

/// Loads a thumbnail image from a local file URL off the main thread.
struct ThumbnailView: View {
    let url: URL?

    @State private var image: UIImage?

    init(url: URL?) {
        self.url = url
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8).fill(Color.secondary.opacity(0.15))
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "video")
                    .foregroundStyle(.secondary)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .accessibilityHidden(true)
        .task(id: url) {
            image = await Self.load(url)
        }
    }

    static func load(_ url: URL?) async -> UIImage? {
        guard let path = url?.path else { return nil }
        let data = await Task.detached { FileManager.default.contents(atPath: path) }.value
        return data.flatMap { UIImage(data: $0) }
    }
}
