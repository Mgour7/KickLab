import AVKit
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

/// A picked video, copied to a temporary file KickLab can import from.
struct PickedMovie: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in
            SentTransferredFile(movie.url)
        } importing: { received in
            let name = "kicklab-import-\(UUID().uuidString).\(received.file.pathExtension)"
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(name)
            try FileManager.default.copyItem(at: received.file, to: destination)
            return PickedMovie(url: destination)
        }
    }
}

/// One kick: outcome, videos and analyses.
struct KickDetailView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: KickDetailViewModel
    @State private var showingImport = false
    @State private var editing: KickEntryViewModel?
    @State private var confirmingDelete = false
    @State private var playingVideoURL: URL?

    init(kickID: UUID) {
        _model = State(initialValue: KickDetailViewModel(kickID: kickID))
    }

    var body: some View {
        content
            .navigationTitle(model.state.value?.kick.title ?? "Kick")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { editing = KickEntryViewModel(editing: model.kickID, app: app) } label: {
                            Label("Edit Kick", systemImage: "pencil")
                        }
                        Button(role: .destructive) { confirmingDelete = true } label: {
                            Label("Delete Kick", systemImage: "trash")
                        }
                    } label: {
                        Label("More", systemImage: "ellipsis.circle")
                    }
                }
            }
            .task(id: app.revision) { model.load(app: app) }
            .sheet(isPresented: $showingImport) {
                VideoImportSheet(model: model)
            }
            .sheet(item: $editing) { editModel in
                KickEntryView(editing: editModel)
            }
            .sheet(item: playingBinding) { item in
                VideoPlayerSheet(url: item.url, markers: [])
            }
            .confirmationDialog("Delete this kick?", isPresented: $confirmingDelete, titleVisibility: .visible) {
                Button("Delete Kick", role: .destructive) {
                    if model.deleteKick(app: app) { dismiss() }
                }
            } message: {
                Text("Its videos stored in KickLab and its analyses are deleted too. Videos in your Photos library are not touched.")
            }
            .alert("Couldn't complete that", isPresented: errorBinding) {
                Button("OK", role: .cancel) { model.errorMessage = nil }
            } message: {
                Text(model.errorMessage ?? "")
            }
    }

    private var errorBinding: Binding<Bool> {
        Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })
    }

    private var playingBinding: Binding<PlayableURL?> {
        Binding(get: { playingVideoURL.map(PlayableURL.init(url:)) }, set: { playingVideoURL = $0?.url })
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView()
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let content):
            List {
                Section {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(content.kick.detail).font(.headline)
                        Text(content.kick.date, style: .date).font(.subheadline).foregroundStyle(.secondary)
                        if let session = content.sessionName {
                            Text("Session: \(session)").font(.subheadline).foregroundStyle(.secondary)
                        }
                        if let notes = content.notes {
                            Text(notes).font(.body)
                        }
                    }
                    .accessibilityElement(children: .combine)
                }
                videosSection(content)
                analysisSection(content)
            }
        }
    }

    private func videosSection(_ content: KickDetailViewModel.Content) -> some View {
        Section {
            if content.videos.isEmpty {
                Text("No video yet. Add one to analyze this kick's mechanics.")
                    .foregroundStyle(.secondary)
            }
            ForEach(content.videos) { video in
                VideoRow(video: video, thumbnailURL: model.thumbnailURL(videoID: video.id, app: app))
                    .contentShape(Rectangle())
                    .onTapGesture {
                        if video.isPlayable { playingVideoURL = model.fileURL(videoID: video.id, app: app) }
                    }
                    .swipeActions {
                        Button(role: .destructive) { model.removeVideo(videoID: video.id, app: app) } label: {
                            Label("Remove", systemImage: "trash")
                        }
                        if !video.isPrimary {
                            Button { model.setPrimary(videoID: video.id, app: app) } label: {
                                Label("Make Primary", systemImage: "star")
                            }
                            .tint(.blue)
                        }
                    }
                    .contextMenu {
                        if !video.isPrimary {
                            Button { model.setPrimary(videoID: video.id, app: app) } label: {
                                Label("Make Primary", systemImage: "star")
                            }
                        }
                        Button(role: .destructive) { model.removeVideo(videoID: video.id, app: app) } label: {
                            Label("Remove Video", systemImage: "trash")
                        }
                    }
            }
            Button {
                showingImport = true
            } label: {
                Label(model.isImporting ? "Importing…" : "Add Video", systemImage: "video.badge.plus")
            }
            .disabled(model.isImporting)
        } header: {
            Text("Videos")
        } footer: {
            if !content.videos.isEmpty {
                Text("Tap a video to play it. Swipe for primary and remove. Removing a video never deletes it from your Photos library.")
            }
        }
    }

    private func analysisSection(_ content: KickDetailViewModel.Content) -> some View {
        Section("Mechanics analysis") {
            if let current = content.analyses.first(where: { $0.id == content.currentAnalysisID }) {
                NavigationLink(value: AppRoute.analysis(current.id)) {
                    HStack {
                        ScoreBadge(scoreText: DisplayFormat.score(current.overallScore), grade: ScoreGrade(score: current.overallScore))
                        VStack(alignment: .leading) {
                            Text("Current analysis").font(.headline)
                            Text(current.date, style: .date).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            } else {
                Text(content.videos.isEmpty ? "Add a video to analyze this kick." : "Not analyzed yet.")
                    .foregroundStyle(.secondary)
            }
            if !content.videos.isEmpty {
                NavigationLink(value: AppRoute.analyze(model.kickID)) {
                    Label(content.currentAnalysisID == nil ? "Analyze" : "Analyze Again", systemImage: "figure.run")
                }
            }
            if content.analyses.count > 1 {
                NavigationLink(value: AppRoute.kickHistory(model.kickID)) {
                    Label("Analysis history (\(content.analyses.count))", systemImage: "clock.arrow.circlepath")
                }
            }
        }
    }
}

/// A URL wrapper so a sheet can be driven by it.
struct PlayableURL: Identifiable, Hashable {
    let url: URL
    var id: String { url.absoluteString }
}

struct VideoRow: View {
    let video: VideoRowPresentation
    let thumbnailURL: URL?

    var body: some View {
        HStack(spacing: 12) {
            ThumbnailView(url: thumbnailURL)
                .frame(width: 72, height: 54)
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(video.angleText).font(.headline)
                    if video.isPrimary {
                        Text("Primary")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.accentColor.opacity(0.2)))
                    }
                }
                Label(video.statusText, systemImage: video.isPlayable ? "checkmark.circle" : "exclamationmark.circle")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let duration = video.durationText {
                    Text([duration, video.frameRateText].compactMap { $0 }.joined(separator: " · "))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(minHeight: 56)
        .accessibilityElement(children: .combine)
    }
}

/// Choose the angle, whether it's primary, and the source (Photos or Files).
struct VideoImportSheet: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let model: KickDetailViewModel

    @State private var angle: VideoAngleType = .side
    @State private var makePrimary = false
    @State private var photoItem: PhotosPickerItem?
    @State private var showingFiles = false
    @State private var loading = false
    @State private var errorMessage: String?

    init(model: KickDetailViewModel) {
        self.model = model
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Camera angle", selection: $angle) {
                        ForEach(VideoRowPresentation.selectableAngles, id: \.self) { angle in
                            Text(angle.displayName).tag(angle)
                        }
                    }
                    Toggle("Use as primary video", isOn: $makePrimary)
                } footer: {
                    Text("A side view with the kicker's whole body in frame gives the most reliable analysis. The first video of a kick is always primary.")
                }
                Section {
                    PhotosPicker(selection: $photoItem, matching: .videos) {
                        Label("Choose from Photos", systemImage: "photo.on.rectangle")
                    }
                    Button {
                        showingFiles = true
                    } label: {
                        Label("Choose from Files", systemImage: "folder")
                    }
                } footer: {
                    Text("KickLab keeps its own copy. Your original video is never changed or deleted.")
                }
                if loading {
                    Section { ProgressView("Importing video…") }
                }
                if let errorMessage {
                    Section { Label(errorMessage, systemImage: "exclamationmark.triangle").foregroundStyle(.red) }
                }
            }
            .navigationTitle("Add Video")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
            .disabled(loading)
            .onChange(of: photoItem) { _, item in
                guard let item else { return }
                Task { await importFromPhotos(item) }
            }
            .fileImporter(isPresented: $showingFiles, allowedContentTypes: [.movie]) { result in
                switch result {
                case .success(let url):
                    Task { await importFromFiles(url) }
                case .failure:
                    errorMessage = "That file couldn't be opened."
                }
            }
        }
    }

    private func importFromPhotos(_ item: PhotosPickerItem) async {
        loading = true
        defer { loading = false }
        do {
            guard let movie = try await item.loadTransferable(type: PickedMovie.self) else {
                errorMessage = "That video couldn't be loaded."
                return
            }
            await model.importVideo(from: movie.url, source: .photosImport, angle: angle, makePrimary: makePrimary,
                                    app: app, removeSourceAfterImport: true)
            finish()
        } catch {
            errorMessage = "That video couldn't be loaded from Photos."
        }
    }

    private func importFromFiles(_ url: URL) async {
        loading = true
        defer { loading = false }
        let accessing = url.startAccessingSecurityScopedResource()
        defer { if accessing { url.stopAccessingSecurityScopedResource() } }
        await model.importVideo(from: url, source: .filesImport, angle: angle, makePrimary: makePrimary, app: app)
        finish()
    }

    private func finish() {
        if model.errorMessage == nil {
            dismiss()
        } else {
            errorMessage = model.errorMessage
            model.errorMessage = nil
        }
    }
}

/// Plays a stored video, with optional jump buttons for kick phases.
struct VideoPlayerSheet: View {
    @Environment(\.dismiss) private var dismiss
    let url: URL
    let markers: [PhaseMarker]
    @State private var player: AVPlayer?
    @State private var rate: PlaybackRate = .full
    @State private var isPlaying = false

    init(url: URL, markers: [PhaseMarker]) {
        self.url = url
        self.markers = markers
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                VideoPlayer(player: player)
                    .frame(minHeight: 280)
                replayControls
                if !markers.isEmpty {
                    PhaseJumpBar(markers: markers) { time in seek(to: time) }
                }
            }
            .padding(.bottom)
            .navigationTitle("Video")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
            .onAppear { if player == nil { player = AVPlayer(url: url) } }
            .onDisappear { player?.pause() }
        }
    }

    /// Step 12E: speed, play/pause and single-frame steps (the video's own frames).
    private var replayControls: some View {
        HStack(spacing: 12) {
            Button {
                player?.currentItem?.step(byCount: -1)
                isPlaying = false
            } label: { Label("Back one frame", systemImage: "backward.frame") }
                .labelStyle(.iconOnly)
                .frame(minWidth: 44, minHeight: 44)
            Button {
                guard let player else { return }
                if isPlaying { player.pause() } else { player.playImmediately(atRate: rate.rawValue) }
                isPlaying.toggle()
            } label: { Label(isPlaying ? "Pause" : "Play", systemImage: isPlaying ? "pause.fill" : "play.fill") }
                .labelStyle(.iconOnly)
                .frame(minWidth: 44, minHeight: 44)
            Button {
                player?.currentItem?.step(byCount: 1)
                isPlaying = false
            } label: { Label("Forward one frame", systemImage: "forward.frame") }
                .labelStyle(.iconOnly)
                .frame(minWidth: 44, minHeight: 44)
            Picker("Speed", selection: $rate) {
                ForEach(PlaybackRate.allCases) { r in Text(r.title).tag(r) }
            }
            .pickerStyle(.segmented)
            .onChange(of: rate) { _, newRate in
                if isPlaying { player?.playImmediately(atRate: newRate.rawValue) }
            }
        }
        .padding(.horizontal)
    }

    private func seek(to seconds: Double) {
        guard let player else { return }
        isPlaying = false
        player.pause()
        player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
    }
}

/// Buttons that jump to each detected kick phase.
struct PhaseJumpBar: View {
    let markers: [PhaseMarker]
    let jump: (Double) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(markers) { marker in
                    Button {
                        jump(marker.time)
                    } label: {
                        VStack(spacing: 0) {
                            Text(marker.title)
                            Text(marker.source.label).font(.caption2).foregroundStyle(.secondary)
                        }
                        .frame(minHeight: 36)
                    }
                    .buttonStyle(.bordered)
                    .accessibilityHint("Jumps the video to \(marker.title.lowercased()), \(marker.source.label)")
                }
            }
            .padding(.horizontal)
        }
    }
}
