import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Shown instead of crashing when KickLab can't open its data store at launch.
struct StartupFailureView: View {
    let message: String

    init(message: String) {
        self.message = message
    }

    var body: some View {
        EmptyStateView(
            title: "KickLab couldn't start",
            systemImage: "exclamationmark.triangle",
            message: message
        )
        .padding()
    }
}

/// Keeps the screen awake while an analysis runs.
enum IdleTimer {
    @MainActor
    static func setDisabled(_ disabled: Bool) {
        #if canImport(UIKit)
        UIApplication.shared.isIdleTimerDisabled = disabled
        #endif
    }
}
