import SwiftUI

/// Step 12E: the curated drill library (general drills, not individually prescribed).
struct DrillLibraryView: View {
    var body: some View {
        List {
            Section {
                Text(DrillLibrary.generalCaution).font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(DrillFocus.allCases) { focus in
                let drills = DrillLibrary.drills(for: focus)
                if !drills.isEmpty {
                    Section(focus.title) {
                        ForEach(drills) { drill in
                            NavigationLink(value: AppRoute.drill(drill.id)) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(drill.title).font(.headline)
                                    Text(drill.purpose).font(.caption).foregroundStyle(.secondary)
                                }
                                .frame(minHeight: 44)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Drill Library")
    }
}

struct DrillDetailView: View {
    let drillID: String

    var body: some View {
        if let drill = DrillLibrary.drill(id: drillID) {
            List {
                Section {
                    Text(drill.purpose).font(.body)
                    Label(drill.focus.title, systemImage: "scope").font(.subheadline)
                    Text("For: " + drill.kickTypes.map(\.displayName).joined(separator: ", ")).font(.caption).foregroundStyle(.secondary)
                }
                Section("How to do it") {
                    ForEach(Array(drill.instructions.enumerated()), id: \.offset) { i, step in
                        Text("\(i + 1). \(step)")
                    }
                }
                Section("Reps") { Text(drill.repetitions) }
                Section("Equipment") { ForEach(drill.equipment, id: \.self) { Text($0) } }
                Section("Common mistakes") { ForEach(drill.commonMistakes, id: \.self) { Text($0) } }
                Section("Cautions") {
                    ForEach(drill.cautions, id: \.self) { Text($0) }
                    Text(DrillLibrary.generalCaution).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle(drill.title)
            .navigationBarTitleDisplayMode(.inline)
        } else {
            EmptyStateView(title: "Drill not found", systemImage: "questionmark", message: "This drill isn't in the library.")
        }
    }
}

/// Related general drills for the areas an analysis flagged.
struct DrillSuggestionsView: View {
    let categories: [AnalysisCategory]
    let kickType: KickType

    var body: some View {
        let drills = DrillSuggestions.drills(for: categories, kickType: kickType)
        VStack(alignment: .leading, spacing: 8) {
            Text("Drills").font(.title3.bold())
            if drills.isEmpty {
                Text("No area was flagged on this kick. Browse the library for general practice.").font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(drills) { drill in
                NavigationLink(value: AppRoute.drill(drill.id)) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(drill.title).font(.headline)
                        Text("\(drill.focus.title) · general drill").font(.caption).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                }
            }
            NavigationLink(value: AppRoute.drillLibrary) {
                Label("Drill library", systemImage: "books.vertical").frame(minHeight: 44)
            }
        }
    }
}
