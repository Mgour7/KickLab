import AVKit
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Build 24 — "Use as Remote Camera": this iPhone sits on a tripod and records when the
/// controlling iPhone says so. Its recordings are kept on this phone (the outbox) until
/// the controller confirms each one is in its training session.
@MainActor
@Observable
final class RemoteCameraModel {
    enum Link: Equatable {
        case searching
        case connecting(String)
        case connected(String)
    }

    let recorder = CameraRecorder()
    let cameraID: String
    private(set) var link: Link = .searching
    private(set) var found: [RemoteControllerFound] = []
    private(set) var welcome: RemoteControllerWelcome?
    private(set) var pending: [RemoteTakeInfo] = []
    private(set) var sendingFraction: Double?
    private(set) var problem: String?
    /// The controller asked for a code this phone doesn't have (or it didn't match).
    var needsCode: RemoteControllerFound?
    var cameraName: String {
        didSet { defaults.set(cameraName, forKey: Keys.name) }
    }

    @ObservationIgnored private let outbox: RemoteCameraOutbox
    @ObservationIgnored private let defaults = UserDefaults.standard
    @ObservationIgnored private let browser = RemoteBrowser()
    @ObservationIgnored private var channel: RemoteChannel?
    @ObservationIgnored private var current: RemoteTakeInfo?
    @ObservationIgnored private var scheduledStart: Task<Void, Never>?
    @ObservationIgnored private var statusTimer: Timer?
    @ObservationIgnored private var sendQueue: [(UUID, Int64)] = []
    @ObservationIgnored private var outgoing: (info: RemoteTakeInfo, handle: FileHandle, offset: Int64)?
    @ObservationIgnored private var lastAttempt: Date = .distantPast
    @ObservationIgnored private var active = false
    @ObservationIgnored private var reachedReady = false

    private enum Keys {
        static let id = "remoteCamera.id"
        static let name = "remoteCamera.name"
        static let code = "remoteCamera.code"
        static let controller = "remoteCamera.controller"
        static let request = "remoteCamera.request"
    }

    init() {
        let d = UserDefaults.standard
        let id = d.string(forKey: Keys.id) ?? UUID().uuidString
        d.set(id, forKey: Keys.id)
        cameraID = id
        cameraName = d.string(forKey: Keys.name) ?? RemoteDeviceName.defaultCameraName(model: Self.modelIdentifier(), cameraID: id)
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true))
            ?? FileManager.default.temporaryDirectory
        outbox = RemoteCameraOutbox(baseURL: base.appendingPathComponent("KickLab", isDirectory: true))
    }

    static func modelIdentifier() -> String {
        var info = utsname()
        uname(&info)
        return withUnsafeBytes(of: &info.machine) { raw in
            String(decoding: raw.prefix { $0 != 0 }, as: UTF8.self)
        }
    }

    var savedCode: String? { defaults.string(forKey: Keys.code) }

    // MARK: Lifecycle

    func appear() async {
        guard !active else { return }
        active = true
        try? outbox.prepare()
        outbox.removeEmpty()
        refreshPending()
        #if canImport(UIKit)
        UIDevice.current.isBatteryMonitoringEnabled = true
        #endif
        if let data = defaults.data(forKey: Keys.request), let r = try? JSONDecoder().decode(CaptureRequest.self, from: data) { recorder.request = r }
        recorder.onFinished = { url, reason, duration, usable in
            self.finished(url: url, reason: reason, duration: duration, usable: usable)
        }
        recorder.onStarted = { host, uncertainty in self.started(hostTime: host, uncertainty: uncertainty) }
        browser.onResults = { [weak self] found in self?.foundControllers(found) }
        browser.onProblem = { [weak self] problem in
            if let problem { self?.problem = "Looking for the controller: \(problem)" }
        }
        browser.start()
        startStatusTimer()
        await recorder.prepare()
    }

    private func startStatusTimer() {
        statusTimer?.invalidate()
        statusTimer = Timer.scheduledTimer(withTimeInterval: RemoteCapture.pingInterval, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tickStatus() }
        }
    }

    func disappear() {
        active = false
        statusTimer?.invalidate()
        statusTimer = nil
        scheduledStart?.cancel()
        browser.stop()
        channel?.close(reason: nil)
        channel = nil
        // A recording in progress is finished and kept for the controller.
        recorder.shutDown(reason: .userStopped)
        closeOutgoing()
    }

    // MARK: Finding the controller

    private func foundControllers(_ list: [RemoteControllerFound]) {
        found = list
        guard channel == nil, let last = defaults.string(forKey: Keys.controller), let code = savedCode,
              let match = list.first(where: { $0.name == last }), Date().timeIntervalSince(lastAttempt) > 3 else { return }
        connect(match, code: code)
    }

    /// Joins a controller with its pairing code (remembered for next time).
    func connect(_ controller: RemoteControllerFound, code: String) {
        guard let code = RemotePairing.normalized(code) else {
            problem = "The pairing code is the six digits shown on the controlling iPhone."
            return
        }
        channel?.close(reason: nil)
        lastAttempt = Date()
        defaults.set(code, forKey: Keys.code)
        defaults.set(controller.name, forKey: Keys.controller)
        problem = nil
        reachedReady = false
        link = .connecting(controller.name)
        let c = RemoteChannel(connection: RemoteBrowser.connection(to: controller), code: code, isController: false)
        c.onEvent = { [weak self] ch, event in self?.channelEvent(ch, event, controller: controller) }
        c.onPayload = { [weak self] ch, payload in self?.payload(ch, payload) }
        c.onDrained = { [weak self] _ in self?.pump() }
        channel = c
        c.start()
        // A controller that has gone away leaves the connection waiting: give up and look again.
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(10))
            guard let self, self.channel === c, !self.reachedReady else { return }
            c.close(reason: "Couldn't reach \(controller.name). Is Remote Cameras open on it?")
        }
    }

    func disconnect() {
        defaults.removeObject(forKey: Keys.controller)
        channel?.close(reason: nil)
    }

    private func channelEvent(_ ch: RemoteChannel, _ event: RemoteChannelEvent, controller: RemoteControllerFound) {
        guard ch === channel else { return }
        switch event {
        case .ready:
            reachedReady = true
            ch.send(.hello(RemoteCameraHello(cameraID: cameraID, name: cameraName, model: Self.modelIdentifier(),
                                             version: RemoteCapture.protocolVersion, pending: pending)))
        case .waiting(let reason):
            problem = "Waiting for the network: \(reason)"
        case .closed(let reason):
            channel = nil
            welcome = nil
            link = .searching
            closeOutgoing()
            if reachedReady, !ch.authenticated {
                // Connected, then dropped before the controller said anything it could
                // read: the controller didn't accept this code. Ask again (and stop retrying).
                defaults.removeObject(forKey: Keys.code)
                problem = "\(controller.name) didn't accept this camera. Check the pairing code shown on it."
                needsCode = controller
            } else if let reason {
                problem = reason
            }
            reachedReady = false
        }
    }

    // MARK: Messages

    private func payload(_ ch: RemoteChannel, _ payload: RemoteWire.Payload) {
        guard case .message(let message) = payload else { return }
        switch message {
        case .welcome(let w):
            welcome = w
            link = .connected(w.controllerName)
            problem = nil
            if let data = try? JSONEncoder().encode(w.request) { defaults.set(data, forKey: Keys.request) }
            if w.request != recorder.request, !recorder.isBusy {
                recorder.request = w.request
                Task { await recorder.prepare(); sendStatus() }
            }
            sendStatus()
        case .ping(let id, let sent):
            let received = HostClock.now()
            ch.send(.pong(id: id, controllerSent: sent, cameraReceived: received, cameraSent: HostClock.now()))
        case .start(let takeID, let at):
            scheduleStart(takeID, at: at)
        case .stop(let takeID):
            if current?.takeID == takeID {
                scheduledStart?.cancel()
                if recorder.state.isRecording { recorder.stopRecording() } else if !recorder.isBusy { abandonCurrent() }
            }
        case .sendFile(let takeID, let offset):
            sendQueue.removeAll { $0.0 == takeID }
            if outgoing?.info.takeID == takeID { closeOutgoing() }
            sendQueue.append((takeID, offset))
            pump()
        case .imported(let takeID):
            outbox.remove(takeID)
            refreshPending()
            sendStatus()
        case .incompatible:
            problem = "This iPhone and the controlling iPhone have different KickLab versions. Update KickLab on both."
        case .hello, .pong, .status, .started, .finished, .fileEnd, .problem:
            break
        }
    }

    // MARK: Recording

    private func scheduleStart(_ takeID: UUID, at cameraTime: Double?) {
        guard let w = welcome else { return }
        guard recorder.state.canStartRecording, current == nil else {
            channel?.send(.problem("\(cameraName) wasn't ready to record (\(statusPhase.title.lowercased()))."))
            return
        }
        let info = RemoteTakeInfo(takeID: takeID, sessionID: w.sessionID, role: w.role, startCameraTime: nil, startUncertainty: nil,
                                  duration: nil, frameRate: nil, bytes: 0, usable: false, fileExtension: "mov", selection: recorder.selection)
        do {
            // Written before recording, so a recording cut off by the app closing is still sent.
            try outbox.save(info)
        } catch {
            channel?.send(.problem("\(cameraName) couldn't save to its storage."))
            return
        }
        current = info
        let delay = min(max((cameraTime ?? HostClock.now()) - HostClock.now(), 0), 2)
        scheduledStart = Task { [weak self] in
            if delay > 0 { try? await Task.sleep(for: .seconds(delay)) }
            guard !Task.isCancelled, let self else { return }
            self.recorder.startRecording(to: self.outbox.videoURL(takeID))
            if !self.recorder.state.isRecording { self.abandonCurrent() }
            self.sendStatus()
        }
    }

    private func abandonCurrent() {
        if let c = current { outbox.remove(c.takeID) }
        current = nil
    }

    private func started(hostTime: Double, uncertainty: Double) {
        guard var c = current else { return }
        c.startCameraTime = hostTime
        c.startUncertainty = uncertainty
        current = c
        try? outbox.save(c)
        channel?.send(.started(takeID: c.takeID, cameraTime: hostTime, uncertainty: uncertainty))
    }

    private func finished(url: URL, reason: CaptureStopReason, duration: Double?, usable: Bool) {
        guard var c = current else { recorder.readyForNextRecording(); return }
        let bytes = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
        c.duration = duration
        c.bytes = bytes
        c.usable = usable || bytes > 0
        c.frameRate = recorder.selection.map { Double($0.framesPerSecond) } ?? c.selection.map { Double($0.framesPerSecond) }
        current = nil
        if bytes > 0 {
            try? outbox.save(c)
        } else {
            outbox.remove(c.takeID)
        }
        if let message = reason.message, reason != .userStopped { problem = message }
        refreshPending()
        channel?.send(.finished(c))
        recorder.readyForNextRecording()
        sendStatus()
        pump()   // a transfer paused for the recording carries on
    }

    // MARK: Sending files

    private func pump() {
        // Nothing is sent while recording: the camera's full attention (and the network's,
        // for the clock exchanges) stays on the recording. Sending resumes after Stop.
        guard let ch = channel, !recorder.isBusy, current == nil else { return }
        if outgoing == nil {
            while let next = sendQueue.first {
                sendQueue.removeFirst()
                let (id, offset) = next
                guard let info = pending.first(where: { $0.takeID == id }),
                      let handle = try? FileHandle(forReadingFrom: outbox.videoURL(id, fileExtension: info.fileExtension)) else {
                    ch.send(.problem("\(cameraName) no longer has that recording."))
                    continue
                }
                do { try handle.seek(toOffset: UInt64(max(0, offset))) } catch { try? handle.close(); continue }
                outgoing = (info, handle, offset)
                break
            }
        }
        guard var out = outgoing else { sendingFraction = nil; return }
        while ch.hasRoom {
            let data: Data
            do { data = try out.handle.read(upToCount: RemoteCapture.fileChunkBytes) ?? Data() } catch { data = Data() }
            if data.isEmpty {
                ch.send(.fileEnd(takeID: out.info.takeID, bytes: out.offset))
                closeOutgoing()
                pump()
                return
            }
            ch.send(.chunk(takeID: out.info.takeID, offset: out.offset, data: data))
            out.offset += Int64(data.count)
            outgoing = out
        }
        sendingFraction = out.info.bytes > 0 ? Double(out.offset) / Double(out.info.bytes) : nil
    }

    private func closeOutgoing() {
        try? outgoing?.handle.close()
        outgoing = nil
        sendingFraction = nil
    }

    func refreshPending() {
        pending = outbox.pending(excluding: current?.takeID)
    }

    /// Recordings for other sessions, or ones the athlete no longer wants: deleted from
    /// this phone (the athlete confirms first).
    func deleteWaitingRecordings() {
        for p in pending where p.takeID != outgoing?.info.takeID { outbox.remove(p.takeID) }
        refreshPending()
        sendStatus()
    }

    // MARK: Status

    var statusPhase: RemoteCameraPhase {
        switch recorder.state {
        case .idle, .requestingPermission, .configuring: .preparing
        case .ready, .saved: .ready
        case .recording: .recording
        case .finishing: .saving
        case .failed: .failed
        case .interrupted: .interrupted
        }
    }

    var waitingBytes: Int64 { pending.reduce(0) { $0 + $1.bytes } }

    private func tickStatus() {
        sendStatus()
        if channel == nil, let last = defaults.string(forKey: Keys.controller), let code = savedCode,
           let match = found.first(where: { $0.name == last }), Date().timeIntervalSince(lastAttempt) > 3 {
            connect(match, code: code)
        }
    }

    private func sendStatus() {
        guard let ch = channel, welcome != nil else { return }
        #if canImport(UIKit)
        let level = Double(UIDevice.current.batteryLevel)
        let battery: Double? = level >= 0 ? level : nil
        #else
        let battery: Double? = nil
        #endif
        let warning: String? = {
            if case .failed(let f) = recorder.state { return f.message }
            return recorder.warning ?? problem
        }()
        ch.send(.status(RemoteCameraStatus(phase: statusPhase, elapsed: recorder.state.isRecording ? recorder.elapsed : nil,
                                           selection: recorder.selection?.title, battery: battery, freeBytes: CameraRecorder.availableBytes(),
                                           warning: warning, pendingCount: pending.count, sending: outgoing != nil)))
    }
}
