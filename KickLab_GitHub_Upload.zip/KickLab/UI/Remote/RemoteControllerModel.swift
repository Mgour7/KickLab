import Network
import SwiftUI

/// Build 24 — the controlling iPhone: finds the remote cameras (they connect to it), shows
/// them, starts and stops all of them together, and adds each camera's recording to the
/// training session as it arrives, synchronized on this iPhone's clock.
@MainActor
@Observable
final class RemoteControllerModel {
    let sessionID: UUID
    private(set) var rig: RemoteRig?
    private(set) var manifest: TrainingSessionManifest?
    private(set) var problem: String?
    private(set) var networkProblem: String?
    private(set) var code: String
    private(set) var importProblem: String?
    /// Add recordings that have arrived even if a camera with a better view hasn't sent its
    /// own yet (that camera never came back).
    var forceImport = false {
        didSet { importReady() }
    }

    @ObservationIgnored private weak var app: AppModel?
    @ObservationIgnored private let listener = RemoteListener()
    @ObservationIgnored private var channels: [UUID: RemoteChannel] = [:]
    @ObservationIgnored private var cameraOfChannel: [UUID: String] = [:]
    @ObservationIgnored private var channelOfCamera: [String: UUID] = [:]
    @ObservationIgnored private var incoming: [String: FileHandle] = [:]
    @ObservationIgnored private var timer: Timer?
    @ObservationIgnored private var importing = false
    @ObservationIgnored private var cameraRequests: [String: CaptureRequest] = [:]
    private static let cameraRequestsKey = "remoteController.cameraRequests"

    private static let codeKey = "remoteController.code"
    private static let idKey = "remoteController.id"

    static func controllerName() -> String {
        let d = UserDefaults.standard
        let id = d.string(forKey: idKey) ?? String(UUID().uuidString.prefix(4))
        d.set(id, forKey: idKey)
        return "KickLab Controller · \(id)"
    }
    static let maximumConnections = 6

    init(sessionID: UUID) {
        self.sessionID = sessionID
        let d = UserDefaults.standard
        if let c = d.string(forKey: Self.codeKey), RemotePairing.normalized(c) != nil {
            code = c
        } else {
            let c = RemotePairing.newCode()
            d.set(c, forKey: Self.codeKey)
            code = c
        }
    }

    // MARK: Lifecycle

    func start(app: AppModel) {
        guard rig == nil else { return }
        self.app = app
        guard let m = try? app.services.trainingSessions.load(sessionID) else {
            problem = "The training session couldn't be read."
            return
        }
        manifest = m
        // A name that stays the same from session to session, so cameras reconnect by
        // themselves (the session's name travels in the welcome message instead).
        let name = Self.controllerName()
        rig = RemoteRig(sessionID: sessionID, sessionName: m.name, controllerName: name, request: CaptureSettingsStore.load(),
                        kickType: m.defaults.kickType, takes: loadTakes(), clock: HostClock.now(), now: .now)
        for (camera, data) in UserDefaults.standard.dictionary(forKey: Self.cameraRequestsKey) as? [String: Data] ?? [:] {
            if let r = try? JSONDecoder().decode(CaptureRequest.self, from: data) { cameraRequests[camera] = r }
        }
        // Transfers cut off last time start over.
        try? FileManager.default.removeItem(at: incomingDirectory)
        listener.onConnection = { [weak self] connection in self?.accept(connection) }
        listener.onProblem = { [weak self] problem in self?.networkProblem = problem }
        listener.start(name: name)
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
        importReady()
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        listener.stop()
        for c in channels.values { c.close(reason: nil) }
        channels.removeAll()
        cameraOfChannel.removeAll()
        channelOfCamera.removeAll()
        for h in incoming.values { try? h.close() }
        incoming.removeAll()
        persist()
        rig = nil
    }

    /// A new code disconnects every camera (each must enter the new one).
    func newCode() {
        guard rig?.isRecording != true else { return }
        let c = RemotePairing.newCode()
        UserDefaults.standard.set(c, forKey: Self.codeKey)
        code = c
        for ch in channels.values { ch.close(reason: nil) }
    }

    // MARK: Connections

    private func accept(_ connection: NWConnection) {
        guard channels.count < Self.maximumConnections else { connection.cancel(); return }
        let ch = RemoteChannel(connection: connection, code: code, isController: true)
        ch.onPayload = { [weak self] c, payload in self?.received(payload, on: c) }
        ch.onEvent = { [weak self] c, event in self?.channelEvent(c, event) }
        channels[ch.id] = ch
        ch.start()
    }

    private func channelEvent(_ ch: RemoteChannel, _ event: RemoteChannelEvent) {
        guard case .closed = event else { return }
        channels[ch.id] = nil
        guard let camera = cameraOfChannel.removeValue(forKey: ch.id) else { return }
        guard channelOfCamera[camera] == ch.id else { return }   // replaced by a newer connection
        channelOfCamera[camera] = nil
        rig?.disconnected(camera)
        for key in incoming.keys where key.hasSuffix("|\(camera)") {
            try? incoming[key]?.close()
            incoming[key] = nil
        }
    }

    private func received(_ payload: RemoteWire.Payload, on ch: RemoteChannel) {
        let t = HostClock.now()
        switch payload {
        case .message(.hello(let h)):
            guard UUID(uuidString: h.cameraID) != nil, var r = rig else { ch.close(reason: nil); return }
            if let old = channelOfCamera[h.cameraID], old != ch.id { channels[old]?.close(reason: nil) }
            cameraOfChannel[ch.id] = h.cameraID
            channelOfCamera[h.cameraID] = ch.id
            let role = r.camera(h.cameraID)?.role ?? r.suggestedRole()
            // A camera given its own quality earlier keeps it.
            let actions = r.hello(h, defaultRole: role, defaultRequest: cameraRequests[h.cameraID], at: t)
            rig = r
            perform(actions)
            persist()
        case .message(let m):
            guard let camera = cameraOfChannel[ch.id], var r = rig else { return }
            let actions = r.receive(m, from: camera, at: t)
            rig = r
            perform(actions)
            switch m {
            case .fileEnd(let takeID, _):
                if case .received = phase(takeID, camera) { closeIncoming(takeID, camera) }
                persist()
                importReady()
            case .started, .finished:
                persist()
            default: break
            }
        case .chunk(let takeID, let offset, let data):
            guard let camera = cameraOfChannel[ch.id], var r = rig else { return }
            guard r.chunk(takeID: takeID, cameraID: camera, offset: offset, count: data.count) == .write else { return }
            do {
                guard let h = incoming[key(takeID, camera)] else { throw CocoaError(.fileWriteUnknown) }
                try h.write(contentsOf: data)
                rig = r
            } catch {
                r.importFailed(takeID: takeID, cameraID: camera, reason: "This iPhone couldn't save the video (is its storage full?).")
                rig = r
                closeIncoming(takeID, camera)
                persist()
            }
        }
    }

    private func phase(_ takeID: UUID, _ camera: String) -> RemoteRig.Phase? {
        rig?.takes.first { $0.id == takeID }?.cameras.first { $0.cameraID == camera }?.phase
    }

    private func perform(_ actions: [RemoteRig.Action]) {
        for case .send(let message, let camera) in actions {
            if case .sendFile(let takeID, let offset) = message, !prepareIncoming(takeID, camera, from: offset) { continue }
            guard let id = channelOfCamera[camera], let ch = channels[id] else { continue }
            ch.send(message)
        }
    }

    private func tick() {
        guard var r = rig else { return }
        let actions = r.tick(at: HostClock.now())
        rig = r
        perform(actions)
        // A connection that went silent is closed (the camera reconnects by itself).
        for (camera, id) in channelOfCamera where r.camera(camera)?.connected == false {
            channels[id]?.close(reason: nil)
        }
    }

    // MARK: Recording

    func record() {
        guard var r = rig else { return }
        do {
            let actions = try r.startRecording(takeID: UUID(), details: manifest?.defaults, at: HostClock.now())
            rig = r
            problem = nil
            perform(actions)
            persist()
        } catch {
            problem = (error as? RemoteRig.StartProblem) == .alreadyRecording
                ? "Already recording." : "No camera is ready. Open KickLab on each tripod iPhone: Analyze → Use as Remote Camera."
        }
    }

    func stopRecording() {
        guard var r = rig else { return }
        let actions = r.stopRecording(at: HostClock.now())
        rig = r
        perform(actions)
        persist()
    }

    func markKick() {
        guard var r = rig else { return }
        r.mark(at: HostClock.now())
        rig = r
    }

    /// New kick settings: from this moment in the take being recorded, and for later takes.
    func changeDetails(_ details: SessionKickDetails) {
        guard let app, var r = rig else { return }
        r.changeDetails(details, at: HostClock.now())
        rig = r
        manifest = app.sessionProcessor(for: sessionID).update(app) {
            TrainingSessionEditor.changeDefaultsForLaterRecordings(&$0, to: details, now: .now)
        } ?? manifest
        var r2 = rig ?? r
        let actions = r2.setKickType(details.kickType)
        rig = r2
        perform(actions)
        persist()
    }

    func setRole(_ role: SessionCameraRole, camera: String) {
        guard var r = rig else { return }
        let actions = r.setRole(role, camera: camera)
        rig = r
        perform(actions)
    }

    /// One camera's own quality (nil: the session's), remembered for that camera.
    func setRequest(_ request: CaptureRequest?, camera: String) {
        guard var r = rig else { return }
        let actions = r.setRequest(request, camera: camera)
        rig = r
        perform(actions)
        cameraRequests[camera] = request
        let stored = cameraRequests.compactMapValues { try? JSONEncoder().encode($0) }
        UserDefaults.standard.set(stored, forKey: Self.cameraRequestsKey)
    }

    func setRequest(_ request: CaptureRequest) {
        guard var r = rig else { return }
        CaptureSettingsStore.save(request)
        let actions = r.setRequest(request)
        rig = r
        perform(actions)
    }

    func forget(camera: String) {
        rig?.forget(camera)
    }

    // MARK: Files

    private var incomingDirectory: URL {
        (app?.services.trainingSessions.directory(sessionID) ?? FileManager.default.temporaryDirectory)
            .appendingPathComponent("incoming", isDirectory: true)
    }

    private func key(_ takeID: UUID, _ camera: String) -> String { "\(takeID.uuidString)|\(camera)" }

    private func incomingURL(_ takeID: UUID, _ camera: String) -> URL {
        incomingDirectory.appendingPathComponent("\(takeID.uuidString)-\(camera).part")
    }

    /// Opens the file a transfer writes into, cut back to where the transfer resumes.
    private func prepareIncoming(_ takeID: UUID, _ camera: String, from offset: Int64) -> Bool {
        let k = key(takeID, camera)
        try? incoming[k]?.close()
        incoming[k] = nil
        let url = incomingURL(takeID, camera)
        do {
            try FileManager.default.createDirectory(at: incomingDirectory, withIntermediateDirectories: true)
            if offset == 0 || !FileManager.default.fileExists(atPath: url.path) {
                guard offset == 0 else { return false }
                _ = FileManager.default.createFile(atPath: url.path, contents: nil)
            }
            let h = try FileHandle(forWritingTo: url)
            try h.truncate(atOffset: UInt64(offset))
            try h.seekToEnd()
            incoming[k] = h
            return true
        } catch {
            importProblem = "This iPhone couldn't prepare storage for a camera's video."
            return false
        }
    }

    private func closeIncoming(_ takeID: UUID, _ camera: String) {
        let k = key(takeID, camera)
        try? incoming[k]?.synchronize()
        try? incoming[k]?.close()
        incoming[k] = nil
    }

    /// Adds every recording that has arrived (in camera order for a new session).
    private func importReady() {
        guard let app, let r = rig, !importing else { return }
        let hasSources = !(manifest?.sources.isEmpty ?? true)
        guard let next = r.importable(sessionHasSources: hasSources, force: forceImport).first,
              let take = r.takes.first(where: { $0.id == next.takeID }), var info = next.camera.info else { return }
        importing = true
        let tc = next.camera
        let store = app.services.trainingSessions
        let id = UUID()
        let ext = Self.safeExtension(info.fileExtension)
        Task {
            defer {
                importing = false
                importReady()
            }
            do {
                try store.prepare(sessionID)
                let destination = store.url(session: sessionID, relativePath: "sources/\(id.uuidString).\(ext)")
                try FileManager.default.moveItem(at: incomingURL(next.takeID, tc.cameraID), to: destination)
                // The file's own duration and frame rate, rather than the camera's report.
                if let metadata = await app.services.mediaStore.metadataReader.readMetadata(at: destination) {
                    info.duration = metadata.durationSeconds
                    info.frameRate = metadata.frameRate ?? info.frameRate
                }
                let remote = RemoteSourceInfo(cameraID: tc.cameraID, cameraName: tc.cameraName, takeID: next.takeID,
                                              startOnController: tc.startOnController, startUncertainty: tc.startTotalUncertainty)
                let processor = app.sessionProcessor(for: sessionID)
                let updated = processor.update(app) { m in
                    guard m.source(id) == nil else { return }
                    let start = tc.startOnController
                    let changes = RemoteRig.defaultsChanges(take, sourceID: id, start: start, sessionDefaults: m.defaults)
                    TrainingSessionEditor.addRemoteSource(&m, id: id, take: info, remote: remote, fileExtension: ext, now: .now)
                    m.defaultsChanges += changes
                    for t in RemoteRig.markTimes(take, start: start, duration: info.duration) {
                        TrainingSessionEditor.addMark(&m, sourceID: id, at: t, now: .now)
                    }
                }
                guard let updated else { throw CocoaError(.fileWriteUnknown) }
                manifest = updated
                if var r2 = rig {
                    let actions = r2.imported(takeID: next.takeID, cameraID: tc.cameraID, sourceID: id)
                    rig = r2
                    perform(actions)
                }
                importProblem = nil
                persist()
                app.dataDidChange()
                processor.start(app: app)
            } catch {
                rig?.importFailed(takeID: next.takeID, cameraID: tc.cameraID, reason: "Couldn't be added to the session (\(error.localizedDescription)).")
                importProblem = "A camera's video couldn't be added to the session."
                persist()
            }
        }
    }

    static func safeExtension(_ e: String) -> String {
        let lower = e.lowercased()
        return ["mov", "mp4", "m4v"].contains(lower) ? lower : "mov"
    }

    // MARK: Persistence

    private var takesURL: URL? {
        app.map { $0.services.trainingSessions.directory(sessionID).appendingPathComponent("remote-takes.json") }
    }

    private func loadTakes() -> [RemoteRig.Take] {
        guard let url = takesURL, let data = try? Data(contentsOf: url) else { return [] }
        return (try? JSONDecoder().decode([RemoteRig.Take].self, from: data)) ?? []
    }

    private func persist() {
        guard let url = takesURL, let takes = rig?.takes else { return }
        try? JSONEncoder().encode(takes).write(to: url, options: .atomic)
    }
}
