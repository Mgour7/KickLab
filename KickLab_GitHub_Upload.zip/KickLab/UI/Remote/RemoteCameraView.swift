import AVKit
import SwiftUI

/// Build 24 — the tripod phone's screen: the camera picture, which view it records, and
/// whether it is connected to the controlling iPhone. Nothing to press during practice.
struct RemoteCameraView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @State private var model = RemoteCameraModel()
    @State private var codeEntry = ""
    @State private var choosing: RemoteControllerFound?
    @State private var confirmingDelete = false
    @State private var renaming = false
    @State private var draftName = ""
    @State private var showingFraming = true

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CameraPreview(recorder: model.recorder).ignoresSafeArea()
            if model.recorder.state.isRecording {
                RoundedRectangle(cornerRadius: 0).stroke(Color.red, lineWidth: 8).ignoresSafeArea()
            }
            VStack(spacing: 12) {
                header
                if model.orientation == .portrait {
                    Label("Turn this iPhone sideways (landscape) — kicks need the wide picture.", systemImage: "rectangle.landscape.rotate")
                        .font(.headline).foregroundStyle(.black).padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Color.yellow))
                }
                if showingFraming, !model.recorder.state.isRecording { framingCard }
                Spacer()
                if case .connected = model.link {} else { connectPanel }
                footer
            }
            .padding()
        }
        .task { await model.appear() }
        .onDisappear {
            model.disappear()
            IdleTimer.setDisabled(false)
        }
        .onAppear { IdleTimer.setDisabled(true) }
        .onChange(of: scenePhase) { _, phase in
            // iOS stops the camera and the network in the background; the recording so far
            // is finished and kept, and sent once this screen is open again.
            if phase == .background { model.disappear() }
            if phase == .active { Task { await model.appear() } }
        }
        .sheet(item: Binding(get: { choosing ?? model.needsCode }, set: { choosing = $0; if $0 == nil { model.needsCode = nil } })) { controller in
            codeSheet(controller)
        }
        .confirmationDialog("Delete the recordings waiting on this iPhone?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Delete \(model.pending.count) Recording\(model.pending.count == 1 ? "" : "s")", role: .destructive) { model.deleteWaitingRecordings() }
        } message: {
            Text("They haven't reached the controlling iPhone yet. Deleting them can't be undone.")
        }
        .alert("Camera name", isPresented: $renaming) {
            TextField("Name", text: $draftName)
            Button("Save") {
                let t = draftName.trimmingCharacters(in: .whitespacesAndNewlines)
                if !t.isEmpty { model.cameraName = String(t.prefix(30)) }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Shown on the controlling iPhone (for example \"Sideline tripod\").")
        }
        .statusBarHidden()
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Circle().fill(model.recorder.state.isRecording ? Color.red : linkColor).frame(width: 12, height: 12)
                Text(model.recorder.state.isRecording ? "REC \(CaptureFormat.elapsed(model.recorder.elapsed))" : model.statusPhase.title)
                    .font(.headline.monospacedDigit())
                Spacer()
                Button {
                    dismiss()
                } label: {
                    Label("Close", systemImage: "xmark.circle.fill").labelStyle(.iconOnly).font(.title2)
                }
                .accessibilityLabel("Close camera mode")
                .disabled(model.recorder.state.isRecording)
            }
            if let w = model.welcome {
                Text(roleTitle(w.role).uppercased()).font(.title2.bold())
                Text("\(w.sessionName) · controlled by \(w.controllerName)").font(.caption)
            } else {
                Text("Remote camera").font(.title2.bold())
            }
            Button {
                draftName = model.cameraName
                renaming = true
            } label: {
                Label(model.cameraName, systemImage: "pencil").font(.caption)
            }
            .disabled(model.recorder.state.isRecording)
            HStack {
                if let s = model.recorder.selection { Text(s.title).font(.caption2) }
                Spacer()
                if !showingFraming { Button("Framing tips") { showingFraming = true }.font(.caption2) }
            }
            if let p = model.problem { Text(p).font(.caption).foregroundStyle(.yellow) }
            if let w = model.recorder.warning { Text(w).font(.caption).foregroundStyle(.yellow) }
        }
        .foregroundStyle(.white)
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.6)))
    }

    private var framingCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Framing · \(model.welcome.map { roleTitle($0.role) } ?? "Side view")").font(.subheadline.bold())
                Spacer()
                Button("Hide") { showingFraming = false }.font(.caption)
            }
            ForEach(model.framingAdvice) { tip in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(tip.title).font(.caption.bold())
                        Text(tip.detail).font(.caption2)
                    }
                } icon: {
                    Image(systemName: tip.symbol)
                }
            }
        }
        .foregroundStyle(.white)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.6)))
    }

    private var linkColor: Color {
        switch model.link {
        case .connected: KickTheme.strength
        case .connecting: KickTheme.workOn
        case .searching: Color.gray
        }
    }

    private func roleTitle(_ role: SessionCameraRole) -> String {
        switch role {
        case .side: "Side view"
        case .rear: "Rear view"
        case .unspecified: "Extra angle"
        }
    }

    private var connectPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            switch model.link {
            case .connecting(let name):
                HStack { ProgressView().tint(.white); Text("Connecting to \(name)…") }
            default:
                Text("Connect to the controlling iPhone").font(.headline)
                if model.found.isEmpty {
                    HStack(spacing: 8) {
                        ProgressView().tint(.white)
                        Text("Looking nearby… On the controlling iPhone, open Analyze → Remote Cameras.").font(.caption)
                    }
                } else {
                    ForEach(model.found) { c in
                        Button {
                            codeEntry = model.savedCode ?? ""
                            choosing = c
                        } label: {
                            Label(c.name, systemImage: "iphone.radiowaves.left.and.right").frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(KickTheme.brand)
                    }
                }
            }
        }
        .foregroundStyle(.white)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.6)))
    }

    private var footer: some View {
        HStack(alignment: .center) {
            if model.pending.isEmpty {
                Text("No recordings waiting").font(.caption)
            } else {
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(model.pending.count) recording\(model.pending.count == 1 ? "" : "s") waiting to send · \(ByteCountFormatter.string(fromByteCount: model.waitingBytes, countStyle: .file))")
                        .font(.caption)
                    if let f = model.sendingFraction {
                        ProgressView(value: f).tint(.white)
                        Text("Sending \(Int((f * 100).rounded()))%").font(.caption2)
                    }
                }
                Spacer()
                Button(role: .destructive) { confirmingDelete = true } label: {
                    Label("Delete", systemImage: "trash").labelStyle(.iconOnly)
                }
                .disabled(model.recorder.state.isRecording)
                .accessibilityLabel("Delete waiting recordings")
            }
            Spacer()
            if case .connected = model.link {
                Button("Disconnect") { model.disconnect() }.font(.caption).disabled(model.recorder.state.isRecording)
            }
        }
        .foregroundStyle(.white)
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.6)))
    }

    private func codeSheet(_ controller: RemoteControllerFound) -> some View {
        NavigationStack {
            Form {
                Section {
                    TextField("6-digit code", text: $codeEntry)
                        .keyboardType(.numberPad)
                        .font(.title2.monospacedDigit())
                } header: {
                    Text("Pairing code")
                } footer: {
                    Text("Shown on \(controller.name), under Remote Cameras. You only enter it once; this iPhone remembers it.")
                }
            }
            .navigationTitle("Join \(controller.name)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { choosing = nil; model.needsCode = nil } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Join") {
                        model.connect(controller, code: codeEntry)
                        choosing = nil
                        model.needsCode = nil
                    }
                    .disabled(RemotePairing.normalized(codeEntry) == nil)
                }
            }
        }
        .presentationDetents([.medium])
    }
}
