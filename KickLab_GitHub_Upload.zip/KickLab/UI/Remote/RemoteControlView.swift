import SwiftUI

/// Build 24 — Remote Cameras, on the controlling iPhone: the pairing code, the connected
/// tripod iPhones (view, battery, storage, clock), one Record / Stop for all of them, and
/// each camera's video arriving into the training session.
struct RemoteControlView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @State private var model: RemoteControllerModel
    @State private var editingDetails = false
    @State private var draftDetails = SessionKickDetails()
    @State private var confirmingFinish = false
    @State private var confirmingNewCode = false
    let onFinish: () -> Void

    init(sessionID: UUID, onFinish: @escaping () -> Void) {
        _model = State(initialValue: RemoteControllerModel(sessionID: sessionID))
        self.onFinish = onFinish
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let p = model.problem { banner(p) }
                    if let p = model.importProblem { banner(p) }
                    pairingCard
                    camerasSection
                    takesSection
                    howItWorks
                }
                .padding()
            }
            .background(KickTheme.canvas)
            .safeAreaInset(edge: .bottom) { controls }
            .navigationTitle("Remote Cameras")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") {
                        if (model.rig?.outstanding ?? 0) > 0 || model.rig?.isRecording == true { confirmingFinish = true } else { finish() }
                    }
                }
                ToolbarItem(placement: .primaryAction) { qualityMenu }
            }
        }
        .task { model.start(app: app) }
        .onAppear { IdleTimer.setDisabled(true) }
        .onDisappear {
            model.stop()
            IdleTimer.setDisabled(false)
        }
        .onChange(of: scenePhase) { _, phase in
            // In the background iOS closes the connections; the cameras keep recording and
            // reconnect when this screen is back.
            if phase == .background { model.stop() }
            if phase == .active { model.start(app: app) }
        }
        .sheet(isPresented: $editingDetails) {
            NavigationStack {
                Form { KickDetailsSection(details: $draftDetails, showsDistance: true) }
                    .navigationTitle("Next kicks")
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Apply") { model.changeDetails(draftDetails); editingDetails = false }
                        }
                    }
            }
        }
        .confirmationDialog(finishTitle, isPresented: $confirmingFinish, titleVisibility: .visible) {
            Button(model.rig?.isRecording == true ? "Stop and Close" : "Close") {
                if model.rig?.isRecording == true { model.stopRecording() }
                finish()
            }
            Button("Keep Open", role: .cancel) {}
        } message: {
            Text("Recordings that haven't arrived stay on the cameras. Open Remote Cameras for this session again with the cameras on to receive them.")
        }
        .confirmationDialog("Make a new pairing code?", isPresented: $confirmingNewCode, titleVisibility: .visible) {
            Button("New Code", role: .destructive) { model.newCode() }
        } message: {
            Text("Every camera disconnects and needs the new code.")
        }
    }

    private var finishTitle: String {
        let n = model.rig?.outstanding ?? 0
        if model.rig?.isRecording == true { return "The cameras are still recording." }
        return "\(n) camera recording\(n == 1 ? " hasn't" : "s haven't") arrived yet."
    }

    private func finish() {
        dismiss()
        onFinish()
    }

    // MARK: Pairing

    private var pairingCard: some View {
        CardView {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("PAIRING CODE").font(.caption.weight(.semibold)).foregroundStyle(.secondary).tracking(1)
                    Text(RemotePairing.display(model.code)).font(.largeTitle.weight(.bold).monospacedDigit())
                        .accessibilityLabel("Pairing code \(model.code.map(String.init).joined(separator: " "))")
                }
                Spacer()
                Button("New Code") { confirmingNewCode = true }
                    .font(.caption)
                    .disabled(model.rig?.isRecording == true)
            }
            Text("On each tripod iPhone open KickLab → Analyze → Use as Remote Camera, tap this iPhone and enter the code once.")
                .font(.footnote).foregroundStyle(.secondary)
            if let p = model.networkProblem {
                Label(p, systemImage: "wifi.exclamationmark").font(.caption).foregroundStyle(KickTheme.workOn)
            }
            Button {
                draftDetails = model.manifest?.defaults ?? SessionKickDetails()
                editingDetails = true
            } label: {
                Label(model.manifest?.defaults.summary ?? "Kick settings", systemImage: "slider.horizontal.3").font(.subheadline)
            }
        }
    }

    private var qualityMenu: some View {
        Menu {
            ForEach(CaptureRequest.choices, id: \.title) { r in
                Button {
                    model.setRequest(r)
                } label: {
                    if r == model.rig?.request { Label(r.title, systemImage: "checkmark") } else { Text(r.title) }
                }
            }
        } label: {
            Label("Quality", systemImage: "camera.aperture")
        }
        .disabled(model.rig?.isRecording == true)
    }

    // MARK: Cameras

    private var camerasSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Cameras", subtitle: cameraSubtitle)
            let cams = model.rig?.cameras ?? []
            if cams.isEmpty {
                CardView {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("Waiting for cameras… Keep the tripod iPhones close by with KickLab open.").font(.subheadline)
                    }
                }
            }
            ForEach(cams) { c in cameraCard(c) }
            if let dup = model.rig?.duplicateRoles, !dup.isEmpty {
                Label("Two cameras are set to \(dup.map(roleTitle).joined(separator: " and ")). Each view should have one camera.", systemImage: "exclamationmark.triangle")
                    .font(.caption).foregroundStyle(KickTheme.workOn)
            }
        }
    }

    private var cameraSubtitle: String {
        let n = model.rig?.cameras.filter(\.connected).count ?? 0
        let ready = model.rig?.readyCameras.count ?? 0
        return n == 0 ? "Up to \(RemoteCapture.maximumCameras) tripod iPhones running KickLab" : "\(n) connected · \(ready) ready to record"
    }

    private func cameraCard(_ c: RemoteRig.Camera) -> some View {
        CardView {
            HStack(alignment: .top) {
                Image(systemName: c.connected ? "iphone.radiowaves.left.and.right" : "iphone.slash")
                    .font(.title2).foregroundStyle(c.connected ? KickTheme.brand : .secondary)
                    .frame(width: 32)
                VStack(alignment: .leading, spacing: 4) {
                    Text(c.name).font(.headline)
                    Text(statusLine(c)).font(.caption).foregroundStyle(.secondary)
                    if let clock = clockLine(c) { Text(clock).font(.caption2).foregroundStyle(.secondary) }
                    if let w = c.status?.warning ?? c.lastProblem { Text(w).font(.caption).foregroundStyle(KickTheme.workOn) }
                    if c.incompatibleVersion != nil {
                        Text("Different KickLab version — update KickLab on both iPhones.").font(.caption).foregroundStyle(KickTheme.priority)
                    }
                    if c.otherSessionsPending > 0 {
                        Text("Has \(c.otherSessionsPending) recording\(c.otherSessionsPending == 1 ? "" : "s") for another session (open that session's Remote Cameras to receive).")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 4)
                if c.status?.phase == .recording {
                    Text("REC").font(.caption.bold()).foregroundStyle(.white).padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Capsule().fill(Color.red))
                }
            }
            HStack {
                Picker("View", selection: Binding(get: { c.role }, set: { model.setRole($0, camera: c.id) })) {
                    ForEach(SessionCameraRole.allCases, id: \.self) { Text(roleTitle($0)).tag($0) }
                }
                .pickerStyle(.segmented)
                .disabled(model.rig?.isRecording == true || !c.connected)
                if !c.connected {
                    Button("Remove") { model.forget(camera: c.id) }.font(.caption)
                }
            }
        }
    }

    private func roleTitle(_ role: SessionCameraRole) -> String {
        switch role {
        case .side: "Side"
        case .rear: "Rear"
        case .unspecified: "Other"
        }
    }

    private func statusLine(_ c: RemoteRig.Camera) -> String {
        guard c.connected else { return "Not connected — it reconnects by itself when KickLab is open on it" }
        guard let s = c.status else { return "Connected" }
        var parts = [s.phase == .recording ? "Recording \(CaptureFormat.elapsed(s.elapsed ?? 0))" : s.phase.title]
        if let sel = s.selection { parts.append(sel) }
        if let b = s.battery { parts.append("battery \(Int((b * 100).rounded()))%") }
        if let free = s.freeBytes { parts.append("\(ByteCountFormatter.string(fromByteCount: free, countStyle: .file)) free") }
        if s.pendingCount > 0 { parts.append("\(s.pendingCount) to send") }
        return parts.joined(separator: " · ")
    }

    private func clockLine(_ c: RemoteRig.Camera) -> String? {
        guard c.connected else { return nil }
        guard let e = c.clock else { return "Measuring clock…" }
        return String(format: "Clock matched to this iPhone ± %.0f ms", e.uncertainty * 1000)
    }

    // MARK: Takes

    @ViewBuilder
    private var takesSection: some View {
        let takes = model.rig?.takes ?? []
        if !takes.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionHeader(title: "Recordings", subtitle: "Each Record → Stop, from every camera")
                ForEach(Array(takes.enumerated().reversed()), id: \.element.id) { i, take in
                    CardView {
                        HStack {
                            Text("Recording \(i + 1)").font(.headline)
                            Spacer()
                            Text(takeLength(take)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                        ForEach(take.cameras, id: \.cameraID) { tc in
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text("\(tc.cameraName) · \(roleTitle(tc.role))").font(.subheadline)
                                    Spacer()
                                    Text(phaseText(tc)).font(.caption).foregroundStyle(phaseColor(tc))
                                }
                                if tc.phase == .receiving, let f = tc.transferFraction { ProgressView(value: f).tint(KickTheme.brand) }
                                if case .imported = tc.phase, let u = tc.startTotalUncertainty {
                                    Text(String(format: "Start measured ± %.0f ms", u * 1000)).font(.caption2).foregroundStyle(.secondary)
                                } else if case .imported = tc.phase {
                                    Text("Start not measured — synchronize it in Session Review").font(.caption2).foregroundStyle(KickTheme.workOn)
                                }
                            }
                        }
                        if !take.marks.isEmpty {
                            Text("\(take.marks.count) kick\(take.marks.count == 1 ? "" : "s") marked").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                if waitingOnBetterView {
                    Toggle("Add videos that have arrived without waiting", isOn: Binding(get: { model.forceImport }, set: { model.forceImport = $0 }))
                        .font(.footnote)
                    Text("The first video added becomes Camera A (the side view is best). Turn this on only if the side camera won't send its video.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
    }

    private var waitingOnBetterView: Bool {
        guard let rig = model.rig, !model.forceImport else { return false }
        let hasSources = !(model.manifest?.sources.isEmpty ?? true)
        return !hasSources && rig.importable(sessionHasSources: false).isEmpty && !rig.importable(sessionHasSources: false, force: true).isEmpty
    }

    private func takeLength(_ take: RemoteRig.Take) -> String {
        guard let end = take.stoppedAt else { return "recording" }
        return CaptureFormat.elapsed(max(0, end.timeIntervalSince(take.startedAt)))
    }

    private func phaseText(_ tc: RemoteRig.TakeCamera) -> String {
        switch tc.phase {
        case .starting: "Starting…"
        case .recording: "Recording"
        case .saving: "Saving on the camera…"
        case .waitingForFile: "Waiting to send"
        case .receiving: "Receiving \(Int(((tc.transferFraction ?? 0) * 100).rounded()))%"
        case .received: "Received — adding"
        case .imported: "In the session"
        case .failed(let why): why
        }
    }

    private func phaseColor(_ tc: RemoteRig.TakeCamera) -> Color {
        switch tc.phase {
        case .imported: KickTheme.strength
        case .failed: KickTheme.priority
        case .recording: Color.red
        default: Color.secondary
        }
    }

    private var howItWorks: some View {
        Text("The cameras record on their own storage and send each video here when you press Stop, over a direct Wi-Fi link between the phones (no internet). Their clocks are matched to this iPhone, so the angles line up automatically; you can still fine-tune in Session Review. Keep KickLab open on every phone until the videos have arrived.")
            .font(.caption).foregroundStyle(.secondary)
    }

    // MARK: Controls

    private var controls: some View {
        let recording = model.rig?.isRecording == true
        return HStack(spacing: 16) {
            Button {
                model.markKick()
            } label: {
                Label("Mark Kick", systemImage: "flag.fill").frame(minWidth: 100)
            }
            .buttonStyle(.bordered)
            .disabled(!recording)
            Button {
                if recording { model.stopRecording() } else { model.record() }
            } label: {
                ZStack {
                    Circle().stroke(Color.primary.opacity(0.25), lineWidth: 4).frame(width: 78, height: 78)
                    if recording {
                        RoundedRectangle(cornerRadius: 6).fill(Color.red).frame(width: 30, height: 30)
                    } else {
                        Circle().fill(Color.red).frame(width: 64, height: 64)
                    }
                }
            }
            .accessibilityLabel(recording ? "Stop all cameras" : "Record on all cameras")
            .disabled(!recording && (model.rig?.readyCameras.isEmpty ?? true))
            VStack(spacing: 2) {
                Text(recording ? "REC" : "\(model.rig?.readyCameras.count ?? 0) ready").font(.headline.monospacedDigit())
                    .foregroundStyle(recording ? Color.red : Color.primary)
                Text(recording ? "all cameras" : "camera\((model.rig?.readyCameras.count ?? 0) == 1 ? "" : "s")").font(.caption2).foregroundStyle(.secondary)
            }
            .frame(minWidth: 100)
        }
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(.bar)
    }

    private func banner(_ text: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.black).padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.yellow))
    }
}
