import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

// Build 22: the Kick Breakdown — the top of the Kick Report. A grade you can trust (what it
// rests on is written under it), a strip of the six phases, the coach's read, ONE priority
// fix (or why there is none), then a card per phase: the real video frame with the tracked
// skeleton, the status, the measurement that explains it against its provisional target,
// and the other measurements of that phase. Every word and number comes from
// `KickBreakdown`, whose consistency rules are tested (KickBreakdownTests).

struct KickBreakdownView: View {
    let breakdown: KickBreakdown
    let videoURL: URL?
    let frames: [Double: PhaseFrame]
    /// Opens the video (the report's "Review Video").
    var playVideo: (() -> Void)?

    var body: some View {
        ScrollViewReader { proxy in
            VStack(alignment: .leading, spacing: 12) {
                gradeCard(proxy)
                coachCard
                fixCard
                ForEach(breakdown.phases) { card in
                    PhaseCardView(card: card, videoURL: videoURL, frame: card.frameTime.flatMap { frames[$0] }, playVideo: playVideo)
                        .id(card.phase)
                }
            }
        }
    }

    // MARK: Grade

    private func gradeCard(_ proxy: ScrollViewProxy) -> some View {
        let g = breakdown.grade
        let color = g.label?.color ?? KickTheme.notGraded
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 16) {
                GradeRing(score: g.score, color: color)
                VStack(alignment: .leading, spacing: 3) {
                    Text(g.label?.title ?? "Not graded").font(.title2.bold()).foregroundStyle(g.label == nil ? Color.primary : color)
                    Text(g.score == nil ? "Measured, not graded" : "Technique · provisional").font(.subheadline).foregroundStyle(.secondary)
                    Text(g.basis.components(separatedBy: " · ").first ?? g.basis).font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .accessibilityElement(children: .combine)
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 6) { chips }
                VStack(alignment: .leading, spacing: 6) { chips }
            }
            HStack(spacing: 4) {
                ForEach(breakdown.phases) { card in
                    Button {
                        withAnimation { proxy.scrollTo(card.phase, anchor: .top) }
                    } label: {
                        VStack(spacing: 4) {
                            Capsule().fill(KickTheme.color(card.status)).frame(height: 8)
                            Text(card.phase == .followThrough ? "Finish" : card.phase.title)
                                .font(.caption2.weight(.semibold)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8)
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(card.phase.title): \(card.status.title)")
                    .accessibilityHint("Shows this phase")
                }
            }
        }
        .breakdownCard()
    }

    @ViewBuilder
    private var chips: some View {
        chip(breakdown.contactText.prefix(1).uppercased() + breakdown.contactText.dropFirst(), symbol: "scope")
        chip(breakdown.viewText, symbol: "video")
    }

    private func chip(_ text: String, symbol: String) -> some View {
        Label(text, systemImage: symbol)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 9).padding(.vertical, 4)
            .background(Capsule().fill(Color.secondary.opacity(0.12)))
    }

    // MARK: Coach and fix

    private var coachCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("COACH’S READ").font(.caption.weight(.bold)).foregroundStyle(.secondary)
            Text(breakdown.coachSummary).font(.subheadline)
        }
        .breakdownCard()
        .accessibilityElement(children: .combine)
    }

    @ViewBuilder
    private var fixCard: some View {
        if let p = breakdown.priority {
            VStack(alignment: .leading, spacing: 8) {
                Text("PRIORITY FIX · \(p.phase.title.uppercased())").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                Text(p.cue).font(.headline)
                fixRow("Why", p.observed)
                if let drill = p.drillTitle {
                    if let id = p.drillID {
                        NavigationLink(value: AppRoute.drill(id)) { fixRow("Drill", drill, bold: true, chevron: true) }
                            .buttonStyle(.plain)
                    } else {
                        fixRow("Drill", drill, bold: true)
                    }
                }
                fixRow("Next kick", p.checkNextKick)
            }
            .breakdownCard(accent: KickTheme.workOn)
        } else {
            let graded = breakdown.phases.contains { $0.status.isGraded }
            VStack(alignment: .leading, spacing: 8) {
                Text(graded ? "NO FIX NEEDED" : "NO CORRECTION FROM THIS VIDEO").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                if let text = breakdown.noPriorityText { Text(text).font(.subheadline) }
                if let w = breakdown.watch {
                    fixRow("Watch", String(w.text.dropFirst("Watch: ".count)))
                }
            }
            .breakdownCard(accent: graded ? KickTheme.strength : KickTheme.notGraded)
            .accessibilityElement(children: .combine)
        }
    }

    private func fixRow(_ key: String, _ value: String, bold: Bool = false, chevron: Bool = false) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(key).font(.caption.weight(.semibold)).foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
            Text(value).font(.subheadline.weight(bold ? .semibold : .regular)).frame(maxWidth: .infinity, alignment: .leading)
            if chevron { Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary) }
        }
        .accessibilityElement(children: .combine)
    }
}

extension View {
    /// The rounded card used by the breakdown, with an optional accent edge.
    func breakdownCard(accent: Color? = nil) -> some View {
        frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.secondary.opacity(0.09)))
            .overlay(alignment: .leading) {
                if let accent {
                    RoundedRectangle(cornerRadius: 2).fill(accent).frame(width: 4).padding(.vertical, 12)
                }
            }
    }
}

/// The score in a ring that fills to the score (empty and "—" when not graded).
struct GradeRing: View {
    let score: Int?
    let color: Color
    @ScaledMetric(relativeTo: .largeTitle) private var size: CGFloat = 96

    var body: some View {
        ZStack {
            Circle().stroke(KickTheme.track, lineWidth: 10)
            Circle()
                .trim(from: 0, to: CGFloat(min(100, max(0, score ?? 0))) / 100)
                .stroke(color, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                .rotationEffect(.degrees(-90))
            VStack(spacing: 0) {
                Text(score.map(String.init) ?? "—").font(.system(size: size * 0.34, weight: .bold)).monospacedDigit()
                Text(score == nil ? "not graded" : "of 100").font(.caption2).foregroundStyle(.secondary)
            }
        }
        .frame(width: size, height: size)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(score.map { "Technique score \($0) of 100" } ?? "Not graded")
    }
}

/// One phase.
struct PhaseCardView: View {
    let card: KickBreakdown.PhaseCard
    let videoURL: URL?
    let frame: PhaseFrame?
    var playVideo: (() -> Void)?
    @State private var showsMore: Bool

    init(card: KickBreakdown.PhaseCard, videoURL: URL?, frame: PhaseFrame?, playVideo: (() -> Void)?) {
        self.card = card
        self.videoURL = videoURL
        self.frame = frame
        self.playVideo = playVideo
        // Open when something below is outside its target, or nothing here is graded.
        let off = card.others.contains { $0.verdict == .below || $0.verdict == .above }
        _showsMore = State(initialValue: off || !card.status.isGraded)
    }

    private var compact: Bool { card.status == .notMeasured }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if !compact, let url = videoURL, let time = card.frameTime {
                PhaseFrameImage(url: url, time: time, frame: frame, caption: caption)
                    .onTapGesture { playVideo?() }
                    .accessibilityHint(playVideo == nil ? "" : "Plays the video")
            }
            VStack(alignment: .leading, spacing: 10) {
                header
                if let m = card.headline {
                    headline(m)
                    if let reason = card.reason { Text(reason).font(.subheadline).foregroundStyle(.secondary) }
                    if !card.others.isEmpty { more }
                    Text("Measurement quality: \(m.qualityText)").font(.caption2).foregroundStyle(.secondary)
                } else {
                    Text(card.reason ?? card.explanation).font(.subheadline).foregroundStyle(.secondary)
                }
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.secondary.opacity(0.09)))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var caption: String {
        [card.frameSource, card.frameTime.map { String(format: "%.2f s", $0) }].compactMap { $0 }.joined(separator: " · ")
    }

    private var header: some View {
        HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(card.phase.title).font(.title3.bold())
                Text(card.phase.subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            StatusPill(status: card.status, score: card.score)
        }
        .accessibilityElement(children: .combine)
    }

    private func headline(_ m: KickBreakdown.Measurement) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(m.name).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            Text(m.valueText).font(.title.bold()).monospacedDigit()
            targetLine(m)
            if let g = m.gauge { TargetBar(gauge: g, color: KickTheme.color(m.verdict), height: 10).padding(.top, 4) }
            Text(m.definition).font(.subheadline).padding(.top, 4)
            if let usual = m.usualText { Text("Your usual: \(usual)").font(.caption).foregroundStyle(.secondary) }
        }
        .accessibilityElement(children: .combine)
    }

    @ViewBuilder
    private func targetLine(_ m: KickBreakdown.Measurement) -> some View {
        if let t = m.targetText, m.verdict != .noTarget {
            (Text("Provisional target \(t) · ") + Text(verdictTitle(m.verdict)).bold().foregroundStyle(KickTheme.color(m.verdict)))
                .font(.caption)
                .foregroundStyle(.secondary)
        } else {
            Text("No target — compare with your own kicks").font(.caption).foregroundStyle(.secondary)
        }
    }

    private func verdictTitle(_ v: KickBreakdown.Verdict) -> String {
        switch v {
        case .inside: "Inside target"
        case .below: "Below target"
        case .above: "Above target"
        case .noTarget: "No target"
        }
    }

    private var more: some View {
        let off = card.others.filter { $0.verdict == .below || $0.verdict == .above }.count
        let title = "\(card.others.count) more measurement\(card.others.count == 1 ? "" : "s")" + (off > 0 ? " · \(off) outside target" : "")
        return DisclosureGroup(title, isExpanded: $showsMore) {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(card.others) { o in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(o.name).font(.subheadline)
                            Spacer(minLength: 8)
                            Text(o.valueText).font(.subheadline.weight(.semibold)).monospacedDigit().multilineTextAlignment(.trailing)
                        }
                        HStack(spacing: 8) {
                            if let g = o.gauge { TargetBar(gauge: g, color: KickTheme.color(o.verdict), height: 6) }
                            Text(o.targetText ?? "no target").font(.caption2.weight(.semibold)).foregroundStyle(KickTheme.color(o.verdict))
                        }
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityValue(o.verdict == .noTarget ? "No target" : "\(verdictTitle(o.verdict)), provisional target \(o.targetText ?? "")")
                }
            }
            .padding(.top, 8)
        }
        .font(.subheadline.weight(.semibold))
    }
}

/// "Strength 92" / "Not graded".
struct StatusPill: View {
    let status: KickBreakdown.Status
    let score: Int?

    var body: some View {
        let color = KickTheme.color(status)
        HStack(spacing: 5) {
            Text(status.title)
            if let score { Text("\(score)").monospacedDigit() }
        }
        .font(.caption.weight(.bold))
        .padding(.horizontal, 10).padding(.vertical, 5)
        .foregroundStyle(status.isGraded ? Color.white : color)
        .background(Capsule().fill(status.isGraded ? color : Color.clear))
        .overlay(Capsule().stroke(color, lineWidth: status.isGraded ? 0 : 1.5))
    }
}

/// A value on one scale with its provisional target zone (from `KickBreakdown.Gauge`, so
/// the dot can't sit on a different side from the verdict).
struct TargetBar: View {
    let gauge: KickBreakdown.Gauge
    let color: Color
    let height: CGFloat

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ZStack(alignment: .leading) {
                Capsule().fill(KickTheme.track)
                Rectangle().fill(KickTheme.target)
                    .frame(width: max(2, CGFloat(gauge.targetEnd - gauge.targetStart) * w))
                    .offset(x: CGFloat(gauge.targetStart) * w)
                Circle().fill(color)
                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                    .frame(width: height + 6, height: height + 6)
                    .offset(x: CGFloat(gauge.value) * w - (height + 6) / 2)
            }
        }
        .frame(height: height + 6)
        .accessibilityHidden(true)
    }
}

/// The phase's real video frame, cropped around the kicker with the tracked skeleton
/// (orange: kicking leg, blue: plant leg). The whole frame when the pose wasn't read.
struct PhaseFrameImage: View {
    let url: URL
    let time: Double
    let frame: PhaseFrame?
    let caption: String
    @State private var image: UIImage?

    var body: some View {
        Color.black
            .aspectRatio(4.0 / 3.0, contentMode: .fit)
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    ProgressView()
                }
            }
            .overlay {
                if image != nil, let frame {
                    GeometryReader { geo in
                        ForEach(Array(frame.bones.enumerated()), id: \.offset) { _, bone in
                            Path { p in
                                p.move(to: CGPoint(x: CGFloat(bone.from.x) * geo.size.width, y: CGFloat(bone.from.y) * geo.size.height))
                                p.addLine(to: CGPoint(x: CGFloat(bone.to.x) * geo.size.width, y: CGFloat(bone.to.y) * geo.size.height))
                            }
                            .stroke(color(bone.role), style: StrokeStyle(lineWidth: bone.role == .body ? 2.5 : 4, lineCap: .round))
                        }
                    }
                    .allowsHitTesting(false)
                }
            }
            .overlay(alignment: .bottomLeading) {
                Text(caption)
                    .font(.caption2.weight(.semibold)).monospacedDigit()
                    .foregroundStyle(.white)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.55)))
                    .padding(10)
            }
            .clipped()
            .contentShape(Rectangle())
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Video frame: \(caption)")
            .task(id: loadKey) {
                image = await FrameImageLoader.image(url: url, time: time, crop: frame?.crop)
            }
    }

    /// Reloads when the crop arrives (the pose is read after the report opens).
    private var loadKey: String { "\(time)|\(frame?.crop.minX ?? -1)|\(frame?.crop.minY ?? -1)" }

    private func color(_ role: PhaseFrame.Bone.Role) -> Color {
        switch role {
        case .kickingLeg: .orange
        case .plantLeg: .cyan
        case .body: .white.opacity(0.85)
        }
    }
}
