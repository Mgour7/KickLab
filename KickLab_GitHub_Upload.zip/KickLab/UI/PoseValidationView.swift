import AVKit
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Step 12C developer Pose Validation player: the analyzed video with the stored pose
/// drawn exactly over the athlete, phase markers, frame stepping and contact marking.
/// Diagnostics-only; the normal video player is unchanged.
struct PoseValidationView: View {
    @Environment(AppModel.self) private var app
    @State private var model: PoseValidationViewModel
    @State private var player: ValidationPlayer?
    @State private var selectedMarker: ValidationMarker?

    init(analysisID: UUID) {
        _model = State(initialValue: PoseValidationViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Pose Validation")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
            }
            .onDisappear { player?.stop() }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading pose data…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    videoArea(c)
                    if let player { controls(c, player: player) }
                    PhaseTimelineBar(timeline: c.timeline, currentTime: player?.currentTime ?? 0) { time in player?.seek(to: time) }
                        .padding(.horizontal)
                    if let evidence = c.evidence {
                        EvidenceTimelineView(model: evidence, currentTime: player?.currentTime ?? 0) { time in player?.seek(to: time) }
                            .padding(.horizontal)
                    }
                    windowPicker(c)
                    markerBar(c)
                    if let marker = selectedMarker, let detail = marker.detail {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(marker.title).font(.subheadline.bold())
                            Text(detail).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.horizontal)
                    }
                    options(c)
                    annotation(c)
                    details(c)
                }
                .padding(.vertical)
            }
        }
    }

    // MARK: Video and overlay

    private func videoArea(_ c: PoseValidationViewModel.Content) -> some View {
        PoseVideoArea(timeline: c.timeline, player: player, source: model.source,
                      showsSkeleton: model.showsSkeleton, showsConfidence: model.showsConfidence,
                      showsFootball: model.showsFootball, zoom: model.zoom)
    }

    // MARK: Controls

    private func controls(_ c: PoseValidationViewModel.Content, player: ValidationPlayer) -> some View {
        VStack(spacing: 8) {
            HStack {
                Text(String(format: "%.3f s", player.currentTime)).monospacedDigit().font(.subheadline)
                Spacer()
                if let i = c.timeline.sampleIndex(at: player.currentTime) {
                    Text("analyzed frame \(i + 1) of \(c.timeline.timestamps.count)").font(.caption).foregroundStyle(.secondary)
                } else {
                    Text("between analyzed frames").font(.caption).foregroundStyle(.secondary)
                }
            }
            Slider(value: Binding(get: { player.currentTime }, set: { player.seek(to: $0) }),
                   in: 0...max(0.01, c.timeline.timestamps.last ?? 0.01))
                .accessibilityLabel("Video position")
            HStack(spacing: 16) {
                Button { player.stepSourceFrame(-1) } label: { Label("Back one video frame", systemImage: "chevron.backward") }
                Button { step(c, player, -1) } label: { Label("Back one analyzed frame", systemImage: "backward.frame") }
                Button {
                    player.isPlaying ? player.pause() : player.play(rate: model.playbackRate)
                } label: {
                    Label(player.isPlaying ? "Pause" : "Play", systemImage: player.isPlaying ? "pause.fill" : "play.fill")
                }
                Button { step(c, player, 1) } label: { Label("Forward one analyzed frame", systemImage: "forward.frame") }
                Button { player.stepSourceFrame(1) } label: { Label("Forward one video frame", systemImage: "chevron.forward") }
                Spacer()
                Picker("Speed", selection: $model.playbackRate) {
                    ForEach(PoseValidationViewModel.playbackRates, id: \.self) { rate in
                        Text(rate == 1 ? "1×" : String(format: "%.2g×", rate)).tag(rate)
                    }
                }
                .onChange(of: model.playbackRate) { _, rate in if player.isPlaying { player.play(rate: rate) } }
            }
            .labelStyle(.iconOnly)
            .frame(minHeight: 44)
        }
        .padding(.horizontal)
    }

    /// Steps between analyzed frames using their stored timestamps (no drift).
    private func step(_ c: PoseValidationViewModel.Content, _ player: ValidationPlayer, _ delta: Int) {
        guard let time = c.timeline.steppedTime(from: player.currentTime, by: delta) else { return }
        player.seek(to: time)
    }

    private func markerBar(_ c: PoseValidationViewModel.Content) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(c.timeline.markers) { marker in
                    Button(marker.title) {
                        player?.seek(to: marker.time)
                        selectedMarker = marker
                    }
                        .buttonStyle(.bordered)
                        .frame(minHeight: 36)
                        .accessibilityHint("Jumps the video to \(marker.title.lowercased())")
                }
            }
            .padding(.horizontal)
        }
    }

    @ViewBuilder
    private func windowPicker(_ c: PoseValidationViewModel.Content) -> some View {
        if let windows = c.timeline.kickWindows, windows.windows.count > 1 {
            VStack(alignment: .leading, spacing: 4) {
                Picker("Kick window", selection: Binding(get: { c.shownWindow ?? 0 }, set: { model.showKickWindow($0) })) {
                    ForEach(Array(windows.windows.enumerated()), id: \.offset) { i, w in
                        Text(String(format: "%.1f–%.1f s%@", w.preparationStart, w.movementEnd, w.hasSwing ? "" : " (no kick)")).tag(i)
                    }
                }
                Text(windows.needsSelection ? "Several kicks were found. Showing the phases the current detector finds in the chosen window (nothing is saved)."
                     : "Other movements were not treated as kicks. Choose one to see what the detector finds there (nothing is saved).")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(.horizontal)
        }
    }

    private func options(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Toggle("Show skeleton", isOn: $model.showsSkeleton)
            Toggle("Show confidence", isOn: $model.showsConfidence)
            if let ball = c.timeline.football {
                Toggle("Show football", isOn: $model.showsFootball)
                Picker("Zoom on the ball", selection: $model.zoom) {
                    ForEach(PoseValidationViewModel.zoomLevels, id: \.self) { Text(String(format: "%.0f×", $0)).tag($0) }
                }
                .pickerStyle(.segmented)
                Text(ball.summary).font(.caption)
                Text("Football: green box = at rest (detected), dashed yellow = obscured or matched by appearance only, orange = moving (detected), grey = another football, white dashed = resting spot; orange dots = the moving ball's detected positions (no positions are filled in). Wrong ball? Use Verify Contact to mark the right one.")
                    .font(.caption).foregroundStyle(.secondary)
            } else {
                Text("Football: the detector didn't run for this analysis (analyzed before Step 12G, user-assisted, or no detector on this device).")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Picker("Pose", selection: $model.source) {
                ForEach(c.timeline.availableSources, id: \.self) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text("Timeline: yellow = kick window, blue = approach, cyan = plant, red = contact, orange = follow-through, green = recovery. Solid = detected, faded = estimated, outlined = ambiguous; grey ticks are rejected contact candidates (tap one for its evidence). Orange = kicking leg, blue = plant leg. Filled dots were measured, hollow dots filled in; faint dots are low confidence. A yellow ring marks a joint changed by leg repair.")
                .font(.caption).foregroundStyle(.secondary)
            ForEach(c.timeline.limitations, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
        }
        .padding(.horizontal)
    }

    private func annotation(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Contact check").font(.headline)
            Text("Step to the frame where the foot meets the ball, then mark it. This is evaluation data only: it never changes the automatic estimate or any score.")
                .font(.caption).foregroundStyle(.secondary)
            HStack {
                Button("Mark This Frame as Contact") {
                    guard let player else { return }
                    let time = c.timeline.steppedTime(from: player.currentTime, by: 0) ?? player.currentTime
                    Task { await model.markContact(at: time, app: app) }
                }
                .buttonStyle(.borderedProminent)
                .frame(minHeight: 44)
                if model.markedContact != nil {
                    Button("Clear", role: .destructive) { Task { await model.markContact(at: nil, app: app) } }
                        .frame(minHeight: 44)
                }
            }
            if let marked = model.markedContact {
                LabeledContent("Marked contact", value: String(format: "%.3f s", marked)).font(.subheadline)
            }
            if let estimate = c.estimatedContact {
                LabeledContent("Estimated contact", value: String(format: "%.3f s", estimate)).font(.subheadline)
            }
            if let comparison = model.comparison { Text(comparison.text).font(.subheadline) }
            if let error = model.annotationError { Text(error).font(.caption).foregroundStyle(.red) }
        }
        .padding(.horizontal)
    }

    private func details(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Engine \(c.engineVersion ?? "—") · detector \(c.algorithmVersion ?? "—")").font(.caption)
            Text(String(format: "Source %@ fps · analyzed %.0f fps · %@",
                        c.sourceFrameRate.map { String(format: "%.0f", $0) } ?? "—", 1 / c.timeline.sampleInterval,
                        c.timeline.isMirrored ? "mirrored video" : "not mirrored"))
                .font(.caption)
        }
        .foregroundStyle(.secondary)
        .padding(.horizontal)
    }
}

/// The video with the skeleton over it (shared by Pose Validation and user-assisted
/// selection). The overlay uses the same aspect-fit rectangle as the player layer.
struct PoseVideoArea: View {
    let timeline: PoseValidationTimeline
    let player: ValidationPlayer?
    let source: PoseOverlaySource
    let showsSkeleton: Bool
    let showsConfidence: Bool
    var showsFootball: Bool = false
    var zoom: Double = 1

    var body: some View {
        let aspect = timeline.displayAspectRatio
        GeometryReader { geometry in
            let w = Double(geometry.size.width), h = Double(geometry.size.height)
            let rect = PoseOverlayGeometry.aspectFitRect(containerWidth: w, containerHeight: h, contentAspect: aspect)
            // Zoom around the football's resting spot (in the container's unit space).
            let anchor = timeline.football?.rest.map {
                UnitPoint(x: (rect.x + $0.cx * rect.width) / max(w, 1), y: (rect.y + $0.cy * rect.height) / max(h, 1))
            } ?? .center
            content(aspect: aspect)
                .scaleEffect(CGFloat(zoom), anchor: anchor)
        }
        .clipped()
        .frame(height: 420)
        .accessibilityLabel("Video with body skeleton overlay")
    }

    @ViewBuilder
    private func content(aspect: Double) -> some View {
        ZStack {
            Color.black
            if let player {
                ValidationVideoSurface(player: player.player)
            } else {
                Text("The video file isn't on this device. The pose is shown on its own.")
                    .font(.footnote).foregroundStyle(.white).padding()
            }
            if showsSkeleton {
                GeometryReader { geometry in
                    let rect = PoseOverlayGeometry.aspectFitRect(
                        containerWidth: Double(geometry.size.width), containerHeight: Double(geometry.size.height), contentAspect: aspect
                    )
                    SkeletonOverlay(timeline: timeline, time: player?.currentTime ?? 0, source: source,
                                    rect: rect, showsConfidence: showsConfidence)
                }
                .allowsHitTesting(false)
            }
            if showsFootball, let ball = timeline.football {
                GeometryReader { geometry in
                    let rect = PoseOverlayGeometry.aspectFitRect(
                        containerWidth: Double(geometry.size.width), containerHeight: Double(geometry.size.height), contentAspect: aspect
                    )
                    FootballOverlayView(model: ball, time: player?.currentTime ?? 0, frame: timeline.sampleInterval, rect: rect)
                }
                .allowsHitTesting(false)
            }
        }
    }
}

/// Step 12G: the football as the detector saw it on the current frame, its resting spot
/// and the observed path. Frames without an observation draw no box.
struct FootballOverlayView: View {
    let model: FootballOverlayModel
    let time: Double
    let frame: Double
    let rect: OverlayRect

    var body: some View {
        ZStack {
            if let rest = model.rest {
                Rectangle()
                    .stroke(Color.white.opacity(0.7), style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
                    .frame(width: width(rest), height: height(rest))
                    .position(point(rest.cx, rest.cy))
            }
            let path = model.path(upTo: time)
            ForEach(Array(path.enumerated()), id: \.offset) { _, p in
                Circle().fill(Color.orange).frame(width: 6, height: 6).position(point(p.x, p.y))
            }
            if let b = model.box(at: time, frame: frame) {
                Rectangle()
                    .stroke(color(b.state), style: StrokeStyle(lineWidth: 2, dash: b.dashed ? [5, 3] : []))
                    .frame(width: width(b.box), height: height(b.box))
                    .position(point(b.box.cx, b.box.cy))
                Text(b.label)
                    .font(.caption2.bold())
                    .foregroundStyle(.white)
                    .padding(2)
                    .background(Color.black.opacity(0.6))
                    .position(point(b.box.cx, b.box.cy - b.box.h / 2 - 0.015))
            }
        }
    }

    private func point(_ x: Double, _ y: Double) -> CGPoint {
        let p = PoseOverlayGeometry.point(x: x, y: y, in: rect)
        return CGPoint(x: p.x, y: p.y)
    }

    private func width(_ b: NormalizedBox) -> CGFloat { CGFloat(max(4, b.w * rect.width)) }
    private func height(_ b: NormalizedBox) -> CGFloat { CGFloat(max(4, b.h * rect.height)) }

    private func color(_ s: FootballFrameState) -> Color {
        switch s {
        case .atRest: .green
        case .obscured: .yellow
        case .moving: .orange
        case .otherFootball: .gray
        case .notSeen: .clear
        }
    }
}

/// Step 12D: the phase timeline — kick window, phases (solid = detected, light =
/// estimated, dashed = ambiguous), recovery, candidate and marked-contact ticks, and the
/// playhead. Tap to seek.
struct PhaseTimelineBar: View {
    let timeline: PoseValidationTimeline
    let currentTime: Double
    let seek: (Double) -> Void

    var body: some View {
        GeometryReader { geometry in
            let width = Double(geometry.size.width)
            let duration = timeline.duration
            ZStack(alignment: .topLeading) {
                Rectangle().fill(Color.gray.opacity(0.15)).frame(height: 44)
                ForEach(timeline.segments) { segment in
                    let x = PhaseTimelineModel.fraction(segment.start, duration: duration) * width
                    let w = max(3, (PhaseTimelineModel.fraction(segment.end, duration: duration) * width) - x)
                    segmentShape(segment)
                        .frame(width: CGFloat(w), height: segment.kind == .kickWindow ? 44 : 14)
                        .offset(x: CGFloat(x), y: CGFloat(segment.kind == .kickWindow ? 0 : row(segment.kind)))
                }
                ForEach(timeline.markers) { marker in
                    Rectangle().fill(markerColor(marker.kind))
                        .frame(width: 2, height: 44)
                        .offset(x: CGFloat(PhaseTimelineModel.fraction(marker.time, duration: duration) * width), y: 0)
                }
                Rectangle().fill(Color.primary)
                    .frame(width: 2, height: 52)
                    .offset(x: CGFloat(PhaseTimelineModel.fraction(currentTime, duration: duration) * width), y: -4)
            }
            .contentShape(Rectangle())
            .onTapGesture { location in
                seek(Double(location.x) / max(1, width) * duration)
            }
        }
        .frame(height: 52)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(accessibilityText)
    }

    private var accessibilityText: String {
        let parts = timeline.segments.filter { $0.kind != .kickWindow }.map {
            "\($0.title) \(String(format: "%.2f", $0.start)) to \(String(format: "%.2f", $0.end)) seconds\($0.status.map { ", \($0.rawValue)" } ?? "")"
        }
        return "Phase timeline. " + parts.joined(separator: "; ")
    }

    private func row(_ kind: TimelineSegment.Kind) -> Double {
        switch kind {
        case .setup, .plant, .followThrough: 4
        case .approach, .contact, .recovery: 24
        case .kickWindow: 0
        }
    }

    @ViewBuilder
    private func segmentShape(_ segment: TimelineSegment) -> some View {
        let color = segmentColor(segment.kind)
        switch PhaseTimelineModel.style(segment.status) {
        case "solid": Rectangle().fill(color)
        case "light": Rectangle().fill(color.opacity(0.45))
        case "dashed": Rectangle().stroke(color, lineWidth: 2)
        case "outline": Rectangle().fill(color.opacity(segment.kind == .kickWindow ? 0.12 : 0.3))
        default: EmptyView()
        }
    }

    private func segmentColor(_ kind: TimelineSegment.Kind) -> Color {
        switch kind {
        case .kickWindow: .yellow
        case .setup: .gray
        case .approach: .blue
        case .plant: .cyan
        case .contact: .red
        case .followThrough: .orange
        case .recovery: .green
        }
    }

    private func markerColor(_ kind: ValidationMarkerKind) -> Color {
        switch kind {
        case .contact: .red
        case .contactCandidate: .gray
        case .plant: .cyan
        case .followThroughEnd: .orange
        case .markedContact: .green
        case .storedContact: .yellow
        case .ballLastAtRest: .mint
        case .ballFirstMovement: .pink
        }
    }
}

/// The skeleton for the analyzed frame nearest the current time.
struct SkeletonOverlay: View {
    let timeline: PoseValidationTimeline
    let time: Double
    let source: PoseOverlaySource
    let rect: OverlayRect
    let showsConfidence: Bool

    var body: some View {
        let index = timeline.sampleIndex(at: time)
        let joints = index.map { timeline.overlay(at: $0, source: source) } ?? []
        let byJoint = Dictionary(uniqueKeysWithValues: joints.map { ($0.joint, $0) })
        ZStack {
            ForEach(Array(timeline.bones().enumerated()), id: \.offset) { _, bone in
                if let a = byJoint[bone.from], let b = byJoint[bone.to] {
                    Path { path in
                        path.move(to: cgPoint(a))
                        path.addLine(to: cgPoint(b))
                    }
                    .stroke(color(bone.role), lineWidth: bone.role == .kickingLeg || bone.role == .plantLeg ? 4 : 2)
                }
            }
            ForEach(joints, id: \.joint) { joint in
                jointDot(joint)
            }
        }
    }

    @ViewBuilder
    private func jointDot(_ j: OverlayJoint) -> some View {
        let size: CGFloat = j.role == .kickingLeg || j.role == .plantLeg ? 10 : 7
        let opacity = showsConfidence ? max(0.25, min(1, j.confidence)) : 1
        ZStack {
            if j.status == .interpolated {
                Circle().stroke(color(j.role), lineWidth: 2).frame(width: size, height: size)
            } else {
                Circle().fill(color(j.role)).frame(width: size, height: size)
            }
            if j.repaired {
                Circle().stroke(Color.yellow, lineWidth: 2).frame(width: size + 8, height: size + 8)
            }
            if j.joint == .leftAnkle || j.joint == .rightAnkle {
                Text(j.joint == .leftAnkle ? "L" : "R").font(.caption2.bold()).foregroundStyle(.white)
                    .offset(x: 12, y: 0)
            }
        }
        .opacity(opacity)
        .position(cgPoint(j))
    }

    private func cgPoint(_ j: OverlayJoint) -> CGPoint {
        let p = PoseOverlayGeometry.point(x: j.x, y: j.y, in: rect)
        return CGPoint(x: p.x, y: p.y)
    }

    private func color(_ role: OverlayLimbRole) -> Color {
        switch role {
        case .kickingLeg: .orange
        case .plantLeg: .cyan
        case .torso, .head: .white
        case .arm: .gray
        }
    }
}

/// Wraps AVPlayer for frame-accurate seeking and a time readout.
@MainActor
@Observable
final class ValidationPlayer {
    let player: AVPlayer
    private(set) var currentTime: Double = 0
    private(set) var isPlaying = false
    @ObservationIgnored private var observer: Any?

    init(url: URL) {
        player = AVPlayer(url: url)
        observer = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 1.0 / 60, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            MainActor.assumeIsolated {
                guard let self else { return }
                let seconds = time.seconds
                if seconds.isFinite { self.currentTime = seconds }
            }
        }
    }

    func play(rate: Double) {
        player.playImmediately(atRate: Float(rate))
        isPlaying = true
    }

    func pause() {
        player.pause()
        isPlaying = false
    }

    /// Exact seek (zero tolerance) to a stored timestamp.
    func seek(to seconds: Double) {
        pause()
        currentTime = seconds
        player.seek(to: CMTime(seconds: seconds, preferredTimescale: 6000), toleranceBefore: .zero, toleranceAfter: .zero)
    }

    /// Step 12D: one SOURCE video frame (the video's own frames, which can be finer than
    /// the analyzed ones), using AVFoundation's frame stepping — no time arithmetic.
    func stepSourceFrame(_ count: Int) {
        pause()
        player.currentItem?.step(byCount: count)
        let seconds = player.currentTime().seconds
        if seconds.isFinite { currentTime = seconds }
    }

    func stop() {
        pause()
        if let observer { player.removeTimeObserver(observer) }
        observer = nil
    }
}

#if canImport(UIKit)
/// An AVPlayerLayer with aspect-fit gravity, so the video rect is exactly the one
/// `PoseOverlayGeometry.aspectFitRect` computes for the overlay.
struct ValidationVideoSurface: UIViewRepresentable {
    let player: AVPlayer

    final class PlayerView: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer? { layer as? AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerView {
        let view = PlayerView()
        view.backgroundColor = .black
        view.playerLayer?.videoGravity = .resizeAspect
        view.playerLayer?.player = player
        return view
    }

    func updateUIView(_ view: PlayerView, context: Context) {
        if view.playerLayer?.player !== player { view.playerLayer?.player = player }
    }
}
#else
/// Non-UIKit fallback (Linux type-checking only).
struct ValidationVideoSurface: View {
    let player: AVPlayer
    var body: some View { VideoPlayer(player: player) }
}
#endif
