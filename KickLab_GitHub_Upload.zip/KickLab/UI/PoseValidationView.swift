import AVKit
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Step 12C developer Pose Validation player: the analyzed video with the stored pose
/// drawn exactly over the athlete, phase markers, frame stepping and contact marking.
/// Diagnostics-only; the normal video player is unchanged.
struct PoseValidationView: View {
    @Environment(AppModel.self) private var app
    @State private var model: PoseValidationViewModel
    @State private var player: ValidationPlayer?

    init(analysisID: UUID) {
        _model = State(initialValue: PoseValidationViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Pose Validation")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
            }
            .onDisappear { player?.stop() }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading pose data…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    videoArea(c)
                    if let player { controls(c, player: player) }
                    markerBar(c)
                    options(c)
                    annotation(c)
                    details(c)
                }
                .padding(.vertical)
            }
        }
    }

    // MARK: Video and overlay

    @ViewBuilder
    private func videoArea(_ c: PoseValidationViewModel.Content) -> some View {
        let aspect = c.timeline.displayAspectRatio
        ZStack {
            Color.black
            if let player {
                ValidationVideoSurface(player: player.player)
            } else {
                Text("The video file isn't on this device. The pose is shown on its own.")
                    .font(.footnote).foregroundStyle(.white).padding()
            }
            if model.showsSkeleton {
                GeometryReader { geometry in
                    let rect = PoseOverlayGeometry.aspectFitRect(
                        containerWidth: Double(geometry.size.width), containerHeight: Double(geometry.size.height), contentAspect: aspect
                    )
                    SkeletonOverlay(timeline: c.timeline, time: player?.currentTime ?? 0, source: model.source,
                                    rect: rect, showsConfidence: model.showsConfidence)
                }
                .allowsHitTesting(false)
            }
        }
        .frame(height: 420)
        .accessibilityLabel("Video with body skeleton overlay")
    }

    // MARK: Controls

    private func controls(_ c: PoseValidationViewModel.Content, player: ValidationPlayer) -> some View {
        VStack(spacing: 8) {
            HStack {
                Text(String(format: "%.3f s", player.currentTime)).monospacedDigit().font(.subheadline)
                Spacer()
                if let i = c.timeline.sampleIndex(at: player.currentTime) {
                    Text("analyzed frame \(i + 1) of \(c.timeline.timestamps.count)").font(.caption).foregroundStyle(.secondary)
                } else {
                    Text("between analyzed frames").font(.caption).foregroundStyle(.secondary)
                }
            }
            Slider(value: Binding(get: { player.currentTime }, set: { player.seek(to: $0) }),
                   in: 0...max(0.01, c.timeline.timestamps.last ?? 0.01))
                .accessibilityLabel("Video position")
            HStack(spacing: 16) {
                Button { step(c, player, -1) } label: { Label("Back one frame", systemImage: "backward.frame") }
                Button {
                    player.isPlaying ? player.pause() : player.play(rate: model.playbackRate)
                } label: {
                    Label(player.isPlaying ? "Pause" : "Play", systemImage: player.isPlaying ? "pause.fill" : "play.fill")
                }
                Button { step(c, player, 1) } label: { Label("Forward one frame", systemImage: "forward.frame") }
                Spacer()
                Picker("Speed", selection: $model.playbackRate) {
                    ForEach(PoseValidationViewModel.playbackRates, id: \.self) { rate in
                        Text(rate == 1 ? "1×" : String(format: "%.2g×", rate)).tag(rate)
                    }
                }
                .onChange(of: model.playbackRate) { _, rate in if player.isPlaying { player.play(rate: rate) } }
            }
            .labelStyle(.iconOnly)
            .frame(minHeight: 44)
        }
        .padding(.horizontal)
    }

    /// Steps between analyzed frames using their stored timestamps (no drift).
    private func step(_ c: PoseValidationViewModel.Content, _ player: ValidationPlayer, _ delta: Int) {
        guard let time = c.timeline.steppedTime(from: player.currentTime, by: delta) else { return }
        player.seek(to: time)
    }

    private func markerBar(_ c: PoseValidationViewModel.Content) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(c.timeline.markers) { marker in
                    Button(marker.title) { player?.seek(to: marker.time) }
                        .buttonStyle(.bordered)
                        .frame(minHeight: 36)
                        .accessibilityHint("Jumps the video to \(marker.title.lowercased())")
                }
            }
            .padding(.horizontal)
        }
    }

    private func options(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Toggle("Show skeleton", isOn: $model.showsSkeleton)
            Toggle("Show confidence", isOn: $model.showsConfidence)
            Picker("Pose", selection: $model.source) {
                ForEach(c.timeline.availableSources, id: \.self) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text("Orange = kicking leg, blue = plant leg. Filled dots were measured, hollow dots filled in; faint dots are low confidence. A yellow ring marks a joint changed by leg repair.")
                .font(.caption).foregroundStyle(.secondary)
            ForEach(c.timeline.limitations, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
        }
        .padding(.horizontal)
    }

    private func annotation(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Contact check").font(.headline)
            Text("Step to the frame where the foot meets the ball, then mark it. This is evaluation data only: it never changes the automatic estimate or any score.")
                .font(.caption).foregroundStyle(.secondary)
            HStack {
                Button("Mark This Frame as Contact") {
                    guard let player else { return }
                    let time = c.timeline.steppedTime(from: player.currentTime, by: 0) ?? player.currentTime
                    Task { await model.markContact(at: time, app: app) }
                }
                .buttonStyle(.borderedProminent)
                .frame(minHeight: 44)
                if model.markedContact != nil {
                    Button("Clear", role: .destructive) { Task { await model.markContact(at: nil, app: app) } }
                        .frame(minHeight: 44)
                }
            }
            if let marked = model.markedContact {
                LabeledContent("Marked contact", value: String(format: "%.3f s", marked)).font(.subheadline)
            }
            if let estimate = c.estimatedContact {
                LabeledContent("Estimated contact", value: String(format: "%.3f s", estimate)).font(.subheadline)
            }
            if let comparison = model.comparison { Text(comparison.text).font(.subheadline) }
            if let error = model.annotationError { Text(error).font(.caption).foregroundStyle(.red) }
        }
        .padding(.horizontal)
    }

    private func details(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Engine \(c.engineVersion ?? "—") · detector \(c.algorithmVersion ?? "—")").font(.caption)
            Text(String(format: "Source %@ fps · analyzed %.0f fps · %@",
                        c.sourceFrameRate.map { String(format: "%.0f", $0) } ?? "—", 1 / c.timeline.sampleInterval,
                        c.timeline.isMirrored ? "mirrored video" : "not mirrored"))
                .font(.caption)
        }
        .foregroundStyle(.secondary)
        .padding(.horizontal)
    }
}

/// The skeleton for the analyzed frame nearest the current time.
struct SkeletonOverlay: View {
    let timeline: PoseValidationTimeline
    let time: Double
    let source: PoseOverlaySource
    let rect: OverlayRect
    let showsConfidence: Bool

    var body: some View {
        let index = timeline.sampleIndex(at: time)
        let joints = index.map { timeline.overlay(at: $0, source: source) } ?? []
        let byJoint = Dictionary(uniqueKeysWithValues: joints.map { ($0.joint, $0) })
        ZStack {
            ForEach(Array(timeline.bones().enumerated()), id: \.offset) { _, bone in
                if let a = byJoint[bone.from], let b = byJoint[bone.to] {
                    Path { path in
                        path.move(to: cgPoint(a))
                        path.addLine(to: cgPoint(b))
                    }
                    .stroke(color(bone.role), lineWidth: bone.role == .kickingLeg || bone.role == .plantLeg ? 4 : 2)
                }
            }
            ForEach(joints, id: \.joint) { joint in
                jointDot(joint)
            }
        }
    }

    @ViewBuilder
    private func jointDot(_ j: OverlayJoint) -> some View {
        let size: CGFloat = j.role == .kickingLeg || j.role == .plantLeg ? 10 : 7
        let opacity = showsConfidence ? max(0.25, min(1, j.confidence)) : 1
        ZStack {
            if j.status == .interpolated {
                Circle().stroke(color(j.role), lineWidth: 2).frame(width: size, height: size)
            } else {
                Circle().fill(color(j.role)).frame(width: size, height: size)
            }
            if j.repaired {
                Circle().stroke(Color.yellow, lineWidth: 2).frame(width: size + 8, height: size + 8)
            }
            if j.joint == .leftAnkle || j.joint == .rightAnkle {
                Text(j.joint == .leftAnkle ? "L" : "R").font(.caption2.bold()).foregroundStyle(.white)
                    .offset(x: 12, y: 0)
            }
        }
        .opacity(opacity)
        .position(cgPoint(j))
    }

    private func cgPoint(_ j: OverlayJoint) -> CGPoint {
        let p = PoseOverlayGeometry.point(x: j.x, y: j.y, in: rect)
        return CGPoint(x: p.x, y: p.y)
    }

    private func color(_ role: OverlayLimbRole) -> Color {
        switch role {
        case .kickingLeg: .orange
        case .plantLeg: .cyan
        case .torso, .head: .white
        case .arm: .gray
        }
    }
}

/// Wraps AVPlayer for frame-accurate seeking and a time readout.
@MainActor
@Observable
final class ValidationPlayer {
    let player: AVPlayer
    private(set) var currentTime: Double = 0
    private(set) var isPlaying = false
    @ObservationIgnored private var observer: Any?

    init(url: URL) {
        player = AVPlayer(url: url)
        observer = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 1.0 / 60, preferredTimescale: 600), queue: .main
        ) { [weak self] time in
            MainActor.assumeIsolated {
                guard let self else { return }
                let seconds = time.seconds
                if seconds.isFinite { self.currentTime = seconds }
            }
        }
    }

    func play(rate: Double) {
        player.playImmediately(atRate: Float(rate))
        isPlaying = true
    }

    func pause() {
        player.pause()
        isPlaying = false
    }

    /// Exact seek (zero tolerance) to a stored timestamp.
    func seek(to seconds: Double) {
        pause()
        currentTime = seconds
        player.seek(to: CMTime(seconds: seconds, preferredTimescale: 6000), toleranceBefore: .zero, toleranceAfter: .zero)
    }

    func stop() {
        pause()
        if let observer { player.removeTimeObserver(observer) }
        observer = nil
    }
}

#if canImport(UIKit)
/// An AVPlayerLayer with aspect-fit gravity, so the video rect is exactly the one
/// `PoseOverlayGeometry.aspectFitRect` computes for the overlay.
struct ValidationVideoSurface: UIViewRepresentable {
    let player: AVPlayer

    final class PlayerView: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer? { layer as? AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerView {
        let view = PlayerView()
        view.backgroundColor = .black
        view.playerLayer?.videoGravity = .resizeAspect
        view.playerLayer?.player = player
        return view
    }

    func updateUIView(_ view: PlayerView, context: Context) {
        if view.playerLayer?.player !== player { view.playerLayer?.player = player }
    }
}
#else
/// Non-UIKit fallback (Linux type-checking only).
struct ValidationVideoSurface: View {
    let player: AVPlayer
    var body: some View { VideoPlayer(player: player) }
}
#endif
