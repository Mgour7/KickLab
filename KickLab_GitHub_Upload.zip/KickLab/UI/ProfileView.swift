import PhotosUI
import SwiftUI

/// Athletes: switch, add, edit and delete.
struct ProfileView: View {
    @Environment(AppModel.self) private var app
    @State private var editingAthleteID: EditTarget?
    @State private var deletingAthleteID: UUID?

    init() {}

    /// Sheet target: a new athlete or an existing one.
    struct EditTarget: Identifiable, Hashable {
        let athleteID: UUID?
        var id: String { athleteID?.uuidString ?? "new" }
    }

    var body: some View {
        List {
            Section {
                ForEach(app.athletes) { athlete in
                    Button {
                        app.select(athlete.id)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(athlete.displayTitle).font(.headline)
                                Text(athlete.detailLine)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if athlete.id == app.selectedAthleteID {
                                Image(systemName: "checkmark.circle.fill")
                                    .accessibilityLabel("Selected")
                            }
                        }
                        .frame(minHeight: 44)
                    }
                    .buttonStyle(.plain)
                    .swipeActions {
                        Button(role: .destructive) { deletingAthleteID = athlete.id } label: {
                            Label("Delete", systemImage: "trash")
                        }
                        Button { editingAthleteID = EditTarget(athleteID: athlete.id) } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                        .tint(.blue)
                        Button { archive(athlete.id) } label: {
                            Label("Archive", systemImage: "archivebox")
                        }
                        .tint(.gray)
                    }
                    .contextMenu {
                        Button { editingAthleteID = EditTarget(athleteID: athlete.id) } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                        Button { archive(athlete.id) } label: {
                            Label("Archive (keeps all history)", systemImage: "archivebox")
                        }
                        Button(role: .destructive) { deletingAthleteID = athlete.id } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                }
                Button {
                    editingAthleteID = EditTarget(athleteID: nil)
                } label: {
                    Label("Add Athlete", systemImage: "person.badge.plus")
                }
            } header: {
                Text("Athletes")
            } footer: {
                Text("Tap an athlete to switch. Swipe to edit, archive or delete. Archiving hides an athlete but keeps every kick, session and analysis.")
            }
            if !archived.isEmpty {
                Section("Archived") {
                    ForEach(archived) { athlete in
                        HStack {
                            Text(athlete.name).foregroundStyle(.secondary)
                            Spacer()
                            Button("Restore") { restore(athlete.id) }
                                .frame(minHeight: 44)
                        }
                    }
                }
            }
            Section("Recording") {
                NavigationLink(value: AppRoute.captureGuide) {
                    Label("How to Film a Kick", systemImage: "video.badge.checkmark")
                }
            }
            Section("Privacy") {
                Text("Videos and analyses stay on this iPhone. KickLab measures body position and looks for the football; it does not recognize faces or identify people.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                NavigationLink(value: AppRoute.acknowledgements) {
                    Label("Acknowledgements", systemImage: "doc.text")
                }
            }
            Section {
                Toggle("Analysis diagnostics", isOn: Bindable(app).showsAnalysisDiagnostics)
                    .frame(minHeight: 44)
            } header: {
                Text("Developer")
            } footer: {
                Text("Adds a Diagnostics screen to analysis results and failed analyses: frame counts, joint confidence, phases and why each measurement was or wasn't available. It can be copied or shared as text and contains no images or names.")
            }
        }
        .navigationTitle("Profile")
        .task(id: app.revision) { loadArchived() }
        .alert("Couldn't change the athlete", isPresented: Binding(get: { archiveError != nil }, set: { if !$0 { archiveError = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(archiveError ?? "")
        }
        .sheet(item: $editingAthleteID) { target in
            AthleteEditorView(athleteID: target.athleteID)
        }
        .sheet(item: deletingBinding) { target in
            AthleteDeletionView(athleteID: target.id)
        }
    }

    @State private var archived: [AthleteSummary] = []
    @State private var archiveError: String?

    private func loadArchived() {
        archived = ((try? app.services.athletes.archivedAthletes()) ?? []).map(AthleteSummary.init(athlete:))
    }

    private func archive(_ id: UUID) {
        guard let athlete = app.athleteModel(id) else { return }
        do {
            try app.services.athletes.archive(athlete)
            app.dataDidChange()
            loadArchived()
        } catch {
            archiveError = UserFacingError.message(for: error)
        }
    }

    private func restore(_ id: UUID) {
        guard let athlete = ModelLookup.athlete(id, in: app.context) else { return }
        do {
            try app.services.athletes.restore(athlete)
            app.dataDidChange()
            loadArchived()
        } catch {
            archiveError = UserFacingError.message(for: error)
        }
    }

    private struct DeleteTarget: Identifiable {
        let id: UUID
    }

    private var deletingBinding: Binding<DeleteTarget?> {
        Binding(get: { deletingAthleteID.map(DeleteTarget.init(id:)) }, set: { deletingAthleteID = $0?.id })
    }
}

/// Create or edit an athlete: name, kicking foot and level (the fields analysis uses).
struct AthleteEditorView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let athleteID: UUID?
    @State private var model: AthleteEditorViewModel?

    init(athleteID: UUID?) {
        self.athleteID = athleteID
    }

    var body: some View {
        NavigationStack {
            Group {
                if let model {
                    AthleteEditorForm(model: model)
                } else {
                    LoadingStateView()
                }
            }
            .navigationTitle(athleteID == nil ? "New Athlete" : "Edit Athlete")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if model?.save(app: app) != nil { dismiss() }
                    }
                }
            }
        }
        .task {
            if model == nil { model = AthleteEditorViewModel(athleteID: athleteID, app: app) }
        }
    }
}

private struct AthleteEditorForm: View {
    @Bindable var model: AthleteEditorViewModel
    @State private var photoItem: PhotosPickerItem?
    @State private var photoProblem: String?

    var body: some View {
        Form {
            Section("Name") {
                TextField("First name", text: $model.firstName)
                    .textContentType(.givenName)
                TextField("Last name", text: $model.lastName)
                    .textContentType(.familyName)
                TextField("Nickname (optional)", text: $model.nickname)
            }
            Section {
                Picker("Kicking foot", selection: $model.kickingFoot) {
                    ForEach(KickingFoot.selectableCases, id: \.self) { foot in
                        Text(foot.displayName).tag(foot)
                    }
                }
                .pickerStyle(.segmented)
                Picker("Level", selection: $model.playingLevel) {
                    ForEach(PlayingLevel.selectableCases, id: \.self) { level in
                        Text(level.displayName).tag(level)
                    }
                }
                Picker("Role", selection: $model.primaryRole) {
                    Text("Not set").tag(AthleteRole?.none)
                    ForEach(AthleteRole.selectableCases, id: \.self) { role in
                        Text(role.displayName).tag(Optional(role))
                    }
                }
                Picker("Experience", selection: $model.experienceLevel) {
                    Text("Not set").tag(ExperienceLevel?.none)
                    ForEach(ExperienceLevel.selectableCases, id: \.self) { level in
                        Text(level.displayName).tag(Optional(level))
                    }
                }
            } header: {
                Text("Kicking")
            } footer: {
                Text("The kicking foot tells KickLab which leg is the kicking leg in the analysis.")
            }
            Section("Optional details") {
                TextField("Team or school", text: $model.schoolTeam)
                TextField("Graduation year", text: $model.graduationYearText)
                    .keyboardType(.numberPad)
                TextField("Birth year", text: $model.birthYearText)
                    .keyboardType(.numberPad)
                Picker("Preferred football", selection: $model.preferredBallType) {
                    Text("Not set").tag(FootballType?.none)
                    ForEach(FootballType.selectableCases, id: \.self) { ball in
                        Text(ball.displayName).tag(Optional(ball))
                    }
                }
            }
            Section {
                TextField("For example: make 40-yard field goals consistently", text: $model.goals, axis: .vertical)
                    .lineLimit(2...6)
            } header: {
                Text("Goals")
            }
            Section {
                PhotosPicker(selection: $photoItem, matching: .images) {
                    Label(model.photoData == nil ? "Add Photo" : "Change Photo", systemImage: "person.crop.circle")
                }
                .frame(minHeight: 44)
                if model.photoData != nil {
                    Button("Remove Photo", role: .destructive) { model.photoData = nil }
                        .frame(minHeight: 44)
                }
                if let photoProblem {
                    Text(photoProblem).font(.caption).foregroundStyle(.red)
                }
            } header: {
                Text("Photo (optional)")
            } footer: {
                Text("Stored only on this iPhone. KickLab never uses the photo for recognition.")
            }
            .onChange(of: photoItem) { _, item in
                guard let item else { return }
                Task {
                    let data = try? await item.loadTransferable(type: Data.self)
                    if let small = data.flatMap(ProfilePhoto.downscaled) {
                        model.photoData = small
                        photoProblem = nil
                    } else {
                        photoProblem = "That photo couldn't be used."
                    }
                }
            }
            if !model.issues.isEmpty || model.errorMessage != nil {
                Section {
                    ForEach(model.issueMessages, id: \.self) { message in
                        Text(message).foregroundStyle(.red)
                    }
                    if let error = model.errorMessage {
                        Text(error).foregroundStyle(.red)
                    }
                }
            }
        }
    }
}

/// Step 12F: profile photos are shrunk to at most 512 px and saved as JPEG.
enum ProfilePhoto {
    static let maximumSide: Double = 512

    static func downscaled(_ data: Data) -> Data? {
        guard let image = UIImage(data: data) else { return nil }
        let size = image.size
        let scale = min(1, maximumSide / max(Double(size.width), Double(size.height), 1))
        let target = CGSize(width: Double(size.width) * scale, height: Double(size.height) * scale)
        let resized = scale < 1 ? (image.preparingThumbnail(of: target) ?? image) : image
        guard let jpeg = resized.jpegData(compressionQuality: 0.8), jpeg.count <= AthleteProfileLimits.photoMaxBytes else { return nil }
        return jpeg
    }
}

/// Permanent deletion with a typed confirmation, using the service's deletion plan.
struct AthleteDeletionView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: AthleteDeletionViewModel

    init(athleteID: UUID) {
        _model = State(initialValue: AthleteDeletionViewModel(athleteID: athleteID))
    }

    var body: some View {
        NavigationStack {
            Form {
                if let plan = model.plan {
                    Section {
                        Text(model.summary)
                        Text("This can't be undone.").font(.headline)
                    }
                    Section {
                        TextField("Type \(plan.confirmationPhrase)", text: $model.typedConfirmation)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    } footer: {
                        Text("Type \"\(plan.confirmationPhrase)\" to confirm.")
                    }
                    Section {
                        Button("Delete Permanently", role: .destructive) {
                            if model.delete(app: app) { dismiss() }
                        }
                        .disabled(!model.canDelete)
                    }
                } else if model.errorMessage == nil {
                    LoadingStateView()
                }
                if let error = model.errorMessage {
                    Section { Text(error).foregroundStyle(.red) }
                }
            }
            .navigationTitle("Delete Athlete")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
            .task { model.prepare(app: app) }
        }
    }
}
