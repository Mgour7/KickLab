import SwiftUI

/// Athletes: switch, add, edit and delete.
struct ProfileView: View {
    @Environment(AppModel.self) private var app
    @State private var editingAthleteID: EditTarget?
    @State private var deletingAthleteID: UUID?

    init() {}

    /// Sheet target: a new athlete or an existing one.
    struct EditTarget: Identifiable, Hashable {
        let athleteID: UUID?
        var id: String { athleteID?.uuidString ?? "new" }
    }

    var body: some View {
        List {
            Section {
                ForEach(app.athletes) { athlete in
                    Button {
                        app.select(athlete.id)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(athlete.name).font(.headline)
                                Text("\(athlete.kickingFootText) · \(athlete.playingLevel.displayName) · \(athlete.kickCount) kicks")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if athlete.id == app.selectedAthleteID {
                                Image(systemName: "checkmark.circle.fill")
                                    .accessibilityLabel("Selected")
                            }
                        }
                        .frame(minHeight: 44)
                    }
                    .buttonStyle(.plain)
                    .swipeActions {
                        Button(role: .destructive) { deletingAthleteID = athlete.id } label: {
                            Label("Delete", systemImage: "trash")
                        }
                        Button { editingAthleteID = EditTarget(athleteID: athlete.id) } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                        .tint(.blue)
                    }
                    .contextMenu {
                        Button { editingAthleteID = EditTarget(athleteID: athlete.id) } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                        Button(role: .destructive) { deletingAthleteID = athlete.id } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                }
                Button {
                    editingAthleteID = EditTarget(athleteID: nil)
                } label: {
                    Label("Add Athlete", systemImage: "person.badge.plus")
                }
            } header: {
                Text("Athletes")
            } footer: {
                Text("Tap an athlete to switch. Swipe to edit or delete.")
            }
            Section("Privacy") {
                Text("Videos and analyses stay on this iPhone. KickLab measures body position only; it does not recognize faces or identify people.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Profile")
        .sheet(item: $editingAthleteID) { target in
            AthleteEditorView(athleteID: target.athleteID)
        }
        .sheet(item: deletingBinding) { target in
            AthleteDeletionView(athleteID: target.id)
        }
    }

    private struct DeleteTarget: Identifiable {
        let id: UUID
    }

    private var deletingBinding: Binding<DeleteTarget?> {
        Binding(get: { deletingAthleteID.map(DeleteTarget.init(id:)) }, set: { deletingAthleteID = $0?.id })
    }
}

/// Create or edit an athlete: name, kicking foot and level (the fields analysis uses).
struct AthleteEditorView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let athleteID: UUID?
    @State private var model: AthleteEditorViewModel?

    init(athleteID: UUID?) {
        self.athleteID = athleteID
    }

    var body: some View {
        NavigationStack {
            Group {
                if let model {
                    AthleteEditorForm(model: model)
                } else {
                    LoadingStateView()
                }
            }
            .navigationTitle(athleteID == nil ? "New Athlete" : "Edit Athlete")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if model?.save(app: app) != nil { dismiss() }
                    }
                }
            }
        }
        .task {
            if model == nil { model = AthleteEditorViewModel(athleteID: athleteID, app: app) }
        }
    }
}

private struct AthleteEditorForm: View {
    @Bindable var model: AthleteEditorViewModel

    var body: some View {
        Form {
            Section("Name") {
                TextField("First name", text: $model.firstName)
                    .textContentType(.givenName)
                TextField("Last name", text: $model.lastName)
                    .textContentType(.familyName)
            }
            Section {
                Picker("Kicking foot", selection: $model.kickingFoot) {
                    ForEach(KickingFoot.selectableCases, id: \.self) { foot in
                        Text(foot.displayName).tag(foot)
                    }
                }
                .pickerStyle(.segmented)
                Picker("Level", selection: $model.playingLevel) {
                    ForEach(PlayingLevel.selectableCases, id: \.self) { level in
                        Text(level.displayName).tag(level)
                    }
                }
            } footer: {
                Text("The kicking foot tells KickLab which leg is the kicking leg in the analysis.")
            }
            if !model.issues.isEmpty || model.errorMessage != nil {
                Section {
                    ForEach(model.issueMessages, id: \.self) { message in
                        Text(message).foregroundStyle(.red)
                    }
                    if let error = model.errorMessage {
                        Text(error).foregroundStyle(.red)
                    }
                }
            }
        }
    }
}

/// Permanent deletion with a typed confirmation, using the service's deletion plan.
struct AthleteDeletionView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var model: AthleteDeletionViewModel

    init(athleteID: UUID) {
        _model = State(initialValue: AthleteDeletionViewModel(athleteID: athleteID))
    }

    var body: some View {
        NavigationStack {
            Form {
                if let plan = model.plan {
                    Section {
                        Text(model.summary)
                        Text("This can't be undone.").font(.headline)
                    }
                    Section {
                        TextField("Type \(plan.confirmationPhrase)", text: $model.typedConfirmation)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    } footer: {
                        Text("Type \"\(plan.confirmationPhrase)\" to confirm.")
                    }
                    Section {
                        Button("Delete Permanently", role: .destructive) {
                            if model.delete(app: app) { dismiss() }
                        }
                        .disabled(!model.canDelete)
                    }
                } else if model.errorMessage == nil {
                    LoadingStateView()
                }
                if let error = model.errorMessage {
                    Section { Text(error).foregroundStyle(.red) }
                }
            }
            .navigationTitle("Delete Athlete")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
            .task { model.prepare(app: app) }
        }
    }
}
