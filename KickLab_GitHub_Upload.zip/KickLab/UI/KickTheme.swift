import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

// Build 22: one palette for every score, grade and status in the app (the Kick Report,
// rated areas and score rings used two different mappings before). Colors always come
// with a word; they never carry meaning on their own.

enum KickTheme {
    // MARK: Brand and surfaces (Build 23)

    /// KickLab's field green: deep in light mode, brighter in dark mode.
    static let brand = adaptive(light: (0.06, 0.42, 0.28), dark: (0.27, 0.76, 0.51))
    /// The brand at low strength, for tinted backgrounds.
    static let brandSoft = brand.opacity(0.14)
    /// The screen behind cards, and the cards themselves (system grouped colors, so both
    /// adapt to dark mode and to Increase Contrast).
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
    static let cardRadius: CGFloat = 20

    static func adaptive(light: (Double, Double, Double), dark: (Double, Double, Double)) -> Color {
        Color(uiColor: UIColor { traits in
            let c = traits.userInterfaceStyle == .dark ? dark : light
            return UIColor(red: c.0, green: c.1, blue: c.2, alpha: 1)
        })
    }

    static func color(_ trend: MetricTrackTrend) -> Color {
        switch trend.tone {
        case 1: strength
        case -1: workOn
        default: .secondary
        }
    }

    static let strength = Color(red: 0.11, green: 0.60, blue: 0.34)
    static let solid = Color(red: 0.07, green: 0.53, blue: 0.53)
    static let workOn = Color(red: 0.86, green: 0.53, blue: 0.08)
    static let priority = Color(red: 0.83, green: 0.25, blue: 0.27)
    static let notGraded = Color(red: 0.37, green: 0.45, blue: 0.56)
    static let notMeasured = Color.gray
    /// The provisional-target zone on measurement bars.
    static let target = strength.opacity(0.22)
    static let track = Color.secondary.opacity(0.18)

    static func color(_ status: KickBreakdown.Status) -> Color {
        switch status {
        case .strength: strength
        case .solid: solid
        case .workOn: workOn
        case .priority: priority
        case .notGraded: notGraded
        case .notMeasured: notMeasured
        }
    }

    static func color(_ verdict: KickBreakdown.Verdict) -> Color {
        switch verdict {
        case .inside: strength
        case .below, .above: workOn
        case .noTarget: .secondary
        }
    }
}

extension PerformanceReport.Label {
    var color: Color { KickTheme.color(KickBreakdown.Status(label: self)) }
}

extension ScoreGrade {
    var color: Color {
        switch self {
        case .excellent: KickTheme.strength
        case .good: KickTheme.solid
        case .fair: KickTheme.workOn
        case .needsWork: KickTheme.priority
        case .unavailable: KickTheme.notMeasured
        }
    }
}
