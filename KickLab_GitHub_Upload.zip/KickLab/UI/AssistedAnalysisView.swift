import AVKit
import SwiftUI

/// Step 12D: user-assisted analysis recovery. When KickLab can't confidently find the
/// strike (or the video has several kicks), the user chooses the contact frame or the
/// kick, and a NEW analysis labeled "User-assisted" is run around that choice. The video
/// and every earlier analysis stay unchanged; leaving this screen changes nothing.
struct AssistedAnalysisView: View {
    enum Mode: Hashable { case contact, kick }

    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let kickID: UUID
    let mode: Mode
    @State private var model: PoseValidationViewModel
    @State private var player: ValidationPlayer?
    @State private var windowIndex = 0
    @State private var windowStart: Double = 0
    @State private var windowEnd: Double = 0
    @State private var started = false
    /// The contact frame must be positioned by the user (the automatic estimate is never
    /// accepted silently).
    @State private var selection = ManualContactSelection(automaticEstimate: nil)

    init(kickID: UUID, analysisID: UUID, mode: Mode) {
        self.kickID = kickID
        self.mode = mode
        _model = State(initialValue: PoseValidationViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle(mode == .contact ? "Manual Contact" : "Choose the Kick")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
                if let windows = model.state.value?.timeline.kickWindows, let first = windows.windows.first {
                    windowIndex = windows.selectedIndex ?? 0
                    let chosen = windows.windows.indices.contains(windowIndex) ? windows.windows[windowIndex] : first
                    windowStart = chosen.preparationStart
                    windowEnd = chosen.movementEnd
                }
                if mode == .contact, let player, let estimate = model.state.value?.estimatedContact {
                    selection = ManualContactSelection(automaticEstimate: estimate)
                    player.seek(to: estimate)
                }
            }
            .onDisappear { player?.stop() }
    }

    @ViewBuilder
    private var content: some View {
        if started {
            progress
        } else {
            switch model.state {
            case .loading:
                LoadingStateView(text: "Reading the video…")
            case .failed(let message):
                ErrorStateView(message: message)
            case .loaded(let c):
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(mode == .contact
                             ? "Choose the frame where the foot contacts the ball. KickLab runs a NEW analysis with that frame as contact; it is used only for that analysis and never for automatic reanalysis."
                             : "This video has more than one kick, or KickLab couldn't find one. Choose the part of the video with the kick you want analyzed.")
                            .font(.subheadline)
                            .padding(.horizontal)
                        PoseVideoArea(timeline: c.timeline, player: player, source: .current, showsSkeleton: true, showsConfidence: true)
                        PhaseTimelineBar(timeline: c.timeline, currentTime: player?.currentTime ?? 0) { time in
                            player?.seek(to: time)
                            selection.userPositionedVideo()
                        }
                            .padding(.horizontal)
                        if mode == .contact { contactControls(c) } else { kickControls(c) }
                        Text("Your choice is recorded exactly and the result is labeled User-assisted. It isn't counted as automatic accuracy, and this analysis and the video stay as they are.")
                            .font(.caption).foregroundStyle(.secondary)
                            .padding(.horizontal)
                    }
                    .padding(.vertical)
                }
            }
        }
    }

    // MARK: Contact frame

    private func contactControls(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if let player {
                HStack {
                    Text(String(format: "%.3f s", player.currentTime)).monospacedDigit()
                    Spacer()
                    Button {
                        player.stepSourceFrame(-1)
                        selection.userPositionedVideo()
                    } label: { Label("Back one frame", systemImage: "chevron.backward") }
                        .frame(minWidth: 44, minHeight: 44)
                    Button {
                        player.stepSourceFrame(1)
                        selection.userPositionedVideo()
                    } label: { Label("Forward one frame", systemImage: "chevron.forward") }
                        .frame(minWidth: 44, minHeight: 44)
                }
                .labelStyle(.iconOnly)
                Slider(value: Binding(get: { player.currentTime }, set: { time in
                    player.seek(to: time)
                    selection.userPositionedVideo()
                }), in: 0...max(0.01, c.timeline.duration))
                    .accessibilityLabel("Video position")
                Text(selection.hint).font(.caption).foregroundStyle(.secondary)
                Button {
                    guard let runMode = selection.runMode(currentTime: player.currentTime) else { return }
                    app.analysisRun(for: kickID).reanalyze(app: app, mode: runMode)
                    started = true
                } label: {
                    Text("Reanalyze With This Contact Frame").frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!selection.canSubmit)
            } else {
                Text("The video file isn't on this device, so the frame can't be chosen.").font(.subheadline)
            }
        }
        .padding(.horizontal)
    }

    // MARK: Kick interval

    private func kickControls(_ c: PoseValidationViewModel.Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if let windows = c.timeline.kickWindows, !windows.windows.isEmpty {
                Picker("Kick", selection: $windowIndex) {
                    ForEach(Array(windows.windows.enumerated()), id: \.offset) { i, w in
                        Text(String(format: "%.1f–%.1f s%@", w.preparationStart, w.movementEnd, w.hasSwing ? "" : " (no swing found)")).tag(i)
                    }
                }
                .onChange(of: windowIndex) { _, index in
                    guard windows.windows.indices.contains(index) else { return }
                    windowStart = windows.windows[index].preparationStart
                    windowEnd = windows.windows[index].movementEnd
                    player?.seek(to: windows.windows[index].strikeStart)
                }
            }
            Stepper(String(format: "Start %.1f s", windowStart), value: $windowStart, in: 0...max(0, windowEnd - 0.5), step: 0.1)
            Stepper(String(format: "End %.1f s", windowEnd), value: $windowEnd, in: (windowStart + 0.5)...max(windowStart + 0.5, c.timeline.duration), step: 0.1)
            Button {
                app.analysisRun(for: kickID).startAssisted(
                    app: app, assistance: PhaseDetectionAssistance(windowStart: windowStart, windowEnd: windowEnd)
                )
                started = true
            } label: {
                Text("Analyze This Kick").frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .disabled(windowEnd - windowStart < 0.5)
        }
        .padding(.horizontal)
    }

    // MARK: Progress

    @ViewBuilder
    private var progress: some View {
        let run = app.analysisRun(for: kickID)
        VStack(spacing: 16) {
            switch run.state {
            case .running(_, let fraction):
                ProgressView(value: fraction) { Text(run.state.stageText ?? "Analyzing") }
                Button("Cancel", role: .cancel) { run.cancel() }
                    .frame(minHeight: 44)
            case .cancelling:
                ProgressView { Text("Cancelling…") }
            case .completed(let id):
                Label("User-assisted analysis finished", systemImage: "checkmark.circle").font(.headline)
                NavigationLink(value: AppRoute.analysis(id)) {
                    Text("View Results").frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
            case .failed(let problem):
                Label(problem.title, systemImage: "exclamationmark.triangle").font(.headline)
                Text(problem.message).font(.subheadline)
                Button("Choose Again") { started = false }
                    .frame(minHeight: 44)
            case .cancelled:
                Text("Cancelled. Nothing was changed.").font(.subheadline)
                Button("Choose Again") { started = false }
                    .frame(minHeight: 44)
            case .idle:
                ProgressView()
            }
        }
        .padding()
    }
}
