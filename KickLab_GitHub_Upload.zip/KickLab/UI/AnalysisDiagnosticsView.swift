import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Developer-only: everything KickLab knows about why an analysis succeeded or failed.
/// Copy or share it as text (it holds no images, coordinates or names).
struct AnalysisDiagnosticsView: View {
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisDiagnosticsViewModel
    @State private var copied = false
    @State private var contactText = ""

    init(analysisID: UUID) {
        _model = State(initialValue: AnalysisDiagnosticsViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Diagnostics")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if let t = model.referenceContactTime { contactText = String(format: "%.3f", t) }
            }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading analysis data…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let report):
            List {
                Section {
                    ShareLink(item: report.plainText, subject: Text("KickLab analysis diagnostics")) {
                        Label("Share or Save Diagnostics", systemImage: "square.and.arrow.up")
                    }
                    .frame(minHeight: 44)
                    Button {
                        copy(report.plainText)
                    } label: {
                        Label(copied ? "Copied" : "Copy to Clipboard", systemImage: copied ? "checkmark" : "doc.on.doc")
                    }
                    .frame(minHeight: 44)
                    if let series = report.timeSeries {
                        ShareLink(item: series.csv, subject: Text("KickLab phase signals (CSV)")) {
                            Label("Share Phase Signals (CSV)", systemImage: "chart.xyaxis.line")
                        }
                        .frame(minHeight: 44)
                    }
                } footer: {
                    Text("Contains counts, confidences, times, speeds in body lengths per second and reasons only — no video frames, body coordinates or names. Nothing is sent anywhere unless you share it.")
                }
                Section("Outcome") {
                    row("Status", report.storedStatus)
                    if let reason = report.storedFailureReason { row("Stored reason", reason) }
                    if let cause = report.failureCause { row("Diagnosed cause", cause.rawValue) }
                    row("Scored categories", report.scoredCategoryCount.map(String.init) ?? "—")
                }
                if !report.contributingFactors.isEmpty {
                    Section("Contributing factors") {
                        ForEach(report.contributingFactors, id: \.self) { Text($0).font(.subheadline) }
                    }
                }
                Section("Configuration") {
                    row("Kick type", report.kickType.rawValue)
                    row("Kicking foot", report.kickingFoot?.rawValue ?? "—")
                    row("Camera angle", report.cameraAngle?.rawValue ?? "—")
                    row("Manual kicker selection", report.manualKickerSelection.map { $0 ? "Yes" : "No" } ?? "—")
                    row("Engine", report.engineVersion ?? "—")
                }
                Section("Video and frames") {
                    row("Duration", number(report.videoDurationSeconds, " s"))
                    row("Frame rate (file / analyzed)", "\(number(report.nominalFrameRate, "")) / \(number(report.measuredAnalysisFrameRate, ""))")
                    row("Frames sampled", count(report.framesSampled))
                    row("Vision failed", count(report.framesVisionFailed))
                    row("Frames with a person", count(report.framesWithPerson))
                    row("Frames with 2+ people", count(report.framesWithMultiplePeople))
                }
                Section("Kicker") {
                    row("Selection", "\(report.kickerStatus?.rawValue ?? "—") (\(report.kickerSelectionMethod?.rawValue ?? "—"))")
                    row("Frames tracked", "\(count(report.framesWithKicker)) (\(number(report.kickerTrackedFraction.map { $0 * 100 }, "%")))")
                    row("Candidates", count(report.kickerCandidates))
                }
                Section("Joints (detected · usable · mean confidence)") {
                    ForEach(report.joints, id: \.joint) { j in
                        row("\(j.joint.rawValue)\(j.role.map { " (\($0))" } ?? "")",
                            "\(j.detectedFrames) · \(j.usableFrames) · \(number(j.meanConfidence, ""))")
                    }
                }
                Section("Phases") {
                    ForEach(report.phases, id: \.phase) { p in
                        row(p.phase.rawValue, "\(p.status.rawValue)\(p.time.map { String(format: " @ %.2f s", $0) } ?? "")")
                    }
                }
                if let replay = report.replay {
                    Section {
                        ForEach(replay.phases, id: \.phase) { p in
                            row(p.phase.rawValue, "\(p.status.rawValue)\(p.time.map { String(format: " @ %.2f s", $0) } ?? "")")
                        }
                        row("Scored categories", "\(replay.scoredCategoryCount)")
                        row("Overall", replay.overallScore.map { String(format: "%.0f", $0) } ?? "—")
                        row("Leg repair", "\(replay.repair.legSwapSamples.count) swaps · \(replay.repair.outlierPoints) jumps")
                        ForEach(replay.notes, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                    } header: {
                        Text("Current detector on stored pose")
                    } footer: {
                        Text(replay.differsFromStored ? "Differs from the stored analysis. Run the analysis again to save these results." : "Same phases as the stored analysis.")
                    }
                }
                if let e = report.replay?.evidence ?? report.detectionEvidence {
                    Section("Detection evidence") {
                        row("Peak foot speed", "\(number(e.contactPeakSpeed, " bl/s")) @ \(number(e.contactPeakTime, " s"))")
                        row("Foot passes plant foot", number(e.anklePassTime, " s"))
                        row("Plant touchdown", number(e.plantTouchdownTime, " s"))
                        row("Plant still through contact", e.plantStillThroughContact.map { $0 ? "Yes" : "No" } ?? "—")
                        row("Plant speed at contact", number(e.plantSpeedAtContact, " bl/s"))
                        row("Still threshold · noise", "\(number(e.plantStillThreshold, "")) · \(number(e.plantNoiseFloor, ""))")
                        row("Follow-through", number(e.followThroughSeconds, " s"))
                    }
                }
                Section {
                    TextField("Strike time in seconds, e.g. 2.35", text: $contactText)
                        .keyboardType(.decimalPad)
                        .frame(minHeight: 44)
                    Button("Save Marked Contact") {
                        Task { await model.saveReferenceContact(Double(contactText.replacingOccurrences(of: ",", with: ".")), app: app) }
                    }
                    .frame(minHeight: 44)
                    .disabled(Double(contactText.replacingOccurrences(of: ",", with: ".")) == nil)
                    if model.referenceContactTime != nil {
                        Button("Clear Marked Contact", role: .destructive) {
                            contactText = ""
                            Task { await model.saveReferenceContact(nil, app: app) }
                        }
                        .frame(minHeight: 44)
                    }
                    if let check = report.contactCheck {
                        row("Marked · estimated", "\(number(check.referenceTime, " s")) · \(number(check.estimatedTime, " s"))")
                        row("Error", "\(number(check.errorSeconds, " s")) (\(number(check.errorFrames, " frames")))")
                    }
                    if let error = model.referenceError { Text(error).font(.caption).foregroundStyle(.red) }
                } header: {
                    Text("Contact check")
                } footer: {
                    Text("Find the frame where the foot meets the ball (scrub the video in Photos), enter its time, and KickLab compares it with its estimate. Used only for checking accuracy.")
                }
                Section("Metrics") {
                    ForEach(report.metrics, id: \.key) { m in
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(m.available ? "✓" : "✗") \(m.name)").font(.subheadline)
                            Text(metricDetail(m)).font(.caption).foregroundStyle(.secondary)
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                Section("Categories") {
                    ForEach(report.categories, id: \.category) { c in
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(c.category.presentationTitle): \(c.score.map { String(format: "%.0f", $0) } ?? "not scored")").font(.subheadline)
                            Text("confidence \(number(c.confidence, "")) · weight available \(number(c.availableWeightFraction, ""))")
                                .font(.caption).foregroundStyle(.secondary)
                            ForEach(c.excluded, id: \.self) { Text("excluded \($0)").font(.caption2).foregroundStyle(.secondary) }
                        }
                    }
                }
            }
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        LabeledContent(title, value: value).font(.subheadline)
    }

    private func number(_ value: Double?, _ suffix: String) -> String {
        value.map { String(format: "%.2f", $0) + suffix } ?? "—"
    }

    private func count(_ value: Int?) -> String { value.map(String.init) ?? "—" }

    private func metricDetail(_ m: DiagnosticsMetric) -> String {
        var parts: [String] = []
        if m.available {
            parts.append("value \(number(m.value, "")) · confidence \(number(m.confidence, ""))")
        } else {
            parts.append("\(m.unavailableReason ?? "unavailable")\(m.missingPhase.map { " (\($0.rawValue))" } ?? "")")
        }
        if let q = m.jointQuality {
            parts.append("joints \(number(q, "")) · phase \(number(m.phaseFactor, "")) · fps \(number(m.frameRateFactor, "")) · camera \(number(m.cameraFactor, ""))")
        }
        if m.limitedByCameraAngle { parts.append("limited by camera angle") }
        return parts.joined(separator: " · ")
    }

    private func copy(_ text: String) {
        #if canImport(UIKit)
        UIPasteboard.general.string = text
        #endif
        copied = true
    }
}
