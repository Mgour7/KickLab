import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Developer-only: everything KickLab knows about why an analysis succeeded or failed.
/// Copy or share it as text (it holds no images, coordinates or names).
struct AnalysisDiagnosticsView: View {
    @Environment(AppModel.self) private var app
    @State private var model: AnalysisDiagnosticsViewModel
    @State private var copied = false
    @State private var contactText = ""
    @State private var confirmingPoseExport = false
    @State private var validationClip: String?

    init(analysisID: UUID) {
        _model = State(initialValue: AnalysisDiagnosticsViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle("Diagnostics")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if let t = model.referenceContactTime { contactText = String(format: "%.3f", t) }
            }
            .alert("Export pose data?", isPresented: $confirmingPoseExport) {
                Button("Export") {
                    Task {
                        validationClip = await model.validationClipJSON(
                            app: app, annotator: "app user",
                            rightsNote: "Exported by the app user for a private validation library; permission confirmed in the app."
                        )
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This file contains the athlete's body coordinates for every analyzed frame, plus the marked contact. It contains no video or images. Continue only if you have permission to use this recording for validation.")
            }
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading analysis data…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let report):
            List {
                Section {
                    ShareLink(item: report.plainText, subject: Text("KickLab analysis diagnostics")) {
                        Label("Share or Save Diagnostics", systemImage: "square.and.arrow.up")
                    }
                    .frame(minHeight: 44)
                    Button {
                        copy(report.plainText)
                    } label: {
                        Label(copied ? "Copied" : "Copy to Clipboard", systemImage: copied ? "checkmark" : "doc.on.doc")
                    }
                    .frame(minHeight: 44)
                    if let series = report.timeSeries {
                        ShareLink(item: series.csv, subject: Text("KickLab phase signals (CSV)")) {
                            Label("Share Phase Signals (CSV)", systemImage: "chart.xyaxis.line")
                        }
                        .frame(minHeight: 44)
                    }
                    NavigationLink(value: AppRoute.poseValidation(model.analysisID)) {
                        Label("Pose Validation", systemImage: "figure.walk.motion")
                    }
                    .frame(minHeight: 44)
                } footer: {
                    Text("Contains counts, confidences, times, speeds in body lengths per second and reasons only — no video frames, body coordinates or names. Nothing is sent anywhere unless you share it.")
                }
                Section("Outcome") {
                    row("Status", report.storedStatus)
                    if let reason = report.storedFailureReason { row("Stored reason", reason) }
                    if let cause = report.failureCause { row("Diagnosed cause", cause.rawValue) }
                    row("Scored categories", report.scoredCategoryCount.map(String.init) ?? "—")
                }
                if !report.contributingFactors.isEmpty {
                    Section("Contributing factors") {
                        ForEach(report.contributingFactors, id: \.self) { Text($0).font(.subheadline) }
                    }
                }
                Section("Configuration") {
                    row("Kick type", report.kickType.rawValue)
                    row("Kicking foot", report.kickingFoot?.rawValue ?? "—")
                    row("Camera angle", report.cameraAngle?.rawValue ?? "—")
                    row("Manual kicker selection", report.manualKickerSelection.map { $0 ? "Yes" : "No" } ?? "—")
                    row("Engine", report.engineVersion ?? "—")
                    row("Analysis mode", report.analysisMode == "userAssisted" ? "User-assisted" : (report.analysisMode == nil ? "—" : "Automatic"))
                    row("Contact timing basis", report.contactTimingSource ?? "—")
                    if let t = report.assistance?.contactTime {
                        row("Assisted contact", String(format: "%.3f s", t))
                    }
                }
                Section("Video and frames") {
                    row("Duration", number(report.videoDurationSeconds, " s"))
                    row("Frame rate (file / analyzed)", "\(number(report.nominalFrameRate, "")) / \(number(report.measuredAnalysisFrameRate, ""))")
                    row("Frames sampled", count(report.framesSampled))
                    row("Vision failed", count(report.framesVisionFailed))
                    row("Frames with a person", count(report.framesWithPerson))
                    row("Frames with 2+ people", count(report.framesWithMultiplePeople))
                }
                Section("Kicker") {
                    row("Selection", "\(report.kickerStatus?.rawValue ?? "—") (\(report.kickerSelectionMethod?.rawValue ?? "—"))")
                    row("Frames tracked", "\(count(report.framesWithKicker)) (\(number(report.kickerTrackedFraction.map { $0 * 100 }, "%")))")
                    row("Candidates", count(report.kickerCandidates))
                }
                Section("Joints (detected · usable · mean confidence)") {
                    ForEach(report.joints, id: \.joint) { j in
                        row("\(j.joint.rawValue)\(j.role.map { " (\($0))" } ?? "")",
                            "\(j.detectedFrames) · \(j.usableFrames) · \(number(j.meanConfidence, ""))")
                    }
                }
                Section("Phases") {
                    ForEach(report.phases, id: \.phase) { p in
                        row(p.phase.rawValue, "\(p.status.rawValue)\(p.time.map { String(format: " @ %.2f s", $0) } ?? "")")
                    }
                }
                replaySections(report)
                if let e = report.replay?.evidence ?? report.detectionEvidence {
                    Section("Detection evidence") {
                        row("Peak foot speed", "\(number(e.contactPeakSpeed, " bl/s")) @ \(number(e.contactPeakTime, " s"))")
                        row("Foot passes plant foot", number(e.anklePassTime, " s"))
                        row("Plant touchdown", number(e.plantTouchdownTime, " s"))
                        row("Plant still through contact", e.plantStillThroughContact.map { $0 ? "Yes" : "No" } ?? "—")
                        row("Plant speed at contact", number(e.plantSpeedAtContact, " bl/s"))
                        row("Still threshold · noise", "\(number(e.plantStillThreshold, "")) · \(number(e.plantNoiseFloor, ""))")
                        row("Follow-through", number(e.followThroughSeconds, " s"))
                        row("Plant state", e.plantState?.rawValue ?? "—")
                        row("Contact uncertainty", number(e.contactUncertaintySeconds, " s"))
                        row("Algorithm", e.algorithmVersion ?? "before contact-candidates-1")
                    }
                    if let candidates = e.contactCandidates, !candidates.isEmpty {
                        Section("Contact candidates") {
                            ForEach(candidates, id: \.time) { c in
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(String(format: "%@%.3f s · score %.2f · %.1f bl/s", c.selected ? "✓ " : "", c.time, c.score, c.peakSpeed))
                                        .font(.subheadline)
                                    if !c.supportingSignals.isEmpty {
                                        Text("supported by: " + c.supportingSignals.joined(separator: ", ")).font(.caption)
                                    }
                                    ForEach(c.rejectionReasons, id: \.self) { Text("rejected: " + $0).font(.caption).foregroundStyle(.secondary) }
                                }
                            }
                            ForEach(e.contactConflicts ?? [], id: \.self) { Text($0).font(.caption) }
                        }
                    }
                }
                if let windows = report.replay?.kickWindows ?? report.kickWindows, !windows.windows.isEmpty {
                    Section {
                        ForEach(Array(windows.windows.enumerated()), id: \.offset) { i, w in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(String(format: "%@%.2f–%.2f s · %@", i == windows.selectedIndex ? "✓ " : "", w.preparationStart, w.movementEnd,
                                            w.hasSwing ? "kick" : "no kick"))
                                    .font(.subheadline)
                                Text(String(format: "approach peak %.1f bl/s · strike interval %.2f–%.2f s · confidence %.2f", w.approachPeakSpeed,
                                            w.strikeStart, w.strikeEnd, w.confidence))
                                    .font(.caption).foregroundStyle(.secondary)
                                ForEach(w.uncertaintyReasons, id: \.self) { Text($0).font(.caption2).foregroundStyle(.secondary) }
                            }
                        }
                    } header: {
                        Text("Kick windows")
                    } footer: {
                        Text(windows.needsSelection ? "Several kicks — the user should choose one." : "Contact candidates outside the selected window are treated as preparation or recovery.")
                    }
                }
                if let findings = report.suitability, !findings.isEmpty {
                    Section("Recording suitability") {
                        ForEach(findings) { f in
                            Label(f.message, systemImage: f.severity == .blocking ? "xmark.octagon" : (f.severity == .limiting ? "exclamationmark.triangle" : "info.circle"))
                                .font(.caption)
                        }
                    }
                }
                if report.assistance?.isEmpty == false {
                    Section("User-assisted analysis") {
                        Text(AnalysisDiagnosticsReport.assistanceText(report.assistance)).font(.subheadline)
                        Text("Excluded from automatic-accuracy statistics.").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section {
                    if let clip = validationClip {
                        ShareLink(item: clip, subject: Text("KickLab validation clip (pose data)")) {
                            Label("Share Validation Clip", systemImage: "square.and.arrow.up")
                        }
                        .frame(minHeight: 44)
                    } else {
                        Button("Export Pose for Validation…") { confirmingPoseExport = true }
                            .frame(minHeight: 44)
                            .disabled(model.referenceContactTime == nil)
                    }
                } header: {
                    Text("Validation library")
                } footer: {
                    Text("Needs a marked contact. Unlike the report, this export CONTAINS BODY COORDINATES for every frame (no video, images or names). Share it only into your private validation library, and only with the athlete's (or a parent's) permission.")
                }
                Section {
                    TextField("Strike time in seconds, e.g. 2.35", text: $contactText)
                        .keyboardType(.decimalPad)
                        .frame(minHeight: 44)
                    Button("Save Marked Contact") {
                        Task { await model.saveReferenceContact(Double(contactText.replacingOccurrences(of: ",", with: ".")), app: app) }
                    }
                    .frame(minHeight: 44)
                    .disabled(Double(contactText.replacingOccurrences(of: ",", with: ".")) == nil)
                    if model.referenceContactTime != nil {
                        Button("Clear Marked Contact", role: .destructive) {
                            contactText = ""
                            Task { await model.saveReferenceContact(nil, app: app) }
                        }
                        .frame(minHeight: 44)
                    }
                    if let check = report.contactCheck {
                        row("Marked · estimated", "\(number(check.referenceTime, " s")) · \(number(check.estimatedTime, " s"))")
                        row("Error", "\(number(check.errorSeconds, " s")) (\(number(check.errorFrames, " frames")))")
                    }
                    if let error = model.referenceError { Text(error).font(.caption).foregroundStyle(.red) }
                } header: {
                    Text("Contact check")
                } footer: {
                    Text("Find the frame where the foot meets the ball (scrub the video in Photos), enter its time, and KickLab compares it with its estimate. Used only for checking accuracy.")
                }
                Section("Metrics") {
                    ForEach(report.metrics, id: \.key) { m in
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(m.available ? "✓" : "✗") \(m.name)").font(.subheadline)
                            Text(metricDetail(m)).font(.caption).foregroundStyle(.secondary)
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                Section("Categories") {
                    ForEach(report.categories, id: \.category) { c in
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(c.category.presentationTitle): \(c.score.map { String(format: "%.0f", $0) } ?? "not scored")").font(.subheadline)
                            Text("confidence \(number(c.confidence, "")) · weight available \(number(c.availableWeightFraction, ""))")
                                .font(.caption).foregroundStyle(.secondary)
                            ForEach(c.excluded, id: \.self) { Text("excluded \($0)").font(.caption2).foregroundStyle(.secondary) }
                        }
                    }
                }
            }
        }
    }

    /// Replay Diagnostics (stored pose, nothing saved) and, for a user-assisted analysis,
    /// the automatic replay without the user's input.
    @ViewBuilder
    private func replaySections(_ report: AnalysisDiagnosticsReport) -> some View {
        if let replay = report.replay {
            Section {
                ForEach(replay.phases, id: \.phase) { p in
                    row(p.phase.rawValue, "\(p.status.rawValue)\(p.time.map { String(format: " @ %.2f s", $0) } ?? "")")
                }
                row("Scored categories", "\(replay.scoredCategoryCount)")
                row("Overall", replay.overallScore.map { String(format: "%.0f", $0) } ?? "—")
                row("Leg repair", "\(replay.repair.legSwapSamples.count) swaps · \(replay.repair.outlierPoints) jumps")
                ForEach(replay.notes, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
            } header: {
                Text(report.analysisMode == "userAssisted" ? "Replay Diagnostics (with the user's input)" : "Replay Diagnostics")
            } footer: {
                Text((replay.differsFromStored ? "Differs from the stored analysis. " : "Same phases as the stored analysis. ")
                     + "Replay re-reads this analysis' stored pose with the current detector and saves nothing. Use Reanalyze Automatically for a new analysis.")
            }
        }
        if let automatic = report.automaticReplay {
            Section {
                ForEach(automatic.phases, id: \.phase) { p in
                    row(p.phase.rawValue, "\(p.status.rawValue)\(p.time.map { String(format: " @ %.2f s", $0) } ?? "")")
                }
                row("Contact timing basis", automatic.evidence?.contactTimingSource?.rawValue ?? "—")
                row("Scored categories", "\(automatic.scoredCategoryCount)")
            } header: {
                Text("Automatic replay (no user input)")
            } footer: {
                Text("What the current detector finds on this stored pose without the contact frame or kick interval chosen for this analysis. Nothing is saved.")
            }
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        LabeledContent(title, value: value).font(.subheadline)
    }

    private func number(_ value: Double?, _ suffix: String) -> String {
        value.map { String(format: "%.2f", $0) + suffix } ?? "—"
    }

    private func count(_ value: Int?) -> String { value.map(String.init) ?? "—" }

    private func metricDetail(_ m: DiagnosticsMetric) -> String {
        var parts: [String] = []
        if m.available {
            parts.append("value \(number(m.value, "")) · confidence \(number(m.confidence, ""))")
        } else {
            parts.append("\(m.unavailableReason ?? "unavailable")\(m.missingPhase.map { " (\($0.rawValue))" } ?? "")")
        }
        if let q = m.jointQuality {
            parts.append("joints \(number(q, "")) · phase \(number(m.phaseFactor, "")) · fps \(number(m.frameRateFactor, "")) · camera \(number(m.cameraFactor, ""))")
        }
        if m.limitedByCameraAngle { parts.append("limited by camera angle") }
        return parts.joined(separator: " · ")
    }

    private func copy(_ text: String) {
        #if canImport(UIKit)
        UIPasteboard.general.string = text
        #endif
        copied = true
    }
}
