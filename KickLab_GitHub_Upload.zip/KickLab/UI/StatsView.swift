import SwiftUI

/// Outcome statistics with date and kick-type filters, plus personal mechanics insights.
struct StatsView: View {
    @Environment(AppModel.self) private var app
    @State private var model = StatsViewModel()

    init() {}

    var body: some View {
        List {
            Section {
                NavigationLink(value: AppRoute.metricTracker) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Metric Tracker").font(.body.weight(.semibold))
                            Text("Every measurement, kick by kick, against its target").font(.caption).foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: "waveform.path.ecg").foregroundStyle(KickTheme.brand)
                    }
                }
                NavigationLink(value: AppRoute.progress) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Progress Dashboard").font(.body.weight(.semibold))
                            Text("Results, distances, sessions and consistency").font(.caption).foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: "chart.xyaxis.line").foregroundStyle(KickTheme.brand)
                    }
                }
            }
            Section {
                Picker("Kick type", selection: $model.kickType) {
                    ForEach(StatsKickTypeFilter.allCases) { filter in
                        Text(filter.title).tag(filter)
                    }
                }
                .pickerStyle(.segmented)
                Picker("Period", selection: $model.datePreset) {
                    ForEach(StatsDatePreset.allCases) { preset in
                        Text(preset.title).tag(preset)
                    }
                }
            }
            content
        }
        .navigationTitle("Progress")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { AthleteSwitcherMenu() }
        }
        .task(id: reloadKey) { model.load(app: app) }
    }

    /// Reload when data, the athlete or a filter changes.
    private var reloadKey: String {
        "\(app.revision)-\(model.kickType.rawValue)-\(model.datePreset.rawValue)"
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            Section { LoadingStateView() }
        case .failed(let message):
            Section { ErrorStateView(message: message) { model.load(app: app) } }
        case .loaded(let c):
            ForEach(c.sections) { section in
                Section(section.title) {
                    if let message = section.emptyMessage {
                        Text(message).foregroundStyle(.secondary)
                    }
                    ForEach(section.rows) { row in
                        LabeledContent {
                            VStack(alignment: .trailing) {
                                Text(row.value).monospacedDigit()
                                if let detail = row.detail {
                                    Text(detail).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        } label: {
                            Text(row.title)
                        }
                    }
                }
            }
            MechanicsInsightsSection(insights: c.insights)
        }
    }
}

/// Best kicks and personal baseline for the selected kick type. Derived from stored
/// analyses with fixed rules; it says so, and says when there isn't enough history.
struct MechanicsInsightsSection: View {
    let insights: PersonalInsights

    var body: some View {
        Section {
            if insights.analyzedKickCount == 0 {
                Text("Analyze kicks with video to build your mechanics history.")
                    .foregroundStyle(.secondary)
            } else {
                LabeledContent("Analyzed kicks", value: "\(insights.analyzedKickCount)")
                availabilityRow("Personal baseline", insights.baselineAvailability, message: PersonalInsights.baselineNeededMessage)
                availabilityRow("Typical on successful kicks", insights.successfulKickAvailability, message: PersonalInsights.successfulNeededMessage)
                availabilityRow("Recent trend", insights.trendAvailability, message: PersonalInsights.trendNeededMessage)
            }
            if insights.bestKicksAvailability.isAvailable {
                ForEach(insights.bestKicks) { entry in
                    NavigationLink(value: AppRoute.analysis(entry.analysisID)) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(entry.date, style: .date).font(.subheadline)
                                Text(entry.isSuccessful ? "Successful kick" : "Outcome not recorded as successful")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(DisplayFormat.score(entry.overallScore)).font(.headline).monospacedDigit()
                        }
                    }
                }
            } else if insights.analyzedKickCount > 0 {
                Text(PersonalInsights.bestKicksNeededMessage).foregroundStyle(.secondary)
            }
        } header: {
            Text("Best kicks & personal mechanics")
        } footer: {
            Text(insights.methodDescription)
        }
    }

    private func availabilityRow(_ title: String, _ availability: InsightAvailability, message: String) -> some View {
        LabeledContent(title) {
            switch availability {
            case .available:
                Text("Ready")
            case .needsMoreKicks(let have, let need):
                Text("\(have) of \(need) kicks").foregroundStyle(.secondary)
            }
        }
        .accessibilityHint(availability.isAvailable ? "" : message)
    }
}
