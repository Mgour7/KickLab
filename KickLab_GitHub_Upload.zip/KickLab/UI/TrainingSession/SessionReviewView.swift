import AVKit
import SwiftUI
import UniformTypeIdentifiers

/// Build 21 — Session Review: every kick of the practice on one screen, with one-tap
/// results, corrections and analytics, so dozens of kicks can be reviewed without
/// navigating back and forth.
struct SessionReviewView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.scenePhase) private var scenePhase
    @State private var playback: SessionPlaybackRequest?
    @State private var exportingDiagnostics = false
    @State private var openedAnalysis: UUID?
    @State private var nextPick: TimePick?
    let sessionID: UUID
    @State private var manifest: TrainingSessionManifest?
    @State private var results: [UUID: KickStatRecord] = [:]
    @State private var entries: [RankingEntry] = []
    @State private var problem: String?
    @State private var picking: TimePick?
    @State private var importingCamera = false
    @State private var confirmingReject: RejectRequest?
    @State private var confirmingSourceDelete: SessionSource?
    @State private var remoteCameras = false

    init(sessionID: UUID) { self.sessionID = sessionID }

    private var processor: TrainingSessionProcessor { app.sessionProcessor(for: sessionID) }

    struct RejectRequest: Identifiable { let candidate: SessionKickCandidate; let practice: Bool; var id: UUID { candidate.id } }

    /// What a time picker is for.
    struct TimePick: Identifiable {
        enum Purpose { case addKick, contact(UUID), start(UUID), end(UUID), splitFirst(UUID), splitSecond(UUID, Double) }
        let purpose: Purpose
        let source: SessionSource
        let initial: Double
        let id = UUID()
    }

    var body: some View {
        List {
            if let m = manifest {
                header(m)
                overview(m)
                kickList(m)
                if !m.unmatchedMarks.isEmpty { marksSection(m) }
                analytics(m)
                cameras(m)
            } else {
                Section { Text(problem ?? "Loading…").foregroundStyle(.secondary) }
            }
        }
        .navigationTitle(manifest?.name ?? "Session")
        .task(id: "\(app.revision)-\(processor.revision)") { reload() }
        .onAppear { processor.start(app: app) }
        .navigationDestination(item: $playback) { SessionPlaybackView(request: $0) }
        .sheet(isPresented: $exportingDiagnostics) { SessionDiagnosticsExportView(sessionID: sessionID) }
        .fullScreenCover(isPresented: $remoteCameras, onDismiss: { reload() }) {
            RemoteControlView(sessionID: sessionID) {}
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { exportingDiagnostics = true } label: { Label("Export Diagnostics", systemImage: "square.and.arrow.up") }
            }
        }
        .navigationDestination(item: $openedAnalysis) { AnalysisResultsView(analysisID: $0) }
        // Processing stops when KickLab leaves the screen (iOS suspends it); it picks up
        // from the saved queue when the athlete comes back to this session.
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { processor.start(app: app) }
        }
        .sheet(item: $picking, onDismiss: {
            // The second pick of a split opens once the first picker has gone away.
            if let next = nextPick { nextPick = nil; picking = next }
        }) { pick in
            SessionTimePickerView(url: app.services.trainingSessions.url(session: sessionID, relativePath: pick.source.relativePath),
                                  initial: pick.initial, frameRate: pick.source.nominalFrameRate ?? 30, title: title(pick)) { time in
                apply(pick, time: time)
            }
        }
        .fileImporter(isPresented: $importingCamera, allowedContentTypes: [.movie, .quickTimeMovie, .mpeg4Movie]) { result in
            guard case .success(let url) = result else { return }
            Task {
                do {
                    _ = try await TrainingSessionImport.importSource(app: app, sessionID: sessionID, from: url, role: .rear)
                    processor.start(app: app)
                } catch {
                    problem = "The video couldn't be imported (\(error.localizedDescription))."
                }
                reload()
            }
        }
        .confirmationDialog("Mark as \(confirmingReject?.practice == true ? "a practice swing" : "not a kick")?", isPresented: Binding(
            get: { confirmingReject != nil }, set: { if !$0 { confirmingReject = nil } }), titleVisibility: .visible) {
            Button(confirmingReject?.practice == true ? "Practice Swing" : "Not a Kick", role: .destructive) {
                if let r = confirmingReject { problem = SessionReviewActions.reject(candidateID: r.candidate.id, practiceSwing: r.practice, processor: processor, app: app) }
                confirmingReject = nil
            }
        } message: {
            Text("The recording is kept. If this kick was already analyzed, its clip, analysis and result are deleted.")
        }
        .confirmationDialog("Delete this recording?", isPresented: Binding(get: { confirmingSourceDelete != nil }, set: { if !$0 { confirmingSourceDelete = nil } }),
                            titleVisibility: .visible) {
            Button("Delete Recording", role: .destructive) { if let s = confirmingSourceDelete { deleteSource(s) }; confirmingSourceDelete = nil }
        } message: {
            Text("Analyzed kicks keep their own clips. This can't be undone.")
        }
    }

    // MARK: Sections

    private func header(_ m: TrainingSessionManifest) -> some View {
        Section {
            VStack(alignment: .leading, spacing: 4) {
                Text(m.createdAt, style: .date).font(.subheadline)
                if let loc = m.location { Text(loc).font(.caption).foregroundStyle(.secondary) }
                Text("Session recordings on this iPhone: \(ByteCountFormatter.string(fromByteCount: app.services.trainingSessions.byteCount(m.id), countStyle: .file))")
                    .font(.caption).foregroundStyle(.secondary)
                let status = SessionStatus.make(m)
                Text(status.headline).font(.subheadline.weight(.semibold))
                    .foregroundStyle(status.stage == .awaitingReview ? Color.orange : Color.primary)
                if !status.details.isEmpty {
                    Text(status.details.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
                }
                Text(processor.phase.text).font(.caption)
                    .foregroundStyle(isFailure ? Color.orange : Color.secondary)
                let p = SessionProcessingQueue.progress(m)
                if p.total > 0 { ProgressView(value: Double(p.done + p.failed), total: Double(max(p.total, 1))) }
            }
            HStack {
                if m.processing.paused {
                    Button("Resume Processing") { processor.resume(app: app) }
                } else if processor.isRunning {
                    Button("Pause Processing") { processor.pause(app: app) }
                } else {
                    Button("Process Kicks") { processor.start(app: app) }
                }
                Spacer()
                let recordings = m.sources.filter { $0.status == .finalized || $0.status == .recovered }
                if recordings.count > 1 {
                    Menu {
                        ForEach(recordings) { src in
                            Button(recordingTitle(src, manifest: m)) { picking = TimePick(purpose: .addKick, source: src, initial: 0) }
                        }
                    } label: { Label("Add Missed Kick", systemImage: "plus") }
                } else {
                    Button { addKick(m) } label: { Label("Add Missed Kick", systemImage: "plus") }
                        .disabled(m.referenceSource == nil)
                }
            }
            .buttonStyle(.bordered)
            if let problem { Text(problem).font(.caption).foregroundStyle(.red) }
        } footer: {
            Text("Processing runs while KickLab is open on screen; iOS pauses it in the background and it picks up where it left off.")
        }
    }

    private var isFailure: Bool { if case .failed = processor.phase { return true }; return false }

    private func overview(_ m: TrainingSessionManifest) -> some View {
        let s = SessionReviewSummary.make(m, results: results)
        return Section("Overview") {
            Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 6) {
                GridRow { stat("Counted kicks", "\(s.attempts)"); stat("To review", "\(s.needsReview)"); stat("Not analyzed yet", "\(SessionStatus.make(m).analysisPending)") }
                GridRow { stat("Analyzed", "\(s.analyzed)"); stat("Failed", "\(s.failed)"); stat("Rejected", "\(s.rejected)") }
                GridRow { stat("Results", "\(s.resultsEntered) of \(s.attempts)"); stat("Made", "\(s.made)"); stat("Make %", s.makeRate.percentage.map { "\(Int($0.rounded()))%" } ?? "—") }
            }
            if s.resultsEntered > 0 {
                Text("Missed left \(s.missedLeft) · right \(s.missedRight) · short \(s.short)\(s.otherMisses > 0 ? " · other \(s.otherMisses)" : "")")
                    .font(.caption).foregroundStyle(.secondary)
                if let note = s.makeRate.sampleNote { Text(note).font(.caption2).foregroundStyle(.secondary) }
            }
        }
    }

    private func stat(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(value).font(.headline.monospacedDigit())
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    /// "Mark Kick" taps where no kick was found: the athlete adds it by hand or dismisses it.
    private func marksSection(_ m: TrainingSessionManifest) -> some View {
        Section {
            ForEach(m.unmatchedMarks) { mark in
                HStack {
                    Text(String(format: "Marked at %@", CaptureFormat.elapsed(mark.sourceTime))).font(.subheadline.monospacedDigit())
                    Spacer()
                    Button("Find Kick") {
                        if let src = m.source(mark.sourceID) { picking = TimePick(purpose: .addKick, source: src, initial: max(0, mark.sourceTime - 1)) }
                    }
                    .buttonStyle(.bordered)
                    Button("Dismiss") { mutate { TrainingSessionEditor.removeMark(&$0, markID: mark.id, now: .now) } }
                        .buttonStyle(.borderless)
                }
            }
        } header: {
            Text("Your marks without a kick")
        } footer: {
            Text("You tapped Mark Kick here, but no kick was found nearby. Find the contact frame to add it, or dismiss the mark.")
        }
    }

    private func kickList(_ m: TrainingSessionManifest) -> some View {
        let secondaries = Set(m.pairs.map(\.secondaryCandidateID))
        let rows = m.candidates.filter { $0.status.isActive && !secondaries.contains($0.id) }.sorted { m.sharedContact($0) < m.sharedContact($1) }
        let reference = m.referenceSource
        return Section {
            if rows.isEmpty { Text("No kicks yet. They appear here as the recording is processed.").foregroundStyle(.secondary) }
            ForEach(Array(rows.enumerated()), id: \.element.id) { index, c in
                kickRow(c, number: index + 1, manifest: m, referenceStart: reference?.recordedAt)
            }
        } header: {
            Text("Kicks")
        } footer: {
            Text("Tap a result to record it. Touch and hold a kick to fix its contact, clip, split or merge it, or pair camera angles. Results, distance and hash are what you enter; KickLab never guesses them from the video.")
        }
    }

    @ViewBuilder
    private func kickRow(_ c: SessionKickCandidate, number: Int, manifest m: TrainingSessionManifest, referenceStart: Date?) -> some View {
        let kick = c.kickID.flatMap { ModelLookup.kick($0, in: app.context) }
        let result = results[c.id]?.result
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .top, spacing: 10) {
                thumbnail(kick)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Kick \(number) · \(CaptureFormat.elapsed(c.contactTime ?? c.startTime))\(recordingLabel(c, manifest: m))").font(.subheadline.weight(.semibold))
                    Text(kick.map { KickRowPresentation(kick: $0).detail } ?? c.details.summary).font(.caption).foregroundStyle(.secondary)
                    Text(SessionKickStatusText.line(c)).font(.caption.weight(.semibold))
                        .foregroundStyle(SessionKickStatusText.nextStep(c) == .review || SessionKickStatusText.nextStep(c) == .findContact ? Color.orange : Color.primary)
                    Text(statusLine(c, manifest: m)).font(.caption2).foregroundStyle(.secondary)
                    if c.approachIncomplete { Text("Approach not fully in the recording").font(.caption2).foregroundStyle(.orange) }
                    if c.followThroughIncomplete { Text("Follow-through not fully in the recording").font(.caption2).foregroundStyle(.orange) }
                    if m.pairs.contains(where: { $0.primaryCandidateID == c.id }) {
                        Text("Filmed by both cameras · touch and hold for options").font(.caption2).foregroundStyle(.secondary)
                    } else if m.cameraIDs.count > 1, let src = m.source(c.sourceID) {
                        Text("Only in: \(src.role.title)").font(.caption2).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 4)
            }
            // Hotfix 2: every action is a visible button (no touch-and-hold needed).
            if SessionKickStatusText.nextStep(c) == .findContact {
                Button { playback = SessionPlaybackRequest(sessionID: sessionID, sourceID: c.sourceID, candidateID: c.id) } label: {
                    Label("Find Contact Manually", systemImage: "scope")
                }
                .buttonStyle(.borderedProminent)
                .font(.caption)
            }
            HStack {
                Button { playback = SessionPlaybackRequest(sessionID: sessionID, sourceID: c.sourceID, candidateID: c.id) } label: {
                    Label("Watch Clip", systemImage: "play.rectangle")
                }
                Button { playback = SessionPlaybackRequest(sessionID: sessionID, sourceID: c.sourceID, candidateID: c.id) } label: {
                    Label("Edit Contact", systemImage: "scope")
                }
                if let analysisID = c.analysis.analysisID, c.analysis.status == .done {
                    Button { openedAnalysis = analysisID } label: { Label("Report", systemImage: "doc.text") }
                }
            }
            .buttonStyle(.bordered)
            .font(.caption)
            HStack {
                if c.status == .needsReview || c.status == .pending && c.kickID == nil && c.analysis.status == .notQueued {
                    Button("Confirm Kick") { mutate { try TrainingSessionEditor.accept(&$0, candidateID: c.id, now: .now) }; processor.start(app: app) }
                }
                if c.kickID != nil, c.analysis.status != .queued, c.analysis.status != .running {
                    Button("Reanalyze") { mutate { try TrainingSessionEditor.requestReanalysis(&$0, candidateID: c.id, now: .now) }; processor.start(app: app) }
                }
                Button("Not a Kick") { confirmingReject = RejectRequest(candidate: c, practice: false) }
                Button("Practice") { confirmingReject = RejectRequest(candidate: c, practice: true) }
            }
            .buttonStyle(.bordered)
            .font(.caption)
            if let kick, kick.kickType == .fieldGoal || kick.kickType == .pat {
                HStack(spacing: 6) {
                    ForEach(SessionKickDrafts.quickResults, id: \.self) { r in
                        Button(shortTitle(r)) { problem = SessionReviewActions.setResult(r, kickID: kick.id, app: app) }
                            .buttonStyle(.bordered)
                            .tint((result ?? .unknown) == r && r != .unknown ? Color.accentColor : Color.secondary)
                            .font(.caption)
                            .accessibilityLabel(r.displayName)
                            .accessibilityAddTraits((result ?? .unknown) == r ? .isSelected : [])
                    }
                }
            }
        }
        .padding(.vertical, 4)
        .contextMenu { menu(c, manifest: m) }
    }

    @ViewBuilder
    private func menu(_ c: SessionKickCandidate, manifest m: TrainingSessionManifest) -> some View {
        if let source = m.source(c.sourceID) {
            Button { picking = TimePick(purpose: .contact(c.id), source: source, initial: c.contactTime ?? c.startTime) } label: { Label("Confirm Contact Frame…", systemImage: "scope") }
            Button { picking = TimePick(purpose: .start(c.id), source: source, initial: c.startTime) } label: { Label("Set Clip Start…", systemImage: "arrow.left.to.line") }
            Button { picking = TimePick(purpose: .end(c.id), source: source, initial: c.endTime) } label: { Label("Set Clip End…", systemImage: "arrow.right.to.line") }
        }
        if c.kickID != nil {
            Button { mutate { SessionProcessingQueue.requeue(&$0, candidateID: c.id) }; processor.start(app: app) } label: { Label("Reanalyze", systemImage: "arrow.clockwise") }
            if let analysisID = c.analysis.analysisID {
                NavigationLink(value: AppRoute.compareKicks(analysisID)) { Label("Compare", systemImage: "rectangle.split.2x1") }
            }
            if let kickID = c.kickID, m.pairs.contains(where: { $0.primaryCandidateID == c.id && m.candidate($0.secondaryCandidateID)?.kickID == kickID }) {
                NavigationLink(value: AppRoute.pairPlayback(kick: kickID)) { Label("Watch Both Cameras", systemImage: "video.badge.checkmark") }
            }
        }
        if c.kickID == nil, let source = m.source(c.sourceID) {
            Button { picking = TimePick(purpose: .splitFirst(c.id), source: source, initial: c.startTime) } label: { Label("Split Into Two Kicks…", systemImage: "scissors") }
        }
        cameraPairingMenu(c, manifest: m)
        if let next = m.candidates(of: c.sourceID).first(where: { ($0.contactTime ?? $0.startTime) > (c.contactTime ?? c.startTime) && $0.status.isActive }) {
            Button { mutate { _ = try TrainingSessionEditor.merge(&$0, c.id, next.id, now: .now) } } label: { Label("Merge With Next", systemImage: "arrow.triangle.merge") }
        }
        Button(role: .destructive) { confirmingReject = RejectRequest(candidate: c, practice: false) } label: { Label("Not a Kick", systemImage: "xmark") }
        Button { confirmingReject = RejectRequest(candidate: c, practice: true) } label: { Label("Practice Swing", systemImage: "figure.walk") }
    }

    /// Pairing by hand: a second-camera kick with a camera A kick, or undoing a pair whose
    /// second-camera clip isn't attached yet.
    @ViewBuilder
    private func cameraPairingMenu(_ c: SessionKickCandidate, manifest m: TrainingSessionManifest) -> some View {
        let choices = MultiCameraSync.pairingChoices(m, for: c.id)
        if c.kickID == nil, !choices.isEmpty {
            Menu {
                ForEach(choices) { p in
                    Button(String(format: "Kick at %@ (%+.1f s)", CaptureFormat.elapsed(p.contactTime ?? p.startTime), m.sharedContact(p) - m.sharedContact(c))) {
                        mutate { try MultiCameraSync.pairManually(&$0, primary: p.id, secondary: c.id, now: .now) }
                        processor.start(app: app)
                    }
                }
            } label: { Label("Same Kick As…", systemImage: "link") }
        }
        ForEach(m.pairs.filter { $0.primaryCandidateID == c.id && m.candidate($0.secondaryCandidateID)?.kickID == nil }) { pair in
            Button { mutate { MultiCameraSync.unpair(&$0, pairID: pair.id, now: .now) } } label: { Label("Not the Same Kick (Unpair Cameras)", systemImage: "link.badge.plus") }
        }
    }

    private func analytics(_ m: TrainingSessionManifest) -> some View {
        let s = SessionReviewSummary.make(m, results: results)
        let views = Set(entries.map(\.view))
        return Section {
            ForEach(s.byDistance, id: \.bucket) { b in
                LabeledContent("\(b.bucket.displayName) yd") { Text(b.rate.text + (b.rate.sampleNote.map { " · \($0)" } ?? "")).font(.caption) }
            }
            ForEach(s.byHash, id: \.hash) { h in
                LabeledContent(h.hash.displayName) { Text(h.rate.text).font(.caption) }
            }
            ForEach(Array(views).sorted { $0.rawValue < $1.rawValue }, id: \.self) { view in
                let trends = SessionAnalytics.trends(entries, view: view)
                if !trends.isEmpty {
                    Text(view.title).font(.caption.weight(.semibold))
                    ForEach(trends) { t in
                        VStack(alignment: .leading, spacing: 1) {
                            Text(t.name).font(.caption)
                            if let range = t.range, let level = t.level {
                                Text("Varied by \(DisplayFormat.metricValue(range, unit: t.key.definition.unit)) across \(t.values.count) kicks · \(level.title)").font(.caption2).foregroundStyle(.secondary)
                            } else {
                                Text("\(t.values.count) kicks measured (4 needed for consistency)").font(.caption2).foregroundStyle(.secondary)
                            }
                            if let h = t.halvesText { Text(h).font(.caption2) }
                        }
                    }
                }
            }
            if let ref = referenceAnalysisID(m) {
                NavigationLink(value: AppRoute.compareKicks(ref)) { Label("Compare with your reference kick", systemImage: "star") }
            }
        } header: {
            Text("Session analytics")
        } footer: {
            Text("Descriptive only: changes across a session don't show fatigue or why a kick was made or missed, and kicks with poor recording quality aren't counted in measurement trends.")
        }
    }

    private func cameras(_ m: TrainingSessionManifest) -> some View {
        Section {
            ForEach(Array(m.cameraIDs.enumerated()), id: \.element) { index, cameraID in
                let segments = m.segments(ofCamera: cameraID)
                ForEach(Array(segments.enumerated()), id: \.element.id) { n, s in
                    VStack(alignment: .leading, spacing: 4) {
                        if n == 0 {
                            Picker("View", selection: Binding(get: { s.role }, set: { r in
                                problem = SessionReviewActions.setRole(r, sourceID: s.id, processor: processor, app: app)
                                reload()
                            })) {
                                ForEach(SessionCameraRole.allCases, id: \.self) { Text($0.title).tag($0) }
                            }
                        }
                        if n == 0, let remote = s.remote {
                            Label(remote.cameraName, systemImage: "iphone.radiowaves.left.and.right").font(.caption)
                        }
                        Text(segments.count > 1 ? "Recording \(n + 1) of \(segments.count) · \(sourceLine(s))" : sourceLine(s))
                            .font(.caption2).foregroundStyle(.secondary)
                        if !s.isReference {
                            Text(syncLine(s.sync)).font(.caption2).foregroundStyle(s.sync.provenance == .none ? Color.orange : Color.secondary)
                        }
                        Button { playback = SessionPlaybackRequest(sessionID: sessionID, sourceID: s.id, candidateID: nil) } label: {
                            Label("Watch Full Recording", systemImage: "play.rectangle")
                        }
                        .buttonStyle(.bordered)
                        .font(.caption)
                        .disabled(s.status == .recording || s.status == .missing)
                    }
                    .swipeActions {
                        Button(role: .destructive) { confirmingSourceDelete = s } label: { Label("Delete", systemImage: "trash") }
                    }
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel(index == 0 ? "Camera A" : "Camera \(index + 1)")
            }
            if m.cameraIDs.count >= 2 {
                NavigationLink(value: AppRoute.sessionSync(sessionID)) { Label("Synchronize Cameras…", systemImage: "timer") }
                Text("\(m.pairs.count) kick\(m.pairs.count == 1 ? "" : "s") paired across cameras (each counts once).").font(.caption)
            }
            Picker("Where the ball goes", selection: Binding(get: { m.recordingContext ?? .unknown }, set: { v in
                mutate { TrainingSessionEditor.setRecordingContext(&$0, v, now: .now) }
            })) {
                ForEach(RecordingContext.allCases, id: \.self) { Text($0.title).tag($0) }
            }
            Button { remoteCameras = true } label: { Label("Remote Cameras…", systemImage: "iphone.radiowaves.left.and.right") }
            Button { importingCamera = true } label: { Label("Import Second Camera's Video", systemImage: "video.badge.plus") }
        } header: {
            Text("Cameras and recordings")
        } footer: {
            Text("Changing a view applies to kicks analyzed next (use Reanalyze). Recordings made with this iPhone in this session are one camera: later recordings continue its timeline and need no sync. Remote Cameras records on your other iPhones running KickLab and synchronizes them automatically. Camera B can also record with the iPhone Camera app; import its video here, set its view and synchronize by marking the same moment in both videos. A second camera's kicks wait until it is synchronized, so the same kick isn't counted twice.")
        }
    }

    private func recordingTitle(_ s: SessionSource, manifest m: TrainingSessionManifest) -> String {
        let segments = m.segments(ofCamera: m.cameraID(of: s))
        let n = (segments.firstIndex { $0.id == s.id } ?? 0) + 1
        let length = s.durationSeconds.map { " · " + CaptureFormat.elapsed($0) } ?? ""
        return segments.count > 1 ? "\(s.role.title) · recording \(n)\(length)" : "\(s.role.title)\(length)"
    }

    /// " · recording 2" when camera A has several recordings (times are within each one).
    private func recordingLabel(_ c: SessionKickCandidate, manifest m: TrainingSessionManifest) -> String {
        guard let s = m.source(c.sourceID) else { return "" }
        let segments = m.segments(ofCamera: m.cameraID(of: s))
        guard segments.count > 1, let i = segments.firstIndex(where: { $0.id == s.id }) else { return "" }
        return " · recording \(i + 1)"
    }

    // MARK: Helpers

    private func reload() {
        let store = app.services.trainingSessions
        guard let m = try? store.load(sessionID) else { problem = "This session couldn't be read."; manifest = nil; return }
        manifest = m
        results = SessionReviewActions.results(m, app: app)
        entries = SessionReviewActions.rankingEntries(m, app: app)
    }

    private func mutate(_ change: (inout TrainingSessionManifest) throws -> Void) {
        do {
            try processor.update(app, change)
            problem = nil
        } catch let e as TrainingSessionEditor.EditError {
            problem = message(e)
        } catch {
            problem = "Couldn't update the session."
        }
        reload()
    }

    private func message(_ e: TrainingSessionEditor.EditError) -> String { e.userMessage }

    private func addKick(_ m: TrainingSessionManifest) {
        guard let src = m.referenceSource else { return }
        picking = TimePick(purpose: .addKick, source: src, initial: 0)
    }

    private func title(_ p: TimePick) -> String {
        switch p.purpose {
        case .addKick: "Move to the moment the foot touches the ball"
        case .contact: "Confirm the contact frame"
        case .start: "Clip start"
        case .end: "Clip end"
        case .splitFirst: "Split: the FIRST kick's contact frame"
        case .splitSecond: "Split: the SECOND kick's contact frame"
        }
    }

    private func apply(_ p: TimePick, time: Double) {
        switch p.purpose {
        case .addKick: mutate { _ = try TrainingSessionEditor.addManualKick(&$0, sourceID: p.source.id, contact: time, now: .now) }
        case .contact(let id): mutate { try TrainingSessionEditor.confirmContact(&$0, candidateID: id, at: time, now: .now) }
        case .start(let id): mutate { m in try TrainingSessionEditor.adjustBoundaries(&m, candidateID: id, start: time, end: m.candidate(id)?.endTime ?? time, now: .now) }
        case .end(let id): mutate { m in try TrainingSessionEditor.adjustBoundaries(&m, candidateID: id, start: m.candidate(id)?.startTime ?? time, end: time, now: .now) }
        case .splitFirst(let id):
            nextPick = TimePick(purpose: .splitSecond(id, time), source: p.source, initial: time + 3)
            return
        case .splitSecond(let id, let first):
            mutate { _ = try TrainingSessionEditor.split(&$0, candidateID: id, firstContact: min(first, time), secondContact: max(first, time), now: .now) }
        }
        processor.start(app: app)
    }

    private func deleteSource(_ s: SessionSource) {
        mutate { try TrainingSessionEditor.removeSource(&$0, sourceID: s.id, now: .now) }
        if manifest?.source(s.id) == nil { app.services.trainingSessions.deleteSourceFile(session: sessionID, relativePath: s.relativePath) }
    }

    private func thumbnail(_ kick: Kick?) -> some View {
        let url = kick.flatMap { k in (k.videos ?? []).first(where: \.isPrimary) }.flatMap { app.services.videos.thumbnailURL(for: $0) }
        return Group {
            if let url, let image = UIImage(contentsOfFile: url.path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "video").foregroundStyle(.secondary)
            }
        }
        .frame(width: 56, height: 56)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.secondary.opacity(0.12)))
        .accessibilityHidden(true)
    }

    private func statusLine(_ c: SessionKickCandidate, manifest m: TrainingSessionManifest) -> String {
        var parts = [c.status.title]
        switch c.analysis.status {
        case .queued: parts.append("waiting for analysis")
        case .running: parts.append("analyzing…")
        case .failed: parts.append("analysis failed\(c.analysis.lastError.map { ": \($0)" } ?? "")")
        case .done: if let o = c.analysis.contactOutcome.flatMap(ContactOutcome.init(rawValue:)) { parts.append(o.title) }
        case .notQueued: break
        }
        parts.append(detectionText(c))
        let partners = m.pairs.filter { $0.primaryCandidateID == c.id }.count
        if partners > 0 { parts.append(partners > 1 ? "seen by \(partners + 1) cameras" : "seen by both cameras") }
        return parts.joined(separator: " · ")
    }

    private func detectionText(_ c: SessionKickCandidate) -> String {
        switch c.discovery {
        case .manual: return "added by you"
        case .edited: return "edited by you"
        case .automatic:
            let e = c.evidence
            if e.ballDeparted && e.swingNearBall { return "found: ball left + leg swing" }
            if e.ballDeparted { return "found: ball left (no swing seen)" }
            return "found: leg swing only"
        }
    }

    private func shortTitle(_ r: KickResult) -> String {
        switch r {
        case .made: "Made"
        case .missedLeft: "Left"
        case .missedRight: "Right"
        case .short: "Short"
        default: "—"
        }
    }

    private func sourceLine(_ s: SessionSource) -> String {
        var parts = [s.origin == .imported ? "Imported" : "Recorded in KickLab"]
        if let d = s.durationSeconds { parts.append(CaptureFormat.elapsed(d)) }
        if let f = s.nominalFrameRate { parts.append("\(Int(f.rounded())) fps") }
        switch s.status {
        case .recovered: parts.append("recovered after an interruption")
        case .missing: parts.append("file missing")
        case .recording: parts.append("recording")
        case .finalized: break
        }
        return parts.joined(separator: " · ")
    }

    private func syncLine(_ s: SourceSync) -> String {
        switch s.provenance {
        case .reference: "Reference timeline"
        case .manualEvent: String(format: "Synchronized by you · offset %.3f s ± %.3f s", s.offsetSeconds, s.uncertaintySeconds ?? 0)
        case .wallClock: String(format: "Rough sync from device clocks (± %.0f s) — mark an event to synchronize", s.uncertaintySeconds ?? 2)
        case .sameCamera: "Same camera, recorded later — on its timeline automatically (no sync needed)"
        case .sharedClock: String(format: "Synchronized automatically by the remote cameras' shared clock · ± %.2f s — mark an event to refine", s.uncertaintySeconds ?? 0)
        case .none: "Not synchronized — its kicks wait until you synchronize"
        }
    }

    private func referenceAnalysisID(_ m: TrainingSessionManifest) -> UUID? {
        m.attempts.compactMap(\.analysis.analysisID).last
    }
}

/// Scrub a recording and pick a moment (frame stepping at the recording's frame rate).
struct SessionTimePickerView: View {
    @Environment(\.dismiss) private var dismiss
    let url: URL
    let initial: Double
    let frameRate: Double
    let title: String
    let onPick: (Double) -> Void
    @State private var player: ValidationPlayer?
    @State private var time: Double = 0
    @State private var duration: Double = 1

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                ZStack {
                    Color.black
                    if let player { ValidationVideoSurface(player: player.player) }
                }
                .frame(height: 320)
                Text(title).font(.subheadline)
                Slider(value: Binding(get: { time }, set: { time = $0; player?.seek(to: $0) }), in: 0...max(duration, 0.1))
                    .accessibilityLabel("Time in the recording")
                HStack {
                    Button { step(-1) } label: { Image(systemName: "backward.frame") }.accessibilityLabel("Back one frame")
                    Text(String(format: "%.3f s", time)).font(.body.monospacedDigit()).frame(minWidth: 100)
                    Button { step(1) } label: { Image(systemName: "forward.frame") }.accessibilityLabel("Forward one frame")
                }
                .buttonStyle(.bordered)
                Spacer()
            }
            .padding()
            .navigationTitle("Pick a Moment")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Use This Frame") { onPick(time); dismiss() } }
            }
            .task {
                let p = ValidationPlayer(url: url)
                player = p
                duration = (try? await AVURLAsset(url: url).load(.duration).seconds).flatMap { $0.isFinite ? $0 : nil } ?? 1
                time = min(initial, duration)
                p.seek(to: time)
            }
            .onDisappear { player?.stop() }
        }
    }

    private func step(_ frames: Int) {
        time = min(max(0, time + Double(frames) / max(frameRate, 1)), duration)
        player?.seek(to: time)
    }
}

/// Build 21 — manual synchronization of two cameras: mark the same moment (e.g. the foot
/// touching the ball in one kick) in both recordings. Raw timestamps never change; the
/// offset and how it was set are saved with the session.
struct SessionSyncView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let sessionID: UUID
    @State private var manifest: TrainingSessionManifest?
    @State private var otherID: UUID?
    @State private var referenceMark: Double?
    @State private var otherMark: Double?
    @State private var picking: (SessionSource, Bool)?
    @State private var showingPicker = false
    /// Which camera A recording the reference mark is in (nil = the first).
    @State private var referenceSegmentID: UUID?

    init(sessionID: UUID) { self.sessionID = sessionID }

    var body: some View {
        Form {
            if let m = manifest, let primary = m.primaryCameraID,
               let reference = m.source(referenceSegmentID ?? primary) ?? m.referenceSource {
                // Other cameras only (their first recording); later recordings of a camera follow it.
                let others = m.sources.filter { m.cameraID(of: $0) != primary && !m.isLaterSegment($0) }
                let aSegments = m.segments(ofCamera: primary)
                if aSegments.count > 1 {
                    Section {
                        Picker("Camera A recording", selection: Binding(get: { reference.id }, set: { referenceSegmentID = $0; referenceMark = nil })) {
                            ForEach(Array(aSegments.enumerated()), id: \.element.id) { i, seg in
                                Text("Recording \(i + 1)\(seg.durationSeconds.map { " · " + CaptureFormat.elapsed($0) } ?? "")").tag(seg.id)
                            }
                        }
                    } footer: {
                        Text("Choose the camera A recording that shows the same moment as the other camera.")
                    }
                }
                Section {
                    Picker("Camera to synchronize", selection: $otherID) {
                        ForEach(others) { o in Text(o.remote.map { "\($0.cameraName) · \(o.role.title)" } ?? o.role.title).tag(Optional(o.id)) }
                    }
                } footer: {
                    Text("Pick one moment you can see clearly in both videos — the foot touching the ball in one kick works well.")
                }
                Section("1. In \(reference.role.title)") {
                    Button(referenceMark.map { String(format: "Marked at %.3f s — change", $0) } ?? "Mark the moment…") { picking = (reference, true); showingPicker = true }
                }
                if let other = others.first(where: { $0.id == otherID }) {
                    Section("2. In \(other.role.title)") {
                        Button(otherMark.map { String(format: "Marked at %.3f s — change", $0) } ?? "Mark the same moment…") { picking = (other, false); showingPicker = true }
                    }
                    Section {
                        Button("Synchronize") { synchronize(reference: reference, other: other) }
                            .disabled(referenceMark == nil || otherMark == nil)
                        Toggle("Keep this camera's kicks separate (don't synchronize)", isOn: Binding(
                            get: { m.processing.separateKicks.contains(other.id.uuidString) },
                            set: { on in
                                app.sessionProcessor(for: sessionID).update(app) { x in
                                    if on { x.processing.separateKicks.insert(other.id.uuidString) } else { x.processing.separateKicks.remove(other.id.uuidString) }
                                }
                                reload()
                            }))
                    } footer: {
                        Text("Synchronizing pairs the kicks both cameras saw, so each counts once. Precision is about one frame of each camera; the offset you set is kept and can be changed.")
                    }
                }
            } else {
                Text("Import a second camera's video first.")
            }
        }
        .navigationTitle("Synchronize Cameras")
        .task { reload() }
        .sheet(isPresented: $showingPicker) {
            if let (source, isReference) = picking {
                SessionTimePickerView(url: app.services.trainingSessions.url(session: sessionID, relativePath: source.relativePath),
                                      initial: (isReference ? referenceMark : otherMark) ?? 0, frameRate: source.nominalFrameRate ?? 30,
                                      title: "Move to the moment you'll also mark in the other video") { t in
                    if isReference { referenceMark = t } else { otherMark = t }
                }
            }
        }
    }

    private func reload() {
        manifest = try? app.services.trainingSessions.load(sessionID)
        if otherID == nil, let m = manifest, let primary = m.primaryCameraID {
            otherID = m.sources.first { m.cameraID(of: $0) != primary && !m.isLaterSegment($0) }?.id
        }
        if let o = manifest?.sources.first(where: { $0.id == otherID }), o.sync.provenance == .manualEvent {
            referenceMark = referenceMark ?? o.sync.referenceMarkTime
            otherMark = otherMark ?? o.sync.sourceMarkTime
        }
    }

    private func synchronize(reference: SessionSource, other: SessionSource) {
        guard let r = referenceMark, let o = otherMark else { return }
        // A mark in a later camera A recording is moved onto camera A's timeline first.
        var sync = MultiCameraSync.manualSync(referenceMark: r + reference.sync.offsetSeconds, sourceMark: o,
                                              referenceFrameRate: reference.nominalFrameRate, sourceFrameRate: other.nominalFrameRate, now: .now)
        if !reference.isReference { sync.uncertaintySeconds = (sync.uncertaintySeconds ?? 0) + (reference.sync.uncertaintySeconds ?? 0) }
        let processor = app.sessionProcessor(for: sessionID)
        processor.update(app) { MultiCameraSync.setSync(&$0, sourceID: other.id, sync: sync, now: .now) }
        processor.start(app: app)
        dismiss()
    }
}
