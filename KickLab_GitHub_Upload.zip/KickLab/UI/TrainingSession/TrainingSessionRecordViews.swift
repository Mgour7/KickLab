import AVKit
import SwiftUI
import UniformTypeIdentifiers

// Build 21 — Training Sessions 1.0 screens: setup, live recording, Session Review (kick
// list, quick results, corrections, analytics), cameras and manual synchronization.

/// Session defaults before recording (or for an imported whole-practice video).
struct TrainingSessionSetupView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var location = ""
    @State private var details = SessionKickDetails(kickType: .fieldGoal, distanceYards: 30, hash: .center)
    @State private var request = CaptureSettingsStore.load()
    @State private var problem: String?
    /// Imports a recorded practice instead of recording one.
    let importsVideo: Bool
    let onCreated: (UUID, URL?) -> Void
    @State private var importing = false
    @State private var cameraRole: SessionCameraRole = .unspecified
    @State private var context: RecordingContext = .unknown

    /// Build 24: recorded by remote cameras (each camera's view is set on the controller).
    let usesRemoteCameras: Bool

    init(importsVideo: Bool = false, usesRemoteCameras: Bool = false, onCreated: @escaping (UUID, URL?) -> Void) {
        self.importsVideo = importsVideo
        self.usesRemoteCameras = usesRemoteCameras
        self.onCreated = onCreated
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Session") {
                    TextField("Name (optional)", text: $name)
                    TextField("Practice location (optional)", text: $location)
                }
                KickDetailsSection(details: $details, showsDistance: true)
                Section {
                    if !usesRemoteCameras {
                        Picker("Camera view", selection: $cameraRole) {
                            ForEach(SessionCameraRole.allCases, id: \.self) { Text($0.title).tag($0) }
                        }
                    }
                    Picker("Where the ball goes", selection: $context) {
                        ForEach(RecordingContext.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                } header: {
                    Text("Setup")
                } footer: {
                    Text("Leave the view unset unless the camera is squarely side-on or behind: KickLab then works it out from the movement (a diagonal view counts). Both can be changed later in Session Review. The net setting is recorded for review and diagnostics; it doesn't change any score.")
                }
                if !importsVideo {
                    Section {
                        Picker("Quality", selection: $request) {
                            ForEach(CaptureRequest.choices, id: \.title) { Text($0.title).tag($0) }
                        }
                        Toggle("Record sound", isOn: $request.recordsAudio)
                    } header: {
                        Text("Camera")
                    } footer: {
                        if usesRemoteCameras {
                            Text("Every remote camera records at this quality (a camera that can't falls back and says so). Put each tripod iPhone in place, turned sideways: one beside the kicking area (side view), one behind the kicker (rear view), and optionally one more angle. You'll pick each camera's view on the next screen.")
                        } else {
                            Text("Put the iPhone on a tripod beside the kicking area (side view), turned sideways. Press Record once and kick; you don't need to touch the phone between kicks. Kicks are found after you stop.")
                        }
                    }
                }
                if let problem { Section { Text(problem).foregroundStyle(.red) } }
            }
            .navigationTitle(importsVideo ? "Import Practice Video" : (usesRemoteCameras ? "Remote Cameras Session" : "Training Session"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(importsVideo ? "Choose Video" : "Start") {
                        if importsVideo { importing = true } else { create(url: nil) }
                    }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.movie, .quickTimeMovie, .mpeg4Movie]) { result in
                if case .success(let url) = result { create(url: url) }
            }
        }
    }

    private func create(url: URL?) {
        CaptureSettingsStore.save(request)
        do {
            let m = try TrainingSessionLibrary.create(app: app, name: name, location: location.isEmpty ? nil : location, defaults: details,
                                                      cameraRole: cameraRole, context: context)
            dismiss()
            onCreated(m.id, url)
        } catch {
            problem = UserFacingError.message(for: error)
        }
    }
}

/// The live recording screen. The phone can sit untouched on a tripod for the whole practice.
struct TrainingSessionRecordView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @State private var model: TrainingSessionRecordModel
    @State private var editingDetails = false
    @State private var draftDetails = SessionKickDetails()
    let onFinish: () -> Void

    init(sessionID: UUID, onFinish: @escaping () -> Void) {
        _model = State(initialValue: TrainingSessionRecordModel(sessionID: sessionID))
        self.onFinish = onFinish
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CameraPreview(recorder: model.recorder).ignoresSafeArea()
            VStack(spacing: 8) {
                header
                Spacer()
                if let w = model.recorder.warning { banner(w) }
                if let p = model.problem { banner(p) }
                controls
            }
            .padding()
        }
        .task { await model.load(app: app) }
        .onChange(of: scenePhase) { _, phase in
            // Never record in the background: leaving the screen finishes the file.
            // ("inactive" — Control Center, a Siri prompt — keeps recording; iOS itself
            // interrupts the camera in the background, which also finishes the file.)
            if phase == .background, model.recorder.state.isRecording { model.recorder.stopRecording(.backgrounded) }
        }
        .onChange(of: model.recorder.state.isRecording) { _, recording in IdleTimer.setDisabled(recording) }
        .onDisappear {
            model.recorder.shutDown()
            IdleTimer.setDisabled(false)
        }
        .sheet(isPresented: $editingDetails) {
            NavigationStack {
                Form { KickDetailsSection(details: $draftDetails, showsDistance: true) }
                    .navigationTitle("Next kicks")
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Apply") { model.changeDetails(draftDetails, app: app); editingDetails = false }
                        }
                    }
            }
        }
        .statusBarHidden()
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Circle().fill(model.recorder.state.isRecording ? Color.red : Color.gray).frame(width: 10, height: 10)
                Text(model.recorder.state.isRecording ? "REC \(CaptureFormat.elapsed(model.recorder.elapsed))" : statusText)
                    .font(.headline.monospacedDigit())
                Spacer()
                Text(model.recorder.selection?.title ?? model.recorder.request.title).font(.caption)
            }
            Text(model.manifest?.name ?? "Training session").font(.caption.weight(.semibold))
            Button {
                draftDetails = model.details
                editingDetails = true
            } label: {
                Label(model.details.summary, systemImage: "slider.horizontal.3").font(.caption)
            }
            .accessibilityHint("Change the kick type, distance or hash for the next kicks")
            HStack {
                Text(CaptureStoragePolicy.text(model.recorder.storage, request: model.recorder.request))
                Spacer()
                Text("Marked: \(model.marksThisRecording)")
            }
            .font(.caption2)
            Text("Detected kicks: found after you stop recording").font(.caption2).foregroundStyle(.white.opacity(0.8))
        }
        .foregroundStyle(.white)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.black.opacity(0.55)))
    }

    private var statusText: String {
        switch model.recorder.state {
        case .finishing: "Saving…"
        case .failed(let f): f.message
        case .interrupted: "Camera in use by another app"
        case .ready, .saved: model.savedRecordings > 0 ? "Recording saved" : "Ready"
        default: "Starting camera…"
        }
    }

    private var controls: some View {
        HStack(spacing: 16) {
            Button {
                model.markKick(app: app)
            } label: {
                Label("Mark Kick", systemImage: "flag.fill").frame(minWidth: 100)
            }
            .buttonStyle(.bordered)
            .tint(.white)
            .disabled(!model.recorder.state.isRecording)
            Button {
                if model.recorder.state.isRecording { model.stop() } else { model.start(app: app) }
            } label: {
                Circle().fill(model.recorder.state.isRecording ? Color.red : Color.white).frame(width: 70, height: 70)
                    .overlay(Circle().stroke(Color.white, lineWidth: 4).frame(width: 82, height: 82))
            }
            .accessibilityLabel(model.recorder.state.isRecording ? "Stop recording" : "Start recording")
            .disabled(!(model.recorder.state.canStartRecording || model.recorder.state.isRecording))
            Button {
                if model.recorder.state.isRecording { model.stop() }
                dismiss()
                onFinish()
            } label: {
                Label("Finish", systemImage: "checkmark.circle").frame(minWidth: 100)
            }
            .buttonStyle(.borderedProminent)
            .disabled(model.recorder.isBusy)
        }
    }

    private func banner(_ text: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.black).padding(8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.yellow))
    }
}

/// Build 21 — the live Training Session screen's model: one continuous recording per
/// Start/Stop, saved into the session folder; kick settings can change between kicks;
/// "Mark Kick" only leaves a hint for discovery. Kick finding runs after recording.
@MainActor
@Observable
final class TrainingSessionRecordModel {
    let sessionID: UUID
    let recorder = CameraRecorder()
    private(set) var manifest: TrainingSessionManifest?
    private(set) var currentSourceID: UUID?
    private(set) var marksThisRecording = 0
    private(set) var savedRecordings = 0
    var problem: String?

    init(sessionID: UUID) { self.sessionID = sessionID }

    func load(app: AppModel) async {
        manifest = try? app.services.trainingSessions.load(sessionID)
        recorder.request = CaptureSettingsStore.load()
        // Strong reference on purpose: the recording must be finalized in the manifest even
        // if the screen has just closed. The recorder drops this closure when it shuts down.
        recorder.onFinished = { url, reason, duration, usable in
            self.finished(url: url, reason: reason, duration: duration, usable: usable, app: app)
        }
        await recorder.prepare()
    }

    var details: SessionKickDetails { manifest?.defaults ?? SessionKickDetails() }

    func start(app: AppModel) {
        let store = app.services.trainingSessions
        guard var m = try? store.load(sessionID), recorder.state.canStartRecording else { return }
        // Hotfix 2: the view chosen at setup (default "not set" → detected from the movement,
        // as for an imported video), not an assumed side view.
        let role: SessionCameraRole = m.sources.isEmpty ? (m.plannedCameraRole ?? .unspecified) : (m.referenceSource?.role ?? .unspecified)
        let source = TrainingSessionEditor.addSource(&m, id: UUID(), role: role, origin: .inAppRecording, fileExtension: "mov",
                                                     status: .recording, now: .now, capture: recorder.selection)
        do {
            try store.prepare(sessionID)
            // The manifest knows about the recording BEFORE it starts (crash recovery).
            try store.save(m)
        } catch {
            problem = "The session couldn't be saved, so recording didn't start."
            return
        }
        manifest = m
        currentSourceID = source.id
        marksThisRecording = 0
        recorder.startRecording(to: store.url(session: sessionID, relativePath: source.relativePath))
    }

    func stop() { recorder.stopRecording() }

    func markKick(app: AppModel) {
        guard let src = currentSourceID, recorder.state.isRecording else { return }
        let time = recorder.recordedSeconds()
        manifest = app.sessionProcessor(for: sessionID).update(app) { TrainingSessionEditor.addMark(&$0, sourceID: src, at: time, now: .now) }
        marksThisRecording += 1
    }

    /// New settings apply from this moment of the recording on; earlier kicks keep theirs.
    func changeDetails(_ details: SessionKickDetails, app: AppModel) {
        let t = recorder.state.isRecording ? recorder.recordedSeconds() : nil
        let src = recorder.state.isRecording ? currentSourceID : nil
        manifest = app.sessionProcessor(for: sessionID).update(app) {
            TrainingSessionEditor.changeDefaults(&$0, to: details, sourceID: src, atSourceTime: t, now: .now)
        }
    }

    private func finished(url: URL, reason: CaptureStopReason, duration: Double?, usable: Bool, app: AppModel) {
        guard let src = currentSourceID else { return }
        let bytes = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value
        if !usable { problem = "That recording couldn't be finished. Anything readable is kept for review; you can record again." }
        manifest = app.sessionProcessor(for: sessionID).update(app) { m in
            TrainingSessionEditor.finalizeSource(&m, id: src, duration: duration, frameRate: recorder.selection.map { Double($0.framesPerSecond) },
                                                 bytes: bytes, status: usable ? .finalized : ((bytes ?? 0) > 0 ? .recovered : .missing), now: .now)
            if let message = reason.message { m.log.append(SessionLogEntry(at: .now, text: message)) }
        }
        if usable { savedRecordings += 1 }
        currentSourceID = nil
        recorder.readyForNextRecording()
    }
}
