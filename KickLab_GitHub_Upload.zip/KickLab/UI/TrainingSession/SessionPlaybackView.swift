import AVKit
import SwiftUI

/// Build 21 hotfix — what Session Review opens: a whole recording ("Watch Full Recording")
/// or one candidate's interval of it ("Watch Clip"). Plays the ORIGINAL source file in the
/// session folder; nothing is copied or changed. For a candidate, the review actions work
/// on the frame on screen and only change the session manifest (non-destructive).
struct SessionPlaybackView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let request: SessionPlaybackRequest
    @State private var manifest: TrainingSessionManifest?
    @State private var plan: SessionPlaybackPlan?
    @State private var problem: String?
    @State private var player: ValidationPlayer?
    @State private var loadedPath: String?
    @State private var recordingDuration: Double?
    @State private var showsWholeRecording = false
    @State private var rate = 0.5
    @State private var confirmingReject: Bool?

    private var processor: TrainingSessionProcessor { app.sessionProcessor(for: request.sessionID) }

    var body: some View {
        List {
            if let plan {
                Section {
                    ZStack {
                        Color.black
                        if let player { ValidationVideoSurface(player: player.player) }
                    }
                    .frame(height: 300)
                    controls(plan)
                }
                if plan.candidateID != nil, let c = candidate {
                    reviewSection(c, plan: plan)
                }
            } else {
                Section { Text(problem ?? "Loading…").foregroundStyle(.secondary) }
            }
            if let problem, plan != nil {
                Section { Text(problem).font(.caption).foregroundStyle(.red) }
            }
        }
        .navigationTitle(request.candidateID == nil ? "Full Recording" : "Kick Clip")
        .navigationBarTitleDisplayMode(.inline)
        .task { load() }
        .onDisappear { player?.stop() }
        .onChange(of: player?.currentTime ?? 0) { _, t in
            // Clip playback stops at the end of the clip.
            guard let player, player.isPlaying, let w = window else { return }
            if t >= w.upperBound { player.seek(to: w.upperBound) }
        }
        .confirmationDialog(confirmingReject == true ? "Mark as a practice swing?" : "Mark as not a kick?", isPresented: Binding(
            get: { confirmingReject != nil }, set: { if !$0 { confirmingReject = nil } }), titleVisibility: .visible) {
            Button(confirmingReject == true ? "Practice Swing" : "Not a Kick", role: .destructive) {
                if let practice = confirmingReject {
                    problem = SessionReviewActions.reject(candidateID: request.candidateID ?? UUID(), practiceSwing: practice, processor: processor, app: app)
                    load()
                }
                confirmingReject = nil
            }
        } message: {
            Text("The recording is kept. An analysis already made for this kick is removed.")
        }
    }

    private var candidate: SessionKickCandidate? { request.candidateID.flatMap { manifest?.candidate($0) } }

    /// The scrubber range: the clip, or the whole recording when asked.
    private var window: ClosedRange<Double>? {
        guard let plan else { return nil }
        if plan.candidateID == nil || showsWholeRecording {
            let end = max(recordingDuration ?? plan.window.upperBound, plan.window.upperBound)
            return 0...max(end, 0.1)
        }
        return plan.window.lowerBound...max(plan.window.upperBound, plan.window.lowerBound + 0.1)
    }

    // MARK: Player controls

    @ViewBuilder
    private func controls(_ plan: SessionPlaybackPlan) -> some View {
        let t = player?.currentTime ?? plan.initialTime
        VStack(alignment: .leading, spacing: 10) {
            Text(plan.title).font(.subheadline.weight(.semibold))
            if let w = window {
                Slider(value: Binding(get: { min(max(t, w.lowerBound), w.upperBound) }, set: { player?.seek(to: $0) }), in: w)
                    .accessibilityLabel("Position in the recording")
                markerBar(plan, window: w, time: t)
            }
            HStack {
                Text(timeText(t, plan: plan)).font(.caption.monospacedDigit())
                Spacer()
                if let c = plan.contact {
                    Button("Contact") { player?.seek(to: c) }.font(.caption)
                }
            }
            HStack(spacing: 12) {
                Button { player?.stepSourceFrame(-1) } label: { Image(systemName: "backward.frame") }
                    .accessibilityLabel("Back one frame")
                Button {
                    guard let player else { return }
                    if player.isPlaying {
                        player.pause()
                    } else {
                        if let w = window, player.currentTime >= w.upperBound - 0.01 { player.seek(to: w.lowerBound) }
                        player.play(rate: rate)
                    }
                } label: {
                    Image(systemName: player?.isPlaying == true ? "pause.fill" : "play.fill").frame(minWidth: 30)
                }
                .accessibilityLabel(player?.isPlaying == true ? "Pause" : "Play")
                Button { player?.stepSourceFrame(1) } label: { Image(systemName: "forward.frame") }
                    .accessibilityLabel("Forward one frame")
                Spacer()
                Picker("Speed", selection: $rate) {
                    Text("0.25×").tag(0.25)
                    Text("0.5×").tag(0.5)
                    Text("1×").tag(1.0)
                }
                .pickerStyle(.menu)
            }
            .buttonStyle(.bordered)
            if plan.candidateID != nil {
                Toggle("Show the whole recording", isOn: $showsWholeRecording).font(.caption)
            }
        }
        .padding(.vertical, 4)
    }

    /// Clip start, contact and clip end on the scrubber's range, with the current position.
    private func markerBar(_ plan: SessionPlaybackPlan, window w: ClosedRange<Double>, time: Double) -> some View {
        GeometryReader { g in
            let span = max(w.upperBound - w.lowerBound, 0.001)
            let x: (Double) -> CGFloat = { CGFloat((min(max($0, w.lowerBound), w.upperBound) - w.lowerBound) / span) * g.size.width }
            ZStack(alignment: .leading) {
                Capsule().fill(Color.secondary.opacity(0.2)).frame(height: 4)
                if let s = plan.clipStart, let e = plan.clipEnd, showsWholeRecording || plan.candidateID == nil {
                    Rectangle().fill(Color.accentColor.opacity(0.35)).frame(width: max(2, x(e) - x(s)), height: 6).offset(x: x(s))
                }
                if let c = plan.contact {
                    Rectangle().fill(Color.yellow).frame(width: 3, height: 14).offset(x: x(c) - 1.5)
                }
                Circle().fill(Color.primary).frame(width: 8, height: 8).offset(x: x(time) - 4)
            }
            .frame(height: 14)
        }
        .frame(height: 14)
        .accessibilityHidden(true)
    }

    private func timeText(_ t: Double, plan: SessionPlaybackPlan) -> String {
        var s = "\(CaptureFormat.elapsed(t)) · \(String(format: "%.3f s", t))"
        if let c = plan.contact {
            let d = t - c
            s += abs(d) < 0.0005 ? " · contact" : String(format: " · %+.2f s from contact", d)
        }
        return s
    }

    // MARK: Review (candidates)

    @ViewBuilder
    private func reviewSection(_ c: SessionKickCandidate, plan: SessionPlaybackPlan) -> some View {
        Section {
            LabeledContent("Status", value: c.status.title)
            if let contact = c.contactTime {
                LabeledContent("Contact", value: String(format: "%.3f s (%@)", contact, contactSource(c)))
            }
            LabeledContent("Clip", value: String(format: "%.2f–%.2f s", c.startTime, c.endTime))
            Button { edit { try TrainingSessionEditor.confirmContact(&$0, candidateID: c.id, at: now(), now: .now) } } label: {
                Label("Set Contact to This Frame", systemImage: "scope")
            }
            Button { edit { m in try TrainingSessionEditor.adjustBoundaries(&m, candidateID: c.id, start: now(), end: c.endTime, now: .now) } } label: {
                Label("Set Clip Start Here", systemImage: "arrow.left.to.line")
            }
            Button { edit { m in try TrainingSessionEditor.adjustBoundaries(&m, candidateID: c.id, start: c.startTime, end: now(), now: .now) } } label: {
                Label("Set Clip End Here", systemImage: "arrow.right.to.line")
            }
        } header: {
            Text("Review")
        } footer: {
            Text("Step to a frame, then use these. Only the session's notes change — the recording itself is never edited.")
        }
        Section {
            if c.status == .needsReview || (c.status == .pending && c.kickID == nil) {
                Button {
                    edit { try TrainingSessionEditor.accept(&$0, candidateID: c.id, now: .now) }
                    processor.start(app: app)
                } label: { Label("Confirm Kick", systemImage: "checkmark.circle") }
            }
            if c.status.isActive {
                Button(role: .destructive) { confirmingReject = false } label: { Label("Not a Kick", systemImage: "xmark") }
                Button { confirmingReject = true } label: { Label("Practice Swing", systemImage: "figure.walk") }
            }
            if let analysisID = c.analysis.analysisID {
                NavigationLink(value: AppRoute.analysis(analysisID)) { Label("Open Kick Report", systemImage: "doc.text") }
            }
        }
    }

    private func contactSource(_ c: SessionKickCandidate) -> String {
        switch c.contactProvenance {
        case .scan: "estimated by the scan"
        case .analysis: "from the analysis"
        case .user: "set by you"
        case nil: "not set"
        }
    }

    private func now() -> Double { player?.currentTime ?? plan?.initialTime ?? 0 }

    private func edit(_ change: (inout TrainingSessionManifest) throws -> Void) {
        do {
            try processor.update(app, change)
            problem = nil
        } catch let e as TrainingSessionEditor.EditError {
            problem = e.userMessage
        } catch {
            problem = "Couldn't update the session."
        }
        load()
    }

    // MARK: Loading

    private func load() {
        let store = app.services.trainingSessions
        guard let m = try? store.load(request.sessionID) else { problem = "This session couldn't be read."; plan = nil; return }
        manifest = m
        let result = SessionPlaybackPlan.make(m, sourceID: request.sourceID, candidateID: request.candidateID) { path in
            FileManager.default.fileExists(atPath: store.url(session: request.sessionID, relativePath: path).path)
        }
        switch result {
        case .failure(let p):
            plan = nil
            problem = SessionPlaybackPlan.text(p)
        case .success(let p):
            let isFirstLoad = plan == nil
            plan = p
            if loadedPath != p.relativePath {
                player?.stop()
                let url = store.url(session: request.sessionID, relativePath: p.relativePath)
                let newPlayer = ValidationPlayer(url: url)
                player = newPlayer
                loadedPath = p.relativePath
                newPlayer.seek(to: p.initialTime)
                Task {
                    let d = try? await AVURLAsset(url: url).load(.duration).seconds
                    if let d, d.isFinite, d > 0 { recordingDuration = d }
                }
            } else if isFirstLoad {
                player?.seek(to: p.initialTime)
            }
        }
    }
}

extension TrainingSessionEditor.EditError {
    var userMessage: String {
        switch self {
        case .boundariesInvalid(let s), .cannotSplit(let s), .cannotMerge(let s): s
        case .contactOutsideClip: "The contact must be inside the clip, at least 1.5 s after its start and 1 s before its end."
        case .sourceInUse(let n): "\(n) kick\(n == 1 ? "" : "s") still need this recording. Analyze or remove them first."
        case .unknownSource, .unknownCandidate: "That kick no longer exists."
        case .alreadyAnalyzing: "Wait for the current analysis to finish."
        }
    }
}
