import AVKit
import SwiftUI

/// Session Review's video screen (Build 21 hotfixes 1–2).
///
/// - **Full recording** ("Watch Full Recording"): the original file; "Add Kick Here" adds a
///   missed kick at the frame on screen.
/// - **A kick** ("Watch Clip" / "Edit Contact" / "Find Contact Manually"): when the kick's
///   clip exists, the clip itself is played — the exact video and timeline the analysis reads
///   — so "Set Contact Here" needs no time conversion; "Save & Reanalyze" runs a real
///   user-assisted analysis of the SAME Kick (its automatic analysis is kept). A kick not yet
///   cut into a clip is reviewed in the original recording at its interval.
///
/// Every edit changes only the session manifest; no video file is modified.
struct SessionPlaybackView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let request: SessionPlaybackRequest
    @State private var manifest: TrainingSessionManifest?
    @State private var plan: SessionPlaybackPlan?
    @State private var problem: String?
    @State private var notice: String?
    @State private var player: ValidationPlayer?
    @State private var loadedURL: URL?
    @State private var videoDuration: Double?
    @State private var showsWholeRecording = false
    @State private var rate = 0.5
    @State private var confirmingReject: Bool?

    private var processor: TrainingSessionProcessor { app.sessionProcessor(for: request.sessionID) }

    var body: some View {
        List {
            if let plan {
                Section {
                    ZStack {
                        Color.black
                        if let player { ValidationVideoSurface(player: player.player) }
                    }
                    .frame(height: 300)
                    controls(plan)
                }
                if let notice { Section { Text(notice).font(.callout) } }
                if let problem { Section { Text(problem).font(.callout).foregroundStyle(.red) } }
                if plan.candidateID != nil, let c = candidate {
                    contactSection(c, plan: plan)
                    decisionSection(c)
                } else if plan.candidateID == nil {
                    addKickSection(plan)
                }
            } else {
                Section { Text(problem ?? "Loading…").foregroundStyle(.secondary) }
            }
        }
        .navigationTitle(request.candidateID == nil ? "Full Recording" : "Kick")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: processor.revision) { load() }
        .onDisappear {
            // Released, so coming back (e.g. from the report) builds a fresh, live player.
            player?.stop()
            player = nil
            loadedURL = nil
        }
        .onChange(of: player?.currentTime ?? 0) { _, t in
            // Clip playback stops at the end of the clip.
            guard let player, player.isPlaying, let w = window else { return }
            if t >= w.upperBound { player.seek(to: w.upperBound) }
        }
        .confirmationDialog(confirmingReject == true ? "Mark as a practice swing?" : "Mark as not a kick?", isPresented: Binding(
            get: { confirmingReject != nil }, set: { if !$0 { confirmingReject = nil } }), titleVisibility: .visible) {
            Button(confirmingReject == true ? "Practice Swing" : "Not a Kick", role: .destructive) {
                if let practice = confirmingReject, let id = request.candidateID {
                    problem = SessionReviewActions.reject(candidateID: id, practiceSwing: practice, processor: processor, app: app)
                    load()
                }
                confirmingReject = nil
            }
        } message: {
            Text("The recording is kept. An analysis already made for this kick is removed.")
        }
    }

    private var candidate: SessionKickCandidate? { request.candidateID.flatMap { manifest?.candidate($0) } }

    /// The scrubber range: the clip, or the whole recording when asked.
    private var window: ClosedRange<Double>? {
        guard let plan else { return nil }
        if plan.timeline == .sourceRecording, plan.candidateID == nil || showsWholeRecording {
            let end = max(videoDuration ?? plan.window.upperBound, plan.window.upperBound)
            return 0...max(end, 0.1)
        }
        let upper = plan.timeline == .kickClip ? max(videoDuration ?? plan.window.upperBound, 0.1) : plan.window.upperBound
        return plan.window.lowerBound...max(upper, plan.window.lowerBound + 0.1)
    }

    private var currentTime: Double { player?.currentTime ?? plan?.initialTime ?? 0 }
    private var frameDuration: Double { 1 / max(plan?.frameRate ?? 30, 1) }

    // MARK: Player controls

    @ViewBuilder
    private func controls(_ plan: SessionPlaybackPlan) -> some View {
        let t = currentTime
        VStack(alignment: .leading, spacing: 10) {
            Text(plan.title).font(.subheadline.weight(.semibold))
            if let w = window {
                Slider(value: Binding(get: { min(max(t, w.lowerBound), w.upperBound) }, set: { player?.seek(to: $0) }), in: w)
                    .accessibilityLabel("Position in the video")
                markerBar(plan, window: w, time: t)
            }
            Text(timeText(t, plan: plan)).font(.caption.monospacedDigit())
            HStack(spacing: 12) {
                Button { player?.stepSourceFrame(-1) } label: { Image(systemName: "backward.frame") }
                    .accessibilityLabel("Back one frame")
                Button {
                    guard let player else { return }
                    if player.isPlaying {
                        player.pause()
                    } else {
                        if let w = window, player.currentTime >= w.upperBound - 0.01 { player.seek(to: w.lowerBound) }
                        player.play(rate: rate)
                    }
                } label: {
                    Image(systemName: player?.isPlaying == true ? "pause.fill" : "play.fill").frame(minWidth: 30)
                }
                .accessibilityLabel(player?.isPlaying == true ? "Pause" : "Play")
                Button { player?.stepSourceFrame(1) } label: { Image(systemName: "forward.frame") }
                    .accessibilityLabel("Forward one frame")
                Spacer()
                Picker("Speed", selection: $rate) {
                    Text("0.25×").tag(0.25)
                    Text("0.5×").tag(0.5)
                    Text("1×").tag(1.0)
                }
                .pickerStyle(.menu)
            }
            .buttonStyle(.bordered)
            HStack {
                if let a = plan.automaticContact {
                    Button("Automatic Contact") { player?.seek(to: a) }.font(.caption)
                }
                if let u = plan.userContact {
                    Button("Your Contact") { player?.seek(to: u) }.font(.caption)
                }
            }
            .buttonStyle(.bordered)
            if plan.candidateID != nil, plan.timeline == .sourceRecording {
                Toggle("Show the whole recording", isOn: $showsWholeRecording).font(.caption)
            }
        }
        .padding(.vertical, 4)
    }

    /// Clip range, automatic contact (yellow), your contact (green) and the current position.
    private func markerBar(_ plan: SessionPlaybackPlan, window w: ClosedRange<Double>, time: Double) -> some View {
        GeometryReader { g in
            let span = max(w.upperBound - w.lowerBound, 0.001)
            let x: (Double) -> CGFloat = { CGFloat((min(max($0, w.lowerBound), w.upperBound) - w.lowerBound) / span) * g.size.width }
            ZStack(alignment: .leading) {
                Capsule().fill(Color.secondary.opacity(0.2)).frame(height: 4)
                if plan.timeline == .sourceRecording, let s = plan.clipStart, let e = plan.clipEnd, showsWholeRecording {
                    Rectangle().fill(Color.accentColor.opacity(0.35)).frame(width: max(2, x(e) - x(s)), height: 6).offset(x: x(s))
                }
                if let a = plan.automaticContact {
                    Rectangle().fill(Color.yellow).frame(width: 3, height: 14).offset(x: x(a) - 1.5)
                }
                if let u = plan.userContact {
                    Rectangle().fill(Color.green).frame(width: 3, height: 14).offset(x: x(u) - 1.5)
                }
                Circle().fill(Color.primary).frame(width: 8, height: 8).offset(x: x(time) - 4)
            }
            .frame(height: 14)
        }
        .frame(height: 14)
        .accessibilityHidden(true)
    }

    private func timeText(_ t: Double, plan: SessionPlaybackPlan) -> String {
        let frame = Int((t * plan.frameRate).rounded())
        var s = String(format: "%.3f s · frame %d", t, frame)
        if plan.timeline == .kickClip, let start = candidate?.clipStartInSource {
            s += " · recording \(CaptureFormat.elapsed(start + t))"
        }
        if let c = plan.userContact ?? plan.automaticContact {
            let d = t - c
            s += abs(d) < frameDuration / 2 ? " · contact" : String(format: " · %+.2f s from contact", d)
        }
        return s
    }

    // MARK: Contact

    @ViewBuilder
    private func contactSection(_ c: SessionKickCandidate, plan: SessionPlaybackPlan) -> some View {
        Section {
            Text(SessionKickStatusText.line(c)).font(.subheadline.weight(.semibold))
            LabeledContent("Automatic contact", value: automaticText(c, plan: plan))
            LabeledContent("Your contact", value: plan.userContact.map { String(format: "%.3f s (±%.3f s)", $0, c.userContact?.uncertainty ?? frameDuration) } ?? "not set")
            if let r = c.userContact?.lastResult { Text(r).font(.caption).foregroundStyle(.secondary) }
            if let w = c.clipTiming?.warning { Text(w).font(.caption).foregroundStyle(.orange) }
            Button { setContactHere(c, plan: plan) } label: {
                Label("Set Contact Here", systemImage: "scope")
            }
            .buttonStyle(.borderedProminent)
            if c.kickID != nil {
                Button { saveAndReanalyze(c) } label: {
                    Label(c.analysis.status == .queued || c.analysis.status == .running ? "Reanalysis in progress…" : "Save & Reanalyze",
                          systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(c.analysis.status == .queued || c.analysis.status == .running)
            }
        } header: {
            Text("Contact")
        } footer: {
            Text("Step frame by frame to the first frame where the foot touches the ball, then Set Contact Here. Save & Reanalyze runs a new analysis of this kick using that frame; the automatic analysis is kept. Your frame is a timing choice — it doesn't prove the ball moved.")
        }
    }

    private func automaticText(_ c: SessionKickCandidate, plan: SessionPlaybackPlan) -> String {
        if let a = plan.automaticContact {
            let outcome = c.automaticContact?.outcome.flatMap(ContactOutcome.init(rawValue:))
            return String(format: "%.3f s", a) + (outcome.map { " · \(SessionKickStatusText.outcomeName($0))" } ?? "")
        }
        if c.automaticContact != nil || c.analysis.status == .done { return "not found" }
        return "not analyzed yet"
    }

    private func setContactHere(_ c: SessionKickCandidate, plan: SessionPlaybackPlan) {
        let t = currentTime
        edit {
            if plan.timeline == .kickClip {
                try TrainingSessionEditor.setUserContactInClip(&$0, candidateID: c.id, clipTime: t, frameDuration: frameDuration, now: .now)
            } else {
                try TrainingSessionEditor.setUserContact(&$0, candidateID: c.id, sourceTime: t, frameDuration: frameDuration, now: .now)
            }
        }
        if problem == nil {
            notice = c.kickID != nil
                ? String(format: "Contact set at %.3f s. Tap Save & Reanalyze to analyze this kick with it.", t)
                : String(format: "Contact set at %.3f s. Confirm the kick to analyze it with this frame.", t)
        }
    }

    private func saveAndReanalyze(_ c: SessionKickCandidate) {
        edit { try TrainingSessionEditor.requestReanalysis(&$0, candidateID: c.id, now: .now) }
        if problem == nil {
            processor.start(app: app)
            notice = c.contactProvenance == .user
                ? "Reanalyzing this kick with your contact frame. Keep KickLab open; the result appears here."
                : "Reanalyzing this kick automatically (no contact frame chosen)."
        }
    }

    // MARK: Decisions

    @ViewBuilder
    private func decisionSection(_ c: SessionKickCandidate) -> some View {
        Section {
            if c.status == .needsReview || (c.status == .pending && c.kickID == nil) {
                Button {
                    edit { try TrainingSessionEditor.accept(&$0, candidateID: c.id, now: .now) }
                    processor.start(app: app)
                    notice = "Kick confirmed — it will be analyzed\(c.contactProvenance == .user ? " with your contact frame" : "")."
                } label: { Label("Confirm Kick", systemImage: "checkmark.circle") }
            }
            if c.status.isActive {
                Button(role: .destructive) { confirmingReject = false } label: { Label("Not a Kick", systemImage: "xmark") }
                Button { confirmingReject = true } label: { Label("Practice Swing", systemImage: "figure.walk") }
            }
            if let analysisID = c.analysis.analysisID, c.analysis.status == .done {
                NavigationLink(value: AppRoute.analysis(analysisID)) { Label("Open Kick Report", systemImage: "doc.text") }
            }
        } header: {
            Text("Kick")
        }
    }

    // MARK: Add a missed kick (full recording)

    @ViewBuilder
    private func addKickSection(_ plan: SessionPlaybackPlan) -> some View {
        Section {
            Button {
                let t = currentTime
                var added: SessionKickCandidate?
                edit { added = try TrainingSessionEditor.addKickHere(&$0, sourceID: plan.sourceID, contact: t, frameDuration: frameDuration, now: .now) }
                if added != nil {
                    processor.start(app: app)
                    notice = String(format: "Kick added at %@ with this frame as contact. It will be analyzed; review it in the kick list.", CaptureFormat.elapsed(t))
                }
            } label: { Label("Add Kick Here", systemImage: "plus.circle") }
            .buttonStyle(.borderedProminent)
        } header: {
            Text("Missed kick?")
        } footer: {
            Text("Step to the frame where the foot touches the ball, then Add Kick Here. A kick already listed at this moment isn't added twice.")
        }
    }

    // MARK: Editing and loading

    private func edit(_ change: (inout TrainingSessionManifest) throws -> Void) {
        do {
            try processor.update(app, change)
            problem = nil
        } catch let e as TrainingSessionEditor.EditError {
            problem = e.userMessage
            notice = nil
        } catch {
            problem = "Couldn't update the session."
            notice = nil
        }
        load()
    }

    /// The kick's own clip file (its primary video), when it exists on this iPhone.
    private func kickClipURL(_ c: SessionKickCandidate?) -> URL? {
        guard let id = c?.kickID, let kick = ModelLookup.kick(id, in: app.context),
              let video = (kick.videos ?? []).first(where: \.isPrimary), app.services.videos.fileExists(for: video) else { return nil }
        return app.services.videos.fileURL(for: video)
    }

    private func load() {
        let store = app.services.trainingSessions
        guard let m = try? store.load(request.sessionID) else { problem = "This session couldn't be read."; plan = nil; return }
        manifest = m
        let c = request.candidateID.flatMap { m.candidate($0) }
        let clipURL = kickClipURL(c)
        let result = SessionPlaybackPlan.make(m, sourceID: request.sourceID, candidateID: request.candidateID,
                                              kickClipAvailable: clipURL != nil) { path in
            FileManager.default.fileExists(atPath: store.url(session: request.sessionID, relativePath: path).path)
        }
        switch result {
        case .failure(let p):
            plan = nil
            problem = SessionPlaybackPlan.text(p)
        case .success(let p):
            let isFirstLoad = plan == nil
            plan = p
            let url = p.timeline == .kickClip ? clipURL : store.url(session: request.sessionID, relativePath: p.relativePath)
            guard let url else { return }
            if loadedURL != url {
                player?.stop()
                let newPlayer = ValidationPlayer(url: url)
                player = newPlayer
                loadedURL = url
                videoDuration = nil
                newPlayer.seek(to: p.userContact ?? p.automaticContact ?? p.initialTime)
                Task {
                    let d = try? await AVURLAsset(url: url).load(.duration).seconds
                    if let d, d.isFinite, d > 0, loadedURL == url { videoDuration = d }
                }
            } else if isFirstLoad {
                player?.seek(to: p.initialTime)
            }
        }
    }
}

extension TrainingSessionEditor.EditError {
    var userMessage: String {
        switch self {
        case .boundariesInvalid(let s), .cannotSplit(let s), .cannotMerge(let s): s
        case .contactOutsideClip: "The contact must be inside the kick's interval."
        case .sourceInUse(let n): "\(n) kick\(n == 1 ? "" : "s") still need this recording. Analyze or remove them first."
        case .unknownSource, .unknownCandidate: "That kick no longer exists."
        case .alreadyAnalyzing: "Wait for the current analysis to finish."
        case .duplicateKick: "A kick is already listed at this moment. Open it with Watch Clip instead."
        case .outsideKickClip: "That frame is outside this kick's clip. Pick a frame inside the clip, or add a new kick at that moment."
        }
    }
}

/// Hotfix 2: "Export Diagnostics" — a ZIP of what the session's kick finding and analysis
/// decided, shared with the iOS share sheet. Video only when chosen (sound and identifying
/// metadata removed unless sound is switched on). Nothing is sent anywhere by KickLab.
struct SessionDiagnosticsExportView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    let sessionID: UUID
    @State private var exporter: SessionDiagnosticsExporter
    @State private var video: SessionDiagnosticVideoChoice = .none
    @State private var selectedKick: UUID?
    @State private var includeSound = false
    @State private var kicks: [(id: UUID, title: String)] = []

    init(sessionID: UUID) {
        self.sessionID = sessionID
        _exporter = State(initialValue: SessionDiagnosticsExporter(sessionID: sessionID))
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Includes the kick-finding scan (ball and body positions per sampled frame), every possible kick and why it was kept or dropped, contact times, clip timing, analysis results and each analysis' evidence bundle. No names, places or IDs.")
                        .font(.caption)
                }
                Section {
                    Picker("Video", selection: $video) {
                        ForEach(SessionDiagnosticVideoChoice.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    if video == .selectedKick {
                        Picker("Kick", selection: $selectedKick) {
                            ForEach(kicks, id: \.id) { Text($0.title).tag(Optional($0.id)) }
                        }
                    }
                    if video != .none {
                        Toggle("Include sound", isOn: $includeSound)
                    }
                } header: {
                    Text("Video (optional)")
                } footer: {
                    Text("Video shows the athlete. Copies are made for sharing; the recordings in KickLab are not changed. Location and device details are removed from the copies.")
                }
                Section {
                    Button(exporter.isWorking ? "Preparing…" : "Prepare Export") {
                        Task { await exporter.export(app: app, video: video, selectedCandidateID: selectedKick, includeSound: includeSound) }
                    }
                    .disabled(exporter.isWorking || (video == .selectedKick && selectedKick == nil))
                    if let summary = exporter.summary, !exporter.shareURLs.isEmpty {
                        Text(summary).font(.caption)
                        ShareLink(items: exporter.shareURLs) { Label("Share Diagnostics", systemImage: "square.and.arrow.up") }
                    }
                    if let p = exporter.problem { Text(p).font(.caption).foregroundStyle(.red) }
                }
            }
            .navigationTitle("Export Diagnostics")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .task {
                guard let m = try? app.services.trainingSessions.load(sessionID) else { return }
                kicks = m.candidates.filter { $0.kickID != nil }.enumerated().map { n, c in
                    (c.id, "Kick \(n + 1) · \(CaptureFormat.elapsed(c.contactTime ?? c.startTime))")
                }
                selectedKick = kicks.first?.id
            }
        }
    }
}
