import AVKit
import SwiftUI

/// Build 20 — Compare Kicks: choose two analyzed kicks (Kick A, Kick B).
struct CompareKicksView: View {
    @Environment(AppModel.self) private var app
    @State private var model: CompareKicksViewModel

    init(preselected: UUID? = nil) {
        _model = State(initialValue: CompareKicksViewModel(preselected: preselected))
    }

    var body: some View {
        List {
            if let message = model.message {
                Section { Label(message, systemImage: "info.circle").foregroundStyle(.secondary) }
            }
            Section("Kick A") {
                Menu {
                    ForEach(KickComparison.filter(model.kicks, by: .all)) { k in
                        Button(k.title) {
                            model.selectedA = k.analysisID
                            if model.selectedB == k.analysisID { model.selectedB = nil }
                        }
                    }
                } label: {
                    if let a = model.kick(model.selectedA) { row(a, selected: true) } else { Text("Choose a kick") }
                }
            }
            Section {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(model.availableFilters, id: \.self) { f in
                            Button(f.title) { model.filter = f }
                                .buttonStyle(.bordered)
                                .tint(model.filter == f ? .accentColor : .secondary)
                                .accessibilityAddTraits(model.filter == f ? .isSelected : [])
                        }
                    }
                }
                Picker("Sort", selection: $model.sort) {
                    ForEach(ComparisonSort.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                if model.candidates.isEmpty {
                    Text("No analyzed kicks match this filter.").foregroundStyle(.secondary)
                }
                ForEach(model.candidates) { k in
                    Button { model.selectedB = k.analysisID } label: { row(k, selected: model.selectedB == k.analysisID) }
                        .buttonStyle(.plain)
                        .swipeActions { referenceButton(k) }
                        .contextMenu { referenceButton(k) }
                }
            } header: {
                Text("Kick B")
            } footer: {
                Text(PersonalReferencePolicy.explanation + " Swipe a kick to set or clear it.")
            }
            Section {
                if model.canCompare, let a = model.selectedA, let b = model.selectedB {
                    NavigationLink(value: AppRoute.comparison(a, b)) {
                        Label("Compare side by side", systemImage: "rectangle.split.2x1")
                    }
                    if let ka = model.kick(a), let kb = model.kick(b), let why = KickComparison.incompatibility(ka, kb) {
                        Text(why).font(.footnote).foregroundStyle(.secondary)
                    }
                } else {
                    Text("Choose two different kicks.").foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("Compare Kicks")
        .task(id: app.revision) { model.load(app: app) }
    }

    @ViewBuilder
    private func referenceButton(_ k: ComparisonKick) -> some View {
        Button {
            model.setReference(kickID: k.kickID, on: !k.isReference, app: app)
        } label: {
            Label(k.isReference ? "Clear Reference" : "Set as Reference", systemImage: k.isReference ? "star.slash" : "star")
        }
        .tint(.yellow)
    }

    private func row(_ k: ComparisonKick, selected: Bool) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(k.title).font(.subheadline.weight(.semibold))
                Text(k.badges.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if k.isReference { Image(systemName: "star.fill").foregroundStyle(.yellow).accessibilityLabel("Reference kick") }
            if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.accentColor).accessibilityLabel("Selected") }
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// Build 20 — two kicks side by side, synchronized at contact.
/// Build 21 (Compare 1.1): opens CLEAN — two plain videos, no overlays — every time. All
/// overlays live behind "Advanced Analysis" and start off. "Zoom to athlete" frames the
/// tracked athlete (aspect kept, overlays registered); pinch and drag zoom/pan by hand.
/// The tab bar is hidden here so no control or table row sits behind it.
struct KickComparisonView: View {
    @Environment(AppModel.self) private var app
    @State private var session: KickComparisonSession

    init(analysisA: UUID, analysisB: UUID) {
        _session = State(initialValue: KickComparisonSession(mode: .analyses(analysisA, analysisB)))
    }

    /// Build 21: one kick's two camera angles (side + rear clips of a session pair).
    init(pairedKick: UUID) {
        _session = State(initialValue: KickComparisonSession(mode: .pair(kick: pairedKick)))
    }

    var body: some View {
        content
            .navigationTitle(session.isPair ? "Both Cameras" : "Compare")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .tabBar)
            .task { await session.load(app: app) }
            .onDisappear { session.stop() }
    }

    @ViewBuilder
    private var content: some View {
        switch session.state {
        case .loading:
            LoadingStateView(text: "Loading both videos…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded:
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 6) {
                        if let a = session.sideA { pane(a, label: "A", time: session.timeA, player: session.playerA) }
                        if let b = session.sideB { pane(b, label: "B", time: session.timeB, player: session.playerB) }
                    }
                    .frame(height: 340)
                    Text(session.alignment.statusText)
                        .font(.caption)
                        .foregroundStyle(statusColor)
                    controls
                    alignmentControls
                    zoomControls
                    advanced
                    table
                }
                .padding(.horizontal)
                .padding(.bottom, 32)
            }
        }
    }

    private var statusColor: Color {
        switch session.alignment.status {
        case .aligned: .secondary
        case .uncertain, .notAligned: .orange
        }
    }

    private func pane(_ s: ComparisonSideContent, label: String, time: Double, player: AVPlayer?) -> some View {
        let aspect = s.timeline?.displayAspectRatio ?? s.displayAspectRatio ?? (9.0 / 16)
        let frame = s.side.frameInterval
        let storedValue = s.kick.metrics[.plantBallLateralOffset]?.value
        let zoom = session.zoom[label] ?? .identity
        let o = session.overlays
        return VStack(alignment: .leading, spacing: 4) {
            GeometryReader { g in
                let rect = PoseOverlayGeometry.aspectFitRect(containerWidth: Double(g.size.width), containerHeight: Double(g.size.height), contentAspect: aspect)
                ZStack(alignment: .topLeading) {
                    // Video and overlays share ONE transform, so overlays stay registered when zoomed.
                    ZStack {
                        Color.black
                        if let player {
                            ValidationVideoSurface(player: player)
                        } else {
                            Text("Video not on this device").font(.caption).foregroundStyle(.white).padding(8)
                        }
                        ZStack {
                            if o.skeleton, let t = s.timeline {
                                SkeletonOverlay(timeline: t, time: time, source: .stored, rect: rect, showsConfidence: false)
                            }
                            if o.football, let ball = s.timeline?.football {
                                FootballOverlayView(model: ball, time: time, frame: frame, rect: rect)
                            }
                            if o.plantFoot, let p = ComparisonOverlay.plantFoot(s.storedTimeline, at: time, frame: frame, kickingFoot: s.kickingFoot) {
                                let pt = PoseOverlayGeometry.point(x: p.x, y: p.y, in: rect)
                                Circle()
                                    .stroke(Color.cyan, lineWidth: 2)
                                    .background(Circle().fill(p.measured ? Color.cyan.opacity(0.6) : Color.clear))
                                    .frame(width: 18, height: 18)
                                    .position(x: CGFloat(pt.x), y: CGFloat(pt.y))
                            }
                            if o.measurementLines,
                               let i = ComparisonOverlay.measurementLine(view: s.kick.view, timeline: s.storedTimeline, football: s.football,
                                                                         contact: s.side.contactTime, time: time, frame: frame,
                                                                         kickingFoot: s.kickingFoot, storedValue: storedValue) {
                                let r = PoseOverlayGeometry.point(x: i.reference.x, y: i.ankle.y, in: rect)
                                let a = PoseOverlayGeometry.point(x: i.ankle.x, y: i.ankle.y, in: rect)
                                Path { path in
                                    path.move(to: CGPoint(x: r.x, y: r.y))
                                    path.addLine(to: CGPoint(x: a.x, y: a.y))
                                }
                                .stroke(Color.yellow, lineWidth: 2)
                            }
                            if o.ballFlight, let flight = session.flight[label] {
                                ForEach(Array(flight.points.filter { $0.time <= time + 1e-6 }.enumerated()), id: \.offset) { _, p in
                                    let pt = PoseOverlayGeometry.point(x: p.cx, y: p.cy, in: rect)
                                    Circle()
                                        .stroke(Color.orange, lineWidth: 1.5)
                                        .background(Circle().fill(p.measured ? Color.orange : Color.clear))
                                        .frame(width: 7, height: 7)
                                        .position(x: CGFloat(pt.x), y: CGFloat(pt.y))
                                }
                            }
                        }
                        .allowsHitTesting(false)
                    }
                    .frame(width: g.size.width, height: g.size.height)
                    .scaleEffect(CGFloat(zoom.scale), anchor: .topLeading)
                    .offset(x: CGFloat(zoom.offsetX), y: CGFloat(zoom.offsetY))
                    HStack {
                        Text(label).font(.caption.bold()).foregroundStyle(.white).padding(4)
                            .background(RoundedRectangle(cornerRadius: 4).fill(Color.black.opacity(0.55)))
                        Spacer()
                        if o.contactBadge, ComparisonOverlay.isContactFrame(time: time, contact: s.side.contactTime, frame: frame) {
                            Text("Contact").font(.caption2.bold()).padding(4).background(RoundedRectangle(cornerRadius: 4).fill(Color.yellow))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding(4)
                }
                .clipped()
                .contentShape(Rectangle())
                .gesture(MagnificationGesture().onChanged { value in
                    session.pinch(label, by: Double(value), content: rect, size: g.size)
                }.onEnded { _ in session.endGesture(label) })
                .simultaneousGesture(DragGesture().onChanged { value in
                    session.pan(label, dx: Double(value.translation.width), dy: Double(value.translation.height), content: rect, size: g.size)
                }.onEnded { _ in session.endGesture(label) })
                .onChange(of: session.overlays.zoomToAthlete, initial: true) { _, on in
                    session.frameAthlete(label, on: on, content: rect, size: g.size)
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(session.isPair ? "Camera" : "Kick") \(label) video, \(s.kick.title)")
            Text(s.caption ?? s.kick.title).font(.caption2.weight(.semibold)).lineLimit(2)
            Text(s.side.provenance.title + (s.side.contactTime.map { String(format: " · %.3f s", $0) } ?? ""))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var controls: some View {
        VStack(spacing: 8) {
            if let range = session.alignment.range {
                Slider(value: Binding(get: { session.relativeTime }, set: { session.scrub(to: $0) }), in: range)
                    .accessibilityLabel("Time relative to contact")
                    .accessibilityValue(String(format: "%.2f seconds", session.relativeTime))
            }
            HStack {
                Text(String(format: "%+.3f s from contact", session.relativeTime)).font(.caption.monospacedDigit())
                Spacer()
                Picker("Speed", selection: $session.rate) {
                    ForEach(KickComparisonSession.rates, id: \.self) { Text(rateText($0)).tag($0) }
                }
                .pickerStyle(.menu)
            }
            HStack(spacing: 16) {
                Button { session.step(-1) } label: { Image(systemName: "backward.frame") }
                    .accessibilityLabel("Back one frame")
                Button { session.isPlaying ? session.pause() : session.play() } label: {
                    Image(systemName: session.isPlaying ? "pause.fill" : "play.fill").font(.title2)
                }
                .accessibilityLabel(session.isPlaying ? "Pause" : "Play")
                Button { session.step(1) } label: { Image(systemName: "forward.frame") }
                    .accessibilityLabel("Forward one frame")
                Spacer()
                Button("Contact") { session.jumpToContact() }
                    .disabled(!session.alignment.isContactAligned)
            }
            .buttonStyle(.bordered)
        }
    }

    private func rateText(_ r: Double) -> String { r == 1 ? "1×" : String(format: "%g×", r) }

    private var alignmentControls: some View {
        HStack {
            Text(session.isPair ? "Align camera B" : "Align Kick B").font(.caption)
            Spacer()
            Button { session.nudge(-1) } label: { Image(systemName: "minus") }
                .accessibilityLabel("Shift B one frame earlier")
            Button { session.nudge(1) } label: { Image(systemName: "plus") }
                .accessibilityLabel("Shift B one frame later")
            Button("Reset") { session.resetAlignment() }
                .disabled(session.alignment.manualOffset == 0)
        }
        .buttonStyle(.bordered)
    }

    private var zoomControls: some View {
        HStack {
            Toggle("Zoom to athlete", isOn: $session.overlays.zoomToAthlete)
                .disabled(session.sideA?.storedTimeline == nil && session.sideB?.storedTimeline == nil)
            Button("Reset Zoom") { session.resetZoom() }
                .buttonStyle(.bordered)
                .disabled(session.zoom.values.allSatisfy { $0 == .identity })
        }
        .font(.subheadline)
    }

    private var advanced: some View {
        DisclosureGroup("Advanced Analysis", isExpanded: $session.showsAdvanced) {
            VStack(alignment: .leading, spacing: 6) {
                Toggle("Skeleton", isOn: $session.overlays.skeleton)
                Toggle("Plant foot", isOn: $session.overlays.plantFoot)
                Toggle("Football", isOn: $session.overlays.football)
                Toggle("Measurement lines", isOn: $session.overlays.measurementLines)
                Toggle("Contact moment", isOn: $session.overlays.contactBadge)
                Toggle("Ball flight (experimental)", isOn: Binding(get: { session.overlays.ballFlight }, set: { on in
                    session.overlays.ballFlight = on
                    if on { Task { await session.trackBallFlight(app: app) } }
                }))
                if session.overlays.ballFlight {
                    ForEach(["A", "B"], id: \.self) { k in
                        if let f = session.flight[k] { Text("\(k): \(f.summary)").font(.caption2) }
                    }
                    if let status = session.flightStatus { Text(status).font(.caption2).foregroundStyle(.secondary) }
                    Text("Image-space path only: no height, distance, launch angle or hang time is measured from one uncalibrated video.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Filled dots: joints detected in the video. Hollow dots: filled in between detections (not directly detected). Missing joints aren't drawn.")
                    Text("Plant foot: cyan ring (filled = detected). Lines appear only on the contact frame of rear/front recordings.")
                    Text("Aligning by hand only changes this comparison; neither analysis is changed.")
                }
                .font(.caption2)
                .foregroundStyle(.secondary)
            }
            .padding(.top, 6)
        }
        .font(.subheadline)
    }

    @ViewBuilder
    private var table: some View {
        if session.isPair {
            Text("Two camera angles of the same kick, synchronized with the offset you set. Only camera A's video is analyzed; multi-view analysis isn't part of this build.")
                .font(.caption2).foregroundStyle(.secondary)
        } else if let a = session.sideA?.kick, let b = session.sideB?.kick {
            VStack(alignment: .leading, spacing: 6) {
                Text("Measurements").font(.headline)
                if let why = KickComparison.incompatibility(a, b) {
                    Text(why).font(.footnote).foregroundStyle(.secondary)
                } else {
                    ForEach(KickComparison.notes(a, b), id: \.self) { Text($0).font(.footnote).foregroundStyle(.orange) }
                    Grid(alignment: .leading, horizontalSpacing: 8, verticalSpacing: 6) {
                        GridRow {
                            Text("Measurement").font(.caption.bold())
                            Text("A").font(.caption.bold())
                            Text("B").font(.caption.bold())
                            Text("B − A").font(.caption.bold())
                        }
                        ForEach(session.rows) { r in
                            GridRow {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(r.name).font(.caption)
                                    if let note = r.note { Text(note).font(.caption2).foregroundStyle(.secondary) }
                                }
                                Text(r.a).font(.caption.monospacedDigit())
                                Text(r.b).font(.caption.monospacedDigit())
                                Text(r.difference ?? "—").font(.caption.monospacedDigit())
                            }
                        }
                    }
                    Text("Only measurements with the same definition and camera view are compared; \"—\" means not measured reliably (never zero). Differences describe the two kicks; they don't say which is better or why a kick was made or missed.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
    }
}

/// Build 20: two videos played in sync relative to contact.
///
/// Playback: both players are seeked exactly (zero tolerance) to their aligned times, then
/// started at the same host time. While playing, Kick B is re-seeked if it drifts more than
/// half a frame from Kick A. Memory: two `AVPlayer`s with a short forward buffer; both are
/// paused and released when the screen closes. Overlays are drawn from stored pose and
/// football data only (binary search per frame; no image processing during playback).
@MainActor
@Observable
final class KickComparisonSession {
    private(set) var state: LoadState<Bool> = .loading
    private(set) var sideA: ComparisonSideContent?
    private(set) var sideB: ComparisonSideContent?
    var alignment = ComparisonAlignment(a: .init(contactTime: nil, provenance: .notEstablished, duration: 0, frameInterval: 1.0 / 30),
                                        b: .init(contactTime: nil, provenance: .notEstablished, duration: 0, frameInterval: 1.0 / 30))
    private(set) var relativeTime: Double = 0
    private(set) var isPlaying = false
    var rate: Double = 0.25
    /// Build 21: everything off when a comparison opens.
    var overlays = CompareOverlaySettings()
    var showsAdvanced = false
    /// Per pane ("A", "B"): the zoom applied to video and overlays together.
    private(set) var zoom: [String: ZoomTransform] = [:]
    @ObservationIgnored private var gestureStart: [String: ZoomTransform] = [:]
    /// Experimental ball-flight observations per pane.
    private(set) var flight: [String: BallFlightObservation] = [:]
    private(set) var flightStatus: String?

    enum Mode: Equatable { case analyses(UUID, UUID), pair(kick: UUID) }
    let mode: Mode
    var isPair: Bool { if case .pair = mode { return true }; return false }

    @ObservationIgnored private(set) var playerA: AVPlayer?
    @ObservationIgnored private(set) var playerB: AVPlayer?
    @ObservationIgnored private var observer: Any?

    static let rates: [Double] = [0.1, 0.25, 0.5, 1]

    init(mode: Mode) {
        self.mode = mode
    }

    convenience init(analysisA: UUID, analysisB: UUID) {
        self.init(mode: .analyses(analysisA, analysisB))
    }

    var timeA: Double { alignment.timeA(relativeTime) }
    var timeB: Double { alignment.timeB(relativeTime) }

    func load(app: AppModel) async {
        let loaded: (ComparisonSideContent, ComparisonSideContent)?
        switch mode {
        case .analyses(let x, let y):
            if let a = await Self.loadSide(x, app: app), let b = await Self.loadSide(y, app: app) { loaded = (a, b) } else { loaded = nil }
        case .pair(let kickID):
            loaded = await Self.loadPair(kickID, app: app)
        }
        guard let (a, b) = loaded else {
            state = .failed(isPair ? "This kick's second camera clip or its analysis is no longer available." : "One of these analyses or its stored data is no longer available.")
            return
        }
        sideA = a
        sideB = b
        alignment = ComparisonAlignment(a: a.side, b: b.side)
        if let url = a.videoURL { playerA = Self.makePlayer(url) }
        if let url = b.videoURL { playerB = Self.makePlayer(url) }
        relativeTime = alignment.initialRelativeTime
        attachObserver()
        seekBoth()
        state = .loaded(true)
    }

    private static func makePlayer(_ url: URL) -> AVPlayer {
        let item = AVPlayerItem(url: url)
        item.preferredForwardBufferDuration = 2
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = false
        player.actionAtItemEnd = .pause
        return player
    }

    private static func loadSide(_ id: UUID, app: AppModel) async -> ComparisonSideContent? {
        guard let analysis = ModelLookup.analysis(id, in: app.context) else { return nil }
        let video = ContactAnnotationStore.primaryVideo(of: analysis)
        let hasVideo = video.map { app.services.videos.fileExists(for: $0) } ?? false
        guard let kick = ComparisonKick(analysis: analysis, hasVideo: hasVideo) else { return nil }
        let url = hasVideo ? video.flatMap { app.services.videos.fileURL(for: $0) } : nil
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) } ?? .right
        var timeline: PoseValidationTimeline?
        var stored: KickerPoseTimeline?
        var phases: KickPhaseDetectionResult?
        var football: FootballTrack?
        var frameRate: Double?
        var kickingFoot = foot
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let built = await Task.detached { () -> (PoseValidationTimeline?, AnalysisArtifactBundle)? in
                guard let bundle = try? store.readBundle(in: directory) else { return nil }
                let input = AnalysisDiagnosticsInput(bundle: bundle)
                // Stored data only: no replay, so what is drawn is what the analysis used.
                let t = PoseValidationTimeline.make(sequence: bundle.pose.sequence, storedTimeline: bundle.pose.kickerTimeline,
                                                    currentTimeline: nil, repair: nil, kickingFoot: input.context?.kickingFoot ?? foot,
                                                    storedPhases: bundle.phases.phases, currentPhases: nil, markedContact: nil,
                                                    football: bundle.phases.football)
                return (t, bundle)
            }.value
            if let (t, bundle) = built {
                timeline = t
                stored = bundle.pose.kickerTimeline
                phases = bundle.phases.phases
                football = bundle.phases.football
                frameRate = bundle.pose.sequence.nominalFrameRate
                kickingFoot = AnalysisDiagnosticsInput(bundle: bundle).context?.kickingFoot ?? foot
            }
        }
        let contact = phases?.estimatedContactTime
        let side = ComparisonSide(
            contactTime: contact, contactEarliest: phases?.evidence?.contactEarliestTime, contactLatest: phases?.evidence?.contactLatestTime,
            provenance: contact == nil ? .notEstablished : (phases?.isUserAssisted == true ? .userAssisted : .automatic),
            duration: video?.durationSeconds ?? timeline?.duration ?? 0,
            frameInterval: 1 / max(frameRate ?? video?.frameRate ?? 30, 1))
        return ComparisonSideContent(kick: kick, timeline: timeline, storedTimeline: stored, football: football,
                                     kickingFoot: kickingFoot, videoURL: url, side: side)
    }

    /// Build 21: a session pair — camera A's analyzed clip and camera B's clip of the same
    /// kick. B's contact comes from A's contact through the synchronization offset; its
    /// uncertainty adds the sync's.
    private static func loadPair(_ kickID: UUID, app: AppModel) async -> (ComparisonSideContent, ComparisonSideContent)? {
        guard let kick = ModelLookup.kick(kickID, in: app.context),
              let analysis = (kick.analyses ?? []).first(where: { $0.isCurrent && $0.processingStatus == .completed }),
              var a = await loadSide(analysis.id, app: app),
              let second = (kick.videos ?? []).first(where: { !$0.isPrimary && $0.syncOffsetSeconds != nil }),
              app.services.videos.fileExists(for: second), let url = app.services.videos.fileURL(for: second) else { return nil }
        let offset = second.syncOffsetSeconds ?? 0
        let syncU = SessionPairLookup.syncUncertainty(kickID: kickID, app: app) ?? 2.0 / 30
        let contactB = a.side.contactTime.map { $0 - offset }
        let widthA = a.side.contactWidth ?? a.side.frameInterval
        let sideB = ComparisonSide(contactTime: contactB,
                                   contactEarliest: contactB.map { $0 - widthA / 2 - syncU }, contactLatest: contactB.map { $0 + widthA / 2 + syncU },
                                   provenance: contactB == nil ? .notEstablished : .cameraSync,
                                   duration: second.durationSeconds ?? 0, frameInterval: 1 / max(second.frameRate ?? 30, 1))
        var kickB = a.kick
        kickB.view = ComparableView(angle: second.angleType)
        let b = ComparisonSideContent(kick: kickB, timeline: nil, storedTimeline: nil, football: nil, kickingFoot: a.kickingFoot, videoURL: url,
                                      side: sideB, caption: "Camera B · \(second.angleType.displayName)",
                                      displayAspectRatio: Self.aspect(width: second.pixelWidth, height: second.pixelHeight))
        a.caption = "Camera A · \(a.kick.view.title)"
        return (a, b)
    }

    private static func aspect(width: Int?, height: Int?) -> Double? {
        guard let w = width, let h = height, w > 0, h > 0 else { return nil }
        return Double(w) / Double(h)
    }

    // MARK: Zoom (Build 21)

    func frameAthlete(_ pane: String, on: Bool, content: OverlayRect, size: CGSize) {
        guard on else { zoom[pane] = .identity; return }
        let side = pane == "A" ? sideA : sideB
        guard let s = side, let range = alignment.range else { return }
        let times = pane == "A" ? (alignment.timeA(range.lowerBound)...alignment.timeA(range.upperBound))
                                : (alignment.timeB(range.lowerBound)...alignment.timeB(range.upperBound))
        guard let box = AthleteFraming.athleteBox(s.storedTimeline, window: times) else { return }
        zoom[pane] = AthleteFraming.transform(box: box, content: content, containerWidth: Double(size.width), containerHeight: Double(size.height))
    }

    func pinch(_ pane: String, by factor: Double, content: OverlayRect, size: CGSize) {
        let start = gestureStart[pane] ?? zoom[pane] ?? .identity
        gestureStart[pane] = start
        // Zoom about the container's centre.
        let cx = Double(size.width) / 2, cy = Double(size.height) / 2
        let scale = start.scale * factor
        var t = ZoomTransform(scale: scale, offsetX: cx - (cx - start.offsetX) * factor, offsetY: cy - (cy - start.offsetY) * factor)
        t = AthleteFraming.clamp(t, content: content, containerWidth: Double(size.width), containerHeight: Double(size.height))
        zoom[pane] = t
    }

    func pan(_ pane: String, dx: Double, dy: Double, content: OverlayRect, size: CGSize) {
        let start = gestureStart[pane] ?? zoom[pane] ?? .identity
        gestureStart[pane] = start
        guard start.scale > 1 else { return }
        let t = ZoomTransform(scale: start.scale, offsetX: start.offsetX + dx, offsetY: start.offsetY + dy)
        zoom[pane] = AthleteFraming.clamp(t, content: content, containerWidth: Double(size.width), containerHeight: Double(size.height))
    }

    func endGesture(_ pane: String) { gestureStart[pane] = nil }

    func resetZoom() {
        zoom = [:]
        overlays.zoomToAthlete = false
    }

    // MARK: Ball flight (experimental, Build 21)

    func trackBallFlight(app: AppModel) async {
        let tracker = app.services.ballFlightTracker
        guard tracker.isAvailable else { flightStatus = "Ball-flight tracking isn't available on this device."; return }
        flightStatus = "Following the ball after contact…"
        for (pane, side) in [("A", sideA), ("B", sideB)] {
            guard flight[pane] == nil, let s = side, let url = s.videoURL, let contact = s.side.contactTime,
                  let rest = s.football.flatMap(FootballTrack.kickedBallRest) else { continue }
            if let o = try? await Task.detached(priority: .utility, operation: {
                try await tracker.observe(videoURL: url, contactTime: contact, rest: rest, seconds: 2.5)
            }).value {
                flight[pane] = o
            }
        }
        flightStatus = flight.isEmpty ? "No ball flight could be followed (the kicked ball's resting spot is needed)." : nil
    }

    private func attachObserver() {
        guard let playerA else { return }
        observer = playerA.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1.0 / 30, preferredTimescale: 600), queue: .main) { [weak self] time in
            MainActor.assumeIsolated {
                guard let self, self.isPlaying, time.seconds.isFinite else { return }
                self.relativeTime = self.alignment.relative(fromA: time.seconds)
                if let range = self.alignment.range, self.relativeTime >= range.upperBound { self.pause(); return }
                // Keep Kick B within half a frame of where it should be.
                if let b = self.playerB {
                    let expected = self.alignment.timeB(self.relativeTime)
                    let drift = b.currentTime().seconds - expected
                    if drift.isFinite, abs(drift) > self.alignment.step / 2 {
                        b.seek(to: CMTime(seconds: expected, preferredTimescale: 6000), toleranceBefore: .zero, toleranceAfter: .zero)
                    }
                }
            }
        }
    }

    private func seekBoth() {
        let a = CMTime(seconds: max(0, timeA), preferredTimescale: 6000)
        let b = CMTime(seconds: max(0, timeB), preferredTimescale: 6000)
        playerA?.seek(to: a, toleranceBefore: .zero, toleranceAfter: .zero)
        playerB?.seek(to: b, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    func play() {
        guard let range = alignment.range else { return }
        if relativeTime >= range.upperBound - alignment.step { relativeTime = alignment.initialRelativeTime }
        seekBoth()
        // Start both at the same host time, slightly in the future.
        let host = CMTimeAdd(CMClockGetTime(CMClockGetHostTimeClock()), CMTime(seconds: 0.15, preferredTimescale: 600))
        let r = Float(rate)
        playerA?.setRate(r, time: CMTime(seconds: max(0, timeA), preferredTimescale: 6000), atHostTime: host)
        playerB?.setRate(r, time: CMTime(seconds: max(0, timeB), preferredTimescale: 6000), atHostTime: host)
        isPlaying = true
    }

    func pause() {
        playerA?.pause()
        playerB?.pause()
        isPlaying = false
    }

    func scrub(to relative: Double) {
        pause()
        relativeTime = alignment.clamp(relative)
        seekBoth()
    }

    func step(_ frames: Int) {
        scrub(to: relativeTime + Double(frames) * alignment.step)
    }

    func jumpToContact() { scrub(to: 0) }

    /// Manual alignment: shifts Kick B by whole frames for this comparison only.
    func nudge(_ frames: Int) {
        pause()
        alignment = alignment.nudged(frames: frames)
        relativeTime = alignment.clamp(relativeTime)
        seekBoth()
    }

    func resetAlignment() {
        pause()
        alignment.manualOffset = 0
        relativeTime = alignment.clamp(relativeTime)
        seekBoth()
    }

    func stop() {
        pause()
        if let observer { playerA?.removeTimeObserver(observer) }
        observer = nil
        playerA?.replaceCurrentItem(with: nil)
        playerB?.replaceCurrentItem(with: nil)
        playerA = nil
        playerB = nil
    }

    var rows: [ComparisonRow] {
        guard let a = sideA?.kick, let b = sideB?.kick else { return [] }
        return KickComparison.rows(a, b)
    }
}
