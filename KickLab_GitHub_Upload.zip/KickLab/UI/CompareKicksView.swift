import AVKit
import SwiftUI

/// Build 20 — Compare Kicks: choose two analyzed kicks (Kick A, Kick B).
struct CompareKicksView: View {
    @Environment(AppModel.self) private var app
    @State private var model: CompareKicksViewModel

    init(preselected: UUID? = nil) {
        _model = State(initialValue: CompareKicksViewModel(preselected: preselected))
    }

    var body: some View {
        List {
            if let message = model.message {
                Section { Label(message, systemImage: "info.circle").foregroundStyle(.secondary) }
            }
            Section("Kick A") {
                Menu {
                    ForEach(KickComparison.filter(model.kicks, by: .all)) { k in
                        Button(k.title) {
                            model.selectedA = k.analysisID
                            if model.selectedB == k.analysisID { model.selectedB = nil }
                        }
                    }
                } label: {
                    if let a = model.kick(model.selectedA) { row(a, selected: true) } else { Text("Choose a kick") }
                }
            }
            Section {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(model.availableFilters, id: \.self) { f in
                            Button(f.title) { model.filter = f }
                                .buttonStyle(.bordered)
                                .tint(model.filter == f ? .accentColor : .secondary)
                                .accessibilityAddTraits(model.filter == f ? .isSelected : [])
                        }
                    }
                }
                Picker("Sort", selection: $model.sort) {
                    ForEach(ComparisonSort.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                if model.candidates.isEmpty {
                    Text("No analyzed kicks match this filter.").foregroundStyle(.secondary)
                }
                ForEach(model.candidates) { k in
                    Button { model.selectedB = k.analysisID } label: { row(k, selected: model.selectedB == k.analysisID) }
                        .buttonStyle(.plain)
                        .swipeActions { referenceButton(k) }
                        .contextMenu { referenceButton(k) }
                }
            } header: {
                Text("Kick B")
            } footer: {
                Text(PersonalReferencePolicy.explanation + " Swipe a kick to set or clear it.")
            }
            Section {
                if model.canCompare, let a = model.selectedA, let b = model.selectedB {
                    NavigationLink(value: AppRoute.comparison(a, b)) {
                        Label("Compare side by side", systemImage: "rectangle.split.2x1")
                    }
                    if let ka = model.kick(a), let kb = model.kick(b), let why = KickComparison.incompatibility(ka, kb) {
                        Text(why).font(.footnote).foregroundStyle(.secondary)
                    }
                } else {
                    Text("Choose two different kicks.").foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("Compare Kicks")
        .task(id: app.revision) { model.load(app: app) }
    }

    @ViewBuilder
    private func referenceButton(_ k: ComparisonKick) -> some View {
        Button {
            model.setReference(kickID: k.kickID, on: !k.isReference, app: app)
        } label: {
            Label(k.isReference ? "Clear Reference" : "Set as Reference", systemImage: k.isReference ? "star.slash" : "star")
        }
        .tint(.yellow)
    }

    private func row(_ k: ComparisonKick, selected: Bool) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(k.title).font(.subheadline.weight(.semibold))
                Text(k.badges.joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if k.isReference { Image(systemName: "star.fill").foregroundStyle(.yellow).accessibilityLabel("Reference kick") }
            if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.accentColor).accessibilityLabel("Selected") }
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

/// Build 20 — two kicks side by side, synchronized at contact.
struct KickComparisonView: View {
    @Environment(AppModel.self) private var app
    @State private var session: KickComparisonSession

    init(analysisA: UUID, analysisB: UUID) {
        _session = State(initialValue: KickComparisonSession(analysisA: analysisA, analysisB: analysisB))
    }

    var body: some View {
        content
            .navigationTitle("Compare")
            .navigationBarTitleDisplayMode(.inline)
            .task { await session.load(app: app) }
            .onDisappear { session.stop() }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Toggle("Skeleton", isOn: $session.showsSkeleton)
                        Toggle("Plant foot", isOn: $session.showsPlantFoot)
                        Toggle("Football", isOn: $session.showsFootball)
                        Toggle("Contact moment", isOn: $session.showsContact)
                        Toggle("Measurement lines", isOn: $session.showsMeasurementLines)
                    } label: {
                        Label("Overlays", systemImage: "square.3.layers.3d")
                    }
                }
            }
    }

    @ViewBuilder
    private var content: some View {
        switch session.state {
        case .loading:
            LoadingStateView(text: "Loading both kicks…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded:
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 6) {
                        if let a = session.sideA { pane(a, label: "A", time: session.timeA, player: session.playerA) }
                        if let b = session.sideB { pane(b, label: "B", time: session.timeB, player: session.playerB) }
                    }
                    .frame(height: 340)
                    Text(session.alignment.statusText)
                        .font(.caption)
                        .foregroundStyle(statusColor)
                    controls
                    alignmentControls
                    legend
                    table
                }
                .padding(.horizontal)
            }
        }
    }

    private var statusColor: Color {
        switch session.alignment.status {
        case .aligned: .secondary
        case .uncertain, .notAligned: .orange
        }
    }

    private func pane(_ s: ComparisonSideContent, label: String, time: Double, player: AVPlayer?) -> some View {
        let aspect = s.timeline?.displayAspectRatio ?? (9.0 / 16)
        let frame = s.side.frameInterval
        let storedValue = s.kick.metrics[.plantBallLateralOffset]?.value
        return VStack(alignment: .leading, spacing: 4) {
            ZStack {
                Color.black
                if let player {
                    ValidationVideoSurface(player: player)
                } else {
                    Text("Video not on this device").font(.caption).foregroundStyle(.white).padding(8)
                }
                GeometryReader { g in
                    let rect = PoseOverlayGeometry.aspectFitRect(containerWidth: Double(g.size.width), containerHeight: Double(g.size.height), contentAspect: aspect)
                    ZStack {
                        if session.showsSkeleton, let t = s.timeline {
                            SkeletonOverlay(timeline: t, time: time, source: .stored, rect: rect, showsConfidence: false)
                        }
                        if session.showsFootball, let ball = s.timeline?.football {
                            FootballOverlayView(model: ball, time: time, frame: frame, rect: rect)
                        }
                        if session.showsPlantFoot, let p = ComparisonOverlay.plantFoot(s.storedTimeline, at: time, frame: frame, kickingFoot: s.kickingFoot) {
                            let pt = PoseOverlayGeometry.point(x: p.x, y: p.y, in: rect)
                            Circle()
                                .stroke(Color.cyan, lineWidth: 2)
                                .background(Circle().fill(p.measured ? Color.cyan.opacity(0.6) : Color.clear))
                                .frame(width: 18, height: 18)
                                .position(x: CGFloat(pt.x), y: CGFloat(pt.y))
                        }
                        if session.showsMeasurementLines,
                           let i = ComparisonOverlay.measurementLine(view: s.kick.view, timeline: s.storedTimeline, football: s.football,
                                                                     contact: s.side.contactTime, time: time, frame: frame,
                                                                     kickingFoot: s.kickingFoot, storedValue: storedValue) {
                            let r = PoseOverlayGeometry.point(x: i.reference.x, y: i.ankle.y, in: rect)
                            let a = PoseOverlayGeometry.point(x: i.ankle.x, y: i.ankle.y, in: rect)
                            Path { path in
                                path.move(to: CGPoint(x: r.x, y: r.y))
                                path.addLine(to: CGPoint(x: a.x, y: a.y))
                            }
                            .stroke(Color.yellow, lineWidth: 2)
                        }
                    }
                }
                .allowsHitTesting(false)
                VStack {
                    HStack {
                        Text(label).font(.caption.bold()).foregroundStyle(.white).padding(4).background(RoundedRectangle(cornerRadius: 4).fill(Color.black.opacity(0.55)))
                        Spacer()
                        if session.showsContact, ComparisonOverlay.isContactFrame(time: time, contact: s.side.contactTime, frame: frame) {
                            Text("Contact").font(.caption2.bold()).padding(4).background(RoundedRectangle(cornerRadius: 4).fill(Color.yellow))
                                .foregroundStyle(.black)
                        }
                    }
                    Spacer()
                }
                .padding(4)
            }
            .clipped()
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Kick \(label) video, \(s.kick.title)")
            Text(s.kick.title).font(.caption2.weight(.semibold)).lineLimit(2)
            Text(s.side.provenance.title + (s.side.contactTime.map { String(format: " · %.3f s", $0) } ?? ""))
                .font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var controls: some View {
        VStack(spacing: 8) {
            if let range = session.alignment.range {
                Slider(value: Binding(get: { session.relativeTime }, set: { session.scrub(to: $0) }), in: range)
                    .accessibilityLabel("Time relative to contact")
                    .accessibilityValue(String(format: "%.2f seconds", session.relativeTime))
            }
            HStack {
                Text(String(format: "%+.3f s from contact", session.relativeTime)).font(.caption.monospacedDigit())
                Spacer()
                Picker("Speed", selection: $session.rate) {
                    ForEach(KickComparisonSession.rates, id: \.self) { Text(rateText($0)).tag($0) }
                }
                .pickerStyle(.menu)
            }
            HStack(spacing: 16) {
                Button { session.step(-1) } label: { Image(systemName: "backward.frame") }
                    .accessibilityLabel("Back one frame")
                Button { session.isPlaying ? session.pause() : session.play() } label: {
                    Image(systemName: session.isPlaying ? "pause.fill" : "play.fill").font(.title2)
                }
                .accessibilityLabel(session.isPlaying ? "Pause" : "Play")
                Button { session.step(1) } label: { Image(systemName: "forward.frame") }
                    .accessibilityLabel("Forward one frame")
                Spacer()
                Button("Contact") { session.jumpToContact() }
                    .disabled(!session.alignment.isContactAligned)
            }
            .buttonStyle(.bordered)
        }
    }

    private func rateText(_ r: Double) -> String { r == 1 ? "1×" : String(format: "%g×", r) }

    private var alignmentControls: some View {
        HStack {
            Text("Align Kick B").font(.caption)
            Spacer()
            Button { session.nudge(-1) } label: { Image(systemName: "minus") }
                .accessibilityLabel("Shift Kick B one frame earlier")
            Button { session.nudge(1) } label: { Image(systemName: "plus") }
                .accessibilityLabel("Shift Kick B one frame later")
            Button("Reset") { session.resetAlignment() }
                .disabled(session.alignment.manualOffset == 0)
        }
        .buttonStyle(.bordered)
    }

    private var legend: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("Filled dots: joints detected in the video. Hollow dots: filled in between detections (not directly detected). Missing joints aren't drawn.")
            Text("Plant foot: cyan ring (filled = detected). Football box: the detector's box on that frame. Lines appear only on the contact frame of rear/front recordings.")
            Text("Aligning by hand only changes this comparison; neither analysis is changed.")
        }
        .font(.caption2)
        .foregroundStyle(.secondary)
    }

    @ViewBuilder
    private var table: some View {
        if let a = session.sideA?.kick, let b = session.sideB?.kick {
            VStack(alignment: .leading, spacing: 6) {
                Text("Measurements").font(.headline)
                if let why = KickComparison.incompatibility(a, b) {
                    Text(why).font(.footnote).foregroundStyle(.secondary)
                } else {
                    ForEach(KickComparison.notes(a, b), id: \.self) { Text($0).font(.footnote).foregroundStyle(.orange) }
                    Grid(alignment: .leading, horizontalSpacing: 8, verticalSpacing: 6) {
                        GridRow {
                            Text("Measurement").font(.caption.bold())
                            Text("A").font(.caption.bold())
                            Text("B").font(.caption.bold())
                            Text("B − A").font(.caption.bold())
                        }
                        ForEach(session.rows) { r in
                            GridRow {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(r.name).font(.caption)
                                    if let note = r.note { Text(note).font(.caption2).foregroundStyle(.secondary) }
                                }
                                Text(r.a).font(.caption.monospacedDigit())
                                Text(r.b).font(.caption.monospacedDigit())
                                Text(r.difference ?? "—").font(.caption.monospacedDigit())
                            }
                        }
                    }
                    Text("Only measurements with the same definition and camera view are compared; \"—\" means not measured reliably (never zero). Differences describe the two kicks; they don't say which is better or why a kick was made or missed.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .padding(.bottom, 24)
        }
    }
}

/// Build 20: two videos played in sync relative to contact.
///
/// Playback: both players are seeked exactly (zero tolerance) to their aligned times, then
/// started at the same host time. While playing, Kick B is re-seeked if it drifts more than
/// half a frame from Kick A. Memory: two `AVPlayer`s with a short forward buffer; both are
/// paused and released when the screen closes. Overlays are drawn from stored pose and
/// football data only (binary search per frame; no image processing during playback).
@MainActor
@Observable
final class KickComparisonSession {
    private(set) var state: LoadState<Bool> = .loading
    private(set) var sideA: ComparisonSideContent?
    private(set) var sideB: ComparisonSideContent?
    var alignment = ComparisonAlignment(a: .init(contactTime: nil, provenance: .notEstablished, duration: 0, frameInterval: 1.0 / 30),
                                        b: .init(contactTime: nil, provenance: .notEstablished, duration: 0, frameInterval: 1.0 / 30))
    private(set) var relativeTime: Double = 0
    private(set) var isPlaying = false
    var rate: Double = 0.25
    // Overlay toggles.
    var showsSkeleton = true
    var showsPlantFoot = true
    var showsFootball = true
    var showsContact = true
    var showsMeasurementLines = true

    @ObservationIgnored private(set) var playerA: AVPlayer?
    @ObservationIgnored private(set) var playerB: AVPlayer?
    @ObservationIgnored private var observer: Any?

    static let rates: [Double] = [0.1, 0.25, 0.5, 1]

    let analysisA: UUID
    let analysisB: UUID

    init(analysisA: UUID, analysisB: UUID) {
        self.analysisA = analysisA
        self.analysisB = analysisB
    }

    var timeA: Double { alignment.timeA(relativeTime) }
    var timeB: Double { alignment.timeB(relativeTime) }

    func load(app: AppModel) async {
        guard let a = await Self.loadSide(analysisA, app: app), let b = await Self.loadSide(analysisB, app: app) else {
            state = .failed("One of these analyses or its stored data is no longer available.")
            return
        }
        sideA = a
        sideB = b
        alignment = ComparisonAlignment(a: a.side, b: b.side)
        if let url = a.videoURL { playerA = Self.makePlayer(url) }
        if let url = b.videoURL { playerB = Self.makePlayer(url) }
        relativeTime = alignment.initialRelativeTime
        attachObserver()
        seekBoth()
        state = .loaded(true)
    }

    private static func makePlayer(_ url: URL) -> AVPlayer {
        let item = AVPlayerItem(url: url)
        item.preferredForwardBufferDuration = 2
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = false
        player.actionAtItemEnd = .pause
        return player
    }

    private static func loadSide(_ id: UUID, app: AppModel) async -> ComparisonSideContent? {
        guard let analysis = ModelLookup.analysis(id, in: app.context) else { return nil }
        let video = ContactAnnotationStore.primaryVideo(of: analysis)
        let hasVideo = video.map { app.services.videos.fileExists(for: $0) } ?? false
        guard let kick = ComparisonKick(analysis: analysis, hasVideo: hasVideo) else { return nil }
        let url = hasVideo ? video.flatMap { app.services.videos.fileURL(for: $0) } : nil
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) } ?? .right
        var timeline: PoseValidationTimeline?
        var stored: KickerPoseTimeline?
        var phases: KickPhaseDetectionResult?
        var football: FootballTrack?
        var frameRate: Double?
        var kickingFoot = foot
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let built = await Task.detached { () -> (PoseValidationTimeline?, AnalysisArtifactBundle)? in
                guard let bundle = try? store.readBundle(in: directory) else { return nil }
                let input = AnalysisDiagnosticsInput(bundle: bundle)
                // Stored data only: no replay, so what is drawn is what the analysis used.
                let t = PoseValidationTimeline.make(sequence: bundle.pose.sequence, storedTimeline: bundle.pose.kickerTimeline,
                                                    currentTimeline: nil, repair: nil, kickingFoot: input.context?.kickingFoot ?? foot,
                                                    storedPhases: bundle.phases.phases, currentPhases: nil, markedContact: nil,
                                                    football: bundle.phases.football)
                return (t, bundle)
            }.value
            if let (t, bundle) = built {
                timeline = t
                stored = bundle.pose.kickerTimeline
                phases = bundle.phases.phases
                football = bundle.phases.football
                frameRate = bundle.pose.sequence.nominalFrameRate
                kickingFoot = AnalysisDiagnosticsInput(bundle: bundle).context?.kickingFoot ?? foot
            }
        }
        let contact = phases?.estimatedContactTime
        let side = ComparisonSide(
            contactTime: contact, contactEarliest: phases?.evidence?.contactEarliestTime, contactLatest: phases?.evidence?.contactLatestTime,
            provenance: contact == nil ? .notEstablished : (phases?.isUserAssisted == true ? .userAssisted : .automatic),
            duration: video?.durationSeconds ?? timeline?.duration ?? 0,
            frameInterval: 1 / max(frameRate ?? video?.frameRate ?? 30, 1))
        return ComparisonSideContent(kick: kick, timeline: timeline, storedTimeline: stored, football: football,
                                     kickingFoot: kickingFoot, videoURL: url, side: side)
    }

    private func attachObserver() {
        guard let playerA else { return }
        observer = playerA.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1.0 / 30, preferredTimescale: 600), queue: .main) { [weak self] time in
            MainActor.assumeIsolated {
                guard let self, self.isPlaying, time.seconds.isFinite else { return }
                self.relativeTime = self.alignment.relative(fromA: time.seconds)
                if let range = self.alignment.range, self.relativeTime >= range.upperBound { self.pause(); return }
                // Keep Kick B within half a frame of where it should be.
                if let b = self.playerB {
                    let expected = self.alignment.timeB(self.relativeTime)
                    let drift = b.currentTime().seconds - expected
                    if drift.isFinite, abs(drift) > self.alignment.step / 2 {
                        b.seek(to: CMTime(seconds: expected, preferredTimescale: 6000), toleranceBefore: .zero, toleranceAfter: .zero)
                    }
                }
            }
        }
    }

    private func seekBoth() {
        let a = CMTime(seconds: max(0, timeA), preferredTimescale: 6000)
        let b = CMTime(seconds: max(0, timeB), preferredTimescale: 6000)
        playerA?.seek(to: a, toleranceBefore: .zero, toleranceAfter: .zero)
        playerB?.seek(to: b, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    func play() {
        guard let range = alignment.range else { return }
        if relativeTime >= range.upperBound - alignment.step { relativeTime = alignment.initialRelativeTime }
        seekBoth()
        // Start both at the same host time, slightly in the future.
        let host = CMTimeAdd(CMClockGetTime(CMClockGetHostTimeClock()), CMTime(seconds: 0.15, preferredTimescale: 600))
        let r = Float(rate)
        playerA?.setRate(r, time: CMTime(seconds: max(0, timeA), preferredTimescale: 6000), atHostTime: host)
        playerB?.setRate(r, time: CMTime(seconds: max(0, timeB), preferredTimescale: 6000), atHostTime: host)
        isPlaying = true
    }

    func pause() {
        playerA?.pause()
        playerB?.pause()
        isPlaying = false
    }

    func scrub(to relative: Double) {
        pause()
        relativeTime = alignment.clamp(relative)
        seekBoth()
    }

    func step(_ frames: Int) {
        scrub(to: relativeTime + Double(frames) * alignment.step)
    }

    func jumpToContact() { scrub(to: 0) }

    /// Manual alignment: shifts Kick B by whole frames for this comparison only.
    func nudge(_ frames: Int) {
        pause()
        alignment = alignment.nudged(frames: frames)
        relativeTime = alignment.clamp(relativeTime)
        seekBoth()
    }

    func resetAlignment() {
        pause()
        alignment.manualOffset = 0
        relativeTime = alignment.clamp(relativeTime)
        seekBoth()
    }

    func stop() {
        pause()
        if let observer { playerA?.removeTimeObserver(observer) }
        observer = nil
        playerA?.replaceCurrentItem(with: nil)
        playerB?.replaceCurrentItem(with: nil)
        playerA = nil
        playerB = nil
    }

    var rows: [ComparisonRow] {
        guard let a = sideA?.kick, let b = sideB?.kick else { return [] }
        return KickComparison.rows(a, b)
    }
}
