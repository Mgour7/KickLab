import SwiftUI

/// Step 10 "Coach" section: up to three fixes and two strengths, each with the few
/// numbers that matter (your normal, this kick, your best kicks), confidence and a cue.
/// The full evidence lives behind "Why?".
struct CoachSectionView: View {
    let coach: PersonalCoachPresentation
    let snapshotNote: String?
    @State private var selected: CoachCardPresentation?

    init(coach: PersonalCoachPresentation, snapshotNote: String?) {
        self.coach = coach
        self.snapshotNote = snapshotNote
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Coach").font(.title3.bold())
            if let message = coach.learningMessage {
                CardView {
                    Label(message, systemImage: "graduationcap").font(.subheadline)
                }
            }
            if coach.fixes.isEmpty {
                CardView {
                    Text("No corrections flagged.").font(.headline)
                    Text("KickLab only suggests a change when the evidence supports it.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            ForEach(coach.fixes) { card in
                CoachCardView(card: card, isStrength: false) { selected = card }
            }
            if !coach.strengths.isEmpty {
                Text("Keep doing").font(.headline)
                ForEach(coach.strengths) { card in
                    CoachCardView(card: card, isStrength: true) { selected = card }
                }
            }
            if !coach.secondary.isEmpty {
                DisclosureGroup("More from your kicks (\(coach.secondary.count))") {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(coach.secondary) { card in
                            CoachCardView(card: card, isStrength: false) { selected = card }
                        }
                    }
                }
                .frame(minHeight: 44)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(coach.maturityText)
                ForEach(coach.notes, id: \.self) { note in
                    Text(note)
                }
                if let snapshotNote {
                    Text(snapshotNote)
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .sheet(item: $selected) { card in
            CoachDetailView(card: card)
        }
    }
}

struct CoachCardView: View {
    let card: CoachCardPresentation
    let isStrength: Bool
    let showDetail: () -> Void

    var body: some View {
        CardView {
            HStack {
                Label(card.categoryTitle, systemImage: isStrength ? "hand.thumbsup" : "target")
                    .font(.caption.weight(.semibold))
                Spacer()
                Text("Confidence: \(card.confidenceText)").font(.caption.weight(.semibold))
            }
            Text(card.headline).font(.headline)
            if !card.rows.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(card.rows) { row in
                        LabeledContent(row.title, value: row.value)
                            .font(.subheadline)
                    }
                }
            }
            if let cue = card.cue {
                Label(cue, systemImage: "quote.bubble").font(.subheadline)
            }
            HStack {
                Text(card.basisText).font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button("Why?", action: showDetail)
                    .frame(minWidth: 44, minHeight: 44)
                    .accessibilityHint("Shows the evidence behind this coaching point")
            }
        }
        .accessibilityElement(children: .contain)
    }
}

/// The evidence behind one coaching point.
struct CoachDetailView: View {
    let card: CoachCardPresentation
    @Environment(\.dismiss) private var dismiss

    init(card: CoachCardPresentation) {
        self.card = card
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text(card.detail.headline).font(.headline)
                    if let why = card.detail.why {
                        Text(why)
                    }
                    if let cue = card.detail.cue {
                        Label(cue, systemImage: "quote.bubble")
                    }
                }
                if !card.detail.rows.isEmpty {
                    Section("Numbers") {
                        ForEach(card.detail.rows) { row in
                            LabeledContent(row.title, value: row.value)
                        }
                        LabeledContent("Confidence", value: card.detail.confidenceText)
                    }
                }
                Section("Evidence") {
                    ForEach(card.detail.evidence) { row in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(row.title).font(.subheadline.weight(.semibold))
                            Text(row.text).font(.subheadline)
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                Section("Why it's ranked here") {
                    Text(card.detail.rationale)
                    ForEach(card.detail.priorityRows) { row in
                        LabeledContent(row.title, value: row.value)
                    }
                }
                Section {
                    Text("KickLab's personal coaching is rule-based statistics on your own recorded kicks, not machine learning. It describes what tends to go with your better kicks; it can't prove what causes them.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Coaching detail")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
