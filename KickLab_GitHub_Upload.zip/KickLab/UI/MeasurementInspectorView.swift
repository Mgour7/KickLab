import AVKit
import SwiftUI

/// Build 19 (Athlete Report 4.0): a sideways plant measurement drawn over the contact frame
/// — the kicked football (or the hips' center), the plant ankle and the sideways offset —
/// from the STORED pose and football detections, on-device. When anything needed is
/// missing, it says so instead of drawing an approximate overlay.
struct MeasurementInspectorView: View {
    @Environment(AppModel.self) private var app
    @State private var model: PoseValidationViewModel
    @State private var player: ValidationPlayer?
    let analysisID: UUID
    let metric: KickMetricKey?

    init(analysisID: UUID, metric: String) {
        self.analysisID = analysisID
        self.metric = KickMetricKey(rawValue: metric)
        _model = State(initialValue: PoseValidationViewModel(analysisID: analysisID))
    }

    var body: some View {
        content
            .navigationTitle(metric?.definition.displayName ?? "Measurement")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await model.load(app: app)
                if player == nil, let url = model.state.value?.videoURL { player = ValidationPlayer(url: url) }
                if case .success(let i) = inspection { player?.seek(to: i.time) }
            }
            .onDisappear { player?.stop() }
    }

    private var storedValue: Double? {
        guard let metric, let analysis = ModelLookup.analysis(analysisID, in: app.context) else { return nil }
        return (analysis.metrics ?? []).first { $0.metricKey == metric.rawValue && $0.measurementStatus != .unavailable }?.value
    }

    private var inspection: Result<MeasurementInspection, MeasurementInspection.Failure> {
        guard let metric, let kind = MeasurementInspection.Kind(metric: metric) else { return .failure(.noMeasurement) }
        guard let c = model.state.value else { return .failure(.noPose) }
        let contact = c.storedPhases?.phase(.contact)
        return MeasurementInspection.make(kind: kind, timeline: c.storedTimeline, football: c.football,
                                          contactTime: contact?.isAvailable == true ? contact?.representativeTime : nil,
                                          kickingFoot: c.kickingFoot, storedValue: storedValue)
    }

    @ViewBuilder
    private var content: some View {
        switch model.state {
        case .loading:
            LoadingStateView(text: "Reading the contact frame…")
        case .failed(let message):
            ErrorStateView(message: message)
        case .loaded(let c):
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    switch inspection {
                    case .success(let i):
                        frame(c, i)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(i.valueText).font(.title3.weight(.bold)).monospacedDigit()
                            Text(MeasurementInspection.provisionalLabel).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                            Text(i.note).font(.caption)
                            Text(String(format: "Contact frame %.3f s · plant ankle %@", i.time, i.ankleMeasured ? "detected" : "filled in (not directly detected)"))
                                .font(.caption2).foregroundStyle(.secondary)
                            if let metric { Text(metric.definition.explanation).font(.caption2).foregroundStyle(.secondary) }
                        }
                        .padding(.horizontal)
                        .accessibilityElement(children: .combine)
                    case .failure(let f):
                        Label(f.message, systemImage: "eye.slash").font(.subheadline).padding()
                    }
                }
                .padding(.vertical)
            }
        }
    }

    private func frame(_ c: PoseValidationViewModel.Content, _ i: MeasurementInspection) -> some View {
        let aspect = c.timeline.displayAspectRatio
        return ZStack {
            Color.black
            if let player { ValidationVideoSurface(player: player.player) }
            GeometryReader { g in
                let rect = PoseOverlayGeometry.aspectFitRect(containerWidth: Double(g.size.width), containerHeight: Double(g.size.height), contentAspect: aspect)
                let rx = rect.x + i.reference.x * rect.width, ax = rect.x + i.ankle.x * rect.width
                let ay = rect.y + i.ankle.y * rect.height, ry = rect.y + i.reference.y * rect.height
                ZStack {
                    if let b = i.ball {
                        Rectangle()
                            .stroke(Color.yellow, lineWidth: 2)
                            .frame(width: CGFloat(b.w * rect.width), height: CGFloat(b.h * rect.height))
                            .position(x: CGFloat(rx), y: CGFloat(ry))
                    }
                    // Vertical guide through the reference, and the sideways offset at ankle height.
                    Path { p in
                        p.move(to: CGPoint(x: rx, y: min(ry, ay) - 20))
                        p.addLine(to: CGPoint(x: rx, y: max(ry, ay) + 20))
                    }
                    .stroke(Color.yellow.opacity(0.7), style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
                    Path { p in
                        p.move(to: CGPoint(x: rx, y: ay))
                        p.addLine(to: CGPoint(x: ax, y: ay))
                    }
                    .stroke(Color.cyan, lineWidth: 3)
                    Circle()
                        .fill(i.ankleMeasured ? Color.cyan : Color.clear)
                        .overlay(Circle().stroke(Color.cyan, lineWidth: 2))
                        .frame(width: 12, height: 12)
                        .position(x: CGFloat(ax), y: CGFloat(ay))
                    Text(i.kind.referenceLabel).font(.caption2.weight(.semibold)).foregroundStyle(.yellow)
                        .position(x: CGFloat(rx), y: CGFloat(max(12, min(ry, ay) - 30)))
                }
            }
            .allowsHitTesting(false)
        }
        .frame(height: 420)
        .clipped()
        .accessibilityLabel("Contact frame with the \(i.kind.referenceLabel.lowercased()) and the plant ankle marked; offset \(i.valueText)")
    }
}
