import SwiftUI

// Athlete Report 5.0 (Build 20; 3.0 in Build 18).
// Top: kick type, the recorded result and distance, analysis status and contact quality;
// one headline sentence; THREE independent summaries (Technique / Consistency / Results —
// never combined); up to three key findings; then measurements with the athlete's usual
// value and what the difference means (long explanations collapsed), coaching labelled by
// kind, one next step, results detail and unavailable areas on demand.
// Quick Report: the kick's result first, then a compact summary that adapts to the
// evidence, rated areas, useful measurements, ≤ 2 strengths, ≤ 2 improvements and ONE
// training priority; unavailable areas collapsed with reasons on demand. Detailed Analysis
// (pushed) is organized by phase in expandable sections. Developer Diagnostics stay
// behind the diagnostics setting. Scores always carry a word as well as a color.

// Build 22: grade colors live in KickTheme.swift.

extension PerformanceReport.Focus {
    /// A practice cue (covered by the breakdown's priority fix when that is shown).
    var isPractice: Bool { if case .practice = self { true } else { false } }
}

extension PerformanceReport.Quality {
    var symbol: String {
        switch self {
        case .good: "circle.fill"
        case .fair: "circle.lefthalf.filled"
        case .limited: "circle.dotted"
        case .unavailable: "circle.slash"
        }
    }
}

/// A compact rounded card used throughout the report.
private struct ReportCard<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 16).fill(KickTheme.surface))
    }
}

/// Level 1: the Quick Report.
struct QuickReportView: View {
    let report: PerformanceReport
    /// Build 19: when set, sideways plant measurements open the contact frame with an overlay.
    let analysisID: UUID?
    @State private var showsUnavailable = false
    /// The headline score scales with Dynamic Type.
    @ScaledMetric(relativeTo: .largeTitle) private var scoreSize: CGFloat = 52

    /// Build 22: the phase-by-phase breakdown shown under the result (replaces the rated
    /// areas and the strengths/improvements list, which it covers phase by phase).
    var breakdown: KickBreakdown?
    var videoURL: URL?
    var phaseFrames: [Double: PhaseFrame] = [:]
    var playVideo: (() -> Void)?

    init(report: PerformanceReport, analysisID: UUID? = nil, breakdown: KickBreakdown? = nil, videoURL: URL? = nil,
         phaseFrames: [Double: PhaseFrame] = [:], playVideo: (() -> Void)? = nil) {
        self.report = report
        self.analysisID = analysisID
        self.breakdown = breakdown
        self.videoURL = videoURL
        self.phaseFrames = phaseFrames
        self.playVideo = playVideo
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            resultCard
            if let breakdown {
                KickBreakdownView(breakdown: breakdown, videoURL: videoURL, frames: phaseFrames, playVideo: playVideo)
            }
            summaryTiles
            if let comparison = report.comparisonText {
                Label(comparison, systemImage: "chart.line.uptrend.xyaxis").font(.caption.weight(.semibold)).padding(.horizontal, 4)
            }
            if !report.keyFindings.isEmpty { findingsCard }
            if breakdown == nil, !report.areas.isEmpty { areasCard }
            if !report.measurements.isEmpty { measurementsCard }
            if breakdown == nil, !report.strengths.isEmpty || !report.improvements.isEmpty || report.noCorrectionText != nil || report.recordingAdvice != nil { coachingCard }
            if let focus = report.focus, !(breakdown != nil && focus.isPractice) { focusCard(focus) }
            if let results = report.results, !results.lines.isEmpty || !results.recentSessions.isEmpty { resultsGroup(results) }
            if let id = analysisID {
                NavigationLink(value: AppRoute.compareKicks(id)) {
                    Label("Compare with another kick", systemImage: "rectangle.split.2x1")
                }
                .font(.subheadline)
                .padding(.horizontal, 4)
            }
            if !report.unavailable.isEmpty { unavailableGroup }
        }
    }

    // Kick type, recorded result (with distance), analysis status, contact quality.
    private var resultCard: some View {
        let h = report.header
        return ReportCard {
            HStack(spacing: 6) {
                Text(h.kickTypeText).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                Spacer(minLength: 4)
                Text(h.state.title).font(.caption.weight(.semibold))
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(Capsule().fill((h.state == .userAssisted ? Color.orange : Color.secondary).opacity(0.18)))
            }
            Text(h.outcomeText)
                .font(h.outcomeRecorded ? .title2.weight(.bold) : .headline)
                .foregroundStyle(h.outcomeRecorded ? Color.primary : Color.secondary)
            HStack(spacing: 6) {
                if h.outcomeRecorded { Text(PerformanceReport.outcomeLabel) }
                Text(h.viewText)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            if let contact = h.contactQualityText { Text(contact).font(.caption).foregroundStyle(.secondary) }
            if !report.headline.isEmpty { Text(report.headline).font(.subheadline) }
        }
        .accessibilityElement(children: .combine)
    }

    // Three independent summaries — never combined into one number.
    private var summaryTiles: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .top, spacing: 8) { tiles }
            VStack(alignment: .leading, spacing: 8) { tiles }
        }
    }

    @ViewBuilder
    private var tiles: some View {
        summaryTile("Technique", report.technique.text, report.technique.detail,
                    color: { if case .technique(_, let label, _) = report.summary { return label.color } else { return .secondary } }())
        summaryTile("Consistency", consistencyTitle, consistencyDetail, color: .secondary)
        summaryTile("Results", report.results?.thisKick ?? "Not recorded", resultsDetail, color: .secondary)
    }

    private var consistencyTitle: String {
        switch report.consistencyReport?.status {
        case .assessed?: "Assessed"
        case .buildingBaseline?: "Building baseline"
        case .notApplicable?, nil: "Not assessed"
        }
    }

    private var consistencyDetail: String {
        report.consistencyReport?.summaryText ?? "Needs a completed analysis"
    }

    private var resultsDetail: String {
        guard let r = report.results else { return "" }
        var parts: [String] = []
        if let s = r.session { parts.append("Session: \(s)") }
        if let o = r.overall, o.overall.attempts > 0 { parts.append("All: \(o.overall.text)") }
        return parts.isEmpty ? "No other results recorded" : parts.joined(separator: " · ")
    }

    private func summaryTile(_ title: String, _ value: String, _ detail: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            Text(value).font(.headline).foregroundStyle(color == .secondary ? Color.primary : color).lineLimit(2)
            Text(detail).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 14).fill(KickTheme.surface))
        .accessibilityElement(children: .combine)
    }

    private var findingsCard: some View {
        ReportCard {
            Text("Key findings").font(.headline)
            ForEach(report.keyFindings) { f in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(f.title).font(.subheadline.weight(.semibold))
                        Text(f.detail).font(.caption).foregroundStyle(.secondary)
                    }
                } icon: {
                    Image(systemName: findingSymbol(f.kind)).foregroundStyle(findingColor(f.kind))
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    private func findingSymbol(_ k: PerformanceReport.Finding.Kind) -> String {
        switch k {
        case .differenceFromUsual: "arrow.left.and.right.circle"
        case .repeatablePattern: "repeat.circle"
        case .strength: "checkmark.circle"
        case .trackingLimitation: "eye.trianglebadge.exclamationmark"
        }
    }

    private func findingColor(_ k: PerformanceReport.Finding.Kind) -> Color {
        switch k {
        case .differenceFromUsual: .blue
        case .repeatablePattern: .mint
        case .strength: .green
        case .trackingLimitation: .orange
        }
    }

    private var areasCard: some View {
        ReportCard {
            Text("Rated areas").font(.headline)
            ForEach(report.areas) { AreaRowView(row: $0) }
        }
    }

    private var measurementsCard: some View {
        ReportCard {
            Text("Measured").font(.headline)
            ForEach(report.measurements) { m in
                if m.inspectable, let id = analysisID {
                    NavigationLink(value: AppRoute.measurementInspector(analysis: id, metric: m.key.rawValue)) {
                        measurementRow(m, showsChevron: true)
                    }
                    .buttonStyle(.plain)
                    .accessibilityHint("Shows the contact frame with this measurement drawn on it")
                } else {
                    measurementRow(m, showsChevron: false)
                }
            }
            measurementDetails
        }
    }

    private func measurementRow(_ m: PerformanceReport.MeasurementRow, showsChevron: Bool) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .firstTextBaseline) {
                Text(m.name).font(.subheadline).lineLimit(2)
                Spacer(minLength: 8)
                Text(m.valueText).font(.subheadline.weight(.semibold)).monospacedDigit().multilineTextAlignment(.trailing)
                if showsChevron { Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary).accessibilityHidden(true) }
            }
            if let usual = m.usualText {
                Text([usual, m.differenceText].compactMap { $0 }.joined(separator: " · ")).font(.caption2).foregroundStyle(.secondary)
            }
            if let reading = m.interpretation {
                Text(reading).font(.caption.weight(m.comparison?.isNotable == true ? .semibold : .regular))
                    .foregroundStyle(m.comparison?.isNotable == true ? Color.primary : Color.secondary)
            }
            Text("Quality: \(m.quality.title)").font(.caption2).foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }

    private var measurementDetails: some View {
        DisclosureGroup("What these measure") {
            VStack(alignment: .leading, spacing: 4) {
                ForEach(report.measurements) { m in
                    Text("\(m.name): \(m.context)").font(.caption2).foregroundStyle(.secondary)
                    if let spread = m.spreadText { Text(spread).font(.caption2).foregroundStyle(.secondary) }
                }
                Text(AnalysisPresentationBuilder.unitNote).font(.caption2).foregroundStyle(.secondary)
            }
            .padding(.top, 4)
        }
        .font(.caption)
    }

    private var coachingCard: some View {
        ReportCard {
            ForEach(report.strengths) { s in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(s.kindLabel).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        Text(s.title).font(.subheadline.weight(.semibold))
                        Text(s.reason).font(.caption).foregroundStyle(.secondary)
                    }
                } icon: {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(report.improvements) { i in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(i.kind.title).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        Text(i.title + (i.insightClass == .provisionalObservation ? " (provisional)" : "")).font(.subheadline.weight(.semibold))
                        Text(i.observed).font(.caption).foregroundStyle(.secondary)
                        Text(i.cue).font(.caption.weight(.semibold))
                        if !i.evidence.isEmpty { Text(i.evidence).font(.caption2).foregroundStyle(.secondary) }
                        if !i.watch.isEmpty { Text("Watch next kick: \(i.watch)").font(.caption2).foregroundStyle(.secondary) }
                    }
                } icon: {
                    Image(systemName: "arrow.up.forward.circle.fill").foregroundStyle(.orange)
                }
                .accessibilityElement(children: .combine)
            }
            if let none = report.noCorrectionText {
                Text(none).font(.caption).foregroundStyle(.secondary)
            }
            if let advice = report.recordingAdvice {
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(PerformanceReport.CoachingKind.recording.title).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        Text(advice).font(.caption)
                    }
                } icon: {
                    Image(systemName: "video").foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    private func focusCard(_ focus: PerformanceReport.Focus) -> some View {
        ReportCard {
            Text(focus.heading).font(.headline)
            switch focus {
            case .practice(let title, let cue, let monitor):
                Text(title).font(.subheadline.weight(.semibold))
                Text(cue).font(.caption)
                Text("Watch next time: \(monitor)").font(.caption).foregroundStyle(.secondary)
            case .recording(let sentence):
                Label(sentence, systemImage: "video").font(.subheadline)
            case .goal(let sentence):
                Label(sentence, systemImage: "target").font(.subheadline)
            }
        }
        .accessibilityElement(children: .combine)
    }

    private func resultsGroup(_ r: KickResultsSummary) -> some View {
        DisclosureGroup("Results detail") {
            VStack(alignment: .leading, spacing: 4) {
                ForEach(r.lines) { line in
                    HStack(alignment: .firstTextBaseline) {
                        Text(line.title).font(.caption)
                        Spacer(minLength: 8)
                        VStack(alignment: .trailing, spacing: 0) {
                            Text(line.value).font(.caption.weight(.semibold)).monospacedDigit()
                            if let d = line.detail { Text(d).font(.caption2).foregroundStyle(.secondary) }
                        }
                    }
                    .accessibilityElement(children: .combine)
                }
                if !r.recentSessions.isEmpty {
                    Text("Recent sessions").font(.caption.weight(.semibold)).padding(.top, 4)
                    ForEach(r.recentSessions) { line in
                        HStack { Text(line.title).font(.caption); Spacer(); Text(line.value).font(.caption).monospacedDigit() }
                    }
                }
                Text("Results are what you entered. KickLab doesn't infer them from the video or link them to a measurement as a cause.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            .padding(.top, 4)
        }
        .font(.subheadline)
        .padding(.horizontal, 4)
    }

    private var unavailableGroup: some View {
        DisclosureGroup("Measurements not available (\(report.unavailable.count))", isExpanded: $showsUnavailable) {
            VStack(alignment: .leading, spacing: 6) {
                ForEach(report.unavailable) { u in
                    VStack(alignment: .leading, spacing: 0) {
                        Text(u.title).font(.caption.weight(.semibold))
                        Text(u.reason).font(.caption).foregroundStyle(.secondary)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
            .padding(.top, 4)
        }
        .font(.subheadline)
        .padding(.horizontal, 4)
    }
}

/// One rated area: name, score + word, a clear limited-confidence marker, and personal rank.
struct AreaRowView: View {
    let row: PerformanceReport.AreaRow

    var body: some View {
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(row.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                if row.isLimitedConfidence {
                    Label("Limited confidence", systemImage: "exclamationmark.circle").font(.caption2.weight(.semibold)).foregroundStyle(.orange)
                } else if row.standing.rank != nil {
                    Text(row.standing.text).font(.caption2).foregroundStyle(.secondary)
                }
                if let note = row.note { Text(note).font(.caption2).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 0) {
                Text("\(row.score)").font(.title3.weight(.bold)).monospacedDigit()
                    .foregroundStyle(row.isLimitedConfidence ? Color.secondary : row.label.color)
                Text(row.label.title).font(.caption2.weight(.semibold))
            }
            .opacity(row.isLimitedConfidence ? 0.7 : 1)
        }
        .padding(.vertical, 2)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(row.accessibilityText)
    }
}

/// Level 2: Detailed Analysis, by phase, in expandable sections.
struct DetailedBreakdownView: View {
    let detailed: DetailedAnalysisReport
    @State private var expanded: Set<String> = []

    private func binding(_ id: String) -> Binding<Bool> {
        Binding(get: { expanded.contains(id) }, set: { if $0 { expanded.insert(id) } else { expanded.remove(id) } })
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(detailed.phases) { section in
                DisclosureGroup(isExpanded: binding(section.id)) {
                    phaseContent(section)
                } label: {
                    HStack {
                        Text(section.title).font(.headline)
                        Spacer()
                        if let a = section.area {
                            Text("\(a.score) · \(a.label.title)").font(.subheadline.weight(.semibold)).monospacedDigit()
                        } else {
                            Text("\(section.metrics.count) measured").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            if !detailed.contactLines.isEmpty {
                DisclosureGroup("Contact and tracking quality", isExpanded: binding("contact")) {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(detailed.contactLines, id: \.self) { Text($0).font(.caption) }
                    }
                    .padding(.top, 4)
                }
                .font(.headline)
            }
            if !detailed.insights.isEmpty {
                DisclosureGroup("Coaching evidence", isExpanded: binding("coaching")) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(detailed.insights) { i in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(i.title).font(.subheadline.weight(.semibold))
                                Text(i.insightClass.title).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                                Text(i.observed).font(.caption)
                                Text(i.interpretation).font(.caption).foregroundStyle(.secondary)
                                if let cue = i.cue { Text("Cue: " + cue).font(.caption) }
                                Text("Watch: \(i.monitorMetricName)").font(.caption2)
                                Text(i.eligibility).font(.caption2).foregroundStyle(.secondary)
                            }
                            .accessibilityElement(children: .combine)
                        }
                    }
                    .padding(.top, 4)
                }
                .font(.headline)
            }
            if let c = detailed.consistencyReport, !c.metrics.isEmpty {
                DisclosureGroup("Consistency", isExpanded: binding("consistency")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(c.summaryText).font(.caption.weight(.semibold))
                        ForEach(c.metrics) { m in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(m.name).font(.caption.weight(.semibold))
                                if let spread = m.spreadText { Text("\(spread) · \(m.level?.title ?? "")").font(.caption2) }
                                if let usual = m.usualText { Text(usual).font(.caption2).foregroundStyle(.secondary) }
                                if m.current != nil { Text(m.interpretation).font(.caption2) }
                                Text("Measurement precision ±\(DisplayFormat.metricValue(m.precision.resolution, unit: m.unit)); differences under \(DisplayFormat.metricValue(m.precision.meaningfulChange, unit: m.unit)) are never called out. \(m.precision.source)")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                            .accessibilityElement(children: .combine)
                        }
                        Text("A repeatable value isn't necessarily good technique, and a value away from your usual isn't necessarily worse.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    .padding(.top, 4)
                }
                .font(.headline)
            }
            DisclosureGroup("Your history", isExpanded: binding("history")) {
                historyContent.padding(.top, 4)
            }
            .font(.headline)
            DisclosureGroup("How scores work", isExpanded: binding("method")) {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(detailed.methodology, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                }
                .padding(.top, 4)
            }
            .font(.headline)
        }
    }

    private func phaseContent(_ section: DetailedAnalysisReport.PhaseSection) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            if let a = section.area {
                AreaRowView(row: a)
                Text("Measurement quality: \(a.quality.title)").font(.caption2).foregroundStyle(.secondary)
            } else if let note = section.areaNote {
                Text("Not rated: \(note)").font(.caption).foregroundStyle(.secondary)
            }
            ForEach(section.metrics) { m in
                VStack(alignment: .leading, spacing: 0) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(m.name).font(.caption)
                        Spacer(minLength: 8)
                        Text(m.valueText).font(.caption.weight(.semibold)).monospacedDigit()
                    }
                    Text("\(m.provenanceText) · quality \(PerformanceReport.Quality(confidence: m.confidence).title)")
                        .font(.caption2).foregroundStyle(.secondary)
                    Text(m.explanation).font(.caption2).foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(section.unavailable) { item in
                HStack(alignment: .firstTextBaseline) {
                    Text(item.name).font(.caption).foregroundStyle(.secondary)
                    Spacer(minLength: 8)
                    Text(item.reason).font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                }
                .accessibilityElement(children: .combine)
            }
        }
        .padding(.top, 4)
    }

    @ViewBuilder
    private var historyContent: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let h = detailed.history, h.hasHistory {
                Text(h.standing.text).font(.caption.weight(.semibold))
                Text("Previous \(DisplayFormat.score(h.previous)) · best \(DisplayFormat.score(h.best)) · recent average \(DisplayFormat.score(h.recentAverage))")
                    .font(.caption)
                if let t = h.trend { Text("Trend: \(t.text)").font(.caption) }
                if let spread = h.spread { Text("Spread over recent kicks: ±\(DisplayFormat.score(spread)) points").font(.caption) }
            } else {
                Text(detailed.history?.message ?? PersonalRanking.historyWillPopulate).font(.caption).foregroundStyle(.secondary)
            }
            if let c = detailed.consistency {
                if let s = c.session { Text(s.text).font(.caption) }
                if let i = c.improving { Text(i.text).font(.caption.weight(.semibold)) }
                ForEach(c.metrics) { m in
                    Text("\(m.name): \(DisplayFormat.number(m.mean, digits: 2)) ± \(DisplayFormat.number(m.spread, digits: 2)) over \(m.count) kicks")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                if let reason = c.currentExcludedReason {
                    Text("This kick isn't added to your measurement history: \(reason).").font(.caption2).foregroundStyle(.secondary)
                }
                if !c.excluded.isEmpty {
                    Text("Left out of measurement history: " + c.excluded.sorted { $0.key < $1.key }.map { "\($0.value) (\($0.key))" }.joined(separator: ", "))
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            if let note = detailed.history?.exclusionNote { Text(note).font(.caption2).foregroundStyle(.secondary) }
        }
    }
}
