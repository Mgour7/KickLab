import SwiftUI

// Build 16 — Performance Report 2.0.
// Level 1 (Quick Report): the default results screen — big score, five compact areas,
// strengths, what needs work, next training focus. Level 2 (Detailed Analysis) is pushed
// by an explicit action; level 3 (Developer Diagnostics) stays behind the diagnostics
// setting. Scores always carry a word as well as a color.

extension PerformanceReport.Label {
    var color: Color {
        switch self {
        case .excellent: .green
        case .good: .mint
        case .developing: .orange
        case .needsWork: .red
        }
    }
}

extension PerformanceReport.Quality {
    var symbol: String {
        switch self {
        case .good: "circle.fill"
        case .fair: "circle.lefthalf.filled"
        case .limited: "circle.dotted"
        case .unavailable: "circle.slash"
        }
    }
}

/// Level 1: the Quick Report.
struct QuickReportView: View {
    let report: PerformanceReport
    /// The big score scales with Dynamic Type.
    @ScaledMetric(relativeTo: .largeTitle) private var scoreSize: CGFloat = 72

    init(report: PerformanceReport) {
        self.report = report
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            kickPerformance
            rankings
            if !report.strengths.isEmpty { strengths }
            if !report.issues.isEmpty { needsWork }
            nextFocus
            if let outcome = report.outcomeText {
                HStack {
                    Text(PerformanceReport.outcomeLabel).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Text(outcome).font(.subheadline.weight(.semibold))
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    // 1. Kick Performance
    private var kickPerformance: some View {
        let h = report.headline
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Text(h.kickTypeText).font(.subheadline.weight(.semibold))
                Text("·").foregroundStyle(.secondary)
                Text(h.viewText).font(.subheadline).foregroundStyle(.secondary)
                Spacer()
                if h.isUserAssisted {
                    Text("User-assisted").font(.caption.weight(.semibold))
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Capsule().fill(Color.orange.opacity(0.2)))
                }
            }
            if let score = h.score, let label = h.label {
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    Text("\(score)")
                        .font(.system(size: scoreSize, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(label.color)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(label.title).font(.title3.weight(.bold))
                        Text("Technique score · provisional").font(.caption).foregroundStyle(.secondary)
                    }
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Overall technique score \(score) out of 100, \(label.title). Provisional.")
            } else {
                VStack(alignment: .leading, spacing: 4) {
                    Text(h.unavailableTitle ?? "Overall Score Unavailable").font(.title3.weight(.bold))
                    if let d = h.unavailableDetail { Text(d).font(.subheadline).foregroundStyle(.secondary) }
                }
                .accessibilityElement(children: .combine)
            }
            HStack(spacing: 12) {
                Label("Analysis quality: \(h.quality.title)", systemImage: h.quality.symbol)
                if let best = report.strongest { Label("Best: \(best.title)", systemImage: "arrow.up.circle") }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            if let history = report.history { historyStrip(history) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 20).fill(Color.secondary.opacity(0.10)))
    }

    private func historyStrip(_ h: PersonalRanking.History) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            if h.hasHistory {
                HStack(spacing: 14) {
                    stat("Previous", h.previous.map { DisplayFormat.score($0) })
                    stat("Best", h.best.map { DisplayFormat.score($0) })
                    stat("Recent avg", h.recentAverage.map { DisplayFormat.score($0) })
                    stat("Change", h.change.map { ($0 >= 0 ? "+" : "") + DisplayFormat.score($0) })
                    if let t = h.trend { stat("Trend", t.text) }
                }
                Text(h.isPersonalBest ? "Personal best · \(h.standing.text)" : h.standing.text)
                    .font(.caption.weight(.semibold))
            } else {
                Text(h.message ?? PersonalRanking.historyWillPopulate).font(.caption).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .combine)
    }

    private func stat(_ title: String, _ value: String?) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(value ?? "—").font(.subheadline.weight(.bold)).monospacedDigit()
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
    }

    // 2. Performance Rankings
    private var rankings: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Performance Rankings").font(.headline)
            ForEach(report.categories) { row in
                CategoryRankRow(row: row)
            }
        }
    }

    // 3. What You Did Well
    private var strengths: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("What You Did Well").font(.headline)
            ForEach(report.strengths) { s in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(s.title).font(.subheadline.weight(.semibold))
                        Text(s.detail).font(.caption).foregroundStyle(.secondary)
                    }
                } icon: {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    // 4. What Needs Work
    private var needsWork: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("What Needs Work").font(.headline)
            ForEach(report.issues) { issue in
                VStack(alignment: .leading, spacing: 3) {
                    Text(issue.title).font(.subheadline.weight(.semibold))
                    Text(issue.observed).font(.caption).foregroundStyle(.secondary)
                    Label(issue.cue, systemImage: "quote.bubble").font(.caption.weight(.semibold))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color.orange.opacity(0.10)))
                .accessibilityElement(children: .combine)
            }
        }
    }

    // 5. Next Training Focus
    private var nextFocus: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Next Training Focus").font(.headline)
            if !report.recordingAdvice.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    Label("Record a clearer clip first", systemImage: "video.badge.checkmark").font(.subheadline.weight(.semibold))
                    ForEach(report.recordingAdvice, id: \.self) { Text("• " + $0).font(.caption) }
                }
                .accessibilityElement(children: .combine)
            } else if report.focus.isEmpty {
                Text("Nothing measured reliably enough to pick a drill this time.").font(.caption).foregroundStyle(.secondary)
            } else {
                ForEach(report.focus) { f in
                    VStack(alignment: .leading, spacing: 3) {
                        Label(f.title, systemImage: "figure.american.football").font(.subheadline.weight(.semibold))
                        Text("Practice: " + f.practice).font(.caption)
                        Text("Why: " + f.why).font(.caption).foregroundStyle(.secondary)
                        Text("Watch: " + f.measurement).font(.caption.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.blue.opacity(0.10)))
                    .accessibilityElement(children: .combine)
                }
            }
        }
    }
}

/// One compact area row: name, score + word, quality dot, personal rank.
struct CategoryRankRow: View {
    let row: PerformanceReport.CategoryRow

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(row.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text(row.score == nil ? (row.notRatedReason ?? "Not rated") : row.standing.text)
                    .font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 8)
            if let score = row.score, let label = row.label {
                VStack(alignment: .trailing, spacing: 0) {
                    Text("\(score)").font(.title3.weight(.bold)).monospacedDigit().foregroundStyle(label.color)
                    Text(label.title).font(.caption2.weight(.semibold))
                }
            } else {
                Text("Not rated").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            }
            Image(systemName: row.quality.symbol)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)
        }
        .padding(.vertical, 6)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(row.accessibilityText)
    }
}

/// Level 2: the Detailed Analysis breakdown shown at the top of the detailed screen.
struct DetailedBreakdownView: View {
    let detailed: DetailedAnalysisReport

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Measurements by area").font(.headline)
            ForEach(detailed.areas) { area in
                VStack(alignment: .leading, spacing: 4) {
                    CategoryRankRow(row: area.row)
                    Text("Measurement quality: \(area.row.quality.title)").font(.caption2).foregroundStyle(.secondary)
                    ForEach(area.metrics) { m in
                        HStack {
                            Text(m.name).font(.caption)
                            Spacer()
                            Text(m.valueText).font(.caption.weight(.semibold)).monospacedDigit()
                        }
                        .accessibilityElement(children: .combine)
                    }
                    ForEach(area.unmeasured, id: \.self) { name in
                        HStack {
                            Text(name).font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            Text("Not rated").font(.caption).foregroundStyle(.secondary)
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color.secondary.opacity(0.08)))
            }
            if !detailed.timing.isEmpty {
                Text("Timing").font(.headline)
                ForEach(detailed.timing, id: \.self) { Text($0).font(.caption) }
            }
            if let h = detailed.history, let note = h.exclusionNote {
                Text(note).font(.caption).foregroundStyle(.secondary)
            }
            Text(PerformanceReport.Label.criteria).font(.caption2).foregroundStyle(.secondary)
        }
    }
}
