import SwiftUI

// Athlete Report 3.0 (Build 18).
// Quick Report: the kick's result first, then a compact summary that adapts to the
// evidence, rated areas, useful measurements, ≤ 2 strengths, ≤ 2 improvements and ONE
// training priority; unavailable areas collapsed with reasons on demand. Detailed Analysis
// (pushed) is organized by phase in expandable sections. Developer Diagnostics stay
// behind the diagnostics setting. Scores always carry a word as well as a color.

extension PerformanceReport.Label {
    var color: Color {
        switch self {
        case .excellent: .green
        case .good: .mint
        case .developing: .orange
        case .needsWork: .red
        }
    }
}

extension PerformanceReport.Quality {
    var symbol: String {
        switch self {
        case .good: "circle.fill"
        case .fair: "circle.lefthalf.filled"
        case .limited: "circle.dotted"
        case .unavailable: "circle.slash"
        }
    }
}

/// A compact rounded card used throughout the report.
private struct ReportCard<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 8) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.secondary.opacity(0.09)))
    }
}

/// Level 1: the Quick Report.
struct QuickReportView: View {
    let report: PerformanceReport
    @State private var showsUnavailable = false
    /// The headline score scales with Dynamic Type.
    @ScaledMetric(relativeTo: .largeTitle) private var scoreSize: CGFloat = 52

    init(report: PerformanceReport) {
        self.report = report
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            resultCard
            summaryCard
            if !report.areas.isEmpty { areasCard }
            if !report.measurements.isEmpty { measurementsCard }
            if !report.strengths.isEmpty || !report.improvements.isEmpty || report.noCorrectionText != nil { coachingCard }
            if let focus = report.focus { focusCard(focus) }
            if !report.unavailable.isEmpty { unavailableGroup }
        }
    }

    // Kick result (entered by the athlete) — first.
    private var resultCard: some View {
        let h = report.header
        return ReportCard {
            HStack(spacing: 6) {
                Text(h.kickTypeText).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                Spacer(minLength: 4)
                Text(h.state.title).font(.caption.weight(.semibold))
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(Capsule().fill((h.state == .userAssisted ? Color.orange : Color.secondary).opacity(0.18)))
            }
            Text(h.outcomeText)
                .font(h.outcomeRecorded ? .title2.weight(.bold) : .headline)
                .foregroundStyle(h.outcomeRecorded ? Color.primary : Color.secondary)
            HStack(spacing: 6) {
                if h.outcomeRecorded { Text(PerformanceReport.outcomeLabel) }
                Text(h.viewText)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    // Performance summary.
    private var summaryCard: some View {
        ReportCard {
            switch report.summary {
            case .technique(let score, let label, let quality):
                HStack(alignment: .center, spacing: 12) {
                    Text("\(score)")
                        .font(.system(size: scoreSize, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(label.color)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(label.title).font(.title3.weight(.bold))
                        Text("Technique score · provisional").font(.caption).foregroundStyle(.secondary)
                        Label("Analysis quality: \(quality.title)", systemImage: quality.symbol).font(.caption).foregroundStyle(.secondary)
                    }
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Technique score \(score) out of 100, \(label.title), provisional. Analysis quality \(quality.title).")
            case .limited(let detail):
                Text("Limited Technique Analysis").font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            case .incomplete(let title, let detail):
                Text(title).font(.headline)
                if let detail { Text(detail).font(.caption).foregroundStyle(.secondary) }
            }
            if let comparison = report.comparisonText {
                Label(comparison, systemImage: "chart.line.uptrend.xyaxis").font(.caption.weight(.semibold))
            }
        }
    }

    private var areasCard: some View {
        ReportCard {
            Text("Rated areas").font(.headline)
            ForEach(report.areas) { AreaRowView(row: $0) }
        }
    }

    private var measurementsCard: some View {
        ReportCard {
            Text("Measured").font(.headline)
            ForEach(report.measurements) { m in
                VStack(alignment: .leading, spacing: 1) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(m.name).font(.subheadline).lineLimit(2)
                        Spacer(minLength: 8)
                        Text(m.valueText).font(.subheadline.weight(.semibold)).monospacedDigit()
                    }
                    if let personal = m.personalText { Text(personal).font(.caption2).foregroundStyle(.secondary) }
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    private var coachingCard: some View {
        ReportCard {
            ForEach(report.strengths) { s in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(s.title).font(.subheadline.weight(.semibold))
                        Text(s.reason).font(.caption).foregroundStyle(.secondary)
                    }
                } icon: {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(report.improvements) { i in
                Label {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(i.title + (i.insightClass == .provisionalObservation ? " (provisional)" : "")).font(.subheadline.weight(.semibold))
                        Text(i.observed).font(.caption).foregroundStyle(.secondary)
                        Text(i.cue).font(.caption.weight(.semibold))
                    }
                } icon: {
                    Image(systemName: "arrow.up.forward.circle.fill").foregroundStyle(.orange)
                }
                .accessibilityElement(children: .combine)
            }
            if let none = report.noCorrectionText {
                Text(none).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func focusCard(_ focus: PerformanceReport.Focus) -> some View {
        ReportCard {
            Text("Next training focus").font(.headline)
            switch focus {
            case .practice(let title, let cue, let monitor):
                Text(title).font(.subheadline.weight(.semibold))
                Text(cue).font(.caption)
                Text("Watch next time: \(monitor)").font(.caption).foregroundStyle(.secondary)
            case .recording(let sentence):
                Label(sentence, systemImage: "video").font(.subheadline)
            }
        }
        .accessibilityElement(children: .combine)
    }

    private var unavailableGroup: some View {
        DisclosureGroup("Measurements not available (\(report.unavailable.count))", isExpanded: $showsUnavailable) {
            VStack(alignment: .leading, spacing: 6) {
                ForEach(report.unavailable) { u in
                    VStack(alignment: .leading, spacing: 0) {
                        Text(u.title).font(.caption.weight(.semibold))
                        Text(u.reason).font(.caption).foregroundStyle(.secondary)
                    }
                    .accessibilityElement(children: .combine)
                }
            }
            .padding(.top, 4)
        }
        .font(.subheadline)
        .padding(.horizontal, 4)
    }
}

/// One rated area: name, score + word, a clear limited-confidence marker, and personal rank.
struct AreaRowView: View {
    let row: PerformanceReport.AreaRow

    var body: some View {
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(row.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                if row.isLimitedConfidence {
                    Label("Limited confidence", systemImage: "exclamationmark.circle").font(.caption2.weight(.semibold)).foregroundStyle(.orange)
                } else if row.standing.rank != nil {
                    Text(row.standing.text).font(.caption2).foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 0) {
                Text("\(row.score)").font(.title3.weight(.bold)).monospacedDigit()
                    .foregroundStyle(row.isLimitedConfidence ? Color.secondary : row.label.color)
                Text(row.label.title).font(.caption2.weight(.semibold))
            }
            .opacity(row.isLimitedConfidence ? 0.7 : 1)
        }
        .padding(.vertical, 2)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(row.accessibilityText)
    }
}

/// Level 2: Detailed Analysis, by phase, in expandable sections.
struct DetailedBreakdownView: View {
    let detailed: DetailedAnalysisReport
    @State private var expanded: Set<String> = []

    private func binding(_ id: String) -> Binding<Bool> {
        Binding(get: { expanded.contains(id) }, set: { if $0 { expanded.insert(id) } else { expanded.remove(id) } })
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(detailed.phases) { section in
                DisclosureGroup(isExpanded: binding(section.id)) {
                    phaseContent(section)
                } label: {
                    HStack {
                        Text(section.title).font(.headline)
                        Spacer()
                        if let a = section.area {
                            Text("\(a.score) · \(a.label.title)").font(.subheadline.weight(.semibold)).monospacedDigit()
                        } else {
                            Text("\(section.metrics.count) measured").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            if !detailed.contactLines.isEmpty {
                DisclosureGroup("Contact and tracking quality", isExpanded: binding("contact")) {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(detailed.contactLines, id: \.self) { Text($0).font(.caption) }
                    }
                    .padding(.top, 4)
                }
                .font(.headline)
            }
            if !detailed.insights.isEmpty {
                DisclosureGroup("Coaching evidence", isExpanded: binding("coaching")) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(detailed.insights) { i in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(i.title).font(.subheadline.weight(.semibold))
                                Text(i.insightClass.title).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                                Text(i.observed).font(.caption)
                                Text(i.interpretation).font(.caption).foregroundStyle(.secondary)
                                if let cue = i.cue { Text("Cue: " + cue).font(.caption) }
                                Text("Watch: \(i.monitorMetricName)").font(.caption2)
                                Text(i.eligibility).font(.caption2).foregroundStyle(.secondary)
                            }
                            .accessibilityElement(children: .combine)
                        }
                    }
                    .padding(.top, 4)
                }
                .font(.headline)
            }
            DisclosureGroup("Your history", isExpanded: binding("history")) {
                historyContent.padding(.top, 4)
            }
            .font(.headline)
            DisclosureGroup("How scores work", isExpanded: binding("method")) {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(detailed.methodology, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                }
                .padding(.top, 4)
            }
            .font(.headline)
        }
    }

    private func phaseContent(_ section: DetailedAnalysisReport.PhaseSection) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            if let a = section.area {
                AreaRowView(row: a)
                Text("Measurement quality: \(a.quality.title)").font(.caption2).foregroundStyle(.secondary)
            } else if let note = section.areaNote {
                Text("Not rated: \(note)").font(.caption).foregroundStyle(.secondary)
            }
            ForEach(section.metrics) { m in
                VStack(alignment: .leading, spacing: 0) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(m.name).font(.caption)
                        Spacer(minLength: 8)
                        Text(m.valueText).font(.caption.weight(.semibold)).monospacedDigit()
                    }
                    Text("\(m.provenanceText) · quality \(PerformanceReport.Quality(confidence: m.confidence).title)")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
            ForEach(section.unavailable) { item in
                HStack(alignment: .firstTextBaseline) {
                    Text(item.name).font(.caption).foregroundStyle(.secondary)
                    Spacer(minLength: 8)
                    Text(item.reason).font(.caption2).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                }
                .accessibilityElement(children: .combine)
            }
        }
        .padding(.top, 4)
    }

    @ViewBuilder
    private var historyContent: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let h = detailed.history, h.hasHistory {
                Text(h.standing.text).font(.caption.weight(.semibold))
                Text("Previous \(DisplayFormat.score(h.previous)) · best \(DisplayFormat.score(h.best)) · recent average \(DisplayFormat.score(h.recentAverage))")
                    .font(.caption)
                if let t = h.trend { Text("Trend: \(t.text)").font(.caption) }
                if let spread = h.spread { Text("Spread over recent kicks: ±\(DisplayFormat.score(spread)) points").font(.caption) }
            } else {
                Text(detailed.history?.message ?? PersonalRanking.historyWillPopulate).font(.caption).foregroundStyle(.secondary)
            }
            if let c = detailed.consistency {
                if let s = c.session { Text(s.text).font(.caption) }
                if let i = c.improving { Text(i.text).font(.caption.weight(.semibold)) }
                ForEach(c.metrics) { m in
                    Text("\(m.name): \(DisplayFormat.number(m.mean, digits: 2)) ± \(DisplayFormat.number(m.spread, digits: 2)) over \(m.count) kicks")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            if let note = detailed.history?.exclusionNote { Text(note).font(.caption2).foregroundStyle(.secondary) }
        }
    }
}
