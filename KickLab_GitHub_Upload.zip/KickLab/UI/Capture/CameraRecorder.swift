import AVKit
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// Build 21 — the in-app camera (rear camera, AVCaptureMovieFileOutput).
///
/// Decisions come from the pure `CapturePolicy` types; this class only carries them out.
/// - The camera runs only while a recording screen is open; nothing records in the background.
/// - The movie is written in fragments every few seconds, so if KickLab is terminated the
///   file is readable up to the last fragment (the session is marked "recovered" at launch).
/// - "Saved" is reported only from AVFoundation's finished-recording callback with a usable
///   file — never when Stop is pressed.
/// - Interruptions (calls, another app using the camera), leaving the screen, critical
///   heat and running out of space all stop and FINALIZE the file.
/// - The microphone is used only when the athlete turned on "Record sound".
/// The capture objects, used ONLY on `queue` (Apple's session-queue pattern): configuring,
/// starting/stopping the session and starting/stopping a recording run there in order, so a
/// quick Close can never stop the camera before it started.
final class CaptureSessionBox: @unchecked Sendable {
    let session = AVCaptureSession()
    let movieOutput = AVCaptureMovieFileOutput()
    let queue = DispatchQueue(label: "com.kicklab.capture", qos: .userInitiated)

    func perform<T: Sendable>(_ work: @escaping @Sendable (CaptureSessionBox) -> T) async -> T {
        await withCheckedContinuation { continuation in
            queue.async { continuation.resume(returning: work(self)) }
        }
    }

    /// Configures the rear camera for `request` (with documented fallbacks). On `queue`.
    func configure(_ request: CaptureRequest) -> Result<CaptureSelection, CaptureFailure> {
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else { return .failure(.noCamera) }
        let formats = camera.formats.map(CameraRecorder.descriptor)
        guard let choice = CaptureConfigurationSelector.select(request, formats: formats) else { return .failure(.configurationFailed) }
        session.beginConfiguration()
        session.sessionPreset = .inputPriority
        for input in session.inputs { session.removeInput(input) }
        do {
            let input = try AVCaptureDeviceInput(device: camera)
            guard session.canAddInput(input) else { throw CaptureFailure.configurationFailed }
            session.addInput(input)
            if request.recordsAudio, let mic = AVCaptureDevice.default(for: .audio) {
                let audio = try AVCaptureDeviceInput(device: mic)
                if session.canAddInput(audio) { session.addInput(audio) }
            }
            if !session.outputs.contains(where: { $0 === movieOutput }) {
                guard session.canAddOutput(movieOutput) else { throw CaptureFailure.configurationFailed }
                session.addOutput(movieOutput)
            }
            // Fragments every 5 s: an interrupted file stays readable up to the last fragment.
            movieOutput.movieFragmentInterval = CMTime(seconds: 5, preferredTimescale: 600)
            try camera.lockForConfiguration()
            camera.activeFormat = camera.formats[choice.formatIndex]
            let duration = CMTime(value: 1, timescale: CMTimeScale(choice.framesPerSecond))
            camera.activeVideoMinFrameDuration = duration
            camera.activeVideoMaxFrameDuration = duration
            if camera.isFocusModeSupported(.continuousAutoFocus) { camera.focusMode = .continuousAutoFocus }
            if camera.isExposureModeSupported(.continuousAutoExposure) { camera.exposureMode = .continuousAutoExposure }
            camera.unlockForConfiguration()
            if let connection = movieOutput.connection(with: .video) {
                // Stabilization crops and shifts the picture; analysis wants fixed geometry.
                if connection.isVideoStabilizationSupported { connection.preferredVideoStabilizationMode = .off }
                if movieOutput.availableVideoCodecTypes.contains(.hevc) {
                    movieOutput.setOutputSettings([AVVideoCodecKey: AVVideoCodecType.hevc], for: connection)
                }
            } else {
                throw CaptureFailure.configurationFailed
            }
        } catch {
            session.commitConfiguration()
            return .failure(.configurationFailed)
        }
        session.commitConfiguration()
        // Never record at another rate than displayed.
        let applied = 1 / camera.activeVideoMinFrameDuration.seconds
        if CaptureConfigurationSelector.verify(choice, appliedFramesPerSecond: applied) != nil { return .failure(.frameRateMismatch) }
        if !session.isRunning { session.startRunning() }
        return session.isRunning ? .success(choice) : .failure(.configurationFailed)
    }
}

@MainActor
@Observable
final class CameraRecorder: NSObject {
    private(set) var state: CaptureState = .idle
    private(set) var warning: String?
    private(set) var elapsed: TimeInterval = 0
    private(set) var storage: CaptureStoragePolicy.Decision = .ok(minutes: .infinity)
    private(set) var previewRotationAngle: CGFloat = 90
    var request: CaptureRequest = .standard
    /// Called once a recording ends: file, why it ended, duration (nil when the file isn't
    /// usable), and whether it's usable. Callers show "saved" only when usable.
    @ObservationIgnored var onFinished: ((URL, CaptureStopReason, Double?, Bool) -> Void)?

    /// Created on first use, so a view re-render that builds a throwaway recorder doesn't
    /// create capture objects.
    @ObservationIgnored private var _box: CaptureSessionBox?
    var box: CaptureSessionBox {
        if let b = _box { return b }
        let b = CaptureSessionBox()
        _box = b
        return b
    }
    @ObservationIgnored private var rotation: AVCaptureDevice.RotationCoordinator?
    /// The rear camera, looked up on the main actor for the rotation coordinator.
    @ObservationIgnored private var device: AVCaptureDevice?
    @ObservationIgnored private weak var previewLayer: AVCaptureVideoPreviewLayer?
    @ObservationIgnored private var observers: [NSObjectProtocol] = []
    @ObservationIgnored private var timer: Timer?
    @ObservationIgnored private var housekeeping: Timer?
    @ObservationIgnored private var startedAt: Date?
    @ObservationIgnored private var pendingReason: CaptureStopReason = .userStopped
    @ObservationIgnored private var lastSelection: CaptureSelection?
    /// The screen went away while a file was still being written: release the camera once
    /// AVFoundation has finished the file (stopping the session earlier could cut it short).
    @ObservationIgnored private var shutDownWhenFinished = false
    /// Free space check (replaceable in tests / previews). A plain file-system query with
    /// no access to the recorder's state, so it is nonisolated and `@Sendable`.
    @ObservationIgnored var freeBytes: @Sendable () -> Int64? = CameraRecorder.availableBytes

    var selection: CaptureSelection? {
        switch state {
        case .ready(let s), .recording(let s, _), .finishing(let s, _): s
        case .interrupted(let s): s
        default: nil
        }
    }

    var isBusy: Bool {
        switch state {
        case .recording, .finishing: true
        default: false
        }
    }

    // MARK: Setup

    /// Asks for camera (and, only with sound on, microphone) access, then configures the
    /// rear camera and starts it. "Ready" only once the camera is actually running.
    func prepare() async {
        // Back on screen while a file was still finishing: keep the camera.
        shutDownWhenFinished = false
        guard !isBusy else { observe(); return }
        apply(.requestPermissions)
        guard await Self.requestAccess(.video) else { apply(.permissionDenied(.cameraPermissionDenied)); return }
        if request.recordsAudio, !(await Self.requestAccess(.audio)) { apply(.permissionDenied(.microphonePermissionDenied)); return }
        apply(.permissionsGranted)
        let req = request
        let result = await box.perform { $0.configure(req) }
        switch result {
        case .failure(let f):
            apply(.configurationFailed(f))
        case .success(let choice):
            // The rotation coordinator (main actor) gets its own reference to the same
            // system camera, rather than passing the device object across threads.
            device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
            warning = choice.fallbackReason
            lastSelection = choice
            makeRotationCoordinator()
            apply(.configured(choice))
            refreshStorage()
            observe()
        }
    }

    private static func requestAccess(_ type: AVMediaType) async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: type) {
        case .authorized: return true
        case .notDetermined: return await AVCaptureDevice.requestAccess(for: type)
        default: return false
        }
    }

    /// Keeps the preview and the recorded file upright whichever way the phone is turned
    /// (the app's screens stay portrait; a phone turned sideways records landscape).
    func attachPreview(_ layer: AVCaptureVideoPreviewLayer) {
        previewLayer = layer
        makeRotationCoordinator()
    }

    /// Needs both the configured camera and the preview layer, whichever comes last.
    private func makeRotationCoordinator() {
        guard let device, let layer = previewLayer else { return }
        if rotation?.device === device, rotation?.previewLayer === layer { return }
        let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: layer)
        rotation = coordinator
        previewRotationAngle = coordinator.videoRotationAngleForHorizonLevelPreview
    }

    func refreshPreviewRotation() {
        if let r = rotation { previewRotationAngle = r.videoRotationAngleForHorizonLevelPreview }
    }

    nonisolated static func descriptor(_ f: AVCaptureDevice.Format) -> CaptureFormatDescriptor {
        let d = CMVideoFormatDescriptionGetDimensions(f.formatDescription)
        let ranges = f.videoSupportedFrameRateRanges
        return CaptureFormatDescriptor(width: Int(d.width), height: Int(d.height),
                                       maxFrameRate: ranges.map(\.maxFrameRate).max() ?? 0,
                                       minFrameRate: ranges.map(\.minFrameRate).min() ?? 1,
                                       isBinned: f.isVideoBinned)
    }

    // MARK: Recording

    /// Starts recording into `url` (inside KickLab's own storage).
    func startRecording(to url: URL) {
        guard state.canStartRecording else { return }
        refreshStorage()
        if case .stop = CaptureStoragePolicy.decide(freeBytes: freeBytes(), resolution: selection?.resolution ?? request.resolution,
                                                    fps: selection?.framesPerSecond ?? request.framesPerSecond, recording: false) {
            warning = CaptureFailure.insufficientStorage.message
            return
        }
        makeRotationCoordinator()
        let angle = rotation?.videoRotationAngleForHorizonLevelCapture
        pendingReason = .userStopped
        startedAt = Date()
        elapsed = 0
        apply(.startRequested(at: startedAt!))
        let box = self.box
        box.queue.async { [self] in
            guard box.session.isRunning, let connection = box.movieOutput.connection(with: .video) else {
                Task { @MainActor in self.finished(url: url, usable: false, duration: nil) }
                return
            }
            if let angle, connection.isVideoRotationAngleSupported(angle) { connection.videoRotationAngle = angle }
            box.movieOutput.startRecording(to: url, recordingDelegate: self)
        }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
    }

    func stopRecording(_ reason: CaptureStopReason = .userStopped) {
        guard state.isRecording else { return }
        pendingReason = reason
        apply(.stopRequested(reason))
        let box = self.box
        box.queue.async { box.movieOutput.stopRecording() }
    }

    /// Seconds of video in the file so far (from its first frame) — the time base for
    /// "Mark Kick" and settings changes, so marks match the recording's own timeline.
    func recordedSeconds() -> Double {
        guard state.isRecording, let box = _box else { return elapsed }
        let t = box.queue.sync { box.movieOutput.recordedDuration.seconds }
        return t.isFinite ? t : elapsed
    }

    private func tick() {
        if state.isRecording { elapsed = recordedSeconds() }
        refreshStorage()
        if case .stop = storage, state.isRecording { stopRecording(.storage) }
    }

    private func refreshStorage() {
        storage = CaptureStoragePolicy.decide(freeBytes: freeBytes(), resolution: selection?.resolution ?? request.resolution,
                                              fps: selection?.framesPerSecond ?? request.framesPerSecond, recording: state.isRecording)
    }

    /// Free space on the app's volume ("important usage" capacity). Reads only the file
    /// system — no recorder state — so it is `nonisolated`: a static method of a
    /// `@MainActor` class is otherwise main-actor-isolated, and its function value can't be
    /// stored as a plain `() -> Int64?` (the Build 21 Xcode error). Same query as the
    /// import path's `DeviceStorage`, which already runs on device.
    nonisolated static func availableBytes() -> Int64? {
        DeviceStorage.availableBytes(at: URL(fileURLWithPath: NSHomeDirectory()))
    }

    // MARK: Lifecycle

    private func observe() {
        guard observers.isEmpty else { return }
        // Housekeeping once a second while the camera screen is open: phone orientation
        // for the preview, and free space.
        housekeeping = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                self?.refreshPreviewRotation()
                if self?.state.isRecording == false { self?.refreshStorage() }
            }
        }
        let center = NotificationCenter.default
        let session = box.session
        observers.append(center.addObserver(forName: AVCaptureSession.wasInterruptedNotification, object: session, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                if self.state.isRecording { self.stopRecording(.interruption) } else { self.apply(.interruptionBegan) }
            }
        })
        observers.append(center.addObserver(forName: AVCaptureSession.interruptionEndedNotification, object: session, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.apply(.interruptionEnded) }
        })
        observers.append(center.addObserver(forName: AVCaptureSession.runtimeErrorNotification, object: session, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                if self.state.isRecording { self.stopRecording(.systemError) }
                self.warning = CaptureStopReason.systemError.message
            }
        })
        #if !os(Linux)
        observers.append(center.addObserver(forName: ProcessInfo.thermalStateDidChangeNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.handleThermal() }
        })
        #endif
        handleThermal()
    }

    private static var thermalLevel: DeviceThermalLevel {
        #if os(Linux)
        return .nominal
        #else
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: return .nominal
        case .fair: return .fair
        case .serious: return .serious
        case .critical: return .critical
        @unknown default: return .serious
        }
        #endif
    }

    private func handleThermal() {
        let level = Self.thermalLevel
        switch CaptureThermalPolicy.action(level, recording: state.isRecording) {
        case .none: break
        case .warn(let text): warning = text
        case .stopAndSave: stopRecording(.thermal)
        }
    }

    /// The screen is going away: finish any recording cleanly, then release the camera
    /// (after the file is finished, if one is being written).
    func shutDown(reason: CaptureStopReason = .backgrounded) {
        if state.isRecording { stopRecording(reason) }
        housekeeping?.invalidate()
        housekeeping = nil
        for o in observers { NotificationCenter.default.removeObserver(o) }
        observers.removeAll()
        if isBusy {
            shutDownWhenFinished = true
        } else {
            releaseCamera()
        }
    }

    private func releaseCamera() {
        timer?.invalidate()
        timer = nil
        onFinished = nil
        guard let box = _box else { return }
        box.queue.async { if box.session.isRunning { box.session.stopRunning() } }
    }

    private func apply(_ event: CaptureEvent) {
        state = CaptureStateMachine.reduce(state, event)
    }

    fileprivate func finished(url: URL, usable: Bool, duration: Double?) {
        timer?.invalidate()
        timer = nil
        let reason = pendingReason
        apply(.fileFinished(url: url, usable: usable, duration: duration))
        if case .saved(_, let r, _) = state, let message = r.message { warning = message }
        if !usable { warning = CaptureFailure.writeFailed.message }
        onFinished?(url, usable ? reason : .systemError, usable ? duration : nil, usable)
        if shutDownWhenFinished {
            shutDownWhenFinished = false
            releaseCamera()
        }
    }

    /// Back to "ready" for another recording (same configuration), after a saved file or
    /// one that couldn't be finished.
    func readyForNextRecording() {
        guard let s = lastSelection else { return }
        switch state {
        case .saved, .failed(.writeFailed): apply(.configured(s))
        default: break
        }
    }
}

extension CameraRecorder: AVCaptureFileOutputRecordingDelegate {
    nonisolated func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        // A recording interrupted by a call, the background or a full disk is still a
        // usable file when AVFoundation says it finished successfully.
        let usable = error == nil || ((error as NSError?)?.userInfo[AVErrorRecordingSuccessfullyFinishedKey] as? Bool ?? false)
        let duration = output.recordedDuration.seconds
        // Strong self: the result must be delivered even if the screen has just closed.
        Task { @MainActor in
            self.finished(url: outputFileURL, usable: usable, duration: duration.isFinite ? duration : nil)
        }
    }
}

/// The live camera picture (aspect-fit, so what's shown is what's recorded).
struct CameraPreview: UIViewRepresentable {
    let recorder: CameraRecorder

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var previewLayer: AVCaptureVideoPreviewLayer? { layer as? AVCaptureVideoPreviewLayer }
    }

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.backgroundColor = .black
        view.previewLayer?.session = recorder.box.session
        view.previewLayer?.videoGravity = .resizeAspect
        if let layer = view.previewLayer { recorder.attachPreview(layer) }
        return view
    }

    func updateUIView(_ view: PreviewView, context: Context) {
        if let connection = view.previewLayer?.connection, connection.isVideoRotationAngleSupported(recorder.previewRotationAngle) {
            connection.videoRotationAngle = recorder.previewRotationAngle
        }
    }
}
