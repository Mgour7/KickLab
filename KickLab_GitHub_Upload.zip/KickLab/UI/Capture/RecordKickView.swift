import AVKit
import Photos
import SwiftUI

/// Build 21 — "Record Single Kick": the in-app camera for one kick. The recording is saved
/// into KickLab (never uploaded), a Kick is created through the normal workflow, and the
/// existing analysis runs. Saving a copy to Photos is optional and asks for add-only access.
struct RecordKickView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @State private var recorder = CameraRecorder()
    @State private var details = SessionKickDetails()
    @State private var savedURL: URL?
    @State private var saveToPhotos = false
    @State private var working = false
    @State private var problem: String?
    @State private var showingSettings = false
    @State private var confirmingDiscard = false
    /// A recording left in KickLab's capture folder by an earlier visit that ended before
    /// the kick was created (app closed, phone restarted). Offered back, never auto-deleted.
    @State private var leftover: URL?
    /// Called with the new kick's ID once it exists (the caller opens its analysis).
    let onKickCreated: (UUID) -> Void

    init(onKickCreated: @escaping (UUID) -> Void) {
        self.onKickCreated = onKickCreated
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CameraPreview(recorder: recorder).ignoresSafeArea()
            VStack(spacing: 10) {
                topBar
                Spacer()
                if let warning = recorder.warning { banner(warning) }
                if let problem { banner(problem) }
                if let leftover, savedURL == nil, !recorder.state.isRecording { leftoverBar(leftover) }
                bottomBar
            }
            .padding()
        }
        .task {
            recorder.request = CaptureSettingsStore.load()
            recorder.onFinished = { url, _, _, usable in
                if usable {
                    savedURL = url
                } else {
                    problem = "The recording couldn't be finished, so nothing was saved. You can record again."
                    recorder.readyForNextRecording()
                }
            }
            leftover = CaptureFiles.leftoverRecordings().first
            await recorder.prepare()
        }
        .onChange(of: scenePhase) { _, phase in
            // Only when KickLab really leaves the screen (Control Center or a Siri prompt
            // makes it "inactive" without stopping the camera).
            if phase == .background, recorder.state.isRecording { recorder.stopRecording(.backgrounded) }
        }
        .onChange(of: recorder.state.isRecording) { _, recording in IdleTimer.setDisabled(recording) }
        .onDisappear {
            recorder.shutDown()
            IdleTimer.setDisabled(false)
        }
        .sheet(isPresented: $showingSettings) {
            CaptureSettingsSheet(request: $recorder.request, details: $details, showsDistance: true) {
                CaptureSettingsStore.save(recorder.request)
                Task { await recorder.prepare() }
            }
        }
        .confirmationDialog("Discard this recording?", isPresented: $confirmingDiscard, titleVisibility: .visible) {
            Button("Discard Recording", role: .destructive) {
                if let savedURL { try? FileManager.default.removeItem(at: savedURL) }
                dismiss()
            }
            Button("Keep Recording", role: .cancel) {}
        } message: {
            Text("It hasn't been added to KickLab yet.")
        }
        .statusBarHidden()
    }

    private func leftoverBar(_ url: URL) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("A recording from \(CaptureFiles.dateText(url)) wasn't added to KickLab.").font(.caption).foregroundStyle(.white)
            HStack {
                Button("Discard", role: .destructive) {
                    try? FileManager.default.removeItem(at: url)
                    leftover = CaptureFiles.leftoverRecordings().first
                }
                .buttonStyle(.bordered)
                Spacer()
                Button("Use It") { savedURL = url; leftover = nil; problem = nil }
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.black.opacity(0.6)))
    }

    private var topBar: some View {
        HStack {
            Button("Close") {
                if savedURL != nil { confirmingDiscard = true } else { dismiss() }
            }
            .disabled(recorder.isBusy || working)
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(recorder.selection?.title ?? recorder.request.title).font(.caption.weight(.semibold))
                Text(CaptureStoragePolicy.text(recorder.storage, request: recorder.request)).font(.caption2)
            }
            Button { showingSettings = true } label: { Image(systemName: "gearshape") }
                .accessibilityLabel("Camera and kick settings")
                .disabled(recorder.state.isRecording || savedURL != nil)
        }
        .foregroundStyle(.white)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.black.opacity(0.5)))
    }

    @ViewBuilder
    private var bottomBar: some View {
        if let url = savedURL {
            VStack(spacing: 10) {
                Text("Recording saved\(durationText)").font(.headline).foregroundStyle(.white)
                Toggle("Also save a copy to Photos", isOn: $saveToPhotos).foregroundStyle(.white)
                HStack {
                    Button("Retake") {
                        try? FileManager.default.removeItem(at: url)
                        savedURL = nil
                        problem = nil
                        recorder.readyForNextRecording()
                    }
                    .buttonStyle(.bordered)
                    Spacer()
                    Button(working ? "Saving…" : "Use Video & Analyze") { Task { await use(url) } }
                        .buttonStyle(.borderedProminent)
                        .disabled(working)
                }
            }
            .padding(12)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.6)))
        } else {
            VStack(spacing: 8) {
                Text(stateText).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                Button {
                    if recorder.state.isRecording { recorder.stopRecording() } else { recorder.startRecording(to: CaptureFiles.newSingleKickURL()) }
                } label: {
                    Circle()
                        .fill(recorder.state.isRecording ? Color.red : Color.white)
                        .frame(width: 72, height: 72)
                        .overlay(Circle().stroke(Color.white, lineWidth: 4).frame(width: 84, height: 84))
                }
                .disabled(!(recorder.state.canStartRecording || recorder.state.isRecording))
                .accessibilityLabel(recorder.state.isRecording ? "Stop recording" : "Start recording")
                Text("Turn the phone sideways on a tripod for landscape video (recommended).").font(.caption2).foregroundStyle(.white.opacity(0.8))
            }
        }
    }

    private var durationText: String {
        if case .saved(_, _, let d?) = recorder.state { return String(format: " · %.1f s", d) }
        return ""
    }

    private var stateText: String {
        switch recorder.state {
        case .recording: CaptureFormat.elapsed(recorder.elapsed)
        case .finishing: "Saving…"
        case .failed(let f): f.message
        case .interrupted: "Camera in use by another app"
        case .ready: "Ready"
        default: "Starting camera…"
        }
    }

    private func banner(_ text: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.black).padding(8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.yellow))
    }

    /// Creates the Kick (existing workflow), copies the video into KickLab's media, removes
    /// the capture file, optionally saves to Photos, and hands the kick over for analysis.
    private func use(_ url: URL) async {
        guard let summary = app.selectedAthlete, let athlete = app.athleteModel(summary.id) else { problem = "Add an athlete first."; return }
        working = true
        defer { working = false }
        do {
            if saveToPhotos, let error = await PhotosSaver.save(videoAt: url) { problem = error }
            let draft = SessionKickDrafts.draft(details: details, timestamp: .now)
            let kick = try app.services.kicks.createKick(for: athlete, draft: draft)
            _ = try await app.services.videos.importVideo(from: url, for: kick, angle: .unknown, sourceType: .captured, makePrimary: true, recordedAt: .now)
            try? FileManager.default.removeItem(at: url)
            app.dataDidChange()
            dismiss()
            onKickCreated(kick.id)
        } catch {
            // The recording stays in KickLab's capture folder until the athlete retries.
            problem = "The kick couldn't be saved (\(UserFacingError.message(for: error))). The recording is kept."
        }
    }
}

/// Where in-progress single-kick recordings are written (KickLab's own storage, not the
/// temporary folder iOS may purge). The file is removed once imported into the kick.
enum CaptureFiles {
    static func directory() -> URL {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true))
            ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("KickLab/Capture", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func newSingleKickURL() -> URL { directory().appendingPathComponent("kick-\(UUID().uuidString).mov") }

    /// Non-empty single-kick recordings still in the capture folder, newest first.
    static func leftoverRecordings() -> [URL] {
        let keys: [URLResourceKey] = [.fileSizeKey, .creationDateKey]
        let files = (try? FileManager.default.contentsOfDirectory(at: directory(), includingPropertiesForKeys: keys)) ?? []
        return files
            .filter { $0.pathExtension == "mov" && ((try? $0.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) > 0 }
            .sorted { created($0) > created($1) }
    }

    static func dateText(_ url: URL) -> String {
        created(url).formatted(date: .abbreviated, time: .shortened)
    }

    private static func created(_ url: URL) -> Date {
        (try? url.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
    }
}

enum CaptureFormat {
    static func elapsed(_ t: TimeInterval) -> String {
        let s = Int(t)
        return String(format: "%d:%02d", s / 60, s % 60)
    }
}

/// The athlete's last camera choice.
enum CaptureSettingsStore {
    private static let key = "capture.request.v1"
    static func load() -> CaptureRequest {
        guard let data = UserDefaults.standard.data(forKey: key), let r = try? JSONDecoder().decode(CaptureRequest.self, from: data) else { return .standard }
        return r
    }
    static func save(_ r: CaptureRequest) {
        if let data = try? JSONEncoder().encode(r) { UserDefaults.standard.set(data, forKey: key) }
    }
}

/// Saves a copy of a recording to Photos with add-only permission.
enum PhotosSaver {
    /// Returns a problem, or nil when saved.
    static func save(videoAt url: URL) async -> String? {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else { return "Photos access wasn't allowed, so no copy was saved to Photos." }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                _ = PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }
            return nil
        } catch {
            return "The copy couldn't be saved to Photos."
        }
    }
}

/// Camera quality, sound and kick details.
struct CaptureSettingsSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var request: CaptureRequest
    @Binding var details: SessionKickDetails
    let showsDistance: Bool
    let onDone: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Quality", selection: $request) {
                        ForEach(CaptureRequest.choices, id: \.title) { Text($0.title).tag($0) }
                    }
                    Toggle("Record sound", isOn: $request.recordsAudio)
                } header: {
                    Text("Camera")
                } footer: {
                    Text("1080p · 60 fps is recommended. If this iPhone can't record a setting, KickLab says what it will record instead before you start. Sound is off unless you turn it on; analysis doesn't use it.")
                }
                KickDetailsSection(details: $details, showsDistance: showsDistance)
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { onDone(); dismiss() } }
            }
        }
    }
}

/// Kick type, distance, hash and optional details — entered by the athlete, never inferred.
struct KickDetailsSection: View {
    @Binding var details: SessionKickDetails
    let showsDistance: Bool

    var body: some View {
        Section("Kick") {
            Picker("Kick type", selection: $details.kickType) {
                ForEach([KickType.fieldGoal, .pat, .kickoff, .punt], id: \.self) { Text($0.displayName).tag($0) }
            }
            if showsDistance, details.kickType == .fieldGoal || details.kickType == .pat {
                Stepper(value: Binding(get: { details.distanceYards ?? 30 }, set: { details.distanceYards = $0 }), in: 10...70, step: 1) {
                    Text("Distance: \(details.distanceYards.map { DisplayFormat.yards($0) } ?? "not set")")
                }
                Picker("Hash", selection: $details.hash) {
                    ForEach([HashLocation.left, .center, .right], id: \.self) { Text($0.displayName).tag($0) }
                }
            }
            TextField("Conditions or wind (optional)", text: Binding(get: { details.conditions ?? "" }, set: { details.conditions = $0.isEmpty ? nil : $0 }))
        }
    }
}
