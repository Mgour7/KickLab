import SwiftUI

/// Step 12F: how to film a kick so KickLab can analyze it.
struct CaptureGuideView: View {
    @Environment(AppModel.self) private var app
    @State private var kickType: KickType = .fieldGoal
    @State private var view: CaptureGuide.View = .side
    @State private var recentRates: [(date: Date, fps: Double?)] = []

    init() {}

    var body: some View {
        List {
            Section {
                Picker("Kick", selection: $kickType) {
                    ForEach(CaptureGuide.kickTypes, id: \.self) { t in Text(t.displayName).tag(t) }
                }
                .pickerStyle(.segmented)
                Picker("Camera", selection: $view) {
                    ForEach(CaptureGuide.View.allCases) { v in Text(v.title).tag(v) }
                }
                .pickerStyle(.segmented)
                Text(CaptureGuide.measurementNote(view)).font(.subheadline)
            }
            Section("Checklist") {
                ForEach(CaptureGuide.tips(kickType, view)) { tip in
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(tip.title).font(.headline)
                            Text(tip.detail).font(.subheadline).foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: tip.symbol)
                    }
                }
            }
            Section {
                if recentRates.isEmpty {
                    Text("Add a video to see the frame rate it was recorded at.").foregroundStyle(.secondary)
                }
                ForEach(Array(recentRates.enumerated()), id: \.offset) { _, item in
                    LabeledContent {
                        Text(CaptureGuide.frameRateAdvice(item.fps)).font(.caption)
                    } label: {
                        Text(item.date, style: .date)
                    }
                }
            } header: {
                Text("Your recent videos")
            } footer: {
                Text("Read from each video file's own metadata.")
            }
        }
        .navigationTitle("How to Film a Kick")
        .task(id: app.revision) { loadRates() }
    }

    private func loadRates() {
        guard let id = app.selectedAthleteID, let athlete = app.athleteModel(id) else { return }
        let videos = (athlete.kicks ?? []).flatMap { $0.videos ?? [] }.sorted { $0.createdAt > $1.createdAt }.prefix(5)
        recentRates = videos.map { (date: $0.recordedAt ?? $0.createdAt, fps: $0.frameRate) }
    }
}
