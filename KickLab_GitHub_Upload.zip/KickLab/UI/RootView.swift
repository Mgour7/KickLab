import SwiftUI

/// Navigation destinations shared by every tab.
enum AppRoute: Hashable {
    case kick(UUID)
    case session(UUID)
    case analysis(UUID)
    case analyze(UUID)
    case kickHistory(UUID)
    case athleteHistory
    /// Step 12A developer diagnostics for one analysis.
    case diagnostics(UUID)
    /// Step 12C developer pose overlay player for one analysis.
    case poseValidation(UUID)
    /// Step 12D user-assisted recovery for a kick, from one of its analyses.
    case assistContact(kick: UUID, analysis: UUID)
    case assistKick(kick: UUID, analysis: UUID)
    /// Reanalysis fix: opens the Analyze screen and starts a NEW automatic analysis
    /// (no manual contact or kick interval) of the kick's original video.
    case reanalyzeAutomatically(UUID)
    /// Step 12E: the drill library and one drill.
    case drillLibrary
    case drill(String)
}

extension View {
    /// Registers every `AppRoute` destination on a navigation stack.
    func appRouteDestinations() -> some View {
        navigationDestination(for: AppRoute.self) { route in
            RouteView(route: route)
        }
    }
}

struct RouteView: View {
    let route: AppRoute

    var body: some View {
        switch route {
        case .kick(let id): KickDetailView(kickID: id)
        case .session(let id): SessionDetailView(sessionID: id)
        case .analysis(let id): AnalysisResultsView(analysisID: id)
        case .analyze(let id): AnalysisRunView(kickID: id)
        case .kickHistory(let id): AnalysisHistoryView(scope: .kick(id))
        case .athleteHistory: AnalysisHistoryView(scope: .athlete)
        case .diagnostics(let id): AnalysisDiagnosticsView(analysisID: id)
        case .poseValidation(let id): PoseValidationView(analysisID: id)
        case .assistContact(let kick, let analysis): AssistedAnalysisView(kickID: kick, analysisID: analysis, mode: .contact)
        case .assistKick(let kick, let analysis): AssistedAnalysisView(kickID: kick, analysisID: analysis, mode: .kick)
        case .reanalyzeAutomatically(let id): AnalysisRunView(kickID: id, startsAutomatically: true)
        case .drillLibrary: DrillLibraryView()
        case .drill(let id): DrillDetailView(drillID: id)
        }
    }
}

/// The top-level screen: welcome when there are no athletes, otherwise the tabs.
struct RootView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.scenePhase) private var scenePhase

    init() {}

    var body: some View {
        Group {
            if !app.hasLoaded {
                LoadingStateView()
            } else if let error = app.loadError, app.athletes.isEmpty {
                ErrorStateView(message: error) { app.load() }
            } else if app.athletes.isEmpty {
                WelcomeView()
            } else {
                MainTabView()
            }
        }
        .task { app.load() }
        .onChange(of: scenePhase) { _, phase in
            // iOS suspends background apps; stop analyses cleanly instead of letting them fail.
            if phase == .background { app.interruptRunningAnalyses() }
        }
    }
}

enum AppTab: Hashable {
    case home, kicks, analyze, stats, profile
}

struct MainTabView: View {
    @State private var selection: AppTab = .home

    init() {}

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack { HomeView(selectedTab: $selection).appRouteDestinations() }
                .tabItem { Label("Home", systemImage: "house") }
                .tag(AppTab.home)
            NavigationStack { KicksView().appRouteDestinations() }
                .tabItem { Label("Kicks", systemImage: "list.bullet.rectangle") }
                .tag(AppTab.kicks)
            NavigationStack { AnalyzeView().appRouteDestinations() }
                .tabItem { Label("Analyze", systemImage: "figure.run") }
                .tag(AppTab.analyze)
            NavigationStack { StatsView().appRouteDestinations() }
                .tabItem { Label("Stats", systemImage: "chart.bar") }
                .tag(AppTab.stats)
            NavigationStack { ProfileView().appRouteDestinations() }
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
                .tag(AppTab.profile)
        }
    }
}

/// First launch: no athletes yet.
struct WelcomeView: View {
    @State private var showingEditor = false

    init() {}

    var body: some View {
        NavigationStack {
            EmptyStateView(
                title: "Welcome to KickLab",
                systemImage: "football",
                message: "Add the kicker you want to track. You can add more athletes later.",
                actionTitle: "Add Athlete",
                action: { showingEditor = true }
            )
            .sheet(isPresented: $showingEditor) {
                AthleteEditorView(athleteID: nil)
            }
        }
    }
}
