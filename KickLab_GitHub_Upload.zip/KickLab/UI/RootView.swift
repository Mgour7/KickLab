import SwiftUI

/// Navigation destinations shared by every tab.
enum AppRoute: Hashable {
    case kick(UUID)
    case session(UUID)
    case analysis(UUID)
    /// Build 16: Performance Report level 2.
    case detailedAnalysis(UUID)
    /// Build 19: a sideways plant measurement drawn over the contact frame.
    case measurementInspector(analysis: UUID, metric: String)
    /// Build 20: pick two kicks to compare (optionally starting from one analysis).
    case compareKicks(UUID?)
    /// Build 20: two analyses side by side, synchronized at contact.
    case comparison(UUID, UUID)
    /// Build 21: Session Review, camera sync, a kick's two camera angles together.
    case trainingSession(UUID)
    case sessionSync(UUID)
    case pairPlayback(kick: UUID)
    case analyze(UUID)
    case kickHistory(UUID)
    case athleteHistory
    /// Step 12A developer diagnostics for one analysis.
    case diagnostics(UUID)
    /// Step 12C developer pose overlay player for one analysis.
    case poseValidation(UUID)
    /// Step 12D user-assisted recovery for a kick, from one of its analyses.
    case assistContact(kick: UUID, analysis: UUID)
    case assistKick(kick: UUID, analysis: UUID)
    /// Reanalysis fix: opens the Analyze screen and starts a NEW automatic analysis
    /// (no manual contact or kick interval) of the kick's original video.
    case reanalyzeAutomatically(UUID)
    /// Step 12E: the drill library and one drill.
    case drillLibrary
    case drill(String)
    /// Step 12F: frame-by-frame contact verification for one analysis.
    case verifyContact(UUID)
    /// Step 12F: progress dashboard, capture guide.
    case progress
    case captureGuide
    /// Step 12G: third-party notices.
    case acknowledgements
    /// Build 23: every measurement kick by kick, and one measurement in full.
    case metricTracker
    case metricDetail(group: String, metric: String)
}

extension View {
    /// Registers every `AppRoute` destination on a navigation stack.
    func appRouteDestinations() -> some View {
        navigationDestination(for: AppRoute.self) { route in
            RouteView(route: route)
        }
    }
}

struct RouteView: View {
    let route: AppRoute

    var body: some View {
        switch route {
        case .kick(let id): KickDetailView(kickID: id)
        case .session(let id): SessionDetailView(sessionID: id)
        case .analysis(let id): AnalysisResultsView(analysisID: id)
        case .detailedAnalysis(let id): AnalysisResultsView(analysisID: id, level: .detailed)
        case .measurementInspector(let id, let metric): MeasurementInspectorView(analysisID: id, metric: metric)
        case .compareKicks(let id): CompareKicksView(preselected: id)
        case .comparison(let a, let b): KickComparisonView(analysisA: a, analysisB: b)
        case .trainingSession(let id): SessionReviewView(sessionID: id)
        case .sessionSync(let id): SessionSyncView(sessionID: id)
        case .pairPlayback(let kick): KickComparisonView(pairedKick: kick)
        case .analyze(let id): AnalysisRunView(kickID: id)
        case .kickHistory(let id): AnalysisHistoryView(scope: .kick(id))
        case .athleteHistory: AnalysisHistoryView(scope: .athlete)
        case .diagnostics(let id): AnalysisDiagnosticsView(analysisID: id)
        case .poseValidation(let id): PoseValidationView(analysisID: id)
        case .assistContact(let kick, let analysis): AssistedAnalysisView(kickID: kick, analysisID: analysis, mode: .contact)
        case .assistKick(let kick, let analysis): AssistedAnalysisView(kickID: kick, analysisID: analysis, mode: .kick)
        case .reanalyzeAutomatically(let id): AnalysisRunView(kickID: id, startsAutomatically: true)
        case .drillLibrary: DrillLibraryView()
        case .drill(let id): DrillDetailView(drillID: id)
        case .verifyContact(let id): VerifyContactView(analysisID: id)
        case .progress: ProgressDashboardView()
        case .captureGuide: CaptureGuideView()
        case .acknowledgements: AcknowledgementsView()
        case .metricTracker: MetricTrackerView()
        case .metricDetail(let group, let metric): MetricDetailView(groupID: group, metric: metric)
        }
    }
}

/// The top-level screen: welcome when there are no athletes, otherwise the tabs.
struct RootView: View {
    @Environment(AppModel.self) private var app
    @Environment(\.scenePhase) private var scenePhase

    init() {}

    var body: some View {
        Group {
            if !app.hasLoaded {
                LoadingStateView()
            } else if let error = app.loadError, app.athletes.isEmpty {
                ErrorStateView(message: error) { app.load() }
            } else if app.athletes.isEmpty {
                WelcomeView()
            } else {
                MainTabView()
            }
        }
        .task {
            app.load()
            // Build 21: sessions interrupted by termination are recovered, never lost.
            app.recoverTrainingSessions()
        }
        .onChange(of: scenePhase) { _, phase in
            // iOS suspends background apps; stop analyses cleanly instead of letting them fail.
            if phase == .background {
                app.interruptRunningAnalyses()
                app.pauseSessionProcessingForBackground()
            }
        }
    }
}

enum AppTab: Hashable {
    case home, kicks, analyze, stats, profile
}

struct MainTabView: View {
    @State private var selection: AppTab = .home

    init() {}

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack { HomeView(selectedTab: $selection).appRouteDestinations() }
                .tabItem { Label("Home", systemImage: "house.fill") }
                .tag(AppTab.home)
            NavigationStack { KicksView().appRouteDestinations() }
                .tabItem { Label("Kicks", systemImage: "list.bullet.rectangle") }
                .tag(AppTab.kicks)
            NavigationStack { AnalyzeView().appRouteDestinations() }
                .tabItem { Label("Analyze", systemImage: "figure.run") }
                .tag(AppTab.analyze)
            NavigationStack { StatsView().appRouteDestinations() }
                .tabItem { Label("Progress", systemImage: "chart.xyaxis.line") }
                .tag(AppTab.stats)
            NavigationStack { ProfileView().appRouteDestinations() }
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
                .tag(AppTab.profile)
        }
        .tint(KickTheme.brand)
    }
}

/// First launch: no athletes yet.
struct WelcomeView: View {
    @State private var showingEditor = false

    init() {}

    var body: some View {
        NavigationStack {
            EmptyStateView(
                title: "Welcome to KickLab",
                systemImage: "football",
                message: "Add the kicker you want to track. You can add more athletes later.",
                actionTitle: "Add Athlete",
                action: { showingEditor = true }
            )
            .sheet(isPresented: $showingEditor) {
                AthleteEditorView(athleteID: nil)
            }
        }
    }
}
