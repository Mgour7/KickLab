import Foundation
import SwiftData

/// Creates, edits and deletes kicking sessions.
///
/// - S1  A session always has an athlete.
/// - S2  Deleting a session keeps its kicks; the `.nullify` rule leaves them unassigned.
/// - S3  Assigning kicks to sessions is delegated to `KickService`.
/// - Changing a session's type never rewrites the context of kicks already recorded.
///
/// Save policy: see `ModelCommit`. Every mutating method saves before returning.
struct KickingSessionService {
    let context: ModelContext
    let saveHandler: ModelSaveHandler

    init(context: ModelContext, saveHandler: @escaping ModelSaveHandler = ModelCommit.defaultSave) {
        self.context = context
        self.saveHandler = saveHandler
    }

    // MARK: Create

    @discardableResult
    func createSession(
        for athlete: Athlete,
        name: String,
        date: Date = .now,
        sessionType: KickingSessionType = .training,
        location: String? = nil,
        notes: String? = nil
    ) throws -> KickingSession {
        try requireManaged(athlete)
        guard !athlete.isArchived else {
            throw KickingSessionServiceError.athleteArchived(athleteID: athlete.id)
        }
        let edit = KickingSessionEdit(name: name, date: date, sessionType: sessionType, location: location, notes: notes)
        let issues = edit.issues
        guard issues.isEmpty else { throw KickingSessionServiceError.invalidEdit(issues) }

        let values = edit.normalized
        let session = KickingSession(
            date: values.date,
            name: values.name,
            sessionType: values.sessionType,
            location: values.location,
            notes: values.notes
        )
        context.insert(session)
        session.athlete = athlete
        try commit()
        return session
    }

    // MARK: Edit

    /// Replaces the session's editable fields. Existing kicks keep their recorded
    /// context even if the session type changes.
    func updateSession(_ session: KickingSession, with edit: KickingSessionEdit) throws {
        try requireManaged(session)
        let issues = edit.issues
        guard issues.isEmpty else { throw KickingSessionServiceError.invalidEdit(issues) }

        let values = edit.normalized
        session.name = values.name
        session.date = values.date
        session.sessionType = values.sessionType
        session.location = values.location
        session.notes = values.notes
        session.updatedAt = .now
        try commit()
    }

    // MARK: Delete

    /// Read-only. What the confirmation should tell the person before deleting.
    func deletionSummary(for session: KickingSession) -> KickingSessionDeletionSummary {
        KickingSessionDeletionSummary(
            sessionID: session.id,
            sessionName: session.name,
            kickCount: session.kicks?.count ?? 0
        )
    }

    /// Deletes the session. Its kicks are preserved and become unassigned through
    /// the `.nullify` delete rule.
    func deleteSession(_ session: KickingSession) throws {
        try requireManaged(session)
        context.delete(session)
        try commit()
    }

    // MARK: Kick assignment

    /// Delegates to `KickService.assign(_:to:)` so relationship rules live in one place.
    /// - Throws: `KickServiceError`.
    func assign(_ kick: Kick, to session: KickingSession?) throws {
        try KickService(context: context, saveHandler: saveHandler).assign(kick, to: session)
    }

    // MARK: Helpers

    private func requireManaged(_ model: any PersistentModel) throws {
        guard context.manages(model) else { throw KickingSessionServiceError.notInServiceContext }
    }

    private func commit() throws {
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw KickingSessionServiceError.persistenceFailed(failure.underlyingDescription)
        }
    }
}
