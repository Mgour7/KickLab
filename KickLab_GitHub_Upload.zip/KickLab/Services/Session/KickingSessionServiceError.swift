import Foundation

/// Errors thrown by `KickingSessionService`.
///
/// `KickingSessionService.assign(_:to:)` delegates to `KickService` and therefore
/// throws `KickServiceError`, so relationship rules live in exactly one place.
enum KickingSessionServiceError: Error, Equatable, Sendable, LocalizedError {
    case invalidEdit([KickingSessionEditIssue])
    /// New sessions cannot be created for an archived athlete.
    case athleteArchived(athleteID: UUID)
    case notInServiceContext
    /// `ModelContext.save()` failed. The context was rolled back; nothing was persisted.
    case persistenceFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidEdit(let issues):
            issues.contains(.emptyName) ? "A session needs a name." : "The session details are invalid."
        case .athleteArchived:
            "Sessions can't be added for an archived athlete."
        case .notInServiceContext:
            "The record isn't available in this data context."
        case .persistenceFailed:
            "KickLab couldn't save the change."
        }
    }
}
