import Foundation

/// The complete editable state of a session. Pass the whole value to
/// `KickingSessionService.updateSession(_:with:)`.
struct KickingSessionEdit: Equatable, Sendable {
    var name: String
    var date: Date
    var sessionType: KickingSessionType
    var location: String?
    var notes: String?

    init(
        name: String,
        date: Date = .now,
        sessionType: KickingSessionType = .training,
        location: String? = nil,
        notes: String? = nil
    ) {
        self.name = name
        self.date = date
        self.sessionType = sessionType
        self.location = location
        self.notes = notes
    }

    /// Trimmed copy: whitespace-only optional text becomes nil.
    var normalized: KickingSessionEdit {
        var copy = self
        copy.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.location = location.normalizedOptionalText
        copy.notes = notes.normalizedOptionalText
        return copy
    }

    /// Pure validation. Empty means valid.
    var issues: [KickingSessionEditIssue] {
        normalized.name.isEmpty ? [.emptyName] : []
    }
}

enum KickingSessionEditIssue: Equatable, Sendable {
    case emptyName
}

/// What the UI needs before confirming a session deletion:
/// "12 kicks will be kept as unassigned."
struct KickingSessionDeletionSummary: Equatable, Sendable {
    let sessionID: UUID
    let sessionName: String
    let kickCount: Int

    var confirmationMessage: String {
        switch kickCount {
        case 0: "This session has no kicks."
        case 1: "1 kick will be kept as unassigned."
        default: "\(kickCount) kicks will be kept as unassigned."
        }
    }
}

extension Optional where Wrapped == String {
    /// Trims whitespace; empty results become nil.
    var normalizedOptionalText: String? {
        guard let trimmed = self?.trimmingCharacters(in: .whitespacesAndNewlines), !trimmed.isEmpty else {
            return nil
        }
        return trimmed
    }
}
