import Foundation

enum AnalysisValueField: String, Sendable {
    case metricValue, metricConfidence, sampleTime
    case score, scoreConfidence
    case observationConfidence
    case analysisConfidence, overallScore
}

/// A reason an analysis result (or completion value) is invalid.
enum AnalysisResultIssue: Equatable, Sendable {
    // Metrics
    case emptyMetricKey
    case invalidMetricDefinitionVersion(Int)
    case unknownMetricUnit
    // Shared
    case unavailableHasValue(AnalysisValueField)
    case measuredValueMissing(AnalysisValueField)
    case nonFiniteValue(AnalysisValueField)
    case valueOutOfRange(AnalysisValueField, value: Double)
    case unknownCategory
    // Observations
    case unknownObservationKind
    case emptyMessage
    case severityOnlyForImprove(ObservationKind)
    case relatedObservationOnlyForCue(ObservationKind)
    case relatedObservationIsSelf
    case relatedObservationNotInAnalysis(UUID)
    case relatedObservationMustBeImprove(found: ObservationKind)
    case duplicateObservationID(UUID)
}

/// Pure validation for analysis results. No database access.
enum AnalysisResultValidator {
    static let confidenceRange: ClosedRange<Double> = 0...1
    static let scoreRange: ClosedRange<Double> = 0...100

    static func validate(_ draft: MetricDraft) -> [AnalysisResultIssue] {
        var issues: [AnalysisResultIssue] = []
        if draft.metricKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            issues.append(.emptyMetricKey)
        }
        if draft.metricDefinitionVersion < 1 {
            issues.append(.invalidMetricDefinitionVersion(draft.metricDefinitionVersion))
        }
        if draft.unit == .unknown {
            issues.append(.unknownMetricUnit)
        }
        checkPresence(value: draft.value, status: draft.measurementStatus, field: .metricValue, into: &issues)
        checkFinite(draft.value, field: .metricValue, range: nil, into: &issues)
        checkFinite(draft.confidence, field: .metricConfidence, range: confidenceRange, into: &issues)
        checkFinite(draft.sampleTimeSeconds, field: .sampleTime, range: 0...Double.greatestFiniteMagnitude, into: &issues)
        return issues
    }

    static func validate(_ draft: CategoryScoreDraft) -> [AnalysisResultIssue] {
        var issues: [AnalysisResultIssue] = []
        if draft.category == .unknown {
            issues.append(.unknownCategory)
        }
        checkPresence(value: draft.score, status: draft.measurementStatus, field: .score, into: &issues)
        checkFinite(draft.score, field: .score, range: scoreRange, into: &issues)
        checkFinite(draft.confidence, field: .scoreConfidence, range: confidenceRange, into: &issues)
        return issues
    }

    /// - Parameter existing: observations already stored in the **same** analysis.
    ///   A related ID is valid only if it appears here, which rules out cross-analysis links.
    static func validate(_ draft: CoachingObservationDraft, existing: [ExistingObservationRef]) -> [AnalysisResultIssue] {
        var issues: [AnalysisResultIssue] = []
        if draft.kind == .unknown {
            issues.append(.unknownObservationKind)
        }
        if draft.category == .unknown {
            issues.append(.unknownCategory)
        }
        if draft.message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            issues.append(.emptyMessage)
        }
        if draft.severity != nil && draft.kind != .improve {
            issues.append(.severityOnlyForImprove(draft.kind))
        }
        if existing.contains(where: { $0.id == draft.id }) {
            issues.append(.duplicateObservationID(draft.id))
        }
        checkFinite(draft.confidence, field: .observationConfidence, range: confidenceRange, into: &issues)

        if let relatedID = draft.relatedObservationID {
            if draft.kind != .cue {
                issues.append(.relatedObservationOnlyForCue(draft.kind))
            }
            if relatedID == draft.id {
                issues.append(.relatedObservationIsSelf)
            } else if let target = existing.first(where: { $0.id == relatedID }) {
                if target.kind != .improve {
                    issues.append(.relatedObservationMustBeImprove(found: target.kind))
                }
            } else {
                issues.append(.relatedObservationNotInAnalysis(relatedID))
            }
        }
        return issues
    }

    /// Values supplied when an analysis is marked completed.
    static func validateCompletion(confidence: Double?, overallScore: Double?) -> [AnalysisResultIssue] {
        var issues: [AnalysisResultIssue] = []
        checkFinite(confidence, field: .analysisConfidence, range: confidenceRange, into: &issues)
        checkFinite(overallScore, field: .overallScore, range: scoreRange, into: &issues)
        return issues
    }

    // MARK: Helpers

    /// unavailable ⇒ nil; measured/estimated ⇒ non-nil.
    private static func checkPresence(
        value: Double?,
        status: MeasurementStatus,
        field: AnalysisValueField,
        into issues: inout [AnalysisResultIssue]
    ) {
        switch (status, value) {
        case (.unavailable, .some):
            issues.append(.unavailableHasValue(field))
        case (.measured, .none), (.estimated, .none):
            issues.append(.measuredValueMissing(field))
        default:
            break
        }
    }

    private static func checkFinite(
        _ value: Double?,
        field: AnalysisValueField,
        range: ClosedRange<Double>?,
        into issues: inout [AnalysisResultIssue]
    ) {
        guard let value else { return }
        if !value.isFinite {
            issues.append(.nonFiniteValue(field))
        } else if let range, !range.contains(value) {
            issues.append(.valueOutOfRange(field, value: value))
        }
    }
}
