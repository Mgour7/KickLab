import Foundation

extension VideoAnalysisRequest {
    /// Builds a request from stored records.
    ///
    /// Every video must belong to `kick` (no orphaned or cross-kick input), the same
    /// rule `AnalysisService` enforces when the analysis record is created. Inputs are
    /// ordered primary first, then by sort order.
    ///
    /// `options.kickingFoot` is replaced by the athlete's kicking foot when the kick has an
    /// athlete, so the pose pipeline never assumes a right-footed kicker.
    ///
    /// - Throws: `AnalysisServiceError.noInputVideos` or `.integrity`.
    static func make(
        for kick: Kick,
        videos: [VideoAsset],
        requestedAt: Date = .now,
        options: VideoAnalysisOptions = VideoAnalysisOptions()
    ) throws -> VideoAnalysisRequest {
        guard !videos.isEmpty else { throw AnalysisServiceError.noInputVideos }
        let issues = videos.flatMap { AnalysisIntegrityValidator.issues(attaching: $0, toKick: kick) }
        guard issues.isEmpty else { throw AnalysisServiceError.integrity(issues) }

        var resolvedOptions = options
        if let foot = kick.athlete?.kickingFoot { resolvedOptions.kickingFoot = foot }

        let ordered = videos.sorted {
            if $0.isPrimary != $1.isPrimary { return $0.isPrimary }
            return $0.sortOrder < $1.sortOrder
        }
        return VideoAnalysisRequest(
            kickID: kick.id,
            kickType: kick.kickType,
            inputs: ordered.map { video in
                VideoAnalysisInput(
                    videoID: video.id,
                    angle: video.angleType,
                    isPrimary: video.isPrimary,
                    relativeFilePath: video.relativeFilePath,
                    frameRate: video.frameRate,
                    durationSeconds: video.durationSeconds,
                    syncOffsetSeconds: video.syncOffsetSeconds,
                    contactTimeSeconds: video.contactTimeSeconds
                )
            },
            requestedAt: requestedAt,
            options: resolvedOptions
        )
    }
}
