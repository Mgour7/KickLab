import Foundation

// Contact-estimation validation (Step 12B harness, extended in Step 12C).
//
// Reference contact times are EVALUATION DATA. They are compared with the automatic
// estimate after the fact and are never an input to analysis: nothing in the pose
// pipeline, phase detection or scoring reads them.

/// Estimated vs. marked contact time for one video.
struct ContactTimingCheck: Codable, Equatable, Sendable {
    /// A contact estimate within this many seconds of the marked contact counts as
    /// agreeing (about one frame at 30 fps, plus marking error).
    static let toleranceSeconds = 0.05

    var referenceTime: Double
    var estimatedTime: Double?
    /// estimated − reference (positive = estimate is late).
    var errorSeconds: Double?
    /// The error in ANALYZED frames (the sampling actually used, not the source rate).
    var errorFrames: Double?
    var withinTolerance: Bool
    /// Step 12C (optional so earlier reports decode).
    var label: String? = nil
    var estimateConfidence: Double? = nil
    var sourceFrameRate: Double? = nil
    var analysisFrameRate: Double? = nil
    /// How uncertain the reference itself is, in source frames (a human marking ±1 frame).
    var referenceUncertaintyFrames: Double? = nil

    init(referenceTime: Double, estimatedTime: Double?, framesPerSecond: Double?) {
        self.referenceTime = referenceTime
        self.estimatedTime = estimatedTime
        let error = estimatedTime.map { $0 - referenceTime }
        errorSeconds = error.map(AnalysisDiagnosticsBuilder.round3)
        errorFrames = error.flatMap { e in framesPerSecond.map { AnalysisDiagnosticsBuilder.round3(e * $0) } }
        withinTolerance = error.map { abs($0) <= Self.toleranceSeconds + 1e-9 } ?? false
        analysisFrameRate = framesPerSecond
    }

    /// Step 12C: with label, confidence and both frame rates.
    init(label: String, referenceTime: Double, estimatedTime: Double?, confidence: Double?,
         sourceFrameRate: Double?, analysisFrameRate: Double?, referenceUncertaintyFrames: Double? = nil) {
        self.init(referenceTime: referenceTime, estimatedTime: estimatedTime, framesPerSecond: analysisFrameRate)
        self.label = label
        estimateConfidence = confidence
        self.sourceFrameRate = sourceFrameRate
        self.referenceUncertaintyFrames = referenceUncertaintyFrames
    }

    var errorMilliseconds: Double? { errorSeconds.map { ($0 * 1000).rounded() } }
    var absoluteErrorMilliseconds: Double? { errorMilliseconds.map(abs) }
    var absoluteErrorFrames: Double? { errorFrames.map(abs) }
}

/// Summary over many annotated videos: the validation harness for contact estimates.
struct ContactTimingSummary: Equatable, Sendable {
    var count: Int
    /// Videos where no contact was estimated.
    var missing: Int
    var meanAbsoluteError: Double?
    var maximumAbsoluteError: Double?
    /// Mean signed error (positive = estimates tend to be late).
    var bias: Double?
    var withinToleranceFraction: Double
    // Step 12C
    var medianAbsoluteError: Double?
    var p90AbsoluteError: Double?
    /// Fractions of ALL checks (missing count as misses) within 1, 2 and 3 analyzed frames.
    var withinOneFrame: Double
    var withinTwoFrames: Double
    var withinThreeFrames: Double
    var calibration: ContactCalibration?

    init(_ checks: [ContactTimingCheck]) {
        count = checks.count
        let errors = checks.compactMap(\.errorSeconds)
        let absolute = errors.map(abs).sorted()
        missing = checks.count - errors.count
        meanAbsoluteError = errors.isEmpty ? nil : absolute.reduce(0, +) / Double(absolute.count)
        maximumAbsoluteError = absolute.last
        bias = errors.isEmpty ? nil : errors.reduce(0, +) / Double(errors.count)
        withinToleranceFraction = checks.isEmpty ? 0 : Double(checks.filter(\.withinTolerance).count) / Double(checks.count)
        medianAbsoluteError = Self.percentile(absolute, 0.5)
        p90AbsoluteError = Self.percentile(absolute, 0.9)
        func within(_ frames: Double) -> Double {
            guard !checks.isEmpty else { return 0 }
            return Double(checks.filter { ($0.absoluteErrorFrames ?? .infinity) <= frames + 1e-6 }.count) / Double(checks.count)
        }
        withinOneFrame = within(1)
        withinTwoFrames = within(2)
        withinThreeFrames = within(3)
        calibration = ContactCalibration(checks)
    }

    /// Nearest-rank percentile of sorted values.
    static func percentile(_ sorted: [Double], _ p: Double) -> Double? {
        guard !sorted.isEmpty else { return nil }
        let rank = Int((p * Double(sorted.count)).rounded(.up))
        return sorted[min(sorted.count - 1, max(0, rank - 1))]
    }

    /// A readable report, one line per check, then the summary.
    static func report(_ checks: [ContactTimingCheck]) -> String {
        func ms(_ v: Double?) -> String { v.map { String(format: "%.0f ms", $0 * 1000) } ?? "—" }
        var lines = ["clip | reference s | estimate s | error ms | |error| frames | confidence | source/analysis fps"]
        for c in checks {
            let reference: String = String(format: "%.3f", c.referenceTime)
            let estimate: String = c.estimatedTime.map { String(format: "%.3f", $0) } ?? "unavailable"
            let error: String = c.errorMilliseconds.map { String(format: "%+.0f", $0) } ?? "—"
            let frames: String = c.absoluteErrorFrames.map { String(format: "%.2f", $0) } ?? "—"
            let confidence: String = c.estimateConfidence.map { String(format: "%.2f", $0) } ?? "—"
            let source: String = c.sourceFrameRate.map { String(format: "%.0f", $0) } ?? "—"
            let analysis: String = c.analysisFrameRate.map { String(format: "%.0f", $0) } ?? "—"
            let fields: [String] = [c.label ?? "—", reference, estimate, error, frames, confidence, source + "/" + analysis]
            lines.append(fields.joined(separator: " | "))
        }
        let s = ContactTimingSummary(checks)
        lines.append("")
        lines.append("clips \(s.count) · unavailable \(s.missing) · MAE \(ms(s.meanAbsoluteError)) · median \(ms(s.medianAbsoluteError)) · p90 \(ms(s.p90AbsoluteError)) · max \(ms(s.maximumAbsoluteError)) · bias \(ms(s.bias))")
        lines.append(String(format: "within 1 / 2 / 3 frames: %.0f%% / %.0f%% / %.0f%%", s.withinOneFrame * 100, s.withinTwoFrames * 100, s.withinThreeFrames * 100))
        if let c = s.calibration {
            lines.append("calibration: high-confidence MAE \(ms(c.highConfidenceMeanAbsoluteError)) (n=\(c.highCount)) vs low-confidence MAE \(ms(c.lowConfidenceMeanAbsoluteError)) (n=\(c.lowCount)) · \(c.higherConfidenceIsMoreAccurate.map { $0 ? "higher confidence IS more accurate" : "higher confidence is NOT more accurate" } ?? "not enough spread to tell")")
        }
        return lines.joined(separator: "\n")
    }
}

/// Is a higher confidence actually more accurate? Splits the estimated checks at the
/// median confidence and compares their mean absolute errors.
struct ContactCalibration: Equatable, Sendable {
    var splitConfidence: Double
    var highCount: Int
    var lowCount: Int
    var highConfidenceMeanAbsoluteError: Double?
    var lowConfidenceMeanAbsoluteError: Double?
    /// Nil when there is no confidence spread or too few checks to tell.
    var higherConfidenceIsMoreAccurate: Bool?

    init?(_ checks: [ContactTimingCheck]) {
        let rated = checks.compactMap { c -> (Double, Double)? in
            guard let confidence = c.estimateConfidence, let error = c.errorSeconds else { return nil }
            return (confidence, abs(error))
        }
        guard rated.count >= 2 else { return nil }
        let sorted = rated.map(\.0).sorted()
        let split = sorted[sorted.count / 2]
        splitConfidence = split
        let high = rated.filter { $0.0 >= split }.map(\.1)
        let low = rated.filter { $0.0 < split }.map(\.1)
        highCount = high.count
        lowCount = low.count
        highConfidenceMeanAbsoluteError = high.isEmpty ? nil : high.reduce(0, +) / Double(high.count)
        lowConfidenceMeanAbsoluteError = low.isEmpty ? nil : low.reduce(0, +) / Double(low.count)
        if let h = highConfidenceMeanAbsoluteError, let l = lowConfidenceMeanAbsoluteError, high.count >= 2, low.count >= 2 {
            higherConfidenceIsMoreAccurate = h <= l
        } else {
            higherConfidenceIsMoreAccurate = nil
        }
    }
}

// MARK: - Reference library

/// One human-annotated reference recording for validation (Step 12C). Holds the stored
/// pose sequence (body coordinates, no video frames) and the reviewer's contact frame.
/// Kept OUT of the analysis code path: only `ContactValidationHarness` reads it.
///
/// Files live in a private validation library (e.g. `KickLabTests/ValidationLibrary/`),
/// one JSON file per clip, exported from the iPhone with "Export Pose for Validation" on
/// the Diagnostics screen. Add a clip only with the athlete's (or guardian's) permission
/// and the right to use the recording; record that in `rightsNote`.
struct ContactReferenceClip: Codable, Equatable, Sendable {
    static let kind = "kicklab.contact-reference"
    static let currentFormatVersion = 1

    var kind: String = ContactReferenceClip.kind
    var formatVersion: Int = ContactReferenceClip.currentFormatVersion
    /// A neutral label (no names), e.g. "fg-side-30fps-01".
    var clipID: String
    var kickType: KickType
    var kickingFoot: KickingFoot
    var cameraAngle: VideoAngleType
    var sourceFrameRate: Double?
    /// Reviewer-marked foot–ball contact, seconds from the start of the video.
    var annotatedContactTime: Double
    /// The reviewer's own uncertainty, in source frames (typically 1).
    var annotationUncertaintyFrames: Double
    /// Who reviewed it (a role, not a name), e.g. "coach", "parent", "athlete".
    var annotator: String
    /// Permission and rights to use the recording for validation.
    var rightsNote: String
    /// Engine version that produced the pose (the pose is replayed by the CURRENT detector).
    var poseEngineVersion: String?
    var sequence: PoseSequence
}

enum ContactValidationHarness {
    /// Replays the current processing and phase detection on a reference clip's stored
    /// pose and compares the estimate with the reviewer's mark. The annotation is read
    /// only AFTER the estimate is made.
    static func evaluate(_ clip: ContactReferenceClip) -> ContactTimingCheck {
        let estimate = estimateContact(sequence: clip.sequence, kickType: clip.kickType, kickingFoot: clip.kickingFoot)
        return ContactTimingCheck(
            label: clip.clipID, referenceTime: clip.annotatedContactTime, estimatedTime: estimate.time,
            confidence: estimate.confidence, sourceFrameRate: clip.sourceFrameRate ?? clip.sequence.nominalFrameRate,
            analysisFrameRate: estimate.analysisFrameRate, referenceUncertaintyFrames: clip.annotationUncertaintyFrames
        )
    }

    /// The automatic estimate from stored pose alone (no annotation in scope).
    static func estimateContact(sequence: PoseSequence, kickType: KickType, kickingFoot: KickingFoot)
        -> (time: Double?, confidence: Double?, analysisFrameRate: Double?) {
        guard let id = sequence.kickerTrackID else { return (nil, nil, nil) }
        let raw = KickerPoseTimeline.make(from: sequence.frames, trackID: id, displayAspectRatio: sequence.displayAspectRatio)
        let processed = PoseTimelineProcessor.process(raw)
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: kickingFoot)
        let phases = KickPhaseDetector.detect(signals, kickType: kickType)
        let contact = phases.phase(.contact)
        let fps = signals.timestamps.count > 1 ? KickPhaseDetector.framesPerSecond(signals.timestamps) : nil
        return (phases.estimatedContactTime, contact.isAvailable ? contact.confidence : nil, fps)
    }

    /// Reads every reference clip (`*.json`) in a directory, skipping other files.
    static func loadLibrary(at directory: URL) throws -> [ContactReferenceClip] {
        let files = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
        return try files.filter { $0.pathExtension == "json" }.sorted { $0.lastPathComponent < $1.lastPathComponent }.map { url in
            let clip = try JSONDecoder().decode(ContactReferenceClip.self, from: Data(contentsOf: url))
            guard clip.kind == ContactReferenceClip.kind, clip.formatVersion <= ContactReferenceClip.currentFormatVersion else {
                throw AnalysisArtifactError.corrupt("\(url.lastPathComponent) is not a supported contact reference clip")
            }
            return clip
        }
    }
}
