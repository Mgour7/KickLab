import Foundation

/// The facts about one analysis needed to decide which is current.
struct AnalysisCurrencySnapshot: Equatable, Sendable {
    var id: UUID
    var status: ProcessingStatus
    var isCurrent: Bool
    var createdAt: Date
    var completedAt: Date?

    /// Recency used for "newest": completion time, falling back to creation time.
    var recency: Date { completedAt ?? createdAt }
}

/// Pure rules for which analysis of a kick is current.
///
/// - Only a completed analysis may be current.
/// - If completed analyses are already marked current, the newest of them wins
///   (this resolves "multiple current").
/// - Otherwise the newest completed analysis is selected (this resolves "zero current"
///   and "only failed/processing records were marked current").
/// - With no completed analyses, nothing is current.
///
/// Ties on recency fall back to `createdAt`, then to the ID string, so the result is
/// deterministic.
enum CurrentAnalysisSelector {
    static func selectCurrent(from analyses: [AnalysisCurrencySnapshot]) -> UUID? {
        let completed = analyses.filter { $0.status == .completed }
        let completedAndCurrent = completed.filter(\.isCurrent)
        let pool = completedAndCurrent.isEmpty ? completed : completedAndCurrent
        return pool.max(by: isOlder)?.id
    }

    /// The `isCurrent` value every analysis should have.
    static func currentFlags(for analyses: [AnalysisCurrencySnapshot]) -> [UUID: Bool] {
        let selected = selectCurrent(from: analyses)
        return Dictionary(uniqueKeysWithValues: analyses.map { ($0.id, $0.id == selected) })
    }

    private static func isOlder(_ a: AnalysisCurrencySnapshot, _ b: AnalysisCurrencySnapshot) -> Bool {
        if a.recency != b.recency { return a.recency < b.recency }
        if a.createdAt != b.createdAt { return a.createdAt < b.createdAt }
        return a.id.uuidString < b.id.uuidString
    }
}

/// One remaining analysis, when the current analysis of a kick is deleted.
struct CurrentReplacementCandidate: Equatable, Sendable {
    var snapshot: AnalysisCurrencySnapshot
    /// Engine version ends in "+assisted": the user chose contact or the kick interval.
    var isUserAssisted: Bool
}

extension CurrentAnalysisSelector {
    /// Which analysis becomes current after the current one is deleted: the newest
    /// completed AUTOMATIC analysis, or none. A user-assisted analysis is never made
    /// current implicitly; the user can still open it from the history.
    static func replacementAfterDeletion(from candidates: [CurrentReplacementCandidate]) -> UUID? {
        let automatic = candidates.filter { !$0.isUserAssisted && $0.snapshot.status == .completed }.map(\.snapshot)
        return automatic.max { a, b in
            if a.recency != b.recency { return a.recency < b.recency }
            if a.createdAt != b.createdAt { return a.createdAt < b.createdAt }
            return a.id.uuidString < b.id.uuidString
        }?.id
    }
}

/// What `AnalysisService.repairCurrent(for:)` changed.
struct CurrentAnalysisRepairResult: Equatable, Sendable {
    /// The analysis that is now current, or nil when no completed analysis exists.
    let currentAnalysisID: UUID?
    /// Analyses whose `isCurrent` flag was changed. Empty means nothing needed repair.
    let changedAnalysisIDs: [UUID]
}
