import Foundation

/// Step 12E: one checkpoint of the analysis, recorded for every run so a failure says
/// exactly where it stopped and why (shown in Diagnostics; no coordinates).
struct AnalysisGate: Codable, Equatable, Sendable {
    enum Name: String, Codable, Sendable, CaseIterable {
        case frames, poseDetection, kickerTracking, perspective, legIdentity, jointCoverage
        case kickWindow, approach, plant, contact, followThrough, metrics, scoring, completion
    }

    var gate: Name
    /// Nil = informational (the run continues either way).
    var passed: Bool?
    var detail: String
    /// Numbers behind the decision (coverage, scores, counts…), keyed by name.
    var values: [String: Double]

    init(_ gate: Name, passed: Bool?, _ detail: String, _ values: [String: Double] = [:]) {
        self.gate = gate
        self.passed = passed
        self.detail = detail
        self.values = values.mapValues { ($0 * 1000).rounded() / 1000 }
    }
}

/// Step 12E: whether a run stands as a completed analysis.
///
/// - Scored: at least one mechanics category could be scored (unchanged rule).
/// - Measurements only (behind / in front / diagonal views): no category reaches its
///   scoring threshold — a depth view can't show most side-view metrics — but the kick
///   was found (contact available and not ambiguous) and at least
///   `minimumMeasurementOnlyMetrics` trustworthy measurements exist. No score is created:
///   the analysis completes with measurements and no overall score.
/// A side view keeps the scored rule only.
enum AnalysisCompletion {
    static let minimumMeasurementOnlyMetrics = 2

    enum Basis: String, Codable, Sendable {
        case scored, measurementsOnly, insufficient
    }

    static func evaluate(
        kickerSelected: Bool,
        perspective: CameraPerspective,
        phases: KickPhaseDetectionResult,
        availableMetricCount: Int,
        scoredCategoryCount: Int
    ) -> (basis: Basis, detail: String) {
        guard kickerSelected else { return (.insufficient, "No kicker was selected.") }
        if scoredCategoryCount > 0 {
            return (.scored, "\(scoredCategoryCount) mechanics categor\(scoredCategoryCount == 1 ? "y" : "ies") scored.")
        }
        guard perspective != .side else {
            return (.insufficient, "No mechanics category reached its scoring threshold (side view: scores are required).")
        }
        let contact = phases.phase(.contact)
        guard contact.isAvailable, contact.status != .ambiguous else {
            return (.insufficient, "No category scored, and contact wasn't found (or several kicks need a choice), so the measurements can't stand alone.")
        }
        guard availableMetricCount >= minimumMeasurementOnlyMetrics else {
            return (.insufficient, "No category scored and only \(availableMetricCount) trustworthy measurement\(availableMetricCount == 1 ? "" : "s") (at least \(minimumMeasurementOnlyMetrics) needed).")
        }
        return (.measurementsOnly, "\(availableMetricCount) trustworthy measurements for this camera view; no category has enough of its scored metrics visible from this angle, so no score is given.")
    }
}

enum AnalysisGates {
    static func make(
        sequence: PoseSequence,
        tracking: KickerTrackingResult?,
        perspective: PerspectiveDecision?,
        legIdentity: LegIdentityCheck?,
        timeline: KickerPoseTimeline?,
        kickingFoot: KickingFoot,
        phases: KickPhaseDetectionResult?,
        measurements: [KickMetricMeasurement]?,
        scoredCategoryCount: Int?,
        completion: (basis: AnalysisCompletion.Basis, detail: String)?
    ) -> [AnalysisGate] {
        var gates: [AnalysisGate] = []
        let stats = sequence.confidenceStatistics
        let analyzed = max(0, stats.frameCount - stats.droppedFrameCount)
        gates.append(AnalysisGate(.frames, passed: analyzed > 0,
                                  "\(analyzed) of \(stats.frameCount) frames analyzed · orientation \(sequence.orientation.rawValue)\(sequence.isMirrored ? " · mirrored" : "")",
                                  ["analyzed": Double(analyzed), "sampled": Double(stats.frameCount)]))
        let withPerson = analyzed > 0 ? Double(stats.framesWithBodies) / Double(analyzed) : 0
        gates.append(AnalysisGate(.poseDetection, passed: withPerson >= 0.1,
                                  String(format: "a person in %.0f%% of analyzed frames", withPerson * 100),
                                  ["framesWithPerson": Double(stats.framesWithBodies), "fraction": withPerson]))
        guard let tracking else { return gates }
        gates.append(AnalysisGate(.kickerTracking, passed: tracking.status == .selected,
                                  "\(tracking.status.rawValue) via \(tracking.method.rawValue) · \(tracking.candidates.count) candidate(s)",
                                  ["confidence": tracking.confidence, "candidates": Double(tracking.candidates.count)]))
        guard tracking.status == .selected else { return gates }
        if let p = perspective {
            var values: [String: Double] = [:]
            if let c = p.cues { values["horizontalTravelBodyLengths"] = c.horizontalTravel; values["sizeRatio"] = c.sizeRatio }
            gates.append(AnalysisGate(.perspective, passed: nil, "\(p.used.rawValue) — \(p.explanation)", values))
        }
        if let l = legIdentity {
            var values: [String: Double] = ["framesChecked": Double(l.framesChecked)]
            if let f = l.agreeingFraction { values["agreeingFraction"] = f }
            gates.append(AnalysisGate(.legIdentity, passed: nil, "\(l.outcome.rawValue) — \(l.explanation)", values))
        }
        if let timeline, !timeline.samples.isEmpty {
            let sides = KickingSideJoints(kickingFoot: kickingFoot)
            func coverage(_ j: PoseJoint) -> Double {
                Double(timeline.samples.filter { $0.point(j) != nil }.count) / Double(timeline.samples.count)
            }
            let values = ["kickingKnee": coverage(sides.kickingKnee), "kickingAnkle": coverage(sides.kickingAnkle),
                          "plantKnee": coverage(sides.plantKnee), "plantAnkle": coverage(sides.plantAnkle),
                          "hips": min(coverage(.leftHip), coverage(.rightHip))]
            let legs = values["kickingAnkle"] ?? 0
            gates.append(AnalysisGate(.jointCoverage, passed: legs >= 0.5,
                                      String(format: "kicking ankle in %.0f%% of kicker frames, plant ankle %.0f%%", legs * 100, (values["plantAnkle"] ?? 0) * 100),
                                      values))
        }
        guard let phases else { return gates }
        let windows = phases.kickWindows
        let selected = windows?.selected
        var windowValues: [String: Double] = ["windows": Double(windows?.windows.count ?? 0),
                                              "withSwing": Double(windows?.windows.filter(\.hasSwing).count ?? 0)]
        if let w = selected { windowValues["score"] = w.score; windowValues["confidence"] = w.confidence; windowValues["approachPeak"] = w.approachPeakSpeed }
        gates.append(AnalysisGate(.kickWindow, passed: selected != nil && windows?.needsSelection != true,
                                  selected.map { String(format: "%@ window %.2f–%.2f s%@", $0.source, $0.preparationStart, $0.movementEnd,
                                                        windows?.needsSelection == true ? " · several kicks, choose one" : "") }
                                      ?? "no kick window: \(windows?.notes.last ?? "no run-up followed by a kicking swing")",
                                  windowValues))
        for (gate, phase) in [(AnalysisGate.Name.approach, KickPhase.approach), (.plant, .plant), (.contact, .contact), (.followThrough, .followThrough)] {
            let p = phases.phase(phase)
            var values: [String: Double] = ["confidence": p.confidence]
            if let t = p.representativeTime { values["time"] = t }
            var detail = p.status.rawValue
            if phase == .contact, let method = phases.evidence?.contactTimingMethodResolved { detail += " · method \(method)" }
            if phase == .contact, let n = phases.evidence?.contactCandidates?.count { values["candidates"] = Double(n) }
            if phase == .plant, let state = phases.evidence?.plantState { detail += " · \(state.rawValue)" }
            if phase == .followThrough, let basis = phases.evidence?.followThroughBasis { detail += " · from \(basis)" }
            gates.append(AnalysisGate(gate, passed: phase == .contact ? (p.isAvailable && p.status != .ambiguous) : nil, detail, values))
        }
        if let measurements {
            let available = measurements.filter(\.isAvailable).count
            var reasons: [String: Int] = [:]
            for m in measurements where !m.isAvailable { reasons[m.unavailableReason?.rawValue ?? "unknown", default: 0] += 1 }
            let text = reasons.sorted { $0.key < $1.key }.map { "\($0.key) \($0.value)" }.joined(separator: ", ")
            gates.append(AnalysisGate(.metrics, passed: nil, "\(available) available\(text.isEmpty ? "" : " · unavailable: \(text)")",
                                      ["available": Double(available)].merging(reasons.mapValues(Double.init)) { a, _ in a }))
        }
        if let scored = scoredCategoryCount {
            gates.append(AnalysisGate(.scoring, passed: nil, "\(scored) categor\(scored == 1 ? "y" : "ies") scored", ["scored": Double(scored)]))
        }
        if let completion {
            gates.append(AnalysisGate(.completion, passed: completion.basis != .insufficient, "\(completion.basis.rawValue) — \(completion.detail)"))
        }
        return gates
    }

    /// The first gate that blocked completion.
    static func firstBlocking(_ gates: [AnalysisGate]) -> AnalysisGate? {
        gates.first { $0.passed == false }
    }
}
