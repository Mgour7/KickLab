import Foundation

/// Build 18, extended in Build 19 (engine 3.1.0): how well the KICKING ANKLE was followed
/// around and after contact, frame by frame. Diagnostics only — nothing here changes a
/// measurement (the detectors make their own decisions; this report explains them).
///
/// Identity state per frame:
/// - `measured`: detected with enough confidence, apart from the plant ankle;
/// - `inferred`: filled by short-gap interpolation or by repair (never shown as observed);
/// - `occluded`: overlapping the plant ankle but anatomically consistent (shank length
///   within 0.6–1.4× its usual length) — one foot hidden behind the other or a leg
///   crossing (projection); the label may be right but can't be confirmed;
/// - `ambiguous`: overlapping AND anatomically implausible (shank length off), or after
///   the detector found the label collapsed onto the plant foot — Vision put both ankles
///   on one foot;
/// - `unavailable`: not detected, below the confidence threshold, or in a gap too long to fill.
///
/// Each frame also records the ORIGINAL (detector) and PROCESSED (repaired / smoothed)
/// ankle position in app-normalized display coordinates, the detector's confidence, the
/// ankle separation and shank ratio, and the reason for its state.
struct KickingLegTrackingReport: Codable, Equatable, Sendable {
    enum State: String, Codable, Sendable { case measured, inferred, occluded, ambiguous, unavailable }

    struct Frame: Codable, Equatable, Sendable {
        var time: Double
        var state: State
        var reason: String
        var originalX: Double?
        var originalY: Double?
        var originalConfidence: Double?
        var processedX: Double?
        var processedY: Double?
        var separation: Double?
        var shankRatio: Double?
    }

    var windowStart: Double
    var windowEnd: Double
    var measured: Int
    var inferred: Int
    var occluded: Int
    var ambiguous: Int
    var unavailable: Int
    /// First occluded/ambiguous/unavailable frame after contact.
    var lostAt: Double?
    /// From contact until the kicking ankle was first lost (a lower bound on how long the
    /// follow-through was observed). Nil when it was never lost in the window.
    var trackedAfterContactSeconds: Double?
    /// Left/right leg labels exchanged back by `PoseLegRepair` inside the window.
    var labelSwapsRepaired: Int
    /// Short explanation of the most likely cause.
    var cause: String
    /// Phase decisions that followed from the tracking (identity loss, reappearance,
    /// follow-through observation).
    var phaseEffects: [String]
    var frameDetails: [Frame]
    /// "t S" per frame (M measured, I inferred, C occluded, A ambiguous, - unavailable).
    var frames: String

    /// Back-compat counts (Build 18 name).
    var overlapping: Int { occluded + ambiguous }

    var lines: [String] {
        var out = [String(format: "  kicking-leg tracking %.3f–%.3f s: measured %d · inferred %d · occluded %d · ambiguous %d · unavailable %d · label swaps repaired %d",
                          windowStart, windowEnd, measured, inferred, occluded, ambiguous, unavailable, labelSwapsRepaired)]
        if let lostAt {
            out.append(String(format: "    kicking ankle lost at %.3f s (tracked %.3f s after contact) — %@", lostAt, trackedAfterContactSeconds ?? 0, cause))
        } else {
            out.append("    kicking ankle followed through the whole window — \(cause)")
        }
        for e in phaseEffects { out.append("    effect: \(e)") }
        out.append("    frames (M measured, I inferred, C occluded, A ambiguous, - unavailable): \(frames)")
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        for f in frameDetails where f.state != .measured {
            out.append("      \(n(f.time)) \(f.state.rawValue): \(f.reason) · original (\(n(f.originalX)), \(n(f.originalY))) conf \(n(f.originalConfidence)) · processed (\(n(f.processedX)), \(n(f.processedY))) · separation \(n(f.separation)) · shank ×\(n(f.shankRatio))")
        }
        return out
    }

    static func make(timeline: KickerPoseTimeline?, signals: PoseSignalSet?, phases: KickPhaseDetectionResult?,
                     kickingFoot: KickingFoot, perspective: CameraPerspective?, swapSamples: [Int] = [],
                     sequence: PoseSequence? = nil) -> KickingLegTrackingReport? {
        guard let timeline, let signals, let contact = phases?.estimatedContactTime else { return nil }
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        let separation = signals.values(.ankleSeparation)
        let times = timeline.samples.map(\.timestamp)
        let aspect = timeline.displayAspectRatio ?? 1
        let window = times.indices.filter { times[$0] >= contact - 0.1 - 1e-9 && times[$0] <= contact + 0.6 + 1e-9 }
        guard !window.isEmpty else { return nil }
        let e = phases?.evidence
        let identityLost = e?.kickingAnkleIdentityLostTime

        // Usual 2D shank length (knee–ankle) over the clip, aspect-corrected.
        func shank(_ i: Int) -> Double? {
            guard let k = timeline.samples[i].point(sides.kickingKnee), let a = timeline.samples[i].point(sides.kickingAnkle) else { return nil }
            return hypot((k.x - a.x) * aspect, k.y - a.y)
        }
        let shanks = times.indices.compactMap(shank).sorted()
        let usualShank = shanks.isEmpty ? nil : shanks[shanks.count / 2]

        // Original detector output for the kicker.
        var original: [Double: PosePoint] = [:]
        if let sequence, let id = sequence.kickerTrackID {
            for f in sequence.frames {
                if let p = f.body(trackID: id)?.joints[sides.kickingAnkle] { original[ContactEstimator.round3(f.timestamp)] = p }
            }
        }

        var details: [Frame] = []
        for i in window {
            let t = times[i]
            let point = timeline.samples[i].joints[sides.kickingAnkle]
            let sep = separation.indices.contains(i) ? separation[i] : nil
            let ratio: Double? = {
                guard let s = shank(i), let u = usualShank else { return nil }
                return s / max(u, 1e-9)
            }()
            let orig = original[ContactEstimator.round3(t)]
            let state: State
            let reason: String
            if point == nil || point?.isAvailable == false {
                state = .unavailable
                reason = orig.map { $0.isAvailable ? "rejected (jump or low confidence) and not refilled" : "not detected" } ?? "not detected"
            } else if point?.status == .interpolated {
                state = .inferred
                reason = swapSamples.contains(i) ? "label swap repaired, then interpolated" : "filled by short-gap interpolation"
            } else if let s = sep, s <= KickPhaseDetector.ankleCollapseDistance {
                let collapsed = (identityLost.map { t >= $0 - 1e-6 } ?? false) || (ratio.map { $0 < 0.6 || $0 > 1.4 } ?? false)
                if collapsed {
                    state = .ambiguous
                    reason = identityLost.map { t >= $0 - 1e-6 } == true
                        ? "after the label collapsed onto the plant foot (abrupt stop, level with the plant ankle)"
                        : "overlapping the plant ankle with an implausible shank length: both labels on one foot"
                } else {
                    state = .occluded
                    reason = perspective?.isDepthView == true
                        ? "overlapping the plant ankle along the line of sight (projection); shank length consistent"
                        : "overlapping the plant ankle (leg crossing); shank length consistent"
                }
            } else if let lost = identityLost, t >= lost - 1e-6, (e?.kickingAnkleReappearedTime.map { t < $0 - 1e-6 } ?? true) {
                state = .ambiguous
                reason = "after the label collapsed onto the plant foot, before the foot was seen again"
            } else {
                state = .measured
                reason = swapSamples.contains(i) ? "left/right labels swapped back by repair" : "detected"
            }
            details.append(Frame(time: ContactEstimator.round3(t), state: state, reason: reason,
                                 originalX: orig.map { ContactEstimator.round3($0.x) }, originalY: orig.map { ContactEstimator.round3($0.y) },
                                 originalConfidence: orig.map { ContactEstimator.round3($0.confidence) },
                                 processedX: point.flatMap { $0.isAvailable ? ContactEstimator.round3($0.x) : nil },
                                 processedY: point.flatMap { $0.isAvailable ? ContactEstimator.round3($0.y) : nil },
                                 separation: sep.map(ContactEstimator.round3), shankRatio: ratio.map(ContactEstimator.round3)))
        }
        let lost = details.first { $0.time > contact + 1e-9 && [.occluded, .ambiguous, .unavailable].contains($0.state) }
        let swaps = swapSamples.filter { window.contains($0) }.count
        func count(_ s: State) -> Int { details.filter { $0.state == s }.count }
        let cause: String
        if lost == nil {
            cause = "no loss of identity"
        } else if count(.ambiguous) > 0 {
            cause = "both ankle labels sat on one foot (Vision; often motion blur at 30 fps) — not recoverable by interpolation; needs a higher frame rate, more light or a closer camera"
        } else if count(.occluded) > 0, perspective?.isDepthView == true {
            cause = "from behind or in front the kicking foot passes along the line of sight over the plant foot, so the two ankles overlap in the image (projection); identity can't be confirmed while they overlap"
        } else if count(.occluded) > 0 {
            cause = "the legs crossed in the image; identity can't be confirmed while they overlap"
        } else if count(.unavailable) > 0 {
            cause = "the kicking ankle wasn't detected (occluded, blurred or out of frame)"
        } else {
            cause = "identity ambiguous"
        }
        var effects: [String] = []
        if let l = identityLost { effects.append(String(format: "label collapse detected at %.3f s%@", l, l <= contact + 1e-6 ? " (at or before contact: kicking-leg values at contact withheld)" : "")) }
        if let r = e?.kickingAnkleReappearedTime { effects.append(String(format: "kicking foot seen again at %.3f s", r)) }
        if let o = e?.followThroughObservation.flatMap(FollowThroughObservation.init(rawValue:)) {
            effects.append("follow-through: \(o.title.lowercased())" + (e?.followThroughBasis.map { " (basis \($0))" } ?? ""))
        }
        if let k = e?.kneeSwingEndTime { effects.append(String(format: "kicking knee's swing relative to the hips ended at %.3f s", k)) }
        return KickingLegTrackingReport(
            windowStart: ContactEstimator.round3(times[window.first!]), windowEnd: ContactEstimator.round3(times[window.last!]),
            measured: count(.measured), inferred: count(.inferred), occluded: count(.occluded), ambiguous: count(.ambiguous),
            unavailable: count(.unavailable),
            lostAt: lost?.time, trackedAfterContactSeconds: lost.map { ContactEstimator.round3($0.time - contact) },
            labelSwapsRepaired: swaps,
            cause: swaps > 0 ? cause + "; \(swaps) left/right label swap(s) were repaired in this window" : cause,
            phaseEffects: effects, frameDetails: details,
            frames: details.map { f in
                let c: String = switch f.state {
                case .measured: "M"
                case .inferred: "I"
                case .occluded: "C"
                case .ambiguous: "A"
                case .unavailable: "-"
                }
                return String(format: "%.3f %@", f.time, c)
            }.joined(separator: " · ")
        )
    }
}
