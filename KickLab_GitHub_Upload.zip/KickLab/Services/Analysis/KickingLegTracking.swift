import Foundation

/// Build 18 (Biomechanics Intelligence 3.0): how well the KICKING ANKLE was followed around
/// and after contact, frame by frame. Diagnostics only — nothing here changes a measurement.
///
/// Every frame's kicking ankle is one of:
/// - `measured`: reported by pose detection with enough confidence, apart from the plant ankle;
/// - `inferred`: filled by short-gap interpolation (never reported as observed);
/// - `overlapping`: present, but within `KickPhaseDetector.ankleCollapseDistance` of the plant
///   ankle — the two labels can't be told apart, so its identity is ambiguous;
/// - `unavailable`: not detected, below the confidence threshold, or in a gap too long to fill.
///
/// From behind or in front, the kicking foot passes in front of (or behind) the plant foot
/// along the line of sight after contact, so its 2D position genuinely overlaps the plant
/// foot: that is projection, not necessarily a tracking error, and it can't be undone by
/// interpolation. The report says which explanation the evidence supports.
struct KickingLegTrackingReport: Codable, Equatable, Sendable {
    enum State: String, Codable, Sendable { case measured, inferred, overlapping, unavailable }

    var windowStart: Double
    var windowEnd: Double
    var measured: Int
    var inferred: Int
    var overlapping: Int
    var unavailable: Int
    /// First overlapping or unavailable frame after contact.
    var lostAt: Double?
    /// From contact until the kicking ankle was first lost (a lower bound on how long the
    /// follow-through was observed). Nil when it was never lost in the window.
    var trackedAfterContactSeconds: Double?
    /// Left/right leg labels exchanged back by `PoseLegRepair` inside the window.
    var labelSwapsRepaired: Int
    /// Short explanation of the most likely cause.
    var cause: String
    /// "t S" per frame (M measured, I inferred, O overlapping, - unavailable).
    var frames: String

    var lines: [String] {
        var out = [String(format: "  kicking-leg tracking %.3f–%.3f s: measured %d · inferred %d · overlapping the plant ankle %d · unavailable %d · label swaps repaired %d",
                          windowStart, windowEnd, measured, inferred, overlapping, unavailable, labelSwapsRepaired)]
        if let lostAt {
            out.append(String(format: "    kicking ankle lost at %.3f s (tracked %.3f s after contact) — %@", lostAt, trackedAfterContactSeconds ?? 0, cause))
        } else {
            out.append("    kicking ankle followed through the whole window — \(cause)")
        }
        out.append("    frames (M measured, I inferred, O overlapping, - unavailable): \(frames)")
        return out
    }

    static func make(timeline: KickerPoseTimeline?, signals: PoseSignalSet?, phases: KickPhaseDetectionResult?,
                     kickingFoot: KickingFoot, perspective: CameraPerspective?, swapSamples: [Int] = []) -> KickingLegTrackingReport? {
        guard let timeline, let signals, let contact = phases?.estimatedContactTime else { return nil }
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        let separation = signals.values(.ankleSeparation)
        let times = timeline.samples.map(\.timestamp)
        let window = times.indices.filter { times[$0] >= contact - 0.1 - 1e-9 && times[$0] <= contact + 0.6 + 1e-9 }
        guard !window.isEmpty else { return nil }
        var states: [(Double, State)] = []
        for i in window {
            let point = timeline.samples[i].joints[sides.kickingAnkle]
            let state: State
            if point == nil || point?.isAvailable == false {
                state = .unavailable
            } else if point?.status == .interpolated {
                state = .inferred
            } else if separation.indices.contains(i), let s = separation[i], s <= KickPhaseDetector.ankleCollapseDistance {
                state = .overlapping
            } else {
                state = .measured
            }
            states.append((times[i], state))
        }
        let lost = states.first { $0.0 > contact + 1e-9 && ($0.1 == .overlapping || $0.1 == .unavailable) }
        let swaps = swapSamples.filter { window.contains($0) }.count
        let overlapCount = states.filter { $0.1 == .overlapping }.count
        let unavailableCount = states.filter { $0.1 == .unavailable }.count
        let cause: String
        if lost == nil {
            cause = "no loss of identity"
        } else if overlapCount > 0, perspective?.isDepthView == true {
            cause = "from behind or in front the kicking foot passes along the line of sight over the plant foot, so the two ankles overlap in the image (projection); identity can't be recovered by interpolation"
        } else if overlapCount > 0 {
            cause = "both ankle labels sit on one foot (motion blur or a leg crossing); the follow-through foot isn't reported"
        } else if unavailableCount > 0 {
            cause = "the kicking ankle wasn't detected (occluded, blurred or out of frame)"
        } else {
            cause = "identity ambiguous"
        }
        return KickingLegTrackingReport(
            windowStart: ContactEstimator.round3(times[window.first!]), windowEnd: ContactEstimator.round3(times[window.last!]),
            measured: states.filter { $0.1 == .measured }.count, inferred: states.filter { $0.1 == .inferred }.count,
            overlapping: overlapCount, unavailable: unavailableCount,
            lostAt: lost.map { ContactEstimator.round3($0.0) },
            trackedAfterContactSeconds: lost.map { ContactEstimator.round3($0.0 - contact) },
            labelSwapsRepaired: swaps,
            cause: swaps > 0 ? cause + "; \(swaps) left/right label swap(s) were repaired in this window" : cause,
            frames: states.map { t, s in
                let c: String = switch s {
                case .measured: "M"
                case .inferred: "I"
                case .overlapping: "O"
                case .unavailable: "-"
                }
                return String(format: "%.3f %@", t, c)
            }.joined(separator: " · ")
        )
    }
}
