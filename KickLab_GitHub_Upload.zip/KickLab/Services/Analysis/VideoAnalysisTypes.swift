import Foundation

/// One video given to the analysis engine. Carries identity and the facts an engine
/// needs to schedule work; the engine resolves the file through `relativeFilePath`
/// (relative to the managed media root).
struct VideoAnalysisInput: Equatable, Sendable {
    let videoID: UUID
    let angle: VideoAngleType
    let isPrimary: Bool
    let relativeFilePath: String?
    let frameRate: Double?
    let durationSeconds: Double?
    /// Offset relative to the kick's primary video, for multi-angle synchronization.
    let syncOffsetSeconds: Double?
    /// Contact time within this video, if already marked.
    let contactTimeSeconds: Double?
}

/// Tuning knobs for an analysis run.
struct VideoAnalysisOptions: Equatable, Sendable {
    /// The athlete's kicking foot. Every left/right decision in the pose pipeline uses
    /// it; nothing assumes a right-footed kicker. `VideoAnalysisRequest.make` fills it
    /// from the athlete profile.
    var kickingFoot: KickingFoot
    /// A point on the kicker chosen by the user. When set it always wins over automatic selection.
    var kickerSeed: KickerSeed?
    /// Where the ball / kick happens in the primary video, if known; helps automatic selection.
    var kickLocationHint: NormalizedPoint?
    /// Which frames to analyze.
    var sampling: FrameSamplingPlan
    /// Writes artifacts to `Analysis/<id>/`. Pass the `BiomechanicsAnalysis.id` so the
    /// folder matches the record; defaults to the request ID.
    var artifactsDirectoryID: UUID?

    init(
        kickingFoot: KickingFoot = .right,
        kickerSeed: KickerSeed? = nil,
        kickLocationHint: NormalizedPoint? = nil,
        sampling: FrameSamplingPlan = .standard,
        artifactsDirectoryID: UUID? = nil
    ) {
        self.kickingFoot = kickingFoot
        self.kickerSeed = kickerSeed
        self.kickLocationHint = kickLocationHint
        self.sampling = sampling
        self.artifactsDirectoryID = artifactsDirectoryID
    }
}

/// Everything an engine needs to analyze one kick. Built from stored records by
/// `VideoAnalysisRequest.make(for:videos:)`, which guarantees every input belongs to the kick.
struct VideoAnalysisRequest: Equatable, Sendable, Identifiable {
    let id: UUID
    let kickID: UUID
    let kickType: KickType
    let inputs: [VideoAnalysisInput]
    let requestedAt: Date
    let options: VideoAnalysisOptions

    init(
        id: UUID = UUID(),
        kickID: UUID,
        kickType: KickType,
        inputs: [VideoAnalysisInput],
        requestedAt: Date = .now,
        options: VideoAnalysisOptions = VideoAnalysisOptions()
    ) {
        self.id = id
        self.kickID = kickID
        self.kickType = kickType
        self.inputs = inputs
        self.requestedAt = requestedAt
        self.options = options
    }

    var inputVideoIDs: [UUID] { inputs.map(\.videoID) }
}

/// The pipeline's coarse stages, in order.
enum VideoAnalysisStage: String, CaseIterable, Sendable {
    case preparing
    case extractingFrames
    case detectingPose
    case detectingEvents      // plant, contact, follow-through
    case measuring
    case scoring
    case finishing
}

/// A progress report. `fractionCompleted` is clamped to 0...1 (non-finite becomes 0).
struct VideoAnalysisProgress: Equatable, Sendable {
    let stage: VideoAnalysisStage
    let fractionCompleted: Double
    let message: String?

    init(stage: VideoAnalysisStage, fractionCompleted: Double, message: String? = nil) {
        self.stage = stage
        self.fractionCompleted = fractionCompleted.isFinite ? min(max(fractionCompleted, 0), 1) : 0
        self.message = message
    }
}

/// An input the engine cannot use, and why.
struct RejectedAnalysisInput: Equatable, Sendable {
    let videoID: UUID
    let reason: String
}

/// The outcome of `prepare`: what the engine will analyze, before any heavy work.
struct PreparedVideoAnalysis: Equatable, Sendable {
    let requestID: UUID
    let engineVersion: String
    let usableVideoIDs: [UUID]
    let rejectedInputs: [RejectedAnalysisInput]
    let estimatedFrameCount: Int?
}

/// The outcome of `analyze`, in the same draft types `AnalysisService` validates and
/// stores. An engine reports only what it actually measured; unmeasurable values are
/// `.unavailable` drafts, never invented numbers.
struct VideoAnalysisResult: Equatable, Sendable {
    let requestID: UUID
    let engineVersion: String
    let metrics: [MetricDraft]
    let categoryScores: [CategoryScoreDraft]
    let observations: [CoachingObservationDraft]
    /// 0...1
    let overallConfidence: Double?
    /// 0...100
    let overallScore: Double?
    /// Relative to the analysis root, if the engine wrote artifacts.
    let artifactsRelativePath: String?
    /// Operational facts from pose analysis (kicker selection, plant / estimated contact
    /// times, extraction confidence). Not metrics or scores. Nil for engines without pose.
    let poseSummary: PoseAnalysisSummary?

    init(
        requestID: UUID,
        engineVersion: String,
        metrics: [MetricDraft] = [],
        categoryScores: [CategoryScoreDraft] = [],
        observations: [CoachingObservationDraft] = [],
        overallConfidence: Double? = nil,
        overallScore: Double? = nil,
        artifactsRelativePath: String? = nil,
        poseSummary: PoseAnalysisSummary? = nil
    ) {
        self.requestID = requestID
        self.engineVersion = engineVersion
        self.metrics = metrics
        self.categoryScores = categoryScores
        self.observations = observations
        self.overallConfidence = overallConfidence
        self.overallScore = overallScore
        self.artifactsRelativePath = artifactsRelativePath
        self.poseSummary = poseSummary
    }
}

enum VideoAnalysisAvailability: Equatable, Sendable {
    case available
    case unavailable(reason: String)

    var isAvailable: Bool { self == .available }
}

enum VideoAnalysisError: Error, Equatable, Sendable, LocalizedError {
    /// No engine is installed, or it cannot run on this device.
    case unavailable(reason: String)
    case noInputs
    case noUsableInputs
    case cancelled
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let reason): reason
        case .noInputs, .noUsableInputs: "There's no usable video to analyze."
        case .cancelled: "The analysis was cancelled."
        case .failed: "The analysis failed."
        }
    }
}
