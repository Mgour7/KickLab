import Foundation

/// Errors thrown by `AnalysisService`.
enum AnalysisServiceError: Error, Equatable, Sendable, LocalizedError {
    case emptyAnalysisVersion
    case noInputVideos
    /// An input video is orphaned or belongs to another kick.
    case integrity([AnalysisIntegrityIssue])
    case analysisHasNoKick(analysisID: UUID)
    case invalidTransition(from: ProcessingStatus, to: ProcessingStatus)
    /// Only a completed analysis can be promoted to current.
    case notCompleted(status: ProcessingStatus)
    /// Results can be added only while processing; input videos only while queued or processing.
    /// Completed, failed and cancelled analyses are immutable.
    case analysisIsImmutable(status: ProcessingStatus)
    case invalidResult([AnalysisResultIssue])
    case emptyFailureReason
    case notInServiceContext
    /// `ModelContext.save()` failed. The context was rolled back; nothing was persisted.
    case persistenceFailed(String)

    var errorDescription: String? {
        switch self {
        case .emptyAnalysisVersion: "An analysis needs an engine version."
        case .noInputVideos: "An analysis needs at least one input video."
        case .integrity: "An input video doesn't belong to this kick."
        case .analysisHasNoKick: "This analysis isn't attached to a kick."
        case .invalidTransition(let from, let to): "An analysis can't go from \(from.displayName) to \(to.displayName)."
        case .notCompleted: "Only a completed analysis can be made current."
        case .analysisIsImmutable: "This analysis can no longer be changed. Run a new analysis instead."
        case .invalidResult: "The analysis result is invalid."
        case .emptyFailureReason: "A failed analysis needs a reason."
        case .notInServiceContext: "The record isn't available in this data context."
        case .persistenceFailed: "KickLab couldn't save the change."
        }
    }
}
