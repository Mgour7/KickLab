import Foundation

/// Why an analysis that ran (and usually found the kicker) could not score any phase of
/// the kick. Before Step 12A every one of these was reported as "Not enough of the kick
/// was visible", which was only true for `legJointsNotVisible`.
///
/// `reasonText` is stored as the analysis' failure reason, so it must never change once
/// shipped; `AnalysisProblem` maps it back to the right message.
enum AnalysisFailureCause: String, Codable, Sendable, CaseIterable {
    /// The kicker was followed in too little of the video.
    case kickerTrackTooShort
    /// Plant and/or contact — which most metrics need — weren't found.
    case kickPhasesNotFound
    /// Metrics were measured but fall below the confidence thresholds only because of the
    /// selected camera angle's penalty for 2D side-plane measurements.
    case cameraAngleLimited
    /// Pose confidence (Vision, frame rate) was too low for the metrics.
    case lowPoseConfidence
    /// Hips, knees or ankles weren't detected often enough.
    case legJointsNotVisible
    /// Some metrics were measured, but no phase had enough of them to be scored.
    case notEnoughScoredMetrics

    var reasonText: String {
        switch self {
        case .kickerTrackTooShort: "The kicker was followed in too little of the video to measure the kick."
        case .kickPhasesNotFound: "The plant and contact moments of the kick couldn't be found."
        case .cameraAngleLimited: "The selected camera angle limits what can be measured in this video."
        case .lowPoseConfidence: "Body-position detection was too uncertain to measure the kick."
        case .legJointsNotVisible: "The kicker's hips, knees or ankles weren't detected often enough."
        case .notEnoughScoredMetrics: "Some mechanics were measured, but not enough of any phase to score it."
        }
    }

    init?(reasonText: String) {
        guard let match = Self.allCases.first(where: { $0.reasonText == reasonText }) else { return nil }
        self = match
    }
}

/// Counts that explain an unscored analysis, and the cause they point to.
struct AnalysisFailureEvidence: Codable, Equatable, Sendable {
    /// Scored metrics (weight > 0, supported for the kick type) considered.
    var scoredMetricCount: Int
    var availableScoredMetrics: Int
    /// Unavailable because a required phase wasn't found.
    var blockedByMissingPhase: Int
    /// Unavailable because joints weren't visible often enough (or too few samples).
    var blockedByMissingJoints: Int
    /// Unavailable for low confidence, or available but below the scoring confidence.
    var blockedByConfidence: Int
    /// Of those, how many would clear their threshold without the camera-angle penalty.
    var rescuedWithoutCameraPenalty: Int
    var otherUnavailable: Int
    /// Fraction of analyzed frames in which the kicker was followed.
    var kickerTrackedFraction: Double
    var missingPhases: [KickPhase]
    var cameraFactor: Double
    /// Fraction of kicker samples with the kicking-ankle signal (phase detection's input).
    var kickingAnkleCoverage: Double
}

/// Pure diagnosis of an analysis' outcome. No thresholds are changed here: it only
/// explains which existing rule stopped the analysis.
enum AnalysisDiagnosis {
    /// Below this fraction of frames with the kicker, a lost track is the likely cause.
    static let minimumTrackedFraction = 0.4
    /// Below this kicking-ankle coverage, missing phases are really missing legs.
    static let minimumAnkleCoverage = 0.5

    static func evidence(
        measurements: [KickMetricMeasurement],
        categories: [CategoryScoreBreakdown],
        profile: BiomechanicsProfile,
        phases: KickPhaseDetectionResult,
        cameraAngle: VideoAngleType,
        kickerTrackedFraction: Double
    ) -> AnalysisFailureEvidence {
        let scored = measurements.filter {
            profile.supportedMetrics.contains($0.key) && (profile.scoring[$0.key]?.weight ?? 0) > 0
        }
        let excludedForScoring = Set(categories.flatMap(\.excluded).filter { $0.reason == .lowConfidence }.map(\.key))
        let cameraFactor = MetricConfidenceModel.cameraFactor(cameraAngle)
        var evidence = AnalysisFailureEvidence(
            scoredMetricCount: scored.count, availableScoredMetrics: 0, blockedByMissingPhase: 0,
            blockedByMissingJoints: 0, blockedByConfidence: 0, rescuedWithoutCameraPenalty: 0, otherUnavailable: 0,
            kickerTrackedFraction: kickerTrackedFraction, missingPhases: [], cameraFactor: cameraFactor,
            kickingAnkleCoverage: phases.dataCoverage
        )
        for m in scored {
            if m.isAvailable {
                evidence.availableScoredMetrics += 1
                if excludedForScoring.contains(m.key) {
                    evidence.blockedByConfidence += 1
                    if wouldPass(m.confidenceInputs, threshold: profile.minimumScoringConfidence) { evidence.rescuedWithoutCameraPenalty += 1 }
                }
                continue
            }
            switch m.unavailableReason {
            case .phaseUnavailable:
                evidence.blockedByMissingPhase += 1
            case .missingJoints, .insufficientSamples, .noKicker:
                evidence.blockedByMissingJoints += 1
            case .lowConfidence:
                evidence.blockedByConfidence += 1
                if wouldPass(m.confidenceInputs, threshold: profile.minimumMetricConfidence) { evidence.rescuedWithoutCameraPenalty += 1 }
            default:
                evidence.otherUnavailable += 1
            }
        }
        evidence.missingPhases = expectedPhases(for: phases).filter { phases.phase($0).status == .unavailable }
        return evidence
    }

    /// The phases metrics depend on for this kick type (setup is optional).
    static func expectedPhases(for phases: KickPhaseDetectionResult) -> [KickPhase] {
        switch phases.support {
        case .full: [.approach, .plant, .contact, .followThrough]
        case .limited: [.contact, .followThrough]
        case .unsupported: []
        }
    }

    /// True when the confidence would clear `threshold` if the camera factor were 1.
    static func wouldPass(_ inputs: MetricConfidenceInputs?, threshold: Double) -> Bool {
        guard let inputs, inputs.cameraFactor < 1, inputs.cameraFactor > 0 else { return false }
        return inputs.combined / inputs.cameraFactor >= threshold
    }

    /// The cause of an analysis that scored no category (nil when something was scored).
    ///
    /// Order: a lost kicker track first; then whichever blocker affected the most scored
    /// metrics (missing phases, then confidence, then joints on ties). Missing phases with
    /// a rarely seen kicking ankle are reported as legs not visible. Confidence is
    /// attributed to the camera angle when at least half the confidence-blocked metrics
    /// would clear their threshold without the angle penalty.
    static func cause(_ e: AnalysisFailureEvidence, scoredCategoryCount: Int) -> AnalysisFailureCause? {
        guard scoredCategoryCount == 0 else { return nil }
        let mostBlocked = max(e.blockedByMissingPhase, e.blockedByMissingJoints, e.blockedByConfidence)
        if e.kickerTrackedFraction < minimumTrackedFraction && mostBlocked > 0 { return .kickerTrackTooShort }
        if mostBlocked == 0 { return e.availableScoredMetrics > 0 ? .notEnoughScoredMetrics : .legJointsNotVisible }
        if e.blockedByMissingPhase == mostBlocked {
            // Phases are found from the kicking ankle; if it was rarely seen, say so.
            return e.kickingAnkleCoverage < minimumAnkleCoverage ? .legJointsNotVisible : .kickPhasesNotFound
        }
        if e.blockedByConfidence == mostBlocked {
            return e.cameraFactor < 1 && e.rescuedWithoutCameraPenalty * 2 >= e.blockedByConfidence ? .cameraAngleLimited : .lowPoseConfidence
        }
        return .legJointsNotVisible
    }
}

extension KickAnalysisPipelineOutput {
    /// Fraction of analyzed frames in which the selected kicker was followed.
    var kickerTrackedFraction: Double {
        let stats = sequence.confidenceStatistics
        let analyzed = stats.frameCount - stats.droppedFrameCount
        return analyzed > 0 ? Double(stats.framesWithKicker) / Double(analyzed) : 0
    }

    /// Why nothing could be scored, when the kicker was selected but no category scored.
    var failureCause: AnalysisFailureCause? {
        guard tracking.status == .selected else { return nil }
        let e = AnalysisDiagnosis.evidence(
            measurements: biomechanics.measurements, categories: biomechanics.categories,
            profile: biomechanics.profile, phases: phases, cameraAngle: biomechanics.context.cameraAngle,
            kickerTrackedFraction: kickerTrackedFraction
        )
        return AnalysisDiagnosis.cause(e, scoredCategoryCount: biomechanics.availableCategoryCount)
    }
}
