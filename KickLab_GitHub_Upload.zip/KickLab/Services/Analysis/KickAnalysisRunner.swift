import Foundation
import SwiftData

/// How a run ended. The analysis record is always saved in its final state.
enum KickAnalysisRunOutcome {
    /// A kicker was found and at least one mechanics category could be scored. Metrics,
    /// scores and coaching observations are stored, and the analysis is promoted to the
    /// kick's current analysis (`AnalysisService.promote`).
    case completed(BiomechanicsAnalysis, PoseAnalysisSummary?)
    /// The engine ran but could not analyze the kick (no kicker, several possible kickers,
    /// or too little of the kick visible to score). Artifacts, if written, stay attached
    /// for diagnosis; recorded (unavailable) metrics stay with the failed record.
    case failed(BiomechanicsAnalysis, reason: String, summary: PoseAnalysisSummary?)
    case cancelled(BiomechanicsAnalysis)

    var analysis: BiomechanicsAnalysis {
        switch self {
        case .completed(let analysis, _), .failed(let analysis, _, _), .cancelled(let analysis): analysis
        }
    }
}

/// Drives one analysis run end to end on the main actor, keeping SwiftData on the
/// main context and all heavy work inside the engine (off the main actor):
///
/// create (queued) → start (processing) → engine.analyze → attach artifacts →
/// record metrics, scores and observations (one validated save) →
/// completed + promoted | failed | cancelled.
@MainActor
struct KickAnalysisRunner {
    let analyses: AnalysisService
    let engine: any VideoAnalysisService
    /// Step 10: when set, each completed analysis also gets a personalization snapshot.
    let personalization: PersonalizationRecorder?

    init(analyses: AnalysisService, engine: any VideoAnalysisService, personalization: PersonalizationRecorder? = nil) {
        self.analyses = analyses
        self.engine = engine
        self.personalization = personalization
    }

    /// - Throws: `VideoAnalysisError.unavailable` before creating any record when the
    ///   engine can't run; `AnalysisServiceError` for invalid input or save failures.
    func run(
        kick: Kick,
        videos: [VideoAsset],
        options: VideoAnalysisOptions = VideoAnalysisOptions(),
        progress: @escaping @Sendable (VideoAnalysisProgress) -> Void = { _ in }
    ) async throws -> KickAnalysisRunOutcome {
        if case .unavailable(let reason) = engine.availability {
            throw VideoAnalysisError.unavailable(reason: reason)
        }

        // Step 12D: a user-assisted run is a NEW analysis labeled "+assisted"; earlier
        // automatic analyses are never changed.
        let version = AnalysisAssistanceLabel.version(engine.engineVersion, assistance: options.assistance)
        let analysis = try analyses.createAnalysis(for: kick, analysisVersion: version, inputVideos: videos)
        var runOptions = options
        runOptions.artifactsDirectoryID = analysis.id
        let request = try VideoAnalysisRequest.make(for: kick, videos: videos, options: runOptions)
        try analyses.startProcessing(analysis)

        let result: VideoAnalysisResult
        do {
            result = try await engine.analyze(request, progress: progress)
        } catch {
            if error is CancellationError || (error as? VideoAnalysisError) == .cancelled || Task.isCancelled {
                try analyses.cancel(analysis)
                return .cancelled(analysis)
            }
            let reason = (error as? VideoAnalysisError).map(Self.failureReason) ?? "The analysis failed."
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: nil)
        }

        if let path = result.artifactsRelativePath {
            try analyses.attachArtifacts(relativePath: path, to: analysis)
        }

        if let summary = result.poseSummary, summary.kickerStatus != .selected {
            let reason = Self.reason(for: summary.kickerStatus)
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: summary)
        }

        do {
            try analyses.recordResults(
                metrics: result.metrics, categoryScores: result.categoryScores,
                observations: result.observations, to: analysis
            )
        } catch AnalysisServiceError.invalidResult {
            let reason = "The analysis produced results that failed validation."
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: result.poseSummary)
        }

        guard Self.isSufficient(result) else {
            // Step 12A: store the specific cause, not one catch-all message.
            let reason = result.poseSummary?.failureCause?.reasonText ?? Self.insufficientDataReason
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: result.poseSummary)
        }

        try analyses.markCompleted(analysis, confidence: result.overallConfidence, overallScore: result.overallScore)
        try analyses.promote(analysis)
        // What KickLab knew about the athlete at this moment (never fails the analysis).
        personalization?.record(analysis)
        return .completed(analysis, result.poseSummary)
    }

    static let insufficientDataReason = AnalysisFailureReasons.insufficientData

    /// A result can stand as a completed analysis when at least one mechanics category
    /// (not just the overall) has a score.
    static func isSufficient(_ result: VideoAnalysisResult) -> Bool {
        result.categoryScores.contains { $0.category != .overall && $0.score != nil && $0.measurementStatus != .unavailable }
    }

    static func reason(for status: KickerSelectionStatus) -> String {
        switch status {
        case .selected: "Kicker identified."
        case .ambiguous: "Multiple possible kickers found. Choose the kicker and run the analysis again."
        case .noCandidates: "No clearly visible person was found in the video."
        case .seedNotMatched: "No person was found where the kicker was marked."
        }
    }

    static func failureReason(_ error: VideoAnalysisError) -> String {
        switch error {
        case .failed(let detail): "The analysis failed: \(detail)"
        default: error.errorDescription ?? "The analysis failed."
        }
    }
}
