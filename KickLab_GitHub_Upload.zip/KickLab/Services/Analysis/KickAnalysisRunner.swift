import Foundation
import SwiftData

/// How a run ended. The analysis record is always saved in its final state.
enum KickAnalysisRunOutcome {
    /// Pose foundation finished and a kicker was found. Not promoted to current:
    /// it has no metrics yet; callers decide when to promote.
    case completed(BiomechanicsAnalysis, PoseAnalysisSummary?)
    /// The engine ran but could not analyze the kick (e.g. no kicker or several possible
    /// kickers). Artifacts, if written, stay attached for diagnosis.
    case failed(BiomechanicsAnalysis, reason: String, summary: PoseAnalysisSummary?)
    case cancelled(BiomechanicsAnalysis)

    var analysis: BiomechanicsAnalysis {
        switch self {
        case .completed(let analysis, _), .failed(let analysis, _, _), .cancelled(let analysis): analysis
        }
    }
}

/// Drives one analysis run end to end on the main actor, keeping SwiftData on the
/// main context and all heavy work inside the engine (off the main actor):
///
/// create (queued) → start (processing) → engine.analyze → attach artifacts →
/// completed | failed | cancelled.
@MainActor
struct KickAnalysisRunner {
    let analyses: AnalysisService
    let engine: any VideoAnalysisService

    init(analyses: AnalysisService, engine: any VideoAnalysisService) {
        self.analyses = analyses
        self.engine = engine
    }

    /// - Throws: `VideoAnalysisError.unavailable` before creating any record when the
    ///   engine can't run; `AnalysisServiceError` for invalid input or save failures.
    func run(
        kick: Kick,
        videos: [VideoAsset],
        options: VideoAnalysisOptions = VideoAnalysisOptions(),
        progress: @escaping @Sendable (VideoAnalysisProgress) -> Void = { _ in }
    ) async throws -> KickAnalysisRunOutcome {
        if case .unavailable(let reason) = engine.availability {
            throw VideoAnalysisError.unavailable(reason: reason)
        }

        let analysis = try analyses.createAnalysis(for: kick, analysisVersion: engine.engineVersion, inputVideos: videos)
        var runOptions = options
        runOptions.artifactsDirectoryID = analysis.id
        let request = try VideoAnalysisRequest.make(for: kick, videos: videos, options: runOptions)
        try analyses.startProcessing(analysis)

        let result: VideoAnalysisResult
        do {
            result = try await engine.analyze(request, progress: progress)
        } catch {
            if error is CancellationError || (error as? VideoAnalysisError) == .cancelled || Task.isCancelled {
                try analyses.cancel(analysis)
                return .cancelled(analysis)
            }
            let reason = (error as? VideoAnalysisError).map(Self.failureReason) ?? "The analysis failed."
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: nil)
        }

        if let path = result.artifactsRelativePath {
            try analyses.attachArtifacts(relativePath: path, to: analysis)
        }

        if let summary = result.poseSummary, summary.kickerStatus != .selected {
            let reason = Self.reason(for: summary.kickerStatus)
            try analyses.markFailed(analysis, reason: reason)
            return .failed(analysis, reason: reason, summary: summary)
        }

        try analyses.markCompleted(analysis, confidence: result.overallConfidence, overallScore: result.overallScore)
        return .completed(analysis, result.poseSummary)
    }

    static func reason(for status: KickerSelectionStatus) -> String {
        switch status {
        case .selected: "Kicker identified."
        case .ambiguous: "Multiple possible kickers found. Choose the kicker and run the analysis again."
        case .noCandidates: "No clearly visible person was found in the video."
        case .seedNotMatched: "No person was found where the kicker was marked."
        }
    }

    static func failureReason(_ error: VideoAnalysisError) -> String {
        switch error {
        case .failed(let detail): "The analysis failed: \(detail)"
        default: error.errorDescription ?? "The analysis failed."
        }
    }
}
