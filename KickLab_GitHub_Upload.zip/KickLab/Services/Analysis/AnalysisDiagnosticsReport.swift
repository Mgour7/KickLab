import Foundation

// Developer diagnostics for one analysis (Step 12A).
//
// Privacy: the report holds counts, confidences, times, statuses and reasons only — no
// images, no joint coordinates, no names, no athlete or kick identifiers. It is built on
// the iPhone from the analysis files already stored there and is only shared if the
// person chooses to share it.

struct DiagnosticsJointStats: Codable, Equatable, Sendable {
    var joint: PoseJoint
    /// "kicking" or "plant" (from the kicking foot), or nil.
    var role: String?
    /// Frames where the kicker was followed and Vision reported this joint.
    var detectedFrames: Int
    /// Of those, frames at or above the processing confidence threshold.
    var usableFrames: Int
    var meanConfidence: Double?
    var medianConfidence: Double?
    /// After processing: measured / interpolated / unavailable samples.
    var measuredSamples: Int
    var interpolatedSamples: Int
    var unavailableSamples: Int
}

struct DiagnosticsPhase: Codable, Equatable, Sendable {
    var phase: KickPhase
    var status: PhaseDetectionStatus
    var time: Double?
    var start: Double?
    var end: Double?
    var confidence: Double
}

struct DiagnosticsMetric: Codable, Equatable, Sendable {
    var key: String
    var name: String
    var available: Bool
    var value: Double?
    var unit: String
    var confidence: Double?
    var unavailableReason: String?
    var missingPhase: KickPhase?
    var jointQuality: Double?
    var jointCoverage: Double?
    var phaseFactor: Double?
    var sampleFactor: Double?
    var frameRateFactor: Double?
    var cameraFactor: Double?
    /// Would clear the reporting threshold if the camera-angle factor were 1.
    var limitedByCameraAngle: Bool
    /// Counts toward a category score (weight > 0).
    var scored: Bool
}

struct DiagnosticsCategory: Codable, Equatable, Sendable {
    var category: AnalysisCategory
    var score: Double?
    var confidence: Double?
    var status: MeasurementStatus
    var availableWeightFraction: Double
    var scoredComponents: Int
    /// "metric: reason" for each metric left out of the score.
    var excluded: [String]
}

struct AnalysisDiagnosticsReport: Codable, Equatable, Sendable {
    /// 1: Step 12A. 2: Step 12B adds detection evidence, leg repair, a replay of the
    /// current detector, the time series and the contact check (all optional).
    static let formatVersion = 2

    var formatVersion: Int = AnalysisDiagnosticsReport.formatVersion
    var generatedAt: Date
    var appVersion: String?
    var engineVersion: String?

    // Configuration
    var kickType: KickType
    var kickingFoot: KickingFoot?
    var cameraAngle: VideoAngleType?
    var manualKickerSelection: Bool?

    // Video and sampling
    var videoDurationSeconds: Double?
    var nominalFrameRate: Double?
    var targetAnalysisFrameRate: Double?
    var measuredAnalysisFrameRate: Double?
    var orientation: String?
    var isMirrored: Bool?

    // Detection and tracking
    var framesSampled: Int?
    var framesVisionFailed: Int?
    var framesWithPerson: Int?
    var framesWithMultiplePeople: Int?
    var maximumPeopleInFrame: Int?
    var kickerStatus: KickerSelectionStatus?
    var kickerSelectionMethod: KickerSelectionMethod?
    var kickerTrackConfidence: Double?
    var kickerCandidates: Int?
    var framesWithKicker: Int?
    var kickerTrackedFraction: Double?
    var processingMinimumJointConfidence: Double?
    var joints: [DiagnosticsJointStats]

    // Phases, metrics, scores
    var phaseSupport: KickPhaseSupport?
    var phases: [DiagnosticsPhase]
    var phaseNotes: [String]
    var bodyScaleAvailable: Bool?
    var metrics: [DiagnosticsMetric]
    var categories: [DiagnosticsCategory]
    var overallScore: Double?
    var scoredCategoryCount: Int?

    // Thresholds in force
    var minimumMetricConfidence: Double?
    var minimumScoringConfidence: Double?
    var minimumCategoryWeightFraction: Double?
    var minimumCategoryConfidence: Double?

    // Outcome
    var storedStatus: String
    var storedFailureReason: String?
    var failureCause: AnalysisFailureCause?
    var evidence: AnalysisFailureEvidence?
    /// Plain-language factors that lowered confidence or blocked metrics.
    var contributingFactors: [String]
    /// True when the analysis files were available; false = summary only.
    var hasAnalysisFiles: Bool

    // Step 12B
    /// What the stored phase detection measured (nil for analyses made before Step 12B).
    var detectionEvidence: PhaseDetectionEvidence? = nil
    /// The current build's detector and scoring re-run on the stored pose.
    var replay: DiagnosticsReplay? = nil
    /// Per-sample signals and candidate events (from the replay when available).
    var timeSeries: DiagnosticsTimeSeries? = nil
    /// Estimated contact vs. a contact time marked on the video.
    var contactCheck: ContactTimingCheck? = nil
}

/// Everything the builder reads. Built from stored artifacts or from a fresh pipeline run.
struct AnalysisDiagnosticsInput: Sendable {
    var kickType: KickType
    var engineVersion: String?
    var sampling: FrameSamplingPlan?
    var processing: PoseProcessingConfiguration?
    var sequence: PoseSequence?
    var tracking: KickerTrackingResult?
    var kickerTimeline: KickerPoseTimeline?
    var signals: PoseSignalSet?
    var phases: KickPhaseDetectionResult?
    var context: BiomechanicsContext?
    var profile: BiomechanicsProfile?
    var measurements: [KickMetricMeasurement]?
    var categories: [CategoryScoreBreakdown]?
    var cameraAngle: VideoAngleType?

    /// From the stored analysis files.
    init(bundle: AnalysisArtifactBundle) {
        kickType = bundle.manifest.kickType
        engineVersion = bundle.manifest.engineVersion
        sampling = bundle.pose.sampling
        processing = bundle.pose.processingConfiguration
        sequence = bundle.pose.sequence
        tracking = bundle.pose.tracking
        kickerTimeline = bundle.pose.kickerTimeline
        signals = bundle.signals.signals
        phases = bundle.phases.phases
        context = bundle.biomechanics?.context
        profile = bundle.biomechanics?.profile
        measurements = bundle.biomechanics?.measurements
        categories = bundle.biomechanics?.categories
        cameraAngle = bundle.biomechanics?.context.cameraAngle
            ?? bundle.manifest.videos.first(where: \.isPrimary)?.angle
    }

    /// From a pipeline run (tests, or diagnostics before anything is stored).
    init(output: KickAnalysisPipelineOutput, sampling: FrameSamplingPlan? = nil,
         processing: PoseProcessingConfiguration = .standard, engineVersion: String? = nil) {
        kickType = output.phases.kickType
        self.engineVersion = engineVersion
        self.sampling = sampling
        self.processing = processing
        sequence = output.sequence
        tracking = output.tracking
        kickerTimeline = output.kickerTimeline
        signals = output.signals
        phases = output.phases
        context = output.biomechanics.context
        profile = output.biomechanics.profile
        measurements = output.biomechanics.measurements
        categories = output.biomechanics.categories
        cameraAngle = output.biomechanics.context.cameraAngle
    }

    /// Nothing stored (e.g. the analysis stopped before measuring).
    init(kickType: KickType, engineVersion: String?, cameraAngle: VideoAngleType?) {
        self.kickType = kickType
        self.engineVersion = engineVersion
        self.cameraAngle = cameraAngle
    }
}

enum AnalysisDiagnosticsBuilder {
    /// Hips, knees and ankles (plus shoulders, which define the body scale).
    static let reportedJoints: [PoseJoint] = [
        .leftShoulder, .rightShoulder, .leftHip, .rightHip, .leftKnee, .rightKnee, .leftAnkle, .rightAnkle,
    ]

    static func build(
        _ input: AnalysisDiagnosticsInput,
        storedStatus: String,
        storedFailureReason: String?,
        kickingFoot: KickingFoot?,
        appVersion: String?,
        generatedAt: Date,
        referenceContactTime: Double? = nil
    ) -> AnalysisDiagnosticsReport {
        let foot = input.context?.kickingFoot ?? input.signals?.kickingFoot ?? kickingFoot
        var report = AnalysisDiagnosticsReport(
            generatedAt: generatedAt, appVersion: appVersion, engineVersion: input.engineVersion,
            kickType: input.kickType, kickingFoot: foot, cameraAngle: input.cameraAngle,
            manualKickerSelection: input.tracking.map { $0.method == .manualSeed },
            joints: [], phases: [], phaseNotes: [], metrics: [], categories: [],
            minimumMetricConfidence: input.profile?.minimumMetricConfidence,
            minimumScoringConfidence: input.profile?.minimumScoringConfidence,
            minimumCategoryWeightFraction: input.profile?.minimumCategoryWeightFraction,
            minimumCategoryConfidence: input.profile?.minimumCategoryConfidence,
            storedStatus: storedStatus, storedFailureReason: storedFailureReason,
            contributingFactors: [], hasAnalysisFiles: input.sequence != nil
        )

        if let sequence = input.sequence {
            let stats = sequence.confidenceStatistics
            let analyzed = stats.frameCount - stats.droppedFrameCount
            report.videoDurationSeconds = sequence.durationSeconds
            report.nominalFrameRate = sequence.nominalFrameRate
            report.targetAnalysisFrameRate = input.sampling?.targetFrameRate ?? sequence.analysisFrameRate
            report.measuredAnalysisFrameRate = measuredFrameRate(sequence.frames.map(\.timestamp))
            report.orientation = sequence.orientation.rawValue
            report.isMirrored = sequence.isMirrored
            report.framesSampled = stats.frameCount
            report.framesVisionFailed = stats.droppedFrameCount
            report.framesWithPerson = stats.framesWithBodies
            report.framesWithMultiplePeople = sequence.frames.filter { $0.bodies.count > 1 }.count
            report.maximumPeopleInFrame = sequence.frames.map(\.bodies.count).max() ?? 0
            report.framesWithKicker = stats.framesWithKicker
            report.kickerTrackedFraction = analyzed > 0 ? round3(Double(stats.framesWithKicker) / Double(analyzed)) : 0
            report.joints = jointStats(sequence: sequence, timeline: input.kickerTimeline,
                                       threshold: input.processing?.minimumJointConfidence ?? PoseProcessingConfiguration.standard.minimumJointConfidence,
                                       foot: foot)
        }
        report.processingMinimumJointConfidence = input.processing?.minimumJointConfidence
        if let tracking = input.tracking {
            report.kickerStatus = tracking.status
            report.kickerSelectionMethod = tracking.method
            report.kickerTrackConfidence = round3(tracking.confidence)
            report.kickerCandidates = tracking.candidates.count
        }
        if let phases = input.phases {
            report.phaseSupport = phases.support
            report.phases = diagnosticsPhases(phases)
            report.phaseNotes = phases.notes
            report.detectionEvidence = phases.evidence
        }
        // Step 12B: re-run the current detector on the stored pose, and export signals.
        if let replayed = DiagnosticsReplay.run(input, kickingFoot: foot) {
            report.replay = replayed.replay
            report.timeSeries = .make(source: "replay", signals: replayed.signals, repair: replayed.replay.repair, phases: replayed.phases)
        } else if let signals = input.signals, !signals.timestamps.isEmpty {
            report.timeSeries = .make(source: "stored", signals: signals, repair: nil, phases: input.phases)
        }
        if let reference = referenceContactTime {
            let estimate = report.replay.map { r in r.phases.first { $0.phase == .contact && $0.status != .unavailable }?.time }
                ?? input.phases?.estimatedContactTime
            report.contactCheck = ContactTimingCheck(referenceTime: reference, estimatedTime: estimate,
                                                     framesPerSecond: report.measuredAnalysisFrameRate)
        }
        report.bodyScaleAvailable = input.signals.map { $0.bodyScale != nil }

        if let measurements = input.measurements, let profile = input.profile {
            report.metrics = measurements.map { m in
                let i = m.confidenceInputs
                let threshold = m.isAvailable ? profile.minimumScoringConfidence : profile.minimumMetricConfidence
                return DiagnosticsMetric(
                    key: m.key.rawValue, name: m.key.definition.displayName, available: m.isAvailable,
                    value: m.value, unit: m.unit.rawValue, confidence: m.confidence,
                    unavailableReason: m.unavailableReason?.rawValue, missingPhase: m.missingPhase,
                    jointQuality: i.map { round3($0.jointQuality) }, jointCoverage: i.map { round3($0.jointCoverage) },
                    phaseFactor: i?.phaseFactor, sampleFactor: i.map { round3($0.sampleFactor) },
                    frameRateFactor: i.map { round3($0.frameRateFactor) }, cameraFactor: i?.cameraFactor,
                    limitedByCameraAngle: (m.unavailableReason == .lowConfidence || (m.confidence ?? 1) < threshold)
                        && AnalysisDiagnosis.wouldPass(i, threshold: threshold),
                    scored: (profile.scoring[m.key]?.weight ?? 0) > 0 && profile.supportedMetrics.contains(m.key)
                )
            }
        }
        if let categories = input.categories {
            report.categories = categories.filter { $0.category != .overall }.map { c in
                DiagnosticsCategory(
                    category: c.category, score: c.score, confidence: c.confidence, status: c.status,
                    availableWeightFraction: round3(c.availableWeightFraction), scoredComponents: c.components.count,
                    excluded: c.excluded.map { "\($0.key.definition.displayName): \($0.reason.rawValue)" }
                )
            }
            report.overallScore = categories.first { $0.category == .overall }?.score
            report.scoredCategoryCount = categories.filter { $0.category != .overall && $0.score != nil }.count
        }

        if let measurements = input.measurements, let categories = input.categories, let profile = input.profile,
           let phases = input.phases, let angle = input.cameraAngle {
            let evidence = AnalysisDiagnosis.evidence(
                measurements: measurements, categories: categories, profile: profile, phases: phases,
                cameraAngle: angle, kickerTrackedFraction: report.kickerTrackedFraction ?? 0
            )
            report.evidence = evidence
            if input.tracking?.status == .selected {
                report.failureCause = AnalysisDiagnosis.cause(evidence, scoredCategoryCount: report.scoredCategoryCount ?? 0)
            }
        }
        if report.failureCause == nil, let reason = storedFailureReason {
            report.failureCause = AnalysisFailureCause(reasonText: reason)
        }
        report.contributingFactors = factors(report)
        return report
    }

    // MARK: Helpers

    static func round3(_ x: Double) -> Double { (x * 1000).rounded() / 1000 }

    static func diagnosticsPhases(_ phases: KickPhaseDetectionResult) -> [DiagnosticsPhase] {
        phases.phases.map {
            DiagnosticsPhase(phase: $0.phase, status: $0.status, time: $0.representativeTime.map(round3),
                             start: $0.startTime.map(round3), end: $0.endTime.map(round3), confidence: round3($0.confidence))
        }
    }

    static func measuredFrameRate(_ times: [Double]) -> Double? {
        var gaps: [Double] = []
        for i in times.indices.dropFirst() where times[i] > times[i - 1] { gaps.append(times[i] - times[i - 1]) }
        gaps.sort()
        guard !gaps.isEmpty else { return nil }
        return round3(1 / gaps[gaps.count / 2])
    }

    static func jointStats(sequence: PoseSequence, timeline: KickerPoseTimeline?, threshold: Double, foot: KickingFoot?) -> [DiagnosticsJointStats] {
        let kickerBodies = sequence.kickerTrackID.map { id in sequence.frames.compactMap { $0.body(trackID: id) } } ?? []
        let sides = foot.map(KickingSideJoints.init(kickingFoot:))
        return reportedJoints.map { joint in
            let confidences = kickerBodies.compactMap { body -> Double? in
                guard let p = body.joints[joint], p.isAvailable, p.confidence > 0 else { return nil }
                return p.confidence
            }
            let sorted = confidences.sorted()
            let processed = (timeline?.samples ?? []).map { $0.joints[joint]?.status ?? .unavailable }
            var role: String?
            if let sides {
                if [sides.kickingHip, sides.kickingKnee, sides.kickingAnkle, sides.kickingShoulder].contains(joint) { role = "kicking" }
                if [sides.plantHip, sides.plantKnee, sides.plantAnkle, sides.plantShoulder].contains(joint) { role = "plant" }
            }
            return DiagnosticsJointStats(
                joint: joint, role: role, detectedFrames: confidences.count,
                usableFrames: confidences.filter { $0 >= threshold }.count,
                meanConfidence: confidences.isEmpty ? nil : round3(confidences.reduce(0, +) / Double(confidences.count)),
                medianConfidence: sorted.isEmpty ? nil : round3(sorted[sorted.count / 2]),
                measuredSamples: processed.filter { $0 == .measured }.count,
                interpolatedSamples: processed.filter { $0 == .interpolated }.count,
                unavailableSamples: processed.filter { $0 == .unavailable }.count
            )
        }
    }

    /// Plain-language reasons, most important first.
    static func factors(_ r: AnalysisDiagnosticsReport) -> [String] {
        var out: [String] = []
        if let cause = r.failureCause { out.append(cause.reasonText) }
        if r.hasAnalysisFiles == false {
            out.append("No analysis files were stored (the run stopped before measuring); only the stored reason is available.")
        }
        if let status = r.kickerStatus, status != .selected { out.append("Kicker selection: \(status.rawValue).") }
        if let fraction = r.kickerTrackedFraction, fraction < AnalysisDiagnosis.minimumTrackedFraction, r.kickerStatus == .selected {
            out.append("The kicker was followed in only \(Int((fraction * 100).rounded()))% of analyzed frames.")
        }
        let missing = r.phases.filter { $0.status == .unavailable && $0.phase != .setup }.map(\.phase.rawValue)
        if !missing.isEmpty { out.append("Phases not found: \(missing.joined(separator: ", ")).") }
        if let angle = r.cameraAngle {
            let factor = MetricConfidenceModel.cameraFactor(angle)
            if factor < 1 {
                out.append("Camera angle '\(angle.rawValue)' multiplies the confidence of position and angle metrics by \(factor).")
            }
        }
        if let fps = r.measuredAnalysisFrameRate {
            let factor = MetricConfidenceModel.frameRateFactor(framesPerSecond: fps)
            if factor < 1 {
                out.append("Analysis frame rate \(Int(fps.rounded())) fps multiplies the confidence of kicking-leg contact metrics by \(round3(factor)).")
            }
        }
        let legs = r.joints.filter { [.leftKnee, .rightKnee, .leftAnkle, .rightAnkle].contains($0.joint) }
        let means = legs.compactMap(\.meanConfidence)
        if !means.isEmpty {
            let mean = round3(means.reduce(0, +) / Double(means.count))
            out.append("Mean Vision confidence of knees and ankles: \(mean).")
        }
        if let threshold = r.processingMinimumJointConfidence {
            for j in legs where j.detectedFrames > 0 && Double(j.usableFrames) < 0.5 * Double(j.detectedFrames) {
                out.append("\(j.joint.rawValue)\(j.role.map { " (\($0))" } ?? ""): below \(threshold) confidence in most frames.")
            }
        }
        if let repair = r.replay?.repair, repair.changedAnything {
            out.append("Leg repair: \(repair.legSwapSamples.count) sample(s) with left/right knee–ankle labels swapped back, \(repair.outlierPoints) knee/ankle jump(s) rejected.")
        }
        if let replay = r.replay, replay.differsFromStored {
            out.append("The current detector finds different phases on this stored pose (see Replay): \(replay.scoredCategoryCount) scored categor\(replay.scoredCategoryCount == 1 ? "y" : "ies") instead of \(r.scoredCategoryCount ?? 0).")
        }
        if let check = r.contactCheck, let error = check.errorSeconds, !check.withinTolerance {
            out.append(String(format: "Estimated contact is %.3f s %@ the marked contact.", abs(error), error > 0 ? "after" : "before"))
        }
        if r.bodyScaleAvailable == false { out.append("No body scale (shoulders and hips not seen together), so size and speed metrics are unavailable.") }
        let cameraLimited = r.metrics.filter(\.limitedByCameraAngle).count
        if cameraLimited > 0 { out.append("\(cameraLimited) metric(s) would clear their confidence threshold without the camera-angle factor.") }
        return out
    }
}

extension AnalysisDiagnosticsReport {
    /// JSON for sharing (stable key order, readable).
    func json() -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        encoder.nonConformingFloatEncodingStrategy = .convertToString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        return (try? encoder.encode(self)).flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
    }

    /// A readable summary, followed by the full JSON.
    var plainText: String {
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        func i(_ v: Int?) -> String { v.map(String.init) ?? "—" }
        var lines: [String] = []
        lines.append("KickLab analysis diagnostics (format \(formatVersion))")
        lines.append("App \(appVersion ?? "—") · engine \(engineVersion ?? "—")")
        lines.append("Outcome: \(storedStatus)\(storedFailureReason.map { " — \($0)" } ?? "")")
        if let cause = failureCause { lines.append("Diagnosed cause: \(cause.rawValue)") }
        lines.append("")
        lines.append("Kick: \(kickType.rawValue) · foot \(kickingFoot?.rawValue ?? "—") · camera \(cameraAngle?.rawValue ?? "—") · manual kicker selection \(manualKickerSelection.map { $0 ? "yes" : "no" } ?? "—")")
        lines.append("Video: \(n(videoDurationSeconds)) s · nominal \(n(nominalFrameRate)) fps · analyzed at \(n(measuredAnalysisFrameRate)) fps · orientation \(orientation ?? "—")\(isMirrored == true ? " (mirrored)" : "")")
        lines.append("Frames: sampled \(i(framesSampled)) · Vision failed \(i(framesVisionFailed)) · with a person \(i(framesWithPerson)) · with 2+ people \(i(framesWithMultiplePeople)) · max people \(i(maximumPeopleInFrame))")
        lines.append("Kicker: \(kickerStatus?.rawValue ?? "—") via \(kickerSelectionMethod?.rawValue ?? "—") · confidence \(n(kickerTrackConfidence)) · candidates \(i(kickerCandidates)) · tracked in \(i(framesWithKicker)) frames (\(n(kickerTrackedFraction)))")
        lines.append("")
        lines.append("Joints (detected / usable ≥ \(n(processingMinimumJointConfidence)) · mean · median · processed measured/interpolated/unavailable):")
        for j in joints {
            lines.append("  \(j.joint.rawValue)\(j.role.map { " [\($0)]" } ?? ""): \(j.detectedFrames) / \(j.usableFrames) · \(n(j.meanConfidence)) · \(n(j.medianConfidence)) · \(j.measuredSamples)/\(j.interpolatedSamples)/\(j.unavailableSamples)")
        }
        lines.append("")
        lines.append("Phases (\(phaseSupport?.rawValue ?? "—")):")
        for p in phases {
            lines.append("  \(p.phase.rawValue): \(p.status.rawValue) at \(n(p.time)) [\(n(p.start))–\(n(p.end))] confidence \(n(p.confidence))")
        }
        for note in phaseNotes { lines.append("  note: \(note)") }
        if let e = detectionEvidence { lines.append(contentsOf: Self.evidenceLines(e, indent: "  ")) }
        if let check = contactCheck {
            lines.append("  marked contact \(n(check.referenceTime)) · estimate \(n(check.estimatedTime)) · error \(n(check.errorSeconds)) s (\(n(check.errorFrames)) frames) · \(check.withinTolerance ? "agrees" : "outside ±\(ContactTimingCheck.toleranceSeconds) s")")
        }
        if let r = replay {
            lines.append("")
            lines.append("Replay — current detector on the stored pose\(r.differsFromStored ? " (differs from stored)" : " (same as stored)"):")
            lines.append("  leg repair: \(r.repair.legSwapSamples.count) swapped sample(s) \(r.repair.legSwapSamples) · \(r.repair.outlierPoints) jump point(s) at \(r.repair.outlierSamples)")
            for p in r.phases {
                lines.append("  \(p.phase.rawValue): \(p.status.rawValue) at \(n(p.time)) [\(n(p.start))–\(n(p.end))] confidence \(n(p.confidence))")
            }
            for note in r.notes { lines.append("  note: \(note)") }
            if let e = r.evidence { lines.append(contentsOf: Self.evidenceLines(e, indent: "  ")) }
            lines.append("  metrics available \(r.availableMetricCount) · scored categories \(r.scoredCategoryCount) · overall \(r.overallScore.map { String(format: "%.1f", $0) } ?? "—")")
            for c in r.categoryScores { lines.append("    \(c)") }
        }
        lines.append("")
        lines.append("Metrics (thresholds: report ≥ \(n(minimumMetricConfidence)), score ≥ \(n(minimumScoringConfidence))):")
        for m in metrics {
            let state = m.available ? "✓ \(n(m.value)) conf \(n(m.confidence))" : "✗ \(m.unavailableReason ?? "?")\(m.missingPhase.map { " (\($0.rawValue))" } ?? "")"
            let factors = m.jointQuality == nil ? "" : " · joints \(n(m.jointQuality)) cov \(n(m.jointCoverage)) phase \(n(m.phaseFactor)) samples \(n(m.sampleFactor)) fps \(n(m.frameRateFactor)) camera \(n(m.cameraFactor))"
            lines.append("  \(m.name): \(state)\(factors)\(m.limitedByCameraAngle ? " · limited by camera angle" : "")")
        }
        lines.append("")
        lines.append("Categories (need ≥ \(n(minimumCategoryWeightFraction)) of weight and confidence ≥ \(n(minimumCategoryConfidence))):")
        for c in categories {
            lines.append("  \(c.category.rawValue): \(c.score.map { String(format: "%.1f", $0) } ?? "not scored") · confidence \(n(c.confidence)) · weight available \(n(c.availableWeightFraction)) · components \(c.scoredComponents)")
            for e in c.excluded { lines.append("    excluded \(e)") }
        }
        lines.append("Scored categories: \(i(scoredCategoryCount)) · overall \(overallScore.map { String(format: "%.1f", $0) } ?? "—")")
        lines.append("")
        lines.append("Contributing factors:")
        for f in contributingFactors { lines.append("  • \(f)") }
        lines.append("")
        lines.append("--- JSON ---")
        lines.append(json())
        return lines.joined(separator: "\n")
    }

    static func evidenceLines(_ e: PhaseDetectionEvidence, indent: String) -> [String] {
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        return [
            "\(indent)contact: peak foot speed \(n(e.contactPeakSpeed)) bl/s at \(n(e.contactPeakTime)) (sub-frame \(n(e.refinedContactTime))) · kicking foot passes plant foot at \(n(e.anklePassTime)) · offset \(n(e.contactCueOffset)) s",
            "\(indent)plant: touchdown \(n(e.plantTouchdownTime)) · still through contact \(e.plantStillThroughContact.map { $0 ? "yes" : "no" } ?? "—") · speed at contact \(n(e.plantSpeedAtContact)) · slowest before contact \(n(e.slowestPlantSpeedBeforeContact)) · still threshold \(n(e.plantStillThreshold)) · noise floor \(n(e.plantNoiseFloor))",
            "\(indent)follow-through: \(n(e.followThroughSeconds)) s from contact to slow-down",
        ]
    }
}
