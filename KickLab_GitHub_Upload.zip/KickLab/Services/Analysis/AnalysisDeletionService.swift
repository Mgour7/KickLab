import Foundation
import SwiftData

/// Deletes ONE analysis of a kick (reanalysis fix).
///
/// What goes: the analysis record with its metrics, category scores and coaching
/// observations (cascade), and its artifact folder — pose, signals, phases,
/// biomechanics, the manifest (which records any user-chosen contact frame or kick
/// interval) and the personalization snapshot. After this nothing that analysis was
/// given by the user exists anywhere, so it cannot reach a later analysis.
///
/// What stays: the kick, its videos (and anything in the person's Photos library), and
/// every other analysis. If the deleted analysis was current, the newest completed
/// AUTOMATIC analysis becomes current, or none; a user-assisted analysis is never
/// promoted implicitly.
///
/// Files are removed only after the deletion is saved (see `MediaCleanupHandling`).
struct AnalysisDeletionService {
    enum DeletionError: Error, Equatable, LocalizedError {
        /// The analysis is still queued or running.
        case stillRunning
        case notInServiceContext
        case persistenceFailed(String)

        var errorDescription: String? {
            switch self {
            case .stillRunning: "This analysis is still running. Cancel it first."
            case .notInServiceContext: "This analysis couldn't be found."
            case .persistenceFailed: "The analysis couldn't be deleted. Nothing was changed."
            }
        }
    }

    struct Outcome: Equatable, Sendable {
        var deletedAnalysisID: UUID
        /// The kick's current analysis afterwards (nil = none).
        var currentAnalysisID: UUID?
        /// The artifact folder scheduled for removal, if the analysis had one.
        var removedArtifactsPath: String?
    }

    let context: ModelContext
    let mediaCleanup: any MediaCleanupHandling
    var saveHandler: ModelSaveHandler = ModelCommit.defaultSave

    /// - Parameter runInProgress: whether an analysis of this kick is running right now.
    ///   A queued or processing record is refused only then; otherwise it is a leftover
    ///   of an interrupted run (KickLab was closed) and can be deleted.
    @discardableResult
    func delete(_ analysis: BiomechanicsAnalysis, runInProgress: Bool) throws -> Outcome {
        guard context.manages(analysis) else { throw DeletionError.notInServiceContext }
        if runInProgress, analysis.processingStatus.acceptsInputVideos { throw DeletionError.stillRunning }
        let id = analysis.id
        let wasCurrent = analysis.isCurrent
        let path = analysis.artifactsRelativePath
        let kick = analysis.kick
        let remaining = (kick?.analyses ?? []).filter { $0.id != id }

        context.delete(analysis)
        var current = remaining.first { $0.isCurrent }?.id
        if wasCurrent {
            let candidates = remaining.map {
                CurrentReplacementCandidate(
                    snapshot: AnalysisCurrencySnapshot(id: $0.id, status: $0.processingStatus, isCurrent: $0.isCurrent,
                                                       createdAt: $0.createdAt, completedAt: $0.completedAt),
                    isUserAssisted: AnalysisAssistanceLabel.isAssisted($0.analysisVersion)
                )
            }
            current = CurrentAnalysisSelector.replacementAfterDeletion(from: candidates)
            for other in remaining { other.isCurrent = (other.id == current) }
        }
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw DeletionError.persistenceFailed(failure.underlyingDescription)
        }
        if let path {
            mediaCleanup.cleanUp(MediaCleanupRequest(mediaRelativePaths: [], analysisRelativePaths: [path]))
        }
        return Outcome(deletedAnalysisID: id, currentAnalysisID: current, removedArtifactsPath: path)
    }
}
