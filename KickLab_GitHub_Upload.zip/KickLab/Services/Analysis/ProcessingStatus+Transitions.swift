import Foundation

/// The only allowed analysis lifecycle transitions:
///
///     queued     → processing | cancelled
///     processing → completed | failed | cancelled
///
/// completed, failed and cancelled are terminal. `unknown` (written by a newer app
/// version) is treated as terminal so this version never mutates it.
extension ProcessingStatus {
    var allowedNextStatuses: Set<ProcessingStatus> {
        switch self {
        case .queued: [.processing, .cancelled]
        case .processing: [.completed, .failed, .cancelled]
        case .completed, .failed, .cancelled, .unknown: []
        }
    }

    func canTransition(to next: ProcessingStatus) -> Bool {
        allowedNextStatuses.contains(next)
    }

    var isTerminal: Bool { allowedNextStatuses.isEmpty }

    /// Metrics, scores and observations may be added only while processing.
    var acceptsResults: Bool { self == .processing }

    /// Input videos may be added only before results exist.
    var acceptsInputVideos: Bool { self == .queued || self == .processing }
}
