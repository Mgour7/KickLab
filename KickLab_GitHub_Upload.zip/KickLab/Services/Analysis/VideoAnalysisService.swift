import Foundation

/// The contract for KickLab's future biomechanics engine.
///
/// The eventual pipeline: accept one or more videos of a kick → prepare the video
/// data → pick frames/timestamps → estimate pose → find plant, contact and
/// follow-through → produce generic metrics, scores and coaching observations.
///
/// Engines contain no SwiftData code and no UI code. The caller:
/// 1. builds a `VideoAnalysisRequest` from stored records (`VideoAnalysisRequest.make`),
/// 2. creates a queued `BiomechanicsAnalysis` via `AnalysisService` and starts it,
/// 3. calls `analyze`, forwarding progress to the UI,
/// 4. records the returned drafts through `AnalysisService` and completes or fails it.
///
/// Work is `async` and must honor task cancellation, throwing
/// `VideoAnalysisError.cancelled` promptly when the calling task is cancelled.
protocol VideoAnalysisService: Sendable {
    /// Recorded on every `BiomechanicsAnalysis` the engine produces.
    var engineVersion: String { get }
    var availability: VideoAnalysisAvailability { get }

    /// Cheap checks before heavy work: which inputs are usable and roughly how much work there is.
    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis

    /// Runs the analysis. `progress` may be called from any thread, any number of times.
    func analyze(
        _ request: VideoAnalysisRequest,
        progress: @escaping @Sendable (VideoAnalysisProgress) -> Void
    ) async throws -> VideoAnalysisResult
}

/// The engine shipped until real analysis exists. It never produces results and
/// says so clearly; it never invents biomechanics values.
struct UnavailableVideoAnalysisService: VideoAnalysisService {
    static let reason = "Video analysis isn't available yet."

    init() {}

    var engineVersion: String { "unavailable" }
    var availability: VideoAnalysisAvailability { .unavailable(reason: Self.reason) }

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        try Self.checkCancellation()
        throw VideoAnalysisError.unavailable(reason: Self.reason)
    }

    func analyze(
        _ request: VideoAnalysisRequest,
        progress: @escaping @Sendable (VideoAnalysisProgress) -> Void
    ) async throws -> VideoAnalysisResult {
        try Self.checkCancellation()
        throw VideoAnalysisError.unavailable(reason: Self.reason)
    }

    /// Maps task cancellation to the engine's typed error.
    private static func checkCancellation() throws {
        if Task.isCancelled { throw VideoAnalysisError.cancelled }
    }
}
