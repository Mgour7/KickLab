import Foundation
import SwiftData

/// Creates analyses, drives their lifecycle, stores their results and decides
/// which analysis of a kick is current. Contains no computer-vision code: the
/// future `VideoAnalysisService` produces results and records them through here.
///
/// - Input videos must belong to the analysis's kick (no cross-kick, no orphans).
/// - Lifecycle: queued → processing → completed | failed; queued/processing → cancelled.
/// - N1  Completed (and failed/cancelled) analyses are immutable: no new results or
///       input videos. A rerun creates a new analysis.
/// - N2  `promote` makes exactly one completed analysis current, in one save.
/// - N3  Failed, cancelled or unfinished analyses are never current.
/// - N4  `repairCurrent` restores the "at most one, completed" rule.
/// - N5/N6  Results are validated by `AnalysisResultValidator`.
/// - Historical analyses are never deleted by this service.
///
/// `isCurrent` is the one field that may change on a completed analysis; it is
/// selection state, not a result.
///
/// Save policy: see `ModelCommit`. Every mutating method saves before returning.
struct AnalysisService {
    let context: ModelContext
    let saveHandler: ModelSaveHandler

    init(context: ModelContext, saveHandler: @escaping ModelSaveHandler = ModelCommit.defaultSave) {
        self.context = context
        self.saveHandler = saveHandler
    }

    // MARK: Create

    /// Creates a queued, non-current analysis of `kick` using `inputVideos`.
    @discardableResult
    func createAnalysis(for kick: Kick, analysisVersion: String, inputVideos: [VideoAsset]) throws -> BiomechanicsAnalysis {
        try requireManaged(kick)
        for video in inputVideos { try requireManaged(video) }

        let version = analysisVersion.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !version.isEmpty else { throw AnalysisServiceError.emptyAnalysisVersion }
        guard !inputVideos.isEmpty else { throw AnalysisServiceError.noInputVideos }

        let issues = inputVideos.flatMap { AnalysisIntegrityValidator.issues(attaching: $0, toKick: kick) }
        guard issues.isEmpty else { throw AnalysisServiceError.integrity(issues) }

        let analysis = BiomechanicsAnalysis(analysisVersion: version, processingStatus: .queued)
        context.insert(analysis)
        analysis.isCurrent = false
        analysis.kick = kick
        for video in inputVideos {
            try analysis.attachInputVideo(video)
        }
        try commit()
        return analysis
    }

    /// Adds an input video while the analysis is queued or processing.
    func addInputVideo(_ video: VideoAsset, to analysis: BiomechanicsAnalysis) throws {
        try requireManaged(analysis)
        try requireManaged(video)
        guard analysis.processingStatus.acceptsInputVideos else {
            throw AnalysisServiceError.analysisIsImmutable(status: analysis.processingStatus)
        }
        do {
            try analysis.attachInputVideo(video)
        } catch let error as AnalysisIntegrityError {
            throw AnalysisServiceError.integrity(error.issues)
        }
        try commit()
    }

    // MARK: Lifecycle

    /// queued → processing
    func startProcessing(_ analysis: BiomechanicsAnalysis) throws {
        try transition(analysis, to: .processing)
        try commit()
    }

    /// processing → completed. Sets `completedAt`. The analysis is then immutable
    /// and may be promoted to current.
    func markCompleted(_ analysis: BiomechanicsAnalysis, confidence: Double?, overallScore: Double? = nil) throws {
        try requireManaged(analysis)
        let issues = AnalysisResultValidator.validateCompletion(confidence: confidence, overallScore: overallScore)
        guard issues.isEmpty else { throw AnalysisServiceError.invalidResult(issues) }
        try transition(analysis, to: .completed)
        analysis.confidence = confidence
        analysis.overallScore = overallScore
        analysis.completedAt = .now
        try commit()
    }

    /// processing → failed. A failed analysis is never current.
    func markFailed(_ analysis: BiomechanicsAnalysis, reason: String) throws {
        try requireManaged(analysis)
        let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw AnalysisServiceError.emptyFailureReason }
        try transition(analysis, to: .failed)
        analysis.failureReason = trimmed
        analysis.isCurrent = false
        try commit()
    }

    /// Records where the engine wrote this analysis's file artifacts (relative to the
    /// analysis root). Only while processing; the path must be a safe managed path.
    func attachArtifacts(relativePath: String, to analysis: BiomechanicsAnalysis) throws {
        try requireAcceptingResults(analysis)
        guard ManagedPath.isValid(relativePath) else { throw AnalysisServiceError.invalidArtifactsPath(relativePath) }
        analysis.artifactsRelativePath = relativePath
        try commit()
    }

    /// queued/processing → cancelled. A cancelled analysis is never current.
    func cancel(_ analysis: BiomechanicsAnalysis) throws {
        try transition(analysis, to: .cancelled)
        analysis.isCurrent = false
        try commit()
    }

    // MARK: Current analysis

    /// Makes `analysis` the kick's only current analysis, in one save.
    /// Other analyses are kept; only their `isCurrent` flag is cleared.
    func promote(_ analysis: BiomechanicsAnalysis) throws {
        try requireManaged(analysis)
        guard analysis.processingStatus == .completed else {
            throw AnalysisServiceError.notCompleted(status: analysis.processingStatus)
        }
        guard let kick = analysis.kick else {
            throw AnalysisServiceError.analysisHasNoKick(analysisID: analysis.id)
        }
        for candidate in kick.analyses ?? [] {
            candidate.isCurrent = (candidate.id == analysis.id)
        }
        analysis.isCurrent = true
        try commit()
    }

    /// Restores the rule "at most one current analysis per kick, and it is completed".
    /// Saves only when a flag changed.
    @discardableResult
    func repairCurrent(for kick: Kick) throws -> CurrentAnalysisRepairResult {
        try requireManaged(kick)
        let analyses = kick.analyses ?? []
        let snapshots = analyses.map {
            AnalysisCurrencySnapshot(
                id: $0.id,
                status: $0.processingStatus,
                isCurrent: $0.isCurrent,
                createdAt: $0.createdAt,
                completedAt: $0.completedAt
            )
        }
        let flags = CurrentAnalysisSelector.currentFlags(for: snapshots)

        var changed: [UUID] = []
        for analysis in analyses {
            let shouldBeCurrent = flags[analysis.id] ?? false
            if analysis.isCurrent != shouldBeCurrent {
                analysis.isCurrent = shouldBeCurrent
                changed.append(analysis.id)
            }
        }
        if !changed.isEmpty {
            try commit()
        }
        return CurrentAnalysisRepairResult(
            currentAnalysisID: CurrentAnalysisSelector.selectCurrent(from: snapshots),
            changedAnalysisIDs: changed.sorted { $0.uuidString < $1.uuidString }
        )
    }

    // MARK: Results (only while processing)

    @discardableResult
    func addMetric(_ draft: MetricDraft, to analysis: BiomechanicsAnalysis) throws -> BiomechanicalMetric {
        try requireAcceptingResults(analysis)
        let issues = AnalysisResultValidator.validate(draft)
        guard issues.isEmpty else { throw AnalysisServiceError.invalidResult(issues) }

        let metric = BiomechanicalMetric(
            metricKey: draft.metricKey.trimmingCharacters(in: .whitespacesAndNewlines),
            value: draft.value,
            unit: draft.unit,
            confidence: draft.confidence,
            measurementStatus: draft.measurementStatus,
            phase: draft.phase
        )
        context.insert(metric)
        metric.metricDefinitionVersion = draft.metricDefinitionVersion
        metric.sampleTimeSeconds = draft.sampleTimeSeconds
        metric.sourceAngle = draft.sourceAngle
        metric.analysis = analysis
        try commit()
        return metric
    }

    @discardableResult
    func addCategoryScore(_ draft: CategoryScoreDraft, to analysis: BiomechanicsAnalysis) throws -> CategoryScore {
        try requireAcceptingResults(analysis)
        let issues = AnalysisResultValidator.validate(draft)
        guard issues.isEmpty else { throw AnalysisServiceError.invalidResult(issues) }

        let score = CategoryScore(
            category: draft.category,
            score: draft.score,
            confidence: draft.confidence,
            measurementStatus: draft.measurementStatus,
            summary: draft.summary.normalizedOptionalText
        )
        context.insert(score)
        score.analysis = analysis
        try commit()
        return score
    }

    /// Adds a KEEP, IMPROVE or CUE. A CUE's `relatedObservationID` must name an
    /// IMPROVE already stored in this same analysis.
    @discardableResult
    func addObservation(_ draft: CoachingObservationDraft, to analysis: BiomechanicsAnalysis) throws -> CoachingObservation {
        try requireAcceptingResults(analysis)
        let existing = (analysis.observations ?? []).map { ExistingObservationRef(id: $0.id, kind: $0.kind) }
        let issues = AnalysisResultValidator.validate(draft, existing: existing)
        guard issues.isEmpty else { throw AnalysisServiceError.invalidResult(issues) }

        let observation = CoachingObservation(
            id: draft.id,
            kind: draft.kind,
            category: draft.category,
            message: draft.message.trimmingCharacters(in: .whitespacesAndNewlines),
            severity: draft.severity,
            confidence: draft.confidence,
            relatedObservationID: draft.relatedObservationID,
            source: draft.source
        )
        context.insert(observation)
        observation.priority = draft.priority
        observation.comparisonBasis = draft.comparisonBasis
        observation.evidenceMetricKeys = draft.evidenceMetricKeys
        observation.ruleKey = draft.ruleKey
        observation.analysis = analysis
        try commit()
        return observation
    }

    // MARK: Helpers

    /// Validates and applies a status change without saving.
    private func transition(_ analysis: BiomechanicsAnalysis, to next: ProcessingStatus) throws {
        try requireManaged(analysis)
        let current = analysis.processingStatus
        guard current.canTransition(to: next) else {
            throw AnalysisServiceError.invalidTransition(from: current, to: next)
        }
        analysis.processingStatus = next
    }

    private func requireAcceptingResults(_ analysis: BiomechanicsAnalysis) throws {
        try requireManaged(analysis)
        guard analysis.processingStatus.acceptsResults else {
            throw AnalysisServiceError.analysisIsImmutable(status: analysis.processingStatus)
        }
    }

    private func requireManaged(_ model: any PersistentModel) throws {
        guard context.manages(model) else { throw AnalysisServiceError.notInServiceContext }
    }

    private func commit() throws {
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw AnalysisServiceError.persistenceFailed(failure.underlyingDescription)
        }
    }
}
