import Foundation

/// Input for `AnalysisService.addMetric(_:to:)`.
struct MetricDraft: Equatable, Sendable {
    var metricKey: String
    var metricDefinitionVersion: Int = 1
    /// Must be nil when `measurementStatus` is `.unavailable`.
    var value: Double?
    var unit: MetricUnit
    /// 0...1.
    var confidence: Double?
    var measurementStatus: MeasurementStatus
    var phase: MechanicsPhase = .unknown
    var sampleTimeSeconds: Double? = nil
    var sourceAngle: VideoAngleType? = nil

    /// A measurement that could not be made. Value is nil by construction.
    static func unavailable(_ metricKey: String, unit: MetricUnit, phase: MechanicsPhase = .unknown) -> MetricDraft {
        MetricDraft(metricKey: metricKey, value: nil, unit: unit, confidence: nil, measurementStatus: .unavailable, phase: phase)
    }
}

/// Input for `AnalysisService.addCategoryScore(_:to:)`.
struct CategoryScoreDraft: Equatable, Sendable {
    var category: AnalysisCategory
    /// 0–100. Must be nil when `measurementStatus` is `.unavailable`.
    var score: Double?
    /// 0...1.
    var confidence: Double?
    var measurementStatus: MeasurementStatus
    var summary: String? = nil
}

/// Input for `AnalysisService.addObservation(_:to:)`.
struct CoachingObservationDraft: Equatable, Sendable {
    /// Chosen by the caller so a CUE created later can reference this observation.
    var id: UUID = UUID()
    var kind: ObservationKind
    var category: AnalysisCategory
    var message: String
    /// Only valid for `.improve`.
    var severity: CoachingSeverity? = nil
    /// 0...1.
    var confidence: Double? = nil
    var priority: Int = 0
    var comparisonBasis: ComparisonBasis? = nil
    var evidenceMetricKeys: [String] = []
    /// Only valid for `.cue`; must be the ID of an IMPROVE observation in the same analysis.
    var relatedObservationID: UUID? = nil
    var ruleKey: String? = nil
    var source: ObservationSource = .engine
}

/// An observation already stored in the analysis, as the validator needs to see it.
struct ExistingObservationRef: Equatable, Sendable {
    let id: UUID
    let kind: ObservationKind
}
