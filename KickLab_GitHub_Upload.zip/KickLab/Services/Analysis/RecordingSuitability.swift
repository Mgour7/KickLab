import Foundation

// Step 12D: is this recording suitable for body-mechanics analysis?
//
// Only measurable characteristics are assessed. Motion blur can't be measured from pose
// alone; it is inferred only from its effect (the kicking ankle merging with the plant
// ankle after contact). Nothing here changes a measurement or a score: findings explain
// results and give recording guidance.

struct SuitabilityFinding: Codable, Equatable, Sendable, Identifiable {
    enum Kind: String, Codable, Sendable, CaseIterable {
        case noPersonDetected, multiplePeople, kickerTooSmall, kickerSmall, lowJointCoverage, lowFrameRate
        case frameRateBlursKick, bodyLeavesFrame, tooFewFrames, cameraAngle, cameraMoving, kickingFootBlurred
    }

    enum Severity: String, Codable, Sendable {
        /// Detailed mechanics can't be measured from this recording.
        case blocking
        /// Some measurements are limited or less reliable.
        case limiting
        /// Worth knowing; results are not affected much.
        case info
    }

    var kind: Kind
    var severity: Severity
    var message: String

    var id: String { kind.rawValue }
}

enum RecordingSuitability {
    /// Torso length (shoulder–hip) as a fraction of the frame height.
    static let tooSmallTorsoFraction = 0.05
    static let smallTorsoFraction = 0.08
    static let minimumKickerFrames = 30

    static func assess(
        sequence: PoseSequence?,
        kickerTimeline: KickerPoseTimeline?,
        signals: PoseSignalSet?,
        cameraAngle: VideoAngleType?,
        phases: KickPhaseDetectionResult?
    ) -> [SuitabilityFinding] {
        var out: [SuitabilityFinding] = []
        let stats = sequence?.confidenceStatistics
        let analyzed = max(0, (stats?.frameCount ?? 0) - (stats?.droppedFrameCount ?? 0))

        if let stats, analyzed > 0, Double(stats.framesWithBodies) < 0.1 * Double(analyzed) {
            let message = cameraAngle == .behindGoal
                ? "No person could be detected. From behind the goal the kicker is usually too far away for body tracking. Keep this recording for kick outcomes; for mechanics, film from the side, close enough that the kicker fills about half the frame height."
                : "No person could be detected. Film from the side, close enough that the kicker fills about half the frame height, with the whole body in frame."
            out.append(SuitabilityFinding(kind: .noPersonDetected, severity: .blocking, message: message))
            return out
        }
        if let sequence, (sequence.frames.map(\.bodies.count).max() ?? 0) > 1 {
            out.append(SuitabilityFinding(kind: .multiplePeople, severity: .info,
                                          message: "Several people are visible. If the wrong person is analyzed, tap the kicker before analyzing."))
        }
        if let scale = signals?.bodyScale {
            if scale < tooSmallTorsoFraction {
                out.append(SuitabilityFinding(kind: .kickerTooSmall, severity: .blocking,
                                              message: "The kicker is too small in this recording for reliable biomechanics analysis. Move closer and keep the entire body visible."))
            } else if scale < smallTorsoFraction {
                out.append(SuitabilityFinding(kind: .kickerSmall, severity: .limiting,
                                              message: "The kicker is fairly small in the frame, so joint positions are less precise. Moving closer helps."))
            }
        }
        if let timeline = kickerTimeline, !timeline.samples.isEmpty {
            if timeline.samples.count < minimumKickerFrames {
                out.append(SuitabilityFinding(kind: .tooFewFrames, severity: .blocking,
                                              message: "The kicker is visible in too few frames. Start recording before the approach and stop after the follow-through."))
            }
            let legs: [PoseJoint] = [.leftKnee, .rightKnee, .leftAnkle, .rightAnkle]
            let legSamples = timeline.samples.count * legs.count
            let available = timeline.samples.reduce(0) { sum, s in sum + legs.filter { s.point($0) != nil }.count }
            if legSamples > 0, Double(available) < 0.6 * Double(legSamples) {
                let percent: Int = Int(100 * Double(available) / Double(legSamples))
                out.append(SuitabilityFinding(kind: .lowJointCoverage, severity: .limiting,
                                              message: "The knees and ankles were detected in only \(percent)% of frames. Better light, a plain background and the whole body in frame help."))
            }
            let edge = timeline.samples.filter { s in
                let ankles = [s.point(.leftAnkle), s.point(.rightAnkle)]
                let missing = ankles.contains { $0 == nil } || s.point(.nose) == nil
                let atEdge = ankles.compactMap { $0 }.contains { $0.x < 0.02 || $0.x > 0.98 || $0.y > 0.98 }
                return missing || atEdge
            }.count
            if Double(edge) > 0.2 * Double(timeline.samples.count) {
                out.append(SuitabilityFinding(kind: .bodyLeavesFrame, severity: .limiting,
                                              message: "Part of the body (feet or head) leaves the frame or is hidden in many frames. Keep the whole body in frame from approach to follow-through."))
            }
        }
        if let times = signals?.timestamps, times.count > 4 {
            let fps = KickPhaseDetector.framesPerSecond(times)
            if fps < 24 {
                out.append(SuitabilityFinding(kind: .lowFrameRate, severity: .limiting,
                                              message: String(format: "Only %.0f frames per second were analyzed. Record at 60 fps or in slow motion for kick timing.", fps)))
            } else if fps < 45 {
                out.append(SuitabilityFinding(kind: .frameRateBlursKick, severity: .info,
                                              message: String(format: "At %.0f fps the kicking foot moves a long way between frames and can blur at contact. 60 fps or slow motion gives sharper contact timing.", fps)))
            }
        }
        if let angle = cameraAngle {
            switch angle {
            case .side: break
            case .unknown:
                out.append(SuitabilityFinding(kind: .cameraAngle, severity: .info,
                                              message: "The camera angle wasn't set. A side view gives the most reliable kicking-leg mechanics."))
            case .rear, .front, .behindGoal:
                out.append(SuitabilityFinding(kind: .cameraAngle, severity: .limiting,
                                              message: "This camera angle supports some measurements, but a side view would provide better kicking-leg mechanics."))
            }
        }
        if phases?.evidence?.cameraMotionSuspected == true {
            out.append(SuitabilityFinding(kind: .cameraMoving, severity: .limiting,
                                          message: "The camera seems to move after the kick (the whole athlete slides backward in the frame). A tripod or a steady hand keeps post-kick measurements reliable."))
        }
        if phases?.evidence?.kickingAnkleMergedAfterContact == true {
            out.append(SuitabilityFinding(kind: .kickingFootBlurred, severity: .limiting,
                                          message: "After contact the kicking foot couldn't be told apart from the plant foot (often motion blur). Slow-motion recording or brighter light helps."))
        }
        return out
    }
}
