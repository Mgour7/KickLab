import Foundation

// Step 12B: phase-detection diagnostics — time series, a replay of the current detector
// on stored pose data, and contact-timing validation against a marked contact time.
//
// Privacy: speeds are in body lengths per second and relative offsets in body lengths.
// No image coordinates, no frames, no names.

/// Per-sample signals around the kick, exportable as CSV.
struct DiagnosticsTimeSeries: Codable, Equatable, Sendable {
    /// "replay" (current detector on the stored pose) or "stored" (as analyzed).
    var source: String
    var time: [Double]
    /// Body lengths per second.
    var plantAnkleSpeed: [Double?]
    var kickingAnkleSpeed: [Double?]
    /// Hip-midpoint speed and its component along the direction of travel.
    var bodyCenterSpeed: [Double?]
    var bodyForwardVelocity: [Double?]
    /// Body lengths; crosses zero when the kicking foot passes the plant foot.
    var kickingAnkleAheadOfPlant: [Double?]
    /// True where leg repair undid a left/right swap / rejected a knee or ankle jump.
    var legSwapRepaired: [Bool]
    var jumpRejected: [Bool]
    /// Candidate and detected events: (name, time).
    var events: [DiagnosticsEvent]
    /// Step 12C: the same ankle speeds WITHOUT leg repair (confidence threshold, gap
    /// filling and smoothing only), to compare raw and repaired trajectories.
    var rawPlantAnkleSpeed: [Double?]? = nil
    var rawKickingAnkleSpeed: [Double?]? = nil
    /// Step 12D: every derived signal except positions (speeds, velocities and offsets in
    /// body lengths, angles in degrees), so the phase detector can be re-run exactly from
    /// an export. Body-center x/y are left out: they are coordinates.
    var allSignals: [String: [Double?]]? = nil

    var csv: String {
        func f(_ v: Double?) -> String { v.map { String(format: "%.4f", $0) } ?? "" }
        let extraKeys = (allSignals ?? [:]).keys.sorted()
        var lines = ["time_s,plant_ankle_speed_bl_s,kicking_ankle_speed_bl_s,body_center_speed_bl_s,body_forward_velocity_bl_s,kicking_ankle_ahead_of_plant_bl,leg_swap_repaired,jump_rejected,raw_plant_ankle_speed_bl_s,raw_kicking_ankle_speed_bl_s"
                     + extraKeys.map { ",signal_\($0)" }.joined()]
        for i in time.indices {
            let rawPlant = rawPlantAnkleSpeed.flatMap { $0.indices.contains(i) ? $0[i] : nil }
            let rawKicking = rawKickingAnkleSpeed.flatMap { $0.indices.contains(i) ? $0[i] : nil }
            lines.append([String(format: "%.4f", time[i]), f(plantAnkleSpeed[i]), f(kickingAnkleSpeed[i]), f(bodyCenterSpeed[i]),
                          f(bodyForwardVelocity[i]), f(kickingAnkleAheadOfPlant[i]),
                          legSwapRepaired[i] ? "1" : "0", jumpRejected[i] ? "1" : "0", f(rawPlant), f(rawKicking)].joined(separator: ",")
                         + extraKeys.map { key in "," + f(allSignals?[key].flatMap { $0.indices.contains(i) ? $0[i] : nil }) }.joined())
        }
        lines.append("")
        lines.append("event,time_s")
        for e in events { lines.append("\(e.name),\(String(format: "%.4f", e.time))") }
        return lines.joined(separator: "\n")
    }

    static func make(source: String, signals: PoseSignalSet, repair: PoseRepairReport?, phases: KickPhaseDetectionResult?,
                     rawSignals: PoseSignalSet? = nil) -> DiagnosticsTimeSeries {
        let round = { (v: [Double?]) in v.map { $0.map(AnalysisDiagnosticsBuilder.round3) } }
        let swaps = Set(repair?.legSwapSamples ?? [])
        let jumps = Set(repair?.outlierSamples ?? [])
        return DiagnosticsTimeSeries(
            source: source,
            time: signals.timestamps.map(AnalysisDiagnosticsBuilder.round3),
            plantAnkleSpeed: round(signals.values(.plantAnkleSpeed)),
            kickingAnkleSpeed: round(signals.values(.kickingAnkleSpeed)),
            bodyCenterSpeed: round(signals.values(.bodyCenterSpeed)),
            bodyForwardVelocity: round(signals.values(.bodyForwardVelocity)),
            kickingAnkleAheadOfPlant: round(signals.values(.kickingAnkleAheadOfPlant)),
            legSwapRepaired: signals.timestamps.indices.map { swaps.contains($0) },
            jumpRejected: signals.timestamps.indices.map { jumps.contains($0) },
            events: phases.map(DiagnosticsEvent.events(from:)) ?? [],
            rawPlantAnkleSpeed: rawSignals.map { round($0.values(.plantAnkleSpeed)) },
            rawKickingAnkleSpeed: rawSignals.map { round($0.values(.kickingAnkleSpeed)) },
            allSignals: Dictionary(uniqueKeysWithValues: PoseSignalKey.allCases.filter { !exportExcluded.contains($0) }.map {
                ($0.rawValue, signals.values($0).map { $0.map { ($0 * 10000).rounded() / 10000 } })
            })
        )
    }

    /// Positions are coordinates and never exported.
    static let exportExcluded: Set<PoseSignalKey> = [.bodyCenterX, .bodyCenterY]

    /// Step 12D: rebuilds a signal set from an export (for exact replays in tests).
    var signalSet: PoseSignalSet {
        var series: [PoseSignalKey: [Double?]] = [:]
        for (key, values) in allSignals ?? [:] { if let k = PoseSignalKey(rawValue: key) { series[k] = values } }
        return PoseSignalSet(timestamps: time, series: series, travelDirection: 1)
    }
}

struct DiagnosticsEvent: Codable, Equatable, Sendable {
    var name: String
    var time: Double

    static func events(from phases: KickPhaseDetectionResult) -> [DiagnosticsEvent] {
        var out: [DiagnosticsEvent] = []
        for p in phases.phases where p.isAvailable {
            if let t = p.startTime { out.append(DiagnosticsEvent(name: "\(p.phase.rawValue)_start", time: t)) }
            if let t = p.endTime, p.endTime != p.startTime { out.append(DiagnosticsEvent(name: "\(p.phase.rawValue)_end", time: t)) }
        }
        if let e = phases.evidence {
            if let t = e.contactPeakTime { out.append(DiagnosticsEvent(name: "candidate_peak_foot_speed", time: t)) }
            if let t = e.refinedContactTime { out.append(DiagnosticsEvent(name: "candidate_peak_foot_speed_subframe", time: t)) }
            if let t = e.anklePassTime { out.append(DiagnosticsEvent(name: "candidate_kicking_foot_passes_plant_foot", time: t)) }
            if let t = e.plantTouchdownTime { out.append(DiagnosticsEvent(name: "candidate_plant_touchdown", time: t)) }
            for c in e.contactCandidates ?? [] {
                out.append(DiagnosticsEvent(name: c.selected ? "contact_candidate_selected" : "contact_candidate_rejected", time: c.time))
            }
            for c in e.plantCandidates ?? [] where !c.accepted {
                out.append(DiagnosticsEvent(name: "plant_candidate_rejected", time: c.time))
            }
            for c in e.followThroughCandidates ?? [] {
                out.append(DiagnosticsEvent(name: "follow_through_\(c.kind)\(c.accepted ? "_used" : "_rejected")", time: c.time))
            }
        }
        return out.map { DiagnosticsEvent(name: $0.name, time: AnalysisDiagnosticsBuilder.round3($0.time)) }
            .sorted { $0.time < $1.time }
    }
}

/// The CURRENT build's processing, phase detection and scoring re-run on the pose data
/// stored with an analysis, so an analysis made by an older build can be compared with
/// the current detector without re-running Vision.
struct DiagnosticsReplay: Codable, Equatable, Sendable {
    var phases: [DiagnosticsPhase]
    var notes: [String]
    var evidence: PhaseDetectionEvidence?
    var repair: PoseRepairReport
    /// Step 12D
    var kickWindows: KickWindowAnalysis? = nil
    var availableMetricCount: Int
    var scoredCategoryCount: Int
    var overallScore: Double?
    /// Scored categories, "category: score".
    var categoryScores: [String]
    /// True when the replayed phases differ from the stored ones (status or time).
    var differsFromStored: Bool

    struct Output {
        var replay: DiagnosticsReplay
        var signals: PoseSignalSet
        var phases: KickPhaseDetectionResult
        /// Step 12C: the replayed processed timeline (for the pose validation player) and
        /// signals without leg repair (for the raw/repaired comparison).
        var timeline: KickerPoseTimeline
        var rawSignals: PoseSignalSet
    }

    static func run(_ input: AnalysisDiagnosticsInput, kickingFoot: KickingFoot?) -> Output? {
        guard let sequence = input.sequence, let id = sequence.kickerTrackID,
              let foot = input.context?.kickingFoot ?? input.signals?.kickingFoot ?? kickingFoot else { return nil }
        let raw = KickerPoseTimeline.make(from: sequence.frames, trackID: id, displayAspectRatio: sequence.displayAspectRatio)
        var processing = PoseProcessingConfiguration.standard
        if let stored = input.processing {
            processing.minimumJointConfidence = stored.minimumJointConfidence
            processing.maximumInterpolationGapSeconds = stored.maximumInterpolationGapSeconds
            processing.smoothingRadius = stored.smoothingRadius
        }
        let (timeline, repair) = PoseTimelineProcessor.processWithReport(raw, configuration: processing)
        let signals = PoseSignalExtractor.extract(from: timeline, kickingFoot: foot)
        var unrepairedConfiguration = processing
        unrepairedConfiguration.repairsLegLabels = false
        let rawSignals = PoseSignalExtractor.extract(
            from: PoseTimelineProcessor.process(raw, configuration: unrepairedConfiguration), kickingFoot: foot
        )
        let phases = KickPhaseDetector.detect(signals, kickType: input.kickType, assistance: input.assistance)
        let context = BiomechanicsContext(kickType: input.kickType, kickingFoot: foot,
                                          cameraAngle: input.context?.cameraAngle ?? input.cameraAngle ?? .unknown)
        let result = KickBiomechanicsAnalyzer.analyze(
            timeline: timeline, signals: signals, phases: phases, context: context,
            idSeed: UUID(uuid: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))
        )
        let replayed = AnalysisDiagnosticsBuilder.diagnosticsPhases(phases)
        let stored = input.phases.map(AnalysisDiagnosticsBuilder.diagnosticsPhases)
        let replay = DiagnosticsReplay(
            phases: replayed, notes: phases.notes, evidence: phases.evidence, repair: repair, kickWindows: phases.kickWindows,
            availableMetricCount: result.availableMetricCount, scoredCategoryCount: result.availableCategoryCount,
            overallScore: result.overallScore,
            categoryScores: result.categories.filter { $0.category != .overall }.compactMap { c in
                c.score.map { "\(c.category.rawValue): \(String(format: "%.1f", $0))" }
            },
            differsFromStored: stored.map { s in
                zip(s, replayed).contains { $0.status != $1.status || $0.time != $1.time }
            } ?? true
        )
        return Output(replay: replay, signals: signals, phases: phases, timeline: timeline, rawSignals: rawSignals)
    }
}

