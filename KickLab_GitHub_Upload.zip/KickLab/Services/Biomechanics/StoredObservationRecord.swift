import Foundation

/// A stored coaching observation as plain values (from `CoachingObservation`), used by
/// the results screen and by the personalized coach.
struct StoredObservationRecord: Equatable, Sendable {
    var id: UUID
    var kind: ObservationKind
    var category: AnalysisCategory
    var message: String
    var severity: CoachingSeverity?
    var confidence: Double?
    var priority: Int
    var ruleKey: String?
    var relatedObservationID: UUID?
    var evidenceMetricKeys: [String]
}

extension GeneralRuleFinding {
    /// Step 8 observations as stored: each IMPROVE paired with its CUE, plus the KEEPs.
    /// Stored IMPROVE/KEEP messages are "observed. why it matters".
    static func from(stored observations: [StoredObservationRecord]) -> [GeneralRuleFinding] {
        var cues: [UUID: String] = [:]
        for cue in observations where cue.kind == .cue {
            if let related = cue.relatedObservationID, cues[related] == nil { cues[related] = cue.message }
        }
        return observations
            .filter { $0.kind == .improve || $0.kind == .keep }
            .sorted { a, b in a.priority != b.priority ? a.priority < b.priority : a.id.uuidString < b.id.uuidString }
            .map { o in
                let (observed, why) = splitMessage(o.message)
                return GeneralRuleFinding(
                    ruleKey: o.ruleKey ?? o.id.uuidString, kind: o.kind, category: o.category,
                    metric: o.evidenceMetricKeys.first.flatMap(KickMetricKey.init(rawValue:)),
                    observed: observed, whyItMatters: why, cue: o.kind == .improve ? cues[o.id] : nil,
                    severity: o.severity, confidence: o.confidence ?? 0, rank: o.priority
                )
            }
    }

    /// Splits at the first ". " (decimals like "0.46" are not split).
    static func splitMessage(_ message: String) -> (observed: String, why: String?) {
        guard let range = message.range(of: ". ") else { return (message, nil) }
        let observed = String(message[..<range.lowerBound]) + "."
        let why = String(message[range.upperBound...]).trimmingCharacters(in: .whitespaces)
        return (observed, why.isEmpty ? nil : why)
    }
}
