import Foundation

/// Step 12E: which metrics a camera perspective can measure, and how much a 2D
/// measurement from it is trusted.
///
/// From the side, the sagittal plane (forward/back, up/down) is seen directly: knee and
/// hip flexion, forward lean, foot speed along the swing, forward travel. From behind or
/// in front that plane runs along the line of sight, so those values are foreshortened
/// by an unknown amount — they are UNSUPPORTED there (not merely less confident), because
/// a foreshortened knee angle or speed isn't a smaller-but-true value. What a depth view
/// does show is the frontal plane (sideways trunk tilt, plant-foot width) and the timing
/// of events. A diagonal view shows both planes partly and foreshortened by an unknown
/// angle: only timings and ratios of speeds (percent changes) are kept, with reduced
/// confidence for the ratios.
enum PerspectiveMetricSupport {
    enum Support: Equatable, Sendable {
        /// Measured in the plane this perspective sees; multiply confidence by `factor`.
        case supported(factor: Double)
        case unsupported
    }

    /// Timings between events and the frontal-plane metrics.
    static let depthViewMetrics: Set<KickMetricKey> = [
        .plantToContactTime, .followThroughDuration, .lateralTrunkLeanAtContact, .plantFootWidth,
        .plantBallLateralOffset, .plantLateralMovement,
    ]
    /// Measured in the image plane of a rear/front view (sideways and vertical), so they
    /// are unsupported from the side or a diagonal.
    static let frontalPlaneMetrics: Set<KickMetricKey> = [.lateralTrunkLeanAtContact, .plantFootWidth,
                                                          .plantBallLateralOffset, .plantLateralMovement]

    static func support(_ key: KickMetricKey, context: BiomechanicsContext) -> Support {
        let definition = key.definition
        let perspective = context.effectivePerspective
        switch perspective {
        case .depthAway, .depthToward:
            return depthViewMetrics.contains(key) ? .supported(factor: 1) : .unsupported
        case .side, .oblique:
            if frontalPlaneMetrics.contains(key) { return .unsupported }
            // Build 19: the knee's forward swing relative to the hips is only seen from the side.
            if key == .kneeSwingAfterContact, perspective == .oblique { return .unsupported }
            // Timings between detected events don't depend on where the camera stood.
            if definition.timing == .interval { return .supported(factor: 1) }
            if perspective == .oblique {
                // A diagonal view foreshortens sagittal lengths, speeds and angles by an
                // unknown amount; a RATIO of two speeds along the same path keeps its value.
                return definition.unit == .percent ? .supported(factor: MetricConfidenceModel.cameraFactor(.oblique)) : .unsupported
            }
            // A side analysis of a video whose camera angle was set otherwise (the
            // movement contradicted the setting) is trusted like an unknown angle.
            let angle: VideoAngleType = context.cameraAngle == .side ? .side : .unknown
            return .supported(factor: MetricConfidenceModel.cameraFactor(angle))
        }
    }
}
