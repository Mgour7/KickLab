import Foundation

// Foundation for comparing kicks over time. Pure and storage-independent: callers build
// `MetricSnapshot`s from stored analyses (see `MetricSnapshot+Analysis.swift`). With no
// history, nothing here is needed and single-kick analysis works unchanged.

/// One kick's metric values, as stored.
struct MetricSnapshot: Codable, Equatable, Sendable {
    struct Value: Codable, Equatable, Sendable {
        var value: Double
        var confidence: Double?
        var status: MeasurementStatus
        var definitionVersion: Int
    }

    var analysisID: UUID?
    var kickID: UUID?
    var kickType: KickType
    var recordedAt: Date
    /// Only available metrics are kept.
    var values: [KickMetricKey: Value]

    init(analysisID: UUID? = nil, kickID: UUID? = nil, kickType: KickType, recordedAt: Date, values: [KickMetricKey: Value]) {
        self.analysisID = analysisID
        self.kickID = kickID
        self.kickType = kickType
        self.recordedAt = recordedAt
        self.values = values
    }

    /// Builds a snapshot from fresh measurements (unavailable ones are dropped).
    init(analysisID: UUID? = nil, kickID: UUID? = nil, kickType: KickType, recordedAt: Date, measurements: [KickMetricMeasurement]) {
        var values: [KickMetricKey: Value] = [:]
        for m in measurements where m.isAvailable {
            guard let v = m.value else { continue }
            values[m.key] = Value(value: v, confidence: m.confidence, status: m.status, definitionVersion: m.definitionVersion)
        }
        self.init(analysisID: analysisID, kickID: kickID, kickType: kickType, recordedAt: recordedAt, values: values)
    }
}

enum MetricChangeDirection: String, Codable, Sendable {
    case improved
    case worsened
    case unchanged
    /// The metric has no "better" direction.
    case notApplicable
}

/// The change in one metric between two kicks.
struct MetricDelta: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var current: Double
    var reference: Double
    var difference: Double
    /// Nil when the reference is (near) zero.
    var percentChange: Double?
    var direction: MetricChangeDirection
}

/// One metric of a kick against the athlete's baseline.
struct BaselineDeviation: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var value: Double
    var baselineMean: Double
    var difference: Double
    /// Nil when the baseline has no spread.
    var standardScore: Double?
    var direction: MetricChangeDirection
}

/// Per-metric statistics over an athlete's previous kicks of one type.
struct AthleteMetricBaseline: Codable, Equatable, Sendable {
    struct Statistic: Codable, Equatable, Sendable {
        var count: Int
        var mean: Double
        var median: Double
        var standardDeviation: Double
    }

    var kickType: KickType
    var kickCount: Int
    var statistics: [KickMetricKey: Statistic]
}

enum MetricComparison {
    /// Values below this confidence are ignored in comparisons.
    static let minimumConfidence = 0.5
    /// Differences smaller than this fraction of the reference count as unchanged.
    static let unchangedTolerance = 0.02

    /// Kick vs kick. Only metrics available in both, with the same definition version
    /// and enough confidence, are compared.
    static func compare(
        _ current: MetricSnapshot,
        to reference: MetricSnapshot,
        profile: BiomechanicsProfile? = nil
    ) -> [MetricDelta] {
        KickMetricKey.allCases.compactMap { key in
            guard let a = usable(current.values[key]), let b = usable(reference.values[key]),
                  a.definitionVersion == b.definitionVersion else { return nil }
            let difference = a.value - b.value
            let percent = abs(b.value) > 1e-9 ? MetricConfidenceModel.round3(100 * difference / abs(b.value)) : nil
            return MetricDelta(
                key: key, current: a.value, reference: b.value,
                difference: MetricConfidenceModel.round3(difference), percentChange: percent,
                direction: direction(key, current: a.value, reference: b.value, profile: profile)
            )
        }
    }

    /// The athlete's baseline from earlier kicks of `kickType`. Nil with fewer than
    /// `minimumKicks` kicks: single-kick analysis does not need a baseline.
    static func baseline(from history: [MetricSnapshot], kickType: KickType, minimumKicks: Int = 3) -> AthleteMetricBaseline? {
        let kicks = history.filter { $0.kickType == kickType }
        guard kicks.count >= minimumKicks else { return nil }
        var statistics: [KickMetricKey: AthleteMetricBaseline.Statistic] = [:]
        for key in KickMetricKey.allCases {
            let values = kicks.compactMap { usable($0.values[key])?.value }.sorted()
            guard values.count >= minimumKicks else { continue }
            let mean = values.reduce(0, +) / Double(values.count)
            let variance = values.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Double(values.count)
            let middle = values.count / 2
            let median = values.count.isMultiple(of: 2) ? (values[middle - 1] + values[middle]) / 2 : values[middle]
            statistics[key] = .init(count: values.count, mean: MetricConfidenceModel.round3(mean),
                                    median: MetricConfidenceModel.round3(median),
                                    standardDeviation: MetricConfidenceModel.round3(variance.squareRoot()))
        }
        return AthleteMetricBaseline(kickType: kickType, kickCount: kicks.count, statistics: statistics)
    }

    /// Kick vs the athlete's baseline.
    static func compare(
        _ snapshot: MetricSnapshot,
        to baseline: AthleteMetricBaseline,
        profile: BiomechanicsProfile? = nil
    ) -> [BaselineDeviation] {
        guard snapshot.kickType == baseline.kickType else { return [] }
        return KickMetricKey.allCases.compactMap { key in
            guard let value = usable(snapshot.values[key])?.value, let stat = baseline.statistics[key] else { return nil }
            let difference = value - stat.mean
            return BaselineDeviation(
                key: key, value: value, baselineMean: stat.mean,
                difference: MetricConfidenceModel.round3(difference),
                standardScore: stat.standardDeviation > 1e-9 ? MetricConfidenceModel.round3(difference / stat.standardDeviation) : nil,
                direction: direction(key, current: value, reference: stat.mean, profile: profile)
            )
        }
    }

    /// A metric's values over time, oldest first, with the least-squares slope per day.
    static func trend(of key: KickMetricKey, in history: [MetricSnapshot]) -> (points: [(date: Date, value: Double)], slopePerDay: Double?) {
        let points = history
            .compactMap { s in usable(s.values[key]).map { (date: s.recordedAt, value: $0.value) } }
            .sorted { $0.date < $1.date }
        guard points.count >= 2, let first = points.first?.date else { return (points, nil) }
        let xs = points.map { $0.date.timeIntervalSince(first) / 86_400 }
        let ys = points.map(\.value)
        let mx = xs.reduce(0, +) / Double(xs.count)
        let my = ys.reduce(0, +) / Double(ys.count)
        let sxx = xs.map { ($0 - mx) * ($0 - mx) }.reduce(0, +)
        guard sxx > 0 else { return (points, nil) }
        let sxy = zip(xs, ys).map { ($0 - mx) * ($1 - my) }.reduce(0, +)
        return (points, sxy / sxx)
    }

    // MARK: Helpers

    private static func usable(_ value: MetricSnapshot.Value?) -> MetricSnapshot.Value? {
        guard let value, value.status != .unavailable, value.value.isFinite else { return nil }
        if let confidence = value.confidence, confidence < minimumConfidence { return nil }
        return value
    }

    static func direction(_ key: KickMetricKey, current: Double, reference: Double, profile: BiomechanicsProfile?) -> MetricChangeDirection {
        let scale = max(abs(reference), 1e-9)
        switch key.definition.betterDirection {
        case .none:
            return .notApplicable
        case .higher:
            if abs(current - reference) <= unchangedTolerance * scale { return .unchanged }
            return current > reference ? .improved : .worsened
        case .lower:
            if abs(current - reference) <= unchangedTolerance * scale { return .unchanged }
            return current < reference ? .improved : .worsened
        case .towardIdealBand:
            guard let band = profile?.scoring[key]?.band else { return .notApplicable }
            let now = band.distanceFromIdeal(current)
            let before = band.distanceFromIdeal(reference)
            if abs(now - before) <= unchangedTolerance * scale { return .unchanged }
            return now < before ? .improved : .worsened
        }
    }
}
