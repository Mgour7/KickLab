import Foundation

// MARK: - Units and conventions
//
// A single phone video cannot establish real-world distance, so KickLab measures
// sizes in BODY LENGTHS (the athlete's torso length: shoulder midpoint to hip midpoint,
// measured in the same video) and speeds in body lengths per second. No metric is
// reported in mph, m/s, yards, force, ball speed or launch angle.
//
// "Forward" is the athlete's direction of travel. Torso lean is positive when the
// shoulders are ahead of the hips (leaning toward the target) and negative when
// leaning back. All left/right decisions come from the athlete's kicking foot.

/// The biomechanics metrics KickLab derives from pose. The raw value is the stored
/// `BiomechanicalMetric.metricKey`; once shipped, a key is never renamed or reused.
enum KickMetricKey: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    // Approach
    case approachSpeed = "approach.speed"
    case approachSpeedVariation = "approach.speedVariation"
    case approachLateSpeedChange = "approach.lateSpeedChange"
    // Plant
    case plantToContactTime = "plant.toContactTime"
    case plantFootDrift = "plant.footDrift"
    case plantKneeAngleAtContact = "plant.kneeAngleAtContact"
    // Swing
    case kickingKneeAngleAtContact = "swing.kickingKneeAngleAtContact"
    case kickingHipAngleAtContact = "swing.kickingHipAngleAtContact"
    case backswingDepth = "swing.backswingDepth"
    case peakFootSpeed = "swing.peakFootSpeed"
    case footSpeedAtContact = "swing.footSpeedAtContact"
    // Body position at contact
    case torsoLeanAtContact = "contact.torsoLean"
    case torsoLeanRange = "contact.torsoLeanRange"
    case bodyForwardSpeedAtContact = "contact.bodyForwardSpeed"
    // Follow-through
    case followThroughDuration = "followThrough.duration"
    case followThroughFootHeight = "followThrough.footHeight"
    case followThroughBodyTravel = "followThrough.bodyTravel"
    // Step 12E: frontal-plane measurements, visible from behind or in front (not from the
    // side). Informational: reported, not scored.
    case lateralTrunkLeanAtContact = "contact.lateralTrunkLean"
    case plantFootWidth = "plant.lateralFootOffset"

    var definition: KickMetricDefinition { KickMetricCatalog.definition(for: self) }
}

/// Which direction of change is an improvement, for comparisons over time.
enum MetricBetterDirection: String, Codable, Sendable {
    case higher
    case lower
    /// Closer to the scoring profile's ideal band is better.
    case towardIdealBand
    /// Informational only; no direction is implied.
    case none
}

/// The timing anchor a metric is read at or over.
enum MetricTiming: String, Codable, Sendable {
    /// Averaged or extremal over a phase window.
    case window
    /// Read at the estimated contact instant (sensitive to frame rate).
    case contactInstant
    /// A duration between phase events.
    case interval
}

/// Static facts about one metric: what it means, its unit, phase and category.
struct KickMetricDefinition: Equatable, Sendable {
    let key: KickMetricKey
    /// Bumped whenever the computation changes meaning.
    let definitionVersion: Int
    let displayName: String
    let explanation: String
    let unit: MetricUnit
    let phase: MechanicsPhase
    let category: AnalysisCategory
    let timing: MetricTiming
    let betterDirection: MetricBetterDirection
    /// True when the value relies on the estimated (not ball-confirmed) contact time.
    let dependsOnContact: Bool
    /// The kick phases that must be available for the metric to exist.
    let requiredPhases: [KickPhase]
}

/// The code catalog of metric definitions (display names and units live here, not in
/// stored data, so they can change without a migration).
enum KickMetricCatalog {
    static let all: [KickMetricDefinition] = KickMetricKey.allCases.map { definition(for: $0) }

    static func definition(for key: KickMetricKey) -> KickMetricDefinition {
        switch key {
        case .approachSpeed:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Approach speed",
                explanation: "Average forward speed of the hips during the approach, in body lengths per second.",
                unit: .bodyLengthsPerSecond, phase: .approach, category: .approach, timing: .window,
                betterDirection: .towardIdealBand, dependsOnContact: false, requiredPhases: [.approach]
            )
        case .approachSpeedVariation:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Approach speed variation",
                explanation: "How much forward speed varies during the approach (standard deviation ÷ mean). Lower is more consistent.",
                unit: .percent, phase: .approach, category: .approach, timing: .window,
                betterDirection: .lower, dependsOnContact: false, requiredPhases: [.approach]
            )
        case .approachLateSpeedChange:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Speed change into the plant",
                explanation: "Forward speed in the last 0.2 s before the plant compared with the rest of the approach. Negative = slowing down.",
                unit: .percent, phase: .approach, category: .approach, timing: .window,
                betterDirection: .towardIdealBand, dependsOnContact: false, requiredPhases: [.approach, .plant]
            )
        case .plantToContactTime:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Plant to contact",
                explanation: "Time from plant-foot touchdown to estimated contact.",
                unit: .seconds, phase: .plant, category: .plant, timing: .interval,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.plant, .contact]
            )
        case .plantFootDrift:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Plant-foot movement",
                explanation: "Largest movement of the plant ankle within 0.1 s of estimated contact, in body lengths. Lower is more stable.",
                unit: .bodyLengths, phase: .plant, category: .plant, timing: .window,
                betterDirection: .lower, dependsOnContact: true, requiredPhases: [.plant, .contact]
            )
        case .plantKneeAngleAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Plant knee angle at contact",
                explanation: "Hip–knee–ankle angle of the plant leg at estimated contact (180° = straight).",
                unit: .degrees, phase: .contact, category: .plant, timing: .contactInstant,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.plant, .contact]
            )
        case .kickingKneeAngleAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Kicking knee angle at contact",
                explanation: "Hip–knee–ankle angle of the kicking leg at estimated contact (180° = fully extended).",
                unit: .degrees, phase: .contact, category: .swing, timing: .contactInstant,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .kickingHipAngleAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Kicking hip angle at contact",
                explanation: "Shoulder–hip–knee angle on the kicking side at estimated contact.",
                unit: .degrees, phase: .contact, category: .swing, timing: .contactInstant,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .backswingDepth:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Backswing depth",
                explanation: "Furthest the kicking ankle travels behind the kicking hip between 0.3 s before the plant and contact, in body lengths (a 2D proxy for hip extension).",
                unit: .bodyLengths, phase: .swing, category: .swing, timing: .window,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.plant, .contact]
            )
        case .peakFootSpeed:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Peak kicking-foot speed",
                explanation: "Fastest kicking-ankle speed from 0.3 s before to 0.1 s after estimated contact, in body lengths per second. Pose sampling underestimates very fast swings.",
                unit: .bodyLengthsPerSecond, phase: .swing, category: .swing, timing: .contactInstant,
                betterDirection: .higher, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .footSpeedAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Kicking-foot speed at contact",
                explanation: "Kicking-ankle speed at estimated contact. Equals the peak speed today because contact is estimated at the speed peak; it will differ once ball tracking confirms contact. Informational; not scored.",
                unit: .bodyLengthsPerSecond, phase: .contact, category: .swing, timing: .contactInstant,
                betterDirection: .higher, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .torsoLeanAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Torso lean at contact",
                explanation: "Trunk angle from vertical at estimated contact. Positive = leaning toward the target, negative = leaning back.",
                unit: .degrees, phase: .contact, category: .contact, timing: .contactInstant,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .torsoLeanRange:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Torso movement through the swing",
                explanation: "Range of torso lean from the plant to the end of the follow-through. Lower = steadier trunk.",
                unit: .degrees, phase: .swing, category: .contact, timing: .window,
                betterDirection: .lower, dependsOnContact: true, requiredPhases: [.plant, .contact, .followThrough]
            )
        case .bodyForwardSpeedAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Body speed through the ball",
                explanation: "Forward speed of the hips at estimated contact, in body lengths per second.",
                unit: .bodyLengthsPerSecond, phase: .contact, category: .contact, timing: .contactInstant,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .followThroughDuration:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Follow-through duration",
                explanation: "Time from estimated contact until the kicking foot slows to a quarter of its peak speed.",
                unit: .seconds, phase: .followThrough, category: .followThrough, timing: .interval,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact, .followThrough]
            )
        case .followThroughFootHeight:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Follow-through leg height",
                explanation: "Highest the kicking ankle rises relative to the kicking hip during the follow-through, in body lengths (positive = above the hip).",
                unit: .bodyLengths, phase: .followThrough, category: .followThrough, timing: .window,
                betterDirection: .higher, dependsOnContact: true, requiredPhases: [.contact, .followThrough]
            )
        case .followThroughBodyTravel:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Body travel after contact",
                explanation: "Forward movement of the hips from estimated contact to the end of the follow-through, in body lengths.",
                unit: .bodyLengths, phase: .followThrough, category: .followThrough, timing: .window,
                betterDirection: .towardIdealBand, dependsOnContact: true, requiredPhases: [.contact, .followThrough]
            )
        case .lateralTrunkLeanAtContact:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Sideways trunk lean at contact",
                explanation: "Trunk tilt from vertical toward the plant-leg side (positive) or the kicking-leg side (negative) at estimated contact. Measured only when filmed from behind or in front. Informational; not scored.",
                unit: .degrees, phase: .contact, category: .contact, timing: .contactInstant,
                betterDirection: .none, dependsOnContact: true, requiredPhases: [.contact]
            )
        case .plantFootWidth:
            KickMetricDefinition(
                key: key, definitionVersion: 1, displayName: "Plant foot width",
                explanation: "How far the plant ankle is to the side of the hips' center at estimated contact, in torso lengths (positive = out to the plant-leg side). Measured only when filmed from behind or in front. Informational; not scored.",
                unit: .bodyLengths, phase: .plant, category: .plant, timing: .contactInstant,
                betterDirection: .none, dependsOnContact: true, requiredPhases: [.plant, .contact]
            )
        }
    }

    /// Metrics in a category, in catalog order.
    static func keys(in category: AnalysisCategory) -> [KickMetricKey] {
        KickMetricKey.allCases.filter { definition(for: $0).category == category }
    }

    /// The categories scored for kick mechanics, in display order.
    static let scoredCategories: [AnalysisCategory] = [.approach, .plant, .swing, .contact, .followThrough]
}
