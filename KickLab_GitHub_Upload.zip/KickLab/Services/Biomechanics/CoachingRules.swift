import Foundation

/// The rule-based coaching rules. Raw values are stored as `CoachingObservation.ruleKey`.
enum CoachingRuleKey: String, CaseIterable, Codable, Sendable {
    // IMPROVE
    case plantLate = "plant.timingLate"
    case plantEarly = "plant.timingEarly"
    case plantUnstable = "plant.unstable"
    case torsoLeaningBack = "contact.torsoLeaningBack"
    case torsoLeaningForward = "contact.torsoLeaningForward"
    case limitedKneeExtension = "swing.limitedKneeExtension"
    case followThroughShort = "followThrough.short"
    case approachSpeedChange = "approach.sharpSpeedChange"
    // KEEP
    case plantStable = "plant.stable"
    case fullKneeExtension = "swing.fullKneeExtension"
    case highFinish = "followThrough.highFinish"
}

/// One coaching conclusion with all its evidence. Kept in the analysis artifact whether
/// or not it was issued, so suppressed findings remain traceable.
struct CoachingFinding: Codable, Equatable, Sendable {
    var rule: CoachingRuleKey
    /// `.improve` or `.keep`.
    var kind: ObservationKind
    var category: AnalysisCategory
    /// What was observed, including the measured value.
    var observed: String
    var whyItMatters: String
    /// A concise, actionable cue (IMPROVE only).
    var cue: String?
    /// IMPROVE only.
    var severity: CoachingSeverity?
    /// The confidence of the evidence metric.
    var confidence: Double
    var evidence: [KickMetricKey]
    var measuredValue: Double
    var unit: MetricUnit
    /// The threshold the rule compared against.
    var threshold: Double
    /// 0 = most important within its kind. Nil until ranked.
    var rank: Int?
    /// False when it did not make the cut (ranked below the observation limit).
    var issued: Bool
}

/// Rule evaluation, ranking and conversion to stored observation drafts.
///
/// Rules fire only when their evidence metric is available and its confidence is at
/// least `minimumImproveConfidence` (IMPROVE) or `minimumKeepConfidence` (KEEP). There is
/// no coaching claim without enough evidence. Wording is coaching-oriented and factual;
/// no injury or medical statements.
enum CoachingEngine {
    // MARK: Evaluate

    static func findings(for measurements: [KickMetricMeasurement], profile: BiomechanicsProfile) -> [CoachingFinding] {
        let byKey = Dictionary(uniqueKeysWithValues: measurements.map { ($0.key, $0) })
        let t = profile.coaching
        var results: [CoachingFinding] = []

        func value(_ key: KickMetricKey, minimum: Double) -> (Double, Double)? {
            guard let m = byKey[key], m.isAvailable, let v = m.value, let c = m.confidence, c >= minimum else { return nil }
            return (v, c)
        }
        let improveMin = profile.minimumImproveConfidence
        let keepMin = profile.minimumKeepConfidence

        // Plant timing: Build 18 (engine 3.0.0) issues no plant-timing advice. The rules
        // (`plantLate`, `plantEarly`) stay defined so older analyses still decode and show
        // what they issued, but no validated criterion supports telling an athlete to change
        // the interval, so they no longer fire.

        // Plant stability.
        if let (v, c) = value(.plantFootDrift, minimum: improveMin), v > t.plantUnstableAboveBodyLengths {
            results.append(improve(.plantUnstable, .plant, value: v, unit: .bodyLengths, threshold: t.plantUnstableAboveBodyLengths,
                                   span: 0.4, confidence: c, evidence: [.plantFootDrift],
                                   observed: "Plant foot moved \(fmt(v)) torso lengths around estimated contact.",
                                   why: "A plant foot that slides or rolls shifts the hips and makes contact harder to repeat.",
                                   cue: "Drive the plant foot into the ground and keep it still through the ball."))
        }
        if let (v, c) = value(.plantFootDrift, minimum: keepMin), v <= t.plantStableAtMostBodyLengths {
            results.append(keep(.plantStable, .plant, value: v, unit: .bodyLengths, threshold: t.plantStableAtMostBodyLengths,
                                confidence: c, evidence: [.plantFootDrift],
                                observed: "Plant foot stayed stable through contact (\(fmt(v)) torso lengths of movement).",
                                why: "A still plant foot gives the swing a solid base."))
        }

        // Torso at contact.
        if let (v, c) = value(.torsoLeanAtContact, minimum: improveMin) {
            if v < t.torsoLeanBackBelowDegrees {
                results.append(improve(.torsoLeaningBack, .contact, value: v, unit: .degrees, threshold: t.torsoLeanBackBelowDegrees,
                                       span: 20, confidence: c, evidence: [.torsoLeanAtContact],
                                       observed: "Torso was leaning back \(fmt(-v, 0))° at estimated contact.",
                                       why: "Leaning well back sends energy upward instead of through the ball.",
                                       cue: "Keep your chest over the ball at contact."))
            } else if v > t.torsoLeanForwardAboveDegrees {
                results.append(improve(.torsoLeaningForward, .contact, value: v, unit: .degrees, threshold: t.torsoLeanForwardAboveDegrees,
                                       span: 20, confidence: c, evidence: [.torsoLeanAtContact],
                                       observed: "Torso was leaning forward \(fmt(v, 0))° at estimated contact.",
                                       why: "Leaning far forward crowds the swing and can drive the ball low.",
                                       cue: "Stay tall through the ball: chest up, eyes on the ball."))
            }
        }

        // Kicking-leg extension.
        if let (v, c) = value(.kickingKneeAngleAtContact, minimum: improveMin), v < t.kneeExtensionLimitedBelowDegrees {
            results.append(improve(.limitedKneeExtension, .swing, value: v, unit: .degrees, threshold: t.kneeExtensionLimitedBelowDegrees,
                                   span: 40, confidence: c, evidence: [.kickingKneeAngleAtContact],
                                   observed: "Kicking knee was bent to \(fmt(v, 0))° at estimated contact.",
                                   why: "A bent knee at contact shortens the kicking leg's lever, so less foot speed reaches the ball.",
                                   cue: "Snap the knee straight through the ball."))
        }
        if let (v, c) = value(.kickingKneeAngleAtContact, minimum: keepMin), v >= t.kneeExtensionFullAtLeastDegrees {
            results.append(keep(.fullKneeExtension, .swing, value: v, unit: .degrees, threshold: t.kneeExtensionFullAtLeastDegrees,
                                confidence: c, evidence: [.kickingKneeAngleAtContact],
                                observed: "Kicking leg was nearly fully extended at contact (\(fmt(v, 0))°).",
                                why: "Full extension carries the most foot speed into the ball."))
        }

        // Follow-through.
        if let (v, c) = value(.followThroughDuration, minimum: improveMin), v < t.followThroughShortBelowSeconds {
            results.append(improve(.followThroughShort, .followThrough, value: v, unit: .seconds, threshold: t.followThroughShortBelowSeconds,
                                   span: 0.04, confidence: c, evidence: [.followThroughDuration],
                                   observed: "Follow-through ended \(fmt(v)) s after estimated contact.",
                                   why: "Cutting the leg off early often means the swing is already slowing down at contact.",
                                   cue: "Let the kicking leg swing up and through toward the target."))
        }
        if let (v, c) = value(.followThroughFootHeight, minimum: keepMin), v >= t.followThroughHighAtLeastBodyLengths {
            results.append(keep(.highFinish, .followThrough, value: v, unit: .bodyLengths, threshold: t.followThroughHighAtLeastBodyLengths,
                                confidence: c, evidence: [.followThroughFootHeight],
                                observed: "Kicking leg finished high (\(fmt(v)) torso lengths above the hip).",
                                why: "A high finish shows the leg kept moving through the ball."))
        }

        // Approach rhythm.
        if let (v, c) = value(.approachLateSpeedChange, minimum: improveMin), abs(v) > t.approachSpeedChangeAbovePercent {
            let direction = v < 0 ? "dropped" : "rose"
            results.append(improve(.approachSpeedChange, .approach, value: v, unit: .percent, threshold: t.approachSpeedChangeAbovePercent,
                                   span: 50, confidence: c, evidence: [.approachLateSpeedChange, .approachSpeed],
                                   observed: "Approach speed \(direction) \(fmt(abs(v), 0))% in the last 0.2 s before the plant.",
                                   why: "Sharp speed changes in the final steps make the plant position harder to repeat.",
                                   cue: "Keep the same rhythm through your last two steps."))
        }

        return rank(results, profile: profile)
    }

    // MARK: Rank

    /// Category order used to break ties: the base of the kick first.
    static let categoryOrder: [AnalysisCategory] = [.plant, .swing, .contact, .approach, .followThrough]

    static func severityRank(_ severity: CoachingSeverity?) -> Int {
        switch severity {
        case .high: 3
        case .moderate: 2
        case .low: 1
        case .info, .none: 0
        }
    }

    /// Deterministic ranking. IMPROVE: severity, then category order, then confidence,
    /// then rule key. KEEP: confidence, then category order, then rule key. Only the top
    /// `maximumImproveObservations` / `maximumKeepObservations` are issued.
    static func rank(_ findings: [CoachingFinding], profile: BiomechanicsProfile) -> [CoachingFinding] {
        func categoryIndex(_ c: AnalysisCategory) -> Int { categoryOrder.firstIndex(of: c) ?? categoryOrder.count }
        let improves = findings.filter { $0.kind == .improve }.sorted { a, b in
            if severityRank(a.severity) != severityRank(b.severity) { return severityRank(a.severity) > severityRank(b.severity) }
            if categoryIndex(a.category) != categoryIndex(b.category) { return categoryIndex(a.category) < categoryIndex(b.category) }
            if a.confidence != b.confidence { return a.confidence > b.confidence }
            return a.rule.rawValue < b.rule.rawValue
        }
        let keeps = findings.filter { $0.kind == .keep }.sorted { a, b in
            if a.confidence != b.confidence { return a.confidence > b.confidence }
            if categoryIndex(a.category) != categoryIndex(b.category) { return categoryIndex(a.category) < categoryIndex(b.category) }
            return a.rule.rawValue < b.rule.rawValue
        }
        var ranked: [CoachingFinding] = []
        for (i, var finding) in improves.enumerated() {
            finding.rank = i
            finding.issued = i < profile.maximumImproveObservations
            ranked.append(finding)
        }
        for (i, var finding) in keeps.enumerated() {
            finding.rank = i
            finding.issued = i < profile.maximumKeepObservations
            ranked.append(finding)
        }
        return ranked
    }

    // MARK: Drafts

    /// Stored observations for the issued findings: each IMPROVE immediately followed by
    /// its CUE (linked by `relatedObservationID`), then the KEEPs. IDs are derived from
    /// `seed` and the rule, so identical input gives identical output.
    static func drafts(for findings: [CoachingFinding], seed: UUID) -> [CoachingObservationDraft] {
        var drafts: [CoachingObservationDraft] = []
        for finding in findings where finding.issued && finding.kind == .improve {
            let improveID = DeterministicID.make(seed: seed, name: finding.rule.rawValue + "#improve")
            let evidence = finding.evidence.map(\.rawValue)
            drafts.append(CoachingObservationDraft(
                id: improveID, kind: .improve, category: finding.category,
                message: "\(finding.observed) \(finding.whyItMatters)",
                severity: finding.severity, confidence: finding.confidence, priority: finding.rank ?? 0,
                comparisonBasis: .absolute, evidenceMetricKeys: evidence, relatedObservationID: nil,
                ruleKey: finding.rule.rawValue, source: .engine
            ))
            if let cue = finding.cue {
                drafts.append(CoachingObservationDraft(
                    id: DeterministicID.make(seed: seed, name: finding.rule.rawValue + "#cue"), kind: .cue,
                    category: finding.category, message: cue, severity: nil, confidence: finding.confidence,
                    priority: finding.rank ?? 0, comparisonBasis: .absolute, evidenceMetricKeys: evidence,
                    relatedObservationID: improveID, ruleKey: finding.rule.rawValue, source: .engine
                ))
            }
        }
        for finding in findings where finding.issued && finding.kind == .keep {
            drafts.append(CoachingObservationDraft(
                id: DeterministicID.make(seed: seed, name: finding.rule.rawValue + "#keep"), kind: .keep,
                category: finding.category, message: "\(finding.observed) \(finding.whyItMatters)",
                severity: nil, confidence: finding.confidence, priority: finding.rank ?? 0,
                comparisonBasis: .absolute, evidenceMetricKeys: finding.evidence.map(\.rawValue),
                relatedObservationID: nil, ruleKey: finding.rule.rawValue, source: .engine
            ))
        }
        return drafts
    }

    // MARK: Helpers

    /// Severity from how far past the threshold the value is, relative to `span`:
    /// under ⅓ low, under ⅔ moderate, otherwise high.
    static func severity(value: Double, threshold: Double, span: Double) -> CoachingSeverity {
        let fraction = abs(value - threshold) / span
        if fraction < 1.0 / 3.0 { return .low }
        if fraction < 2.0 / 3.0 { return .moderate }
        return .high
    }

    private static func improve(
        _ rule: CoachingRuleKey, _ category: AnalysisCategory, value: Double, unit: MetricUnit, threshold: Double,
        span: Double, confidence: Double, evidence: [KickMetricKey], observed: String, why: String, cue: String
    ) -> CoachingFinding {
        // For the two-sided approach rule, severity is measured on the magnitude.
        let measured = rule == .approachSpeedChange ? abs(value) : value
        return CoachingFinding(
            rule: rule, kind: .improve, category: category, observed: observed, whyItMatters: why, cue: cue,
            severity: severity(value: measured, threshold: threshold, span: span), confidence: confidence,
            evidence: evidence, measuredValue: value, unit: unit, threshold: threshold, rank: nil, issued: false
        )
    }

    private static func keep(
        _ rule: CoachingRuleKey, _ category: AnalysisCategory, value: Double, unit: MetricUnit, threshold: Double,
        confidence: Double, evidence: [KickMetricKey], observed: String, why: String
    ) -> CoachingFinding {
        CoachingFinding(
            rule: rule, kind: .keep, category: category, observed: observed, whyItMatters: why, cue: nil,
            severity: nil, confidence: confidence, evidence: evidence, measuredValue: value, unit: unit,
            threshold: threshold, rank: nil, issued: false
        )
    }

    /// Locale-independent fixed-point formatting.
    static func fmt(_ value: Double, _ digits: Int = 2) -> String {
        let text = String(format: "%.\(digits)f", value)
        return text.hasPrefix("-") && Double(text) == 0 ? String(text.dropFirst()) : text
    }
}

/// Name-based UUIDs (FNV-1a over seed + name), so re-running identical input yields
/// identical observation IDs. Not cryptographic; uniqueness comes from the per-run seed.
enum DeterministicID {
    static func make(seed: UUID, name: String) -> UUID {
        let bytes = Array((seed.uuidString + "|" + name).utf8)
        let a = fnv1a(bytes, offset: 0xcbf2_9ce4_8422_2325)
        let b = fnv1a(bytes, offset: 0x8422_2325_cbf2_9ce4)
        var raw = [UInt8](repeating: 0, count: 16)
        for i in 0..<8 {
            raw[i] = UInt8(truncatingIfNeeded: a >> (8 * UInt64(i)))
            raw[8 + i] = UInt8(truncatingIfNeeded: b >> (8 * UInt64(i)))
        }
        raw[6] = (raw[6] & 0x0F) | 0x50   // version 5 layout
        raw[8] = (raw[8] & 0x3F) | 0x80   // RFC 4122 variant
        return UUID(uuid: (raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7],
                           raw[8], raw[9], raw[10], raw[11], raw[12], raw[13], raw[14], raw[15]))
    }

    private static func fnv1a(_ bytes: [UInt8], offset: UInt64) -> UInt64 {
        var hash = offset
        for byte in bytes {
            hash ^= UInt64(byte)
            hash = hash &* 0x0000_0100_0000_01B3
        }
        return hash
    }
}
