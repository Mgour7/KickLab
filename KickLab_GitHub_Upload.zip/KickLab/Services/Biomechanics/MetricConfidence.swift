import Foundation

/// Why a metric could not be reported.
enum MetricUnavailableReason: String, Codable, Equatable, Sendable {
    /// Not supported for this kick type in this version (e.g. plant metrics for punts).
    case unsupportedKickType
    /// No kicker was selected, so there is no pose to measure.
    case noKicker
    /// A phase the metric depends on was not detected.
    case phaseUnavailable
    /// Too few frames in the measurement window.
    case insufficientSamples
    /// The joints the metric needs were not visible often enough.
    case missingJoints
    /// The joints were visible but the combined confidence is too low to report.
    case lowConfidence
    /// The value is undefined for this kick (e.g. speed variation of a standing start).
    case notComputable
}

/// A coarse label for a 0...1 confidence, for display and rules.
enum ConfidenceLevel: String, Codable, Equatable, Sendable {
    case high
    case medium
    case low
    case insufficient

    init(_ confidence: Double?) {
        guard let confidence else { self = .insufficient; return }
        switch confidence {
        case 0.75...: self = .high
        case 0.5..<0.75: self = .medium
        case 0.25..<0.5: self = .low
        default: self = .insufficient
        }
    }
}

/// The factors behind a metric's confidence, kept so every number is explainable.
///
/// `combined = jointQuality × phaseFactor × sampleFactor × frameRateFactor × cameraFactor`,
/// rounded to 3 decimals.
struct MetricConfidenceInputs: Codable, Equatable, Sendable {
    /// Mean over every (sample, joint) used of: Vision confidence × 1.0 (measured)
    /// or × 0.6 (interpolated); a missing joint counts as 0.
    var jointQuality: Double
    /// Fraction of (sample, joint) pairs that were available.
    var jointCoverage: Double
    /// Fraction of available pairs that were interpolated rather than measured.
    var interpolatedFraction: Double
    /// Product over the phases used: detected 1.0, estimated 0.85, ambiguous 0.4.
    var phaseFactor: Double
    /// Samples used ÷ samples wanted, capped at 1.
    var sampleFactor: Double
    /// For kicking-leg values read at contact: analysis frame rate ÷ 120, clamped to 0.7...1.
    var frameRateFactor: Double
    /// Side view 1.0; unknown 0.85; rear, front or behind-goal 0.5. Applies to 2D
    /// side-plane metrics (positions, angles, speeds); timing intervals use 1.0.
    var cameraFactor: Double
    var samplesUsed: Int

    var combined: Double {
        MetricConfidenceModel.round3(jointQuality * phaseFactor * sampleFactor * frameRateFactor * cameraFactor)
    }
}

/// Deterministic confidence rules.
enum MetricConfidenceModel {
    static let interpolatedWeight = 0.6
    static let minimumJointCoverage = 0.5

    static func phaseFactor(_ status: PhaseDetectionStatus) -> Double? {
        switch status {
        case .detected: 1.0
        case .estimated: 0.85
        case .ambiguous: 0.4
        case .unavailable: nil
        }
    }

    static func cameraFactor(_ angle: VideoAngleType) -> Double {
        switch angle {
        case .side: 1.0
        case .unknown: 0.85
        case .rear, .front, .behindGoal: 0.5
        }
    }

    static func frameRateFactor(framesPerSecond: Double?) -> Double {
        guard let fps = framesPerSecond, fps > 0 else { return 0.7 }
        return min(1, max(0.7, fps / 120))
    }

    struct JointStats: Equatable {
        var quality: Double
        var coverage: Double
        var interpolatedFraction: Double
    }

    /// Joint quality over the given samples and joints of a timeline.
    static func jointStats(_ timeline: KickerPoseTimeline, indices: [Int], joints: [PoseJoint]) -> JointStats {
        var total = 0
        var available = 0
        var interpolated = 0
        var quality = 0.0
        for i in indices where timeline.samples.indices.contains(i) {
            for joint in joints {
                total += 1
                guard let point = timeline.samples[i].joints[joint], point.isAvailable else { continue }
                available += 1
                if point.status == .interpolated {
                    interpolated += 1
                    quality += point.confidence * interpolatedWeight
                } else {
                    quality += point.confidence
                }
            }
        }
        guard total > 0 else { return JointStats(quality: 0, coverage: 0, interpolatedFraction: 0) }
        return JointStats(
            quality: quality / Double(total),
            coverage: Double(available) / Double(total),
            interpolatedFraction: available == 0 ? 0 : Double(interpolated) / Double(available)
        )
    }

    static func round3(_ x: Double) -> Double { (x * 1000).rounded() / 1000 }
}
