import Foundation

/// One metric as measured for one kick, with everything needed to explain it.
struct KickMetricMeasurement: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var definitionVersion: Int
    /// Nil whenever `status == .unavailable`. Never a placeholder.
    var value: Double?
    var unit: MetricUnit
    var status: MeasurementStatus
    /// 0...1, nil when unavailable.
    var confidence: Double?
    var confidenceLevel: ConfidenceLevel
    var phase: MechanicsPhase
    /// The instant the value refers to (contact, plant, …), when it is a single instant.
    var sampleTime: Double?
    /// The time window the value was computed over, when it is a window.
    var windowStart: Double?
    var windowEnd: Double?
    var unavailableReason: MetricUnavailableReason?
    /// The phase whose absence made the metric unavailable, if any.
    var missingPhase: KickPhase?
    /// The factors behind `confidence` (nil when unavailable before measuring).
    var confidenceInputs: MetricConfidenceInputs?

    var isAvailable: Bool { status != .unavailable && value != nil }

    static func unavailable(
        _ key: KickMetricKey,
        reason: MetricUnavailableReason,
        missingPhase: KickPhase? = nil,
        inputs: MetricConfidenceInputs? = nil
    ) -> KickMetricMeasurement {
        let definition = key.definition
        return KickMetricMeasurement(
            key: key, definitionVersion: definition.definitionVersion, value: nil, unit: definition.unit,
            status: .unavailable, confidence: nil, confidenceLevel: .insufficient, phase: definition.phase,
            sampleTime: nil, windowStart: nil, windowEnd: nil, unavailableReason: reason,
            missingPhase: missingPhase, confidenceInputs: inputs
        )
    }

    /// The draft `AnalysisService` validates and stores.
    func draft(sourceAngle: VideoAngleType?) -> MetricDraft {
        MetricDraft(
            metricKey: key.rawValue,
            metricDefinitionVersion: definitionVersion,
            value: isAvailable ? value : nil,
            unit: unit,
            confidence: isAvailable ? confidence : nil,
            measurementStatus: isAvailable ? status : .unavailable,
            phase: phase,
            sampleTimeSeconds: isAvailable ? sampleTime.map { max(0, $0) } : nil,
            sourceAngle: sourceAngle
        )
    }
}

/// Everything the extractor reads. All Step 7 outputs; nothing new is detected here.
struct KickMetricInput: Sendable {
    /// The PROCESSED kicker timeline (thresholded, gap-filled, smoothed).
    var timeline: KickerPoseTimeline
    var signals: PoseSignalSet
    var phases: KickPhaseDetectionResult
    var context: BiomechanicsContext
    var profile: BiomechanicsProfile
}

/// Pure, deterministic extraction of football-kicking metrics from pose, signals and
/// phases. Every metric in `KickMetricKey` is returned (in catalog order), available or not.
///
/// Rules:
/// - A metric whose required phase is unavailable is unavailable. Ambiguous phases
///   reduce confidence (× 0.4); no other timestamp is ever substituted.
/// - Missing joints and low confidence make a metric unavailable, never zero.
/// - Sizes and speeds are in body lengths (torso length); without a body scale, those
///   metrics are unavailable.
/// - All side-specific joints come from the athlete's kicking foot.
enum KickMetricExtractor {
    static func extract(_ input: KickMetricInput) -> [KickMetricMeasurement] {
        let workspace = Workspace(input)
        return KickMetricKey.allCases.map { workspace.measure($0) }
    }

    /// Unavailable measurements for every metric, e.g. when no kicker was found.
    static func allUnavailable(reason: MetricUnavailableReason) -> [KickMetricMeasurement] {
        KickMetricKey.allCases.map { .unavailable($0, reason: reason) }
    }

    // MARK: - Workspace

    private struct Workspace {
        let input: KickMetricInput
        let times: [Double]
        let sides: KickingSideJoints
        let aspect: Double
        let scale: Double?
        let forward: Double
        let framesPerSecond: Double?
        let cameraFactor: Double

        init(_ input: KickMetricInput) {
            self.input = input
            times = input.signals.timestamps
            sides = KickingSideJoints(kickingFoot: input.context.kickingFoot)
            aspect = input.timeline.displayAspectRatio ?? 1
            scale = input.signals.bodyScale
            forward = Double(input.signals.travelDirection == 0 ? 1 : input.signals.travelDirection)
            framesPerSecond = Self.frameRate(input.signals.timestamps)
            cameraFactor = MetricConfidenceModel.cameraFactor(input.context.cameraAngle)
        }

        static func frameRate(_ times: [Double]) -> Double? {
            var gaps: [Double] = []
            for i in times.indices.dropFirst() where times[i] > times[i - 1] {
                gaps.append(times[i] - times[i - 1])
            }
            gaps.sort()
            guard !gaps.isEmpty else { return nil }
            return 1 / gaps[gaps.count / 2]
        }

        // MARK: Lookup

        func phase(_ phase: KickPhase) -> DetectedKickPhase { input.phases.phase(phase) }

        /// Step 12D: the kicking ankle merged with the plant ankle right after contact.
        var kickingLegLostAtContact: Bool { input.phases.evidence?.kickingAnkleMergedAfterContact == true }

        /// Step 12E: is the kicking ANKLE usable at the contact sample itself? With the
        /// straight-line rule: yes when the ankles are apart at contact (a merge that starts
        /// after contact doesn't spoil the contact frame). With the legacy rule (no
        /// separation signal): not when merged, as before.
        var kickingAnkleUsableAtContact: Bool {
            guard let e = input.phases.evidence, e.kickingAnkleMergedAfterContact == true else { return true }
            guard e.kickingAnkleTrackingRule == "separation2D", let separation = e.ankleSeparationAtContact else { return false }
            return separation > KickPhaseDetector.ankleCollapseDistance
        }

        /// Step 12E: is the kicking KNEE usable at contact? It doesn't depend on the ankle:
        /// the knee must be measured there (not filled in), and must not sit on top of the
        /// plant knee for the time after contact (the same persistence rule as the ankles —
        /// knees side by side AT contact are normal in a side view).
        func kickingKneeUsable(at i: Int) -> Bool {
            guard input.timeline.samples.indices.contains(i),
                  let p = input.timeline.samples[i].joints[sides.kickingKnee], p.isAvailable, p.status == .measured else { return false }
            let separation = signal(.kneeSeparation)
            if separation.compactMap({ $0 }).isEmpty { return !kickingLegLostAtContact }
            return KickPhaseDetector.merge(separation, times, after: times[i] - 1e-6, limit: KickPhaseDetector.ankleCollapseDistance) == nil
        }

        /// Step 12E: the follow-through was timed from the knee because the ankle wasn't
        /// tracked separately after contact.
        var followThroughFromKnee: Bool { input.phases.evidence?.followThroughBasis == "kickingKnee" }

        /// The sample at `time` (phase times are sample times, so this is exact).
        func index(at time: Double?) -> Int? {
            guard let time, !times.isEmpty else { return nil }
            var best = 0
            for i in times.indices where abs(times[i] - time) < abs(times[best] - time) { best = i }
            let rate: Double = framesPerSecond ?? 30
            let tolerance: Double = 0.5 / rate + 1e-9
            let distance: Double = abs(times[best] - time)
            return distance <= tolerance ? best : nil
        }

        func indices(from start: Double, to end: Double) -> [Int] {
            times.indices.filter { times[$0] >= start - 1e-9 && times[$0] <= end + 1e-9 }
        }

        func signal(_ key: PoseSignalKey) -> [Double?] { input.signals.values(key) }

        func position(_ joint: PoseJoint, _ i: Int) -> NormalizedPoint? {
            guard input.timeline.samples.indices.contains(i), let p = input.timeline.samples[i].point(joint) else { return nil }
            return NormalizedPoint(x: p.x * aspect, y: p.y)
        }

        func neighborhood(_ i: Int) -> [Int] {
            [i - 1, i, i + 1].filter { times.indices.contains($0) }
        }

        var hips: [PoseJoint] { [.leftHip, .rightHip] }
        var torso: [PoseJoint] { [.leftShoulder, .rightShoulder, .leftHip, .rightHip] }
        var kickingLeg: [PoseJoint] { [sides.kickingHip, sides.kickingKnee, sides.kickingAnkle] }
        var plantLeg: [PoseJoint] { [sides.plantHip, sides.plantKnee, sides.plantAnkle] }
        var kickingHipChain: [PoseJoint] { [sides.kickingShoulder, sides.kickingHip, sides.kickingKnee] }

        // MARK: Measure

        func measure(_ key: KickMetricKey) -> KickMetricMeasurement {
            let definition = key.definition
            guard input.profile.supportedMetrics.contains(key) else {
                return .unavailable(key, reason: .unsupportedKickType)
            }
            // Step 12E: only what the camera perspective can show.
            guard case .supported = PerspectiveMetricSupport.support(key, context: input.context) else {
                return .unavailable(key, reason: .cameraAngleUnsupported)
            }
            // Step 12G: from behind or in front, when pose only found a strike WINDOW,
            // nothing that depends on the moment of contact is reported.
            if definition.dependsOnContact, input.context.effectivePerspective.isDepthView,
               phase(.contact).status == .ambiguous, !input.phases.isUserAssisted {
                return .unavailable(key, reason: .contactTimingUncertain)
            }
            // Required phases: unavailable → unavailable; otherwise multiply the factors.
            var phaseFactor = 1.0
            var allDetected = true
            for required in definition.requiredPhases {
                let detected = phase(required)
                guard let factor = MetricConfidenceModel.phaseFactor(detected.status) else {
                    return .unavailable(key, reason: .phaseUnavailable, missingPhase: required)
                }
                phaseFactor *= factor
                if detected.status != .detected { allDetected = false }
            }
            if definition.unit == .bodyLengths || definition.unit == .bodyLengthsPerSecond, scale == nil {
                return .unavailable(key, reason: .missingJoints)
            }
            let result = compute(key)
            switch result {
            case .failed(let reason):
                return .unavailable(key, reason: reason)
            case .value(let raw):
                return finalize(definition, raw, phaseFactor: phaseFactor, allPhasesDetected: allDetected)
            }
        }

        enum Computation {
            case value(Raw)
            case failed(MetricUnavailableReason)
        }

        /// A computed value before confidence is applied.
        struct Raw {
            var value: Double
            /// Samples whose joints support the value.
            var jointIndices: [Int]
            var joints: [PoseJoint]
            var samplesUsed: Int
            var samplesWanted: Int
            var sampleTime: Double?
            var window: (start: Double, end: Double)?
        }

        func finalize(_ definition: KickMetricDefinition, _ raw: Raw, phaseFactor: Double, allPhasesDetected: Bool) -> KickMetricMeasurement {
            let stats = MetricConfidenceModel.jointStats(input.timeline, indices: raw.jointIndices, joints: raw.joints)
            let legAtContact: Set<KickMetricKey> = [.kickingKneeAngleAtContact, .kickingHipAngleAtContact, .peakFootSpeed, .footSpeedAtContact]
            let inputs = MetricConfidenceInputs(
                jointQuality: stats.quality,
                jointCoverage: stats.coverage,
                interpolatedFraction: stats.interpolatedFraction,
                phaseFactor: phaseFactor,
                sampleFactor: min(1, Double(raw.samplesUsed) / Double(max(raw.samplesWanted, 1))),
                frameRateFactor: legAtContact.contains(definition.key) ? MetricConfidenceModel.frameRateFactor(framesPerSecond: framesPerSecond) : 1,
                // Step 12A: the camera-angle factor describes 2D side-plane geometry. Timings
                // between detected events don't depend on where the camera stood; their
                // uncertainty is already in the phase factor.
                cameraFactor: perspectiveFactor(definition.key),
                samplesUsed: raw.samplesUsed
            )
            guard raw.value.isFinite else { return .unavailable(definition.key, reason: .notComputable, inputs: inputs) }
            guard stats.coverage >= MetricConfidenceModel.minimumJointCoverage else {
                return .unavailable(definition.key, reason: .missingJoints, inputs: inputs)
            }
            let confidence = inputs.combined
            guard confidence >= input.profile.minimumMetricConfidence else {
                return .unavailable(definition.key, reason: .lowConfidence, inputs: inputs)
            }
            let measured = allPhasesDetected && !definition.dependsOnContact && stats.interpolatedFraction <= 0.25
            return KickMetricMeasurement(
                key: definition.key,
                definitionVersion: definition.definitionVersion,
                value: MetricConfidenceModel.round3(raw.value),
                unit: definition.unit,
                status: measured ? .measured : .estimated,
                confidence: confidence,
                confidenceLevel: ConfidenceLevel(confidence),
                phase: definition.phase,
                sampleTime: raw.sampleTime,
                windowStart: raw.window?.start,
                windowEnd: raw.window?.end,
                unavailableReason: nil,
                missingPhase: nil,
                confidenceInputs: inputs
            )
        }

        /// Step 12E: the confidence factor for the camera perspective (1 for metrics the
        /// perspective sees directly, e.g. timings and, from behind, frontal-plane values).
        func perspectiveFactor(_ key: KickMetricKey) -> Double {
            if case .supported(let factor) = PerspectiveMetricSupport.support(key, context: input.context) { return factor }
            return 0
        }

        // MARK: Formulas

        func compute(_ key: KickMetricKey) -> Computation {
            let approach = phase(.approach)
            let plantTime = phase(.plant).representativeTime
            let contactTime = phase(.contact).representativeTime
            let followEnd = phase(.followThrough).endTime

            switch key {
            case .approachSpeed, .approachSpeedVariation:
                guard let start = approach.startTime, let end = approach.endTime else { return .failed(.phaseUnavailable) }
                let window = indices(from: start, to: end)
                let speeds = window.compactMap { signal(.bodyForwardVelocity)[$0] }
                guard speeds.count >= 3 else { return .failed(.insufficientSamples) }
                let mean = speeds.reduce(0, +) / Double(speeds.count)
                if key == .approachSpeed {
                    return .value(Raw(value: mean, jointIndices: window, joints: hips, samplesUsed: speeds.count,
                                        samplesWanted: 6, sampleTime: nil, window: (start, end)))
                }
                guard speeds.count >= 6 else { return .failed(.insufficientSamples) }
                guard mean > 0.3 else { return .failed(.notComputable) }
                let variance = speeds.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Double(speeds.count)
                return .value(Raw(value: 100 * variance.squareRoot() / mean, jointIndices: window, joints: hips,
                                    samplesUsed: speeds.count, samplesWanted: 10, sampleTime: nil, window: (start, end)))

            case .approachLateSpeedChange:
                guard let start = approach.startTime, let plant = plantTime else { return .failed(.phaseUnavailable) }
                let split = plant - 0.2
                guard split > start else { return .failed(.insufficientSamples) }
                let early = indices(from: start, to: split - 1e-6)
                let late = indices(from: split, to: plant)
                let earlySpeeds = early.compactMap { signal(.bodyForwardVelocity)[$0] }
                let lateSpeeds = late.compactMap { signal(.bodyForwardVelocity)[$0] }
                guard earlySpeeds.count >= 3, lateSpeeds.count >= 3 else { return .failed(.insufficientSamples) }
                let earlyMean = earlySpeeds.reduce(0, +) / Double(earlySpeeds.count)
                let lateMean = lateSpeeds.reduce(0, +) / Double(lateSpeeds.count)
                guard earlyMean > 0.3 else { return .failed(.notComputable) }
                return .value(Raw(value: 100 * (lateMean - earlyMean) / earlyMean, jointIndices: early + late, joints: hips,
                                    samplesUsed: earlySpeeds.count + lateSpeeds.count, samplesWanted: 10,
                                    sampleTime: nil, window: (start, plant)))

            case .plantToContactTime:
                guard let plant = plantTime, let contact = contactTime,
                      let pi = index(at: plant), let ci = index(at: contact) else { return .failed(.phaseUnavailable) }
                return .value(Raw(value: contact - plant, jointIndices: [pi, ci], joints: [sides.plantAnkle, sides.kickingAnkle],
                                    samplesUsed: 1, samplesWanted: 1, sampleTime: plant, window: (plant, contact)))

            case .plantFootDrift:
                guard let plant = plantTime, let contact = contactTime, let ci = index(at: contact), let scale else {
                    return .failed(.phaseUnavailable)
                }
                guard let reference = position(sides.plantAnkle, ci) else { return .failed(.missingJoints) }
                let start = max(plant, contact - 0.1)
                let window = indices(from: start, to: contact + 0.1)
                let points = window.compactMap { position(sides.plantAnkle, $0) }
                guard points.count >= 3 else { return .failed(.insufficientSamples) }
                let drift = points.map { hypot($0.x - reference.x, $0.y - reference.y) }.max() ?? 0
                return .value(Raw(value: drift / scale, jointIndices: window, joints: [sides.plantAnkle],
                                    samplesUsed: points.count, samplesWanted: 7, sampleTime: contact, window: (start, contact + 0.1)))

            case .plantKneeAngleAtContact:
                return instant(.plantKneeAngle, at: contactTime, joints: plantLeg)
            case .kickingKneeAngleAtContact:
                // Hip–knee–ANKLE: needs the kicking ankle at the contact frame.
                if !kickingAnkleUsableAtContact { return .failed(.kickingLegNotTracked) }
                return instant(.kickingKneeAngle, at: contactTime, joints: kickingLeg)
            case .kickingHipAngleAtContact:
                // Shoulder–hip–KNEE: no ankle involved, so only the knee must be usable.
                if let i = index(at: contactTime), !kickingKneeUsable(at: i) { return .failed(.kickingLegNotTracked) }
                return instant(.kickingHipAngle, at: contactTime, joints: kickingHipChain)
            case .torsoLeanAtContact:
                return instant(.torsoLean, at: contactTime, joints: torso)
            case .footSpeedAtContact:
                // Timed from the plant landing / foot passing (after the measured peak), the
                // ankle at that instant is not the striking foot's speed.
                if input.phases.evidence?.contactTimedByConstraints == true { return .failed(.contactNotMeasured) }
                if !kickingAnkleUsableAtContact { return .failed(.kickingLegNotTracked) }
                return instant(.kickingAnkleSpeed, at: contactTime, joints: [sides.kickingAnkle], neighbors: true)
            case .bodyForwardSpeedAtContact:
                return instant(.bodyForwardVelocity, at: contactTime, joints: hips, neighbors: true)

            case .backswingDepth:
                guard let plant = plantTime, let contact = contactTime else { return .failed(.phaseUnavailable) }
                let window = indices(from: plant - 0.3, to: contact)
                let offsets = window.compactMap { signal(.kickingAnkleForwardOffset)[$0] }
                guard offsets.count >= 3, let deepest = offsets.min() else { return .failed(.insufficientSamples) }
                return .value(Raw(value: max(0, -deepest), jointIndices: window, joints: [sides.kickingHip, sides.kickingAnkle],
                                    samplesUsed: offsets.count, samplesWanted: 8, sampleTime: nil, window: (plant - 0.3, contact)))

            case .peakFootSpeed:
                guard let contact = contactTime else { return .failed(.phaseUnavailable) }
                let window = indices(from: contact - 0.3, to: contact + 0.1)
                let speeds = window.compactMap { i in signal(.kickingAnkleSpeed)[i].map { (i, $0) } }
                guard speeds.count >= 3, let peak = speeds.max(by: { $0.1 < $1.1 }) else { return .failed(.insufficientSamples) }
                return .value(Raw(value: peak.1, jointIndices: neighborhood(peak.0), joints: [sides.kickingAnkle],
                                    samplesUsed: speeds.count, samplesWanted: 8, sampleTime: times[peak.0],
                                    window: (contact - 0.3, contact + 0.1)))

            case .torsoLeanRange:
                guard let plant = plantTime, let end = followEnd else { return .failed(.phaseUnavailable) }
                let window = indices(from: plant, to: end)
                let leans = window.compactMap { signal(.torsoLean)[$0] }
                guard leans.count >= 3, let low = leans.min(), let high = leans.max() else { return .failed(.insufficientSamples) }
                return .value(Raw(value: high - low, jointIndices: window, joints: torso, samplesUsed: leans.count,
                                    samplesWanted: 8, sampleTime: nil, window: (plant, end)))

            case .followThroughDuration:
                guard let contact = contactTime, let end = followEnd else { return .failed(.phaseUnavailable) }
                let window = indices(from: contact, to: end)
                guard window.count >= 2 else { return .failed(.insufficientSamples) }
                return .value(Raw(value: end - contact, jointIndices: window,
                                    joints: [followThroughFromKnee ? sides.kickingKnee : sides.kickingAnkle],
                                    samplesUsed: window.count, samplesWanted: 2, sampleTime: contact, window: (contact, end)))

            case .followThroughFootHeight:
                guard let contact = contactTime, let end = followEnd, let scale else { return .failed(.phaseUnavailable) }
                // The foot's height needs the kicking ankle; never taken from a merged label.
                if followThroughFromKnee || kickingLegLostAtContact { return .failed(.kickingLegNotTracked) }
                let window = indices(from: contact, to: end)
                let heights = window.compactMap { i -> Double? in
                    guard let hip = position(sides.kickingHip, i), let ankle = position(sides.kickingAnkle, i) else { return nil }
                    return (hip.y - ankle.y) / scale
                }
                guard heights.count >= 2, let highest = heights.max() else { return .failed(.insufficientSamples) }
                return .value(Raw(value: highest, jointIndices: window, joints: [sides.kickingHip, sides.kickingAnkle],
                                    samplesUsed: heights.count, samplesWanted: 4, sampleTime: nil, window: (contact, end)))

            case .lateralTrunkLeanAtContact:
                return instant(.lateralTrunkLean, at: contactTime, joints: torso)
            case .plantFootWidth:
                return instant(.plantAnkleLateralOffset, at: contactTime, joints: [sides.plantAnkle, .leftHip, .rightHip])

            case .plantBallLateralOffset:
                // Build 18: the plant ankle beside the football, sideways in the image plane of
                // a rear/front view (ball and plant foot are at nearly the same depth).
                guard let ball = input.context.ballRest else { return .failed(.ballNotTracked) }
                guard let contact = contactTime, let ci = index(at: contact) else { return .failed(.phaseUnavailable) }
                let window = neighborhood(ci)
                let bx = ball.cx * aspect
                let offsets = window.compactMap { i -> Double? in
                    guard let a = position(sides.plantAnkle, i), let u = torsoLength(i) else { return nil }
                    return (a.x - bx) * plantSide / u
                }
                guard offsets.count >= 2 else { return .failed(.missingJoints) }
                return .value(Raw(value: Self.median(offsets), jointIndices: window, joints: [sides.plantAnkle] + torso,
                                    samplesUsed: offsets.count, samplesWanted: 3, sampleTime: times[ci], window: nil))
            case .plantLateralMovement:
                guard let contact = contactTime, let ci = index(at: contact) else { return .failed(.phaseUnavailable) }
                guard let reference = position(sides.plantAnkle, ci), let u = torsoLength(ci) else { return .failed(.missingJoints) }
                // From the plant landing (never before it: a foot still landing isn't
                // "moving on the ground"); from contact when the landing wasn't found.
                let start = max(plantTime ?? contact, contact - 0.1)
                let window = indices(from: start, to: contact + 0.1)
                let xs = window.compactMap { position(sides.plantAnkle, $0)?.x }
                guard xs.count >= 4 else { return .failed(.insufficientSamples) }
                let movement = xs.map { abs($0 - reference.x) }.max() ?? 0
                return .value(Raw(value: movement / u, jointIndices: window, joints: [sides.plantAnkle],
                                    samplesUsed: xs.count, samplesWanted: 7, sampleTime: contact, window: (start, contact + 0.1)))

            case .followThroughBodyTravel:
                guard let contact = contactTime, let end = followEnd, let scale,
                      let ci = index(at: contact), let ei = index(at: end) else { return .failed(.phaseUnavailable) }
                // Travel in the frame includes the camera's own movement.
                if input.phases.evidence?.cameraMotionSuspected == true { return .failed(.cameraMoving) }
                guard let a = signal(.bodyCenterX)[ci], let b = signal(.bodyCenterX)[ei] else { return .failed(.missingJoints) }
                return .value(Raw(value: (b - a) * forward / scale, jointIndices: [ci, ei], joints: hips,
                                    samplesUsed: 2, samplesWanted: 2, sampleTime: nil, window: (contact, end)))
            }
        }

        /// Build 18: which image side the plant leg is on (+1 right, −1 left), from the
        /// median hip offset (labels already checked against the facing direction).
        var plantSide: Double {
            let offsets = times.indices.compactMap { i -> Double? in
                guard let p = position(sides.plantHip, i), let k = position(sides.kickingHip, i) else { return nil }
                return p.x - k.x
            }.sorted()
            return (offsets.isEmpty ? 0 : offsets[offsets.count / 2]) >= 0 ? 1 : -1
        }

        /// Build 18: the torso length at one sample (shoulder midpoint to hip midpoint) —
        /// the local scale in a depth view, where apparent size changes along the run-up.
        func torsoLength(_ i: Int) -> Double? {
            guard let ls = position(.leftShoulder, i), let rs = position(.rightShoulder, i),
                  let lh = position(.leftHip, i), let rh = position(.rightHip, i) else { return nil }
            let d = hypot((ls.x + rs.x - lh.x - rh.x) / 2, (ls.y + rs.y - lh.y - rh.y) / 2)
            return d > 1e-6 ? d : nil
        }

        static func median(_ v: [Double]) -> Double {
            let s = v.sorted()
            return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
        }

        /// A signal read at one instant (the estimated contact).
        func instant(_ key: PoseSignalKey, at time: Double?, joints: [PoseJoint], neighbors: Bool = false) -> Computation {
            guard let time, let i = index(at: time) else { return .failed(.phaseUnavailable) }
            guard let value = signal(key)[i] else { return .failed(.missingJoints) }
            return .value(Raw(value: value, jointIndices: neighbors ? neighborhood(i) : [i], joints: joints,
                                samplesUsed: 1, samplesWanted: 1, sampleTime: times[i], window: nil))
        }
    }
}
