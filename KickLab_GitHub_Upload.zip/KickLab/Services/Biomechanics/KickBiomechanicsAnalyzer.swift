import Foundation

/// Everything Step 8 derives for one kick.
struct KickBiomechanicsResult: Equatable, Sendable {
    var context: BiomechanicsContext
    var profile: BiomechanicsProfile
    /// Every metric in catalog order, available or not.
    var measurements: [KickMetricMeasurement]
    /// The scored categories in display order, then `.overall`.
    var categories: [CategoryScoreBreakdown]
    /// All coaching findings, ranked, issued or not.
    var findings: [CoachingFinding]
    /// Drafts for `AnalysisService`, in a valid insertion order.
    var metricDrafts: [MetricDraft]
    var scoreDrafts: [CategoryScoreDraft]
    var observationDrafts: [CoachingObservationDraft]

    var overall: CategoryScoreBreakdown? { categories.first { $0.category == .overall } }
    var overallScore: Double? { overall?.score }
    var overallConfidence: Double? { overall?.confidence }

    var availableMetricCount: Int { measurements.filter(\.isAvailable).count }
    var availableCategoryCount: Int { categories.filter { $0.category != .overall && $0.score != nil }.count }

    /// Enough was measured to stand as a completed analysis: at least one scored category.
    var isSufficient: Bool { availableCategoryCount > 0 }

    func measurement(_ key: KickMetricKey) -> KickMetricMeasurement? { measurements.first { $0.key == key } }
    func category(_ category: AnalysisCategory) -> CategoryScoreBreakdown? { categories.first { $0.category == category } }
}

/// The versioned file artifact of Step 8: every measurement with its confidence
/// inputs, every score with its components, and every coaching finding (issued or not),
/// so any result can be inspected and reproduced.
struct BiomechanicsArtifact: VersionedArtifact, Equatable {
    static let kind = "kicklab.biomechanics"
    static let currentFormatVersion = 1

    var kind: String = BiomechanicsArtifact.kind
    var formatVersion: Int = BiomechanicsArtifact.currentFormatVersion
    var videoID: UUID
    /// Version of the metric formulas, scoring and coaching rules.
    var rulesVersion: Int
    var context: BiomechanicsContext
    var profile: BiomechanicsProfile
    var measurements: [KickMetricMeasurement]
    var categories: [CategoryScoreBreakdown]
    var findings: [CoachingFinding]

    init(videoID: UUID, result: KickBiomechanicsResult) {
        self.videoID = videoID
        rulesVersion = KickBiomechanicsAnalyzer.rulesVersion
        context = result.context
        profile = result.profile
        measurements = result.measurements
        categories = result.categories
        findings = result.findings
    }
}

/// Pure Step 8 interpretation: metrics → category scores → coaching observations.
/// Deterministic: identical input (including `idSeed`) gives identical output.
enum KickBiomechanicsAnalyzer {
    static let rulesVersion = 1

    static func analyze(
        timeline: KickerPoseTimeline?,
        signals: PoseSignalSet,
        phases: KickPhaseDetectionResult,
        context: BiomechanicsContext,
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles(),
        idSeed: UUID
    ) -> KickBiomechanicsResult {
        let profile = profiles.profile(for: context)
        let measurements: [KickMetricMeasurement]
        if let timeline {
            measurements = KickMetricExtractor.extract(KickMetricInput(
                timeline: timeline, signals: signals, phases: phases, context: context, profile: profile
            ))
        } else {
            measurements = KickMetricExtractor.allUnavailable(reason: .noKicker)
        }
        let categories = KickScorer.score(measurements, profile: profile)
        let findings = CoachingEngine.findings(for: measurements, profile: profile)
        return KickBiomechanicsResult(
            context: context,
            profile: profile,
            measurements: measurements,
            categories: categories,
            findings: findings,
            metricDrafts: measurements.map { $0.draft(sourceAngle: context.cameraAngle) },
            scoreDrafts: categories.map(\.draft),
            observationDrafts: CoachingEngine.drafts(for: findings, seed: idSeed)
        )
    }
}
