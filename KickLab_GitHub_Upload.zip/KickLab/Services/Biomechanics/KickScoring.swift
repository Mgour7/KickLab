import Foundation

/// One metric's contribution to a category score.
struct ScoreComponent: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var value: Double
    var band: ScoreBand
    /// 0...100 from the band.
    var componentScore: Double
    var weight: Double
    var confidence: Double
    var status: MeasurementStatus
}

/// A scored metric left out of a category score, and why.
struct ExcludedScoreComponent: Codable, Equatable, Sendable {
    enum Reason: String, Codable, Sendable {
        /// The metric was unavailable (e.g. a hidden joint). Never counted against the athlete.
        case unavailable
        /// Available but below the scoring confidence threshold.
        case lowConfidence
    }

    var key: KickMetricKey
    var weight: Double
    var reason: Reason
}

/// The full explanation of one category score.
struct CategoryScoreBreakdown: Codable, Equatable, Sendable {
    var category: AnalysisCategory
    /// 0...100, nil when unavailable.
    var score: Double?
    var confidence: Double?
    var status: MeasurementStatus
    var components: [ScoreComponent]
    var excluded: [ExcludedScoreComponent]
    /// Available scoring weight ÷ total scoring weight for the category.
    var availableWeightFraction: Double
    var summary: String

    var draft: CategoryScoreDraft {
        CategoryScoreDraft(category: category, score: score, confidence: confidence, measurementStatus: status, summary: summary)
    }
}

/// Explicit, deterministic category scoring (no learned weights).
///
/// For each category:
/// 1. Each available metric with a scoring rule and weight > 0, at or above the scoring
///    confidence, is scored 0–100 by its band.
/// 2. Category score = Σ(weight × confidence × componentScore) ÷ Σ(weight × confidence),
///    rounded to 0.1. Unavailable metrics are excluded, never scored as 0, so a hidden
///    joint lowers confidence, not the score.
/// 3. Category confidence = Σ(weight × confidence) ÷ Σ(weight of every scored metric in
///    the category for this kick type), rounded to 3 decimals. It falls as evidence is missing.
/// 4. The category is unavailable when less than `minimumCategoryWeightFraction` of its
///    weight is available or its confidence is below `minimumCategoryConfidence`.
/// 5. Status is `.estimated` if any component is estimated, else `.measured`.
///
/// Overall (`.overall`): the unweighted mean of the available category scores, when at
/// least `minimumCategoriesForOverall` are available. Confidence = mean category
/// confidence × (available ÷ expected categories for the kick type).
enum KickScorer {
    static func score(_ measurements: [KickMetricMeasurement], profile: BiomechanicsProfile) -> [CategoryScoreBreakdown] {
        let byKey = Dictionary(uniqueKeysWithValues: measurements.map { ($0.key, $0) })
        var breakdowns = KickMetricCatalog.scoredCategories.map { category in
            scoreCategory(category, byKey: byKey, profile: profile)
        }
        breakdowns.append(overall(breakdowns, profile: profile))
        return breakdowns
    }

    static func scoreCategory(
        _ category: AnalysisCategory,
        byKey: [KickMetricKey: KickMetricMeasurement],
        profile: BiomechanicsProfile
    ) -> CategoryScoreBreakdown {
        let keys = KickMetricCatalog.keys(in: category).filter {
            profile.supportedMetrics.contains($0) && (profile.scoring[$0]?.weight ?? 0) > 0
        }
        let totalWeight = keys.compactMap { profile.scoring[$0]?.weight }.reduce(0, +)
        var components: [ScoreComponent] = []
        var excluded: [ExcludedScoreComponent] = []
        for key in keys {
            guard let rule = profile.scoring[key] else { continue }
            guard let m = byKey[key], m.isAvailable, let value = m.value, let confidence = m.confidence else {
                excluded.append(ExcludedScoreComponent(key: key, weight: rule.weight, reason: .unavailable))
                continue
            }
            guard confidence >= profile.minimumScoringConfidence else {
                excluded.append(ExcludedScoreComponent(key: key, weight: rule.weight, reason: .lowConfidence))
                continue
            }
            components.append(ScoreComponent(
                key: key, value: value, band: rule.band, componentScore: round1(rule.band.score(value)),
                weight: rule.weight, confidence: confidence, status: m.status
            ))
        }

        let availableWeight = components.map(\.weight).reduce(0, +)
        let fraction = totalWeight > 0 ? MetricConfidenceModel.round3(availableWeight / totalWeight) : 0
        let evidence = components.map { $0.weight * $0.confidence }.reduce(0, +)
        let confidence = totalWeight > 0 ? MetricConfidenceModel.round3(evidence / totalWeight) : 0
        let used = "\(components.count) of \(keys.count) measurements"

        guard totalWeight > 0, fraction >= profile.minimumCategoryWeightFraction,
              confidence >= profile.minimumCategoryConfidence, evidence > 0 else {
            let summary = totalWeight == 0
                ? "Not scored for this kick type."
                : "Not enough reliable measurements to score (\(used) available)."
            return CategoryScoreBreakdown(category: category, score: nil, confidence: nil, status: .unavailable,
                                          components: components, excluded: excluded,
                                          availableWeightFraction: fraction, summary: summary)
        }
        let score = round1(components.map { $0.weight * $0.confidence * $0.componentScore }.reduce(0, +) / evidence)
        let status: MeasurementStatus = components.contains { $0.status == .estimated } ? .estimated : .measured
        return CategoryScoreBreakdown(category: category, score: score, confidence: confidence, status: status,
                                      components: components, excluded: excluded,
                                      availableWeightFraction: fraction, summary: "Based on \(used).")
    }

    static func overall(_ categories: [CategoryScoreBreakdown], profile: BiomechanicsProfile) -> CategoryScoreBreakdown {
        let expected = profile.expectedCategories
        let available = categories.filter { $0.score != nil && expected.contains($0.category) }
        guard !expected.isEmpty, available.count >= profile.minimumCategoriesForOverall else {
            return CategoryScoreBreakdown(
                category: .overall, score: nil, confidence: nil, status: .unavailable, components: [], excluded: [],
                availableWeightFraction: expected.isEmpty ? 0 : Double(available.count) / Double(expected.count),
                summary: "Needs at least \(profile.minimumCategoriesForOverall) scored categories (\(available.count) available)."
            )
        }
        let scores = available.compactMap(\.score)
        let confidences = available.compactMap(\.confidence)
        let coverage = Double(available.count) / Double(expected.count)
        let confidence = MetricConfidenceModel.round3(confidences.reduce(0, +) / Double(confidences.count) * coverage)
        let status: MeasurementStatus = available.contains { $0.status == .estimated } ? .estimated : .measured
        return CategoryScoreBreakdown(
            category: .overall,
            score: round1(scores.reduce(0, +) / Double(scores.count)),
            confidence: confidence,
            status: status,
            components: [],
            excluded: [],
            availableWeightFraction: MetricConfidenceModel.round3(coverage),
            summary: "Average of \(available.count) of \(expected.count) category scores."
        )
    }

    static func round1(_ x: Double) -> Double { (x * 10).rounded() / 10 }
}
