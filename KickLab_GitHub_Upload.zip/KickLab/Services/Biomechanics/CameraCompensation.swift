import Foundation

/// Build 19 (engine 3.1.0): camera-motion compensation from MEASURED background motion.
///
/// Source: the football layer's `CameraMotionEstimator`, which matches textured background
/// blocks (athlete and the ball's path excluded) between upright thumbnails and records the
/// camera's apparent translation relative to the first frame of the precision window (the
/// strike ± a few tenths of a second), in displayed normalized coordinates. It is stored
/// in every analysis since build 15 (`FootballRawEvidence.cameraShift…`).
///
/// What this can and can't correct:
/// - TRANSLATION (panning, a hand-held drift): a world-fixed point appears shifted by the
///   measured amount, so subtracting it gives camera-steady coordinates.
/// - ZOOM and PERSPECTIVE are not modelled. When the resting football's box changes size by
///   more than `zoomTolerance` the camera is treated as zooming/moving in depth and nothing
///   is compensated.
/// - Only times inside the measured window, with measured frames no more than
///   `maximumGapSeconds` apart, are compensated; outside it a measurement that needs
///   compensation is reported unavailable (`cameraMoving`) rather than corrected by guess.
struct CameraShiftSeries: Codable, Equatable, Sendable {
    var times: [Double]
    var dx: [Double]
    var dy: [Double]
    /// The estimator's verdict: shift above 0.25 ball sizes.
    var cameraMoved: Bool
    /// The resting ball's apparent size changed: zoom / depth motion, not compensable.
    var zoomSuspected: Bool

    static let zoomTolerance = 0.15
    static let maximumGapSeconds = 0.07

    enum State: String, Equatable, Sendable {
        /// Measured, and the camera didn't move: positions are used as they are.
        case steady
        /// The times needed fall outside the measured window, and no movement was measured:
        /// nothing is known either way (earlier behaviour applies).
        case unmeasured
        /// Moved, and every time needed is inside the measured window: compensated.
        case compensated
        /// Moved, but not measurable for the times needed (or zoom): not compensable.
        case notCompensable
    }

    /// From a stored football track (nil before build 15 or without measured frames).
    static func from(_ track: FootballTrack?) -> CameraShiftSeries? {
        guard let track, let raw = track.raw, raw.cameraShiftTimes.count >= 2,
              raw.cameraShiftTimes.count == raw.cameraShiftX.count, raw.cameraShiftX.count == raw.cameraShiftY.count else { return nil }
        let order = raw.cameraShiftTimes.indices.sorted { raw.cameraShiftTimes[$0] < raw.cameraShiftTimes[$1] }
        let sizes = track.observations.filter { $0.state == .atRest && $0.source == .detected }.compactMap { $0.box?.h }.filter { $0 > 0 }
        var zoom = false
        if sizes.count >= 3 {
            let m = FootballTrackAnalyzer.median(sizes)
            zoom = m > 0 && (sizes.max()! - sizes.min()!) / m > zoomTolerance
        }
        return CameraShiftSeries(times: order.map { raw.cameraShiftTimes[$0] }, dx: order.map { raw.cameraShiftX[$0] },
                                 dy: order.map { raw.cameraShiftY[$0] }, cameraMoved: raw.camera?.cameraMoved ?? false, zoomSuspected: zoom)
    }

    /// The camera's apparent shift at `t` (linear between neighbouring measured frames no
    /// more than `maximumGapSeconds` apart); nil outside the measured window.
    func shift(at t: Double) -> (dx: Double, dy: Double)? {
        guard let first = times.first, let last = times.last, t >= first - 1e-6, t <= last + 1e-6 else { return nil }
        if let i = times.firstIndex(where: { abs($0 - t) < 1e-6 }) { return (dx[i], dy[i]) }
        guard let j = times.firstIndex(where: { $0 > t }), j > 0 else { return nil }
        let a = times[j - 1], b = times[j]
        guard b - a <= Self.maximumGapSeconds + 1e-9 else { return nil }
        let f = (t - a) / (b - a)
        return (dx[j - 1] + f * (dx[j] - dx[j - 1]), dy[j - 1] + f * (dy[j] - dy[j - 1]))
    }

    func state(for sampleTimes: [Double]) -> State {
        let covered = !sampleTimes.isEmpty && sampleTimes.allSatisfy { shift(at: $0) != nil }
        guard covered else { return cameraMoved ? .notCompensable : .unmeasured }
        guard cameraMoved else { return .steady }
        return zoomSuspected ? .notCompensable : .compensated
    }
}
