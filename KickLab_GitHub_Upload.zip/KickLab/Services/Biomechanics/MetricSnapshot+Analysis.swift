import Foundation
import SwiftData

extension MetricSnapshot {
    /// A snapshot of a stored, completed analysis for comparisons. Unknown metric keys
    /// (from other engines) and unavailable metrics are skipped. Nil for analyses that
    /// are not completed or have no kick.
    init?(analysis: BiomechanicsAnalysis) {
        guard analysis.processingStatus == .completed, let kick = analysis.kick else { return nil }
        var values: [KickMetricKey: Value] = [:]
        for metric in analysis.metrics ?? [] {
            guard let key = KickMetricKey(rawValue: metric.metricKey),
                  metric.measurementStatus != .unavailable,
                  let value = metric.value else { continue }
            values[key] = Value(value: value, confidence: metric.confidence, status: metric.measurementStatus,
                                definitionVersion: metric.metricDefinitionVersion)
        }
        self.init(analysisID: analysis.id, kickID: kick.id, kickType: kick.kickType,
                  recordedAt: analysis.completedAt ?? analysis.createdAt, values: values)
    }

    /// Snapshots of the current analyses of `kicks`, oldest first, for baselines and trends.
    static func history(of kicks: [Kick]) -> [MetricSnapshot] {
        kicks.compactMap { kick in
            (kick.analyses ?? []).first(where: \.isCurrent).flatMap { MetricSnapshot(analysis: $0) }
        }
        .sorted { $0.recordedAt < $1.recordedAt }
    }
}
