import Foundation

/// A piecewise-linear scoring band.
///
/// - Inside `idealLow...idealHigh` the score is 100.
/// - Below `idealLow` it falls linearly to 0 at `zeroLow` (no penalty if `zeroLow` is nil).
/// - Above `idealHigh` it falls linearly to 0 at `zeroHigh` (no penalty if `zeroHigh` is nil).
struct ScoreBand: Codable, Equatable, Sendable {
    var zeroLow: Double?
    var idealLow: Double
    var idealHigh: Double
    var zeroHigh: Double?

    init(zeroLow: Double?, idealLow: Double, idealHigh: Double, zeroHigh: Double?) {
        self.zeroLow = zeroLow
        self.idealLow = idealLow
        self.idealHigh = idealHigh
        self.zeroHigh = zeroHigh
    }

    /// 0...100.
    func score(_ value: Double) -> Double {
        if value < idealLow {
            guard let zeroLow, zeroLow < idealLow else { return 100 }
            return Self.clamp100(100 * (value - zeroLow) / (idealLow - zeroLow))
        }
        if value > idealHigh {
            guard let zeroHigh, zeroHigh > idealHigh else { return 100 }
            return Self.clamp100(100 * (zeroHigh - value) / (zeroHigh - idealHigh))
        }
        return 100
    }

    /// Distance from the ideal band (0 inside it). Used for "toward ideal" comparisons.
    func distanceFromIdeal(_ value: Double) -> Double {
        if value < idealLow { return idealLow - value }
        if value > idealHigh { return value - idealHigh }
        return 0
    }

    private static func clamp100(_ x: Double) -> Double { min(100, max(0, x)) }
}

/// How one metric is scored: its band and its weight within its category.
/// Weight 0 = informational (reported, never scored).
struct MetricScoringRule: Codable, Equatable, Sendable {
    var band: ScoreBand
    var weight: Double
}

/// The thresholds a coaching rule fires at, kept in configuration so they can be tuned
/// per kick type, level or camera angle later.
struct CoachingThresholds: Codable, Equatable, Sendable {
    /// Plant-to-contact shorter than this → "plant late".
    var plantLateBelowSeconds: Double = 0.06
    /// Plant-to-contact longer than this → "plant early".
    var plantEarlyAboveSeconds: Double = 0.32
    /// Plant ankle movement above this (body lengths) → "plant unstable".
    var plantUnstableAboveBodyLengths: Double = 0.3
    /// Plant ankle movement at or below this → KEEP "stable plant".
    var plantStableAtMostBodyLengths: Double = 0.1
    /// Torso lean below this (degrees, leaning back) → "leaning back".
    var torsoLeanBackBelowDegrees: Double = -25
    /// Torso lean above this (degrees, leaning forward) → "leaning forward".
    var torsoLeanForwardAboveDegrees: Double = 15
    /// Kicking knee angle at contact below this → "limited extension".
    var kneeExtensionLimitedBelowDegrees: Double = 130
    /// Kicking knee angle at contact at or above this → KEEP "full extension".
    var kneeExtensionFullAtLeastDegrees: Double = 160
    /// Follow-through shorter than this → "follow-through stops early". (Step 7 reports
    /// follow-throughs under 0.1 s as unavailable, so the rule covers 0.1–0.12 s.)
    var followThroughShortBelowSeconds: Double = 0.12
    /// Follow-through ankle height at or above this (body lengths) → KEEP "high finish".
    var followThroughHighAtLeastBodyLengths: Double = 1.0
    /// |late approach speed change| above this percent → "speed changes sharply".
    var approachSpeedChangeAbovePercent: Double = 35
}

/// Every tunable number for one kind of kick. `BiomechanicsProfile.standard(for:)`
/// gives the defaults; `BiomechanicsProfileProviding` lets later steps tune by level,
/// athlete baseline or camera angle without changing the extractor or the rules.
///
/// The bands are initial, provisional values for single-camera 2D pose in body-length
/// units. They are explicit so every score can be explained and re-tuned.
struct BiomechanicsProfile: Codable, Equatable, Sendable {
    var name: String
    var kickType: KickType
    /// Scored metrics and their bands. Metrics absent here are reported but not scored.
    var scoring: [KickMetricKey: MetricScoringRule]
    var coaching: CoachingThresholds
    /// Metrics below this confidence are reported as unavailable.
    var minimumMetricConfidence: Double = 0.25
    /// Metrics below this confidence are not used in scores.
    var minimumScoringConfidence: Double = 0.35
    /// A category needs at least this fraction of its scoring weight available.
    var minimumCategoryWeightFraction: Double = 0.5
    /// Category scores below this confidence are reported as unavailable.
    var minimumCategoryConfidence: Double = 0.35
    /// The overall score needs at least this many available category scores.
    var minimumCategoriesForOverall: Int = 3
    /// IMPROVE observations need at least this metric confidence.
    var minimumImproveConfidence: Double = 0.5
    /// KEEP observations need at least this metric confidence.
    var minimumKeepConfidence: Double = 0.7
    /// At most this many IMPROVE (each with its CUE) and KEEP observations are issued.
    var maximumImproveObservations: Int = 3
    var maximumKeepObservations: Int = 2

    /// Metrics this kick type supports. Others are reported unavailable as unsupported.
    var supportedMetrics: [KickMetricKey]

    /// The categories this kick type is expected to score (for coverage of the overall score).
    var expectedCategories: [AnalysisCategory] {
        KickMetricCatalog.scoredCategories.filter { category in
            supportedMetrics.contains { $0.definition.category == category && (scoring[$0]?.weight ?? 0) > 0 }
        }
    }

    static func standard(for kickType: KickType) -> BiomechanicsProfile {
        switch kickType {
        case .fieldGoal, .pat: placeKick(kickType)
        case .kickoff: kickoff
        case .punt: punt
        case .unknown:
            BiomechanicsProfile(name: "unsupported", kickType: .unknown, scoring: [:],
                                coaching: CoachingThresholds(), supportedMetrics: [])
        }
    }

    static func placeKick(_ kickType: KickType) -> BiomechanicsProfile {
        BiomechanicsProfile(
            name: kickType == .pat ? "pat-v1" : "fieldGoal-v1",
            kickType: kickType,
            scoring: placeKickScoring,
            coaching: CoachingThresholds(),
            supportedMetrics: KickMetricKey.allCases
        )
    }

    static var kickoff: BiomechanicsProfile {
        var scoring = placeKickScoring
        // Longer, faster run-up.
        scoring[.approachSpeed] = MetricScoringRule(band: ScoreBand(zeroLow: 1, idealLow: 4, idealHigh: 10, zeroHigh: 16), weight: 1)
        scoring[.approachLateSpeedChange] = MetricScoringRule(band: ScoreBand(zeroLow: -60, idealLow: -20, idealHigh: 30, zeroHigh: 90), weight: 1)
        scoring[.bodyForwardSpeedAtContact] = MetricScoringRule(band: ScoreBand(zeroLow: -1, idealLow: 1, idealHigh: 6, zeroHigh: 12), weight: 1)
        var coaching = CoachingThresholds()
        coaching.approachSpeedChangeAbovePercent = 45
        return BiomechanicsProfile(name: "kickoff-v1", kickType: .kickoff, scoring: scoring,
                                   coaching: coaching, supportedMetrics: KickMetricKey.allCases)
    }

    /// Punts: no approach, plant or backswing metrics (consistent with Step 7's limited
    /// phase support for punts).
    static var punt: BiomechanicsProfile {
        let supported: [KickMetricKey] = [
            .kickingKneeAngleAtContact, .kickingHipAngleAtContact, .peakFootSpeed, .footSpeedAtContact,
            .torsoLeanAtContact, .bodyForwardSpeedAtContact,
            .followThroughDuration, .followThroughFootHeight, .followThroughBodyTravel,
            .lateralTrunkLeanAtContact,
        ]
        return BiomechanicsProfile(
            name: "punt-limited-v1", kickType: .punt,
            scoring: placeKickScoring.filter { supported.contains($0.key) },
            coaching: CoachingThresholds(), supportedMetrics: supported
        )
    }

    static let placeKickScoring: [KickMetricKey: MetricScoringRule] = [
        .approachSpeed: MetricScoringRule(band: ScoreBand(zeroLow: 0.5, idealLow: 2.5, idealHigh: 7, zeroHigh: 12), weight: 1),
        .approachSpeedVariation: MetricScoringRule(band: ScoreBand(zeroLow: nil, idealLow: 0, idealHigh: 20, zeroHigh: 60), weight: 1),
        .approachLateSpeedChange: MetricScoringRule(band: ScoreBand(zeroLow: -60, idealLow: -15, idealHigh: 25, zeroHigh: 80), weight: 1),
        .plantToContactTime: MetricScoringRule(band: ScoreBand(zeroLow: 0, idealLow: 0.08, idealHigh: 0.25, zeroHigh: 0.45), weight: 1),
        .plantFootDrift: MetricScoringRule(band: ScoreBand(zeroLow: nil, idealLow: 0, idealHigh: 0.1, zeroHigh: 0.6), weight: 1.5),
        .plantKneeAngleAtContact: MetricScoringRule(band: ScoreBand(zeroLow: 95, idealLow: 135, idealHigh: 170, zeroHigh: 200), weight: 1),
        .kickingKneeAngleAtContact: MetricScoringRule(band: ScoreBand(zeroLow: 90, idealLow: 145, idealHigh: 180, zeroHigh: nil), weight: 1.5),
        .kickingHipAngleAtContact: MetricScoringRule(band: ScoreBand(zeroLow: 80, idealLow: 130, idealHigh: 180, zeroHigh: nil), weight: 0.5),
        .backswingDepth: MetricScoringRule(band: ScoreBand(zeroLow: 0, idealLow: 0.8, idealHigh: 2.5, zeroHigh: 4), weight: 1),
        .peakFootSpeed: MetricScoringRule(band: ScoreBand(zeroLow: 4, idealLow: 20, idealHigh: 1_000, zeroHigh: nil), weight: 1),
        .footSpeedAtContact: MetricScoringRule(band: ScoreBand(zeroLow: 4, idealLow: 20, idealHigh: 1_000, zeroHigh: nil), weight: 0),
        .torsoLeanAtContact: MetricScoringRule(band: ScoreBand(zeroLow: -40, idealLow: -15, idealHigh: 5, zeroHigh: 30), weight: 1.5),
        .torsoLeanRange: MetricScoringRule(band: ScoreBand(zeroLow: nil, idealLow: 0, idealHigh: 15, zeroHigh: 45), weight: 1),
        .bodyForwardSpeedAtContact: MetricScoringRule(band: ScoreBand(zeroLow: -1, idealLow: 0.5, idealHigh: 4, zeroHigh: 10), weight: 1),
        .followThroughDuration: MetricScoringRule(band: ScoreBand(zeroLow: 0.05, idealLow: 0.15, idealHigh: 0.5, zeroHigh: 1.0), weight: 1),
        .followThroughFootHeight: MetricScoringRule(band: ScoreBand(zeroLow: -1, idealLow: 0.5, idealHigh: 3, zeroHigh: 5), weight: 1),
        .followThroughBodyTravel: MetricScoringRule(band: ScoreBand(zeroLow: -0.3, idealLow: 0.1, idealHigh: 1.5, zeroHigh: 3), weight: 1),
    ]
}

/// Facts about the athlete and recording that may change how a kick is interpreted.
struct BiomechanicsContext: Codable, Equatable, Sendable {
    var kickType: KickType
    var kickingFoot: KickingFoot
    /// Camera position for the analyzed video; affects confidence of 2D measurements.
    var cameraAngle: VideoAngleType
    /// Reserved for level-specific tuning (not used by the standard profiles yet).
    var playingLevel: PlayingLevel?
    /// Step 12E: how the kicker moved relative to the camera, as analyzed (nil in files
    /// written before Step 12E = the selected camera angle's perspective).
    var perspective: CameraPerspective?

    init(kickType: KickType, kickingFoot: KickingFoot, cameraAngle: VideoAngleType = .side, playingLevel: PlayingLevel? = nil,
         perspective: CameraPerspective? = nil) {
        self.kickType = kickType
        self.kickingFoot = kickingFoot
        self.cameraAngle = cameraAngle
        self.playingLevel = playingLevel
        self.perspective = perspective
    }

    /// The perspective used: recorded, or derived from the camera angle (older files).
    var effectivePerspective: CameraPerspective {
        if let perspective { return perspective }
        switch cameraAngle {
        case .side, .unknown: return .side
        case .rear: return .depthAway
        case .front, .behindGoal: return .depthToward
        case .oblique: return .oblique
        }
    }
}

/// Supplies the profile for a context. The standard provider uses kick type only;
/// later providers can tune by level, athlete baseline or camera angle.
protocol BiomechanicsProfileProviding: Sendable {
    func profile(for context: BiomechanicsContext) -> BiomechanicsProfile
}

struct StandardBiomechanicsProfiles: BiomechanicsProfileProviding {
    init() {}

    func profile(for context: BiomechanicsContext) -> BiomechanicsProfile {
        .standard(for: context.kickType)
    }
}
