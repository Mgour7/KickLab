import Foundation

// Build 21 — in-app camera: the pure, testable decisions (format choice and fallback,
// recording states, storage, heat and interruptions). The AVFoundation side lives in
// `Services/Capture/Apple/CameraRecorder.swift` and only carries these decisions out.

/// A resolution KickLab can ask for.
enum CaptureResolution: String, Codable, CaseIterable, Sendable, Comparable {
    case hd720 = "720p"
    case hd1080 = "1080p"
    case uhd4K = "4K"

    /// The long and short edges in pixels (sensor orientation is landscape).
    var dimensions: (long: Int, short: Int) {
        switch self {
        case .hd720: (1280, 720)
        case .hd1080: (1920, 1080)
        case .uhd4K: (3840, 2160)
        }
    }

    private var rank: Int {
        switch self {
        case .hd720: 0
        case .hd1080: 1
        case .uhd4K: 2
        }
    }

    static func < (a: Self, b: Self) -> Bool { a.rank < b.rank }
}

/// What the athlete chose. 1080p at 60 fps is the default: sharp enough to see the strike,
/// supported by every iPhone KickLab runs on, and modest in storage.
struct CaptureRequest: Codable, Hashable, Sendable {
    var resolution: CaptureResolution = .hd1080
    var framesPerSecond: Int = 60
    /// Off by default: kick analysis doesn't use sound, and the microphone is only asked
    /// for when the athlete turns this on.
    var recordsAudio = false

    static let standard = CaptureRequest()
    static let choices: [CaptureRequest] = [
        CaptureRequest(resolution: .hd1080, framesPerSecond: 60),
        CaptureRequest(resolution: .hd1080, framesPerSecond: 120),
        CaptureRequest(resolution: .hd1080, framesPerSecond: 30),
        CaptureRequest(resolution: .uhd4K, framesPerSecond: 60),
        CaptureRequest(resolution: .uhd4K, framesPerSecond: 30),
    ]

    var title: String { "\(resolution.rawValue) · \(framesPerSecond) fps" }
}

/// One camera format as KickLab sees it (built from `AVCaptureDevice.Format`).
struct CaptureFormatDescriptor: Codable, Equatable, Sendable {
    var width: Int
    var height: Int
    /// Highest frame rate of the format's supported ranges.
    var maxFrameRate: Double
    var minFrameRate: Double = 1
    /// Binned / lower-quality formats are avoided when an equal non-binned one exists.
    var isBinned = false

    var resolution: CaptureResolution? {
        let long = max(width, height), short = min(width, height)
        return CaptureResolution.allCases.first { $0.dimensions.long == long && $0.dimensions.short == short }
    }

    func supports(fps: Int) -> Bool { Double(fps) <= maxFrameRate + 0.01 && Double(fps) >= minFrameRate - 0.01 }
}

/// The configuration that will actually be used, and how it differs from the request.
struct CaptureSelection: Codable, Equatable, Sendable {
    var formatIndex: Int
    var resolution: CaptureResolution
    var framesPerSecond: Int
    var requested: CaptureRequest
    /// Nil when exactly what was asked for; otherwise shown to the athlete before recording.
    var fallbackReason: String?

    var title: String { "\(resolution.rawValue) · \(framesPerSecond) fps" }
    var isExact: Bool { fallbackReason == nil }
}

enum CaptureConfigurationSelector {
    /// Chooses a format for the request, falling back step by step:
    /// 1. the requested resolution and frame rate;
    /// 2. the requested resolution at a lower standard rate (120 → 60 → 30);
    /// 3. a lower resolution (4K → 1080p → 720p) at the requested rate, then lower rates.
    /// Never a higher frame rate than asked (more data than the athlete chose), never a
    /// silent change: any difference is described in `fallbackReason`.
    static func select(_ request: CaptureRequest, formats: [CaptureFormatDescriptor]) -> CaptureSelection? {
        let rates = [request.framesPerSecond] + [120, 60, 30].filter { $0 < request.framesPerSecond }
        let resolutions = [request.resolution] + CaptureResolution.allCases.filter { $0 < request.resolution }.sorted(by: >)
        for resolution in resolutions {
            for fps in rates {
                let candidates = formats.enumerated().filter { $0.element.resolution == resolution && $0.element.supports(fps: fps) }
                guard let best = candidates.min(by: { rank($0.element) < rank($1.element) }) else { continue }
                var reason: String?
                if resolution != request.resolution || fps != request.framesPerSecond {
                    reason = "This iPhone's camera can't record \(request.title); KickLab will record \(resolution.rawValue) · \(fps) fps."
                }
                return CaptureSelection(formatIndex: best.offset, resolution: resolution, framesPerSecond: fps,
                                        requested: request, fallbackReason: reason)
            }
        }
        return nil
    }

    /// Prefer non-binned formats; among equals, the one whose maximum rate is closest.
    private static func rank(_ f: CaptureFormatDescriptor) -> (Int, Double) { (f.isBinned ? 1 : 0, f.maxFrameRate) }

    /// After configuring, the camera reports the frame duration it actually applied.
    /// Recording must not start when it differs from the displayed rate.
    static func verify(_ selection: CaptureSelection, appliedFramesPerSecond: Double) -> String? {
        guard appliedFramesPerSecond.isFinite, appliedFramesPerSecond > 0 else { return "The camera didn't report its frame rate." }
        let expected = Double(selection.framesPerSecond)
        return abs(appliedFramesPerSecond - expected) / expected <= 0.01
            ? nil
            : String(format: "The camera applied %.0f fps instead of %d fps, so recording was not started.", appliedFramesPerSecond, selection.framesPerSecond)
    }
}

// MARK: - Recording states

enum CaptureFailure: String, Codable, Equatable, Sendable, Error {
    case cameraPermissionDenied
    case microphonePermissionDenied
    case noCamera
    case configurationFailed
    case frameRateMismatch
    case insufficientStorage
    case writeFailed
    case unknown

    var message: String {
        switch self {
        case .cameraPermissionDenied: "KickLab doesn't have camera access. Allow it in Settings › KickLab › Camera."
        case .microphonePermissionDenied: "Microphone access is off. Turn off \"Record sound\" or allow the microphone in Settings › KickLab."
        case .noCamera: "No rear camera is available."
        case .configurationFailed: "The camera couldn't be set up. Close other camera apps and try again."
        case .frameRateMismatch: "The camera didn't apply the chosen frame rate, so recording didn't start."
        case .insufficientStorage: "There isn't enough free space to record. Free up space and try again."
        case .writeFailed: "The video couldn't be written."
        case .unknown: "Recording stopped unexpectedly."
        }
    }
}

/// Why a recording ended other than by pressing Stop.
enum CaptureStopReason: String, Codable, Equatable, Sendable {
    case userStopped
    case interruption        // phone call, Siri, another app took the camera
    case backgrounded        // KickLab left the screen
    case thermal             // the phone got critically hot
    case storage             // free space ran out
    case systemError

    var message: String? {
        switch self {
        case .userStopped: nil
        case .interruption: "Recording stopped because another app or a call used the camera. What was recorded is saved."
        case .backgrounded: "Recording stopped when KickLab left the screen. What was recorded is saved."
        case .thermal: "Recording stopped because the iPhone got too hot. What was recorded is saved."
        case .storage: "Recording stopped because the iPhone ran out of space. What was recorded is saved."
        case .systemError: "Recording stopped because of a camera error."
        }
    }
}

enum CaptureState: Equatable, Sendable {
    case idle
    case requestingPermission
    case configuring
    case ready(CaptureSelection)
    case recording(CaptureSelection, startedAt: Date)
    /// Stop requested (or forced); waiting for the file to be finalized.
    case finishing(CaptureSelection, reason: CaptureStopReason)
    /// The file is finalized and readable. Only now may the UI say "saved".
    case saved(fileURL: URL, reason: CaptureStopReason, duration: Double?)
    case failed(CaptureFailure)
    /// Camera unavailable for now (call, another app); recording isn't possible until it ends.
    case interrupted(previous: CaptureSelection?)

    var isRecording: Bool { if case .recording = self { return true }; return false }
    var isBusy: Bool {
        switch self {
        case .recording, .finishing, .configuring, .requestingPermission: true
        default: false
        }
    }
    var canStartRecording: Bool { if case .ready = self { return true }; return false }
}

enum CaptureEvent: Equatable, Sendable {
    case requestPermissions
    case permissionsGranted
    case permissionDenied(CaptureFailure)
    case configured(CaptureSelection)
    case configurationFailed(CaptureFailure)
    case startRequested(at: Date)
    case stopRequested(CaptureStopReason)
    /// The recorder delegate reported the file. `usable` = AVFoundation says the file
    /// finished successfully (also true after an interruption that finalized the file).
    case fileFinished(url: URL, usable: Bool, duration: Double?)
    case interruptionBegan
    case interruptionEnded
    case reset
}

/// Pure transitions. The recorder performs the side effects for the resulting state.
enum CaptureStateMachine {
    static func reduce(_ state: CaptureState, _ event: CaptureEvent) -> CaptureState {
        switch (state, event) {
        case (_, .reset): return .idle
        // Also from ready/interrupted: changing the camera settings reconfigures.
        case (.idle, .requestPermissions), (.failed, .requestPermissions), (.saved, .requestPermissions),
             (.ready, .requestPermissions), (.interrupted, .requestPermissions): return .requestingPermission
        case (.requestingPermission, .permissionsGranted): return .configuring
        case (.requestingPermission, .permissionDenied(let f)): return .failed(f)
        // From failed: "Try Again" after a recording that couldn't be finished.
        case (.configuring, .configured(let s)), (.saved, .configured(let s)), (.interrupted, .configured(let s)),
             (.failed, .configured(let s)): return .ready(s)
        case (.configuring, .configurationFailed(let f)): return .failed(f)
        case (.ready(let s), .startRequested(let date)): return .recording(s, startedAt: date)
        case (.recording(let s, _), .stopRequested(let reason)): return .finishing(s, reason: reason)
        case (.recording(let s, _), .interruptionBegan): return .finishing(s, reason: .interruption)
        // A file can finish without a stop request (interruption, disk full, error).
        case (.recording, .fileFinished(let url, let usable, let duration)):
            return usable ? .saved(fileURL: url, reason: .systemError, duration: duration) : .failed(.writeFailed)
        case (.finishing(_, let reason), .fileFinished(let url, let usable, let duration)):
            return usable ? .saved(fileURL: url, reason: reason, duration: duration) : .failed(.writeFailed)
        case (.ready(let s), .interruptionBegan): return .interrupted(previous: s)
        case (.interrupted(let previous), .interruptionEnded): return previous.map { .ready($0) } ?? .configuring
        default: return state
        }
    }
}

// MARK: - Storage

/// Conservative recording-size estimates (Apple's published H.264 camera figures; HEVC
/// files are usually smaller, so these over-estimate, which is the safe direction).
enum CaptureStoragePolicy {
    /// Megabytes per minute of video.
    static func megabytesPerMinute(_ resolution: CaptureResolution, fps: Int) -> Double {
        switch (resolution, fps) {
        case (.hd720, _): return 45
        case (.hd1080, ...30): return 60
        case (.hd1080, ...60): return 90
        case (.hd1080, _): return 170
        case (.uhd4K, ...30): return 170
        case (.uhd4K, _): return 400
        }
    }

    static func bytesPerSecond(_ resolution: CaptureResolution, fps: Int) -> Double {
        megabytesPerMinute(resolution, fps: fps) * 1_000_000 / 60
    }

    /// Space always left free for iOS and KickLab's own files.
    static let reserveBytes: Int64 = 1_000_000_000
    /// Recording doesn't start with less than this much recording time.
    static let minimumStartMinutes = 3.0
    /// The screen warns below this.
    static let warningMinutes = 10.0

    static func minutesAvailable(freeBytes: Int64, resolution: CaptureResolution, fps: Int) -> Double {
        let usable = Double(max(0, freeBytes - reserveBytes))
        return usable / bytesPerSecond(resolution, fps: fps) / 60
    }

    enum Decision: Equatable, Sendable {
        case ok(minutes: Double)
        case warn(minutes: Double)
        /// Don't start / stop now and finalize.
        case stop(minutes: Double)
    }

    static func decide(freeBytes: Int64?, resolution: CaptureResolution, fps: Int, recording: Bool) -> Decision {
        // Unknown free space: allow, but never claim a number.
        guard let freeBytes else { return .ok(minutes: .infinity) }
        let m = minutesAvailable(freeBytes: freeBytes, resolution: resolution, fps: fps)
        if recording {
            return freeBytes <= reserveBytes ? .stop(minutes: 0) : (m < warningMinutes ? .warn(minutes: m) : .ok(minutes: m))
        }
        if m < minimumStartMinutes { return .stop(minutes: m) }
        return m < warningMinutes ? .warn(minutes: m) : .ok(minutes: m)
    }

    /// "About 48 minutes left at 1080p · 60 fps".
    static func text(_ decision: Decision, request: CaptureRequest) -> String {
        switch decision {
        case .ok(let m) where !m.isFinite: return "Free space unknown"
        case .ok(let m), .warn(let m): return "About \(Int(m.rounded(.down))) min of space at \(request.title)"
        case .stop: return "Not enough free space to record"
        }
    }
}

// MARK: - Heat

/// Mirrors `ProcessInfo.ThermalState` without importing it.
enum DeviceThermalLevel: Int, Codable, Sendable { case nominal, fair, serious, critical }

enum CaptureThermalPolicy {
    enum Action: Equatable, Sendable {
        case none
        /// Recording continues; the screen says the phone is hot and suggests shade.
        case warn(String)
        /// Stop now and keep the file (iOS may otherwise end the capture session itself).
        case stopAndSave
    }

    static func action(_ level: DeviceThermalLevel, recording: Bool) -> Action {
        switch level {
        case .nominal, .fair: return .none
        case .serious: return .warn("The iPhone is getting hot. Recording continues; shade the phone if you can.")
        case .critical: return recording ? .stopAndSave : .warn("The iPhone is too hot to record. Let it cool down.")
        }
    }
}
