import Foundation

/// Pure statistics math over `KickStatRecord` values. No database, no I/O.
enum KickStatisticsCalculator {
    // MARK: Field goal / PAT

    static func fieldGoal(
        _ records: [KickStatRecord],
        kickType: KickType,
        measurementSource: MeasurementSourceFilter
    ) -> FieldGoalStatistics {
        let kicks = records.filter { $0.kickType == kickType }

        var results = ResultBreakdown()
        for kick in kicks {
            switch kick.result ?? .unknown {
            case .made: results.made += 1
            case .missedLeft: results.missedLeft += 1
            case .missedRight: results.missedRight += 1
            case .short: results.short += 1
            case .blocked: results.blocked += 1
            case .unknown: results.unknown += 1
            }
        }

        let decided = kicks.filter { ($0.result ?? .unknown) != .unknown }

        let byDistance = DistanceBucket.allCases.map { bucket in
            DistanceBucketStatistics(
                bucket: bucket,
                makeRate: makeRate(decided.filter { $0.distanceYards.flatMap(DistanceBucket.bucket(forYards:)) == bucket })
            )
        }
        let withoutDistance = decided.filter { $0.distanceYards.flatMap(DistanceBucket.bucket(forYards:)) == nil }.count

        let byHash = [HashLocation.left, .center, .right].map { hash in
            HashStatistics(hash: hash, makeRate: makeRate(decided.filter { $0.hashLocation == hash }))
        }
        let byContext = KickContext.allCases.map { context in
            ContextStatistics(context: context, makeRate: makeRate(decided.filter { $0.context == context }))
        }

        return FieldGoalStatistics(
            kickType: kickType,
            kickCount: kicks.count,
            makeRate: makeRate(decided),
            results: results,
            byDistance: byDistance,
            decidedAttemptsWithoutDistance: withoutDistance,
            byHash: byHash,
            byContext: byContext,
            accuracy: accuracy(kicks, measurementSource: measurementSource)
        )
    }

    /// Makes over the given decided attempts.
    static func makeRate(_ decided: [KickStatRecord]) -> RateStatistic {
        RateStatistic(attempts: decided.count, successes: decided.filter { $0.result == .made }.count)
    }

    static func accuracy(_ kicks: [KickStatRecord], measurementSource: MeasurementSourceFilter) -> AccuracyStatistics {
        let sampled = kicks.filter { kick in
            guard let x = kick.accuracyX, x.isFinite else { return false }
            return measurementSource.includes(kick.accuracySource)
        }
        let xs = sampled.compactMap(\.accuracyX)
        let ys = sampled.compactMap(\.accuracyY).filter(\.isFinite)

        func distribution(_ values: [Double]) -> [BandCount] {
            HorizontalBand.allCases.map { band in
                BandCount(band: band, count: values.filter { HorizontalBand.band(forX: $0) == band }.count)
            }
        }

        return AccuracyStatistics(
            sampleCount: xs.count,
            averageX: mean(xs),
            averageAbsoluteDeviation: mean(xs.map { abs($0) }),
            verticalSampleCount: ys.count,
            averageY: mean(ys),
            madeDistribution: distribution(sampled.filter { $0.result == .made }.compactMap(\.accuracyX)),
            allDistribution: distribution(xs)
        )
    }

    // MARK: Kickoff

    static func kickoff(_ records: [KickStatRecord], measurementSource: MeasurementSourceFilter) -> KickoffStatistics {
        let kickoffs = records.filter { $0.kickType == .kickoff }
        let recordedTouchback = kickoffs.compactMap(\.touchback)

        let zones = [LandingZone.left, .middle, .right, .unknown].map { zone in
            ZoneCount(zone: zone, count: kickoffs.filter { $0.landingZone == zone }.count)
        }

        return KickoffStatistics(
            kickoffCount: kickoffs.count,
            touchbackRate: RateStatistic(attempts: recordedTouchback.count, successes: recordedTouchback.filter { $0 }.count),
            outOfBoundsCount: kickoffs.filter { $0.outOfBounds == true }.count,
            distance: summary(kickoffs.map { ($0.distanceYards, $0.distanceSource) }, filter: measurementSource),
            hangTime: summary(kickoffs.map { ($0.hangTimeSeconds, $0.hangTimeSource) }, filter: measurementSource),
            landingYardLine: summary(kickoffs.map { ($0.landingYardLine, $0.landingSource) }, filter: measurementSource),
            landingZones: zones
        )
    }

    // MARK: Punt

    static func punt(_ records: [KickStatRecord], measurementSource: MeasurementSourceFilter) -> PuntStatistics {
        let punts = records.filter { $0.kickType == .punt }
        return PuntStatistics(
            puntCount: punts.count,
            distance: summary(punts.map { ($0.distanceYards, $0.distanceSource) }, filter: measurementSource),
            hangTime: summary(punts.map { ($0.hangTimeSeconds, $0.hangTimeSource) }, filter: measurementSource)
        )
    }

    // MARK: Helpers

    /// Average and max of the finite values whose source passes `filter`.
    static func summary(
        _ samples: [(value: Double?, source: OutcomeMeasurementSource?)],
        filter: MeasurementSourceFilter
    ) -> MeasurementSummary {
        let included = samples.compactMap { sample -> (Double, OutcomeMeasurementSource?)? in
            guard let value = sample.value, value.isFinite, filter.includes(sample.source) else { return nil }
            return (value, sample.source)
        }
        guard !included.isEmpty else { return .empty }
        let values = included.map { $0.0 }
        let sources = OutcomeMeasurementSource.allCases.compactMap { source -> SourceCount? in
            let count = included.filter { ($0.1 ?? .unknown) == source }.count
            return count > 0 ? SourceCount(source: source, count: count) : nil
        }
        return MeasurementSummary(sampleCount: values.count, average: mean(values), maximum: values.max(), sources: sources)
    }

    static func mean(_ values: [Double]) -> Double? {
        values.isEmpty ? nil : values.reduce(0, +) / Double(values.count)
    }
}
