import Foundation

/// Which measurement sources an average or maximum may include.
/// Provenance is never discarded: results also report how many samples came from each source.
enum MeasurementSourceFilter: Equatable, Sendable {
    /// Every recorded value, including legacy values with no recorded source.
    case all
    case manualOnly
    /// primaryVideo, secondaryVideo or multiVideo.
    case videoDerivedOnly
    case only(Set<OutcomeMeasurementSource>)

    func includes(_ source: OutcomeMeasurementSource?) -> Bool {
        switch self {
        case .all: true
        case .manualOnly: source == .manual
        case .videoDerivedOnly: source?.isVideoDerived ?? false
        case .only(let allowed): source.map(allowed.contains) ?? false
        }
    }
}

/// What a statistic covers. Statistics are always for one athlete.
struct StatisticsFilter: Equatable, Sendable {
    var athleteID: UUID
    /// Inclusive on both ends; nil means all time.
    var dateRange: ClosedRange<Date>?
    /// Nil means every context.
    var contexts: Set<KickContext>?
    /// Applies to measured values (distance, hang time, landing line, accuracy averages).
    /// It does not change which kicks are counted as attempts.
    var measurementSource: MeasurementSourceFilter

    init(
        athleteID: UUID,
        dateRange: ClosedRange<Date>? = nil,
        contexts: Set<KickContext>? = nil,
        measurementSource: MeasurementSourceFilter = .all
    ) {
        self.athleteID = athleteID
        self.dateRange = dateRange
        self.contexts = contexts
        self.measurementSource = measurementSource
    }

    func query(kickTypes: Set<KickType>? = nil) -> KickQuery {
        KickQuery(athleteID: athleteID, kickTypes: kickTypes, contexts: contexts, dateRange: dateRange)
    }

    func with(dateRange: ClosedRange<Date>?) -> StatisticsFilter {
        var copy = self
        copy.dateRange = dateRange
        return copy
    }
}

/// The selection a `KickStatisticsSource` must apply.
struct KickQuery: Equatable, Sendable {
    var athleteID: UUID
    /// Nil means every kick type.
    var kickTypes: Set<KickType>?
    /// Nil means every context.
    var contexts: Set<KickContext>?
    /// Inclusive on both ends; nil means all time.
    var dateRange: ClosedRange<Date>?

    init(athleteID: UUID, kickTypes: Set<KickType>? = nil, contexts: Set<KickContext>? = nil, dateRange: ClosedRange<Date>? = nil) {
        self.athleteID = athleteID
        self.kickTypes = kickTypes
        self.contexts = contexts
        self.dateRange = dateRange
    }
}

/// Date-range helpers for trend comparisons. Fixed-length periods (24-hour days),
/// so results never depend on calendar or time-zone quirks.
enum StatisticsPeriod {
    /// The `days` days ending at `end` (inclusive).
    static func last(days: Int, endingAt end: Date) -> ClosedRange<Date> {
        end.addingTimeInterval(-Double(max(days, 0)) * 86_400)...end
    }

    /// The equally long period immediately before `range`, ending one millisecond
    /// before it starts so no kick is counted in both.
    static func previous(to range: ClosedRange<Date>) -> ClosedRange<Date> {
        let length = range.upperBound.timeIntervalSince(range.lowerBound)
        let end = range.lowerBound.addingTimeInterval(-0.001)
        return end.addingTimeInterval(-length)...end
    }
}
