import Foundation

/// FG/PAT selector for `StatisticsService.fieldGoalStatistics`, so a kickoff or punt
/// can't be requested by mistake.
enum GoalpostKickType: Sendable {
    case fieldGoal
    case pat

    var kickType: KickType {
        switch self {
        case .fieldGoal: .fieldGoal
        case .pat: .pat
        }
    }
}

/// Kicking statistics derived from stored kicks. No mock values: every number comes
/// from records returned by the `KickStatisticsSource`.
///
/// - Counts use `countKicks` (a `fetchCount` in SwiftData).
/// - Per-type statistics fetch that type's records once and compute in memory,
///   because SwiftData has no average/max aggregates. See `KickStatisticsSource`.
/// - Distances come from `Kick.distanceYards` only, never from the spot coordinate.
/// - `.unknown` results are not attempts, makes or misses for percentages.
///
/// Read-only: never writes or saves.
struct StatisticsService {
    let source: any KickStatisticsSource

    init(source: any KickStatisticsSource) {
        self.source = source
    }

    // MARK: General

    func totalKickCount(_ filter: StatisticsFilter) throws -> Int {
        try source.countKicks(matching: filter.query())
    }

    /// Field goal, PAT, kickoff, punt — zero counts included.
    func kickCountsByType(_ filter: StatisticsFilter) throws -> [KickTypeCount] {
        try KickType.selectableCases.map { type in
            KickTypeCount(kickType: type, count: try source.countKicks(matching: filter.query(kickTypes: [type])))
        }
    }

    /// Every context; a context excluded by the filter reports zero.
    func kickCountsByContext(_ filter: StatisticsFilter) throws -> [KickContextCount] {
        try KickContext.allCases.map { context in
            if let allowed = filter.contexts, !allowed.contains(context) {
                return KickContextCount(context: context, count: 0)
            }
            var query = filter.query()
            query.contexts = [context]
            return KickContextCount(context: context, count: try source.countKicks(matching: query))
        }
    }

    func kickCount(in range: ClosedRange<Date>, _ filter: StatisticsFilter) throws -> Int {
        try totalKickCount(filter.with(dateRange: range))
    }

    /// Newest first.
    func recentKicks(limit: Int, _ filter: StatisticsFilter) throws -> [KickStatRecord] {
        try source.records(matching: filter.query(), newestFirst: true, limit: limit)
    }

    func sessionKickCount(sessionID: UUID) throws -> Int {
        try source.kickCount(inSession: sessionID)
    }

    // MARK: Per type

    func fieldGoalStatistics(_ filter: StatisticsFilter, kickType: GoalpostKickType = .fieldGoal) throws -> FieldGoalStatistics {
        let type = kickType.kickType
        let records = try source.records(matching: filter.query(kickTypes: [type]), newestFirst: false, limit: nil)
        return KickStatisticsCalculator.fieldGoal(records, kickType: type, measurementSource: filter.measurementSource)
    }

    func kickoffStatistics(_ filter: StatisticsFilter) throws -> KickoffStatistics {
        let records = try source.records(matching: filter.query(kickTypes: [.kickoff]), newestFirst: false, limit: nil)
        return KickStatisticsCalculator.kickoff(records, measurementSource: filter.measurementSource)
    }

    func puntStatistics(_ filter: StatisticsFilter) throws -> PuntStatistics {
        let records = try source.records(matching: filter.query(kickTypes: [.punt]), newestFirst: false, limit: nil)
        return KickStatisticsCalculator.punt(records, measurementSource: filter.measurementSource)
    }

    // MARK: Trends

    /// Compares two periods with the same athlete, contexts and measurement-source filter.
    /// `filter.dateRange` is ignored; the two periods replace it.
    func trend(current: ClosedRange<Date>, previous: ClosedRange<Date>, _ filter: StatisticsFilter) throws -> PerformanceTrend {
        let currentFG = try fieldGoalStatistics(filter.with(dateRange: current))
        let previousFG = try fieldGoalStatistics(filter.with(dateRange: previous))
        let currentKO = try kickoffStatistics(filter.with(dateRange: current))
        let previousKO = try kickoffStatistics(filter.with(dateRange: previous))

        return PerformanceTrend(
            currentPeriod: current,
            previousPeriod: previous,
            fieldGoalPercentage: MetricTrend(
                current: currentFG.makeRate.percentage,
                previous: previousFG.makeRate.percentage,
                currentSampleCount: currentFG.makeRate.attempts,
                previousSampleCount: previousFG.makeRate.attempts
            ),
            touchbackPercentage: MetricTrend(
                current: currentKO.touchbackRate.percentage,
                previous: previousKO.touchbackRate.percentage,
                currentSampleCount: currentKO.touchbackRate.attempts,
                previousSampleCount: previousKO.touchbackRate.attempts
            ),
            averageKickoffDistance: MetricTrend(
                current: currentKO.distance.average,
                previous: previousKO.distance.average,
                currentSampleCount: currentKO.distance.sampleCount,
                previousSampleCount: previousKO.distance.sampleCount
            ),
            averageKickoffHangTime: MetricTrend(
                current: currentKO.hangTime.average,
                previous: previousKO.hangTime.average,
                currentSampleCount: currentKO.hangTime.sampleCount,
                previousSampleCount: previousKO.hangTime.sampleCount
            )
        )
    }

    /// The last `days` days ending at `now`, compared with the equally long period before.
    func trendForLast(days: Int, endingAt now: Date = .now, _ filter: StatisticsFilter) throws -> PerformanceTrend {
        let current = StatisticsPeriod.last(days: days, endingAt: now)
        return try trend(current: current, previous: StatisticsPeriod.previous(to: current), filter)
    }
}
