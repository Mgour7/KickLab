import Foundation

/// The fields statistics need from one kick, as a plain value.
///
/// Statistics are computed from these records, never from `Kick` models directly,
/// so the math is testable without a database and the data source can later be a
/// server instead of SwiftData.
struct KickStatRecord: Equatable, Sendable {
    var kickID: UUID = UUID()
    var athleteID: UUID?
    var sessionID: UUID?
    var timestamp: Date = .now
    var kickType: KickType = .fieldGoal
    var context: KickContext = .training
    var hashLocation: HashLocation = .notApplicable
    /// FG/PAT only.
    var result: KickResult?
    /// `Kick.distanceYards`. Never derived from the spot coordinate.
    var distanceYards: Double?
    var distanceSource: OutcomeMeasurementSource?
    var accuracyX: Double?
    var accuracyY: Double?
    var accuracySource: OutcomeMeasurementSource?
    var touchback: Bool?
    var outOfBounds: Bool?
    var landingYardLine: Double?
    var landingZone: LandingZone?
    var landingSource: OutcomeMeasurementSource?
    var hangTimeSeconds: Double?
    var hangTimeSource: OutcomeMeasurementSource?
    /// Step 12F entered details.
    var direction: KickDirection? = nil
    var puntInsideTwenty: Bool? = nil
    var puntResult: PuntResult? = nil
    var hasVideo: Bool = false
    /// Build 20: the athlete's own conditions note (e.g. "windy"), never inferred.
    var conditions: String? = nil
}

/// Where statistics read kicks from.
///
/// The SwiftData implementation (`SwiftDataKickStatisticsSource`) counts with
/// `fetchCount` and fetches only the kicks a query selects. SwiftData has no
/// average/max aggregates, so per-type statistics fetch that type's rows once
/// (a bounded fetch) and compute in memory. A future server backend can implement
/// this protocol with real aggregate queries without changing `StatisticsService`.
protocol KickStatisticsSource {
    func countKicks(matching query: KickQuery) throws -> Int
    func records(matching query: KickQuery, newestFirst: Bool, limit: Int?) throws -> [KickStatRecord]
    func kickCount(inSession sessionID: UUID) throws -> Int
}

/// An in-memory source. Used by tests and as a reference implementation of the
/// filtering rules every source must follow.
struct InMemoryKickStatisticsSource: KickStatisticsSource {
    var records: [KickStatRecord]

    init(_ records: [KickStatRecord]) {
        self.records = records
    }

    func countKicks(matching query: KickQuery) throws -> Int {
        records.filter { Self.matches($0, query) }.count
    }

    func records(matching query: KickQuery, newestFirst: Bool, limit: Int?) throws -> [KickStatRecord] {
        let sorted = records
            .filter { Self.matches($0, query) }
            .sorted { newestFirst ? $0.timestamp > $1.timestamp : $0.timestamp < $1.timestamp }
        guard let limit else { return sorted }
        return Array(sorted.prefix(max(limit, 0)))
    }

    func kickCount(inSession sessionID: UUID) throws -> Int {
        records.filter { $0.sessionID == sessionID }.count
    }

    static func matches(_ record: KickStatRecord, _ query: KickQuery) -> Bool {
        guard record.athleteID == query.athleteID else { return false }
        if let types = query.kickTypes, !types.contains(record.kickType) { return false }
        if let contexts = query.contexts, !contexts.contains(record.context) { return false }
        if let range = query.dateRange, !range.contains(record.timestamp) { return false }
        return true
    }
}
