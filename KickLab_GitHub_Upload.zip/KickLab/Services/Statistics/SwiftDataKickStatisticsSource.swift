import Foundation
import SwiftData

/// `KickStatisticsSource` backed by SwiftData.
///
/// - `countKicks` is a `fetchCount` on indexed scalar columns
///   (`athleteID`, `storedKickType`, `storedContext`, `timestamp`).
/// - `records` fetches only the selected kicks. SwiftData has no average/max
///   aggregates, so this bounded fetch is where per-type statistics read rows; it is
///   isolated here so a database or server backend can replace it.
/// - Filtering uses the stored raw strings. A kick whose context string was written by
///   a newer app version (unrecognized here) is not matched by a context filter.
struct SwiftDataKickStatisticsSource: KickStatisticsSource {
    let context: ModelContext

    init(context: ModelContext) {
        self.context = context
    }

    func countKicks(matching query: KickQuery) throws -> Int {
        try context.fetchCount(FetchDescriptor<Kick>(predicate: Self.predicate(for: query)))
    }

    func records(matching query: KickQuery, newestFirst: Bool, limit: Int?) throws -> [KickStatRecord] {
        var descriptor = FetchDescriptor<Kick>(
            predicate: Self.predicate(for: query),
            sortBy: [SortDescriptor(\.timestamp, order: newestFirst ? .reverse : .forward)]
        )
        descriptor.fetchLimit = limit
        return try context.fetch(descriptor).map(KickStatRecord.init(kick:))
    }

    /// Sessions hold a bounded number of kicks, so this counts the relationship.
    func kickCount(inSession sessionID: UUID) throws -> Int {
        let target = sessionID
        var descriptor = FetchDescriptor<KickingSession>(predicate: #Predicate { $0.id == target })
        descriptor.fetchLimit = 1
        return try context.fetch(descriptor).first?.kicks?.count ?? 0
    }

    /// Every clause is always present; "no filter" means "all known values".
    static func predicate(for query: KickQuery) -> Predicate<Kick> {
        let athleteID: UUID? = query.athleteID
        let typeRaws = (query.kickTypes ?? Set(KickType.allCases)).map(\.rawValue)
        let contextRaws = (query.contexts ?? Set(KickContext.allCases)).map(\.rawValue)
        let start = query.dateRange?.lowerBound ?? Date.distantPast
        let end = query.dateRange?.upperBound ?? Date.distantFuture
        return #Predicate<Kick> { kick in
            kick.athleteID == athleteID
                && typeRaws.contains(kick.storedKickType)
                && contextRaws.contains(kick.storedContext)
                && kick.timestamp >= start
                && kick.timestamp <= end
        }
    }
}

extension KickStatRecord {
    /// Copies the statistics fields of a stored kick.
    init(kick: Kick) {
        self.init(
            kickID: kick.id,
            athleteID: kick.athleteID,
            sessionID: kick.session?.id,
            timestamp: kick.timestamp,
            kickType: kick.kickType,
            context: kick.context,
            hashLocation: kick.hashLocation,
            result: KickResult(optionalStoredValue: kick.storedResult),
            distanceYards: kick.distanceYards,
            distanceSource: OutcomeMeasurementSource(optionalStoredValue: kick.storedDistanceSource),
            accuracyX: kick.accuracyX,
            accuracyY: kick.accuracyY,
            accuracySource: OutcomeMeasurementSource(optionalStoredValue: kick.storedAccuracySource),
            touchback: kick.touchback,
            outOfBounds: kick.outOfBounds,
            landingYardLine: kick.landingYardLine,
            landingZone: LandingZone(optionalStoredValue: kick.storedLandingZone),
            landingSource: OutcomeMeasurementSource(optionalStoredValue: kick.storedLandingSource),
            hangTimeSeconds: kick.hangTimeSeconds,
            hangTimeSource: OutcomeMeasurementSource(optionalStoredValue: kick.storedHangTimeSource),
            direction: kick.kickDirection,
            puntInsideTwenty: kick.puntInsideTwenty,
            puntResult: kick.puntResult,
            hasVideo: !(kick.videos ?? []).isEmpty,
            conditions: kick.conditionsNote
        )
    }
}
