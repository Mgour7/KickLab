import Foundation

/// successes / attempts. `rate` is nil when there are no attempts, never 0.
struct RateStatistic: Equatable, Sendable {
    let attempts: Int
    let successes: Int

    init(attempts: Int, successes: Int) {
        self.attempts = attempts
        self.successes = successes
    }

    static let empty = RateStatistic(attempts: 0, successes: 0)

    var failures: Int { attempts - successes }
    /// 0...1, or nil with no attempts.
    var rate: Double? { attempts > 0 ? Double(successes) / Double(attempts) : nil }
    /// 0...100, or nil with no attempts.
    var percentage: Double? { rate.map { $0 * 100 } }
}

/// Field-goal distance buckets by `Kick.distanceYards`:
/// under 30 is [0, 30), 30–39 is [30, 40), 40–49 is [40, 50), 50+ is [50, ∞).
enum DistanceBucket: String, CaseIterable, Codable, Sendable {
    case under30
    case from30To39
    case from40To49
    case fiftyPlus

    static func bucket(forYards yards: Double) -> DistanceBucket? {
        guard yards.isFinite, yards >= 0 else { return nil }
        switch yards {
        case ..<30: return .under30
        case ..<40: return .from30To39
        case ..<50: return .from40To49
        default: return .fiftyPlus
        }
    }

    var displayName: String {
        switch self {
        case .under30: "Under 30"
        case .from30To39: "30–39"
        case .from40To49: "40–49"
        case .fiftyPlus: "50+"
        }
    }
}

struct DistanceBucketStatistics: Equatable, Sendable {
    let bucket: DistanceBucket
    let makeRate: RateStatistic
}

struct HashStatistics: Equatable, Sendable {
    let hash: HashLocation
    let makeRate: RateStatistic
}

struct ContextStatistics: Equatable, Sendable {
    let context: KickContext
    let makeRate: RateStatistic
}

/// Counts of every FG/PAT result, including `unknown`.
struct ResultBreakdown: Equatable, Sendable {
    var made = 0
    var missedLeft = 0
    var missedRight = 0
    var short = 0
    var blocked = 0
    var unknown = 0

    /// Known results only; this is the make-percentage denominator.
    var decided: Int { made + missedLeft + missedRight + short + blocked }
}

/// Horizontal crossing bands in normalized goalpost coordinates (x: −1 left upright, +1 right).
enum HorizontalBand: String, CaseIterable, Sendable {
    /// x < −1
    case outsideLeft
    /// −1 ≤ x < −1/3
    case left
    /// −1/3 ≤ x ≤ 1/3
    case center
    /// 1/3 < x ≤ 1
    case right
    /// x > 1
    case outsideRight

    static func band(forX x: Double) -> HorizontalBand {
        switch x {
        case ..<(-1): .outsideLeft
        case ..<(-1.0 / 3.0): .left
        case ...(1.0 / 3.0): .center
        case ...1: .right
        default: .outsideRight
        }
    }
}

struct BandCount: Equatable, Sendable {
    let band: HorizontalBand
    let count: Int
}

/// Accuracy computed only from kicks with recorded coordinates. Vertical values are
/// averaged only over kicks whose `accuracyY` was recorded; they are never inferred.
struct AccuracyStatistics: Equatable, Sendable {
    /// Kicks with a recorded `accuracyX` (after the measurement-source filter).
    let sampleCount: Int
    /// Signed mean of x: negative = tends left, positive = tends right.
    let averageX: Double?
    /// Mean of |x|: average horizontal distance from center.
    let averageAbsoluteDeviation: Double?
    /// Kicks with a recorded `accuracyY`.
    let verticalSampleCount: Int
    let averageY: Double?
    /// Made kicks by horizontal band, in `HorizontalBand.allCases` order.
    let madeDistribution: [BandCount]
    /// All sampled kicks by horizontal band.
    let allDistribution: [BandCount]
}

/// How many samples came from each measurement source (nil sources count as `.unknown`).
struct SourceCount: Equatable, Sendable {
    let source: OutcomeMeasurementSource
    let count: Int
}

/// Average and maximum of a measured quantity, with provenance.
struct MeasurementSummary: Equatable, Sendable {
    let sampleCount: Int
    let average: Double?
    let maximum: Double?
    /// Sources of the included samples, in `OutcomeMeasurementSource.allCases` order, zero counts omitted.
    let sources: [SourceCount]

    static let empty = MeasurementSummary(sampleCount: 0, average: nil, maximum: nil, sources: [])
}

struct FieldGoalStatistics: Equatable, Sendable {
    /// `.fieldGoal` or `.pat`.
    let kickType: KickType
    /// Every kick of this type in the filter, including unknown results.
    let kickCount: Int
    /// Makes over decided attempts. `unknown` results are excluded from the denominator.
    let makeRate: RateStatistic
    let results: ResultBreakdown
    /// In `DistanceBucket.allCases` order.
    let byDistance: [DistanceBucketStatistics]
    /// Decided attempts with no recorded distance (not in any bucket).
    let decidedAttemptsWithoutDistance: Int
    /// Left, center, right.
    let byHash: [HashStatistics]
    /// In `KickContext.allCases` order.
    let byContext: [ContextStatistics]
    let accuracy: AccuracyStatistics
}

struct ZoneCount: Equatable, Sendable {
    let zone: LandingZone
    let count: Int
}

struct KickoffStatistics: Equatable, Sendable {
    let kickoffCount: Int
    /// Touchbacks over kickoffs where touchback was recorded (nil is not counted as "no").
    let touchbackRate: RateStatistic
    let outOfBoundsCount: Int
    let distance: MeasurementSummary
    let hangTime: MeasurementSummary
    let landingYardLine: MeasurementSummary
    /// Left, middle, right, unknown — zero counts included.
    let landingZones: [ZoneCount]
}

struct PuntStatistics: Equatable, Sendable {
    let puntCount: Int
    let distance: MeasurementSummary
    let hangTime: MeasurementSummary
}

struct KickTypeCount: Equatable, Sendable {
    let kickType: KickType
    let count: Int
}

struct KickContextCount: Equatable, Sendable {
    let context: KickContext
    let count: Int
}

/// One metric in two periods. `change` is current − previous when both exist.
struct MetricTrend: Equatable, Sendable {
    let current: Double?
    let previous: Double?
    let currentSampleCount: Int
    let previousSampleCount: Int

    var change: Double? {
        guard let current, let previous else { return nil }
        return current - previous
    }
}

struct PerformanceTrend: Equatable, Sendable {
    let currentPeriod: ClosedRange<Date>
    let previousPeriod: ClosedRange<Date>
    /// 0...100. Samples = decided field-goal attempts.
    let fieldGoalPercentage: MetricTrend
    /// 0...100. Samples = kickoffs with touchback recorded.
    let touchbackPercentage: MetricTrend
    /// Yards. Samples = kickoffs with a distance passing the measurement-source filter.
    let averageKickoffDistance: MetricTrend
    /// Seconds. Samples = kickoffs with a hang time passing the measurement-source filter.
    let averageKickoffHangTime: MetricTrend
}
