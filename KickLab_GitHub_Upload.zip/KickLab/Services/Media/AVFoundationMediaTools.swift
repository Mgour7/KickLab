#if canImport(AVFoundation) && canImport(ImageIO)
import AVFoundation
import Foundation
import ImageIO
import UniformTypeIdentifiers

/// Reads duration, nominal frame rate, display dimensions and audio presence with AVFoundation.
struct AVFoundationVideoMetadataReader: VideoMetadataReading {
    init() {}

    func readMetadata(at url: URL) async -> VideoMediaMetadata? {
        let asset = AVURLAsset(url: url)
        do {
            let duration = try await asset.load(.duration)
            let videoTracks = try await asset.loadTracks(withMediaType: .video)
            let audioTracks = try await asset.loadTracks(withMediaType: .audio)

            var width: Int?
            var height: Int?
            var frameRate: Double?
            if let track = videoTracks.first {
                let (size, transform, nominalRate) = try await track.load(.naturalSize, .preferredTransform, .nominalFrameRate)
                let oriented = CGRect(origin: .zero, size: size).applying(transform)
                width = Int(abs(oriented.width).rounded())
                height = Int(abs(oriented.height).rounded())
                frameRate = Double(nominalRate)
            }
            return VideoMediaMetadata(
                durationSeconds: duration.seconds,
                frameRate: frameRate,
                pixelWidth: width,
                pixelHeight: height,
                hasAudio: !audioTracks.isEmpty
            )
        } catch {
            return nil
        }
    }
}

/// Writes a JPEG of a frame one third of the way into the video (a representative
/// frame for a short kick clip), oriented for display and capped in size.
struct AVFoundationThumbnailGenerator: VideoThumbnailGenerating {
    let maximumDimension: Double
    let compressionQuality: Double

    init(maximumDimension: Double = 640, compressionQuality: Double = 0.8) {
        self.maximumDimension = maximumDimension
        self.compressionQuality = compressionQuality
    }

    func generateThumbnail(for videoURL: URL, writingTo destination: URL) async -> Bool {
        let asset = AVURLAsset(url: videoURL)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: maximumDimension, height: maximumDimension)
        do {
            let duration = try await asset.load(.duration).seconds
            let seconds = duration.isFinite && duration > 0 ? duration / 3 : 0
            let (image, _) = try await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600))
            return writeJPEG(image, to: destination)
        } catch {
            return false
        }
    }

    private func writeJPEG(_ image: CGImage, to destination: URL) -> Bool {
        guard let target = CGImageDestinationCreateWithURL(
            destination as CFURL,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else { return false }
        let options = [kCGImageDestinationLossyCompressionQuality: compressionQuality] as CFDictionary
        CGImageDestinationAddImage(target, image, options)
        return CGImageDestinationFinalize(target)
    }
}
#endif
