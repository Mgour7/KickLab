import Foundation

/// Why a relative path was refused.
enum ManagedPathError: Error, Equatable, Sendable {
    case empty
    /// Starts with "/" or "~".
    case absolute(String)
    /// A component is empty, ".", "..", hidden, or contains characters outside the allowlist.
    case invalidComponent(String)
}

/// Builds and validates the relative paths KickLab stores in SwiftData.
///
/// Paths are generated from UUIDs only, never from user-visible filenames. Every
/// stored path is re-validated before use, so even a corrupted or imported row
/// cannot address a file outside the managed roots.
enum ManagedPath {
    /// Characters allowed in a path component. Anything else is rejected.
    static let allowedCharacters = CharacterSet(
        charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
    )

    /// Video container extensions KickLab accepts for import.
    static let supportedVideoExtensions: Set<String> = ["mov", "mp4", "m4v"]

    static let originalVideoBaseName = "original"
    static let thumbnailFileName = "thumbnail.jpg"

    // MARK: Validation

    /// Validated components of a relative path, or a thrown `ManagedPathError`.
    static func components(of relativePath: String) throws -> [String] {
        guard !relativePath.isEmpty else { throw ManagedPathError.empty }
        guard !relativePath.hasPrefix("/"), !relativePath.hasPrefix("~") else {
            throw ManagedPathError.absolute(relativePath)
        }
        let parts = relativePath.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        for part in parts {
            let valid = !part.isEmpty
                && !part.hasPrefix(".")          // rejects ".", "..", and hidden names
                && part.unicodeScalars.allSatisfy { allowedCharacters.contains($0) }
            guard valid else { throw ManagedPathError.invalidComponent(part) }
        }
        return parts
    }

    static func isValid(_ relativePath: String) -> Bool {
        (try? components(of: relativePath)) != nil
    }

    /// Resolves a validated relative path under `root`. The result can never be
    /// outside `root`, because no component may be "..", absolute, or hidden.
    static func url(for relativePath: String, under root: URL) throws -> URL {
        let parts = try components(of: relativePath)
        return parts.reduce(root) { $0.appendingPathComponent($1) }
    }

    /// Every ancestor path of `relativePath`, nearest first, excluding the path itself.
    /// "a/b/c.mov" → ["a/b", "a"].
    static func ancestors(of relativePath: String) -> [String] {
        var parts = relativePath.split(separator: "/").map(String.init)
        var result: [String] = []
        while parts.count > 1 {
            parts.removeLast()
            result.append(parts.joined(separator: "/"))
        }
        return result
    }

    // MARK: Builders (media area)

    static func kickDirectory(kickID: UUID) -> String {
        kickID.uuidString.lowercased()
    }

    static func videoDirectory(kickID: UUID, videoID: UUID) -> String {
        "\(kickDirectory(kickID: kickID))/\(videoID.uuidString.lowercased())"
    }

    static func originalVideoPath(kickID: UUID, videoID: UUID, fileExtension: String) -> String {
        "\(videoDirectory(kickID: kickID, videoID: videoID))/\(originalVideoBaseName).\(fileExtension)"
    }

    static func thumbnailPath(kickID: UUID, videoID: UUID) -> String {
        "\(videoDirectory(kickID: kickID, videoID: videoID))/\(thumbnailFileName)"
    }

    // MARK: Builders (analysis area)

    static func analysisDirectory(analysisID: UUID) -> String {
        analysisID.uuidString.lowercased()
    }

    // MARK: Sanitizing imported names

    /// The lowercased container extension of `source`, if KickLab supports it.
    /// The source filename itself is never used to build a stored path.
    static func videoFileExtension(for source: URL) -> String? {
        let ext = source.pathExtension.lowercased()
        return supportedVideoExtensions.contains(ext) ? ext : nil
    }

    /// A display-only copy of the source filename: last component, control characters
    /// and path separators removed, trimmed, at most 255 characters. Nil if nothing remains.
    static func displayFilename(from source: URL) -> String? {
        displayFilename(fromName: source.lastPathComponent)
    }

    static func displayFilename(fromName raw: String) -> String? {
        let cleaned = String(String.UnicodeScalarView(raw.unicodeScalars.filter {
            !CharacterSet.controlCharacters.contains($0) && $0 != "/" && $0 != "\\"
        }))
        let trimmed = cleaned.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return String(trimmed.prefix(255))
    }
}
