import Foundation

/// The two app-managed storage areas. Relative paths stored in SwiftData are
/// always relative to one of these roots, never absolute.
enum MediaArea: String, Sendable, CaseIterable {
    /// `Application Support/KickLab/Media/` — videos and thumbnails.
    case media
    /// `Application Support/KickLab/Analysis/` — file-backed analysis artifacts.
    case analysis
}

/// Where KickLab keeps files on disk.
///
///     Application Support/
///       KickLab/
///         Media/<kickUUID>/<videoUUID>/original.mov
///         Media/<kickUUID>/<videoUUID>/thumbnail.jpg
///         Analysis/<analysisUUID>/...
///
/// The base URL is injectable so tests can use a temporary directory.
struct MediaLocations: Sendable, Equatable {
    static let mediaFolderName = "Media"
    static let analysisFolderName = "Analysis"

    /// `.../Application Support/KickLab`
    let baseURL: URL

    init(baseURL: URL) {
        self.baseURL = baseURL.standardizedFileURL
    }

    var mediaRootURL: URL {
        baseURL.appendingPathComponent(Self.mediaFolderName, isDirectory: true)
    }

    var analysisRootURL: URL {
        baseURL.appendingPathComponent(Self.analysisFolderName, isDirectory: true)
    }

    func rootURL(for area: MediaArea) -> URL {
        switch area {
        case .media: mediaRootURL
        case .analysis: analysisRootURL
        }
    }

    /// The production location inside the app's Application Support directory.
    static func applicationSupport() throws -> MediaLocations {
        let support = try FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        return MediaLocations(baseURL: support.appendingPathComponent("KickLab", isDirectory: true))
    }
}
