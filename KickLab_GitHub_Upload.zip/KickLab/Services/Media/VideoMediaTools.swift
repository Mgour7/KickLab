import Foundation

/// Technical facts read from a video file. Every field is optional: a value is
/// nil whenever it could not be read reliably, never a guess.
struct VideoMediaMetadata: Equatable, Sendable {
    var durationSeconds: Double?
    /// The track's nominal frame rate as encoded (e.g. 240 for slow motion).
    /// Variable-frame-rate recordings may deviate from it.
    var frameRate: Double?
    /// Display-oriented dimensions (the track's preferred transform applied).
    var pixelWidth: Int?
    var pixelHeight: Int?
    var hasAudio: Bool?

    init(
        durationSeconds: Double? = nil,
        frameRate: Double? = nil,
        pixelWidth: Int? = nil,
        pixelHeight: Int? = nil,
        hasAudio: Bool? = nil
    ) {
        self.durationSeconds = Self.positiveFinite(durationSeconds)
        self.frameRate = Self.positiveFinite(frameRate)
        self.pixelWidth = pixelWidth.flatMap { $0 > 0 ? $0 : nil }
        self.pixelHeight = pixelHeight.flatMap { $0 > 0 ? $0 : nil }
        self.hasAudio = hasAudio
    }

    private static func positiveFinite(_ value: Double?) -> Double? {
        guard let value, value.isFinite, value > 0 else { return nil }
        return value
    }
}

/// Reads technical metadata from a local video file. Returns nil on failure;
/// a failed read never fails an import.
protocol VideoMetadataReading: Sendable {
    func readMetadata(at url: URL) async -> VideoMediaMetadata?
}

/// Writes a representative still frame of a video as a JPEG.
/// Returns true only if the file was written.
protocol VideoThumbnailGenerating: Sendable {
    func generateThumbnail(for videoURL: URL, writingTo destination: URL) async -> Bool
}

/// Used where metadata cannot or need not be read (tests, non-Apple platforms).
struct NoVideoMetadataReader: VideoMetadataReading {
    init() {}
    func readMetadata(at url: URL) async -> VideoMediaMetadata? { nil }
}

/// Used where thumbnails cannot or need not be generated (tests, non-Apple platforms).
struct NoThumbnailGenerator: VideoThumbnailGenerating {
    init() {}
    func generateThumbnail(for videoURL: URL, writingTo destination: URL) async -> Bool { false }
}
