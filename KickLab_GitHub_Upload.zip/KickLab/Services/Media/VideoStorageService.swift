import Foundation
import SwiftData

/// Byte totals for an athlete's videos.
struct MediaByteTotals: Equatable, Sendable {
    let videoCount: Int
    /// Sum of `VideoAsset.fileSizeBytes` as recorded at import.
    let recordedBytes: Int64
    /// Sum of the managed files actually on disk (videos and thumbnails).
    let onDiskBytes: Int64
    /// Videos whose managed file is referenced but not on disk.
    let missingFileCount: Int
}

/// Manages KickLab's video files and their `VideoAsset` records.
///
/// File work is delegated to `ManagedMediaStore` (no SwiftData, runs off the main
/// actor); this service records the results in SwiftData and enforces:
/// - V1  video bytes never enter SwiftData; records hold relative paths only;
/// - V2  at most one primary video per kick; the first video becomes primary, and
///       making another primary clears the old one in the same save;
/// - V3  a missing file yields `.missing`, never a crash;
/// - V4  orphaned files can be detected and swept;
/// - files are removed only after the record deletion is saved; Photos-library
///   originals and import sources are never deleted.
///
/// `@MainActor` because it uses the main `ModelContext` across `await`
/// (imports read metadata and write thumbnails asynchronously).
///
/// Save policy: see `ModelCommit`. Every mutating method saves before returning.
@MainActor
struct VideoStorageService {
    let context: ModelContext
    let store: ManagedMediaStore
    let saveHandler: ModelSaveHandler

    init(context: ModelContext, store: ManagedMediaStore, saveHandler: @escaping ModelSaveHandler = ModelCommit.defaultSave) {
        self.context = context
        self.store = store
        self.saveHandler = saveHandler
    }

    var mediaRootURL: URL { store.mediaRootURL }
    var analysisRootURL: URL { store.analysisRootURL }

    /// Creates the managed `Media/` and `Analysis/` folders if needed.
    func prepareDirectories() throws {
        try store.prepareDirectories()
    }

    // MARK: Import

    /// Copies a local video into managed storage and attaches it to `kick`.
    ///
    /// - The source file is read only; it is never moved, changed or deleted.
    /// - Metadata (duration, nominal frame rate, dimensions, audio) and a thumbnail
    ///   are added when AVFoundation can read them; failures leave those fields nil.
    /// - The video becomes primary when `makePrimary` is true or the kick has no
    ///   primary video yet; any previous primary is cleared in the same save.
    /// - `photosLocalIdentifier` records where a Photos import came from. KickLab works
    ///   on its own copy and never deletes the Photos original.
    /// - If the record cannot be saved, or the kick is deleted during the import, the
    ///   copied files are discarded.
    @discardableResult
    func importVideo(
        from source: URL,
        for kick: Kick,
        angle: VideoAngleType,
        sourceType: VideoSourceType,
        makePrimary: Bool = false,
        photosLocalIdentifier: String? = nil,
        recordedAt: Date? = nil
    ) async throws -> VideoAsset {
        try requireManaged(kick)
        let prepared = try await store.prepareImport(from: source, kickID: kick.id, videoID: UUID())

        guard !kick.isDeleted, context.manages(kick) else {
            store.discard(prepared)
            throw VideoStorageError.kickNoLongerExists
        }

        let siblings = (kick.videos ?? []).filter { !$0.isDeleted }
        let becomesPrimary = makePrimary || !siblings.contains(where: \.isPrimary)

        let video = VideoAsset(
            id: prepared.videoID,
            angleType: angle,
            isPrimary: becomesPrimary,
            sourceType: sourceType,
            storageStatus: .local,
            relativeFilePath: prepared.relativeFilePath
        )
        context.insert(video)
        video.thumbnailRelativePath = prepared.thumbnailRelativePath
        video.fileSizeBytes = prepared.byteCount
        video.originalFilename = prepared.originalFilename
        video.photosLocalIdentifier = photosLocalIdentifier
        video.recordedAt = recordedAt
        video.durationSeconds = prepared.metadata?.durationSeconds
        video.frameRate = prepared.metadata?.frameRate
        video.pixelWidth = prepared.metadata?.pixelWidth
        video.pixelHeight = prepared.metadata?.pixelHeight
        video.hasAudio = prepared.metadata?.hasAudio
        video.sortOrder = (siblings.map(\.sortOrder).max() ?? -1) + 1
        if becomesPrimary {
            for sibling in siblings { sibling.isPrimary = false }
        }
        video.kick = kick

        do {
            try commit()
        } catch {
            store.discard(prepared)
            throw error
        }
        return video
    }

    // MARK: Primary video

    /// Makes `video` its kick's only primary video, in one save.
    func setPrimary(_ video: VideoAsset) throws {
        try requireManaged(video)
        guard let kick = video.kick else { throw VideoStorageError.videoHasNoKick(videoID: video.id) }
        for sibling in kick.videos ?? [] {
            sibling.isPrimary = (sibling.id == video.id)
        }
        video.isPrimary = true
        try commit()
    }

    // MARK: Resolving and status

    /// The managed file's URL, or nil when the video has no managed copy or its path is unsafe.
    func fileURL(for video: VideoAsset) -> URL? {
        video.relativeFilePath.flatMap { try? store.url(for: $0, in: .media) }
    }

    func thumbnailURL(for video: VideoAsset) -> URL? {
        video.thumbnailRelativePath.flatMap { try? store.url(for: $0, in: .media) }
    }

    /// True when the managed copy exists on disk.
    func fileExists(for video: VideoAsset) -> Bool {
        video.relativeFilePath.map { store.fileExists($0, in: .media) } ?? false
    }

    /// Recomputes `storageStatus` from what is actually on disk. Saves only if it changed.
    @discardableResult
    func refreshStorageStatus(of video: VideoAsset) throws -> VideoStorageStatus {
        try requireManaged(video)
        let status = resolvedStatus(of: video)
        if status != video.storageStatus {
            video.storageStatus = status
            try commit()
        }
        return status
    }

    /// Refreshes every video of a kick in one save (only if something changed).
    func refreshStorageStatuses(for kick: Kick) throws {
        try requireManaged(kick)
        var changed = false
        for video in kick.videos ?? [] {
            let status = resolvedStatus(of: video)
            if status != video.storageStatus {
                video.storageStatus = status
                changed = true
            }
        }
        if changed { try commit() }
    }

    // MARK: Removal

    /// Deletes a video record, then its managed files. If it was primary, the
    /// next video (lowest sort order) becomes primary in the same save.
    /// Analyses that used it keep existing (their input link is nullified).
    @discardableResult
    func removeVideo(_ video: VideoAsset) throws -> MediaCleanupOutcome {
        try requireManaged(video)
        let request = Self.managedFiles(of: [video])
        let kick = video.kick
        let wasPrimary = video.isPrimary
        let removedID = video.id

        context.delete(video)
        if wasPrimary, let kick {
            let next = (kick.videos ?? [])
                .filter { $0.id != removedID && !$0.isDeleted }
                .sorted { ($0.sortOrder, $0.createdAt) < ($1.sortOrder, $1.createdAt) }
                .first
            next?.isPrimary = true
        }
        try commit()
        return store.remove(request)
    }

    /// Deletes every video record of a kick, then removes the kick's media folder.
    @discardableResult
    func removeAllVideos(of kick: Kick) throws -> MediaCleanupOutcome {
        try requireManaged(kick)
        let videos = kick.videos ?? []
        let request = Self.managedFiles(of: videos)
        for video in videos { context.delete(video) }
        try commit()
        var outcome = store.remove(request)
        outcome.merge(store.removeKickDirectory(kickID: kick.id))
        return outcome
    }

    // MARK: Totals and orphans

    /// Recorded and on-disk bytes for every video of an athlete's kicks.
    func mediaByteTotals(for athlete: Athlete) -> MediaByteTotals {
        let videos = (athlete.kicks ?? []).flatMap { $0.videos ?? [] }
        var recorded: Int64 = 0
        var onDisk: Int64 = 0
        var missing = 0
        for video in videos {
            recorded += max(0, video.fileSizeBytes ?? 0)
            if let path = video.relativeFilePath {
                if let size = store.fileSize(path, in: .media) { onDisk += size } else { missing += 1 }
            }
            if let thumbnail = video.thumbnailRelativePath {
                onDisk += store.fileSize(thumbnail, in: .media) ?? 0
            }
        }
        return MediaByteTotals(videoCount: videos.count, recordedBytes: recorded, onDiskBytes: onDisk, missingFileCount: missing)
    }

    /// Files under the managed roots that no `VideoAsset` or `BiomechanicsAnalysis` references.
    ///
    /// Fetches every video and analysis to build the referenced set. That is a bounded
    /// read of two path columns; fine at V1 scale and isolated here if it ever needs
    /// a narrower query.
    func orphanReport(minimumAge: TimeInterval = 3600, now: Date = .now) throws -> OrphanReport {
        let videos = try context.fetch(FetchDescriptor<VideoAsset>())
        let analyses = try context.fetch(FetchDescriptor<BiomechanicsAnalysis>())
        let mediaReferences = Set(videos.flatMap { [$0.relativeFilePath, $0.thumbnailRelativePath].compactMap { $0 } })
        let analysisReferences = Set(analyses.compactMap(\.artifactsRelativePath))
        return store.orphanReport(
            referencedMediaPaths: mediaReferences,
            referencedAnalysisPaths: analysisReferences,
            minimumAge: minimumAge,
            now: now
        )
    }

    /// Removes unreferenced managed files older than `minimumAge` (default one hour,
    /// so an in-flight import is never swept). Read-only toward SwiftData.
    @discardableResult
    func sweepOrphans(minimumAge: TimeInterval = 3600, now: Date = .now) throws -> MediaCleanupOutcome {
        store.sweep(try orphanReport(minimumAge: minimumAge, now: now))
    }

    // MARK: Analysis artifact locations

    /// Where an analysis's artifacts belong: `Analysis/<analysisUUID>/`.
    /// Writing artifacts arrives with the analysis engine.
    func artifactsLocation(for analysis: BiomechanicsAnalysis) throws -> (relativePath: String, url: URL) {
        let path = ManagedPath.analysisDirectory(analysisID: analysis.id)
        return (path, try store.url(for: path, in: .analysis))
    }

    // MARK: Helpers

    /// Managed files of the given videos. Photos identifiers are deliberately excluded.
    static func managedFiles(of videos: [VideoAsset]) -> MediaCleanupRequest {
        MediaCleanupRequest(mediaRelativePaths: videos.flatMap {
            [$0.relativeFilePath, $0.thumbnailRelativePath].compactMap { $0 }
        })
    }

    private func resolvedStatus(of video: VideoAsset) -> VideoStorageStatus {
        VideoStorageStatusResolver.resolve(
            current: video.storageStatus,
            hasManagedPath: video.relativeFilePath != nil,
            managedFileExists: fileExists(for: video),
            hasPhotosIdentifier: video.photosLocalIdentifier != nil
        )
    }

    private func requireManaged(_ model: any PersistentModel) throws {
        guard context.manages(model) else { throw VideoStorageError.notInServiceContext }
    }

    private func commit() throws {
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw VideoStorageError.persistenceFailed(failure.underlyingDescription)
        }
    }
}
