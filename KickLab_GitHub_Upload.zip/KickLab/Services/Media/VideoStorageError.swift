import Foundation

/// Errors from media storage and `VideoStorageService`.
enum VideoStorageError: Error, Equatable, Sendable, LocalizedError {
    /// A stored or generated relative path failed validation.
    case invalidPath(ManagedPathError)
    /// The source is not a `file://` URL.
    case sourceNotAFileURL
    /// No readable file exists at the source URL.
    case sourceNotFound
    /// The file's container type is not one KickLab imports (mov, mp4, m4v).
    case unsupportedVideoType(fileExtension: String)
    case directoryCreationFailed(String)
    case copyFailed(String)
    /// The kick was deleted while its video was being imported. The copy was discarded.
    case kickNoLongerExists
    /// The video is not attached to a kick.
    case videoHasNoKick(videoID: UUID)
    case notInServiceContext
    /// `ModelContext.save()` failed. The context was rolled back; copied files were discarded.
    case persistenceFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidPath: "The media path is invalid."
        case .sourceNotAFileURL, .sourceNotFound: "The video file couldn't be found."
        case .unsupportedVideoType(let ext): "KickLab can't import .\(ext) files. Use .mov, .mp4 or .m4v."
        case .directoryCreationFailed, .copyFailed: "KickLab couldn't store the video."
        case .kickNoLongerExists: "The kick was deleted before the video finished importing."
        case .videoHasNoKick: "This video isn't attached to a kick."
        case .notInServiceContext: "The record isn't available in this data context."
        case .persistenceFailed: "KickLab couldn't save the change."
        }
    }
}
