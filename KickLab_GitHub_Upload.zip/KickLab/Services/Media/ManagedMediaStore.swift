import Foundation

/// A video copied into managed storage, ready to be recorded in SwiftData.
struct PreparedVideoImport: Equatable, Sendable {
    let kickID: UUID
    let videoID: UUID
    /// Relative to the media root.
    let relativeFilePath: String
    /// Relative to the media root; nil when no thumbnail could be generated.
    let thumbnailRelativePath: String?
    let byteCount: Int64?
    /// Nil when metadata could not be read; the import still succeeds.
    let metadata: VideoMediaMetadata?
    /// Display-only, sanitized. Never used to build a path.
    let originalFilename: String?
}

struct MediaCleanupFailure: Equatable, Sendable {
    let relativePath: String
    let area: MediaArea
    let reason: String
}

/// What a removal or sweep did. Removal is idempotent: repeating it reports
/// already-removed files as `alreadyMissing`, never as an error.
struct MediaCleanupOutcome: Equatable, Sendable {
    var removed: [String] = []
    var alreadyMissing: [String] = []
    /// Paths refused because they failed validation. Nothing was touched for them.
    var rejectedUnsafe: [String] = []
    /// Files that could not be removed. They stay unreferenced on disk and the
    /// next orphan sweep retries them.
    var failed: [MediaCleanupFailure] = []

    var isComplete: Bool { failed.isEmpty && rejectedUnsafe.isEmpty }

    mutating func merge(_ other: MediaCleanupOutcome) {
        removed += other.removed
        alreadyMissing += other.alreadyMissing
        rejectedUnsafe += other.rejectedUnsafe
        failed += other.failed
    }
}

/// Unreferenced files found under the managed roots.
struct OrphanReport: Equatable, Sendable {
    var mediaPaths: [String] = []
    var analysisPaths: [String] = []
    var totalBytes: Int64 = 0

    var isEmpty: Bool { mediaPaths.isEmpty && analysisPaths.isEmpty }
}

/// KickLab's managed file storage. Knows nothing about SwiftData: it works purely
/// with relative paths, so it is testable on any platform and safe to call from
/// any thread.
///
/// Rules:
/// - Every path is validated (`ManagedPath`) and resolved under a managed root, so
///   nothing outside `Media/` or `Analysis/` can be read, written or deleted.
/// - Only KickLab-managed copies are ever removed. Photos-library originals and
///   imported source files are never touched.
/// - Removal is idempotent and never throws; failures are left for the orphan sweep.
///
/// Conforms to `MediaCleanupHandling`, so `KickService` and `AthleteService` call
/// it only after their deletion has been saved.
struct ManagedMediaStore: MediaCleanupHandling, Sendable {
    let locations: MediaLocations
    let fileSystem: any MediaFileSystem
    let metadataReader: any VideoMetadataReading
    let thumbnailGenerator: any VideoThumbnailGenerating

    init(
        locations: MediaLocations,
        fileSystem: any MediaFileSystem = LocalMediaFileSystem(),
        metadataReader: any VideoMetadataReading = NoVideoMetadataReader(),
        thumbnailGenerator: any VideoThumbnailGenerating = NoThumbnailGenerator()
    ) {
        self.locations = locations
        self.fileSystem = fileSystem
        self.metadataReader = metadataReader
        self.thumbnailGenerator = thumbnailGenerator
    }

    var mediaRootURL: URL { locations.mediaRootURL }
    var analysisRootURL: URL { locations.analysisRootURL }

    /// Creates `Media/` and `Analysis/` if needed.
    func prepareDirectories() throws {
        for area in MediaArea.allCases {
            do {
                try fileSystem.createDirectory(at: locations.rootURL(for: area))
            } catch {
                throw VideoStorageError.directoryCreationFailed(String(describing: error))
            }
        }
    }

    // MARK: Resolving

    /// The absolute URL for a stored relative path. Throws for unsafe paths.
    func url(for relativePath: String, in area: MediaArea) throws -> URL {
        do {
            return try ManagedPath.url(for: relativePath, under: locations.rootURL(for: area))
        } catch let error as ManagedPathError {
            throw VideoStorageError.invalidPath(error)
        }
    }

    /// False for missing files and for unsafe paths.
    func fileExists(_ relativePath: String, in area: MediaArea) -> Bool {
        guard let url = try? url(for: relativePath, in: area) else { return false }
        return fileSystem.itemExists(at: url)
    }

    func fileSize(_ relativePath: String, in area: MediaArea) -> Int64? {
        guard let url = try? url(for: relativePath, in: area) else { return nil }
        return fileSystem.fileSize(at: url)
    }

    // MARK: Import

    /// Copies `source` into `Media/<kick>/<video>/original.<ext>`, then reads metadata
    /// and writes a thumbnail. Metadata and thumbnail failures do not fail the import.
    /// The source file is only read, never moved or modified.
    ///
    /// Runs off the main actor. On failure or cancellation, the partial copy is removed.
    func prepareImport(from source: URL, kickID: UUID, videoID: UUID) async throws -> PreparedVideoImport {
        guard source.isFileURL else { throw VideoStorageError.sourceNotAFileURL }
        guard fileSystem.itemExists(at: source), !fileSystem.isDirectory(at: source) else {
            throw VideoStorageError.sourceNotFound
        }
        guard let fileExtension = ManagedPath.videoFileExtension(for: source) else {
            throw VideoStorageError.unsupportedVideoType(fileExtension: source.pathExtension.lowercased())
        }

        let videoDirectoryPath = ManagedPath.videoDirectory(kickID: kickID, videoID: videoID)
        let relativeFilePath = ManagedPath.originalVideoPath(kickID: kickID, videoID: videoID, fileExtension: fileExtension)
        let videoDirectory = try url(for: videoDirectoryPath, in: .media)
        let destination = try url(for: relativeFilePath, in: .media)

        do {
            try fileSystem.createDirectory(at: videoDirectory)
        } catch {
            throw VideoStorageError.directoryCreationFailed(String(describing: error))
        }
        do {
            try fileSystem.copyItem(at: source, to: destination)
        } catch {
            discardDirectory(videoDirectoryPath)
            throw VideoStorageError.copyFailed(String(describing: error))
        }
        do {
            try Task.checkCancellation()
        } catch {
            discardDirectory(videoDirectoryPath)
            throw error
        }

        let metadata = await metadataReader.readMetadata(at: destination)

        var thumbnailPath: String? = ManagedPath.thumbnailPath(kickID: kickID, videoID: videoID)
        if let path = thumbnailPath, let thumbnailURL = try? url(for: path, in: .media) {
            let written = await thumbnailGenerator.generateThumbnail(for: destination, writingTo: thumbnailURL)
            if !written || fileSystem.fileSize(at: thumbnailURL) == nil {
                if fileSystem.itemExists(at: thumbnailURL) { try? fileSystem.removeItem(at: thumbnailURL) }
                thumbnailPath = nil
            }
        }

        return PreparedVideoImport(
            kickID: kickID,
            videoID: videoID,
            relativeFilePath: relativeFilePath,
            thumbnailRelativePath: thumbnailPath,
            byteCount: fileSystem.fileSize(at: destination),
            metadata: metadata,
            originalFilename: ManagedPath.displayFilename(from: source)
        )
    }

    /// Removes the files of an import whose database record was never saved.
    func discard(_ prepared: PreparedVideoImport) {
        discardDirectory(ManagedPath.videoDirectory(kickID: prepared.kickID, videoID: prepared.videoID))
        pruneEmptyAncestors(of: ManagedPath.videoDirectory(kickID: prepared.kickID, videoID: prepared.videoID), in: .media)
    }

    // MARK: Removal

    /// Removes the files in `request`. Missing files are reported, unsafe paths are
    /// refused, and empty parent folders inside the root are pruned. Never throws.
    func remove(_ request: MediaCleanupRequest) -> MediaCleanupOutcome {
        var outcome = MediaCleanupOutcome()
        let work: [(MediaArea, [String])] = [
            (.media, request.mediaRelativePaths),
            (.analysis, request.analysisRelativePaths),
        ]
        for (area, paths) in work {
            for path in paths {
                guard let target = try? url(for: path, in: area) else {
                    outcome.rejectedUnsafe.append(path)
                    continue
                }
                if !fileSystem.itemExists(at: target) {
                    outcome.alreadyMissing.append(path)
                } else {
                    do {
                        try fileSystem.removeItem(at: target)
                        outcome.removed.append(path)
                    } catch {
                        outcome.failed.append(MediaCleanupFailure(relativePath: path, area: area, reason: String(describing: error)))
                        continue
                    }
                }
                pruneEmptyAncestors(of: path, in: area)
            }
        }
        return outcome
    }

    /// `MediaCleanupHandling`: called by services only after a successful save.
    func cleanUp(_ request: MediaCleanupRequest) {
        _ = remove(request)
    }

    /// Removes `Media/<kickUUID>/` entirely (every video and thumbnail of one kick).
    func removeKickDirectory(kickID: UUID) -> MediaCleanupOutcome {
        let path = ManagedPath.kickDirectory(kickID: kickID)
        var outcome = MediaCleanupOutcome()
        guard let target = try? url(for: path, in: .media) else {
            outcome.rejectedUnsafe.append(path)
            return outcome
        }
        guard fileSystem.itemExists(at: target) else {
            outcome.alreadyMissing.append(path)
            return outcome
        }
        do {
            try fileSystem.removeItem(at: target)
            outcome.removed.append(path)
        } catch {
            outcome.failed.append(MediaCleanupFailure(relativePath: path, area: .media, reason: String(describing: error)))
        }
        return outcome
    }

    // MARK: Orphans

    /// Files under the managed roots that no record references.
    ///
    /// - A media file is referenced if its path, or any folder above it, is in
    ///   `referencedMediaPaths`.
    /// - An analysis file is referenced if its path, or any folder above it, is in
    ///   `referencedAnalysisPaths` (artifacts may be a whole folder).
    /// - Files younger than `minimumAge` are skipped so an import that has copied its
    ///   file but not yet saved its record is never swept.
    func orphanReport(
        referencedMediaPaths: Set<String>,
        referencedAnalysisPaths: Set<String>,
        minimumAge: TimeInterval,
        now: Date = .now
    ) -> OrphanReport {
        var report = OrphanReport()
        for area in MediaArea.allCases {
            let referenced = area == .media ? referencedMediaPaths : referencedAnalysisPaths
            for entry in fileSystem.regularFiles(under: locations.rootURL(for: area)) {
                if let modified = entry.modificationDate, now.timeIntervalSince(modified) < minimumAge { continue }
                let isReferenced = referenced.contains(entry.relativePath)
                    || ManagedPath.ancestors(of: entry.relativePath).contains(where: referenced.contains)
                guard !isReferenced else { continue }
                switch area {
                case .media: report.mediaPaths.append(entry.relativePath)
                case .analysis: report.analysisPaths.append(entry.relativePath)
                }
                report.totalBytes += entry.byteCount
            }
        }
        return report
    }

    /// Removes every orphan in `report` and prunes empty folders.
    func sweep(_ report: OrphanReport) -> MediaCleanupOutcome {
        remove(MediaCleanupRequest(mediaRelativePaths: report.mediaPaths, analysisRelativePaths: report.analysisPaths))
    }

    // MARK: Helpers

    private func discardDirectory(_ relativePath: String) {
        guard let target = try? url(for: relativePath, in: .media), fileSystem.itemExists(at: target) else { return }
        try? fileSystem.removeItem(at: target)
    }

    /// Removes empty folders above `relativePath`, stopping at the root.
    private func pruneEmptyAncestors(of relativePath: String, in area: MediaArea) {
        for ancestor in ManagedPath.ancestors(of: relativePath) {
            guard
                let folder = try? url(for: ancestor, in: area),
                fileSystem.isDirectory(at: folder),
                fileSystem.isDirectoryEmpty(at: folder)
            else { return }
            try? fileSystem.removeItem(at: folder)
        }
    }
}
