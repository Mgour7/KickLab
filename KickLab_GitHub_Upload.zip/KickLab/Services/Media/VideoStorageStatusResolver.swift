import Foundation

/// Pure rule for a video's `VideoStorageStatus`.
///
/// - A managed copy that exists → `.local`.
/// - Deliberately offloaded media stays `.offloaded` while no local copy exists.
/// - Otherwise a Photos-library reference → `.photosLibrary` (KickLab never deletes it).
/// - Otherwise → `.missing`. A missing file is a status, never a crash.
enum VideoStorageStatusResolver {
    static func resolve(
        current: VideoStorageStatus,
        hasManagedPath: Bool,
        managedFileExists: Bool,
        hasPhotosIdentifier: Bool
    ) -> VideoStorageStatus {
        if hasManagedPath && managedFileExists { return .local }
        if current == .offloaded { return .offloaded }
        if hasPhotosIdentifier { return .photosLibrary }
        return .missing
    }
}
