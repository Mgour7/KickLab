import Foundation

/// One regular file found under a managed root.
struct MediaFileEntry: Equatable, Sendable {
    /// Relative to the root that was scanned, "/"-separated.
    let relativePath: String
    let byteCount: Int64
    let modificationDate: Date?
}

/// The file operations KickLab media storage needs. A protocol so storage logic
/// can be tested against a temporary directory or a fake.
protocol MediaFileSystem: Sendable {
    func itemExists(at url: URL) -> Bool
    func isDirectory(at url: URL) -> Bool
    /// Creates the directory and any missing parents.
    func createDirectory(at url: URL) throws
    func copyItem(at source: URL, to destination: URL) throws
    func removeItem(at url: URL) throws
    /// Size of a regular file, or nil if missing or not a regular file.
    func fileSize(at url: URL) -> Int64?
    func isDirectoryEmpty(at url: URL) -> Bool
    /// Every regular file under `root`, recursively. Symbolic links are skipped and
    /// never followed. A missing root yields an empty list.
    func regularFiles(under root: URL) -> [MediaFileEntry]
}

/// `MediaFileSystem` backed by `FileManager`.
struct LocalMediaFileSystem: MediaFileSystem {
    init() {}

    private var fileManager: FileManager { FileManager.default }

    func itemExists(at url: URL) -> Bool {
        fileManager.fileExists(atPath: url.path)
    }

    func isDirectory(at url: URL) -> Bool {
        var isDirectory: ObjCBool = false
        return fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) && isDirectory.boolValue
    }

    func createDirectory(at url: URL) throws {
        try fileManager.createDirectory(at: url, withIntermediateDirectories: true)
    }

    func copyItem(at source: URL, to destination: URL) throws {
        try fileManager.copyItem(at: source, to: destination)
    }

    func removeItem(at url: URL) throws {
        try fileManager.removeItem(at: url)
    }

    func fileSize(at url: URL) -> Int64? {
        guard
            let attributes = try? fileManager.attributesOfItem(atPath: url.path),
            (attributes[.type] as? FileAttributeType) == .typeRegular
        else { return nil }
        return Self.size(from: attributes)
    }

    func isDirectoryEmpty(at url: URL) -> Bool {
        (try? fileManager.contentsOfDirectory(atPath: url.path))?.isEmpty ?? false
    }

    func regularFiles(under root: URL) -> [MediaFileEntry] {
        var entries: [MediaFileEntry] = []
        walk(absolutePath: root.path, relativePath: "", into: &entries)
        return entries
    }

    // Builds paths from the root string plus component names, so results never
    // depend on how the OS spells resolved paths (e.g. /var vs /private/var).
    private func walk(absolutePath: String, relativePath: String, into entries: inout [MediaFileEntry]) {
        guard let names = try? fileManager.contentsOfDirectory(atPath: absolutePath) else { return }
        for name in names.sorted() {
            let childAbsolute = absolutePath.hasSuffix("/") ? absolutePath + name : absolutePath + "/" + name
            let childRelative = relativePath.isEmpty ? name : relativePath + "/" + name
            guard
                let attributes = try? fileManager.attributesOfItem(atPath: childAbsolute),
                let type = attributes[.type] as? FileAttributeType
            else { continue }
            if type == .typeDirectory {
                walk(absolutePath: childAbsolute, relativePath: childRelative, into: &entries)
            } else if type == .typeRegular {
                entries.append(MediaFileEntry(
                    relativePath: childRelative,
                    byteCount: Self.size(from: attributes) ?? 0,
                    modificationDate: attributes[.modificationDate] as? Date
                ))
            }
            // Symbolic links and special files are skipped, never followed.
        }
    }

    private static func size(from attributes: [FileAttributeKey: Any]) -> Int64? {
        let value = attributes[.size]
        if let number = value as? NSNumber { return number.int64Value }
        if let int = value as? Int { return Int64(int) }
        if let int64 = value as? Int64 { return int64 }
        if let uint64 = value as? UInt64 { return Int64(clamping: uint64) }
        return nil
    }
}
