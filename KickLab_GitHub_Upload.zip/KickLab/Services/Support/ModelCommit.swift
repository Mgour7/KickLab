import Foundation
import SwiftData

/// How a service persists its changes. Injectable so tests can simulate a failed save.
typealias ModelSaveHandler = (ModelContext) throws -> Void

/// The single save policy used by every KickLab service.
///
/// Save policy (V1):
/// - Every public service method that changes data is one atomic action: it
///   validates everything first, mutates, then calls `commit` exactly once before
///   returning. Callers never call `save()` themselves.
/// - Read-only methods (audits, plans, summaries) never save.
/// - If the save fails, the context is rolled back, so the action leaves no
///   pending half-applied changes, and the service throws `persistenceFailed`.
///   Follow-up work (media cleanup) runs only after a successful save.
///
/// Because of the rollback, services assume their context holds no unrelated
/// pending edits — true while services are the only writers (invariant G3).
enum ModelCommit {
    static func defaultSave(_ context: ModelContext) throws {
        try context.save()
    }

    /// Saves, or rolls back and throws `CommitFailure`.
    static func commit(_ context: ModelContext, using save: ModelSaveHandler) throws {
        do {
            try save(context)
        } catch {
            context.rollback()
            throw CommitFailure(underlyingDescription: String(describing: error))
        }
    }
}

/// A failed save, already rolled back. Each service maps it to its own `persistenceFailed` case.
struct CommitFailure: Error, Equatable, Sendable {
    let underlyingDescription: String
}

extension ModelContext {
    /// True when `model` is managed by this exact context.
    func manages(_ model: any PersistentModel) -> Bool {
        model.modelContext === self
    }
}
