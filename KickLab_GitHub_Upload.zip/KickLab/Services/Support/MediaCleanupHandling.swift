import Foundation

/// Files to remove after their database records were deleted and saved.
///
/// Media paths (videos, thumbnails) are relative to `Application Support/KickLab/Media/`;
/// analysis paths (artifact files or folders) are relative to
/// `Application Support/KickLab/Analysis/`. Photos-library identifiers are never
/// included: KickLab does not delete anything from the person's Photos library.
struct MediaCleanupRequest: Equatable, Sendable {
    /// De-duplicated, sorted, empty strings removed.
    let mediaRelativePaths: [String]
    /// De-duplicated, sorted, empty strings removed.
    let analysisRelativePaths: [String]

    init(mediaRelativePaths: [String], analysisRelativePaths: [String] = []) {
        self.mediaRelativePaths = Self.normalized(mediaRelativePaths)
        self.analysisRelativePaths = Self.normalized(analysisRelativePaths)
    }

    /// Step 5 compatibility: media paths only.
    init(relativePaths: [String]) {
        self.init(mediaRelativePaths: relativePaths)
    }

    static let empty = MediaCleanupRequest(mediaRelativePaths: [])

    /// Every path in the request (both areas), sorted. For display and logging.
    var relativePaths: [String] {
        (mediaRelativePaths + analysisRelativePaths).sorted()
    }

    var isEmpty: Bool { mediaRelativePaths.isEmpty && analysisRelativePaths.isEmpty }

    func merged(with other: MediaCleanupRequest) -> MediaCleanupRequest {
        MediaCleanupRequest(
            mediaRelativePaths: mediaRelativePaths + other.mediaRelativePaths,
            analysisRelativePaths: analysisRelativePaths + other.analysisRelativePaths
        )
    }

    private static func normalized(_ paths: [String]) -> [String] {
        Array(Set(paths.filter { !$0.isEmpty })).sorted()
    }
}

/// Removes media files once their records are gone from the database.
///
/// Services call this **only after** `ModelContext.save()` succeeds. If the save
/// fails, nothing is removed. Implementations must not throw: a file that cannot
/// be removed is left for the orphan sweep, because the database is the source of
/// truth and its deletion has already happened.
///
/// Production implementation: `ManagedMediaStore` (wired in `AppServices`).
protocol MediaCleanupHandling {
    func cleanUp(_ request: MediaCleanupRequest)
}

/// Does nothing. For tests and previews that must not touch the file system.
struct NoOpMediaCleanup: MediaCleanupHandling {
    func cleanUp(_ request: MediaCleanupRequest) {}
}
