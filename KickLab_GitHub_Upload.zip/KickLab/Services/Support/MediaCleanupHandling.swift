import Foundation

/// Files to remove after their database records were deleted and saved.
///
/// Paths are relative to the app's managed media root
/// (`Application Support/KickLab/Media/`). Photos-library identifiers are never
/// included: KickLab does not delete anything from the person's Photos library.
struct MediaCleanupRequest: Equatable, Sendable {
    /// Video files, thumbnails and analysis artifact paths, de-duplicated and sorted.
    let relativePaths: [String]

    init(relativePaths: [String]) {
        self.relativePaths = Array(Set(relativePaths.filter { !$0.isEmpty })).sorted()
    }

    static let empty = MediaCleanupRequest(relativePaths: [])

    var isEmpty: Bool { relativePaths.isEmpty }

    func merged(with other: MediaCleanupRequest) -> MediaCleanupRequest {
        MediaCleanupRequest(relativePaths: relativePaths + other.relativePaths)
    }
}

/// Removes media files once their records are gone from the database.
///
/// Services call this **only after** `ModelContext.save()` succeeds. If the save
/// fails, nothing is removed. Implementations must not throw: a file that cannot
/// be removed is left for the launch-time orphan sweep (Step 6), because the
/// database is the source of truth and its deletion has already happened.
protocol MediaCleanupHandling {
    func cleanUp(_ request: MediaCleanupRequest)
}

/// Step 5 placeholder. `VideoStorageService` replaces it in Step 6.
struct NoOpMediaCleanup: MediaCleanupHandling {
    func cleanUp(_ request: MediaCleanupRequest) {}
}
