import Foundation
import SwiftData

/// Manages athletes: creation, profile edits, archive/restore, deliberate permanent
/// deletion and history reassignment.
///
/// - A1  Archive/restore only flip `isArchived`; no history is touched.
/// - A2  Permanent deletion requires a fresh `AthleteDeletionPlan` plus an explicit
///       typed confirmation. It is a separate method that profile editing never calls.
/// - A3  `reassignHistory(from:to:)` moves sessions and kicks together and keeps
///       `athleteID` synchronized.
/// - A4  `ensureAtLeastOneAthlete` guarantees one active athlete without duplicating it.
///
/// Save policy: see `ModelCommit`. Every mutating method saves before returning.
///
/// Permanent deletion runs synchronously on the service's context in V1. The
/// plan/confirm/delete API is designed so the body can later move to a background
/// `ModelActor` that deletes in batches without changing callers.
struct AthleteService {
    let context: ModelContext
    let mediaCleanup: any MediaCleanupHandling
    let saveHandler: ModelSaveHandler

    init(
        context: ModelContext,
        mediaCleanup: any MediaCleanupHandling = NoOpMediaCleanup(),
        saveHandler: @escaping ModelSaveHandler = ModelCommit.defaultSave
    ) {
        self.context = context
        self.mediaCleanup = mediaCleanup
        self.saveHandler = saveHandler
    }

    // MARK: Create

    @discardableResult
    func createAthlete(_ profile: AthleteProfile) throws -> Athlete {
        let issues = AthleteProfileValidator.validate(profile)
        guard issues.isEmpty else { throw AthleteServiceError.invalidProfile(issues) }

        let athlete = Athlete()
        context.insert(athlete)
        apply(profile.normalized, to: athlete)
        try commit()
        return athlete
    }

    /// Returns the oldest active (non-archived) athlete, creating one from `profile`
    /// only when none exists. Safe to call on every launch: it never creates a
    /// duplicate while an active athlete exists. Saves only when it creates.
    @discardableResult
    func ensureAtLeastOneAthlete(defaultProfile profile: AthleteProfile = .firstLaunchDefault) throws -> Athlete {
        if let existing = try activeAthletes().first {
            return existing
        }
        return try createAthlete(profile)
    }

    /// Active athletes, oldest first. Read-only.
    func activeAthletes() throws -> [Athlete] {
        try context.fetch(FetchDescriptor<Athlete>())
            .filter { !$0.isArchived }
            .sorted { ($0.createdAt, $0.id.uuidString) < ($1.createdAt, $1.id.uuidString) }
    }

    // MARK: Profile

    /// Replaces the athlete's profile fields and updates `updatedAt`. Never deletes anything.
    func updateProfile(_ athlete: Athlete, with profile: AthleteProfile) throws {
        try requireManaged(athlete)
        let issues = AthleteProfileValidator.validate(profile)
        guard issues.isEmpty else { throw AthleteServiceError.invalidProfile(issues) }
        apply(profile.normalized, to: athlete)
        try commit()
    }

    /// The athlete's current profile, for editors.
    func profile(of athlete: Athlete) -> AthleteProfile {
        AthleteProfile(
            firstName: athlete.firstName,
            lastName: athlete.lastName,
            dateOfBirth: athlete.dateOfBirth,
            graduationYear: athlete.graduationYear,
            kickingFoot: athlete.kickingFoot,
            currentPlayingLevel: athlete.currentPlayingLevel,
            heightInches: athlete.heightInches,
            weightPounds: athlete.weightPounds,
            schoolTeam: athlete.schoolTeam,
            jerseyNumber: athlete.jerseyNumber
        )
    }

    // MARK: Archive / restore

    /// Soft delete. Idempotent; no sessions, kicks or media are touched.
    func archive(_ athlete: Athlete) throws {
        try setArchived(true, athlete)
    }

    /// Reverses `archive`. Idempotent.
    func restore(_ athlete: Athlete) throws {
        try setArchived(false, athlete)
    }

    // MARK: Permanent deletion

    /// Read-only. Everything a permanent deletion would remove, plus a fingerprint
    /// used to reject the plan if anything changes before confirmation.
    func deletionPlan(for athlete: Athlete, generatedAt: Date = .now) throws -> AthleteDeletionPlan {
        try requireManaged(athlete)
        return Self.makePlan(for: athlete, generatedAt: generatedAt)
    }

    /// Permanently deletes the planned athlete, their sessions and kicks (with the
    /// kicks' videos, analyses and results via cascade), then cleans up media.
    ///
    /// Steps: confirm → re-plan and compare fingerprints → stage kick deletions
    /// (same semantics as `KickService.deleteKick`) → delete sessions → delete
    /// athlete → save once → media cleanup.
    ///
    /// Callers should run `ensureAtLeastOneAthlete` afterwards if this was the last
    /// active athlete.
    @discardableResult
    func permanentlyDelete(
        using plan: AthleteDeletionPlan,
        confirmation: AthleteDeletionConfirmation
    ) throws -> AthleteDeletionResult {
        guard plan.isConfirmed(by: confirmation) else {
            throw AthleteServiceError.confirmationMismatch
        }
        guard let athlete = try context.fetch(FetchDescriptor<Athlete>()).first(where: { $0.id == plan.athleteID }) else {
            throw AthleteServiceError.athleteNotFound(athleteID: plan.athleteID)
        }
        guard plan.matches(Self.makePlan(for: athlete, generatedAt: .now)) else {
            throw AthleteServiceError.stalePlan(athleteID: plan.athleteID)
        }

        let kickService = KickService(context: context, mediaCleanup: mediaCleanup, saveHandler: saveHandler)
        var cleanup = MediaCleanupRequest.empty
        for kick in athlete.kicks ?? [] {
            cleanup = cleanup.merged(with: kickService.stageDeletion(of: kick))
        }
        for session in athlete.kickingSessions ?? [] {
            context.delete(session)
        }
        context.delete(athlete)
        try commit()

        if !cleanup.isEmpty {
            mediaCleanup.cleanUp(cleanup)
        }
        return AthleteDeletionResult(
            athleteID: plan.athleteID,
            deletedSessionCount: plan.sessionCount,
            deletedKickCount: plan.kickCount,
            deletedVideoCount: plan.videoCount,
            deletedAnalysisCount: plan.analysisCount,
            mediaCleanup: cleanup
        )
    }

    // MARK: History reassignment

    /// Moves every session and kick from `source` to `destination`, updating every
    /// `Kick.athleteID`. Outcomes, videos and analyses are untouched.
    ///
    /// Rejected when source and destination are the same athlete, or when the
    /// source's sessions contain kicks owned by a third athlete (moving them would
    /// break session/kick consistency).
    func reassignHistory(from source: Athlete, to destination: Athlete) throws {
        try requireManaged(source)
        try requireManaged(destination)
        guard source.id != destination.id else {
            throw AthleteServiceError.sameSourceAndDestination
        }

        let sessions = source.kickingSessions ?? []
        let kicks = source.kicks ?? []
        let foreignKickIDs = sessions
            .flatMap { $0.kicks ?? [] }
            .filter { $0.athlete?.id != source.id }
            .map(\.id)
        guard foreignKickIDs.isEmpty else {
            throw AthleteServiceError.inconsistentHistory(kickIDs: foreignKickIDs.sorted { $0.uuidString < $1.uuidString })
        }

        for session in sessions {
            session.athlete = destination
            session.updatedAt = .now
        }
        for kick in kicks {
            kick.assignAthlete(destination)
        }
        source.updatedAt = .now
        destination.updatedAt = .now
        try commit()
    }

    // MARK: Helpers

    static func makePlan(for athlete: Athlete, generatedAt: Date) -> AthleteDeletionPlan {
        let kicks = athlete.kicks ?? []
        let videos = kicks.flatMap { $0.videos ?? [] }
        let analyses = kicks.flatMap { $0.analyses ?? [] }
        let name = athlete.fullName
        return AthleteDeletionPlan(
            athleteID: athlete.id,
            athleteDisplayName: name,
            sessionIDs: (athlete.kickingSessions ?? []).map(\.id),
            kickIDs: kicks.map(\.id),
            videoIDs: videos.map(\.id),
            analysisIDs: analyses.map(\.id),
            videoFileSizes: videos.map(\.fileSizeBytes),
            generatedAt: generatedAt
        )
    }

    private func apply(_ profile: AthleteProfile, to athlete: Athlete) {
        athlete.firstName = profile.firstName
        athlete.lastName = profile.lastName
        athlete.dateOfBirth = profile.dateOfBirth
        athlete.graduationYear = profile.graduationYear
        athlete.kickingFoot = profile.kickingFoot
        athlete.currentPlayingLevel = profile.currentPlayingLevel
        athlete.heightInches = profile.heightInches
        athlete.weightPounds = profile.weightPounds
        athlete.schoolTeam = profile.schoolTeam
        athlete.jerseyNumber = profile.jerseyNumber
        athlete.updatedAt = .now
    }

    private func setArchived(_ archived: Bool, _ athlete: Athlete) throws {
        try requireManaged(athlete)
        guard athlete.isArchived != archived else { return }
        athlete.isArchived = archived
        athlete.updatedAt = .now
        try commit()
    }

    private func requireManaged(_ model: any PersistentModel) throws {
        guard context.manages(model) else { throw AthleteServiceError.notInServiceContext }
    }

    private func commit() throws {
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw AthleteServiceError.persistenceFailed(failure.underlyingDescription)
        }
    }
}
