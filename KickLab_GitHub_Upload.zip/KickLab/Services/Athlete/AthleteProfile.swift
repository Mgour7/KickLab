import Foundation

/// The editable athlete profile. Passed whole to `AthleteService.createAthlete(_:)`
/// and `AthleteService.updateProfile(_:with:)`.
struct AthleteProfile: Equatable, Sendable {
    var firstName: String
    var lastName: String
    var dateOfBirth: Date?
    var graduationYear: Int?
    var kickingFoot: KickingFoot
    var currentPlayingLevel: PlayingLevel
    /// Inches.
    var heightInches: Double?
    /// Pounds.
    var weightPounds: Double?
    var schoolTeam: String?
    var jerseyNumber: String?
    // Step 12F (schema V2): all optional.
    var nickname: String?
    var birthYear: Int?
    var primaryRole: AthleteRole?
    var experienceLevel: ExperienceLevel?
    var goals: String?
    var preferredBallType: FootballType?
    /// JPEG data for the optional profile photo.
    var photoData: Data?

    init(
        firstName: String,
        lastName: String = "",
        dateOfBirth: Date? = nil,
        graduationYear: Int? = nil,
        kickingFoot: KickingFoot = .right,
        currentPlayingLevel: PlayingLevel = .highSchool,
        heightInches: Double? = nil,
        weightPounds: Double? = nil,
        schoolTeam: String? = nil,
        jerseyNumber: String? = nil
    ) {
        self.firstName = firstName
        self.lastName = lastName
        self.dateOfBirth = dateOfBirth
        self.graduationYear = graduationYear
        self.kickingFoot = kickingFoot
        self.currentPlayingLevel = currentPlayingLevel
        self.heightInches = heightInches
        self.weightPounds = weightPounds
        self.schoolTeam = schoolTeam
        self.jerseyNumber = jerseyNumber
    }

    /// The profile created on first launch, before the person edits it.
    static let firstLaunchDefault = AthleteProfile(firstName: "Kicker")

    /// Trimmed copy: whitespace-only optional text becomes nil.
    var normalized: AthleteProfile {
        var copy = self
        copy.firstName = firstName.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.lastName = lastName.trimmingCharacters(in: .whitespacesAndNewlines)
        copy.schoolTeam = schoolTeam.normalizedOptionalText
        copy.jerseyNumber = jerseyNumber.normalizedOptionalText
        copy.nickname = nickname.normalizedOptionalText
        copy.goals = goals.normalizedOptionalText
        return copy
    }
}

enum AthleteProfileField: String, Sendable {
    case name, dateOfBirth, graduationYear, heightInches, weightPounds, jerseyNumber, birthYear, photo, goals
}

enum AthleteProfileIssue: Equatable, Sendable {
    /// First and last name are both empty.
    case missingName
    case dateOfBirthInFuture
    case nonFiniteValue(AthleteProfileField)
    case valueOutOfRange(AthleteProfileField, value: Double)
    case jerseyNumberTooLong
}

/// Plausibility bounds for profile values. Not eligibility rules.
enum AthleteProfileLimits {
    static let graduationYear: ClosedRange<Int> = 1950...2100
    static let heightInches: ClosedRange<Double> = 24...108
    static let weightPounds: ClosedRange<Double> = 40...500
    static let jerseyNumberMaxLength = 4
    /// Step 12F.
    static let birthYear: ClosedRange<Int> = 1900...2100
    static let goalsMaxLength = 2_000
    /// Profile photos are downscaled before saving; anything larger is refused.
    static let photoMaxBytes = 2_000_000
}

enum AthleteProfileValidator {
    static func validate(_ profile: AthleteProfile, now: Date = .now) -> [AthleteProfileIssue] {
        let p = profile.normalized
        var issues: [AthleteProfileIssue] = []

        if p.firstName.isEmpty && p.lastName.isEmpty {
            issues.append(.missingName)
        }
        if let dob = p.dateOfBirth, dob > now {
            issues.append(.dateOfBirthInFuture)
        }
        if let year = p.graduationYear, !AthleteProfileLimits.graduationYear.contains(year) {
            issues.append(.valueOutOfRange(.graduationYear, value: Double(year)))
        }
        check(p.heightInches, .heightInches, AthleteProfileLimits.heightInches, into: &issues)
        check(p.weightPounds, .weightPounds, AthleteProfileLimits.weightPounds, into: &issues)
        if let jersey = p.jerseyNumber, jersey.count > AthleteProfileLimits.jerseyNumberMaxLength {
            issues.append(.jerseyNumberTooLong)
        }
        if let year = p.birthYear {
            let current = Calendar(identifier: .gregorian).component(.year, from: now)
            if !AthleteProfileLimits.birthYear.contains(year) || year > current {
                issues.append(.valueOutOfRange(.birthYear, value: Double(year)))
            }
        }
        if let goals = p.goals, goals.count > AthleteProfileLimits.goalsMaxLength {
            issues.append(.valueOutOfRange(.goals, value: Double(goals.count)))
        }
        if let photo = p.photoData, photo.count > AthleteProfileLimits.photoMaxBytes {
            issues.append(.valueOutOfRange(.photo, value: Double(photo.count)))
        }
        return issues
    }

    private static func check(
        _ value: Double?,
        _ field: AthleteProfileField,
        _ range: ClosedRange<Double>,
        into issues: inout [AthleteProfileIssue]
    ) {
        guard let value else { return }
        if !value.isFinite {
            issues.append(.nonFiniteValue(field))
        } else if !range.contains(value) {
            issues.append(.valueOutOfRange(field, value: value))
        }
    }
}

extension AthleteProfile {
    /// Step 12F: the same profile with the V2 fields set.
    func withV2Fields(nickname: String?, birthYear: Int?, primaryRole: AthleteRole?, experienceLevel: ExperienceLevel?,
                      goals: String?, preferredBallType: FootballType?, photoData: Data?) -> AthleteProfile {
        var p = self
        p.nickname = nickname
        p.birthYear = birthYear
        p.primaryRole = primaryRole
        p.experienceLevel = experienceLevel
        p.goals = goals
        p.preferredBallType = preferredBallType
        p.photoData = photoData
        return p
    }
}
