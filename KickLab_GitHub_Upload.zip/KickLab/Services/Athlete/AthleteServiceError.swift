import Foundation

/// Errors thrown by `AthleteService`.
enum AthleteServiceError: Error, Equatable, Sendable, LocalizedError {
    case invalidProfile([AthleteProfileIssue])
    /// The athlete in the deletion plan no longer exists.
    case athleteNotFound(athleteID: UUID)
    /// The athlete's history changed after the deletion plan was generated.
    /// Generate and confirm a new plan.
    case stalePlan(athleteID: UUID)
    /// The typed confirmation did not match the plan's confirmation phrase.
    case confirmationMismatch
    case sameSourceAndDestination
    /// The source athlete's sessions contain kicks owned by another athlete,
    /// so moving them would break session/kick consistency. Repair first.
    case inconsistentHistory(kickIDs: [UUID])
    case notInServiceContext
    /// `ModelContext.save()` failed. The context was rolled back; nothing was persisted.
    case persistenceFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidProfile:
            "Some profile details are invalid."
        case .athleteNotFound:
            "That athlete no longer exists."
        case .stalePlan:
            "This athlete's history changed. Review the deletion again."
        case .confirmationMismatch:
            "The confirmation text didn't match."
        case .sameSourceAndDestination:
            "Choose a different athlete to move the history to."
        case .inconsistentHistory:
            "Some sessions contain another athlete's kicks. Fix them before moving this history."
        case .notInServiceContext:
            "The record isn't available in this data context."
        case .persistenceFailed:
            "KickLab couldn't save the change."
        }
    }
}
