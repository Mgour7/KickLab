import Foundation

/// A deterministic fingerprint of everything a permanent athlete deletion would remove.
///
/// Any added, removed or moved session, kick, video or analysis — or a change in
/// recorded media size — changes the fingerprint, so a plan shown to the person
/// becomes stale and is rejected.
struct AthleteHistoryFingerprint: Equatable, Sendable {
    let sessionCount: Int
    let kickCount: Int
    let videoCount: Int
    let analysisCount: Int
    let mediaBytes: Int64
    /// FNV-1a 64-bit digest over the sorted IDs of every record in scope.
    let digest: UInt64

    init(
        sessionIDs: [UUID],
        kickIDs: [UUID],
        videoIDs: [UUID],
        analysisIDs: [UUID],
        mediaBytes: Int64
    ) {
        sessionCount = sessionIDs.count
        kickCount = kickIDs.count
        videoCount = videoIDs.count
        analysisCount = analysisIDs.count
        self.mediaBytes = mediaBytes

        var hasher = FNV1a64()
        for (tag, ids) in [("s", sessionIDs), ("k", kickIDs), ("v", videoIDs), ("a", analysisIDs)] {
            hasher.combine(tag)
            for id in ids.map(\.uuidString).sorted() {
                hasher.combine(id)
            }
        }
        hasher.combine(String(mediaBytes))
        digest = hasher.value
    }
}

/// Stable (not per-process seeded) 64-bit FNV-1a, so fingerprints are reproducible.
private struct FNV1a64 {
    private(set) var value: UInt64 = 0xcbf2_9ce4_8422_2325

    mutating func combine(_ string: String) {
        for byte in string.utf8 {
            value ^= UInt64(byte)
            value = value &* 0x0000_0100_0000_01b3
        }
        // Separator so ["ab","c"] and ["a","bc"] differ.
        value ^= 0xff
        value = value &* 0x0000_0100_0000_01b3
    }
}

/// What permanently deleting an athlete would remove. Shown to the person before
/// they confirm, then passed back to `AthleteService.permanentlyDelete(using:confirmation:)`.
struct AthleteDeletionPlan: Equatable, Sendable {
    let athleteID: UUID
    let athleteDisplayName: String
    let sessionCount: Int
    let kickCount: Int
    let videoCount: Int
    let analysisCount: Int
    /// Sum of recorded `VideoAsset.fileSizeBytes`. Videos without a recorded size count as 0.
    let estimatedMediaBytes: Int64
    let generatedAt: Date
    /// Used to detect a stale plan.
    let fingerprint: AthleteHistoryFingerprint

    init(
        athleteID: UUID,
        athleteDisplayName: String,
        sessionIDs: [UUID],
        kickIDs: [UUID],
        videoIDs: [UUID],
        analysisIDs: [UUID],
        videoFileSizes: [Int64?],
        generatedAt: Date = .now
    ) {
        let bytes = videoFileSizes.reduce(Int64(0)) { $0 + max(0, $1 ?? 0) }
        self.athleteID = athleteID
        self.athleteDisplayName = athleteDisplayName
        self.sessionCount = sessionIDs.count
        self.kickCount = kickIDs.count
        self.videoCount = videoIDs.count
        self.analysisCount = analysisIDs.count
        self.estimatedMediaBytes = bytes
        self.generatedAt = generatedAt
        self.fingerprint = AthleteHistoryFingerprint(
            sessionIDs: sessionIDs,
            kickIDs: kickIDs,
            videoIDs: videoIDs,
            analysisIDs: analysisIDs,
            mediaBytes: bytes
        )
    }

    /// The exact text the person must type to confirm. The athlete's name, or
    /// "DELETE" when the athlete has no name.
    var confirmationPhrase: String {
        let name = athleteDisplayName.trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "DELETE" : name
    }

    /// True when the typed confirmation matches `confirmationPhrase` exactly (after trimming).
    func isConfirmed(by confirmation: AthleteDeletionConfirmation) -> Bool {
        confirmation.typedText.trimmingCharacters(in: .whitespacesAndNewlines) == confirmationPhrase
    }

    /// True when `current` describes the same athlete and the same records.
    /// `generatedAt` is ignored.
    func matches(_ current: AthleteDeletionPlan) -> Bool {
        athleteID == current.athleteID && fingerprint == current.fingerprint
    }
}

/// The person's explicit confirmation for a permanent deletion.
struct AthleteDeletionConfirmation: Equatable, Sendable {
    let typedText: String

    init(typedText: String) {
        self.typedText = typedText
    }
}

/// What a permanent deletion removed.
struct AthleteDeletionResult: Equatable, Sendable {
    let athleteID: UUID
    let deletedSessionCount: Int
    let deletedKickCount: Int
    let deletedVideoCount: Int
    let deletedAnalysisCount: Int
    /// Handed to `MediaCleanupHandling` after the save succeeded.
    let mediaCleanup: MediaCleanupRequest
}
