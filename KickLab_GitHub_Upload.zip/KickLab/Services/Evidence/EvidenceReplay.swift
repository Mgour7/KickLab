import Foundation

/// Build 15: replays an evidence bundle through the app's own pure analysis code — the same
/// functions the device ran after pose extraction and Core ML:
/// - football stage: `FootballTrackAnalyzer.analyze(raw:)` on the recorded detections;
/// - pose → phases → fusion → metrics: `DiagnosticsReplay.run` (the production detectors,
///   fusion and biomechanics) on the recorded pose, with the replayed football track;
/// - gates: `AnalysisGates.make`.
/// Nothing here re-implements a decision. Vision and Core ML outputs are inputs, not replayed.
struct EvidenceReplayReport: Codable, Equatable, Sendable {
    enum FootballStage: String, Codable, Sendable {
        /// Re-run from the recorded raw detections.
        case replayed
        /// The bundle has no raw detections (before build 15): the recorded track was reused.
        case recordedTrackReused
        case absent
    }
    struct Difference: Codable, Equatable, Sendable {
        var field: String
        var recorded: String
        var replayed: String
    }

    var bundleEngineVersion: String?
    var replayEngineVersion: String
    var footballStage: FootballStage
    var recorded: EvidenceOutcome?
    var replayed: EvidenceOutcome?
    var differences: [Difference]
    var notes: [String]

    var matchesRecording: Bool { replayed != nil && differences.isEmpty }

    var text: String {
        var lines = ["KickLab evidence replay",
                     "bundle engine \(bundleEngineVersion ?? "—") · replay engine \(replayEngineVersion) · football stage \(footballStage.rawValue)"]
        lines += notes.map { "note: \($0)" }
        if replayed == nil { lines.append("RESULT: not replayable") }
        else if differences.isEmpty { lines.append("RESULT: identical to the recorded outcome") }
        else {
            lines.append("RESULT: \(differences.count) difference(s)")
            lines += differences.map { "  \($0.field): recorded \($0.recorded) → replayed \($0.replayed)" }
        }
        if let r = replayed {
            lines.append("replayed: contact \(r.contactOutcome) \(r.contactTime.map { String($0) } ?? "—") [\(r.contactEarliest.map { String($0) } ?? "—")–\(r.contactLatest.map { String($0) } ?? "—")] · plant \(r.plantUsed.map { String($0) } ?? "—") · ball \(r.ballLastStationary.map { String($0) } ?? "—")→\(r.ballFirstMovement.map { String($0) } ?? "—") · stops at \(r.stopGate ?? "— (completed)")")
        }
        return lines.joined(separator: "\n")
    }
}

enum EvidenceReplay {
    static func run(_ contents: EvidenceContents) -> EvidenceReplayReport {
        let engine = PoseVideoAnalysisService.version
        guard let artifacts = contents.artifacts else {
            return EvidenceReplayReport(bundleEngineVersion: contents.manifest.engineVersion, replayEngineVersion: engine, footballStage: .absent,
                                        recorded: contents.recorded, replayed: nil, differences: [],
                                        notes: ["The bundle has no analysis files, so there is nothing to replay."])
        }
        var notes: [String] = []
        var input = AnalysisDiagnosticsInput(bundle: artifacts)
        var stage = EvidenceReplayReport.FootballStage.absent
        if let stored = artifacts.phases.football {
            if let raw = stored.raw, let detector = stored.detector {
                var track = FootballTrackAnalyzer.analyze(raw: raw, detector: detector)
                track.runtimeSeconds = stored.runtimeSeconds
                input.football = track
                stage = .replayed
            } else {
                stage = .recordedTrackReused
                notes.append("No raw football detections in this bundle (made before build 15): the recorded football track is reused, so football selection and departure are not re-decided.")
            }
        }
        if artifacts.manifest.assistance?.isEmpty == false {
            notes.append("User-assisted analysis: replayed with the user's recorded choices, as on the device.")
        }
        guard let sequence = input.sequence, let out = DiagnosticsReplay.run(input, kickingFoot: input.context?.kickingFoot) else {
            notes.append("No kicker was selected in the recorded pose, so phases can't be replayed.")
            return EvidenceReplayReport(bundleEngineVersion: artifacts.manifest.engineVersion, replayEngineVersion: engine, footballStage: stage,
                                        recorded: contents.recorded ?? EvidenceBundle.recordedOutcome(artifacts), replayed: nil,
                                        differences: [], notes: notes)
        }
        let foot = input.context?.kickingFoot ?? out.signals.kickingFoot
        let gates = AnalysisGates.make(sequence: sequence, tracking: input.tracking, perspective: out.perspective, legIdentity: out.legIdentity,
                                       timeline: out.timeline, kickingFoot: foot, phases: out.phases, measurements: out.measurements,
                                       scoredCategoryCount: out.scoredCategoryCount, completion: out.completion)
        let replayed = EvidenceOutcome.make(phases: out.phases, football: input.football, gates: gates,
                                            measurements: out.measurements ?? [], engineVersion: artifacts.manifest.engineVersion)
        let recorded = contents.recorded ?? EvidenceBundle.recordedOutcome(artifacts)
        let diffs = recorded.differences(from: replayed).map { EvidenceReplayReport.Difference(field: $0.field, recorded: $0.recorded, replayed: $0.replayed) }
        if !artifacts.manifest.engineVersion.hasPrefix(engine) {
            notes.append("Recorded by \(artifacts.manifest.engineVersion); replayed by \(engine): differences may come from the engine change.")
        }
        return EvidenceReplayReport(bundleEngineVersion: artifacts.manifest.engineVersion, replayEngineVersion: engine, footballStage: stage,
                                    recorded: recorded, replayed: replayed, differences: diffs, notes: notes)
    }

    /// Baseline regression: a previous replay report (JSON) against this one.
    static func compare(baseline: EvidenceReplayReport, current: EvidenceReplayReport) -> [EvidenceReplayReport.Difference] {
        guard let a = baseline.replayed, let b = current.replayed else {
            return [EvidenceReplayReport.Difference(field: "replayable", recorded: "\(baseline.replayed != nil)", replayed: "\(current.replayed != nil)")]
        }
        return a.differences(from: b).map { EvidenceReplayReport.Difference(field: $0.field, recorded: $0.recorded, replayed: $0.replayed) }
    }
}
