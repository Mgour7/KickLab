import Foundation

// Build 15: the evidence bundle — everything one analysis decided, and the inputs it decided
// from, in one ZIP the user exports on purpose. Format: Docs/EVIDENCE_BUNDLE_FORMAT.md.
//
//   manifest.json                 EvidenceManifest (format "kicklab.evidence", version 1)
//   analysis/manifest.json        the analysis artifact files, exactly as the app stores them:
//   analysis/pose.json              pose samples, tracking, processed kicker timeline
//   analysis/signals.json           derived signals
//   analysis/phases.json            phases, evidence, and the football track WITH raw detections
//   analysis/biomechanics.json      metrics and scores (when written)
//   recorded/outcome.json         EvidenceOutcome — the decisions as recorded on the device
//   annotations/human.json        human-reviewed marks, kept apart from automatic inputs
//   diagnostics/summary.txt       the readable diagnostics summary
//   crops/*.pgm                   optional ball-region crops (only with explicit consent)
//
// The pure analysis (pose → kicker timeline → signals → football tracking → fusion →
// phases → metrics → gates) can be replayed from it with `EvidenceReplay`. Apple Vision pose
// extraction and Core ML inference CANNOT be replayed: their outputs are recorded instead.

struct EvidenceManifest: Codable, Equatable, Sendable {
    static let format = "kicklab.evidence"
    static let currentFormatVersion = 1

    struct App: Codable, Equatable, Sendable { var version: String?; var build: String? }
    struct Runtime: Codable, Equatable, Sendable {
        var platform: String
        var osVersion: String?
        var footballComputeUnits: String
    }
    struct Video: Codable, Equatable, Sendable {
        var durationSeconds: Double?
        var sourceFrameRate: Double?
        var analysisFrameRate: Double?
        var framesSampled: Int?
        var orientation: String?
        var isMirrored: Bool?
        var displayAspectRatio: Double?
    }
    struct Analysis: Codable, Equatable, Sendable {
        var mode: String
        var status: String
        var failureReason: String?
        var kickType: String
        var cameraAngle: String?
    }
    struct Privacy: Codable, Equatable, Sendable {
        var includesVideo = false
        var includesImageCrops: Bool
        var includesPoseCoordinates: Bool
        var includesBallBoxes: Bool
        var includesHumanAnnotations: Bool
        var notice: String
    }
    struct File: Codable, Equatable, Sendable {
        var path: String
        var kind: String
        var bytes: Int
        var crc32: UInt32
    }

    var format = EvidenceManifest.format
    var formatVersion = EvidenceManifest.currentFormatVersion
    var createdAt: Date
    var app: App
    var engineVersion: String?
    var contactDetector: String?
    var poseDetector = "Apple Vision human body pose (recorded output; not replayable without the video)"
    var footballDetector: FootballDetectorInfo?
    var dataSchema = "SwiftData V3 (unchanged; evidence is read from the stored analysis files)"
    var artifactFormats: [String: Int]
    var runtime: Runtime
    var video: Video
    var coordinates = "Times in seconds from the video start (frame presentation times). Positions are app-normalized DISPLAYED coordinates: origin top-left of the upright (rotated, as-viewed) frame, x as a fraction of the displayed width, y and sizes as fractions of the displayed height unless stated; ball sizes in displayed-height units. Speeds in body lengths per second; angles in degrees."
    var analysis: Analysis
    var files: [File]
    /// Explicit markers for evidence that is missing or was never recorded.
    var unavailable: [String]
    var privacy: Privacy
}

/// Human input, exported separately from automatic inputs and never fed to replay.
struct EvidenceAnnotations: Codable, Equatable, Sendable {
    var note = "HUMAN INPUT — for comparison only. Never used as an automatic input, in the app or in replay."
    var markedContactTime: Double?
    var contactAnnotation: String
    var verification: VideoVerification?
    /// What the user supplied when this analysis itself was user-assisted.
    var analysisAssistance: PhaseDetectionAssistance?
}

/// The decisions of one analysis, comparable between the device and a replay.
struct EvidenceOutcome: Codable, Equatable, Sendable {
    var engineVersion: String?
    var footballMethod: String?
    var footballDetectorRan: Bool?
    var selectedBallX: Double?
    var selectedBallY: Double?
    var ballLastStationary: Double?
    var ballFirstMovement: Double?
    var ballMovementBasis: String?
    var kickWindowSource: String?
    var plantProposed: Double?
    var plantRejected: Bool?
    var plantUsed: Double?
    var contactOutcome: String
    var contactStatus: String
    var contactTime: Double?
    var contactEarliest: Double?
    var contactLatest: Double?
    var contactConfidence: Double?
    var contactMethod: String?
    var fusionAccepted: Bool?
    var fusionRejection: String?
    var availableMetrics: Int
    var completionPassed: Bool?
    var stopGate: String?

    static func r3(_ v: Double?) -> Double? { v.map { ($0 * 1000).rounded() / 1000 } }

    static func make(phases: KickPhaseDetectionResult, football: FootballTrack?, gates: [AnalysisGate]?,
                     measurements: [KickMetricMeasurement], engineVersion: String?) -> EvidenceOutcome {
        let e = phases.evidence
        let c = phases.phase(.contact)
        let selected = football?.sites.first(where: \.selected)
        let completion = gates?.last { $0.gate == .completion }
        return EvidenceOutcome(
            engineVersion: engineVersion,
            footballMethod: football?.method.rawValue,
            footballDetectorRan: football.map { $0.detector != nil },
            selectedBallX: r3(selected?.center.x), selectedBallY: r3(selected?.center.y),
            ballLastStationary: r3(football?.lastStationaryTime), ballFirstMovement: r3(football?.firstPersistentMovementTime),
            ballMovementBasis: football?.movementBasis,
            kickWindowSource: phases.kickWindows?.selected?.source,
            plantProposed: r3(e?.ballFusion?.plantCandidateTime), plantRejected: e?.ballFusion?.plantRejected,
            plantUsed: r3(phases.plantTime),
            contactOutcome: ContactOutcome.of(phases).rawValue, contactStatus: c.status.rawValue,
            contactTime: r3(c.isAvailable ? c.representativeTime : nil),
            contactEarliest: r3(e?.contactEarliestTime), contactLatest: r3(e?.contactLatestTime),
            contactConfidence: r3(c.isAvailable ? c.confidence : nil), contactMethod: e?.contactTimingMethod,
            fusionAccepted: e?.ballFusion?.accepted, fusionRejection: e?.ballFusion?.rejectionReason,
            availableMetrics: measurements.filter(\.isAvailable).count,
            completionPassed: completion?.passed,
            stopGate: gates?.first { $0.passed == false }?.gate.rawValue
        )
    }

    /// Field-by-field differences (name, recorded, replayed).
    func differences(from other: EvidenceOutcome) -> [(field: String, recorded: String, replayed: String)] {
        func s<T>(_ v: T?) -> String { v.map { "\($0)" } ?? "—" }
        let pairs: [(String, String, String)] = [
            ("footballMethod", s(footballMethod), s(other.footballMethod)),
            ("selectedBall", "\(s(selectedBallX)),\(s(selectedBallY))", "\(s(other.selectedBallX)),\(s(other.selectedBallY))"),
            ("ballLastStationary", s(ballLastStationary), s(other.ballLastStationary)),
            ("ballFirstMovement", s(ballFirstMovement), s(other.ballFirstMovement)),
            ("kickWindowSource", s(kickWindowSource), s(other.kickWindowSource)),
            ("plantProposed", s(plantProposed), s(other.plantProposed)),
            ("plantRejected", s(plantRejected), s(other.plantRejected)),
            ("plantUsed", s(plantUsed), s(other.plantUsed)),
            ("contactOutcome", contactOutcome, other.contactOutcome),
            ("contactStatus", contactStatus, other.contactStatus),
            ("contactTime", s(contactTime), s(other.contactTime)),
            ("contactInterval", "\(s(contactEarliest))–\(s(contactLatest))", "\(s(other.contactEarliest))–\(s(other.contactLatest))"),
            ("contactConfidence", s(contactConfidence), s(other.contactConfidence)),
            ("contactMethod", s(contactMethod), s(other.contactMethod)),
            ("fusionAccepted", s(fusionAccepted), s(other.fusionAccepted)),
            ("availableMetrics", "\(availableMetrics)", "\(other.availableMetrics)"),
            ("completionPassed", s(completionPassed), s(other.completionPassed)),
            ("stopGate", s(stopGate), s(other.stopGate)),
        ]
        return pairs.filter { $0.1 != $0.2 }.map { (field: $0.0, recorded: $0.1, replayed: $0.2) }
    }
}

/// What the app knows besides the analysis files when exporting.
struct EvidenceExportContext: Sendable {
    var appVersion: String?
    var appBuild: String?
    var osVersion: String?
    var status: String
    var failureReason: String?
    var kickType: KickType
    var cameraAngle: VideoAngleType?
    var annotations: EvidenceAnnotations
    var summaryText: String
    var createdAt: Date
    /// Ball-region crops (file name → PGM bytes), only when the user consented.
    var crops: [(name: String, data: Data)] = []
}

enum EvidenceBundleError: Error, Equatable, Sendable {
    case zip(StoredZip.ZipError)
    case missingManifest
    case wrongFormat(String)
    case unsupportedVersion(Int)
    case listedFileMissing(String)
    case checksumMismatch(String)
    case invalidArtifacts(String)
    case invalidUnits(String)
}

/// The decoded, validated contents of a bundle.
struct EvidenceContents: Sendable {
    var manifest: EvidenceManifest
    var artifacts: AnalysisArtifactBundle?
    var recorded: EvidenceOutcome?
    var annotations: EvidenceAnnotations?
    var files: [String: Data]
}

enum EvidenceBundle {
    static let privacyNotice = "This file contains body-position coordinates for every analyzed frame, football positions and timing, and any marks you made. It contains no video, no images (unless you chose to include ball crops), no names and no account or device identifiers. Share it only with people you trust."

    static func jsonEncoder() -> JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.sortedKeys, .prettyPrinted]
        e.dateEncodingStrategy = .iso8601
        e.nonConformingFloatEncodingStrategy = .convertToString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        return e
    }

    static func jsonDecoder() -> JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        d.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        return d
    }

    /// The decisions recorded in stored analysis files.
    static func recordedOutcome(_ a: AnalysisArtifactBundle) -> EvidenceOutcome {
        EvidenceOutcome.make(phases: a.phases.phases, football: a.phases.football, gates: a.manifest.gates,
                             measurements: a.biomechanics?.measurements ?? [], engineVersion: a.manifest.engineVersion)
    }

    // MARK: Build

    static func build(artifacts: AnalysisArtifactBundle?, context c: EvidenceExportContext) throws -> (data: Data, manifest: EvidenceManifest) {
        var entries: [StoredZip.Entry] = []
        var listed: [EvidenceManifest.File] = []
        var unavailable: [String] = []
        func add(_ path: String, _ kind: String, _ data: Data) {
            entries.append(StoredZip.Entry(path: path, data: data))
            listed.append(EvidenceManifest.File(path: path, kind: kind, bytes: data.count, crc32: StoredZip.crc32(data)))
        }
        if let a = artifacts {
            add("analysis/manifest.json", AnalysisArtifactManifest.kind, try AnalysisArtifactCoder.encode(a.manifest))
            add("analysis/pose.json", PoseArtifact.kind, try AnalysisArtifactCoder.encode(a.pose))
            add("analysis/signals.json", SignalArtifact.kind, try AnalysisArtifactCoder.encode(a.signals))
            add("analysis/phases.json", PhaseArtifact.kind, try AnalysisArtifactCoder.encode(a.phases))
            if let b = a.biomechanics { add("analysis/biomechanics.json", BiomechanicsArtifact.kind, try AnalysisArtifactCoder.encode(b)) }
            else { unavailable.append("analysis/biomechanics.json: no biomechanics file was written for this analysis") }
            add("recorded/outcome.json", "kicklab.evidence.outcome", try jsonEncoder().encode(recordedOutcome(a)))
            if a.pose.kickerTimeline == nil { unavailable.append("processed kicker timeline: no kicker was selected") }
            switch a.phases.football {
            case .none: unavailable.append("football: the detector didn't run for this analysis (made before engine 2.8.0, user-assisted, or no detector on the device)")
            case .some(let f) where f.raw == nil: unavailable.append("football raw detections: not recorded (analysis made before build 15) — the football stage is replayed from its recorded track, not from detections")
            case .some(let f) where f.raw?.precisionTimes == nil: unavailable.append("football precision pass: not run (\(f.note))")
            default: break
            }
            let dropped = a.pose.sequence.frames.filter { $0.status != .analyzed }.count
            if dropped > 0 { unavailable.append("pose: \(dropped) sampled frame(s) have no pose (status recorded per frame in analysis/pose.json)") }
        } else {
            unavailable.append("analysis files: none were stored for this analysis — only the outcome and annotations are included, and it can't be replayed")
        }
        add("annotations/human.json", "kicklab.evidence.annotations", try jsonEncoder().encode(c.annotations))
        add("diagnostics/summary.txt", "text/plain", Data(c.summaryText.utf8))
        for crop in c.crops where StoredZip.isSafePath("crops/" + crop.name) { add("crops/" + crop.name, "image/x-portable-graymap", crop.data) }
        unavailable.append("video, frames and thumbnails: never included")
        if c.crops.isEmpty { unavailable.append("ball image crops: not included (optional, requires consent)") }

        let seq = artifacts?.pose.sequence
        let manifest = EvidenceManifest(
            createdAt: c.createdAt, app: .init(version: c.appVersion, build: c.appBuild),
            engineVersion: artifacts?.manifest.engineVersion, contactDetector: artifacts?.phases.phases.evidence?.algorithmVersion,
            footballDetector: artifacts?.phases.football?.detector,
            artifactFormats: [AnalysisArtifactManifest.kind: AnalysisArtifactManifest.currentFormatVersion, PoseArtifact.kind: PoseArtifact.currentFormatVersion,
                              SignalArtifact.kind: SignalArtifact.currentFormatVersion, PhaseArtifact.kind: PhaseArtifact.currentFormatVersion,
                              BiomechanicsArtifact.kind: BiomechanicsArtifact.currentFormatVersion, "football.raw": FootballRawEvidence.formatVersion],
            runtime: .init(platform: "iOS", osVersion: c.osVersion, footballComputeUnits: "all (CPU, GPU, Neural Engine as Core ML chooses)"),
            video: .init(durationSeconds: seq?.durationSeconds, sourceFrameRate: seq?.nominalFrameRate, analysisFrameRate: seq?.analysisFrameRate,
                         framesSampled: seq?.frames.count, orientation: seq?.orientation.rawValue, isMirrored: seq?.isMirrored,
                         displayAspectRatio: seq?.displayAspectRatio),
            analysis: .init(mode: c.annotations.analysisAssistance?.isEmpty == false ? "userAssisted" : "automatic", status: c.status,
                            failureReason: c.failureReason, kickType: c.kickType.rawValue, cameraAngle: c.cameraAngle?.rawValue),
            files: listed, unavailable: unavailable,
            privacy: .init(includesImageCrops: !c.crops.isEmpty, includesPoseCoordinates: artifacts != nil,
                           includesBallBoxes: artifacts?.phases.football?.raw != nil,
                           includesHumanAnnotations: c.annotations.markedContactTime != nil || c.annotations.verification != nil,
                           notice: privacyNotice)
        )
        let manifestEntry = StoredZip.Entry(path: "manifest.json", data: try jsonEncoder().encode(manifest))
        do {
            return (try StoredZip.write([manifestEntry] + entries), manifest)
        } catch let e as StoredZip.ZipError {
            throw EvidenceBundleError.zip(e)
        }
    }

    // MARK: Read and validate

    static func read(zip data: Data, limits: StoredZip.Limits = .standard) throws -> EvidenceContents {
        let entries: [StoredZip.Entry]
        do { entries = try StoredZip.read(data, limits: limits) } catch let e as StoredZip.ZipError { throw EvidenceBundleError.zip(e) }
        var files: [String: Data] = [:]
        for e in entries { files[e.path] = e.data }
        return try read(files: files)
    }

    /// Validates a bundle given as path → bytes (from a ZIP or an unzipped folder).
    static func read(files: [String: Data]) throws -> EvidenceContents {
        guard let m = files["manifest.json"] else { throw EvidenceBundleError.missingManifest }
        struct Header: Decodable { var format: String?; var formatVersion: Int? }
        guard let header = try? jsonDecoder().decode(Header.self, from: m), header.format == EvidenceManifest.format else {
            throw EvidenceBundleError.wrongFormat("manifest.json is not a KickLab evidence manifest")
        }
        guard let v = header.formatVersion, v >= 1, v <= EvidenceManifest.currentFormatVersion else {
            throw EvidenceBundleError.unsupportedVersion(header.formatVersion ?? -1)
        }
        let manifest: EvidenceManifest
        do { manifest = try jsonDecoder().decode(EvidenceManifest.self, from: m) } catch { throw EvidenceBundleError.wrongFormat("manifest.json: \(error)") }
        for f in manifest.files {
            guard StoredZip.isSafePath(f.path), let d = files[f.path] else { throw EvidenceBundleError.listedFileMissing(f.path) }
            guard d.count == f.bytes, StoredZip.crc32(d) == f.crc32 else { throw EvidenceBundleError.checksumMismatch(f.path) }
        }
        var artifacts: AnalysisArtifactBundle?
        if let man = files["analysis/manifest.json"] {
            do {
                let am = try AnalysisArtifactCoder.decode(AnalysisArtifactManifest.self, from: man)
                guard let p = files["analysis/pose.json"], let s = files["analysis/signals.json"], let ph = files["analysis/phases.json"] else {
                    throw EvidenceBundleError.invalidArtifacts("an analysis file is missing")
                }
                artifacts = AnalysisArtifactBundle(
                    manifest: am, pose: try AnalysisArtifactCoder.decode(PoseArtifact.self, from: p),
                    signals: try AnalysisArtifactCoder.decode(SignalArtifact.self, from: s),
                    phases: try AnalysisArtifactCoder.decode(PhaseArtifact.self, from: ph),
                    biomechanics: try files["analysis/biomechanics.json"].map { try AnalysisArtifactCoder.decode(BiomechanicsArtifact.self, from: $0) }
                )
            } catch let e as EvidenceBundleError {
                throw e
            } catch {
                throw EvidenceBundleError.invalidArtifacts("\(error)")
            }
            try validateUnits(artifacts!)
        }
        let recorded = try files["recorded/outcome.json"].map { d -> EvidenceOutcome in
            do { return try jsonDecoder().decode(EvidenceOutcome.self, from: d) } catch { throw EvidenceBundleError.invalidArtifacts("recorded/outcome.json: \(error)") }
        }
        let annotations = files["annotations/human.json"].flatMap { try? jsonDecoder().decode(EvidenceAnnotations.self, from: $0) }
        return EvidenceContents(manifest: manifest, artifacts: artifacts, recorded: recorded, annotations: annotations, files: files)
    }

    /// Units and ranges a replay depends on.
    static func validateUnits(_ a: AnalysisArtifactBundle) throws {
        let seq = a.pose.sequence
        if let r = seq.displayAspectRatio, !(r > 0.05 && r < 20) { throw EvidenceBundleError.invalidUnits("display aspect ratio \(r)") }
        if let fps = seq.nominalFrameRate, !(fps > 0 && fps <= 1000) { throw EvidenceBundleError.invalidUnits("frame rate \(fps)") }
        let times = seq.frames.map(\.timestamp)
        guard times.allSatisfy({ $0.isFinite && $0 >= 0 }), zip(times, times.dropFirst()).allSatisfy({ $0 < $1 }) else {
            throw EvidenceBundleError.invalidUnits("frame times must be finite, non-negative and increasing")
        }
        if let raw = a.phases.football?.raw {
            let boxes = raw.broadScan + (raw.precision ?? [])
            guard boxes.allSatisfy({ $0.score >= 0 && $0.score <= 1 && $0.box.w >= 0 && $0.box.h >= 0 && $0.time.isFinite }) else {
                throw EvidenceBundleError.invalidUnits("football detection out of range")
            }
            guard raw.aspect > 0.05, raw.aspect < 20 else { throw EvidenceBundleError.invalidUnits("football aspect \(raw.aspect)") }
        }
    }

    /// Portable graymap (binary P5) — a plain image format any viewer reads.
    static func pgm(_ image: LumaImage) -> Data {
        var d = Data("P5\n\(image.width) \(image.height)\n255\n".utf8)
        d.append(contentsOf: image.pixels)
        return d
    }
}
