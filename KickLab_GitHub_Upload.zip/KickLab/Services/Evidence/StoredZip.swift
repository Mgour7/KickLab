import Foundation

/// Build 15: a minimal, deterministic ZIP archive (STORED entries, no compression) for
/// evidence bundles. Written and read in pure Swift so the same code runs in the app, in
/// tests and in the replay tool. Any standard unzip tool can open the archives.
///
/// The reader is strict: it accepts only stored entries, checks every CRC and size, and
/// rejects absolute paths, "..", backslashes, duplicate names, too many entries and
/// archives larger than the limits — an imported file can never write outside its folder
/// or exhaust memory.
enum StoredZip {
    struct Entry: Equatable, Sendable {
        var path: String
        var data: Data
    }

    struct Limits: Equatable, Sendable {
        var maximumEntries = 512
        var maximumEntryBytes = 48 * 1024 * 1024
        var maximumTotalBytes = 96 * 1024 * 1024
        static let standard = Limits()
    }

    enum ZipError: Error, Equatable, Sendable {
        case notAZip
        case tooLarge(String)
        case unsupported(String)
        case corrupt(String)
        case unsafePath(String)
        case duplicate(String)
    }

    // MARK: CRC-32 (IEEE 802.3)

    private static let table: [UInt32] = (0..<256).map { n -> UInt32 in
        var c = UInt32(n)
        for _ in 0..<8 { c = (c & 1) != 0 ? 0xEDB8_8320 ^ (c >> 1) : c >> 1 }
        return c
    }

    static func crc32(_ data: Data) -> UInt32 {
        var c: UInt32 = 0xFFFF_FFFF
        for b in data { c = table[Int((c ^ UInt32(b)) & 0xFF)] ^ (c >> 8) }
        return c ^ 0xFFFF_FFFF
    }

    // MARK: Paths

    static func isSafePath(_ p: String) -> Bool {
        guard !p.isEmpty, p.utf8.count <= 240, !p.hasPrefix("/"), !p.contains("\\"), !p.contains("\0") else { return false }
        return !p.split(separator: "/", omittingEmptySubsequences: false).contains { $0 == ".." || $0 == "." || $0.isEmpty }
    }

    // MARK: Write

    static func write(_ entries: [Entry]) throws -> Data {
        var out = Data()
        var central = Data()
        var seen = Set<String>()
        for e in entries {
            guard isSafePath(e.path) else { throw ZipError.unsafePath(e.path) }
            guard seen.insert(e.path).inserted else { throw ZipError.duplicate(e.path) }
            guard e.data.count < Int(UInt32.max), out.count < Int(UInt32.max) else { throw ZipError.tooLarge(e.path) }
            let name = Data(e.path.utf8)
            let crc = crc32(e.data)
            let offset = UInt32(out.count)
            // Local file header. Fixed date (1980-01-01) keeps archives byte-for-byte reproducible.
            out.append(le32(0x0403_4B50)); out.append(le16(10)); out.append(le16(0x0800)); out.append(le16(0))
            out.append(le16(0)); out.append(le16(0x21))
            out.append(le32(crc)); out.append(le32(UInt32(e.data.count))); out.append(le32(UInt32(e.data.count)))
            out.append(le16(UInt16(name.count))); out.append(le16(0))
            out.append(name); out.append(e.data)
            central.append(le32(0x0201_4B50)); central.append(le16(20)); central.append(le16(10)); central.append(le16(0x0800))
            central.append(le16(0)); central.append(le16(0)); central.append(le16(0x21))
            central.append(le32(crc)); central.append(le32(UInt32(e.data.count))); central.append(le32(UInt32(e.data.count)))
            central.append(le16(UInt16(name.count))); central.append(le16(0)); central.append(le16(0)); central.append(le16(0))
            central.append(le16(0)); central.append(le32(0)); central.append(le32(offset)); central.append(name)
        }
        let centralOffset = UInt32(out.count)
        out.append(central)
        out.append(le32(0x0605_4B50)); out.append(le16(0)); out.append(le16(0))
        out.append(le16(UInt16(entries.count))); out.append(le16(UInt16(entries.count)))
        out.append(le32(UInt32(central.count))); out.append(le32(centralOffset)); out.append(le16(0))
        return out
    }

    // MARK: Read

    static func read(_ data: Data, limits: Limits = .standard) throws -> [Entry] {
        let bytes = [UInt8](data)
        guard bytes.count >= 22 else { throw ZipError.notAZip }
        guard bytes.count <= limits.maximumTotalBytes + 1_048_576 else { throw ZipError.tooLarge("archive") }
        // End of central directory: within the last 22 + 65535 bytes.
        var eocd: Int?
        var i = bytes.count - 22
        let stop = max(0, bytes.count - 22 - 65_535)
        while i >= stop {
            if u32(bytes, i) == 0x0605_4B50 { eocd = i; break }
            i -= 1
        }
        guard let e = eocd else { throw ZipError.notAZip }
        let count = Int(u16(bytes, e + 10))
        let centralSize = Int(u32(bytes, e + 12)), centralOffset = Int(u32(bytes, e + 16))
        guard count <= limits.maximumEntries else { throw ZipError.tooLarge("\(count) entries") }
        guard centralOffset + centralSize <= e else { throw ZipError.corrupt("central directory") }
        var entries: [Entry] = []
        var names = Set<String>()
        var total = 0
        var p = centralOffset
        for _ in 0..<count {
            guard p + 46 <= bytes.count, u32(bytes, p) == 0x0201_4B50 else { throw ZipError.corrupt("central entry") }
            let flags = u16(bytes, p + 8), method = u16(bytes, p + 10)
            let crc = u32(bytes, p + 16), compressed = Int(u32(bytes, p + 20)), size = Int(u32(bytes, p + 24))
            let nameLength = Int(u16(bytes, p + 28)), extra = Int(u16(bytes, p + 30)), comment = Int(u16(bytes, p + 32))
            let local = Int(u32(bytes, p + 42))
            guard p + 46 + nameLength <= bytes.count else { throw ZipError.corrupt("name") }
            guard let name = String(bytes: bytes[(p + 46)..<(p + 46 + nameLength)], encoding: .utf8) else { throw ZipError.corrupt("name") }
            p += 46 + nameLength + extra + comment
            if name.hasSuffix("/") { continue }   // directory entries carry no data
            guard method == 0 else { throw ZipError.unsupported("compressed entry \(name): unzip the bundle and pass the folder instead") }
            guard flags & 0x1 == 0 else { throw ZipError.unsupported("encrypted entry \(name)") }
            guard isSafePath(name) else { throw ZipError.unsafePath(name) }
            guard names.insert(name).inserted else { throw ZipError.duplicate(name) }
            guard compressed == size, size <= limits.maximumEntryBytes else { throw ZipError.tooLarge(name) }
            total += size
            guard total <= limits.maximumTotalBytes else { throw ZipError.tooLarge("archive contents") }
            guard local + 30 <= bytes.count, u32(bytes, local) == 0x0403_4B50 else { throw ZipError.corrupt("local header \(name)") }
            let start = local + 30 + Int(u16(bytes, local + 26)) + Int(u16(bytes, local + 28))
            guard start >= 0, start + size <= bytes.count else { throw ZipError.corrupt("data \(name)") }
            let payload = Data(bytes[start..<(start + size)])
            guard crc32(payload) == crc else { throw ZipError.corrupt("checksum \(name)") }
            entries.append(Entry(path: name, data: payload))
        }
        return entries
    }

    private static func le16(_ v: UInt16) -> Data { Data([UInt8(v & 0xFF), UInt8(v >> 8)]) }
    private static func le32(_ v: UInt32) -> Data { Data((0..<4).map { UInt8((v >> (8 * UInt32($0))) & 0xFF) }) }
    private static func u16(_ b: [UInt8], _ i: Int) -> UInt16 { i + 2 <= b.count ? UInt16(b[i]) | UInt16(b[i + 1]) << 8 : 0 }
    private static func u32(_ b: [UInt8], _ i: Int) -> UInt32 {
        guard i >= 0, i + 4 <= b.count else { return 0 }
        return UInt32(b[i]) | UInt32(b[i + 1]) << 8 | UInt32(b[i + 2]) << 16 | UInt32(b[i + 3]) << 24
    }
}
