#if canImport(CoreML) && canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
import AVFoundation
import CoreML
import CoreVideo
import Foundation

/// Build 21 — Stage A scanner on the iPhone. One decode pass over the whole recording:
/// the frame reader keeps about `framesPerSecond` frames per second; each kept frame goes
/// through YOLOX-S (full frame) and the injected person detector (Vision). Frames are
/// released one by one, so memory stays flat for a 30-minute recording.
struct CoreMLSessionScanner: SessionScanning {
    /// The most prominent person's ankles/hips on one frame (Vision on the iPhone; injected
    /// so this file doesn't depend on Vision).
    let personDetector: @Sendable (CVPixelBuffer, VideoTrackInfo, Double) -> ScanPerson?
    let bundle: Bundle

    init(bundle: Bundle = .main, personDetector: @escaping @Sendable (CVPixelBuffer, VideoTrackInfo, Double) -> ScanPerson?) {
        self.bundle = bundle
        self.personDetector = personDetector
    }

    var isAvailable: Bool { CoreMLFootballDetector.modelURL(in: bundle) != nil }

    func scan(videoURL: URL, framesPerSecond: Double, progress: @escaping @Sendable (Double) -> Void) async throws -> [SessionScanSample] {
        let detector: CoreMLFootballDetector
        do {
            detector = try CoreMLFootballDetector.load(bundle: bundle)
        } catch {
            throw SessionMediaError.unavailable("The football detector couldn't be loaded.")
        }
        let info = try await VideoFrameReader.trackInfo(for: videoURL)
        let quarter = info.orientation == .right || info.orientation == .left
        let width = quarter ? info.naturalHeight : info.naturalWidth
        let height = quarter ? info.naturalWidth : info.naturalHeight
        let full = DisplayRect(x: 0, y: 0, width: width, height: height)
        let duration = info.durationSeconds ?? 0
        var samples: [SessionScanSample] = []
        let detect = personDetector
        _ = try await VideoFrameReader.read(url: videoURL, plan: FrameSamplingPlan(rate: .target(framesPerSecond: framesPerSecond))) { _, time, buffer in
            // A detector failure fails the scan (it's retried later) instead of silently
            // recording "no ball" for that frame and caching an incomplete scan.
            let dets = try detector.detect(pixelBuffer: buffer, orientation: info.orientation, isMirrored: info.isMirrored,
                                           region: full, time: time, pass: .broadScan)
            let balls = dets.map { ScanBall(cx: $0.box.cx, cy: $0.box.cy, w: $0.box.w, h: $0.box.h, score: $0.score) }
            samples.append(SessionScanSample(time: time, balls: balls, person: detect(buffer, info, time)))
            if duration > 0 { progress(min(1, time / duration)) }
        }
        progress(1)
        return samples
    }
}

/// Cuts a clip out of a recording without re-encoding (passthrough). AVFoundation trims at
/// the requested time with an edit list, so the clip's time 0 is the requested start; the
/// exported duration is read back and recorded.
struct AVClipExporter: ClipExporting {
    var isAvailable: Bool { true }

    func exportClip(from source: URL, start: Double, end: Double, to destination: URL) async throws -> ExportedClip {
        let asset = AVURLAsset(url: source)
        guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) else {
            throw SessionMediaError.failed("This recording can't be cut without re-encoding.")
        }
        try? FileManager.default.removeItem(at: destination)
        session.timeRange = CMTimeRange(start: CMTime(seconds: start, preferredTimescale: 600),
                                        duration: CMTime(seconds: end - start, preferredTimescale: 600))
        do {
            try await session.export(to: destination, as: .mov)
        } catch {
            try? FileManager.default.removeItem(at: destination)
            throw SessionMediaError.failed("The clip couldn't be exported (\(error.localizedDescription)).")
        }
        let duration = try await AVURLAsset(url: destination).load(.duration).seconds
        return ExportedClip(url: destination, startInSource: start, duration: duration.isFinite ? duration : end - start)
    }
}

/// Experimental: runs YOLOX-S on every frame for `seconds` after contact and lets
/// `BallFlightObserver` follow the kicked ball. Never scored.
struct CoreMLBallFlightTracker: BallFlightTracking {
    let bundle: Bundle
    init(bundle: Bundle = .main) { self.bundle = bundle }
    var isAvailable: Bool { CoreMLFootballDetector.modelURL(in: bundle) != nil }

    func observe(videoURL: URL, contactTime: Double, rest: NormalizedBox, seconds: Double) async throws -> BallFlightObservation {
        let detector: CoreMLFootballDetector
        do {
            detector = try CoreMLFootballDetector.load(bundle: bundle)
        } catch {
            throw SessionMediaError.unavailable("The football detector couldn't be loaded.")
        }
        let info = try await VideoFrameReader.trackInfo(for: videoURL)
        let quarter = info.orientation == .right || info.orientation == .left
        let full = DisplayRect(x: 0, y: 0, width: quarter ? info.naturalHeight : info.naturalWidth,
                               height: quarter ? info.naturalWidth : info.naturalHeight)
        let end = min(info.durationSeconds ?? contactTime + seconds, contactTime + seconds)
        var frames: [(time: Double, boxes: [FootballDetection])] = []
        _ = try await VideoFrameReader.read(url: videoURL, plan: FrameSamplingPlan(rate: .everyFrame, timeRange: contactTime...end)) { _, time, buffer in
            let dets = try detector.detect(pixelBuffer: buffer, orientation: info.orientation, isMirrored: info.isMirrored,
                                           region: full, time: time, pass: .precision)
            frames.append((time, dets))
        }
        return BallFlightObserver.observe(contactTime: contactTime, rest: rest, detections: frames, windowEnd: end)
    }
}
/// Hotfix 2: what AVFoundation reports about a file's timing, read the way the analysis
/// reads it (the first frame time comes from `VideoFrameReader`, the engine's own reader).
struct AVMediaTimingInspector: MediaTimingInspecting {
    private struct FirstFrameFound: Error {}

    func timing(of url: URL) async -> MediaTimingInfo? {
        let asset = AVURLAsset(url: url)
        guard let track = try? await asset.loadTracks(withMediaType: .video).first else { return nil }
        var info = MediaTimingInfo()
        info.durationSeconds = (try? await asset.load(.duration)).map(\.seconds).flatMap { $0.isFinite ? $0 : nil }
        if let size = try? await track.load(.naturalSize) {
            info.width = Int(size.width.rounded())
            info.height = Int(size.height.rounded())
            if let t = try? await track.load(.preferredTransform) {
                info.transform = [Double(t.a), Double(t.b), Double(t.c), Double(t.d), Double(t.tx), Double(t.ty)]
                let quarterTurn = abs(Double(t.b)) > 0.5 && abs(Double(t.c)) > 0.5
                let w = quarterTurn ? size.height : size.width, h = quarterTurn ? size.width : size.height
                info.displayOrientation = h > w ? "portrait" : "landscape"
            }
        }
        info.nominalFrameRate = (try? await track.load(.nominalFrameRate)).map(Double.init)
        info.minFrameDuration = (try? await track.load(.minFrameDuration)).map(\.seconds).flatMap { $0.isFinite && $0 > 0 ? $0 : nil }
        if let range = try? await track.load(.timeRange) {
            info.trackStart = range.start.seconds.isFinite ? range.start.seconds : nil
            info.trackDuration = range.duration.seconds.isFinite ? range.duration.seconds : nil
        }
        if let formats = try? await track.load(.formatDescriptions), let f = formats.first {
            let code = CMFormatDescriptionGetMediaSubType(f)
            let bytes = [UInt8((code >> 24) & 0xFF), UInt8((code >> 16) & 0xFF), UInt8((code >> 8) & 0xFF), UInt8(code & 0xFF)]
            info.codec = String(decoding: bytes, as: UTF8.self)
        }
        if let segments = try? await track.load(.segments) {
            info.editSegments = segments.map { seg in
                let src = seg.timeMapping.source, dst = seg.timeMapping.target
                return MediaTimingInfo.EditSegment(
                    mediaStart: seg.isEmpty ? nil : src.start.seconds, mediaDuration: seg.isEmpty ? nil : src.duration.seconds,
                    targetStart: dst.start.seconds, targetDuration: dst.duration.seconds, isEmpty: seg.isEmpty)
            }
        }
        info.hasAudio = !((try? await asset.loadTracks(withMediaType: .audio)) ?? []).isEmpty
        if let items = try? await asset.load(.metadata) {
            info.metadataKeys = items.compactMap { $0.identifier?.rawValue }.sorted()
        }
        // The first frame time as the analysis sees it.
        var first: Double?
        do {
            _ = try await VideoFrameReader.read(url: url, plan: FrameSamplingPlan(rate: .everyFrame)) { _, time, _ in
                first = time
                throw FirstFrameFound()
            }
        } catch {}
        info.firstFrameTime = first
        return info
    }
}

/// Hotfix 2: a copy of a video for the diagnostics share sheet — the video track only
/// (sound only when the athlete asks), passthrough (no re-encoding), with identifying
/// metadata (location, device) filtered out. The original file is not modified.
struct AVSharingVideoExporter: SharingVideoExporting {
    func exportForSharing(source: URL, includeAudio: Bool, to destination: URL) async throws {
        let asset = AVURLAsset(url: source)
        let composition = AVMutableComposition()
        guard let video = try await asset.loadTracks(withMediaType: .video).first,
              let videoOut = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw SessionMediaError.failed("This video has no picture track.")
        }
        let range = try await video.load(.timeRange)
        // Each track keeps its own start, so the copy has the same timeline as the original.
        try videoOut.insertTimeRange(range, of: video, at: range.start)
        videoOut.preferredTransform = try await video.load(.preferredTransform)
        if includeAudio, let audio = try await asset.loadTracks(withMediaType: .audio).first,
           let audioOut = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let audioRange = try await audio.load(.timeRange)
            try audioOut.insertTimeRange(audioRange, of: audio, at: audioRange.start)
        }
        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetPassthrough) else {
            throw SessionMediaError.failed("This video can't be copied without re-encoding.")
        }
        session.metadataItemFilter = .forSharing()
        session.metadata = []
        try? FileManager.default.removeItem(at: destination)
        try await session.export(to: destination, as: .mov)
    }
}

#endif
