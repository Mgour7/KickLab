#if canImport(Vision) && canImport(AVFoundation) && canImport(CoreML)
import AVFoundation
import CoreVideo
import Foundation
import Vision

/// Build 21 — Stage A's person reading: one Vision body pose per scanned frame (the same
/// request and coordinate conversion the analysis uses), reduced to the largest person's
/// ankles, hip centre and torso length.
enum VisionScanPerson {
    static func detector() -> @Sendable (CVPixelBuffer, VideoTrackInfo, Double) -> ScanPerson? {
        let cpuOnly = VisionPoseSequenceExtractor.probeRuntime().usesCPUOnly
        return { buffer, info, time in
            // A request per frame: VNRequest isn't Sendable, and its setup is cheap next to inference.
            let request = VisionPoseSequenceExtractor.makeRequest(cpuOnly: cpuOnly)
            let frame = VisionPoseSequenceExtractor.detect(in: buffer, orientation: VisionPoseSequenceExtractor.imageOrientation(info.orientation),
                                                           isMirrored: info.isMirrored, request: request, index: 0, time: time)
            return person(frame.bodies)
        }
    }

    /// The largest body (by torso length) as a scan person.
    static func person(_ bodies: [BodyPose]) -> ScanPerson? {
        func torso(_ b: BodyPose) -> Double? {
            guard let ls = b.point(.leftShoulder), let rs = b.point(.rightShoulder), let lh = b.point(.leftHip), let rh = b.point(.rightHip) else { return nil }
            return hypot((ls.x + rs.x) / 2 - (lh.x + rh.x) / 2, (ls.y + rs.y) / 2 - (lh.y + rh.y) / 2)
        }
        guard let best = bodies.compactMap({ b in torso(b).map { (b, $0) } }).max(by: { $0.1 < $1.1 }) else { return nil }
        let b = best.0
        let hip: NormalizedPoint? = {
            guard let l = b.point(.leftHip), let r = b.point(.rightHip) else { return nil }
            return NormalizedPoint(x: (l.x + r.x) / 2, y: (l.y + r.y) / 2)
        }()
        return ScanPerson(leftAnkle: b.point(.leftAnkle).map { NormalizedPoint(x: $0.x, y: $0.y) },
                          rightAnkle: b.point(.rightAnkle).map { NormalizedPoint(x: $0.x, y: $0.y) },
                          hipCenter: hip, torsoLength: best.1)
    }
}
#endif
