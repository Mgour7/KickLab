#if canImport(Network) && canImport(CryptoKit)
import CryptoKit
import Foundation
import Network

// Build 24 — the remote-camera transport: Bonjour + TCP from Apple's Network framework
// (Multipeer Connectivity is deprecated from iOS 27; Apple's TN3213 points to Network).
// Peer-to-peer Wi-Fi is allowed, so the phones find each other on a field with no Wi-Fi
// network. Every frame is encrypted and authenticated with ChaChaPoly (CryptoKit) under a
// key derived from the six-digit pairing code; a phone without the code is dropped at its
// first frame.
//
// Concurrency: every Network object here is started on the main queue, so its callbacks
// arrive on the main thread; each callback converts what it received into plain Sendable
// values first and then enters the main actor with `MainActor.assumeIsolated` (which
// checks that it really is on the main thread). No unchecked-Sendable or unsafe
// isolation is used.

enum RemoteNetwork {
    static func parameters() -> NWParameters {
        let tcp = NWProtocolTCP.Options()
        tcp.noDelay = true
        tcp.enableKeepalive = true
        tcp.keepaliveIdle = 5
        let parameters = NWParameters(tls: nil, tcp: tcp)
        parameters.includePeerToPeer = true
        return parameters
    }

    static func key(code: String) -> SymmetricKey {
        HKDF<SHA256>.deriveKey(inputKeyMaterial: SymmetricKey(data: Data(code.utf8)), salt: RemotePairing.keySalt,
                               info: Data("frames".utf8), outputByteCount: 32)
    }
}

/// What a connection reports, as Sendable values.
enum RemoteChannelEvent: Equatable, Sendable {
    case ready
    case waiting(String)
    case closed(String?)
}

/// One encrypted, framed connection (either end).
@MainActor
final class RemoteChannel {
    let id = UUID()
    private let connection: NWConnection
    private let key: SymmetricKey
    private let sendContext: Data
    private let receiveContext: Data
    private var deframer = RemoteWire.Deframer()
    private var closed = false
    /// Bytes handed to the connection and not yet sent.
    private(set) var bufferedBytes = 0
    /// At least one frame decrypted: the other side has the code.
    private(set) var authenticated = false

    var onPayload: ((RemoteChannel, RemoteWire.Payload) -> Void)?
    var onEvent: ((RemoteChannel, RemoteChannelEvent) -> Void)?
    /// Called when the send buffer has room again (file streaming).
    var onDrained: ((RemoteChannel) -> Void)?

    init(connection: NWConnection, code: String, isController: Bool) {
        self.connection = connection
        key = RemoteNetwork.key(code: code)
        sendContext = isController ? RemotePairing.toCameraContext : RemotePairing.toControllerContext
        receiveContext = isController ? RemotePairing.toControllerContext : RemotePairing.toCameraContext
    }

    func start() {
        connection.stateUpdateHandler = { [weak self] state in
            let event = RemoteChannel.event(state)
            MainActor.assumeIsolated {
                guard let self, let event else { return }
                self.handle(event)
            }
        }
        connection.start(queue: .main)
        receive()
    }

    nonisolated static func event(_ state: NWConnection.State) -> RemoteChannelEvent? {
        switch state {
        case .ready: .ready
        case .waiting(let error): .waiting(error.localizedDescription)
        case .failed(let error): .closed(error.localizedDescription)
        case .cancelled: .closed(nil)
        default: nil
        }
    }

    private func handle(_ event: RemoteChannelEvent) {
        if case .closed = event {
            guard !closed else { return }
            closed = true
        }
        onEvent?(self, event)
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 1 << 20) { [weak self] data, _, isComplete, error in
            let failure = error.map(\.localizedDescription)
            MainActor.assumeIsolated {
                self?.received(data, isComplete: isComplete, failure: failure)
            }
        }
    }

    private func received(_ data: Data?, isComplete: Bool, failure: String?) {
        guard !closed else { return }
        if let data, !data.isEmpty {
            do {
                for sealed in try deframer.append(data) {
                    let body = try ChaChaPoly.open(ChaChaPoly.SealedBox(combined: sealed), using: key, authenticating: receiveContext)
                    authenticated = true
                    onPayload?(self, try RemoteWire.decode(body))
                    if closed { return }
                }
            } catch {
                close(reason: authenticated ? "The connection sent something KickLab couldn't read." : "The pairing code didn't match.")
                return
            }
        }
        if let failure {
            close(reason: failure)
        } else if isComplete {
            close(reason: nil)
        } else {
            receive()
        }
    }

    func send(_ payload: RemoteWire.Payload) {
        guard !closed else { return }
        let frame: Data
        do {
            let body = try RemoteWire.encode(payload)
            frame = RemoteWire.frame(try ChaChaPoly.seal(body, using: key, authenticating: sendContext).combined)
        } catch {
            close(reason: "A message couldn't be prepared.")
            return
        }
        let count = frame.count
        bufferedBytes += count
        connection.send(content: frame, completion: .contentProcessed { [weak self] error in
            let failure = error.map(\.localizedDescription)
            MainActor.assumeIsolated {
                self?.sent(count, failure: failure)
            }
        })
    }

    func send(_ message: RemoteMessage) { send(.message(message)) }

    private func sent(_ count: Int, failure: String?) {
        bufferedBytes -= count
        if let failure { close(reason: failure); return }
        if bufferedBytes < RemoteCapture.maximumBufferedBytes { onDrained?(self) }
    }

    var hasRoom: Bool { bufferedBytes < RemoteCapture.maximumBufferedBytes }

    func close(reason: String?) {
        guard !closed else { return }
        closed = true
        connection.cancel()
        onEvent?(self, .closed(reason))
    }
}

/// The controller's Bonjour listener: cameras connect to it.
@MainActor
final class RemoteListener {
    private var listener: NWListener?
    var onConnection: ((NWConnection) -> Void)?
    var onProblem: ((String?) -> Void)?

    func start(name: String) {
        stop()
        do {
            let l = try NWListener(using: RemoteNetwork.parameters())
            l.service = NWListener.Service(name: name, type: RemoteCapture.bonjourType)
            l.newConnectionHandler = { [weak self] connection in
                MainActor.assumeIsolated { self?.onConnection?(connection) }
            }
            l.stateUpdateHandler = { [weak self] state in
                let problem: String?? = switch state {
                case .failed(let e): .some(e.localizedDescription)
                case .waiting(let e): .some(e.localizedDescription)
                case .ready: .some(nil)
                default: .none
                }
                MainActor.assumeIsolated {
                    if let problem { self?.onProblem?(problem) }
                }
            }
            l.start(queue: .main)
            listener = l
        } catch {
            onProblem?(error.localizedDescription)
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }
}

/// A controller found nearby (camera side).
struct RemoteControllerFound: Identifiable, Equatable, Sendable {
    var name: String
    var endpoint: NWEndpoint
    var id: String { name }
}

/// The camera's Bonjour browser.
@MainActor
final class RemoteBrowser {
    private var browser: NWBrowser?
    var onResults: (([RemoteControllerFound]) -> Void)?
    var onProblem: ((String?) -> Void)?

    func start() {
        stop()
        let b = NWBrowser(for: .bonjour(type: RemoteCapture.bonjourType, domain: nil), using: RemoteNetwork.parameters())
        b.browseResultsChangedHandler = { [weak self] results, _ in
            let found = results.compactMap { r -> RemoteControllerFound? in
                guard case .service(let name, _, _, _) = r.endpoint else { return nil }
                return RemoteControllerFound(name: name, endpoint: r.endpoint)
            }.sorted { $0.name < $1.name }
            MainActor.assumeIsolated { self?.onResults?(found) }
        }
        b.stateUpdateHandler = { [weak self] state in
            let problem: String?? = switch state {
            case .failed(let e): .some(e.localizedDescription)
            case .waiting(let e): .some(e.localizedDescription)
            case .ready: .some(nil)
            default: .none
            }
            MainActor.assumeIsolated {
                if let problem { self?.onProblem?(problem) }
            }
        }
        b.start(queue: .main)
        browser = b
    }

    func stop() {
        browser?.cancel()
        browser = nil
    }

    static func connection(to found: RemoteControllerFound) -> NWConnection {
        NWConnection(to: found.endpoint, using: RemoteNetwork.parameters())
    }
}
#endif
