import Foundation

// Build 21 — Multi-kick discovery (Stage A) and clip boundaries.
//
// The single-kick contact detector assumes ONE kick per clip, so it is never run over a
// whole session. Stage A scans the recording sparsely (about 5 frames/s: football boxes
// from YOLOX-S and one body pose from Vision per frame) and looks for the signature of a
// kick: a ball at rest that leaves its spot quickly while a foot moves fast next to it.
// Stage B (the existing full analysis on a short clip) then verifies each candidate.
// See Docs/MULTI_KICK_DETECTION.md.

/// One football box in a scan frame (app-normalized displayed coordinates, 0…1).
struct ScanBall: Codable, Equatable, Sendable {
    var cx: Double
    var cy: Double
    var w: Double
    var h: Double
    var score: Double
}

/// The most prominent person in a scan frame.
struct ScanPerson: Codable, Equatable, Sendable {
    var leftAnkle: NormalizedPoint?
    var rightAnkle: NormalizedPoint?
    var hipCenter: NormalizedPoint?
    /// Shoulder-to-hip distance in the same normalized units (the speed scale).
    var torsoLength: Double?
}

/// One sparsely sampled frame of a session recording (source time, seconds).
struct SessionScanSample: Codable, Equatable, Sendable {
    var time: Double
    var balls: [ScanBall]
    var person: ScanPerson?
}

/// The scan's output for one candidate, before Stage B.
struct DiscoveredKick: Equatable, Sendable {
    var contactTime: Double
    var contactUncertainty: Double
    var evidence: CandidateEvidence
    /// Strong enough to verify automatically; otherwise listed for review.
    var autoVerify: Bool
    var restSpot: ScanBall?
    var approachStart: Double?
}

enum KickDiscovery {
    // Thresholds (documented in Docs/MULTI_KICK_DETECTION.md; provisional).
    static let minimumBallScore = 0.3
    /// A ball counts as "at rest" when it stays within this many ball widths of its median.
    static let restRadiusInBallWidths = 0.6
    /// …for at least this long.
    static let minimumRestSeconds = 0.6
    /// A ball seen again within this many ball widths of the spot soon after didn't leave.
    static let leaveDistanceInBallWidths = 2.0
    /// Seen within this time after leaving, moving less than `handledSpeed` = carried/rolled.
    static let handledWindowSeconds = 1.0
    /// Ball widths per second; slower than this is a hand or a roll, not a kick.
    static let handledSpeed = 6.0
    /// Peak ankle speed (torso lengths/s, measured between scan frames ≈ 0.2 s apart) that
    /// counts as a swing. Walking and jogging stay well below; a kicking swing peaks far
    /// above even when averaged over 0.2 s.
    static let swingSpeed = 5.0
    /// The fast foot must be this close to the ball spot (torso lengths).
    static let swingNearBallTorsoLengths = 1.5
    /// A swing counts if it peaks within this window around the departure.
    static let swingWindowSeconds = 0.5
    /// Two kicks are at least this far apart; closer candidates are one kick.
    static let minimumSeparationSeconds = 4.0
    /// Score at or above this verifies automatically (ball left + swing near it).
    static let autoVerifyScore = 4
    /// Below this the candidate isn't listed at all.
    static let minimumListedScore = 2

    // MARK: Stage A

    static func discover(_ samples: [SessionScanSample], marks: [Double] = []) -> [DiscoveredKick] {
        let s = samples.sorted { $0.time < $1.time }
        guard s.count >= 3 else { return [] }
        let step = medianStep(s)
        var found: [DiscoveredKick] = []

        // 1. Ball departures from rest spots.
        for rest in restSegments(s) {
            let lastRest = rest.lastTime
            let spot = rest.spot
            // What happened to the ball after the last at-rest sighting?
            let after = s.filter { $0.time > lastRest + 1e-9 && $0.time <= lastRest + handledWindowSeconds + 1e-9 }
            let near = after.filter { f in f.balls.contains { distanceInWidths($0, spot) <= leaveDistanceInBallWidths } }
            // Seen at the spot again soon after (a leg or body hid it for a moment) → it
            // didn't leave.
            if !near.isEmpty { continue }
            var evidence = CandidateEvidence(ballSeenAtRest: true)
            // A ball seen moving slowly away from the spot: handled or rolled.
            let slow = after.contains { f in
                f.balls.contains { b in
                    let d = distanceInWidths(b, spot)
                    return d > leaveDistanceInBallWidths && d / max(f.time - lastRest, step) < handledSpeed
                }
            }
            evidence.ballHandled = slow
            evidence.ballDeparted = !slow
            let departure = lastRest + step / 2
            let swing = swingNear(s, at: departure, spot: spot)
            evidence.swingSpeed = swing.speed
            evidence.swingNearBall = swing.nearBall
            let approach = approachStart(s, before: departure, spot: spot)
            evidence.approachSeen = approach != nil
            if slow { evidence.notes.append("The ball moved off slowly (placed, picked up or rolled).") }
            if !evidence.swingNearBall { evidence.notes.append(swing.speed == nil ? "No fast leg swing seen." : "A fast foot was seen, but not at the ball.") }
            found.append(DiscoveredKick(contactTime: departure, contactUncertainty: step, evidence: evidence, autoVerify: false,
                                        restSpot: spot, approachStart: approach))
        }

        // 2. Fast swings with no ball departure nearby (practice swing, or the ball wasn't seen).
        for peak in swingPeaks(s) where !found.contains(where: { abs($0.contactTime - peak.time) < minimumSeparationSeconds }) {
            var evidence = CandidateEvidence(swingSpeed: peak.speed)
            evidence.notes.append("A leg swing without a ball seen leaving — possibly a practice swing, or the ball wasn't visible.")
            evidence.approachSeen = approachStart(s, before: peak.time, spot: nil) != nil
            found.append(DiscoveredKick(contactTime: peak.time, contactUncertainty: step, evidence: evidence, autoVerify: false,
                                        restSpot: nil, approachStart: nil))
        }

        // 3. Manual marks near a candidate strengthen it; a mark alone is not a kick.
        for i in found.indices where marks.contains(where: { abs($0 - found[i].contactTime) <= 3 }) {
            found[i].evidence.manualMarkNearby = true
        }

        // 4. Classify, drop handled balls without a swing, deduplicate.
        var kept: [DiscoveredKick] = []
        for var k in found {
            let e = k.evidence
            if e.ballHandled && !e.swingNearBall { continue }
            if e.score < minimumListedScore { continue }
            k.autoVerify = e.ballDeparted && e.swingNearBall && e.score >= autoVerifyScore
            kept.append(k)
        }
        return deduplicate(kept)
    }

    /// Merges candidates closer than `minimumSeparationSeconds`, keeping the strongest
    /// (ties: the earlier).
    static func deduplicate(_ kicks: [DiscoveredKick]) -> [DiscoveredKick] {
        var out: [DiscoveredKick] = []
        for k in kicks.sorted(by: { $0.contactTime < $1.contactTime }) {
            if let last = out.last, k.contactTime - last.contactTime < minimumSeparationSeconds {
                if (k.evidence.score, k.autoVerify ? 1 : 0) > (last.evidence.score, last.autoVerify ? 1 : 0) { out[out.count - 1] = k }
                continue
            }
            out.append(k)
        }
        return out
    }

    // MARK: Pieces

    struct RestSegment: Equatable, Sendable {
        var spot: ScanBall
        var firstTime: Double
        var lastTime: Double
    }

    /// Runs of frames where a ball sits within `restRadiusInBallWidths` of one spot for at
    /// least `minimumRestSeconds`. A gap of up to two frames without the ball is tolerated
    /// (a leg passing in front of it).
    static func restSegments(_ s: [SessionScanSample]) -> [RestSegment] {
        let step = medianStep(s)
        var segments: [RestSegment] = []
        var open: [(spot: ScanBall, first: Double, last: Double, members: [ScanBall])] = []
        for f in s {
            let balls = f.balls.filter { $0.score >= minimumBallScore }
            var matched = Set<Int>()
            for b in balls {
                if let i = open.indices.first(where: { !matched.contains($0) && distanceInWidths(b, open[$0].spot) <= restRadiusInBallWidths }) {
                    open[i].last = f.time
                    open[i].members.append(b)
                    open[i].spot = median(open[i].members)
                    matched.insert(i)
                } else {
                    open.append((b, f.time, f.time, [b]))
                    matched.insert(open.count - 1)
                }
            }
            // Close runs not seen for more than two frames.
            var still: [(spot: ScanBall, first: Double, last: Double, members: [ScanBall])] = []
            for r in open {
                if f.time - r.last > 2.5 * step {
                    if r.last - r.first >= minimumRestSeconds - 1e-9 { segments.append(RestSegment(spot: r.spot, firstTime: r.first, lastTime: r.last)) }
                } else {
                    still.append(r)
                }
            }
            open = still
        }
        // Runs still open when the recording ends: the ball never left (not a departure).
        return segments.sorted { $0.lastTime < $1.lastTime }
    }

    /// The fastest ankle within `swingWindowSeconds` of `time`, and whether that ankle was
    /// near `spot` (torso-length scale) at its fastest.
    static func swingNear(_ s: [SessionScanSample], at time: Double, spot: ScanBall?) -> (speed: Double?, nearBall: Bool) {
        var best: (speed: Double, near: Bool)?
        for (a, b) in zip(s, s.dropFirst()) where b.time >= time - swingWindowSeconds && a.time <= time + swingWindowSeconds {
            for (pa, pb) in anklePairs(a.person, b.person) {
                guard let scale = b.person?.torsoLength ?? a.person?.torsoLength, scale > 0 else { continue }
                let dt = b.time - a.time
                guard dt > 0 else { continue }
                let speed = hypot(pb.x - pa.x, pb.y - pa.y) / scale / dt
                guard speed >= swingSpeed else { continue }
                var near = false
                if let spot {
                    let d = min(hypot(pa.x - spot.cx, pa.y - spot.cy), hypot(pb.x - spot.cx, pb.y - spot.cy)) / scale
                    near = d <= swingNearBallTorsoLengths
                }
                if best == nil || speed > best!.speed { best = (speed, near || (best?.near ?? false)) }
                else if near { best!.near = true }
            }
        }
        return (best?.speed, best?.near ?? false)
    }

    /// Ankle speed peaks above `swingSpeed`, at least `minimumSeparationSeconds` apart.
    static func swingPeaks(_ s: [SessionScanSample]) -> [(time: Double, speed: Double)] {
        var raw: [(time: Double, speed: Double)] = []
        for (a, b) in zip(s, s.dropFirst()) {
            guard let scale = b.person?.torsoLength ?? a.person?.torsoLength, scale > 0, b.time > a.time else { continue }
            let speeds = anklePairs(a.person, b.person).map { hypot($1.x - $0.x, $1.y - $0.y) / scale / (b.time - a.time) }
            if let v = speeds.max(), v >= swingSpeed { raw.append(((a.time + b.time) / 2, v)) }
        }
        var peaks: [(time: Double, speed: Double)] = []
        for r in raw {
            if let last = peaks.last, r.time - last.time < minimumSeparationSeconds {
                if r.speed > last.speed { peaks[peaks.count - 1] = r }
            } else {
                peaks.append(r)
            }
        }
        return peaks
    }

    /// When the hips started moving steadily toward the spot (or just moving, without a
    /// spot) in the 5 s before `time`: ≥ 0.5 torso lengths of travel.
    static func approachStart(_ s: [SessionScanSample], before time: Double, spot: ScanBall?) -> Double? {
        let window = s.filter { $0.time >= time - 5 && $0.time <= time && $0.person?.hipCenter != nil }
        guard let last = window.last?.person, let end = last.hipCenter, let scale = last.torsoLength, scale > 0 else { return nil }
        for f in window {
            guard let p = f.person?.hipCenter else { continue }
            let travel = hypot(end.x - p.x, end.y - p.y) / scale
            if travel >= 0.5 {
                if let spot {
                    let before = hypot(p.x - spot.cx, p.y - spot.cy), after = hypot(end.x - spot.cx, end.y - spot.cy)
                    guard after < before else { continue }
                }
                return f.time
            }
        }
        return nil
    }

    static func anklePairs(_ a: ScanPerson?, _ b: ScanPerson?) -> [(NormalizedPoint, NormalizedPoint)] {
        var out: [(NormalizedPoint, NormalizedPoint)] = []
        if let x = a?.leftAnkle, let y = b?.leftAnkle { out.append((x, y)) }
        if let x = a?.rightAnkle, let y = b?.rightAnkle { out.append((x, y)) }
        return out
    }

    static func distanceInWidths(_ b: ScanBall, _ spot: ScanBall) -> Double {
        hypot(b.cx - spot.cx, b.cy - spot.cy) / max(spot.w, 0.005)
    }

    static func median(_ balls: [ScanBall]) -> ScanBall {
        func med(_ v: [Double]) -> Double { let s = v.sorted(); return s[s.count / 2] }
        return ScanBall(cx: med(balls.map(\.cx)), cy: med(balls.map(\.cy)), w: med(balls.map(\.w)), h: med(balls.map(\.h)),
                        score: med(balls.map(\.score)))
    }

    static func medianStep(_ s: [SessionScanSample]) -> Double {
        let d = zip(s, s.dropFirst()).map { $1.time - $0.time }.filter { $0 > 0 }.sorted()
        return d.isEmpty ? 0.2 : d[d.count / 2]
    }
}

// MARK: - Clip boundaries

enum ClipBoundaryPolicy {
    static let preferredBefore = 4.0
    static let minimumBefore = 3.0
    static let maximumBefore = 5.0
    static let preferredAfter = 3.0
    static let minimumAfter = 2.0
    static let maximumAfter = 4.0
    /// Never cut closer than this before contact (the plant and strike happen here).
    static let protectedBefore = 1.5
    /// Never cut closer than this after contact (the strike and ball departure).
    static let protectedAfter = 1.0
    /// Stay this far after the previous kick's contact.
    static let gapAfterPreviousKick = 1.0

    struct Boundaries: Equatable, Sendable {
        var start: Double
        var end: Double
        var approachIncomplete: Bool
        var followThroughIncomplete: Bool
    }

    /// Clip boundaries (source time) around `contact`, adapted to the approach when known,
    /// limited by the recording and by neighbouring kicks — but never cutting into the
    /// protected plant/strike window just to keep a fixed duration.
    static func boundaries(contact: Double, approachStart: Double? = nil, sourceDuration: Double,
                           previousContact: Double? = nil, nextContact: Double? = nil) -> Boundaries {
        var start = contact - preferredBefore
        if let a = approachStart { start = min(start, a - 0.5) }
        start = max(start, contact - maximumBefore)
        if let p = previousContact { start = max(start, p + gapAfterPreviousKick) }
        start = max(0, min(start, contact - protectedBefore))
        if start < 0 { start = 0 }

        var end = contact + preferredAfter
        if let n = nextContact { end = min(end, n - protectedBefore - 0.1) }
        end = max(end, contact + protectedAfter)
        end = min(end, sourceDuration)

        return Boundaries(start: start, end: end,
                          approachIncomplete: contact - start < minimumBefore - 1e-9,
                          followThroughIncomplete: end - contact < minimumAfter - 1e-9)
    }
}

// MARK: - Stage B classification

enum CandidateVerification {
    /// What the full analysis of the candidate's clip says about it.
    static func status(analysisCompleted: Bool, contactOutcome: ContactOutcome?) -> CandidateStatus {
        guard analysisCompleted, let outcome = contactOutcome else { return .needsReview }
        switch outcome {
        case .ballVerifiedContact, .ballConstrainedContactInterval: return .confirmed
        case .poseEstimatedContact, .userSelectedContact: return .probable
        case .strikeWindowOnly, .contactUncertain, .contactUnavailable: return .needsReview
        }
    }
}
