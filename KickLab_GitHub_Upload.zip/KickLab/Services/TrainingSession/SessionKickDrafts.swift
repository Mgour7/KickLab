import Foundation

/// Build 21 — how a session candidate becomes a normal `Kick` (through the existing
/// `KickService` creation workflow), and quick result entry. Results, distance and hash
/// come only from what the athlete set — never from pose tracking.
enum SessionKickDrafts {
    /// The Kick for a candidate: the session's details at that moment, result "unknown"
    /// until the athlete enters it.
    static func draft(details: SessionKickDetails, timestamp: Date, id: UUID = UUID()) -> KickDraft {
        let distance = details.distanceYards.map { MeasuredValue.manual($0) }
        let outcome: KickOutcome
        switch details.kickType {
        case .pat: outcome = .pat(FieldGoalOutcome(result: .unknown, distance: distance))
        case .kickoff: outcome = .kickoff(KickoffOutcome(distance: nil))
        case .punt: outcome = .punt(PuntOutcome(distance: nil))
        case .fieldGoal, .unknown: outcome = .fieldGoal(FieldGoalOutcome(result: .unknown, distance: distance))
        }
        let goalpost = details.kickType == .fieldGoal || details.kickType == .pat || details.kickType == .unknown
        return KickDraft(id: id, timestamp: timestamp, outcome: outcome, context: nil, playingLevelAtKick: nil,
                         spotDistanceToTargetGoalLine: nil, hashLocation: goalpost ? details.hash : .notApplicable,
                         isReferenceKick: false, notes: nil,
                         details: KickEnteredDetails(ballType: details.ballType.flatMap(FootballType.init(rawValue:)),
                                                     conditions: details.conditions))
    }

    /// The results offered for one-tap entry.
    static let quickResults: [KickResult] = [.made, .missedLeft, .missedRight, .short, .unknown]

    /// The same outcome with a new result (field goals and PATs only; other kick types have
    /// no made/missed and are returned unchanged).
    static func outcome(_ outcome: KickOutcome, settingResult result: KickResult) -> KickOutcome {
        switch outcome {
        case .fieldGoal(var fg): fg.result = result; return .fieldGoal(fg)
        case .pat(var fg): fg.result = result; return .pat(fg)
        case .kickoff, .punt: return outcome
        }
    }

    /// The same outcome with a new distance (field goals/PATs keep their result).
    static func outcome(_ outcome: KickOutcome, settingDistance yards: Double?) -> KickOutcome {
        let d = yards.map { MeasuredValue.manual($0) }
        switch outcome {
        case .fieldGoal(var fg): fg.distance = d; return .fieldGoal(fg)
        case .pat(var fg): fg.distance = d; return .pat(fg)
        case .kickoff(var k): k.distance = d; return .kickoff(k)
        case .punt(var p): p.distance = d; return .punt(p)
        }
    }

    /// When the kick happened: the recording's start plus the contact time.
    static func timestamp(recordingStart: Date?, sessionCreated: Date, contactInSource: Double?) -> Date {
        (recordingStart ?? sessionCreated).addingTimeInterval(contactInSource ?? 0)
    }
}
