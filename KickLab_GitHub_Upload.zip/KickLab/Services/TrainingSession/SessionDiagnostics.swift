import Foundation

// Build 21 Hotfix 2 — Session Diagnostics export ("kicklab-session-diagnostics", v1).
//
// Everything needed to understand what a training session's kick finding and analysis
// decided, WITHOUT video by default: the cached Stage A scan (ball boxes and one body per
// sampled frame), every raw discovery event and why it was kept/merged/dropped, every
// candidate with its interval, contact (automatic and the athlete's, kept apart), clip
// timing as measured on the real files, queue state and errors. Each analyzed kick adds
// its existing Evidence Bundle v1 (pose, football, phases, gates) — that format is
// unchanged. Identifiers are replaced by export-local references; names, locations,
// athlete and record IDs are never written. See Docs/SESSION_DIAGNOSTICS.md.

struct SessionDiagnosticsReport: Codable, Equatable, Sendable {
    static let format = "kicklab-session-diagnostics"
    static let formatVersion = 1

    struct AppInfo: Codable, Equatable, Sendable {
        var appVersion: String?
        var appBuild: String?
        var osVersion: String?
        var engineVersion: String?
    }

    struct ScanCoverage: Codable, Equatable, Sendable {
        var status: String
        var error: String?
        var samples: Int
        var framesWithBall: Int
        var framesWithPerson: Int
        var framesWithBothAnkles: Int
        var samplingFramesPerSecond: Double?
    }

    struct Recording: Codable, Equatable, Sendable {
        var ref: String
        var camera: String
        var segmentNumber: Int
        var role: String
        var origin: String
        var status: String
        var durationSeconds: Double?
        var nominalFrameRate: Double?
        var capture: CaptureSelection?
        var sync: SourceSync
        var media: MediaTimingInfo?
        var scan: ScanCoverage
        var scanFile: String?
    }

    struct AnalysisEntry: Codable, Equatable, Sendable {
        var ref: String
        var engineVersion: String
        var status: String
        var isCurrent: Bool
        var userAssisted: Bool
        var failureReason: String?
        var createdAt: Date
        var evidenceFile: String?
    }

    struct KickRecord: Codable, Equatable, Sendable {
        var present: Bool
        var videoAngle: String?
        var clipMedia: MediaTimingInfo?
        /// The athlete's entered result (never evidence of contact).
        var enteredResult: String?
        var enteredDistanceYards: Double?
        var analyses: [AnalysisEntry]
    }

    struct Candidate: Codable, Equatable, Sendable {
        var ref: String
        var recording: String
        var discovery: String
        var hypothesis: String
        var status: String
        var statusText: String
        var evidence: CandidateEvidence
        var score: Int
        var startTime: Double
        var endTime: Double
        var approachIncomplete: Bool
        var followThroughIncomplete: Bool
        var contactTime: Double?
        var contactUncertainty: Double?
        var contactProvenance: String?
        var automaticContact: AutomaticContactRecord?
        var userContact: UserContactSelection?
        var clipStartInSource: Double?
        /// Recording seconds → clip seconds: clip = recording − clipStartInSource.
        var contactInClip: Double?
        var clipTiming: ClipTimingRecord?
        var analysisStatus: String
        var analysisAttempts: Int
        var lastError: String?
        var contactOutcome: String?
        var pairedWith: String?
        var kick: KickRecord?
    }

    var format = SessionDiagnosticsReport.format
    var formatVersion = SessionDiagnosticsReport.formatVersion
    var exportID: String
    var createdAt: Date
    var app: AppInfo
    var manifestVersion: Int
    var recordingContext: String
    var status: String
    var statusDetails: [String]
    var queuePaused: Bool
    var queue: [String: Int]
    var recordings: [Recording]
    var candidates: [Candidate]
    /// Raw Stage A events per recording ref, re-derived from the cached scan with the
    /// shipped thresholds.
    var discoveryTrace: [String: [DiscoveryTraceEntry]]
    var includedVideos: [String]
    var notes: [String]
}

/// Kick-side facts gathered by the app (SwiftData), passed in so the builder stays pure.
struct SessionDiagnosticsKickInput: Sendable {
    var videoAngle: String?
    var clipMedia: MediaTimingInfo?
    var enteredResult: String?
    var enteredDistanceYards: Double?
    var analyses: [(id: UUID, engineVersion: String, status: String, isCurrent: Bool, failureReason: String?, createdAt: Date, evidenceFile: String?)]
}

enum SessionDiagnosticsBuilder {
    /// - Parameters:
    ///   - scans: cached Stage A samples by source ID.
    ///   - media: measured timing by source ID.
    ///   - kicks: by candidate ID.
    static func make(_ m: TrainingSessionManifest, scans: [UUID: [SessionScanSample]], media: [UUID: MediaTimingInfo],
                     kicks: [UUID: SessionDiagnosticsKickInput], app: SessionDiagnosticsReport.AppInfo, exportID: String,
                     includedVideos: [String] = [], now: Date) -> SessionDiagnosticsReport {
        // Export-local references instead of IDs.
        var sourceRef: [UUID: String] = [:]
        var recordings: [SessionDiagnosticsReport.Recording] = []
        for (cameraIndex, camera) in m.cameraIDs.enumerated() {
            for (n, s) in m.segments(ofCamera: camera).enumerated() {
                let ref = "camera\(cameraIndex + 1)-recording\(n + 1)"
                sourceRef[s.id] = ref
                let samples = scans[s.id] ?? []
                recordings.append(.init(
                    ref: ref, camera: "camera\(cameraIndex + 1)", segmentNumber: n + 1, role: s.role.rawValue, origin: s.origin.rawValue,
                    status: s.status.rawValue, durationSeconds: s.durationSeconds, nominalFrameRate: s.nominalFrameRate, capture: s.capture,
                    sync: s.sync, media: media[s.id],
                    scan: coverage(samples, status: m.processing.scan[s.id.uuidString]?.rawValue ?? "notStarted",
                                   error: m.processing.scanError[s.id.uuidString]),
                    scanFile: samples.isEmpty ? nil : "scan/\(ref).csv"))
            }
        }
        let ordered = m.candidates.sorted { (sourceRef[$0.sourceID] ?? "", $0.startTime) < (sourceRef[$1.sourceID] ?? "", $1.startTime) }
        var candRef: [UUID: String] = [:]
        for (i, c) in ordered.enumerated() { candRef[c.id] = "candidate\(i + 1)" }
        var analysisRefs = 0
        let candidates: [SessionDiagnosticsReport.Candidate] = ordered.map { c in
            let partner = m.pairs.first { $0.primaryCandidateID == c.id || $0.secondaryCandidateID == c.id }
                .map { $0.primaryCandidateID == c.id ? $0.secondaryCandidateID : $0.primaryCandidateID }
            let kick: SessionDiagnosticsReport.KickRecord? = c.kickID.map { _ in
                let input = kicks[c.id]
                return SessionDiagnosticsReport.KickRecord(
                    present: input != nil, videoAngle: input?.videoAngle, clipMedia: input?.clipMedia,
                    enteredResult: input?.enteredResult, enteredDistanceYards: input?.enteredDistanceYards,
                    analyses: (input?.analyses ?? []).map { a in
                        analysisRefs += 1
                        return SessionDiagnosticsReport.AnalysisEntry(
                            ref: "analysis\(analysisRefs)", engineVersion: a.engineVersion, status: a.status, isCurrent: a.isCurrent,
                            userAssisted: a.engineVersion.hasSuffix("+assisted"), failureReason: a.failureReason,
                            createdAt: a.createdAt, evidenceFile: a.evidenceFile)
                    })
            }
            return SessionDiagnosticsReport.Candidate(
                ref: candRef[c.id] ?? "?", recording: sourceRef[c.sourceID] ?? "?", discovery: c.discovery.rawValue,
                hypothesis: DiscoveryHypothesis.of(c).rawValue, status: c.status.rawValue, statusText: SessionKickStatusText.line(c),
                evidence: c.evidence, score: c.evidence.score, startTime: c.startTime, endTime: c.endTime,
                approachIncomplete: c.approachIncomplete, followThroughIncomplete: c.followThroughIncomplete,
                contactTime: c.contactTime, contactUncertainty: c.contactUncertainty, contactProvenance: c.contactProvenance?.rawValue,
                automaticContact: c.automaticContact, userContact: c.userContact, clipStartInSource: c.clipStartInSource,
                contactInClip: c.contactTime.flatMap { t in c.clipStartInSource.map { ClipTimeMapping.clipTime(sourceTime: t, clipStartInSource: $0) } },
                clipTiming: c.clipTiming, analysisStatus: c.analysis.status.rawValue, analysisAttempts: c.analysis.attempts,
                lastError: c.analysis.lastError, contactOutcome: c.analysis.contactOutcome, pairedWith: partner.flatMap { candRef[$0] },
                kick: kick)
        }
        var trace: [String: [DiscoveryTraceEntry]] = [:]
        for s in m.sources {
            guard let samples = scans[s.id], let ref = sourceRef[s.id] else { continue }
            let marks = m.marks.filter { $0.sourceID == s.id }.map(\.sourceTime)
            trace[ref] = KickDiscovery.discoverWithTrace(samples, marks: marks).trace
        }
        let status = SessionStatus.make(m)
        let p = SessionProcessingQueue.progress(m)
        var notes = [
            "Times are seconds. Recording times are in each recording's own timeline; clip times in the kick clip's (clip = recording − clipStartInSource).",
            "contactProvenance 'user' means the athlete chose the frame; it is a timing judgement, not evidence that the ball moved.",
            "Entered results are what the athlete typed; they are not evidence of a detected strike.",
            "discoveryTrace is re-derived from the cached scan with the thresholds in this build; candidates may differ if the scan or thresholds changed since they were created.",
        ]
        if m.recordingContext == .net { notes.append("Recording context: kicking into a net (recorded only; no detection or scoring rule depends on it in this build).") }
        return SessionDiagnosticsReport(
            exportID: exportID, createdAt: now, app: app, manifestVersion: m.version,
            recordingContext: (m.recordingContext ?? .unknown).rawValue, status: status.headline, statusDetails: status.details,
            queuePaused: m.processing.paused, queue: ["queued": p.queued, "running": p.running, "done": p.done, "failed": p.failed],
            recordings: recordings, candidates: candidates, discoveryTrace: trace, includedVideos: includedVideos, notes: notes)
    }

    static func coverage(_ samples: [SessionScanSample], status: String, error: String?) -> SessionDiagnosticsReport.ScanCoverage {
        let steps = zip(samples, samples.dropFirst()).map { $1.time - $0.time }.filter { $0 > 0 }.sorted()
        let rate = steps.isEmpty ? nil : 1 / steps[steps.count / 2]
        return .init(status: status, error: error, samples: samples.count,
                     framesWithBall: samples.filter { !$0.balls.isEmpty }.count,
                     framesWithPerson: samples.filter { $0.person != nil }.count,
                     framesWithBothAnkles: samples.filter { $0.person?.leftAnkle != nil && $0.person?.rightAnkle != nil }.count,
                     samplingFramesPerSecond: rate.map { ($0 * 100).rounded() / 100 })
    }

    /// The cached scan as CSV: one row per sampled frame, the most confident ball and the
    /// selected person's ankles/hips (normalized display coordinates).
    static func scanCSV(_ samples: [SessionScanSample]) -> String {
        func f(_ v: Double?) -> String { v.map { String(format: "%.4f", $0) } ?? "" }
        var lines = ["time,balls,ball_cx,ball_cy,ball_w,ball_h,ball_score,left_ankle_x,left_ankle_y,right_ankle_x,right_ankle_y,hip_x,hip_y,torso"]
        for s in samples.sorted(by: { $0.time < $1.time }) {
            let b = s.balls.max { $0.score < $1.score }
            let p = s.person
            lines.append([f(s.time), "\(s.balls.count)", f(b?.cx), f(b?.cy), f(b?.w), f(b?.h), f(b?.score),
                          f(p?.leftAnkle?.x), f(p?.leftAnkle?.y), f(p?.rightAnkle?.x), f(p?.rightAnkle?.y),
                          f(p?.hipCenter?.x), f(p?.hipCenter?.y), f(p?.torsoLength)].joined(separator: ","))
        }
        return lines.joined(separator: "\n") + "\n"
    }

    static func readme(_ r: SessionDiagnosticsReport) -> String {
        """
        KickLab session diagnostics (\(SessionDiagnosticsReport.format) v\(SessionDiagnosticsReport.formatVersion))
        Export \(r.exportID) · \(r.recordings.count) recording(s) · \(r.candidates.count) candidate(s)

        session.json        everything below in one file (see Docs/SESSION_DIAGNOSTICS.md)
        scan/*.csv          the Stage A scan: one row per sampled frame (ball + body)
        evidence/*.zip      Evidence Bundle v1 of each analysis (pose, football, phases, gates)

        No names, locations, athlete or record IDs are included. Video is included only if you
        chose it when exporting; shared videos have sound and identifying metadata removed
        unless you chose to keep sound. Pose coordinates can still be sensitive.
        """
    }

    static func jsonEncoder() -> JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        e.dateEncodingStrategy = .iso8601
        return e
    }
}

/// What to share alongside the diagnostics ZIP (video only when chosen).
enum SessionDiagnosticVideoChoice: String, CaseIterable, Sendable {
    case none
    case selectedKick
    case allKickClips
    case originalRecordings

    var title: String {
        switch self {
        case .none: "No video (recommended)"
        case .selectedKick: "One kick's clip"
        case .allKickClips: "All kick clips"
        case .originalRecordings: "The original recordings"
        }
    }
}

/// Copies a video for sharing: video track only unless sound is wanted, identifying
/// metadata (location, device) removed. The original file is never modified.
protocol SharingVideoExporting: Sendable {
    func exportForSharing(source: URL, includeAudio: Bool, to destination: URL) async throws
}

struct UnavailableSharingVideoExporter: SharingVideoExporting {
    func exportForSharing(source: URL, includeAudio: Bool, to destination: URL) async throws {
        throw SessionMediaError.unavailable("Video sharing isn't available on this device.")
    }
}
