import Foundation

/// Build 21 — where training sessions live on disk, and safe reading/writing of manifests.
///
///     Application Support/KickLab/Sessions/<sessionID>/manifest.json
///     Application Support/KickLab/Sessions/<sessionID>/manifest.previous.json   (last good copy)
///     Application Support/KickLab/Sessions/<sessionID>/sources/<sourceID>.mov
///     Application Support/KickLab/Sessions/<sessionID>/scan/<sourceID>.json      (Stage A samples)
///
/// Outside `Media/` and `Analysis/`, so the orphan-file sweep never sees session footage.
/// Every manifest write is atomic (write to a temporary file, then replace), and the
/// previous version is kept, so a crash mid-write never loses the session.
struct TrainingSessionStore: Sendable {
    static let folderName = "Sessions"
    let rootURL: URL

    init(baseURL: URL) {
        rootURL = baseURL.appendingPathComponent(Self.folderName, isDirectory: true)
    }

    enum StoreError: Error, Equatable, Sendable {
        case unreadable(String)
        case newerVersion(Int)
        case writeFailed(String)
    }

    func directory(_ id: UUID) -> URL { rootURL.appendingPathComponent(id.uuidString, isDirectory: true) }
    func manifestURL(_ id: UUID) -> URL { directory(id).appendingPathComponent("manifest.json") }
    func previousManifestURL(_ id: UUID) -> URL { directory(id).appendingPathComponent("manifest.previous.json") }
    func url(session: UUID, relativePath: String) -> URL { directory(session).appendingPathComponent(relativePath) }
    func scanURL(session: UUID, source: UUID) -> URL { directory(session).appendingPathComponent("scan/\(source.uuidString).json") }

    static func encoder() -> JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        e.dateEncodingStrategy = .iso8601
        return e
    }

    static func decoder() -> JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }

    func prepare(_ id: UUID) throws {
        let fm = FileManager.default
        try fm.createDirectory(at: directory(id).appendingPathComponent("sources", isDirectory: true), withIntermediateDirectories: true)
        try fm.createDirectory(at: directory(id).appendingPathComponent("scan", isDirectory: true), withIntermediateDirectories: true)
    }

    func save(_ m: TrainingSessionManifest) throws {
        do {
            try prepare(m.id)
            let data = try Self.encoder().encode(m)
            let fm = FileManager.default
            let current = manifestURL(m.id)
            if fm.fileExists(atPath: current.path) {
                let previous = previousManifestURL(m.id)
                try? fm.removeItem(at: previous)
                try? fm.copyItem(at: current, to: previous)
            }
            try data.write(to: current, options: Self.writeOptions)
        } catch {
            throw StoreError.writeFailed(String(describing: error))
        }
    }

    /// Atomic, and on iOS protected until the phone is first unlocked after a restart
    /// (so a recording finishing on a locked phone can still be written).
    static var writeOptions: Data.WritingOptions {
        #if os(iOS)
        return [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
        #else
        return [.atomic]
        #endif
    }

    /// Reads a manifest, falling back to the previous good copy if the current one is damaged.
    func load(_ id: UUID) throws -> TrainingSessionManifest {
        for url in [manifestURL(id), previousManifestURL(id)] {
            guard let data = try? Data(contentsOf: url) else { continue }
            if let m = try? Self.decoder().decode(TrainingSessionManifest.self, from: data) {
                guard m.version <= TrainingSessionManifest.currentVersion else { throw StoreError.newerVersion(m.version) }
                return m
            }
        }
        throw StoreError.unreadable(id.uuidString)
    }

    /// Every session on disk, newest first. Damaged ones are skipped (never deleted).
    func loadAll() -> [TrainingSessionManifest] {
        guard let items = try? FileManager.default.contentsOfDirectory(at: rootURL, includingPropertiesForKeys: nil) else { return [] }
        return items.compactMap { UUID(uuidString: $0.lastPathComponent) }.compactMap { try? load($0) }.sorted { $0.createdAt > $1.createdAt }
    }

    /// At launch: recordings that were still "recording" (the app was terminated) are kept
    /// as recovered when their file exists, otherwise marked missing; interrupted analyses
    /// go back to the queue. Returns the sessions that changed.
    @discardableResult
    func recoverAfterLaunch() -> [UUID] {
        var changed: [UUID] = []
        for var m in loadAll() {
            let before = m
            SessionProcessingQueue.recoverAfterRelaunch(&m)
            for i in m.sources.indices where m.sources[i].status == .recovered || m.sources[i].status == .finalized {
                let url = url(session: m.id, relativePath: m.sources[i].relativePath)
                let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
                if size == 0 { m.sources[i].status = .missing }
                else if before.sources[i].status == .recording { m.sources[i].byteCount = size }
            }
            if m != before {
                if m.sources != before.sources {
                    m.log.append(SessionLogEntry(at: Date(), text: "Recovered after KickLab was closed during recording or analysis"))
                }
                try? save(m)
                changed.append(m.id)
            }
        }
        return changed
    }

    /// Deletes a source's file (callers check `TrainingSessionEditor.candidatesDependingOn`
    /// and ask the athlete first).
    func deleteSourceFile(session: UUID, relativePath: String) {
        try? FileManager.default.removeItem(at: url(session: session, relativePath: relativePath))
    }

    /// Bytes used by a session's files (recordings, manifest, scans).
    func byteCount(_ id: UUID) -> Int64 {
        guard let e = FileManager.default.enumerator(at: directory(id), includingPropertiesForKeys: [.fileSizeKey]) else { return 0 }
        var total: Int64 = 0
        for case let url as URL in e {
            total += Int64((try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
        return total
    }

    func saveScan(_ samples: [SessionScanSample], session: UUID, source: UUID) throws {
        try prepare(session)
        try Self.encoder().encode(samples).write(to: scanURL(session: session, source: source), options: Self.writeOptions)
    }

    func loadScan(session: UUID, source: UUID) -> [SessionScanSample]? {
        guard let data = try? Data(contentsOf: scanURL(session: session, source: source)) else { return nil }
        return try? Self.decoder().decode([SessionScanSample].self, from: data)
    }
}
