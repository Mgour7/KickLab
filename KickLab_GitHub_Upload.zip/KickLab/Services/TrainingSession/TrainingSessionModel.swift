import Foundation

// Build 21 — Training Sessions 1.0: the versioned, file-backed session manifest.
//
// A continuous recording is kept whole. Each kick found in it is a TIME INTERVAL in that
// recording (a "candidate"); a short clip is exported only when a candidate becomes a
// Kick for analysis. Nothing here is stored in SwiftData (schema V3 is unchanged): the
// manifest lives at `Application Support/KickLab/Sessions/<sessionID>/manifest.json`,
// outside the folders the orphan-file sweep scans. See Docs/TRAINING_SESSIONS.md.

/// Which way a camera looked at the kicker.
enum SessionCameraRole: String, Codable, CaseIterable, Sendable {
    case side
    case rear
    case unspecified

    var title: String {
        switch self {
        case .side: "Side view (Camera A)"
        case .rear: "Rear view (Camera B)"
        case .unspecified: "View not set"
        }
    }

    var angle: VideoAngleType {
        switch self {
        case .side: .side
        case .rear: .rear
        case .unspecified: .unknown
        }
    }
}

enum SessionSourceOrigin: String, Codable, Sendable {
    case inAppRecording
    case imported
}

enum SessionSourceStatus: String, Codable, Sendable {
    /// Being recorded right now (if seen at launch, the app was terminated mid-recording).
    case recording
    /// Finalized by AVFoundation (or a complete imported file).
    case finalized
    /// Found unfinished at launch; the file exists and was kept (readable up to the last
    /// written movie fragment).
    case recovered
    /// The file is gone or unreadable.
    case missing
}

/// How a source's time maps onto the session's shared timeline (the reference source's
/// own time). `sharedTime = sourceTime + offsetSeconds`. Raw timestamps never change.
struct SourceSync: Codable, Equatable, Sendable {
    enum Provenance: String, Codable, Sendable {
        /// This source IS the reference timeline.
        case reference
        /// The athlete marked the same event in both recordings.
        case manualEvent
        /// From the files' recording start times (device clocks): rough only.
        case wallClock
        /// Not synchronized.
        case none
    }

    var offsetSeconds: Double
    var provenance: Provenance
    /// ± seconds the two timelines may still disagree by.
    var uncertaintySeconds: Double?
    /// For `.manualEvent`: the two marks used.
    var referenceMarkTime: Double?
    var sourceMarkTime: Double?
    var setAt: Date?

    static let reference = SourceSync(offsetSeconds: 0, provenance: .reference, uncertaintySeconds: 0)
    static let unsynchronized = SourceSync(offsetSeconds: 0, provenance: .none, uncertaintySeconds: nil)
}

/// One recording in the session (camera A's in-app recording, or an imported file).
struct SessionSource: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var role: SessionCameraRole
    var origin: SessionSourceOrigin
    /// Relative to the session folder ("sources/<id>.mov").
    var relativePath: String
    var status: SessionSourceStatus
    var createdAt: Date
    var recordedAt: Date?
    var durationSeconds: Double?
    var nominalFrameRate: Double?
    var capture: CaptureSelection?
    var originalFilename: String?
    var byteCount: Int64?
    var sync: SourceSync
    var isReference: Bool { sync.provenance == .reference }
}

/// The athlete's settings for kicks (changeable between kicks; each kick keeps its own copy).
struct SessionKickDetails: Codable, Equatable, Sendable {
    var kickType: KickType = .fieldGoal
    var distanceYards: Double?
    var hash: HashLocation = .center
    var ballType: String?
    var conditions: String?

    var summary: String {
        var parts = [kickType.displayName]
        if let d = distanceYards { parts.append(DisplayFormat.yards(d)) }
        if kickType == .fieldGoal || kickType == .pat { parts.append(hash.displayName) }
        return parts.joined(separator: " · ")
    }
}

/// A change of defaults at a moment of the recording, so kicks before and after it keep
/// what was set when they happened.
struct SessionDefaultsChange: Codable, Equatable, Sendable {
    var sourceID: UUID
    var atSourceTime: Double
    var details: SessionKickDetails
}

/// A "Mark Kick" tap during recording (a hint for discovery; never a kick on its own).
struct SessionMark: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var sourceID: UUID
    var sourceTime: Double
    var createdAt: Date
}

enum CandidateDiscovery: String, Codable, Sendable {
    /// Found by the automatic scan.
    case automatic
    /// Added by the athlete.
    case manual
    /// Created by splitting or merging other candidates.
    case edited
}

enum CandidateStatus: String, Codable, Sendable, CaseIterable {
    /// Found by the scan, waiting for verification.
    case pending
    /// Analysis established contact with ball evidence.
    case confirmed
    /// Analysis established contact from body pose only.
    case probable
    /// Weak evidence, or analysis couldn't establish contact: the athlete decides.
    case needsReview
    /// Not a kick (false detection). Kept for the record; the recording isn't touched.
    case rejected
    /// The athlete marked it a practice swing.
    case practiceSwing

    var title: String {
        switch self {
        case .pending: "Checking"
        case .confirmed: "Confirmed"
        case .probable: "Probable"
        case .needsReview: "Needs review"
        case .rejected: "Not a kick"
        case .practiceSwing: "Practice swing"
        }
    }

    /// Counts as a kick attempt.
    var isKick: Bool { self == .confirmed || self == .probable }
    var isActive: Bool { self != .rejected && self != .practiceSwing }
}

/// What the scan saw (kept so the classification can be explained).
struct CandidateEvidence: Codable, Equatable, Sendable {
    var ballSeenAtRest = false
    /// The resting ball left its spot quickly.
    var ballDeparted = false
    /// The ball moved off slowly / was carried (handled, rolled, placed).
    var ballHandled = false
    /// Peak kicking-leg speed near the moment, in torso lengths per second (scan rate).
    var swingSpeed: Double?
    /// The fast foot was near the ball's spot.
    var swingNearBall = false
    var approachSeen = false
    var manualMarkNearby = false
    var notes: [String] = []

    var score: Int {
        (ballDeparted ? 2 : 0) + (swingNearBall ? 2 : (swingSpeed != nil ? 1 : 0)) + (approachSeen ? 1 : 0) + (manualMarkNearby ? 1 : 0)
    }
}

enum CandidateAnalysisStatus: String, Codable, Sendable {
    case notQueued, queued, running, done, failed
}

struct CandidateAnalysis: Codable, Equatable, Sendable {
    var status: CandidateAnalysisStatus = .notQueued
    var attempts = 0
    var lastError: String?
    var analysisID: UUID?
    var contactOutcome: String?
}

/// One kick (or possible kick) as an interval of a source recording.
struct SessionKickCandidate: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var sourceID: UUID
    var discovery: CandidateDiscovery
    var status: CandidateStatus
    var evidence: CandidateEvidence
    /// Source-time seconds.
    var startTime: Double
    var endTime: Double
    /// Best contact estimate (source time) and its ± uncertainty.
    var contactTime: Double?
    var contactUncertainty: Double?
    enum ContactProvenance: String, Codable, Sendable { case scan, analysis, user }
    var contactProvenance: ContactProvenance?
    /// The approach (≥ 3 s before contact) isn't in the clip.
    var approachIncomplete = false
    var followThroughIncomplete = false
    var boundariesEditedByUser = false
    var details: SessionKickDetails
    /// The Kick created for this candidate (one per candidate; reanalysis reuses it).
    var kickID: UUID?
    /// Source time of the exported clip's first frame (clip time + this = source time).
    var clipStartInSource: Double?
    var analysis = CandidateAnalysis()
    var createdAt: Date

    var duration: Double { endTime - startTime }
}

/// One physical kick seen by two cameras.
struct SessionKickPair: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    /// The candidate that is the attempt (owns the Kick record).
    var primaryCandidateID: UUID
    var secondaryCandidateID: UUID
    enum Provenance: String, Codable, Sendable { case automatic, manual }
    var provenance: Provenance
    /// |shared-time difference| between the two contacts when paired.
    var contactDifference: Double?
}

struct SessionLogEntry: Codable, Equatable, Sendable {
    var at: Date
    var text: String
}

struct SessionProcessing: Codable, Equatable, Sendable {
    enum ScanStatus: String, Codable, Sendable { case notStarted, scanning, done, failed }
    /// Keyed by source ID (uuidString).
    var scan: [String: ScanStatus] = [:]
    var scanError: [String: String] = [:]
    /// The athlete paused the analysis queue.
    var paused = false
    /// Sources (uuidString) whose kicks the athlete chose to keep as separate attempts
    /// without synchronizing (e.g. a different session filmed by another phone).
    var separateKicks: Set<String> = []
}

struct TrainingSessionManifest: Codable, Equatable, Sendable, Identifiable {
    static let currentVersion = 1

    var version = TrainingSessionManifest.currentVersion
    var id: UUID
    var athleteID: UUID
    /// The SwiftData `KickingSession` the session's kicks belong to.
    var kickingSessionID: UUID?
    var name: String
    var createdAt: Date
    var location: String?
    var defaults: SessionKickDetails
    var defaultsChanges: [SessionDefaultsChange] = []
    var sources: [SessionSource] = []
    var marks: [SessionMark] = []
    var candidates: [SessionKickCandidate] = []
    var pairs: [SessionKickPair] = []
    /// "primaryID|secondaryID" combinations the athlete said are NOT the same kick, so
    /// automatic pairing never re-creates them. (Optional: older v1 manifests lack it.)
    var declinedPairs: [String]?
    var processing = SessionProcessing()
    var log: [SessionLogEntry] = []

    var referenceSource: SessionSource? { sources.first(where: \.isReference) ?? sources.first }
    func source(_ id: UUID) -> SessionSource? { sources.first { $0.id == id } }
    func candidate(_ id: UUID) -> SessionKickCandidate? { candidates.first { $0.id == id } }

    /// The details in effect at a moment of a source (the last change at or before it).
    func details(sourceID: UUID, at time: Double) -> SessionKickDetails {
        defaultsChanges.filter { $0.sourceID == sourceID && $0.atSourceTime <= time + 1e-9 }
            .max { $0.atSourceTime < $1.atSourceTime }?.details ?? defaults
    }

    /// Candidates of a source in time order.
    func candidates(of sourceID: UUID) -> [SessionKickCandidate] {
        candidates.filter { $0.sourceID == sourceID }.sorted { ($0.contactTime ?? $0.startTime) < ($1.contactTime ?? $1.startTime) }
    }

    /// The attempts: active kicks, each physical kick once (a paired secondary is the same kick).
    var attempts: [SessionKickCandidate] {
        let secondaries = Set(pairs.map(\.secondaryCandidateID))
        return candidates.filter { $0.status.isKick && !secondaries.contains($0.id) }
            .sorted { sharedContact($0) < sharedContact($1) }
    }

    /// Marks ("Mark Kick" during recording) with no candidate near them — any status, so a
    /// kick the athlete already ruled out doesn't bring its mark back — once that recording
    /// has been scanned. A mark alone is not counted as a kick; Session Review offers these
    /// so the athlete can add the kick by hand or dismiss the mark.
    var unmatchedMarks: [SessionMark] {
        marks.filter { mark in
            processing.scan[mark.sourceID.uuidString] == .done
                && !candidates.contains { c in
                    c.sourceID == mark.sourceID
                        && mark.sourceTime >= c.startTime - Self.markMatchSeconds
                        && mark.sourceTime <= c.endTime + Self.markMatchSeconds
                }
        }
        .sorted { $0.sourceTime < $1.sourceTime }
    }

    /// A mark this close to a candidate's clip belongs to it (people tap after the kick).
    static let markMatchSeconds = 3.0

    /// Contact (or interval start) on the shared timeline.
    func sharedContact(_ c: SessionKickCandidate) -> Double {
        (c.contactTime ?? c.startTime) + (source(c.sourceID)?.sync.offsetSeconds ?? 0)
    }
}
