import Foundation

// Build 21 — Training Sessions 1.0: the versioned, file-backed session manifest.
//
// A continuous recording is kept whole. Each kick found in it is a TIME INTERVAL in that
// recording (a "candidate"); a short clip is exported only when a candidate becomes a
// Kick for analysis. Nothing here is stored in SwiftData (schema V3 is unchanged): the
// manifest lives at `Application Support/KickLab/Sessions/<sessionID>/manifest.json`,
// outside the folders the orphan-file sweep scans. See Docs/TRAINING_SESSIONS.md.

/// Which way a camera looked at the kicker.
enum SessionCameraRole: String, Codable, CaseIterable, Sendable {
    case side
    case rear
    case unspecified

    var title: String {
        switch self {
        case .side: "Side view (Camera A)"
        case .rear: "Rear view (Camera B)"
        case .unspecified: "View not set (detected from the movement)"
        }
    }

    var angle: VideoAngleType {
        switch self {
        case .side: .side
        case .rear: .rear
        case .unspecified: .unknown
        }
    }
}

/// Hotfix 2: where the kicks went. Recorded for diagnostics and review; it changes no
/// score, gate or detection threshold (see Docs/NET_PRACTICE.md).
enum RecordingContext: String, Codable, CaseIterable, Sendable {
    case openField
    case net
    case unknown

    var title: String {
        switch self {
        case .openField: "Open field"
        case .net: "Kicking into a net"
        case .unknown: "Not specified"
        }
    }
}

enum SessionSourceOrigin: String, Codable, Sendable {
    case inAppRecording
    case imported
}

enum SessionSourceStatus: String, Codable, Sendable {
    /// Being recorded right now (if seen at launch, the app was terminated mid-recording).
    case recording
    /// Finalized by AVFoundation (or a complete imported file).
    case finalized
    /// Found unfinished at launch; the file exists and was kept (readable up to the last
    /// written movie fragment).
    case recovered
    /// The file is gone or unreadable.
    case missing
}

/// How a source's time maps onto the session's shared timeline (the reference source's
/// own time). `sharedTime = sourceTime + offsetSeconds`. Raw timestamps never change.
struct SourceSync: Codable, Equatable, Sendable {
    enum Provenance: String, Codable, Sendable {
        /// This source IS the reference timeline.
        case reference
        /// The athlete marked the same event in both recordings.
        case manualEvent
        /// From the files' recording start times (device clocks): rough only.
        case wallClock
        /// A later recording made on THIS iPhone in the same session: the same camera, so
        /// it continues camera A's timeline from its start time (same clock) — no manual
        /// sync. (Build 21 hotfix.)
        case sameCamera
        /// Build 24: recorded by a KickLab remote camera controlled from this iPhone. Each
        /// camera's recording start was measured on this iPhone's clock (network clock
        /// exchange + the camera's first-frame time), so it is on the timeline without
        /// marking an event. The athlete can still refine it by marking an event.
        case sharedClock
        /// Not synchronized.
        case none
    }

    var offsetSeconds: Double
    var provenance: Provenance
    /// ± seconds the two timelines may still disagree by.
    var uncertaintySeconds: Double?
    /// For `.manualEvent`: the two marks used.
    var referenceMarkTime: Double?
    var sourceMarkTime: Double?
    var setAt: Date?

    static let reference = SourceSync(offsetSeconds: 0, provenance: .reference, uncertaintySeconds: 0)
    static let unsynchronized = SourceSync(offsetSeconds: 0, provenance: .none, uncertaintySeconds: nil)
}

/// One recording in the session (camera A's in-app recording, or an imported file).
struct SessionSource: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var role: SessionCameraRole
    var origin: SessionSourceOrigin
    /// Relative to the session folder ("sources/<id>.mov").
    var relativePath: String
    var status: SessionSourceStatus
    var createdAt: Date
    var recordedAt: Date?
    var durationSeconds: Double?
    var nominalFrameRate: Double?
    var capture: CaptureSelection?
    var originalFilename: String?
    var byteCount: Int64?
    var sync: SourceSync
    /// The first recording of the same physical camera when this one is a later segment of
    /// it (Build 21 hotfix; nil in manifests written before, see `normalizeCameraSegments`).
    var cameraGroup: UUID?
    /// Build 24: set when the recording came from a KickLab remote camera (nil otherwise,
    /// and in manifests written before).
    var remote: RemoteSourceInfo? = nil
    var isReference: Bool { sync.provenance == .reference }
}

/// The athlete's settings for kicks (changeable between kicks; each kick keeps its own copy).
struct SessionKickDetails: Codable, Equatable, Sendable {
    var kickType: KickType = .fieldGoal
    var distanceYards: Double?
    var hash: HashLocation = .center
    var ballType: String?
    var conditions: String?

    var summary: String {
        var parts = [kickType.displayName]
        if let d = distanceYards { parts.append(DisplayFormat.yards(d)) }
        if kickType == .fieldGoal || kickType == .pat { parts.append(hash.displayName) }
        return parts.joined(separator: " · ")
    }
}

/// A change of defaults at a moment of the recording, so kicks before and after it keep
/// what was set when they happened.
struct SessionDefaultsChange: Codable, Equatable, Sendable {
    var sourceID: UUID
    var atSourceTime: Double
    var details: SessionKickDetails
}

/// A "Mark Kick" tap during recording (a hint for discovery; never a kick on its own).
struct SessionMark: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var sourceID: UUID
    var sourceTime: Double
    var createdAt: Date
}

enum CandidateDiscovery: String, Codable, Sendable {
    /// Found by the automatic scan.
    case automatic
    /// Added by the athlete.
    case manual
    /// Created by splitting or merging other candidates.
    case edited
}

enum CandidateStatus: String, Codable, Sendable, CaseIterable {
    /// Found by the scan, waiting for verification.
    case pending
    /// Analysis established contact with ball evidence.
    case confirmed
    /// Analysis established contact from body pose only.
    case probable
    /// Weak evidence, or analysis couldn't establish contact: the athlete decides.
    case needsReview
    /// Not a kick (false detection). Kept for the record; the recording isn't touched.
    case rejected
    /// The athlete marked it a practice swing.
    case practiceSwing

    var title: String {
        switch self {
        case .pending: "Checking"
        case .confirmed: "Confirmed"
        case .probable: "Probable"
        case .needsReview: "Needs review"
        case .rejected: "Not a kick"
        case .practiceSwing: "Practice swing"
        }
    }

    /// Counts as a kick attempt.
    var isKick: Bool { self == .confirmed || self == .probable }
    var isActive: Bool { self != .rejected && self != .practiceSwing }
}

/// What the scan saw (kept so the classification can be explained).
struct CandidateEvidence: Codable, Equatable, Sendable {
    var ballSeenAtRest = false
    /// The resting ball left its spot quickly.
    var ballDeparted = false
    /// The ball moved off slowly / was carried (handled, rolled, placed).
    var ballHandled = false
    /// Peak kicking-leg speed near the moment, in torso lengths per second (scan rate).
    var swingSpeed: Double?
    /// The fast foot was near the ball's spot.
    var swingNearBall = false
    var approachSeen = false
    var manualMarkNearby = false
    var notes: [String] = []

    var score: Int {
        (ballDeparted ? 2 : 0) + (swingNearBall ? 2 : (swingSpeed != nil ? 1 : 0)) + (approachSeen ? 1 : 0) + (manualMarkNearby ? 1 : 0)
    }
}

enum CandidateAnalysisStatus: String, Codable, Sendable {
    case notQueued, queued, running, done, failed
}

struct CandidateAnalysis: Codable, Equatable, Sendable {
    var status: CandidateAnalysisStatus = .notQueued
    var attempts = 0
    var lastError: String?
    var analysisID: UUID?
    var contactOutcome: String?
}

/// One kick (or possible kick) as an interval of a source recording.
struct SessionKickCandidate: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var sourceID: UUID
    var discovery: CandidateDiscovery
    var status: CandidateStatus
    var evidence: CandidateEvidence
    /// Source-time seconds.
    var startTime: Double
    var endTime: Double
    /// Best contact estimate (source time) and its ± uncertainty.
    var contactTime: Double?
    var contactUncertainty: Double?
    enum ContactProvenance: String, Codable, Sendable { case scan, analysis, user }
    var contactProvenance: ContactProvenance?
    /// The approach (≥ 3 s before contact) isn't in the clip.
    var approachIncomplete = false
    var followThroughIncomplete = false
    var boundariesEditedByUser = false
    var details: SessionKickDetails
    /// The Kick created for this candidate (one per candidate; reanalysis reuses it).
    var kickID: UUID?
    /// Source time of the exported clip's first frame (clip time + this = source time).
    var clipStartInSource: Double?
    var analysis = CandidateAnalysis()
    var createdAt: Date
    /// Hotfix 2: the last AUTOMATIC contact result, kept for comparison after a correction.
    var automaticContact: AutomaticContactRecord?
    /// Hotfix 2: the contact frame the athlete chose (kept until changed again).
    var userContact: UserContactSelection?
    /// Hotfix 2: how the exported clip's timeline relates to the recording, as measured.
    var clipTiming: ClipTimingRecord?

    var duration: Double { endTime - startTime }
}

/// What the automatic analysis said about contact (source and clip time).
struct AutomaticContactRecord: Codable, Equatable, Sendable {
    var sourceTime: Double?
    var clipTime: Double?
    var uncertainty: Double?
    /// `ContactOutcome` raw value, e.g. "ballVerified", "notEstablished".
    var outcome: String?
    var analysisID: UUID?
    var recordedAt: Date
}

/// The athlete's contact frame. It is a human judgement of timing — never evidence that the
/// ball moved — and is passed to the engine as a user-assisted contact.
struct UserContactSelection: Codable, Equatable, Sendable {
    enum Timeline: String, Codable, Sendable {
        /// Chosen while watching the kick's own clip (the engine's timeline).
        case kickClip
        /// Chosen in the original recording (mapped through the clip start).
        case sourceRecording
    }
    var sourceTime: Double
    /// In the kick clip's presentation timeline, when known.
    var clipTime: Double?
    var timeline: Timeline
    /// ± seconds: one frame of the video it was chosen in.
    var uncertainty: Double
    var selectedAt: Date
    /// Set when a reanalysis with this contact was requested / finished.
    var reanalysisRequestedAt: Date?
    var reanalyzedAt: Date?
    var analysisID: UUID?
    /// Plain-language result of the last reanalysis (or why it failed).
    var lastResult: String?
}

/// Measured timing of an exported kick clip (see Docs/CONTACT_CORRECTION.md).
struct ClipTimingRecord: Codable, Equatable, Sendable {
    /// The source time asked for as clip time 0.
    var requestedStart: Double
    var requestedDuration: Double
    /// Duration of the exported file as AVFoundation reports it.
    var exportedDuration: Double?
    /// First presented video frame time in the clip (expected ≈ 0 with an edit list).
    var firstFrameTime: Double?
    var editSegmentCount: Int?
    var nominalFrameRate: Double?
    /// A note when the measurement disagrees with the expected mapping.
    var warning: String?
}

/// One physical kick seen by two cameras.
struct SessionKickPair: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    /// The candidate that is the attempt (owns the Kick record).
    var primaryCandidateID: UUID
    var secondaryCandidateID: UUID
    enum Provenance: String, Codable, Sendable { case automatic, manual }
    var provenance: Provenance
    /// |shared-time difference| between the two contacts when paired.
    var contactDifference: Double?
}

struct SessionLogEntry: Codable, Equatable, Sendable {
    var at: Date
    var text: String
}

struct SessionProcessing: Codable, Equatable, Sendable {
    enum ScanStatus: String, Codable, Sendable { case notStarted, scanning, done, failed }
    /// Keyed by source ID (uuidString).
    var scan: [String: ScanStatus] = [:]
    var scanError: [String: String] = [:]
    /// The athlete paused the analysis queue.
    var paused = false
    /// Sources (uuidString) whose kicks the athlete chose to keep as separate attempts
    /// without synchronizing (e.g. a different session filmed by another phone).
    var separateKicks: Set<String> = []
}

struct TrainingSessionManifest: Codable, Equatable, Sendable, Identifiable {
    static let currentVersion = 1

    var version = TrainingSessionManifest.currentVersion
    var id: UUID
    var athleteID: UUID
    /// The SwiftData `KickingSession` the session's kicks belong to.
    var kickingSessionID: UUID?
    var name: String
    var createdAt: Date
    var location: String?
    var defaults: SessionKickDetails
    var defaultsChanges: [SessionDefaultsChange] = []
    var sources: [SessionSource] = []
    var marks: [SessionMark] = []
    var candidates: [SessionKickCandidate] = []
    var pairs: [SessionKickPair] = []
    /// Hotfix 2 (optional: older manifests lack them).
    var recordingContext: RecordingContext?
    /// The camera view chosen before recording (used for the first recording).
    var plannedCameraRole: SessionCameraRole?
    /// "primaryID|secondaryID" combinations the athlete said are NOT the same kick, so
    /// automatic pairing never re-creates them. (Optional: older v1 manifests lack it.)
    var declinedPairs: [String]?
    var processing = SessionProcessing()
    var log: [SessionLogEntry] = []

    var referenceSource: SessionSource? { sources.first(where: \.isReference) ?? sources.first }
    func source(_ id: UUID) -> SessionSource? { sources.first { $0.id == id } }
    func candidate(_ id: UUID) -> SessionKickCandidate? { candidates.first { $0.id == id } }

    /// The details in effect at a moment of a source (the last change at or before it).
    func details(sourceID: UUID, at time: Double) -> SessionKickDetails {
        defaultsChanges.filter { $0.sourceID == sourceID && $0.atSourceTime <= time + 1e-9 }
            .max { $0.atSourceTime < $1.atSourceTime }?.details ?? defaults
    }

    /// Candidates of a source in time order.
    func candidates(of sourceID: UUID) -> [SessionKickCandidate] {
        candidates.filter { $0.sourceID == sourceID }.sorted { ($0.contactTime ?? $0.startTime) < ($1.contactTime ?? $1.startTime) }
    }

    // MARK: Cameras and recording segments (Build 21 hotfix)

    /// The camera a recording belongs to (the ID of that camera's first recording). Several
    /// in-app recordings in one session are segments of ONE camera (this iPhone), not
    /// separate camera angles. Imports are their own camera unless set otherwise.
    func cameraID(of s: SessionSource) -> UUID {
        if let g = cameraGroup(s) { return g }
        return s.id
    }

    private func cameraGroup(_ s: SessionSource) -> UUID? {
        if let g = s.cameraGroup { return g }
        guard s.origin == .inAppRecording, let first = sources.first(where: { $0.origin == .inAppRecording }), first.id != s.id else { return nil }
        return first.cameraGroup ?? first.id
    }

    /// Camera A: the camera of the reference recording.
    var primaryCameraID: UUID? { referenceSource.map(cameraID(of:)) }

    /// The recordings of one camera, in recording order.
    func segments(ofCamera id: UUID) -> [SessionSource] {
        sources.filter { cameraID(of: $0) == id }
    }

    /// Distinct cameras in first-recording order.
    var cameraIDs: [UUID] {
        var seen: [UUID] = []
        for s in sources where !seen.contains(cameraID(of: s)) { seen.append(cameraID(of: s)) }
        return seen
    }

    /// True for a second, third… recording of the same camera.
    func isLaterSegment(_ s: SessionSource) -> Bool { cameraID(of: s) != s.id }

    /// The attempts: active kicks, each physical kick once (a paired secondary is the same kick).
    var attempts: [SessionKickCandidate] {
        let secondaries = Set(pairs.map(\.secondaryCandidateID))
        return candidates.filter { $0.status.isKick && !secondaries.contains($0.id) }
            .sorted { sharedContact($0) < sharedContact($1) }
    }

    /// Marks ("Mark Kick" during recording) with no candidate near them — any status, so a
    /// kick the athlete already ruled out doesn't bring its mark back — once that recording
    /// has been scanned. A mark alone is not counted as a kick; Session Review offers these
    /// so the athlete can add the kick by hand or dismiss the mark.
    var unmatchedMarks: [SessionMark] {
        marks.filter { mark in
            processing.scan[mark.sourceID.uuidString] == .done
                && !candidates.contains { c in
                    c.sourceID == mark.sourceID
                        && mark.sourceTime >= c.startTime - Self.markMatchSeconds
                        && mark.sourceTime <= c.endTime + Self.markMatchSeconds
                }
        }
        .sorted { $0.sourceTime < $1.sourceTime }
    }

    /// A mark this close to a candidate's clip belongs to it (people tap after the kick).
    static let markMatchSeconds = 3.0

    /// Contact (or interval start) on the shared timeline.
    func sharedContact(_ c: SessionKickCandidate) -> Double {
        (c.contactTime ?? c.startTime) + (source(c.sourceID)?.sync.offsetSeconds ?? 0)
    }
}
