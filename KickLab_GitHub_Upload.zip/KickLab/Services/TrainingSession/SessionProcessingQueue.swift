import Foundation

/// Build 21 — the session's analysis queue, persisted in the manifest so it survives a
/// relaunch. One candidate at a time (bounded: recording and the UI stay responsive; the
/// phone's pose/ML hardware is shared). The executor (Apple) asks `next`, exports the clip,
/// creates or reuses the Kick, runs the existing analysis and reports back.
enum SessionProcessingQueue {
    /// Most attempts per candidate before it is left as failed (the athlete can retry).
    static let maximumAttempts = 2

    /// Queues every candidate that should be analyzed: pending (strong scan evidence,
    /// added or accepted by the athlete) and not yet analyzed.
    ///
    /// A second camera's candidates wait until that camera is synchronized (so its kicks
    /// can be paired with camera A's instead of counted twice) — unless the athlete chose
    /// to keep that recording's kicks separate (`separateKicks`).
    static func enqueueReady(_ m: inout TrainingSessionManifest) {
        for i in m.candidates.indices {
            let c = m.candidates[i]
            guard c.status == .pending, c.analysis.status == .notQueued || (c.analysis.status == .failed && c.analysis.attempts < maximumAttempts) else { continue }
            guard let source = m.source(c.sourceID), source.isReference || source.sync.provenance != .none || m.processing.separateKicks.contains(source.id.uuidString) else { continue }
            m.candidates[i].analysis.status = .queued
        }
    }

    /// For a paired SECONDARY candidate, the primary's Kick (its clip is attached there
    /// as a second camera angle instead of becoming another Kick). Nil otherwise.
    static func primaryKickForSecondary(_ m: TrainingSessionManifest, _ c: SessionKickCandidate) -> UUID?? {
        guard let pair = m.pairs.first(where: { $0.secondaryCandidateID == c.id }) else { return nil }
        return .some(m.candidate(pair.primaryCandidateID)?.kickID)
    }

    /// `VideoAsset.syncOffsetSeconds` for a secondary clip: secondary clip time =
    /// primary clip time − offset (both clips mapped through the session's shared timeline).
    static func secondaryClipOffset(primaryClipStart: Double, primarySync: SourceSync, secondaryClipStart: Double, secondarySync: SourceSync) -> Double {
        (secondaryClipStart + secondarySync.offsetSeconds) - (primaryClipStart + primarySync.offsetSeconds)
    }

    /// Explicit reanalysis of one kick (reuses its Kick and clip; never a duplicate).
    static func requeue(_ m: inout TrainingSessionManifest, candidateID: UUID) {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }), m.candidates[i].analysis.status != .running else { return }
        m.candidates[i].analysis.status = .queued
        m.candidates[i].analysis.attempts = 0
        if m.candidates[i].status == .needsReview { m.candidates[i].status = .pending }
    }

    static func next(_ m: TrainingSessionManifest) -> SessionKickCandidate? {
        guard !m.processing.paused, !m.candidates.contains(where: { $0.analysis.status == .running }) else { return nil }
        // A paired secondary waits until its primary has a Kick to attach to.
        return m.candidates.filter { c in
            guard c.analysis.status == .queued, c.status.isActive else { return false }
            if case .some(let primaryKick) = primaryKickForSecondary(m, c) { return primaryKick != nil }
            return true
        }
            .sorted { ($0.contactTime ?? $0.startTime) < ($1.contactTime ?? $1.startTime) }.first
    }

    static func markRunning(_ m: inout TrainingSessionManifest, _ id: UUID) {
        guard let i = m.candidates.firstIndex(where: { $0.id == id }) else { return }
        m.candidates[i].analysis.status = .running
        m.candidates[i].analysis.attempts += 1
    }

    /// The Kick and clip exist (recorded before the analysis runs, so a relaunch reuses them).
    static func recordMaterialized(_ m: inout TrainingSessionManifest, _ id: UUID, kickID: UUID, clipStartInSource: Double) {
        guard let i = m.candidates.firstIndex(where: { $0.id == id }) else { return }
        m.candidates[i].kickID = kickID
        m.candidates[i].clipStartInSource = clipStartInSource
    }

    /// The analysis finished: Stage B decides the candidate's status. A contact found by
    /// the analysis replaces the scan's estimate (mapped to source time) unless the
    /// athlete confirmed it.
    static func recordAnalysis(_ m: inout TrainingSessionManifest, _ id: UUID, analysisID: UUID?, completed: Bool,
                               contactOutcome: ContactOutcome?, clipContact: Double?, contactUncertainty: Double?, now: Date) {
        guard let i = m.candidates.firstIndex(where: { $0.id == id }) else { return }
        m.candidates[i].analysis.status = .done
        m.candidates[i].analysis.analysisID = analysisID
        m.candidates[i].analysis.contactOutcome = contactOutcome?.rawValue
        m.candidates[i].analysis.lastError = nil
        if m.candidates[i].status.isActive {
            m.candidates[i].status = CandidateVerification.status(analysisCompleted: completed, contactOutcome: contactOutcome)
        }
        if m.candidates[i].contactProvenance != .user, let c = clipContact, let start = m.candidates[i].clipStartInSource {
            m.candidates[i].contactTime = ClipTimeMapping.sourceTime(clipTime: c, clipStartInSource: start)
            m.candidates[i].contactUncertainty = contactUncertainty
            m.candidates[i].contactProvenance = .analysis
        }
        m.log.append(SessionLogEntry(at: now, text: "Kick analyzed: \(m.candidates[i].status.title)"))
    }

    /// A paired secondary's clip was attached to the primary's Kick: same status as the
    /// primary, no separate analysis (multi-view analysis is future work).
    static func recordAttached(_ m: inout TrainingSessionManifest, _ id: UUID, toKick kickID: UUID, clipStartInSource: Double, now: Date) {
        guard let i = m.candidates.firstIndex(where: { $0.id == id }) else { return }
        m.candidates[i].kickID = kickID
        m.candidates[i].clipStartInSource = clipStartInSource
        m.candidates[i].analysis.status = .done
        if let pair = m.pairs.first(where: { $0.secondaryCandidateID == id }), let primary = m.candidate(pair.primaryCandidateID), primary.status.isKick {
            m.candidates[i].status = primary.status
        } else if m.candidates[i].status == .pending {
            m.candidates[i].status = .probable
        }
        m.log.append(SessionLogEntry(at: now, text: "Second camera's clip added to the same kick"))
    }

    static func recordFailure(_ m: inout TrainingSessionManifest, _ id: UUID, error: String, now: Date) {
        guard let i = m.candidates.firstIndex(where: { $0.id == id }) else { return }
        let c = m.candidates[i]
        m.candidates[i].analysis.status = c.analysis.attempts < maximumAttempts ? .queued : .failed
        m.candidates[i].analysis.lastError = error
        if m.candidates[i].analysis.status == .failed { m.candidates[i].status = c.status == .pending ? .needsReview : c.status }
        m.log.append(SessionLogEntry(at: now, text: "Analysis failed: \(error)"))
    }

    /// After a relaunch (or when iOS stopped KickLab mid-analysis), a running item goes
    /// back to the queue; nothing finished is redone.
    static func recoverAfterRelaunch(_ m: inout TrainingSessionManifest) {
        for i in m.candidates.indices where m.candidates[i].analysis.status == .running {
            m.candidates[i].analysis.status = .queued
        }
        for (k, v) in m.processing.scan where v == .scanning { m.processing.scan[k] = .notStarted }
        for i in m.sources.indices where m.sources[i].status == .recording { m.sources[i].status = .recovered }
    }

    struct Progress: Equatable, Sendable {
        var queued: Int
        var running: Int
        var done: Int
        var failed: Int
        var total: Int { queued + running + done + failed }
    }

    static func progress(_ m: TrainingSessionManifest) -> Progress {
        let a = m.candidates.filter(\.status.isActive).map(\.analysis.status)
        return Progress(queued: a.filter { $0 == .queued }.count, running: a.filter { $0 == .running }.count,
                        done: a.filter { $0 == .done }.count, failed: a.filter { $0 == .failed }.count)
    }
}
