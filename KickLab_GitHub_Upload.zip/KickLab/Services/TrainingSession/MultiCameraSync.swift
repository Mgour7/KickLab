import Foundation

/// Build 21 — two-camera foundation: manual synchronization and kick pairing.
///
/// Each source keeps its own raw timestamps. A source maps onto the session's shared
/// timeline (the reference source's time) with `sharedTime = sourceTime + offset`. The
/// offset comes from the athlete marking the SAME event in both recordings (e.g. the foot
/// touching the ball in kick 1); device clocks are only used as a rough first guess.
/// See Docs/MULTICAMERA_FOUNDATION.md.
enum MultiCameraSync {
    /// Marking an event by eye is good to about one frame in each video.
    static func markUncertainty(referenceFrameRate: Double?, sourceFrameRate: Double?) -> Double {
        let a = 1 / max(referenceFrameRate ?? 30, 1), b = 1 / max(sourceFrameRate ?? 30, 1)
        return a + b
    }

    /// Offset from two marks of the same event: reference time `ref` and source time `src`.
    static func manualSync(referenceMark ref: Double, sourceMark src: Double, referenceFrameRate: Double?, sourceFrameRate: Double?, now: Date) -> SourceSync {
        SourceSync(offsetSeconds: ref - src, provenance: .manualEvent,
                   uncertaintySeconds: markUncertainty(referenceFrameRate: referenceFrameRate, sourceFrameRate: sourceFrameRate),
                   referenceMarkTime: ref, sourceMarkTime: src, setAt: now)
    }

    /// A rough offset from the two files' recording start times (different phones' clocks
    /// can differ by seconds): only a starting point, labelled as such.
    static func wallClockSync(referenceStart: Date, sourceStart: Date, now: Date) -> SourceSync {
        SourceSync(offsetSeconds: sourceStart.timeIntervalSince(referenceStart), provenance: .wallClock, uncertaintySeconds: 2.0, setAt: now)
    }

    static func sharedTime(_ sourceTime: Double, sync: SourceSync) -> Double { sourceTime + sync.offsetSeconds }
    static func sourceTime(_ sharedTime: Double, sync: SourceSync) -> Double { sharedTime - sync.offsetSeconds }

    /// Applies a sync to a source. Raw timestamps and contact provenance are untouched.
    static func setSync(_ m: inout TrainingSessionManifest, sourceID: UUID, sync: SourceSync, now: Date) {
        guard let i = m.sources.firstIndex(where: { $0.id == sourceID }), !m.sources[i].isReference else { return }
        m.sources[i].sync = sync
        m.log.append(SessionLogEntry(at: now, text: String(format: "Synchronized %@ (%@, offset %.3f s ± %.3f s)",
                                                           m.sources[i].role.title, sync.provenance.rawValue, sync.offsetSeconds, sync.uncertaintySeconds ?? 0)))
        // The camera's later recordings follow it (same clock).
        let head = m.sources[i]
        for j in m.sources.indices where m.sources[j].id != head.id && m.sources[j].cameraGroup == head.id {
            m.sources[j].sync = TrainingSessionEditor.segmentSync(m, head: head, segmentStart: m.sources[j].recordedAt)
        }
    }

    /// Pairing tolerance: contacts closer than this on the shared timeline are one kick.
    static func pairingTolerance(syncUncertainty: Double?, contactUncertaintyA: Double?, contactUncertaintyB: Double?) -> Double {
        max(0.25, 3 * ((syncUncertainty ?? 0) + (contactUncertaintyA ?? 0) + (contactUncertaintyB ?? 0)))
    }

    /// Pairs active candidates of the reference-side source with those of another source,
    /// one-to-one, nearest contacts first, within the tolerance. Requires a sync (manual or
    /// wall-clock); unsynchronized sources are never paired automatically. Existing manual
    /// pairs are kept.
    static func pairAutomatically(_ m: inout TrainingSessionManifest, primarySourceID: UUID, secondarySourceID: UUID, now: Date) -> Int {
        guard let p = m.source(primarySourceID), let s = m.source(secondarySourceID),
              m.cameraID(of: p) != m.cameraID(of: s),   // two recordings of ONE camera are never paired
              s.sync.provenance != .none || s.isReference, p.sync.provenance != .none || p.isReference else { return 0 }
        let sourceOf = Dictionary(uniqueKeysWithValues: m.candidates.map { ($0.id, $0.sourceID) })
        let attached = Set(m.candidates.filter { $0.kickID != nil }.map(\.id))
        let declined = Set(m.declinedPairs ?? [])
        // Automatic pairs are recomputed — except one whose second-camera clip is already
        // attached to the Kick (it stays, so that kick is never counted twice).
        m.pairs.removeAll { pair in
            pair.provenance == .automatic && !attached.contains(pair.secondaryCandidateID)
                && [pair.primaryCandidateID, pair.secondaryCandidateID].allSatisfy { id in
                    let src = sourceOf[id]
                    return src == primarySourceID || src == secondarySourceID
                }
        }
        let taken = Set(m.pairs.flatMap { [$0.primaryCandidateID, $0.secondaryCandidateID] })
        let a = m.candidates(of: primarySourceID).filter { $0.status.isActive && $0.contactTime != nil && !taken.contains($0.id) }
        let b = m.candidates(of: secondarySourceID).filter { $0.status.isActive && $0.contactTime != nil && !taken.contains($0.id) }
        let syncU = (p.sync.uncertaintySeconds ?? 0) + (s.sync.uncertaintySeconds ?? 0)
        var options: [(Double, SessionKickCandidate, SessionKickCandidate)] = []
        for x in a {
            for y in b {
                let d = abs(m.sharedContact(x) - m.sharedContact(y))
                if d <= pairingTolerance(syncUncertainty: syncU, contactUncertaintyA: x.contactUncertainty, contactUncertaintyB: y.contactUncertainty) {
                    options.append((d, x, y))
                }
            }
        }
        var usedA = Set<UUID>(), usedB = Set<UUID>()
        var made = 0
        for (d, x, y) in options.sorted(by: { $0.0 < $1.0 })
        where !usedA.contains(x.id) && !usedB.contains(y.id) && !declined.contains(declinedKey(x.id, y.id)) {
            m.pairs.append(SessionKickPair(id: UUID(), primaryCandidateID: x.id, secondaryCandidateID: y.id, provenance: .automatic, contactDifference: d))
            usedA.insert(x.id); usedB.insert(y.id)
            made += 1
        }
        m.log.append(SessionLogEntry(at: now, text: "Paired \(made) kick\(made == 1 ? "" : "s") across cameras"))
        return made
    }

    /// The athlete pairs two candidates by hand (replacing any pair either was in).
    static func pairManually(_ m: inout TrainingSessionManifest, primary: UUID, secondary: UUID, now: Date) throws {
        guard let a = m.candidate(primary), let b = m.candidate(secondary) else { throw TrainingSessionEditor.EditError.unknownCandidate }
        guard a.sourceID != b.sourceID else { throw TrainingSessionEditor.EditError.cannotMerge("Both are from the same recording; merge them instead.") }
        // A second-camera clip already attached to a Kick stays with that Kick.
        let replaced = m.pairs.filter { [$0.primaryCandidateID, $0.secondaryCandidateID].contains(where: { $0 == primary || $0 == secondary }) }
        guard b.kickID == nil, !replaced.contains(where: { m.candidate($0.secondaryCandidateID)?.kickID != nil }) else {
            throw TrainingSessionEditor.EditError.cannotMerge("That camera angle is already attached to a kick.")
        }
        m.pairs.removeAll { [$0.primaryCandidateID, $0.secondaryCandidateID].contains(where: { $0 == primary || $0 == secondary }) }
        m.pairs.append(SessionKickPair(id: UUID(), primaryCandidateID: primary, secondaryCandidateID: secondary, provenance: .manual,
                                       contactDifference: (a.contactTime != nil && b.contactTime != nil) ? abs(m.sharedContact(a) - m.sharedContact(b)) : nil))
        m.declinedPairs?.removeAll { $0 == declinedKey(primary, secondary) }
        m.log.append(SessionLogEntry(at: now, text: "Kicks paired by you"))
    }

    /// Removes a pair whose second-camera clip hasn't been attached yet (an attached clip is
    /// part of that Kick's videos; it isn't detached silently).
    static func unpair(_ m: inout TrainingSessionManifest, pairID: UUID, now: Date) {
        guard let pair = m.pairs.first(where: { $0.id == pairID }), m.candidate(pair.secondaryCandidateID)?.kickID == nil else { return }
        m.pairs.removeAll { $0.id == pairID }
        m.declinedPairs = (m.declinedPairs ?? []) + [declinedKey(pair.primaryCandidateID, pair.secondaryCandidateID)]
        m.log.append(SessionLogEntry(at: now, text: "Pair removed by you"))
    }

    static func declinedKey(_ primary: UUID, _ secondary: UUID) -> String { "\(primary.uuidString)|\(secondary.uuidString)" }

    /// Camera A kicks a second-camera candidate could be paired with by hand: active,
    /// from the reference recording, within `window` seconds on the shared timeline,
    /// nearest first. Empty unless the second camera is synchronized.
    static func pairingChoices(_ m: TrainingSessionManifest, for secondary: UUID, window: Double = 10) -> [SessionKickCandidate] {
        guard let c = m.candidate(secondary), let src = m.source(c.sourceID), let primary = m.primaryCameraID,
              m.cameraID(of: src) != primary, src.sync.provenance != .none else { return [] }
        let t = m.sharedContact(c)
        let primarySources = Set(m.segments(ofCamera: primary).map(\.id))
        return m.candidates.filter { primarySources.contains($0.sourceID) && $0.status.isActive && abs(m.sharedContact($0) - t) <= window }
            .sorted { abs(m.sharedContact($0) - t) < abs(m.sharedContact($1) - t) }
    }

    /// The paired partner's contact in the partner's own source time (for synchronized
    /// playback of the two clips): through the shared timeline.
    static func partnerTime(of time: Double, from: SourceSync, to: SourceSync) -> Double {
        MultiCameraSync.sourceTime(sharedTime(time, sync: from), sync: to)
    }

    /// How sure the side/rear playback alignment is (± seconds), or nil when not synchronized.
    static func alignmentUncertainty(_ a: SourceSync, _ b: SourceSync) -> Double? {
        guard a.provenance != .none, b.provenance != .none else { return nil }
        return (a.uncertaintySeconds ?? 0) + (b.uncertaintySeconds ?? 0)
    }
}
