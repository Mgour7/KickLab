import Foundation

// Build 24 — Remote cameras: up to three tripod iPhones running KickLab in camera mode,
// controlled from one iPhone (the "controller"). Pure, Linux-tested parts:
//
// - the messages the phones exchange and their wire format (framed, then encrypted by the
//   Apple layer with a key from the pairing code);
// - clock synchronization: the controller measures each camera's clock against its own
//   with NTP-style ping exchanges (offset = ((t1 − t0) + (t2 − t3)) / 2, from the exchange
//   with the shortest round trip), so every camera's first-frame time is known on the
//   controller's clock and the recordings line up without marking an event;
// - `RemoteRig`, the controller's bookkeeping (cameras, takes, transfers), as a reducer
//   that returns the messages to send;
// - turning a received recording into a session source with a `.sharedClock` sync.
//
// What this does NOT promise: the accuracy is what the measurements say (± the shortest
// round trip / 2 plus how exactly the camera knows its first frame), shown on every
// recording. It has been unit-tested with synthetic clocks only; it has not been measured
// on iPhones. The athlete can refine any sync by marking an event, as before.

enum RemoteCapture {
    /// Bumped when the messages change incompatibly; phones with another version are told
    /// to update instead of misreading each other.
    static let protocolVersion = 1
    /// Bonjour service (also declared in Info.plist `NSBonjourServices`).
    static let bonjourType = "_kicklab-cam._tcp"
    /// Largest frame accepted (a file chunk plus headers and encryption overhead).
    static let maximumFrameBytes = 2 << 20
    static let fileChunkBytes = 256 * 1024
    /// Most bytes a sender keeps queued on the connection before waiting (small, so clock
    /// exchanges aren't stuck behind a video).
    static let maximumBufferedBytes = 768 * 1024
    static let pingInterval = 2.0
    /// No message for this long → the camera is shown as disconnected.
    static let lostAfter = 8.0
    /// Clock exchanges used for one estimate: within this many seconds of the moment.
    static let clockWindow = 120.0
    static let keptClockSamples = 90
    /// How far two phones' clocks may drift apart, as a fraction (50 ppm, generous).
    static let clockDriftAllowance = 50e-6
    /// The camera knows its first frame exactly on iOS 18.2+ (`startPTS`); on earlier iOS
    /// only when AVFoundation reports that recording began, which is less exact.
    static let firstFrameUncertainty = 0.02
    static let startCallbackUncertainty = 0.15
    /// Start is scheduled this far ahead so all cameras begin together.
    static let scheduledStartLead = 0.8
    static let maximumCameras = 3
}

// MARK: - Messages

/// What a camera says about itself when it connects.
struct RemoteCameraHello: Codable, Equatable, Sendable {
    var cameraID: String
    var name: String
    var model: String?
    var version: Int
    /// Finished recordings still on the camera (not yet confirmed imported).
    var pending: [RemoteTakeInfo]
}

/// The controller's answer: which session and view this camera records, at what quality.
struct RemoteControllerWelcome: Codable, Equatable, Sendable {
    var controllerName: String
    var sessionID: UUID
    var sessionName: String
    var role: SessionCameraRole
    var request: CaptureRequest
    var version: Int
}

enum RemoteCameraPhase: String, Codable, Sendable {
    case preparing
    case ready
    case recording
    case saving
    case failed
    case interrupted

    var title: String {
        switch self {
        case .preparing: "Starting camera"
        case .ready: "Ready"
        case .recording: "Recording"
        case .saving: "Saving"
        case .failed: "Camera problem"
        case .interrupted: "Camera in use"
        }
    }
}

struct RemoteCameraStatus: Codable, Equatable, Sendable {
    var phase: RemoteCameraPhase
    var elapsed: Double?
    /// "1080p · 60 fps"
    var selection: String?
    /// 0…1 (nil when unknown).
    var battery: Double?
    var freeBytes: Int64?
    var warning: String?
    /// Recordings waiting on the camera to be sent.
    var pendingCount: Int
    var sending: Bool
}

/// One finished recording on a camera.
struct RemoteTakeInfo: Codable, Equatable, Sendable {
    var takeID: UUID
    var sessionID: UUID
    var role: SessionCameraRole
    /// First frame, on the camera's clock (nil if the camera never learned it).
    var startCameraTime: Double?
    var startUncertainty: Double?
    var duration: Double?
    var frameRate: Double?
    var bytes: Int64
    var usable: Bool
    var fileExtension: String
    var selection: CaptureSelection?
}

enum RemoteMessage: Codable, Equatable, Sendable {
    // camera → controller
    case hello(RemoteCameraHello)
    case pong(id: Int, controllerSent: Double, cameraReceived: Double, cameraSent: Double)
    case status(RemoteCameraStatus)
    case started(takeID: UUID, cameraTime: Double, uncertainty: Double)
    case finished(RemoteTakeInfo)
    case fileEnd(takeID: UUID, bytes: Int64)
    case problem(String)
    // controller → camera
    case welcome(RemoteControllerWelcome)
    case ping(id: Int, sent: Double)
    case start(takeID: UUID, atCameraTime: Double?)
    case stop(takeID: UUID)
    case sendFile(takeID: UUID, fromOffset: Int64)
    case imported(takeID: UUID)
    /// The other side's protocol version can't be used.
    case incompatible(version: Int)
}

// MARK: - Wire format

/// Plain-text frame bodies (the Apple layer encrypts each body, then length-prefixes it).
/// Body: one kind byte, then a JSON message, or a file chunk (16-byte take ID, 8-byte
/// big-endian offset, data).
enum RemoteWire {
    enum Payload: Equatable, Sendable {
        case message(RemoteMessage)
        case chunk(takeID: UUID, offset: Int64, data: Data)
    }

    enum WireError: Error, Equatable {
        case empty
        case unknownKind(UInt8)
        case truncated
        case tooLarge(Int)
    }

    static func encode(_ payload: Payload) throws -> Data {
        switch payload {
        case .message(let m):
            var d = Data([0])
            d.append(try JSONEncoder().encode(m))
            return d
        case .chunk(let id, let offset, let data):
            var d = Data([1])
            d.append(contentsOf: uuidBytes(id))
            d.append(contentsOf: bigEndian(UInt64(bitPattern: offset)))
            d.append(data)
            return d
        }
    }

    static func decode(_ body: Data) throws -> Payload {
        let b = Data(body)   // re-based, so indices start at 0
        guard let kind = b.first else { throw WireError.empty }
        switch kind {
        case 0:
            return .message(try JSONDecoder().decode(RemoteMessage.self, from: b.dropFirst()))
        case 1:
            guard b.count >= 25 else { throw WireError.truncated }
            let id = uuid(Array(b[1..<17]))
            let offset = Int64(bitPattern: b[17..<25].reduce(UInt64(0)) { $0 << 8 | UInt64($1) })
            return .chunk(takeID: id, offset: offset, data: Data(b[25...]))
        default:
            throw WireError.unknownKind(kind)
        }
    }

    /// 4-byte big-endian length, then the bytes.
    static func frame(_ bytes: Data) -> Data {
        var d = Data(bigEndian(UInt64(bytes.count)).suffix(4))
        d.append(bytes)
        return d
    }

    /// Splits a byte stream back into frames.
    struct Deframer: Sendable {
        private var buffer = Data()
        init() {}

        mutating func append(_ data: Data) throws -> [Data] {
            buffer.append(data)
            var out: [Data] = []
            while buffer.count >= 4 {
                let header = Array(buffer.prefix(4))
                let length = header.reduce(0) { $0 << 8 | Int($1) }
                guard length <= RemoteCapture.maximumFrameBytes else { throw WireError.tooLarge(length) }
                guard buffer.count >= 4 + length else { break }
                out.append(Data(buffer.dropFirst(4).prefix(length)))
                buffer = Data(buffer.dropFirst(4 + length))
            }
            return out
        }
    }

    static func bigEndian(_ v: UInt64) -> [UInt8] { (0..<8).map { UInt8(truncatingIfNeeded: v >> (56 - 8 * UInt64($0))) } }

    static func uuidBytes(_ id: UUID) -> [UInt8] {
        let u = id.uuid
        return [u.0, u.1, u.2, u.3, u.4, u.5, u.6, u.7, u.8, u.9, u.10, u.11, u.12, u.13, u.14, u.15]
    }

    static func uuid(_ b: [UInt8]) -> UUID {
        UUID(uuid: (b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]))
    }
}

// MARK: - Pairing

/// The six-digit code shown on the controller and typed once on each camera. The
/// encryption key is derived from it, so a phone without the code can neither join nor
/// read the traffic. (A six-digit code is not a strong secret: it keeps nearby phones out,
/// it is not meant to stop a determined attacker recording the radio traffic.)
enum RemotePairing {
    static let codeLength = 6

    static func newCode<G: RandomNumberGenerator>(using generator: inout G) -> String {
        (0..<codeLength).map { _ in String(Int.random(in: 0...9, using: &generator)) }.joined()
    }

    static func newCode() -> String {
        var g = SystemRandomNumberGenerator()
        return newCode(using: &g)
    }

    /// Digits only ("482 913" → "482913"); nil unless exactly six digits.
    static func normalized(_ input: String) -> String? {
        let kept = input.filter { !$0.isWhitespace && $0 != "-" }
        guard kept.count == codeLength, kept.allSatisfy({ $0.isASCII && $0.isNumber }) else { return nil }
        return kept
    }

    /// "482 913"
    static func display(_ code: String) -> String {
        guard code.count == codeLength else { return code }
        return String(code.prefix(3)) + " " + String(code.suffix(3))
    }

    static let keySalt = Data("KickLab remote cameras v1".utf8)
    /// Authenticated with every frame, so a frame can't be reflected back to its sender.
    static let toCameraContext = Data("controller-to-camera".utf8)
    static let toControllerContext = Data("camera-to-controller".utf8)
}

// MARK: - Clock synchronization

/// One ping/pong exchange. t0 and t3 on the controller's clock, t1 and t2 on the camera's.
struct ClockSample: Codable, Equatable, Sendable {
    var controllerSent: Double
    var cameraReceived: Double
    var cameraSent: Double
    var controllerReceived: Double

    /// Camera clock − controller clock (exact when the two network legs take equal time).
    var offset: Double { ((cameraReceived - controllerSent) + (cameraSent - controllerReceived)) / 2 }
    /// Time on the network (excludes the camera's own turnaround).
    var roundTrip: Double { (controllerReceived - controllerSent) - (cameraSent - cameraReceived) }
    var isValid: Bool {
        [controllerSent, cameraReceived, cameraSent, controllerReceived].allSatisfy(\.isFinite)
            && controllerReceived >= controllerSent && cameraSent >= cameraReceived && roundTrip >= 0 && roundTrip < 2
    }
}

struct ClockEstimate: Codable, Equatable, Sendable {
    /// Camera clock − controller clock.
    var offset: Double
    /// ± seconds: half the shortest round trip (the offset can be wrong by at most that if
    /// one leg took the whole round trip).
    var uncertainty: Double
    var samples: Int
}

enum ClockSync {
    /// The shortest-round-trip exchange near `time` (controller clock). Exchanges with a
    /// round trip within 1 ms of the shortest are averaged (median) to steady the offset.
    static func estimate(_ samples: [ClockSample], near time: Double, window: Double = RemoteCapture.clockWindow) -> ClockEstimate? {
        let near = samples.filter { $0.isValid && abs($0.controllerReceived - time) <= window }
        guard let best = near.min(by: { $0.roundTrip < $1.roundTrip }) else { return nil }
        let good = near.filter { $0.roundTrip <= best.roundTrip + 0.001 }.map(\.offset).sorted()
        let median = good.count % 2 == 1 ? good[good.count / 2] : (good[good.count / 2 - 1] + good[good.count / 2]) / 2
        return ClockEstimate(offset: median, uncertainty: max(best.roundTrip / 2, 0.0005), samples: near.count)
    }

    static func controllerTime(cameraTime: Double, _ e: ClockEstimate) -> Double { cameraTime - e.offset }
    static func cameraTime(controllerTime: Double, _ e: ClockEstimate) -> Double { controllerTime + e.offset }

    /// A controller-clock time as a date, given the clock reading `nowClock` at `now`.
    static func date(controllerTime t: Double, nowClock: Double, now: Date) -> Date { now.addingTimeInterval(t - nowClock) }
}

// MARK: - Session sources

/// Where a remote camera's recording came from, stored on its session source.
struct RemoteSourceInfo: Codable, Equatable, Sendable {
    var cameraID: String
    var cameraName: String
    var takeID: UUID
    /// The first frame, on the controller's clock (nil: the start couldn't be measured).
    var startOnController: Date?
    /// ± seconds of that start (clock estimate + first-frame timing).
    var startUncertainty: Double?
}

enum RemoteCaptureSync {
    /// Sync for a remote recording joining `m`: the first recording of a session is the
    /// reference; otherwise the difference of the two starts on the controller's clock.
    /// A reference recorded ON the controller (in-app) is on the same clock (± its start
    /// timing). Anything else (an imported file of unknown clock) stays unsynchronized.
    static func sync(start: Date?, uncertainty: Double?, in m: TrainingSessionManifest, now: Date) -> SourceSync {
        guard !m.sources.isEmpty else { return .reference }
        guard let start, let ref = m.referenceSource else { return .unsynchronized }
        let u = uncertainty ?? RemoteCapture.startCallbackUncertainty
        if let r = ref.remote {
            guard let refStart = r.startOnController else { return .unsynchronized }
            return SourceSync(offsetSeconds: start.timeIntervalSince(refStart), provenance: .sharedClock,
                              uncertaintySeconds: u + (r.startUncertainty ?? RemoteCapture.startCallbackUncertainty), setAt: now)
        }
        if ref.origin == .inAppRecording, let refStart = ref.recordedAt {
            return SourceSync(offsetSeconds: start.timeIntervalSince(refStart), provenance: .sharedClock,
                              uncertaintySeconds: u + TrainingSessionEditor.sameCameraStartUncertainty, setAt: now)
        }
        return .unsynchronized
    }

    /// Order cameras' recordings of one take are added in, so the side view (the most
    /// measurable) becomes Camera A of a new session.
    static func priority(_ role: SessionCameraRole) -> Int {
        switch role {
        case .side: 0
        case .unspecified: 1
        case .rear: 2
        }
    }
}

extension TrainingSessionEditor {
    /// Adds a recording received from a remote camera (the file is already in place at the
    /// returned source's path). Later recordings of the same camera, still in the same view,
    /// are segments of that camera (never paired with each other).
    @discardableResult
    static func addRemoteSource(_ m: inout TrainingSessionManifest, id: UUID, take: RemoteTakeInfo, remote: RemoteSourceInfo,
                                fileExtension: String, now: Date) -> SessionSource {
        var source = SessionSource(id: id, role: take.role, origin: .imported, relativePath: "sources/\(id.uuidString).\(fileExtension)",
                                   status: .finalized, createdAt: now, recordedAt: remote.startOnController,
                                   durationSeconds: take.duration, nominalFrameRate: take.frameRate, capture: take.selection,
                                   originalFilename: "\(remote.cameraName) (remote camera)", byteCount: take.bytes,
                                   sync: .unsynchronized, cameraGroup: nil, remote: remote)
        if let head = m.sources.first(where: { $0.remote?.cameraID == remote.cameraID && $0.role == take.role }) {
            source.cameraGroup = m.cameraID(of: head)
        }
        source.sync = RemoteCaptureSync.sync(start: remote.startOnController, uncertainty: remote.startUncertainty, in: m, now: now)
        // A camera the athlete synchronized by hand: its later recordings follow that sync.
        if source.sync.provenance == .none, let g = source.cameraGroup, let head = m.source(g) {
            source.sync = segmentSync(m, head: head, segmentStart: source.recordedAt)
        }
        if !take.usable { source.status = (take.bytes > 0) ? .recovered : .missing }
        m.sources.append(source)
        m.processing.scan[id.uuidString] = .notStarted
        let syncText = switch source.sync.provenance {
        case .reference: "reference timeline"
        case .sharedClock: String(format: "synchronized by shared clock ± %.2f s", source.sync.uncertaintySeconds ?? 0)
        case .sameCamera: "follows its camera's sync"
        default: "not synchronized — mark an event to synchronize"
        }
        m.log.append(SessionLogEntry(at: now, text: "Received from \(remote.cameraName): \(take.role.title) (\(syncText))"))
        return source
    }
}

extension TrainingSessionEditor {
    /// New kick settings for recordings still to come. Recordings already in the session
    /// keep the settings they were made with (pinned first, so a recording not yet scanned
    /// isn't given the new ones).
    static func changeDefaultsForLaterRecordings(_ m: inout TrainingSessionManifest, to details: SessionKickDetails, now: Date) {
        guard details != m.defaults else { return }
        for s in m.sources where !m.defaultsChanges.contains(where: { $0.sourceID == s.id }) {
            m.defaultsChanges.append(SessionDefaultsChange(sourceID: s.id, atSourceTime: 0, details: m.defaults))
        }
        m.defaults = details
        m.log.append(SessionLogEntry(at: now, text: "Kick settings for the next recordings: \(details.summary)"))
    }
}

// MARK: - Device names

enum RemoteDeviceName {
    /// Marketing name for an iPhone model identifier ("iPhone11,8" → "iPhone XR"); the
    /// identifier itself when unknown.
    static func marketingName(_ identifier: String) -> String {
        let names: [String: String] = [
            "iPhone11,2": "iPhone XS", "iPhone11,4": "iPhone XS Max", "iPhone11,6": "iPhone XS Max", "iPhone11,8": "iPhone XR",
            "iPhone12,1": "iPhone 11", "iPhone12,3": "iPhone 11 Pro", "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,8": "iPhone SE",
            "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12", "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max",
            "iPhone14,4": "iPhone 13 mini", "iPhone14,5": "iPhone 13", "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max",
            "iPhone14,6": "iPhone SE", "iPhone14,7": "iPhone 14", "iPhone14,8": "iPhone 14 Plus", "iPhone15,2": "iPhone 14 Pro",
            "iPhone15,3": "iPhone 14 Pro Max", "iPhone15,4": "iPhone 15", "iPhone15,5": "iPhone 15 Plus", "iPhone16,1": "iPhone 15 Pro",
            "iPhone16,2": "iPhone 15 Pro Max", "iPhone17,3": "iPhone 16", "iPhone17,4": "iPhone 16 Plus", "iPhone17,1": "iPhone 16 Pro",
            "iPhone17,2": "iPhone 16 Pro Max", "iPhone17,5": "iPhone 16e",
        ]
        return names[identifier] ?? identifier
    }

    /// "iPhone XR · 4F2A" — the short suffix tells two phones of one model apart.
    static func defaultCameraName(model: String, cameraID: String) -> String {
        "\(marketingName(model)) · \(cameraID.prefix(4).uppercased())"
    }
}
