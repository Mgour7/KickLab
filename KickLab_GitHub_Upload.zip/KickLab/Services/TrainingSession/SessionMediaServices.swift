import Foundation

/// Build 21 — the media work a training session needs, behind protocols so the session
/// logic and screens don't depend on AVFoundation/Vision/Core ML directly. Production
/// implementations live in `Services/TrainingSession/Apple/` (iPhone only); the
/// "unavailable" ones say so honestly instead of pretending to work.

/// Stage A: sparse scan of a long recording.
protocol SessionScanning: Sendable {
    var isAvailable: Bool { get }
    /// Samples about `framesPerSecond` frames per second of the whole recording: football
    /// boxes (YOLOX-S) and the most prominent person's ankles/hips (Vision).
    func scan(videoURL: URL, framesPerSecond: Double, progress: @escaping @Sendable (Double) -> Void) async throws -> [SessionScanSample]
}

/// A clip cut out of a recording WITHOUT re-encoding.
struct ExportedClip: Equatable, Sendable {
    var url: URL
    /// Source time of the clip's first frame (clip time + this = source time).
    var startInSource: Double
    var duration: Double
}

protocol ClipExporting: Sendable {
    var isAvailable: Bool { get }
    func exportClip(from source: URL, start: Double, end: Double, to destination: URL) async throws -> ExportedClip
}

/// Experimental: YOLOX-S over the frames after contact, fed to `BallFlightObserver`.
protocol BallFlightTracking: Sendable {
    var isAvailable: Bool { get }
    func observe(videoURL: URL, contactTime: Double, rest: NormalizedBox, seconds: Double) async throws -> BallFlightObservation
}

enum SessionMediaError: Error, Equatable, Sendable, LocalizedError {
    case unavailable(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let s), .failed(let s): s
        }
    }
}

struct UnavailableSessionScanner: SessionScanning {
    var isAvailable: Bool { false }
    func scan(videoURL: URL, framesPerSecond: Double, progress: @escaping @Sendable (Double) -> Void) async throws -> [SessionScanSample] {
        throw SessionMediaError.unavailable("Automatic kick finding needs the iPhone's Vision and Core ML frameworks.")
    }
}

struct UnavailableClipExporter: ClipExporting {
    var isAvailable: Bool { false }
    func exportClip(from source: URL, start: Double, end: Double, to destination: URL) async throws -> ExportedClip {
        throw SessionMediaError.unavailable("Clip export needs AVFoundation.")
    }
}

struct UnavailableBallFlightTracker: BallFlightTracking {
    var isAvailable: Bool { false }
    func observe(videoURL: URL, contactTime: Double, rest: NormalizedBox, seconds: Double) async throws -> BallFlightObservation {
        throw SessionMediaError.unavailable("Ball-flight tracking needs the football detector (Core ML).")
    }
}

/// Stage A sampling rate: enough to see a ball leave its spot and a leg swing (a kicking
/// swing lasts ~0.3 s) while keeping a 30-minute scan to a few minutes on an iPhone.
enum SessionScanSettings {
    static let framesPerSecond = 5.0
}
