import Foundation

/// Build 21 — the media work a training session needs, behind protocols so the session
/// logic and screens don't depend on AVFoundation/Vision/Core ML directly. Production
/// implementations live in `Services/TrainingSession/Apple/` (iPhone only); the
/// "unavailable" ones say so honestly instead of pretending to work.

/// Stage A: sparse scan of a long recording.
protocol SessionScanning: Sendable {
    var isAvailable: Bool { get }
    /// Samples about `framesPerSecond` frames per second of the whole recording: football
    /// boxes (YOLOX-S) and the most prominent person's ankles/hips (Vision).
    func scan(videoURL: URL, framesPerSecond: Double, progress: @escaping @Sendable (Double) -> Void) async throws -> [SessionScanSample]
}

/// A clip cut out of a recording WITHOUT re-encoding.
struct ExportedClip: Equatable, Sendable {
    var url: URL
    /// Source time of the clip's first frame (clip time + this = source time).
    var startInSource: Double
    var duration: Double
}

protocol ClipExporting: Sendable {
    var isAvailable: Bool { get }
    func exportClip(from source: URL, start: Double, end: Double, to destination: URL) async throws -> ExportedClip
}

/// Experimental: YOLOX-S over the frames after contact, fed to `BallFlightObserver`.
protocol BallFlightTracking: Sendable {
    var isAvailable: Bool { get }
    func observe(videoURL: URL, contactTime: Double, rest: NormalizedBox, seconds: Double) async throws -> BallFlightObservation
}

enum SessionMediaError: Error, Equatable, Sendable, LocalizedError {
    case unavailable(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let s), .failed(let s): s
        }
    }
}

struct UnavailableSessionScanner: SessionScanning {
    var isAvailable: Bool { false }
    func scan(videoURL: URL, framesPerSecond: Double, progress: @escaping @Sendable (Double) -> Void) async throws -> [SessionScanSample] {
        throw SessionMediaError.unavailable("Automatic kick finding needs the iPhone's Vision and Core ML frameworks.")
    }
}

struct UnavailableClipExporter: ClipExporting {
    var isAvailable: Bool { false }
    func exportClip(from source: URL, start: Double, end: Double, to destination: URL) async throws -> ExportedClip {
        throw SessionMediaError.unavailable("Clip export needs AVFoundation.")
    }
}

struct UnavailableBallFlightTracker: BallFlightTracking {
    var isAvailable: Bool { false }
    func observe(videoURL: URL, contactTime: Double, rest: NormalizedBox, seconds: Double) async throws -> BallFlightObservation {
        throw SessionMediaError.unavailable("Ball-flight tracking needs the football detector (Core ML).")
    }
}

/// Stage A sampling rate: enough to see a ball leave its spot and a leg swing (a kicking
/// swing lasts ~0.3 s) while keeping a 30-minute scan to a few minutes on an iPhone.
enum SessionScanSettings {
    static let framesPerSecond = 5.0
}

// MARK: - Media timing (Hotfix 2)

/// What AVFoundation reports about a video file's timing and geometry — for diagnostics and
/// to check the recording → clip time mapping on the real files.
struct MediaTimingInfo: Codable, Equatable, Sendable {
    struct EditSegment: Codable, Equatable, Sendable {
        /// Media (source-sample) time range; nil for an empty edit.
        var mediaStart: Double?
        var mediaDuration: Double?
        /// Where it lands on the presentation timeline.
        var targetStart: Double
        var targetDuration: Double
        var isEmpty: Bool
    }

    var durationSeconds: Double?
    var width: Int?
    var height: Int?
    /// Preferred transform (a, b, c, d, tx, ty): rotation/mirroring applied on display.
    var transform: [Double]?
    /// "portrait" / "landscape" after the transform.
    var displayOrientation: String?
    var nominalFrameRate: Double?
    var minFrameDuration: Double?
    /// Four-character codec code, e.g. "hvc1", "avc1".
    var codec: String?
    var trackStart: Double?
    var trackDuration: Double?
    var editSegments: [EditSegment]?
    /// Presentation time of the first decoded video frame (edits applied).
    var firstFrameTime: Double?
    var hasAudio: Bool?
    /// Metadata keys present (names only; values are never exported).
    var metadataKeys: [String]?
}

protocol MediaTimingInspecting: Sendable {
    func timing(of url: URL) async -> MediaTimingInfo?
}

struct UnavailableMediaTimingInspector: MediaTimingInspecting {
    func timing(of url: URL) async -> MediaTimingInfo? { nil }
}

extension ClipTimingRecord {
    /// The measured timing of an exported clip, with a warning when it doesn't match the
    /// expected mapping (clip time 0 = requested start in the recording).
    static func make(requestedStart: Double, requestedDuration: Double, exportedDuration: Double?, info: MediaTimingInfo?) -> ClipTimingRecord {
        let frame = info?.minFrameDuration ?? info?.nominalFrameRate.map { 1 / max($0, 1) } ?? 1.0 / 30
        var warnings: [String] = []
        if let first = info?.firstFrameTime, abs(first) > frame / 2 + 1e-6 {
            warnings.append(String(format: "first frame at %.3f s, not 0", first))
        }
        if let d = exportedDuration, abs(d - requestedDuration) > 0.25 {
            warnings.append(String(format: "clip is %.2f s long, %.2f s requested", d, requestedDuration))
        }
        return ClipTimingRecord(requestedStart: requestedStart, requestedDuration: requestedDuration, exportedDuration: exportedDuration,
                                firstFrameTime: info?.firstFrameTime, editSegmentCount: info?.editSegments?.count,
                                nominalFrameRate: info?.nominalFrameRate,
                                warning: warnings.isEmpty ? nil : "Clip timing differs from the expected mapping: " + warnings.joined(separator: "; "))
    }
}
