import Foundation

/// Build 24 — on a CAMERA phone: its recordings for the controller, kept until the
/// controller confirms each one is in its session (then deleted from the camera). A
/// recording's details are written BEFORE recording starts, so a recording cut off by the
/// app being closed is still known (and sent) next time. Lives in KickLab's own storage,
/// outside the folders the orphan-file sweep scans.
struct RemoteCameraOutbox: Sendable {
    let directory: URL

    init(baseURL: URL) {
        directory = baseURL.appendingPathComponent("RemoteCamera", isDirectory: true)
    }

    func prepare() throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    func videoURL(_ takeID: UUID, fileExtension: String = "mov") -> URL {
        directory.appendingPathComponent("\(takeID.uuidString).\(fileExtension)")
    }

    func infoURL(_ takeID: UUID) -> URL { directory.appendingPathComponent("\(takeID.uuidString).json") }

    func save(_ info: RemoteTakeInfo) throws {
        try prepare()
        try JSONEncoder().encode(info).write(to: infoURL(info.takeID), options: .atomic)
    }

    /// Recordings waiting to be sent, oldest first. One left unfinished (bytes 0 in its
    /// details) is brought up to date from its file: readable up to its last fragment.
    func pending(excluding current: UUID? = nil) -> [RemoteTakeInfo] {
        guard let items = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.creationDateKey]) else { return [] }
        var out: [(Date, RemoteTakeInfo)] = []
        for url in items where url.pathExtension == "json" {
            guard let data = try? Data(contentsOf: url), var info = try? JSONDecoder().decode(RemoteTakeInfo.self, from: data),
                  info.takeID != current else { continue }
            let video = videoURL(info.takeID, fileExtension: info.fileExtension)
            let attributes = try? FileManager.default.attributesOfItem(atPath: video.path)
            let size = (attributes?[.size] as? NSNumber)?.int64Value ?? 0
            guard size > 0 else { continue }
            if info.bytes != size {
                // Cut off while recording: keep what was written.
                info.bytes = size
                info.usable = true
                try? save(info)
            }
            let created = (attributes?[.creationDate] as? Date) ?? .distantPast
            out.append((created, info))
        }
        return out.sorted { $0.0 < $1.0 }.map(\.1)
    }

    var totalBytes: Int64 { pending().reduce(0) { $0 + $1.bytes } }

    func remove(_ takeID: UUID) {
        let info = (try? Data(contentsOf: infoURL(takeID))).flatMap { try? JSONDecoder().decode(RemoteTakeInfo.self, from: $0) }
        try? FileManager.default.removeItem(at: videoURL(takeID, fileExtension: info?.fileExtension ?? "mov"))
        try? FileManager.default.removeItem(at: infoURL(takeID))
    }

    /// Details whose recording never got a byte (the camera never started): dropped.
    func removeEmpty(excluding current: UUID? = nil) {
        guard let items = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else { return }
        for url in items where url.pathExtension == "json" {
            guard let id = UUID(uuidString: url.deletingPathExtension().lastPathComponent), id != current else { continue }
            let info = (try? Data(contentsOf: url)).flatMap { try? JSONDecoder().decode(RemoteTakeInfo.self, from: $0) }
            let video = videoURL(id, fileExtension: info?.fileExtension ?? "mov")
            let size = ((try? FileManager.default.attributesOfItem(atPath: video.path))?[.size] as? NSNumber)?.int64Value ?? 0
            if size == 0 { remove(id) }
        }
    }
}
