import Foundation

/// Build 24 — the controller's bookkeeping for remote cameras: who is connected, their
/// clocks, and each take (one Record → Stop across all ready cameras) until every camera's
/// file has arrived and been added to the session. Pure: every event comes in with the
/// controller's clock reading `t` (seconds, monotonic), and the messages to send come back
/// as actions, so all of it is unit-tested without phones or a network.
struct RemoteRig: Equatable, Sendable {
    struct Camera: Equatable, Sendable, Identifiable {
        var id: String
        var name: String
        var model: String?
        var role: SessionCameraRole
        var connected: Bool
        var lastHeard: Double
        var lastPing = -Double.infinity
        var status: RemoteCameraStatus?
        var samples: [ClockSample] = []
        /// The current clock estimate (for display: "clock ± 4 ms").
        var clock: ClockEstimate?
        var incompatibleVersion: Int?
        var lastProblem: String?
        /// Recordings on this camera that belong to other sessions.
        var otherSessionsPending = 0
        /// This camera's own quality (nil: the session's).
        var request: CaptureRequest? = nil
    }

    enum Phase: Codable, Equatable, Sendable {
        case starting
        case recording
        case saving
        case waitingForFile
        case receiving
        case received
        case imported(sourceID: UUID)
        case failed(String)

        var isTerminal: Bool {
            switch self {
            case .imported, .failed: true
            default: false
            }
        }
    }

    struct TakeCamera: Codable, Equatable, Sendable {
        var cameraID: String
        var cameraName: String
        var role: SessionCameraRole
        var phase: Phase
        var startCameraTime: Double?
        var startUncertainty: Double?
        /// First frame on the controller's clock, as a date (nil until measured).
        var startOnController: Date?
        /// ± seconds of `startOnController` (clock + first-frame timing).
        var startTotalUncertainty: Double?
        var info: RemoteTakeInfo?
        var receivedBytes: Int64 = 0

        var transferFraction: Double? {
            guard let total = info?.bytes, total > 0 else { return nil }
            return min(1, Double(receivedBytes) / Double(total))
        }
    }

    struct Take: Codable, Equatable, Sendable, Identifiable {
        var id: UUID
        var startedAt: Date
        var stoppedAt: Date?
        var cameras: [TakeCamera]
        /// "Mark Kick" taps, on the controller's clock as dates.
        var marks: [Date]
        /// The kick settings when the take started, and changes made during it.
        var details: SessionKickDetails? = nil
        var detailChanges: [DetailsChange] = []
        var isRecording: Bool { stoppedAt == nil }
    }

    struct DetailsChange: Codable, Equatable, Sendable {
        var at: Date
        var details: SessionKickDetails
    }

    enum Action: Equatable, Sendable {
        case send(RemoteMessage, to: String)
    }

    enum StartProblem: Error, Equatable {
        case alreadyRecording
        case noReadyCamera
    }

    var sessionID: UUID
    var sessionName: String
    var controllerName: String
    var request: CaptureRequest
    var kickType: KickType?
    var cameras: [Camera] = []
    var takes: [Take] = []
    /// Maps the controller clock to dates: `date = anchorDate + (t − anchorClock)`.
    var anchorClock: Double
    var anchorDate: Date
    private var nextPingID = 1

    init(sessionID: UUID, sessionName: String, controllerName: String, request: CaptureRequest, kickType: KickType? = nil, takes: [Take] = [],
         clock: Double, now: Date) {
        self.kickType = kickType
        self.sessionID = sessionID
        self.sessionName = sessionName
        self.controllerName = controllerName
        self.request = request
        self.takes = takes
        anchorClock = clock
        anchorDate = now
        // A transfer cut off when the controller closed starts over when the camera returns.
        for i in self.takes.indices {
            for j in self.takes[i].cameras.indices {
                switch self.takes[i].cameras[j].phase {
                case .receiving:
                    self.takes[i].cameras[j].phase = .waitingForFile
                    self.takes[i].cameras[j].receivedBytes = 0
                case .starting, .recording, .saving:
                    self.takes[i].cameras[j].phase = .saving
                default: break
                }
            }
            if self.takes[i].stoppedAt == nil { self.takes[i].stoppedAt = now }
        }
    }

    func date(_ t: Double) -> Date { anchorDate.addingTimeInterval(t - anchorClock) }
    func clockTime(_ d: Date) -> Double { anchorClock + d.timeIntervalSince(anchorDate) }

    var currentTake: Take? { takes.last.flatMap { $0.isRecording ? $0 : nil } }
    var isRecording: Bool { currentTake != nil }
    func camera(_ id: String) -> Camera? { cameras.first { $0.id == id } }

    var readyCameras: [Camera] {
        cameras.filter { $0.connected && $0.incompatibleVersion == nil && $0.status?.phase == .ready }
    }

    /// Two connected cameras set to the same side or rear view (allowed, but worth a word).
    var duplicateRoles: [SessionCameraRole] {
        let roles = cameras.filter(\.connected).map(\.role).filter { $0 != .unspecified }
        return Array(Set(roles.filter { r in roles.filter { $0 == r }.count > 1 })).sorted { $0.rawValue < $1.rawValue }
    }

    private func welcome(_ c: Camera) -> RemoteMessage {
        .welcome(RemoteControllerWelcome(controllerName: controllerName, sessionID: sessionID, sessionName: sessionName,
                                         role: c.role, request: c.request ?? request, version: RemoteCapture.protocolVersion, kickType: kickType))
    }

    // MARK: Connection

    /// A camera connected (or came back): welcome it and collect recordings it still holds.
    mutating func hello(_ h: RemoteCameraHello, defaultRole: SessionCameraRole, defaultRequest: CaptureRequest? = nil, at t: Double) -> [Action] {
        guard h.version == RemoteCapture.protocolVersion else {
            upsert(h, role: defaultRole, request: defaultRequest, at: t)
            if let i = cameras.firstIndex(where: { $0.id == h.cameraID }) { cameras[i].incompatibleVersion = h.version }
            return [.send(.incompatible(version: RemoteCapture.protocolVersion), to: h.cameraID)]
        }
        upsert(h, role: defaultRole, request: defaultRequest, at: t)
        guard let i = cameras.firstIndex(where: { $0.id == h.cameraID }) else { return [] }
        cameras[i].incompatibleVersion = nil
        cameras[i].otherSessionsPending = h.pending.filter { $0.sessionID != sessionID }.count
        var out: [Action] = [.send(welcome(cameras[i]), to: h.cameraID), ping(i, at: t)]
        for info in h.pending where info.sessionID == sessionID {
            out += collect(info, from: h.cameraID, at: t)
        }
        return out
    }

    private mutating func upsert(_ h: RemoteCameraHello, role: SessionCameraRole, request: CaptureRequest?, at t: Double) {
        if let i = cameras.firstIndex(where: { $0.id == h.cameraID }) {
            cameras[i].name = h.name
            cameras[i].model = h.model
            cameras[i].connected = true
            cameras[i].lastHeard = t
        } else {
            cameras.append(Camera(id: h.cameraID, name: h.name, model: h.model, role: role, connected: true, lastHeard: t, request: request))
        }
    }

    /// The role a newly connected camera gets: the first of side, rear, not set that no
    /// connected camera has yet (the athlete can change it before recording).
    func suggestedRole() -> SessionCameraRole {
        let used = Set(cameras.filter(\.connected).map(\.role))
        return [SessionCameraRole.side, .rear].first { !used.contains($0) } ?? .unspecified
    }

    mutating func disconnected(_ cameraID: String) {
        guard let i = cameras.firstIndex(where: { $0.id == cameraID }) else { return }
        cameras[i].connected = false
        cameras[i].status = nil
    }

    /// The athlete removes a disconnected camera from the list (its takes are kept).
    mutating func forget(_ cameraID: String) {
        cameras.removeAll { $0.id == cameraID && !$0.connected }
    }

    mutating func setRole(_ role: SessionCameraRole, camera id: String) -> [Action] {
        guard !isRecording, let i = cameras.firstIndex(where: { $0.id == id }) else { return [] }
        cameras[i].role = role
        return cameras[i].connected ? [.send(welcome(cameras[i]), to: id)] : []
    }

    /// One camera's own quality (nil: back to the session's), e.g. 120 fps on the side
    /// view and 60 fps behind.
    mutating func setRequest(_ r: CaptureRequest?, camera id: String) -> [Action] {
        guard !isRecording, let i = cameras.firstIndex(where: { $0.id == id }) else { return [] }
        cameras[i].request = r
        return cameras[i].connected && cameras[i].incompatibleVersion == nil ? [.send(welcome(cameras[i]), to: id)] : []
    }

    func request(for c: Camera) -> CaptureRequest { c.request ?? request }

    /// The kick type changed: cameras update their framing advice.
    mutating func setKickType(_ k: KickType?) -> [Action] {
        guard k != kickType else { return [] }
        kickType = k
        guard !isRecording else { return [] }
        return cameras.filter { $0.connected && $0.incompatibleVersion == nil }.map { .send(welcome($0), to: $0.id) }
    }

    /// Ready cameras standing upright (they'd record a narrow picture).
    var uprightCameras: [Camera] { readyCameras.filter { $0.status?.orientation == .portrait } }

    mutating func setRequest(_ r: CaptureRequest) -> [Action] {
        guard !isRecording else { return [] }
        request = r
        return cameras.filter { $0.connected && $0.incompatibleVersion == nil }.map { .send(welcome($0), to: $0.id) }
    }

    // MARK: Messages from cameras

    mutating func receive(_ message: RemoteMessage, from id: String, at t: Double) -> [Action] {
        guard let i = cameras.firstIndex(where: { $0.id == id }) else { return [] }
        cameras[i].lastHeard = t
        cameras[i].connected = true
        switch message {
        case .pong(_, let sent, let received, let replied):
            let s = ClockSample(controllerSent: sent, cameraReceived: received, cameraSent: replied, controllerReceived: t)
            guard s.isValid else { return [] }
            cameras[i].samples.append(s)
            if cameras[i].samples.count > RemoteCapture.keptClockSamples { cameras[i].samples.removeFirst(cameras[i].samples.count - RemoteCapture.keptClockSamples) }
            cameras[i].clock = ClockSync.estimate(cameras[i].samples, near: t)
            return []
        case .status(let s):
            cameras[i].status = s
            // Still recording a take the athlete stopped (it missed the Stop): stop it.
            if s.phase == .recording, let take = takes.last(where: { tk in tk.cameras.contains { $0.cameraID == id } }), !take.isRecording {
                return [.send(.stop(takeID: take.id), to: id)]
            }
            return []
        case .started(let takeID, let cameraTime, let uncertainty):
            guard let (k, j) = index(takeID, id) else { return [] }
            takes[k].cameras[j].startCameraTime = cameraTime
            takes[k].cameras[j].startUncertainty = uncertainty
            if takes[k].cameras[j].phase == .starting { takes[k].cameras[j].phase = takes[k].isRecording ? .recording : .saving }
            measureStart(k, j, camera: i)
            return []
        case .finished(let info):
            return collect(info, from: id, at: t)
        case .fileEnd(let takeID, let bytes):
            guard let (k, j) = index(takeID, id) else { return [] }
            let tc = takes[k].cameras[j]
            guard tc.phase == .receiving || tc.phase == .waitingForFile else { return [] }
            if tc.receivedBytes == bytes, bytes > 0 {
                takes[k].cameras[j].phase = .received
                return []
            }
            return [.send(.sendFile(takeID: takeID, fromOffset: tc.receivedBytes), to: id)]
        case .problem(let text):
            cameras[i].lastProblem = text
            return []
        case .incompatible(let version):
            cameras[i].incompatibleVersion = version
            return []
        case .hello, .welcome, .ping, .start, .stop, .sendFile, .imported:
            return []
        }
    }

    /// A finished recording reported by a camera (now, or again after reconnecting).
    private mutating func collect(_ info: RemoteTakeInfo, from id: String, at t: Double) -> [Action] {
        guard info.sessionID == sessionID, let i = cameras.firstIndex(where: { $0.id == id }) else { return [] }
        if index(info.takeID, id) == nil {
            // Recorded while this screen wasn't tracking it: kept, but its start is unknown.
            let tc = TakeCamera(cameraID: id, cameraName: cameras[i].name, role: info.role, phase: .saving)
            if let k = takes.firstIndex(where: { $0.id == info.takeID }) {
                takes[k].cameras.append(tc)
            } else {
                takes.append(Take(id: info.takeID, startedAt: date(t - (info.duration ?? 0)), stoppedAt: date(t), cameras: [tc], marks: []))
                takes.sort { $0.startedAt < $1.startedAt }
            }
        }
        guard let (k, j) = index(info.takeID, id) else { return [] }
        takes[k].cameras[j].info = info
        if takes[k].cameras[j].startCameraTime == nil, let s = info.startCameraTime {
            takes[k].cameras[j].startCameraTime = s
            takes[k].cameras[j].startUncertainty = info.startUncertainty
        }
        // Measured again with the exchanges made during the recording (often quieter than
        // those just before it, when the previous recording may still have been sending).
        measureStart(k, j, camera: i)
        switch takes[k].cameras[j].phase {
        case .imported:
            return [.send(.imported(takeID: info.takeID), to: id)]   // the camera missed the confirmation
        case .received:
            return []
        default:
            guard info.bytes > 0 else {
                takes[k].cameras[j].phase = .failed("The camera couldn't save this recording.")
                return []
            }
            takes[k].cameras[j].phase = .waitingForFile
            takes[k].cameras[j].receivedBytes = 0
            return [.send(.sendFile(takeID: info.takeID, fromOffset: 0), to: id)]
        }
    }

    /// Converts the camera's first-frame time to the controller's clock with the clock
    /// exchanges nearest that moment.
    private mutating func measureStart(_ k: Int, _ j: Int, camera i: Int) {
        guard let s = takes[k].cameras[j].startCameraTime else { return }
        let rough = clockTime(takes[k].startedAt)
        // Exchanges near the start; otherwise the latest ones, allowing for the clocks
        // drifting apart since then (iPhone clocks: well under 50 parts per million).
        var estimate = ClockSync.estimate(cameras[i].samples, near: rough)
        if estimate == nil, let last = cameras[i].samples.last, var e = ClockSync.estimate(cameras[i].samples, near: last.controllerReceived),
           abs(last.controllerReceived - rough) < 3600 {
            e.uncertainty += abs(last.controllerReceived - rough) * RemoteCapture.clockDriftAllowance
            estimate = e
        }
        guard let e = estimate else { return }
        let start = ClockSync.controllerTime(cameraTime: s, e)
        // A wildly different answer (a camera restarted, a different clock) isn't trusted.
        guard abs(start - rough) < 30 else { return }
        let u = e.uncertainty + (takes[k].cameras[j].startUncertainty ?? RemoteCapture.startCallbackUncertainty)
        // Keep the better of this and an earlier measurement.
        if let old = takes[k].cameras[j].startTotalUncertainty, takes[k].cameras[j].startOnController != nil, old <= u { return }
        takes[k].cameras[j].startOnController = date(start)
        takes[k].cameras[j].startTotalUncertainty = u
    }

    private func index(_ takeID: UUID, _ cameraID: String) -> (Int, Int)? {
        guard let k = takes.firstIndex(where: { $0.id == takeID }), let j = takes[k].cameras.firstIndex(where: { $0.cameraID == cameraID }) else { return nil }
        return (k, j)
    }

    // MARK: Recording

    /// Record on every ready camera. Each camera is asked to start at the same moment
    /// (its own clock), a little ahead so the message reaches all of them first.
    mutating func startRecording(takeID: UUID, details: SessionKickDetails? = nil, at t: Double) throws -> [Action] {
        guard !isRecording else { throw StartProblem.alreadyRecording }
        let ready = readyCameras
        guard !ready.isEmpty else { throw StartProblem.noReadyCamera }
        let startAt = t + RemoteCapture.scheduledStartLead
        takes.append(Take(id: takeID, startedAt: date(startAt), stoppedAt: nil,
                          cameras: ready.map { TakeCamera(cameraID: $0.id, cameraName: $0.name, role: $0.role, phase: .starting) }, marks: [],
                          details: details))
        return ready.map { c in
            .send(.start(takeID: takeID, atCameraTime: c.clock.map { ClockSync.cameraTime(controllerTime: startAt, $0) }), to: c.id)
        }
    }

    /// Kick settings changed during the take (applies from this moment in every camera's
    /// recording); between takes the session defaults change instead.
    @discardableResult
    mutating func changeDetails(_ details: SessionKickDetails, at t: Double) -> Bool {
        guard let k = takes.indices.last, takes[k].isRecording else { return false }
        takes[k].detailChanges.append(DetailsChange(at: date(t), details: details))
        return true
    }

    mutating func stopRecording(at t: Double) -> [Action] {
        guard let k = takes.indices.last, takes[k].isRecording else { return [] }
        takes[k].stoppedAt = date(t)
        for j in takes[k].cameras.indices where [.starting, .recording].contains(takes[k].cameras[j].phase) {
            takes[k].cameras[j].phase = .saving
        }
        return takes[k].cameras.map { .send(.stop(takeID: takes[k].id), to: $0.cameraID) }
    }

    /// "Mark Kick" during a take (a hint for kick finding in every camera's recording).
    @discardableResult
    mutating func mark(at t: Double) -> Bool {
        guard let k = takes.indices.last, takes[k].isRecording else { return false }
        takes[k].marks.append(date(t))
        return true
    }

    // MARK: Housekeeping

    mutating func tick(at t: Double) -> [Action] {
        var out: [Action] = []
        for i in cameras.indices where cameras[i].connected {
            if t - cameras[i].lastHeard > RemoteCapture.lostAfter {
                cameras[i].connected = false
                cameras[i].status = nil
                continue
            }
            if cameras[i].incompatibleVersion == nil, t - cameras[i].lastPing >= RemoteCapture.pingInterval { out.append(ping(i, at: t)) }
        }
        return out
    }

    private mutating func ping(_ i: Int, at t: Double) -> Action {
        cameras[i].lastPing = t
        nextPingID += 1
        return .send(.ping(id: nextPingID, sent: t), to: cameras[i].id)
    }

    // MARK: Files

    enum ChunkDecision: Equatable, Sendable {
        /// Write the bytes at this offset of the file.
        case write
        /// Out of order (left over from before a resend request): drop it.
        case ignore
    }

    mutating func chunk(takeID: UUID, cameraID: String, offset: Int64, count: Int) -> ChunkDecision {
        guard let (k, j) = index(takeID, cameraID) else { return .ignore }
        let tc = takes[k].cameras[j]
        guard tc.phase == .waitingForFile || tc.phase == .receiving, offset == tc.receivedBytes else { return .ignore }
        takes[k].cameras[j].receivedBytes += Int64(count)
        takes[k].cameras[j].phase = .receiving
        return .write
    }

    /// Received files that can be added to the session now. Into an EMPTY session they go
    /// in camera order (side, then not set, then rear) so the side view becomes Camera A;
    /// `force` adds whatever has arrived (a camera that never came back).
    func importable(sessionHasSources: Bool, force: Bool = false) -> [(takeID: UUID, camera: TakeCamera)] {
        let ready = takes.flatMap { take in take.cameras.filter { $0.phase == .received }.map { (takeID: take.id, camera: $0) } }
        if sessionHasSources || force { return ready }
        guard let first = takes.first(where: { tk in tk.cameras.contains { !$0.phase.isTerminal } }) else { return [] }
        let order = first.cameras.filter { !$0.phase.isTerminal }.sorted { RemoteCaptureSync.priority($0.role) < RemoteCaptureSync.priority($1.role) }
        guard let lead = order.first, lead.phase == .received else { return [] }
        return [(takeID: first.id, camera: lead)]
    }

    mutating func imported(takeID: UUID, cameraID: String, sourceID: UUID) -> [Action] {
        guard let (k, j) = index(takeID, cameraID) else { return [] }
        takes[k].cameras[j].phase = .imported(sourceID: sourceID)
        return [.send(.imported(takeID: takeID), to: cameraID)]
    }

    mutating func importFailed(takeID: UUID, cameraID: String, reason: String) {
        guard let (k, j) = index(takeID, cameraID) else { return }
        takes[k].cameras[j].phase = .failed(reason)
    }

    /// Files still to arrive (for "keep the cameras open" warnings).
    var outstanding: Int {
        takes.flatMap(\.cameras).filter { !$0.phase.isTerminal }.count
    }

    /// The kick settings for one camera's recording of a take, as defaults changes in that
    /// recording's own time (empty when the take kept the session defaults throughout).
    static func defaultsChanges(_ take: Take, sourceID: UUID, start: Date?, sessionDefaults: SessionKickDetails) -> [SessionDefaultsChange] {
        let initial = take.details ?? sessionDefaults
        var out: [SessionDefaultsChange] = []
        if initial != sessionDefaults || !take.detailChanges.isEmpty {
            out.append(SessionDefaultsChange(sourceID: sourceID, atSourceTime: 0, details: initial))
        }
        guard let start else { return out }
        for c in take.detailChanges {
            out.append(SessionDefaultsChange(sourceID: sourceID, atSourceTime: max(0, c.at.timeIntervalSince(start)), details: c.details))
        }
        return out
    }

    /// The take's marks in one camera's own recording time.
    static func markTimes(_ take: Take, start: Date?, duration: Double?) -> [Double] {
        guard let start else { return [] }
        return take.marks.map { $0.timeIntervalSince(start) }.filter { $0 >= 0 && $0 <= (duration ?? .infinity) }
    }
}
