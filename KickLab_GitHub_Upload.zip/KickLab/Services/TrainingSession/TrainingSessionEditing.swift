import Foundation

/// Build 21 — every change to a session manifest, as pure functions with validation and a
/// log entry. None of them touches a recording file: deleting a candidate marks it, it
/// never removes footage.
enum TrainingSessionEditor {
    enum EditError: Error, Equatable, Sendable {
        case unknownSource, unknownCandidate
        case boundariesInvalid(String)
        case contactOutsideClip
        case cannotSplit(String)
        case cannotMerge(String)
        case sourceInUse(Int)
        case alreadyAnalyzing
    }

    // MARK: Creating

    static func makeSession(athleteID: UUID, kickingSessionID: UUID?, name: String, location: String?,
                            defaults: SessionKickDetails, now: Date) -> TrainingSessionManifest {
        var m = TrainingSessionManifest(id: UUID(), athleteID: athleteID, kickingSessionID: kickingSessionID, name: name,
                                        createdAt: now, location: location, defaults: defaults)
        m.log.append(SessionLogEntry(at: now, text: "Session created"))
        return m
    }

    /// Adds a recording. The first source becomes the session's reference timeline.
    static func addSource(_ m: inout TrainingSessionManifest, id: UUID, role: SessionCameraRole, origin: SessionSourceOrigin,
                          fileExtension: String, status: SessionSourceStatus, now: Date, capture: CaptureSelection? = nil,
                          originalFilename: String? = nil) -> SessionSource {
        let source = SessionSource(id: id, role: role, origin: origin, relativePath: "sources/\(id.uuidString).\(fileExtension)",
                                   status: status, createdAt: now, recordedAt: origin == .inAppRecording ? now : nil, capture: capture,
                                   originalFilename: originalFilename,
                                   sync: m.sources.isEmpty ? .reference : .unsynchronized)
        m.sources.append(source)
        m.processing.scan[id.uuidString] = .notStarted
        m.log.append(SessionLogEntry(at: now, text: "\(origin == .imported ? "Imported" : "Recording started"): \(role.title)"))
        return source
    }

    static func finalizeSource(_ m: inout TrainingSessionManifest, id: UUID, duration: Double?, frameRate: Double?, bytes: Int64?,
                               status: SessionSourceStatus = .finalized, now: Date) {
        guard let i = m.sources.firstIndex(where: { $0.id == id }) else { return }
        m.sources[i].status = status
        m.sources[i].durationSeconds = duration
        m.sources[i].nominalFrameRate = frameRate
        m.sources[i].byteCount = bytes
        m.log.append(SessionLogEntry(at: now, text: "Recording saved (\(status.rawValue))"))
    }

    static func setRole(_ m: inout TrainingSessionManifest, sourceID: UUID, role: SessionCameraRole, now: Date) {
        guard let i = m.sources.firstIndex(where: { $0.id == sourceID }) else { return }
        m.sources[i].role = role
        m.log.append(SessionLogEntry(at: now, text: "View set to \(role.title)"))
    }

    /// Changes the defaults from this moment of the recording on; earlier kicks keep theirs.
    static func changeDefaults(_ m: inout TrainingSessionManifest, to details: SessionKickDetails, sourceID: UUID?, atSourceTime: Double?, now: Date) {
        if let sourceID, atSourceTime != nil, !m.defaultsChanges.contains(where: { $0.sourceID == sourceID }) {
            // Keep what applied before this change for the kicks already recorded.
            m.defaultsChanges.append(SessionDefaultsChange(sourceID: sourceID, atSourceTime: 0, details: m.defaults))
        }
        m.defaults = details
        if let sourceID, let t = atSourceTime {
            m.defaultsChanges.append(SessionDefaultsChange(sourceID: sourceID, atSourceTime: t, details: details))
        }
        m.log.append(SessionLogEntry(at: now, text: "Kick settings: \(details.summary)"))
    }

    static func addMark(_ m: inout TrainingSessionManifest, sourceID: UUID, at time: Double, now: Date) {
        m.marks.append(SessionMark(id: UUID(), sourceID: sourceID, sourceTime: time, createdAt: now))
    }

    /// Removes a mark (it was only a hint; no kick or recording is affected).
    static func removeMark(_ m: inout TrainingSessionManifest, markID: UUID, now: Date) {
        guard m.marks.contains(where: { $0.id == markID }) else { return }
        m.marks.removeAll { $0.id == markID }
        m.log.append(SessionLogEntry(at: now, text: "Dismissed a mark"))
    }

    // MARK: Candidates from the scan

    /// Adds the scan's candidates for a source (replacing earlier AUTOMATIC candidates of
    /// that source that were never confirmed, analyzed or edited — the athlete's work is kept).
    static func applyDiscovery(_ m: inout TrainingSessionManifest, sourceID: UUID, found: [DiscoveredKick], now: Date) {
        guard let source = m.source(sourceID) else { return }
        let duration = source.durationSeconds ?? .greatestFiniteMagnitude
        m.candidates.removeAll { c in
            c.sourceID == sourceID && c.discovery == .automatic && c.kickID == nil && !c.boundariesEditedByUser
                && c.contactProvenance != .user && c.status != .rejected && c.status != .practiceSwing
        }
        let kept = m.candidates(of: sourceID)
        let sorted = found.sorted { $0.contactTime < $1.contactTime }
        for (i, k) in sorted.enumerated() {
            // Don't duplicate a kick the athlete already has (manual or analyzed).
            if kept.contains(where: { abs(($0.contactTime ?? $0.startTime) - k.contactTime) < KickDiscovery.minimumSeparationSeconds && $0.status.isActive }) { continue }
            // A previously rejected spot stays rejected (the athlete said it isn't a kick).
            if kept.contains(where: { abs(($0.contactTime ?? $0.startTime) - k.contactTime) < 1 && !$0.status.isActive }) { continue }
            let b = ClipBoundaryPolicy.boundaries(contact: k.contactTime, approachStart: k.approachStart, sourceDuration: duration,
                                                  previousContact: i > 0 ? sorted[i - 1].contactTime : nil,
                                                  nextContact: i + 1 < sorted.count ? sorted[i + 1].contactTime : nil)
            m.candidates.append(SessionKickCandidate(
                id: UUID(), sourceID: sourceID, discovery: .automatic, status: k.autoVerify ? .pending : .needsReview, evidence: k.evidence,
                startTime: b.start, endTime: b.end, contactTime: k.contactTime, contactUncertainty: k.contactUncertainty,
                contactProvenance: .scan, approachIncomplete: b.approachIncomplete, followThroughIncomplete: b.followThroughIncomplete,
                details: m.details(sourceID: sourceID, at: k.contactTime), createdAt: now))
        }
        m.processing.scan[sourceID.uuidString] = .done
        m.log.append(SessionLogEntry(at: now, text: "Scan found \(sorted.count) possible kick\(sorted.count == 1 ? "" : "s") (\(sorted.filter(\.autoVerify).count) strong)"))
    }

    // MARK: Manual corrections

    /// Adds a kick the scan missed, around a contact time the athlete chose.
    @discardableResult
    static func addManualKick(_ m: inout TrainingSessionManifest, sourceID: UUID, contact: Double, now: Date) throws -> SessionKickCandidate {
        guard let source = m.source(sourceID) else { throw EditError.unknownSource }
        let others = m.candidates(of: sourceID).filter(\.status.isActive).compactMap(\.contactTime)
        let b = ClipBoundaryPolicy.boundaries(contact: contact, sourceDuration: source.durationSeconds ?? .greatestFiniteMagnitude,
                                              previousContact: others.filter { $0 < contact }.max(),
                                              nextContact: others.filter { $0 > contact }.min())
        let c = SessionKickCandidate(id: UUID(), sourceID: sourceID, discovery: .manual, status: .pending,
                                     evidence: CandidateEvidence(notes: ["Added by you."]),
                                     startTime: b.start, endTime: b.end, contactTime: contact, contactUncertainty: nil,
                                     contactProvenance: .user, approachIncomplete: b.approachIncomplete,
                                     followThroughIncomplete: b.followThroughIncomplete,
                                     details: m.details(sourceID: sourceID, at: contact), createdAt: now)
        m.candidates.append(c)
        m.log.append(SessionLogEntry(at: now, text: String(format: "Kick added by you at %.2f s", contact)))
        return c
    }

    /// Marks a candidate as not a kick (or a practice swing). The recording isn't touched;
    /// a Kick already created for it is left for the caller to remove (with confirmation).
    static func reject(_ m: inout TrainingSessionManifest, candidateID: UUID, practiceSwing: Bool, now: Date) throws {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        m.candidates[i].status = practiceSwing ? .practiceSwing : .rejected
        if m.candidates[i].analysis.status == .queued { m.candidates[i].analysis.status = .notQueued }
        m.pairs.removeAll { $0.primaryCandidateID == candidateID || $0.secondaryCandidateID == candidateID }
        m.log.append(SessionLogEntry(at: now, text: practiceSwing ? "Marked a practice swing" : "Marked not a kick"))
    }

    /// Accepts a needs-review candidate as a kick (it will be analyzed).
    static func accept(_ m: inout TrainingSessionManifest, candidateID: UUID, now: Date) throws {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        if m.candidates[i].status == .needsReview || !m.candidates[i].status.isActive { m.candidates[i].status = .pending }
        m.log.append(SessionLogEntry(at: now, text: "Kick accepted by you"))
    }

    /// New clip boundaries. They must contain the contact with the protected margins, and
    /// stay inside the recording.
    static func adjustBoundaries(_ m: inout TrainingSessionManifest, candidateID: UUID, start: Double, end: Double, now: Date) throws {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        let duration = m.source(m.candidates[i].sourceID)?.durationSeconds ?? .greatestFiniteMagnitude
        guard start >= 0, end <= duration + 1e-6, end > start else { throw EditError.boundariesInvalid("The clip must lie inside the recording.") }
        guard end - start <= AnalysisLimits.maximumVideoSeconds else { throw EditError.boundariesInvalid("A kick clip can be at most \(Int(AnalysisLimits.maximumVideoSeconds)) s.") }
        if let c = m.candidates[i].contactTime {
            guard start <= c - ClipBoundaryPolicy.protectedBefore + 1e-6, end >= c + ClipBoundaryPolicy.protectedAfter - 1e-6 else {
                throw EditError.boundariesInvalid("Keep at least \(ClipBoundaryPolicy.protectedBefore) s before and \(ClipBoundaryPolicy.protectedAfter) s after contact, so the plant and strike stay in the clip.")
            }
            m.candidates[i].approachIncomplete = c - start < ClipBoundaryPolicy.minimumBefore - 1e-9
            m.candidates[i].followThroughIncomplete = end - c < ClipBoundaryPolicy.minimumAfter - 1e-9
        }
        m.candidates[i].startTime = start
        m.candidates[i].endTime = end
        m.candidates[i].boundariesEditedByUser = true
        m.log.append(SessionLogEntry(at: now, text: String(format: "Clip boundaries set by you: %.2f–%.2f s", start, end)))
    }

    /// The athlete confirms the contact moment (source time).
    static func confirmContact(_ m: inout TrainingSessionManifest, candidateID: UUID, at time: Double, now: Date) throws {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        let c = m.candidates[i]
        guard time >= c.startTime + ClipBoundaryPolicy.protectedBefore - 1e-6, time <= c.endTime - ClipBoundaryPolicy.protectedAfter + 1e-6 else {
            throw EditError.contactOutsideClip
        }
        m.candidates[i].contactTime = time
        m.candidates[i].contactUncertainty = nil
        m.candidates[i].contactProvenance = .user
        m.log.append(SessionLogEntry(at: now, text: String(format: "Contact confirmed by you at %.3f s", time)))
    }

    /// Splits one candidate holding two kicks into two, around two contact times.
    static func split(_ m: inout TrainingSessionManifest, candidateID: UUID, firstContact: Double, secondContact: Double, now: Date) throws -> [UUID] {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        let c = m.candidates[i]
        guard c.kickID == nil else { throw EditError.cannotSplit("This kick was already analyzed. Mark it not a kick and add the two kicks instead.") }
        guard secondContact - firstContact >= 2 * ClipBoundaryPolicy.protectedAfter else { throw EditError.cannotSplit("The two contacts are too close together.") }
        let duration = m.source(c.sourceID)?.durationSeconds ?? .greatestFiniteMagnitude
        var ids: [UUID] = []
        for (contact, prev, next) in [(firstContact, nil as Double?, secondContact as Double?), (secondContact, firstContact, nil)] {
            let b = ClipBoundaryPolicy.boundaries(contact: contact, sourceDuration: duration, previousContact: prev, nextContact: next)
            let n = SessionKickCandidate(id: UUID(), sourceID: c.sourceID, discovery: .edited, status: .pending,
                                         evidence: CandidateEvidence(notes: ["Split by you."]), startTime: b.start, endTime: b.end,
                                         contactTime: contact, contactProvenance: .user, approachIncomplete: b.approachIncomplete,
                                         followThroughIncomplete: b.followThroughIncomplete,
                                         details: m.details(sourceID: c.sourceID, at: contact), createdAt: now)
            m.candidates.append(n)
            ids.append(n.id)
        }
        m.candidates[i].status = .rejected
        m.candidates[i].evidence.notes.append("Replaced by two kicks (split by you).")
        m.log.append(SessionLogEntry(at: now, text: "Split one candidate into two"))
        return ids
    }

    /// Merges two candidates that are the same kick into one (keeping the analyzed one if any).
    static func merge(_ m: inout TrainingSessionManifest, _ a: UUID, _ b: UUID, now: Date) throws -> UUID {
        guard let ia = m.candidates.firstIndex(where: { $0.id == a }), let ib = m.candidates.firstIndex(where: { $0.id == b }) else {
            throw EditError.unknownCandidate
        }
        let ca = m.candidates[ia], cb = m.candidates[ib]
        guard ca.sourceID == cb.sourceID else { throw EditError.cannotMerge("They come from different recordings; pair them instead.") }
        guard ca.kickID == nil || cb.kickID == nil else { throw EditError.cannotMerge("Both were analyzed as kicks. Mark one of them not a kick.") }
        let keep = ca.kickID != nil ? ia : (cb.kickID != nil ? ib : (ca.evidence.score >= cb.evidence.score ? ia : ib))
        let drop = keep == ia ? ib : ia
        let start = min(ca.startTime, cb.startTime), end = max(ca.endTime, cb.endTime)
        guard end - start <= AnalysisLimits.maximumVideoSeconds else {
            throw EditError.cannotMerge("The merged clip would be longer than \(Int(AnalysisLimits.maximumVideoSeconds)) s.")
        }
        m.candidates[keep].startTime = start
        m.candidates[keep].endTime = end
        m.candidates[keep].boundariesEditedByUser = true
        m.candidates[drop].status = .rejected
        m.candidates[drop].evidence.notes.append("Merged into another candidate by you.")
        m.log.append(SessionLogEntry(at: now, text: "Merged two candidates"))
        return m.candidates[keep].id
    }

    /// Per-kick details (distance, hash, type) — never inferred from video.
    static func setDetails(_ m: inout TrainingSessionManifest, candidateID: UUID, details: SessionKickDetails, now: Date) throws {
        guard let i = m.candidates.firstIndex(where: { $0.id == candidateID }) else { throw EditError.unknownCandidate }
        m.candidates[i].details = details
        m.log.append(SessionLogEntry(at: now, text: "Kick details set: \(details.summary)"))
    }

    // MARK: Sources

    /// A source may be deleted only when no unanalyzed candidate still needs its footage
    /// (analyzed kicks have their own exported clip).
    static func candidatesDependingOn(_ m: TrainingSessionManifest, sourceID: UUID) -> Int {
        m.candidates.filter { $0.sourceID == sourceID && $0.status.isActive && $0.kickID == nil }.count
    }

    static func removeSource(_ m: inout TrainingSessionManifest, sourceID: UUID, now: Date) throws {
        let n = candidatesDependingOn(m, sourceID: sourceID)
        guard n == 0 else { throw EditError.sourceInUse(n) }
        m.sources.removeAll { $0.id == sourceID }
        m.log.append(SessionLogEntry(at: now, text: "Recording deleted by you"))
    }
}

/// Clip time ↔ source time (an exported clip starts at `clipStartInSource`).
enum ClipTimeMapping {
    static func sourceTime(clipTime: Double, clipStartInSource: Double) -> Double { clipStartInSource + clipTime }
    static func clipTime(sourceTime: Double, clipStartInSource: Double) -> Double { sourceTime - clipStartInSource }
}
