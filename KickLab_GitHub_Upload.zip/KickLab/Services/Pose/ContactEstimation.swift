import Foundation

// Step 12C: multi-candidate, evidence-based contact estimation.
//
// Without ball tracking, contact is always an ESTIMATE. Before Step 12C it was simply the
// highest kicking-ankle speed in the clip. On a real 30 fps recording that peak came
// 0.17 s (five frames) before the visible strike, and plant and follow-through, which
// are searched relative to contact, were then looked for in the wrong place.
//
// Now every local kicking-ankle speed peak is a candidate. Each candidate is scored on
// lines of evidence that come from DIFFERENT body parts, so they are not just restating
// the same measurement:
//
//   K  kicking-foot kinematics: relative speed, a supported (non-spike) swing, forward
//      direction, continued forward travel afterwards. These all come from the same
//      ankle, so together they count as ONE line of evidence.
//   P  the plant foot (a different joint) at rest just before or at the candidate.
//   H  the hips (body centre) slowing into the candidate: approach → plant transition.
//   G  timing relative to the kicking foot passing the plant foot. It is geometric, but
//      it shares the kicking ankle, so it counts as HALF an independent line.
//
// Candidates are ranked deterministically (score, then speed, then earlier time). Hard
// rejections: isolated one-sample spikes and backward motion (backswing, recovery).
// Nothing here reads a manually marked contact time.

/// One candidate moment of foot–ball contact and the evidence for it.
struct ContactCandidate: Codable, Equatable, Sendable {
    /// Sample time of the local kicking-ankle speed peak.
    var time: Double
    /// Sub-sample peak time (parabola through the neighbours).
    var refinedTime: Double
    /// Body lengths per second.
    var peakSpeed: Double
    /// 0...1 per line of evidence; nil when it couldn't be observed.
    var relativeSpeed: Double
    var swingSupport: Double
    var forwardDirection: Double?
    var plantSupport: Double?
    var passTiming: Double?
    var bodyTransition: Double?
    var followThrough: Double?
    /// Weighted evidence score, 0...1 (0 when rejected).
    var score: Double
    /// Independent lines that clearly support it (K = 1, P = 1, H = 1, G = 0.5).
    var independentSupport: Double
    var supportingSignals: [String]
    var rejectionReasons: [String]
    var selected: Bool
    /// Step 12D: the contact time this candidate implies (its speed peak, or later when the
    /// plant landing or the foot reaching the plant foot comes after the peak), and why.
    var strikeTime: Double? = nil
    /// "speedPeak", "plantAndFootPassing" or "user".
    var timingBasis: String? = nil
    /// Step 12D: inside the selected kick window.
    var insideKickWindow: Bool? = nil

    var isRejected: Bool { !rejectionReasons.isEmpty }
}

/// The contact decision and everything considered.
struct ContactEstimate: Equatable, Sendable {
    var candidates: [ContactCandidate]
    /// Index into `candidates` of the chosen one (nil = no contact estimate).
    var selectedIndex: Int?
    /// Index of the best rival at least `rivalSeparationSeconds` away.
    var runnerUpIndex: Int?
    var isAmbiguous: Bool
    /// 0...1
    var confidence: Double
    /// ± seconds around the selected time.
    var uncertaintySeconds: Double?
    /// Conflicts between cues, in plain language.
    var conflicts: [String]
    /// Why no contact was chosen (when `selectedIndex` is nil).
    var unavailableReason: String?
    /// The plant-ankle speed series (filtered) and still threshold used for plant support.
    var plantStillThreshold: Double
    var plantNoiseFloor: Double?

    var selected: ContactCandidate? { selectedIndex.map { candidates[$0] } }
    /// Step 12D: the contact time to use (the selected candidate's strike time).
    var strikeTime: Double? { selected.map { $0.strikeTime ?? $0.time } }
}

enum ContactEstimator {
    /// Version of the contact and phase rules, recorded in diagnostics.
    /// contact-candidates-1 (engine 2.2.0) ranked every speed peak in the clip;
    /// contact-window-2 (engine 2.3.0) ranks only peaks inside the kick window, uses
    /// hip-relative foot motion, requires a real plant landing and a foot coming from
    /// behind, and keeps contact after the plant landing and the foot passing.
    static let algorithmVersion = "contact-window-2"

    // Weights of each line of evidence in the score (sum 1). Unobservable evidence counts
    // as neutral (half its weight).
    static let weightRelativeSpeed = 0.25
    static let weightSwingSupport = 0.10
    static let weightForward = 0.10
    static let weightPlant = 0.20
    static let weightPass = 0.15
    static let weightBody = 0.10
    static let weightFollow = 0.10

    /// Below this best score there is no contact estimate.
    static let minimumScore = 0.35
    /// A rival within this score margin, at least `rivalSeparationSeconds` away, makes
    /// contact ambiguous.
    static let ambiguityMargin = 0.08
    static let rivalSeparationSeconds = 0.25
    /// Peaks closer than this are one motion (the faster is kept).
    static let mergeSeconds = 0.08
    static let maximumCandidates = 8
    /// A peak whose larger neighbour is below this fraction of it is an isolated spike.
    static let minimumNeighbourRatio = 0.3
    /// Evidence at or above this counts as clearly supporting.
    static let supportLevel = 0.6
    /// Contact usually happens from just before to shortly after the kicking foot passes
    /// the plant foot (the ball sits beside or a little ahead of the plant foot).
    static let passWindow: ClosedRange<Double> = -0.04...0.15
    /// A strike carries the foot forward: over −0.1…+0.2 s, net forward travel must be at
    /// least this fraction of the path the foot covered.
    static let minimumNetForwardTravel = 0.3
    /// Step 12D: hip-relative forward share of the foot's motion below which a peak is not
    /// a strike (a backswing whips up and back; a strike drives forward).
    static let minimumForwardCosine = 0.3
    /// Step 12D: in the kick window, a swing slower than this fraction of the strongest
    /// valid swing is follow-through or recovery motion, not the kick — however "clean"
    /// its other evidence looks.
    static let secondaryMotionFraction = 0.5
    /// Step 12D: the strike can be moved at most this long after the speed peak by the
    /// plant landing / foot-passing order constraint.
    static let maximumStrikeDelay = 0.25
    /// Below this analysis frame rate, contact timing is coarse.
    static let minimumUsefulFrameRate = 15.0

    /// The weighted evidence score (unobservable evidence counts as neutral, 0.5).
    static func score(relativeSpeed: Double, swingSupport: Double, forwardDirection: Double?, plantSupport: Double?,
                      passTiming: Double?, bodyTransition: Double?, followThrough: Double?) -> Double {
        func neutral(_ x: Double?) -> Double { x ?? 0.5 }
        let kinematic = weightRelativeSpeed * relativeSpeed + weightSwingSupport * swingSupport + weightForward * neutral(forwardDirection)
        let other = weightPlant * neutral(plantSupport) + weightPass * neutral(passTiming) + weightBody * neutral(bodyTransition)
            + weightFollow * neutral(followThrough)
        return kinematic + other
    }

    /// Local maxima at or above `minimum` (plateaus count once, at their first sample).
    static func localPeaks(_ speed: [Double?], _ times: [Double], minimum: Double) -> [Int] {
        times.indices.filter { i in
            guard let v = speed[i], v >= minimum else { return false }
            let before = i > 0 ? speed[i - 1] : nil
            let after = i + 1 < times.count ? speed[i + 1] : nil
            return (before.map { v >= $0 } ?? true) && (after.map { v > $0 } ?? true)
        }
    }

    /// Kicking-ankle forward velocity relative to the hips: body translation and camera
    /// panning cancel out, leaving the leg's own swing.
    static func hipRelativeForward(_ signals: PoseSignalSet) -> [Double?] {
        let foot = signals.values(.kickingAnkleForwardVelocity)
        let hips = signals.values(.bodyForwardVelocity)
        return foot.indices.map { i in
            guard let f = foot[i] else { return nil }
            return f - (hips[i] ?? 0)
        }
    }

    static func estimate(_ signals: PoseSignalSet, profile: KickPhaseProfile, window: KickWindow? = nil,
                         plantTouchdown: Double? = nil) -> ContactEstimate {
        let times = signals.timestamps
        let speed = signals.values(.kickingAnkleSpeed)
        let forward = hipRelativeForward(signals)
        let fps = KickPhaseDetector.framesPerSecond(times)
        let usesPlant = profile.support == .full

        let plantSpeed = KickPhaseDetector.medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let bodySpeed = signals.values(.bodyCenterSpeed)
        let noiseFloor = KickPhaseDetector.plantNoiseFloor(plantSpeed, bodySpeed, profile: profile)
        var threshold = profile.plantStillSpeedThreshold
        if let noiseFloor, KickPhaseDetector.noiseFloorMultiplier * noiseFloor > threshold {
            threshold = min(KickPhaseDetector.noiseFloorMultiplier * noiseFloor, KickPhaseDetector.plantStillSpeedCeiling)
        }

        // Candidates: local speed maxima at or above the minimum kick speed.
        let peaks = localPeaks(speed, times, minimum: profile.contactMinimumPeakSpeed)
        // Merge peaks of one motion.
        var merged: [Int] = []
        for i in peaks {
            if let last = merged.last, times[i] - times[last] < mergeSeconds {
                if (speed[i] ?? 0) > (speed[last] ?? 0) { merged[merged.count - 1] = i }
            } else {
                merged.append(i)
            }
        }
        let kept = merged.sorted { (speed[$0] ?? 0) > (speed[$1] ?? 0) }.prefix(maximumCandidates).sorted()
        var empty = ContactEstimate(candidates: [], selectedIndex: nil, runnerUpIndex: nil, isAmbiguous: false,
                                    confidence: 0, uncertaintySeconds: nil, conflicts: [], unavailableReason: nil,
                                    plantStillThreshold: threshold, plantNoiseFloor: noiseFloor)
        // Relative speed is judged among candidates inside the kick window, when there is one.
        let pool = window.map { w in kept.filter { w.containsStrike(times[$0]) } } ?? Array(kept)
        guard let fastest = (pool.isEmpty ? Array(kept) : pool).compactMap({ speed[$0] }).max(), fastest > 0 else {
            empty.unavailableReason = "No kicking motion was found."
            return empty
        }

        let ahead = signals.values(.kickingAnkleAheadOfPlant)
        let bodyForward = signals.values(.bodyForwardVelocity)
        let offset = signals.values(.kickingAnkleForwardOffset)
        let directionKnown = signals.travelDirection != 0

        var candidates: [ContactCandidate] = kept.map { i in
            let v = speed[i] ?? 0
            let t = times[i]
            var reasons: [String] = []
            var supports: [String] = []

            // K: swing support — neighbours carry the motion; a spike stands alone.
            let neighbour = max(i > 0 ? speed[i - 1] ?? 0 : 0, i + 1 < times.count ? speed[i + 1] ?? 0 : 0)
            let ratio = v > 0 ? neighbour / v : 0
            var swing = clamp((ratio - minimumNeighbourRatio) / 0.4)
            if let straight = straightness(forward, speed, times, around: i) {
                swing *= clamp((straight - 0.2) / 0.5)
            }
            if ratio < minimumNeighbourRatio { reasons.append("isolated one-sample speed spike (pose noise or a label error)") }
            let inside = window.map { $0.containsStrike(t) }
            if inside == false {
                reasons.append("outside the kick window (preparation, walking or recovery movement)")
            }
            if directionKnown, let travel = netForwardTravel(forward, speed, times, at: t), travel < minimumNetForwardTravel {
                reasons.append(String(format: "no net forward travel around the peak (%.0f%% of the path): out-and-back, mostly upward, or a pose glitch", travel * 100))
            }
            if swing >= supportLevel { supports.append("supported swing") }

            // K: direction — a strike moves the foot forward.
            var direction: Double?
            if directionKnown, let cosine = forwardCosine(forward, speed, around: i) {
                direction = clamp(cosine / 0.6)
                if cosine < minimumForwardCosine {
                    reasons.append("not a forward strike: relative to the hips the foot moves mostly upward or backward (backswing, lift or recovery)")
                }
                if cosine >= 0.36 { supports.append("forward foot motion") }
            }

            // P: plant foot at rest (different joint).
            var plant: Double?
            if usesPlant {
                plant = plantSupport(plantSpeed, times, at: t, threshold: threshold, fps: fps)
                // A foot that was never moving (the athlete standing) is not a plant: the
                // foot must have come in from a step.
                if plant != nil, !footArrived(plantSpeed, times, before: t, threshold: threshold) {
                    plant = plant.map { $0 * 0.3 }
                }
                if let p = plant, p >= supportLevel { supports.append("plant foot landed and at rest") }
            }

            // G: timing relative to the kicking foot passing the plant foot.
            var pass: Double?
            if usesPlant, directionKnown, let crossing = KickPhaseDetector.anklePassTime(ahead, times, near: t),
               cameFromBehind(ahead, times, before: crossing) {
                let delta = t - crossing
                if delta < passWindow.lowerBound {
                    pass = clamp(1 - (passWindow.lowerBound - delta) / 0.1)
                } else if delta > passWindow.upperBound {
                    pass = clamp(1 - (delta - passWindow.upperBound) / 0.15)
                } else {
                    pass = 1
                }
                if let p = pass, p >= supportLevel { supports.append("kicking foot at or past the plant foot") }
            }

            // H: hips slowing into the candidate.
            let body = bodyTransition(bodyForward, times, at: t)
            if let b = body, b >= supportLevel { supports.append("hips slowing (approach to plant)") }

            // K: continued forward travel after the candidate.
            let follow = followSupport(offset, speed, times, at: i, peak: v)
            if let f = follow, f >= supportLevel { supports.append("foot keeps travelling forward") }

            let relative = v / fastest
            var score = Self.score(relativeSpeed: relative, swingSupport: swing, forwardDirection: direction, plantSupport: plant,
                                   passTiming: pass, bodyTransition: body, followThrough: follow)
            if !reasons.isEmpty { score = 0 }

            let kinematic = swing >= 0.3 && (direction ?? 1) >= 0.3
            var lines = kinematic ? 1.0 : 0
            if let plant, plant >= supportLevel { lines += 1 }
            if let body, body >= supportLevel { lines += 1 }
            if let pass, pass >= supportLevel { lines += 0.5 }

            return ContactCandidate(
                time: t, refinedTime: KickPhaseDetector.refinedPeakTime(speed, times, i), peakSpeed: round3(v),
                relativeSpeed: round3(relative), swingSupport: round3(swing), forwardDirection: direction.map(round3),
                plantSupport: plant.map(round3), passTiming: pass.map(round3), bodyTransition: body.map(round3),
                followThrough: follow.map(round3), score: round3(score), independentSupport: lines,
                supportingSignals: supports, rejectionReasons: reasons, selected: false, insideKickWindow: inside
            )
        }

        // Step 12D: inside the kick window, weak motions are follow-through or recovery.
        if window != nil {
            let strongest = candidates.filter { !$0.isRejected }.map(\.peakSpeed).max() ?? 0
            for i in candidates.indices where !candidates[i].isRejected && candidates[i].peakSpeed < secondaryMotionFraction * strongest {
                candidates[i].rejectionReasons.append(String(format: "secondary motion: %.0f%% of the strongest swing in the kick window (follow-through or recovery)",
                                                             100 * candidates[i].peakSpeed / strongest))
                candidates[i].score = 0
            }
        }

        // Rank: score, then speed, then the earlier time. Deterministic.
        let order = candidates.indices.filter { !candidates[$0].isRejected }.sorted { a, b in
            let x = candidates[a], y = candidates[b]
            if x.score != y.score { return x.score > y.score }
            if x.peakSpeed != y.peakSpeed { return x.peakSpeed > y.peakSpeed }
            return x.time < y.time
        }
        guard let best = order.first, candidates[best].score >= minimumScore else {
            for i in candidates.indices where !candidates[i].isRejected {
                candidates[i].rejectionReasons.append(String(format: "evidence score %.2f below %.2f", candidates[i].score, minimumScore))
            }
            empty.candidates = candidates
            empty.unavailableReason = "Kick-like motions were found, but none had enough supporting evidence to estimate contact."
            return empty
        }
        candidates[best].selected = true
        let chosen = candidates[best]
        for i in order.dropFirst() {
            candidates[i].rejectionReasons.append(String(format: "lower evidence score (%.2f vs %.2f)", candidates[i].score, chosen.score))
        }
        let runnerUp = order.dropFirst().first { abs(candidates[$0].time - chosen.time) >= rivalSeparationSeconds }
        let isAmbiguous = runnerUp.map { candidates[$0].score >= chosen.score - ambiguityMargin } ?? false

        var conflicts: [String] = []
        if let fastestIndex = candidates.indices.max(by: { candidates[$0].peakSpeed < candidates[$1].peakSpeed }),
           fastestIndex != best {
            let f = candidates[fastestIndex]
            conflicts.append(String(format: "The fastest foot motion (%.2f s) was not chosen as contact: %@.", f.time,
                                    f.rejectionReasons.first ?? "weaker supporting evidence"))
        }
        if let p = chosen.plantSupport, p < 0.3, plantTouchdown == nil {
            conflicts.append("The plant foot was not at rest at the estimated contact.")
        }
        if let g = chosen.passTiming, g < 0.5 {
            conflicts.append("The estimated contact is not where the kicking foot passes the plant foot.")
        }

        // Step 12D: chronological order. The strike can't come before the plant foot lands,
        // or before the kicking foot reaches the plant foot (the ball sits beside or a little
        // ahead of it). When the measured speed peak is earlier — the fast part of the swing
        // seen before the foot blurs or merges with the plant leg at 30 fps — contact is
        // timed from those two events instead, with lower confidence.
        var strike = chosen.time
        var basis = "speedPeak"
        var orderFactor = 1.0
        var orderUncertainty = 0.0
        var bound: Double?
        if let plant = plantTouchdown { bound = plant + 1 / fps }
        if usesPlant, directionKnown, let crossing = KickPhaseDetector.anklePassTime(ahead, times, near: chosen.time),
           crossing >= chosen.time - 0.1, cameFromBehind(ahead, times, before: crossing) {
            bound = max(bound ?? -.infinity, crossing - 0.03)
        }
        if let bound, bound > chosen.time + 1e-9 {
            if bound <= chosen.time + maximumStrikeDelay + 1e-9, let index = times.firstIndex(where: { $0 >= bound - 1e-9 }) {
                strike = times[index]
                basis = "plantAndFootPassing"
                orderFactor = 0.75
                orderUncertainty = (strike - chosen.time) / 2
                conflicts.append(String(format: "Kicking-foot speed peaked at %.2f s, before the plant landing / the foot reaching the plant foot; contact is timed at %.2f s from those events.",
                                        chosen.time, strike))
            } else {
                orderFactor = 0.5
                orderUncertainty = bound - chosen.time
                conflicts.append(String(format: "Kicking-foot speed peaked at %.2f s, well before the plant landing / the foot reaching the plant foot (%.2f s): the contact time is uncertain.",
                                        chosen.time, bound))
            }
        }
        candidates[best].strikeTime = strike
        candidates[best].timingBasis = basis

        // Confidence from independent support, temporal resolution and the margin.
        var confidence = min(0.9, 0.3 + 0.17 * (chosen.independentSupport - 1)) * orderFactor
        if fps < minimumUsefulFrameRate {
            confidence *= 0.6
            conflicts.append(String(format: "Only %.0f analyzed frames per second: contact timing is coarse.", fps))
        }
        if isAmbiguous { confidence *= 0.4 }
        var uncertainty = max(1 / fps, 0.02)
        if let g = chosen.passTiming, g < 0.5 { uncertainty += 0.05 }
        if isAmbiguous, let r = runnerUp { uncertainty = max(uncertainty, abs(candidates[r].time - chosen.time)) }
        uncertainty += orderUncertainty

        return ContactEstimate(
            candidates: candidates, selectedIndex: best, runnerUpIndex: runnerUp, isAmbiguous: isAmbiguous,
            confidence: round3(max(0, confidence)), uncertaintySeconds: round3(uncertainty), conflicts: conflicts,
            unavailableReason: nil, plantStillThreshold: threshold, plantNoiseFloor: noiseFloor
        )
    }

    // MARK: Evidence helpers

    static func clamp(_ x: Double) -> Double { min(1, max(0, x)) }
    static func round3(_ x: Double) -> Double { (x * 1000).rounded() / 1000 }

    /// |net forward travel| ÷ path length over ±2 samples. A swing is mostly one way; a
    /// jitter spike goes back and forth.
    static func straightness(_ forward: [Double?], _ speed: [Double?], _ times: [Double], around i: Int) -> Double? {
        let window = max(0, i - 2)...min(times.count - 1, i + 2)
        var net = 0.0
        var path = 0.0
        for j in window where j > window.lowerBound {
            let dt = times[j] - times[j - 1]
            guard let f = forward[j], let s = speed[j] else { return nil }
            net += f * dt
            path += s * dt
        }
        return path > 0 ? abs(net) / path : nil
    }

    /// Step 12D: the plant foot was moving (a step, ≥ 1.5 × the still threshold) before coming to rest near `t`, not
    /// standing still all along.
    static func footArrived(_ plant: [Double?], _ times: [Double], before t: Double, threshold: Double) -> Bool {
        times.indices.contains { i in
            times[i] >= t - 0.6 - 1e-9 && times[i] <= t - 0.05 + 1e-9 && (plant[i] ?? 0) >= 1.5 * threshold
        }
    }

    /// Step 12D: the kicking foot was clearly behind the plant foot (≥ 0.3 torso lengths)
    /// within the half second before passing it — a real swing through, not two feet side
    /// by side.
    static func cameFromBehind(_ ahead: [Double?], _ times: [Double], before crossing: Double) -> Bool {
        times.indices.contains { i in
            times[i] >= crossing - 0.5 - 1e-9 && times[i] <= crossing + 1e-9 && (ahead[i] ?? 0) <= -0.3
        }
    }

    /// Net forward travel ÷ path length from 0.1 s before to 0.2 s after the peak.
    static func netForwardTravel(_ forward: [Double?], _ speed: [Double?], _ times: [Double], at t: Double) -> Double? {
        let window = times.indices.filter { times[$0] >= t - 0.1 - 1e-9 && times[$0] <= t + 0.2 + 1e-9 }
        guard window.count >= 3 else { return nil }
        var net = 0.0
        var path = 0.0
        for j in window.dropFirst() {
            guard let f = forward[j], let s = speed[j] else { return nil }
            let dt = times[j] - times[j - 1]
            net += f * dt
            path += s * dt
        }
        return path > 0 ? net / path : nil
    }

    /// Mean forward velocity ÷ mean speed over the peak and its neighbours.
    static func forwardCosine(_ forward: [Double?], _ speed: [Double?], around i: Int) -> Double? {
        let window = [i - 1, i, i + 1].filter { forward.indices.contains($0) }
        let f = window.compactMap { forward[$0] }
        let s = window.compactMap { speed[$0] }
        guard f.count == window.count, s.count == window.count else { return nil }
        let meanSpeed = s.reduce(0, +) / Double(s.count)
        return meanSpeed > 0 ? (f.reduce(0, +) / Double(f.count)) / meanSpeed : nil
    }

    /// 0.6 × fraction of samples at rest in the last 0.15 s up to the candidate, plus 0.4
    /// when a still run (≥ 0.05 s) began within the 0.4 s before it.
    static func plantSupport(_ plant: [Double?], _ times: [Double], at t: Double, threshold: Double, fps: Double) -> Double? {
        let recent = times.indices.filter { times[$0] >= t - 0.15 - 1e-9 && times[$0] <= t + 0.02 }
        let known = recent.compactMap { plant[$0] }
        guard !known.isEmpty else { return nil }
        let fraction = Double(known.filter { $0 <= threshold }.count) / Double(known.count)
        let minimumRun = max(2, Int((KickPhaseDetector.minimumStillSeconds * fps).rounded(.up)))
        var run = 0
        var landed = false
        for i in times.indices where times[i] >= t - 0.4 - 1e-9 && times[i] <= t + 1e-9 {
            if let v = plant[i], v <= threshold { run += 1 } else { run = 0 }
            if run >= minimumRun { landed = true }
        }
        return 0.6 * fraction + (landed ? 0.4 : 0)
    }

    /// 1 when forward hip speed falls to ≤ 60% of the approach speed into the candidate,
    /// 0 when it doesn't fall; 0.3 when there was no approach to slow from.
    static func bodyTransition(_ bodyForward: [Double?], _ times: [Double], at t: Double) -> Double? {
        func mean(_ from: Double, _ to: Double) -> Double? {
            let v = times.indices.filter { times[$0] >= from - 1e-9 && times[$0] <= to + 1e-9 }.compactMap { bodyForward[$0] }
            return v.isEmpty ? nil : v.reduce(0, +) / Double(v.count)
        }
        guard let early = mean(t - 0.45, t - 0.25), let late = mean(t - 0.1, t + 0.05) else { return nil }
        guard early >= 0.6 else { return 0.3 }
        return clamp((1 - late / early) / 0.4)
    }

    /// The foot keeps travelling forward relative to the hip, and keeps moving, for 0.1 s.
    static func followSupport(_ offset: [Double?], _ speed: [Double?], _ times: [Double], at i: Int, peak: Double) -> Double? {
        let t = times[i]
        let after = times.indices.filter { times[$0] > t + 1e-9 && times[$0] <= t + 0.1 + 1e-9 }
        guard let last = after.last else { return nil }
        var parts: [Double] = []
        if let start = offset[i], let end = offset[last] { parts.append(clamp((end - start) / 0.3)) }
        let moving = after.compactMap { speed[$0] }
        if !moving.isEmpty {
            parts.append(Double(moving.filter { $0 >= 0.25 * peak }.count) / Double(moving.count))
        }
        return parts.isEmpty ? nil : parts.reduce(0, +) / Double(parts.count)
    }
}
