import Foundation

/// Step 12G: what the user verified on one video's frames, stored on the video
/// (`VideoAsset.verificationData`). Every value is HUMAN INPUT (or measured from the frames
/// after the user located the ball) and is never read by automatic analysis or counted as
/// automatic accuracy. The contact frame itself stays in `contactTimeSeconds`.
struct VideoVerification: Codable, Equatable, Sendable {
    static let formatVersion = 1

    enum Mark: Codable, Equatable, Sendable {
        case frame(time: Double)
        case cannotTell
    }

    /// Where the user said the ball rests, on the frame at `time` (app-normalized,
    /// displayed upright), and its radius as a fraction of the displayed height.
    struct BallMark: Codable, Equatable, Sendable {
        var time: Double
        var x: Double
        var y: Double
        var radius: Double
    }

    /// Build 15: contact seen somewhere between two frames (when one frame can't be chosen).
    struct RangeMark: Codable, Equatable, Sendable {
        var start: Double
        var end: Double
    }

    /// Build 15: the football the user says was kicked (displayed-normalized center, size
    /// in displayed-height units), and which detected ball it is when picked from the list.
    struct KickedBallChoice: Codable, Equatable, Sendable {
        var x: Double
        var y: Double
        var size: Double
        var detectedBallNumber: Int?
    }

    var formatVersion = VideoVerification.formatVersion
    var plant: Mark?
    /// The first frame where the user sees the ball move.
    var firstBallMovement: Mark?
    var ballMark: BallMark?
    /// The ball's movement measured from the frames after `ballMark` (nil until run).
    var ballMotion: BallMotionResult?
    var contactRange: RangeMark? = nil
    var kickedBall: KickedBallChoice? = nil

    var isEmpty: Bool {
        plant == nil && firstBallMovement == nil && ballMark == nil && ballMotion == nil && contactRange == nil && kickedBall == nil
    }

    init(plant: Mark? = nil, firstBallMovement: Mark? = nil, ballMark: BallMark? = nil, ballMotion: BallMotionResult? = nil,
         contactRange: RangeMark? = nil, kickedBall: KickedBallChoice? = nil) {
        self.plant = plant
        self.firstBallMovement = firstBallMovement
        self.ballMark = ballMark
        self.ballMotion = ballMotion
        self.contactRange = contactRange
        self.kickedBall = kickedBall
    }

    func encoded() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(self)
    }

    static func decode(_ data: Data) -> VideoVerification? {
        try? JSONDecoder().decode(VideoVerification.self, from: data)
    }

    /// What a user-assisted reanalysis from these verified frames would use: the contact
    /// frame the user marked, else the ball's measured departure; and the plant frame.
    func assistance(contactTime: Double?) -> PhaseDetectionAssistance? {
        var a = PhaseDetectionAssistance(contactTime: contactTime)
        if case .frame(let t) = plant { a.plantTime = t }
        if contactTime == nil, ballMotion?.outcome == .departed { a.ballMotion = ballMotion }
        return a.isEmpty ? nil : a
    }
}

/// Step 12G: reads a video's ball region from its real frames (luma only). The tapped
/// display point is mapped back to the stored pixel buffer; template and frames share the
/// stored orientation, so no image is rotated.
protocol BallRegionReading: Sendable {
    /// Crops centered on the marked ball for every frame from the mark's time up to
    /// `duration` seconds later, each downsampled so the ball radius is about
    /// `targetRadius` pixels. Returns the crops and the ball radius in crop pixels.
    func crops(url: URL, mark: VideoVerification.BallMark, duration: Double, targetRadius: Double) async throws
        -> (frames: [(time: Double, image: LumaImage)], radius: Double)
}

struct UnavailableBallRegionReader: BallRegionReading {
    func crops(url: URL, mark: VideoVerification.BallMark, duration: Double, targetRadius: Double) async throws
        -> (frames: [(time: Double, image: LumaImage)], radius: Double) { ([], 0) }
}

enum LumaCropGeometry {
    /// The square crop (in stored-buffer pixels) around a ball marked in the displayed
    /// frame: center, half-size and the area-downsampling factor.
    static func crop(mark: VideoVerification.BallMark, bufferWidth: Int, bufferHeight: Int, orientation: VideoOrientation,
                     isMirrored: Bool, targetRadius: Double) -> (cx: Int, cy: Int, half: Int, factor: Int, radius: Double)? {
        guard bufferWidth > 0, bufferHeight > 0, mark.radius > 0 else { return nil }
        let stored = PoseCoordinates.stored(NormalizedPoint(x: mark.x, y: mark.y), from: orientation, isMirrored: isMirrored)
        let displayHeight = (orientation == .right || orientation == .left) ? bufferWidth : bufferHeight
        let radiusPx = mark.radius * Double(displayHeight)
        let factor = max(1, Int((radiusPx / max(targetRadius, 1)).rounded(.down)))
        let half = Int((radiusPx * 3).rounded())
        let cx = Int((stored.x * Double(bufferWidth)).rounded()), cy = Int((stored.y * Double(bufferHeight)).rounded())
        guard cx - half >= 0, cy - half >= 0, cx + half <= bufferWidth, cy + half <= bufferHeight, half >= 4 else { return nil }
        return (cx, cy, half, factor, radiusPx / Double(factor))
    }

    /// Area-average downsampling of a luma region (row-major source with `stride`).
    static func downsample(_ source: (Int, Int) -> UInt8, x0: Int, y0: Int, size: Int, factor: Int) -> LumaImage {
        let out = size / factor
        var px = [UInt8](repeating: 0, count: out * out)
        for oy in 0..<out {
            for ox in 0..<out {
                var sum = 0
                for dy in 0..<factor { for dx in 0..<factor { sum += Int(source(x0 + ox * factor + dx, y0 + oy * factor + dy)) } }
                px[oy * out + ox] = UInt8(sum / (factor * factor))
            }
        }
        return LumaImage(width: out, height: out, pixels: px)
    }
}
