import Foundation

/// Every tunable threshold for pose processing and tracking, in one place.
/// Defaults are deliberately conservative.
struct PoseProcessingConfiguration: Codable, Equatable, Sendable {
    /// Joints below this confidence become unavailable.
    var minimumJointConfidence: Double = 0.3
    /// Gaps are filled only when the two bounding measured samples are at most this far
    /// apart in time. Longer gaps (occlusions) stay unavailable.
    var maximumInterpolationGapSeconds: Double = 0.1
    /// Centered moving-average radius in samples (1 = average of 3). 0 disables smoothing.
    var smoothingRadius: Int = 1
    /// Step 12B: undo left/right knee–ankle label swaps and reject one- or two-frame
    /// knee/ankle jumps before gap filling (see `PoseLegRepair`).
    var repairsLegLabels: Bool = true

    init(minimumJointConfidence: Double = 0.3, maximumInterpolationGapSeconds: Double = 0.1, smoothingRadius: Int = 1,
         repairsLegLabels: Bool = true) {
        self.minimumJointConfidence = minimumJointConfidence
        self.maximumInterpolationGapSeconds = maximumInterpolationGapSeconds
        self.smoothingRadius = smoothingRadius
        self.repairsLegLabels = repairsLegLabels
    }

    private enum CodingKeys: String, CodingKey {
        case minimumJointConfidence, maximumInterpolationGapSeconds, smoothingRadius, repairsLegLabels
    }

    /// Files written before Step 12B have no `repairsLegLabels`; they were processed without repair.
    init(from decoder: any Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        minimumJointConfidence = try c.decode(Double.self, forKey: .minimumJointConfidence)
        maximumInterpolationGapSeconds = try c.decode(Double.self, forKey: .maximumInterpolationGapSeconds)
        smoothingRadius = try c.decode(Int.self, forKey: .smoothingRadius)
        repairsLegLabels = try c.decodeIfPresent(Bool.self, forKey: .repairsLegLabels) ?? false
    }

    static let standard = PoseProcessingConfiguration()
}

/// Pure, conservative clean-up of a kicker timeline:
/// 1. confidence thresholding → 2. leg-label repair (Step 12B) → 3. short-gap
/// interpolation → 4. light smoothing.
///
/// Provenance is preserved: measured points stay `.measured` (smoothing adjusts their
/// position only), filled points are `.interpolated`, and anything else is `.unavailable`.
/// Smoothing never creates a point where none was available.
enum PoseTimelineProcessor {
    static func process(_ timeline: KickerPoseTimeline, configuration: PoseProcessingConfiguration = .standard) -> KickerPoseTimeline {
        processWithReport(timeline, configuration: configuration).timeline
    }

    /// Processing plus what leg repair changed.
    static func processWithReport(
        _ timeline: KickerPoseTimeline,
        configuration: PoseProcessingConfiguration = .standard
    ) -> (timeline: KickerPoseTimeline, repair: PoseRepairReport) {
        let thresholded = applyConfidenceThreshold(timeline, minimum: configuration.minimumJointConfidence)
        let (repaired, report) = configuration.repairsLegLabels ? PoseLegRepair.repair(thresholded) : (thresholded, .none)
        let filled = interpolateShortGaps(repaired, maximumGapSeconds: configuration.maximumInterpolationGapSeconds)
        return (smooth(filled, radius: configuration.smoothingRadius), report)
    }

    /// Points below `minimum` confidence (or outside the frame) become unavailable.
    static func applyConfidenceThreshold(_ timeline: KickerPoseTimeline, minimum: Double) -> KickerPoseTimeline {
        var result = timeline
        for i in result.samples.indices {
            for (joint, point) in result.samples[i].joints where point.isAvailable {
                if point.confidence < minimum || !point.x.isFinite || !point.y.isFinite {
                    result.samples[i].joints[joint] = .unavailable
                }
            }
        }
        return result
    }

    /// Linearly fills gaps whose bounding MEASURED samples are at most `maximumGapSeconds`
    /// apart. Gaps at the start or end, and longer gaps, are left unavailable.
    static func interpolateShortGaps(_ timeline: KickerPoseTimeline, maximumGapSeconds: Double) -> KickerPoseTimeline {
        var result = timeline
        let samples = timeline.samples
        guard samples.count > 2 else { return result }

        for joint in PoseJoint.allCases {
            var previousMeasured: Int?
            for i in samples.indices {
                guard let point = samples[i].joints[joint], point.status == .measured else { continue }
                if let start = previousMeasured, i - start > 1 {
                    let t0 = samples[start].timestamp
                    let t1 = samples[i].timestamp
                    if t1 - t0 <= maximumGapSeconds + 1e-9, t1 > t0, let p0 = samples[start].joints[joint] {
                        for j in (start + 1)..<i {
                            let fraction = (samples[j].timestamp - t0) / (t1 - t0)
                            result.samples[j].joints[joint] = PosePoint(
                                x: p0.x + (point.x - p0.x) * fraction,
                                y: p0.y + (point.y - p0.y) * fraction,
                                confidence: min(p0.confidence, point.confidence),
                                status: .interpolated
                            )
                        }
                    }
                }
                previousMeasured = i
            }
        }
        return result
    }

    /// Centered moving average over available neighbors within `radius` samples.
    /// Only positions change; status and confidence are kept. Unavailable points stay unavailable.
    static func smooth(_ timeline: KickerPoseTimeline, radius: Int) -> KickerPoseTimeline {
        guard radius > 0 else { return timeline }
        var result = timeline
        let samples = timeline.samples
        for joint in PoseJoint.allCases {
            for i in samples.indices {
                guard let point = samples[i].joints[joint], point.isAvailable else { continue }
                let window = max(0, i - radius)...min(samples.count - 1, i + radius)
                let neighbors = window.compactMap { samples[$0].joints[joint] }.filter(\.isAvailable)
                guard neighbors.count > 1 else { continue }
                var smoothed = point
                smoothed.x = neighbors.map(\.x).reduce(0, +) / Double(neighbors.count)
                smoothed.y = neighbors.map(\.y).reduce(0, +) / Double(neighbors.count)
                result.samples[i].joints[joint] = smoothed
            }
        }
        return result
    }
}
