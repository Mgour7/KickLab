import Foundation

/// Ball tracking is NOT implemented in this version. These types define the extension
/// point so a future detector can supply measured contact times and ball flight
/// without changing the phase or artifact formats.

enum BallTrackingStatus: String, Codable, Sendable {
    /// Seen in this frame.
    case tracked
    /// Not seen; position predicted from neighbors.
    case predicted
    /// Lost (occluded or out of frame).
    case lost
    /// No ball tracker is available.
    case unavailable
}

struct BallObservation: Codable, Equatable, Sendable {
    let timestamp: Double
    /// App-normalized coordinates (see `PoseModel.swift`).
    let position: NormalizedPoint?
    /// Approximate ball radius in normalized height units.
    let radius: Double?
    let confidence: Double
    let status: BallTrackingStatus
}

struct BallTrackingResult: Codable, Equatable, Sendable {
    let status: BallTrackingStatus
    let observations: [BallObservation]
    /// When the ball first starts moving: a MEASURED contact time, when available.
    let launchTime: Double?

    static let unavailable = BallTrackingResult(status: .unavailable, observations: [], launchTime: nil)
}

/// Finds the ball in sampled frames. Implementations must run on-device.
protocol BallTrackingService: Sendable {
    var isAvailable: Bool { get }
    func track(videoID: UUID, timestamps: [Double]) async throws -> BallTrackingResult
}

/// The only implementation in this version: reports that ball tracking is unavailable,
/// so contact stays an estimate from body motion.
struct UnavailableBallTrackingService: BallTrackingService {
    var isAvailable: Bool { false }

    init() {}

    func track(videoID: UUID, timestamps: [Double]) async throws -> BallTrackingResult {
        try Task.checkCancellation()
        return .unavailable
    }
}
