import Foundation

/// Step 12F: one independent line of evidence about first contact. Cues measured on the
/// same body segment chain (knee angle, ankle height, ankle speed) are one group, because
/// they describe the same leg motion and agree with each other almost by construction.
struct ContactEvidenceGroup: Codable, Equatable, Sendable {
    /// "kickingLegDrive", "trunkLateralLean" or "football".
    var name: String
    var signals: [String]
    /// Whether the group could be observed in this clip at all.
    var observed: Bool
    /// The first-contact interval this group supports (nil when not observed).
    var earliestTime: Double?
    var latestTime: Double?
    /// Whether it overlaps the selected interval (nil when not observed).
    var agrees: Bool?
    var note: String
}

/// Step 12G: contact-intelligence-4 for depth views (filmed from behind or in front).
///
/// History. 2.5.0 picked the frame where five correlated leg cues agreed — the
/// post-contact swing (rear clip 1: 4.033 s vs 3.867 s). 2.6.0 (contact-intelligence-3)
/// took the start of the fastest knee extension, narrowed by the trunk's sideways-lean
/// peak; on the second real rear clip (IMG_1709) both happened ~3 frames BEFORE the foot
/// reached the ball, and it confidently reported 7.835 s.
///
/// What pose can and can't say. The knee's drive (from the start of its fastest
/// extension to the frame where the leg has straightened) brackets the strike on both real
/// clips, but where contact falls inside it varied (at the start on clip 1, near the middle
/// on IMG_1709), and the trunk lean led the strike. So contact-intelligence-4:
/// - reports the drive as the STRIKE WINDOW;
/// - calls it a contact ESTIMATE (middle frame) only when the window is within the contact
///   tolerance (±0.05 s, `ContactTimingCheck.toleranceSeconds`); otherwise the result is
///   "strike window, contact timing uncertain" and nothing contact-timed is measured;
/// - records the trunk lean as a clue that never moves or narrows contact;
/// - never derives the plant from contact.
/// Ball contact is only placed precisely from the video's frames (the user marks the ball
/// and `BallMotionTracker` finds when it leaves) or by the user's own frame.
enum ContactIntelligence {
    static let version = "contact-intelligence-4"
    /// Degrees per second of 2D knee extension that count as a strike drive.
    static let minimumDriveRate = 200.0
    /// The knee must extend at least this much (2D degrees) around the drive.
    static let minimumDriveExtension = 15.0
    /// Within this many degrees of its straightest, the extension is complete.
    static let extensionCompleteTolerance = 5.0
    /// A rival drive at ≥ 80% of the fastest, ≥ 0.15 s away, makes contact ambiguous.
    static let rivalDriveRatio = 0.8
    static let rivalSeparationSeconds = 0.15
    /// The trunk lean must rise at least this much (degrees) to count as a peak.
    static let minimumLeanRise = 4.0
    /// Below this 2D knee angle the projection is degenerate (shank along the line of sight).
    static let minimumPlausibleKneeAngle = 40.0
    static let oneGroupConfidence = 0.35
    /// Step 12G: a strike window without localized contact.
    static let strikeWindowConfidence = 0.15
    static let twoGroupConfidence = 0.5

    enum Decision: Equatable {
        case established(index: Int, earliest: Int, latest: Int)
        /// Step 12G: a kick's strike window was found, but pose alone can't place contact
        /// within the contact tolerance. `index` is only the window's middle.
        case strikeWindow(index: Int, earliest: Int, latest: Int)
        case notEstablished(String)
    }

    struct Result: Equatable {
        var decision: Decision
        var groups: [ContactEvidenceGroup]
        var candidates: [ContactCandidate]
        var strikeApproachStart: Int?
        var postContactMarkers: [PhaseEndpointCandidate]
        /// Before tracking coverage is applied.
        var confidence: Double
    }

    struct Drive: Equatable {
        /// The fastest extension runs from frame `index` to `index + 1`.
        var index: Int
        var rate: Double
        /// First frame where the extension is complete.
        var complete: Int
        var extensionDegrees: Double
        var footKeepsMoving: Bool
    }

    /// Knee-extension drives (local maxima of the 2D extension rate) inside `range`.
    static func drives(knee: [Double?], speed: [Double?], times: [Double], in range: ClosedRange<Double>, frame: Double) -> [Drive] {
        var rates: [(index: Int, rate: Double)] = []
        for i in times.indices where range.contains(times[i]) && i + 1 < times.count {
            guard let a = knee[i], let b = knee[i + 1], times[i + 1] - times[i] <= 1.6 * frame else { continue }
            rates.append((i, (b - a) / (times[i + 1] - times[i])))
        }
        var out: [Drive] = []
        for (k, r) in rates.enumerated() where r.rate >= minimumDriveRate {
            let prev = k > 0 && rates[k - 1].index == r.index - 1 ? rates[k - 1].rate : -.infinity
            let next = k + 1 < rates.count && rates[k + 1].index == r.index + 1 ? rates[k + 1].rate : -.infinity
            guard r.rate >= prev, r.rate > next else { continue }
            let i = r.index
            let ahead = times.indices.filter { $0 >= i && times[$0] - times[i] <= 0.3 + 1e-9 && knee[$0] != nil }
            guard let top = ahead.compactMap({ knee[$0] }).max(),
                  let complete = ahead.first(where: { $0 > i && (knee[$0] ?? -.infinity) >= top - extensionCompleteTolerance }) else { continue }
            let before = times.indices.filter { times[$0] >= times[i] - 0.25 - 1e-9 && $0 <= i }.compactMap { knee[$0] }
            let rise = top - (before.min() ?? top)
            let next15 = times.indices.filter { $0 > i && times[$0] - times[i] <= 0.15 + 1e-9 }.compactMap { speed[$0] }
            out.append(Drive(index: i, rate: r.rate, complete: complete, extensionDegrees: rise,
                             footKeepsMoving: (next15.max() ?? 0) >= 2.0))
        }
        return out
    }

    /// The trunk's sideways lean peak around the kick: (peak, plateau start, plateau end,
    /// rise) or nil when there's no clear peak.
    static func leanPeak(_ lean: [Double?], _ times: [Double], in window: ClosedRange<Double>) -> (peak: Int, start: Int, end: Int, rise: Double)? {
        let idx = times.indices.filter { window.contains(times[$0]) }
        let seen = idx.filter { lean[$0] != nil }
        guard !idx.isEmpty, Double(seen.count) / Double(idx.count) >= 0.6,
              let peak = seen.max(by: { lean[$0]! < lean[$1]! }), let top = lean[peak] else { return nil }
        let base = seen.filter { $0 <= peak }.compactMap { lean[$0] }.min() ?? top
        let rise = top - base
        guard rise >= minimumLeanRise else { return nil }
        let tolerance = max(0.5, 0.1 * rise)
        var a = peak, b = peak
        while a - 1 >= 0, window.contains(times[a - 1]), let v = lean[a - 1], v >= top - tolerance { a -= 1 }
        while b + 1 < times.count, window.contains(times[b + 1]), let v = lean[b + 1], v >= top - tolerance { b += 1 }
        return (peak, a, b, rise)
    }

    /// First contact in a depth view. `landing` is the independently found plant landing
    /// (nil when not found); `searchRange` the times where contact is physically possible.
    static func firstContact(_ signals: PoseSignalSet, lift: [Double?], searchRange: ClosedRange<Double>,
                             landingTime: Double?, frame: Double) -> Result {
        let times = signals.timestamps
        let knee = signals.values(.kickingKneeAngle).map { a in a.flatMap { $0 >= minimumPlausibleKneeAngle ? $0 : nil } }
        let speed = signals.values(.kickingAnkleSpeed)
        let lean = signals.values(.lateralTrunkLean)
        var groups: [ContactEvidenceGroup] = []
        var candidates: [ContactCandidate] = []
        var markers: [PhaseEndpointCandidate] = []

        func record(_ time: Double, _ i: Int, selected: Bool, support: [String], rejection: String?) -> ContactCandidate {
            ContactCandidate(time: time, refinedTime: time, peakSpeed: ContactEstimator.round3(speed[i] ?? 0), relativeSpeed: 0,
                             swingSupport: support.contains("kickingLegDrive") ? 1 : 0, forwardDirection: nil,
                             plantSupport: landingTime == nil ? nil : 1, passTiming: nil, bodyTransition: nil, followThrough: nil,
                             score: selected ? 1 : 0, independentSupport: Double(support.count), supportingSignals: support,
                             rejectionReasons: rejection.map { [$0] } ?? [], selected: selected, strikeTime: time,
                             timingBasis: "firstContactInterval", insideKickWindow: true)
        }
        func fail(_ reason: String) -> Result {
            Result(decision: .notEstablished(reason), groups: groups, candidates: candidates, strikeApproachStart: nil,
                   postContactMarkers: markers, confidence: 0)
        }

        // Group 1: the kicking leg's drive.
        let all = drives(knee: knee, speed: speed, times: times, in: searchRange, frame: frame)
        let valid = all.filter { $0.extensionDegrees >= minimumDriveExtension && $0.footKeepsMoving }
        for d in all where !valid.contains(d) {
            candidates.append(record(times[d.index], d.index, selected: false, support: [],
                                     rejection: d.footKeepsMoving ? String(format: "the knee extended only %.0f° (≥ %.0f° needed)", d.extensionDegrees, minimumDriveExtension)
                                                                  : "the foot stopped after it: not a strike"))
        }
        guard let best = valid.max(by: { $0.rate < $1.rate }) else {
            groups.append(ContactEvidenceGroup(name: "kickingLegDrive", signals: ["kickingKneeAngle", "kickingAnkleSpeed"], observed: false,
                                               earliestTime: nil, latestTime: nil, agrees: nil,
                                               note: "No fast knee extension (strike) was seen after the plant."))
            return fail("The kicking knee wasn't seen extending into a strike after the plant.")
        }
        let rivals = valid.filter { $0 != best && $0.rate >= rivalDriveRatio * best.rate && abs(times[$0.index] - times[best.index]) >= rivalSeparationSeconds - 1e-9 }
        if let rival = rivals.first {
            for d in [best, rival] {
                candidates.append(record(times[d.index], d.index, selected: false, support: ["kickingLegDrive"],
                                         rejection: "another knee drive is about as fast"))
            }
            return fail(String(format: "Two separate knee drives (%.3f s and %.3f s) look like strikes.", times[best.index], times[rival.index]))
        }
        for d in valid where d != best {
            candidates.append(record(times[d.index], d.index, selected: false, support: ["kickingLegDrive"],
                                     rejection: String(format: "slower drive (%.0f°/s vs %.0f°/s)", d.rate, best.rate)))
        }
        let legEarliest = best.index, legLatest = best.complete
        groups.append(ContactEvidenceGroup(
            name: "kickingLegDrive", signals: ["kickingKneeAngle", "kickingAnkleSpeed"], observed: true,
            earliestTime: times[legEarliest], latestTime: times[legLatest], agrees: true,
            note: String(format: "Fastest knee extension %.0f°/s from %.3f s; extension complete at %.3f s (%.0f° in all).",
                         best.rate, times[legEarliest], times[legLatest], best.extensionDegrees)))

        // Post-contact milestones (never first contact).
        markers.append(PhaseEndpointCandidate(kind: "kneeExtensionComplete", time: times[legLatest], accepted: false,
                                              reason: "post-contact swing: the leg has straightened"))
        let after = times.indices.filter { $0 >= legLatest && times[$0] - times[legLatest] <= 0.3 + 1e-9 }
        if let low = after.filter({ lift[$0] != nil }).min(by: { lift[$0]! < lift[$1]! }) {
            markers.append(PhaseEndpointCandidate(kind: "footLowest", time: times[low], accepted: false,
                                                  reason: "post-contact swing: the foot's lowest point in the image comes after the leg straightens"))
        }
        // Strike approach: the knee's last most-bent frame before the drive.
        // Walk back from the drive while the knee keeps getting more bent (≤ 0.25 s).
        var approachStart: Int? = knee[legEarliest] == nil ? nil : legEarliest
        while let j = approachStart, j > 0, times[legEarliest] - times[j - 1] <= 0.25 + 1e-9,
              let prev = knee[j - 1], let cur = knee[j], prev <= cur {
            approachStart = j - 1
        }

        // Step 12G: the trunk's sideways lean is RECORDED but never narrows the window. On
        // the second real rear clip (IMG_1709) it peaked three frames before the foot
        // reached the ball, so it is a clue to the strike window, not a contact marker.
        let anchor = landingTime ?? searchRange.lowerBound
        let earliest = legEarliest, latest = legLatest
        if let peak = leanPeak(lean, times, in: (anchor - 0.3)...(anchor + 0.6)) {
            let overlaps = max(earliest, peak.start) <= min(latest, peak.end)
            groups.append(ContactEvidenceGroup(
                name: "trunkLateralLean", signals: ["lateralTrunkLean"], observed: true,
                earliestTime: times[peak.start], latestTime: times[peak.end], agrees: overlaps,
                note: String(format: "The trunk's sideways lean peaked at %.3f s (%.1f° rise), level %.3f–%.3f s — %@; a clue only, it doesn't narrow contact.",
                             times[peak.peak], peak.rise, times[peak.start], times[peak.end],
                             overlaps ? "inside the strike window" : "outside the strike window")))
        } else {
            groups.append(ContactEvidenceGroup(name: "trunkLateralLean", signals: ["lateralTrunkLean"], observed: false,
                                               earliestTime: nil, latestTime: nil, agrees: nil,
                                               note: "No clear sideways trunk-lean peak around the kick."))
        }
        // The estimate is the middle of the strike window (the earlier frame when the
        // middle falls between two frames). Only when the window is within the contact
        // tolerance (±0.05 s, `ContactTimingCheck.toleranceSeconds`) is it a contact
        // ESTIMATE; a wider window is reported as "strike window, contact timing uncertain".
        let inside = times.indices.filter { $0 >= earliest && $0 <= latest }
        let chosen = inside.isEmpty ? earliest : inside[(inside.count - 1) / 2]
        let halfWidth = (times[latest] - times[earliest]) / 2
        let localized = halfWidth <= ContactTimingCheck.toleranceSeconds + 1e-9
        candidates.insert(record(times[chosen], chosen, selected: true, support: ["kickingLegDrive"],
                                 rejection: nil), at: 0)
        if let low = markers.first(where: { $0.kind == "footLowest" }), low.time > times[latest] + 1e-9,
           let i = times.firstIndex(where: { abs($0 - low.time) < 1e-9 }) {
            candidates.append(record(low.time, i, selected: false, support: [],
                                     rejection: "after the knee extension completed: post-contact swing, not first contact"))
        }
        return Result(decision: localized ? .established(index: chosen, earliest: earliest, latest: latest)
                                          : .strikeWindow(index: chosen, earliest: earliest, latest: latest),
                      groups: groups, candidates: candidates, strikeApproachStart: approachStart, postContactMarkers: markers,
                      confidence: localized ? oneGroupConfidence : strikeWindowConfidence)
    }
}
