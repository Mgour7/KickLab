import Foundation

/// Tunable thresholds for multi-person tracking and kicker selection.
struct PoseTrackingConfiguration: Codable, Equatable, Sendable {
    /// Bodies below this confidence are ignored for tracking.
    var minimumBodyConfidence: Double = 0.2
    /// A body continues a track if its center moved at most this far (aspect-corrected
    /// normalized units) since the track was last seen.
    var maximumCenterJump: Double = 0.12
    /// A track not seen for more than this many frames ends.
    var maximumMissingFrames: Int = 10
    /// Tracks present in fewer than this fraction of frames are not kicker candidates.
    var minimumCandidateCoverage: Double = 0.2
    /// The runner-up is "too close to call" when its score is at least this fraction of the best.
    var ambiguityRatio: Double = 0.8
    /// A manual seed matches a body whose box contains it, or whose center is this close.
    var seedMaximumDistance: Double = 0.1

    init() {}

    static let standard = PoseTrackingConfiguration()
}

/// The caller's identification of the kicker: a point on the kicker in one frame,
/// in app-normalized coordinates.
struct KickerSeed: Codable, Equatable, Sendable {
    var timestamp: Double
    var point: NormalizedPoint

    init(timestamp: Double, point: NormalizedPoint) {
        self.timestamp = timestamp
        self.point = point
    }
}

/// One person followed across frames.
struct PoseTrack: Equatable, Sendable {
    let trackID: Int
    /// Indices into the frames array where this track appears.
    let frameIndices: [Int]
}

struct KickerCandidate: Codable, Equatable, Sendable {
    let trackID: Int
    /// 0...1 relative score (best candidate = highest).
    let score: Double
    /// Fraction of analyzed frames containing this track.
    let coverage: Double
    /// Path length of the body center, in torso lengths.
    let motion: Double
    /// Peak ankle speed, in torso lengths per second.
    let peakAnkleSpeed: Double
}

enum KickerSelectionMethod: String, Codable, Sendable {
    case manualSeed
    case automatic
    case none
}

enum KickerSelectionStatus: String, Codable, Sendable {
    case selected
    /// Several people are plausible; nobody was chosen. Ask the user for a seed.
    case ambiguous
    /// No sufficiently visible person.
    case noCandidates
    /// The manual seed did not land on (or near) a detected person.
    case seedNotMatched
}

/// Who the kicker is, how sure KickLab is, and the alternatives when it can't tell.
struct KickerTrackingResult: Codable, Equatable, Sendable {
    let status: KickerSelectionStatus
    let method: KickerSelectionMethod
    /// Nil unless `status == .selected`. KickLab never silently picks when ambiguous.
    let selectedTrackID: Int?
    /// 0...1
    let confidence: Double
    /// Best first. All plausible candidates when ambiguous.
    let candidates: [KickerCandidate]

    var isAmbiguous: Bool { status == .ambiguous }

    var message: String {
        switch status {
        case .selected: "Kicker identified."
        case .ambiguous: "Multiple possible kickers found. Tap the kicker to choose."
        case .noCandidates: "No clearly visible person was found."
        case .seedNotMatched: "No person was found where you tapped."
        }
    }
}

/// Pure multi-person tracking and kicker selection. No identity recognition: people
/// are followed only by where their body is from frame to frame.
enum PoseTracker {
    /// Assigns stable track IDs to bodies across frames by greedy nearest-center matching.
    /// Returns the frames with `trackID`s set, and the tracks.
    static func assignTracks(
        _ frames: [PoseFrame],
        aspectRatio: Double? = nil,
        configuration: PoseTrackingConfiguration = .standard
    ) -> (frames: [PoseFrame], tracks: [PoseTrack]) {
        let aspect = aspectRatio ?? 1
        var result = frames
        var lastSeen: [Int: (center: NormalizedPoint, frame: Int)] = [:]
        var trackFrames: [Int: [Int]] = [:]
        var nextID = 1

        for f in result.indices {
            let active = lastSeen.filter { f - $0.value.frame <= configuration.maximumMissingFrames + 1 }
            var candidates: [(distance: Double, body: Int, track: Int)] = []
            for (b, body) in result[f].bodies.enumerated() where body.confidence >= configuration.minimumBodyConfidence {
                guard let center = body.center else { continue }
                for (track, seen) in active {
                    let d = distance(center, seen.center, aspect: aspect)
                    if d <= configuration.maximumCenterJump { candidates.append((d, b, track)) }
                }
            }
            candidates.sort { ($0.distance, $0.track, $0.body) < ($1.distance, $1.track, $1.body) }

            var usedBodies = Set<Int>()
            var usedTracks = Set<Int>()
            for candidate in candidates where !usedBodies.contains(candidate.body) && !usedTracks.contains(candidate.track) {
                usedBodies.insert(candidate.body)
                usedTracks.insert(candidate.track)
                result[f].bodies[candidate.body].trackID = candidate.track
            }
            for b in result[f].bodies.indices where !usedBodies.contains(b) {
                let body = result[f].bodies[b]
                guard body.confidence >= configuration.minimumBodyConfidence, body.center != nil else {
                    result[f].bodies[b].trackID = nil
                    continue
                }
                result[f].bodies[b].trackID = nextID
                nextID += 1
            }
            for body in result[f].bodies {
                guard let id = body.trackID, let center = body.center else { continue }
                lastSeen[id] = (center, f)
                trackFrames[id, default: []].append(f)
            }
        }

        let tracks = trackFrames.keys.sorted().map { PoseTrack(trackID: $0, frameIndices: trackFrames[$0] ?? []) }
        return (result, tracks)
    }

    /// Chooses the kicker. A manual seed always wins; otherwise tracks are scored on
    /// coverage, body motion and lower-body activity (plus closeness to `kickLocationHint`).
    /// When the runner-up is close to the best, the result is `.ambiguous` with no selection.
    static func selectKicker(
        frames: [PoseFrame],
        tracks: [PoseTrack],
        seed: KickerSeed? = nil,
        kickLocationHint: NormalizedPoint? = nil,
        aspectRatio: Double? = nil,
        configuration: PoseTrackingConfiguration = .standard
    ) -> KickerTrackingResult {
        let aspect = aspectRatio ?? 1

        if let seed {
            return selectFromSeed(seed, frames: frames, aspect: aspect, configuration: configuration)
        }

        let frameCount = max(frames.count, 1)
        var raw: [(track: Int, coverage: Double, motion: Double, ankle: Double, proximity: Double)] = []
        for track in tracks {
            let coverage = Double(track.frameIndices.count) / Double(frameCount)
            guard coverage >= configuration.minimumCandidateCoverage else { continue }
            let bodies = track.frameIndices.compactMap { index in frames[index].body(trackID: track.trackID).map { (frames[index].timestamp, $0) } }
            let scale = bodyScale(bodies.map(\.1), aspect: aspect) ?? 0.15
            let centers = bodies.compactMap { pair in pair.1.center.map { (pair.0, $0) } }
            var path = 0.0
            for i in centers.indices.dropFirst() {
                path += distance(centers[i].1, centers[i - 1].1, aspect: aspect)
            }
            let ankle = peakAnkleSpeed(bodies, aspect: aspect) / scale
            var proximity = 0.0
            if let hint = kickLocationHint, !centers.isEmpty {
                let nearest = centers.map { distance($0.1, hint, aspect: aspect) }.min() ?? 1
                proximity = max(0, 1 - nearest)
            }
            raw.append((track.trackID, coverage, path / scale, ankle, proximity))
        }

        guard !raw.isEmpty else {
            return KickerTrackingResult(status: .noCandidates, method: .none, selectedTrackID: nil, confidence: 0, candidates: [])
        }

        let maxMotion = max(raw.map(\.motion).max() ?? 0, 1e-9)
        let maxAnkle = max(raw.map(\.ankle).max() ?? 0, 1e-9)
        let useHint = kickLocationHint != nil
        let candidates = raw.map { r -> KickerCandidate in
            var score = 0.25 * r.coverage + 0.40 * (r.motion / maxMotion) + 0.35 * (r.ankle / maxAnkle)
            if useHint { score = 0.8 * score + 0.2 * r.proximity }
            return KickerCandidate(trackID: r.track, score: score, coverage: r.coverage, motion: r.motion, peakAnkleSpeed: r.ankle)
        }
        .sorted { ($0.score, -$0.trackID) > ($1.score, -$1.trackID) }

        let best = candidates[0]
        if candidates.count > 1 {
            let runnerUp = candidates[1]
            if runnerUp.score >= configuration.ambiguityRatio * best.score {
                let plausible = candidates.filter { $0.score >= configuration.ambiguityRatio * best.score }
                return KickerTrackingResult(status: .ambiguous, method: .automatic, selectedTrackID: nil,
                                            confidence: 0, candidates: plausible)
            }
            let margin = (best.score - runnerUp.score) / max(best.score, 1e-9)
            return KickerTrackingResult(status: .selected, method: .automatic, selectedTrackID: best.trackID,
                                        confidence: min(1, margin * best.coverage + 0.3 * best.coverage), candidates: candidates)
        }
        return KickerTrackingResult(status: .selected, method: .automatic, selectedTrackID: best.trackID,
                                    confidence: min(0.9, best.coverage), candidates: candidates)
    }

    // MARK: Helpers

    private static func selectFromSeed(
        _ seed: KickerSeed,
        frames: [PoseFrame],
        aspect: Double,
        configuration: PoseTrackingConfiguration
    ) -> KickerTrackingResult {
        guard let frame = frames.min(by: { abs($0.timestamp - seed.timestamp) < abs($1.timestamp - seed.timestamp) }) else {
            return KickerTrackingResult(status: .seedNotMatched, method: .manualSeed, selectedTrackID: nil, confidence: 0, candidates: [])
        }
        let tracked = frame.bodies.filter { $0.trackID != nil }
        if let inside = tracked.first(where: { $0.boundingBox?.contains(seed.point) ?? false }), let id = inside.trackID {
            return KickerTrackingResult(status: .selected, method: .manualSeed, selectedTrackID: id, confidence: 1, candidates: [])
        }
        let nearest = tracked
            .compactMap { body in body.center.map { (body, distance($0, seed.point, aspect: aspect)) } }
            .min { $0.1 < $1.1 }
        if let (body, d) = nearest, d <= configuration.seedMaximumDistance, let id = body.trackID {
            return KickerTrackingResult(status: .selected, method: .manualSeed, selectedTrackID: id, confidence: 0.9, candidates: [])
        }
        return KickerTrackingResult(status: .seedNotMatched, method: .manualSeed, selectedTrackID: nil, confidence: 0, candidates: [])
    }

    static func distance(_ a: NormalizedPoint, _ b: NormalizedPoint, aspect: Double) -> Double {
        let dx = (a.x - b.x) * aspect
        let dy = a.y - b.y
        return (dx * dx + dy * dy).squareRoot()
    }

    /// Median shoulder-midpoint-to-hip-midpoint distance (torso length), aspect-corrected.
    static func bodyScale(_ bodies: [BodyPose], aspect: Double) -> Double? {
        let lengths = bodies.compactMap { body -> Double? in
            guard
                let ls = body.point(.leftShoulder), let rs = body.point(.rightShoulder),
                let lh = body.point(.leftHip), let rh = body.point(.rightHip)
            else { return nil }
            let shoulder = NormalizedPoint(x: (ls.x + rs.x) / 2, y: (ls.y + rs.y) / 2)
            let hip = NormalizedPoint(x: (lh.x + rh.x) / 2, y: (lh.y + rh.y) / 2)
            let d = distance(shoulder, hip, aspect: aspect)
            return d > 0 ? d : nil
        }.sorted()
        guard !lengths.isEmpty else { return nil }
        return lengths[lengths.count / 2]
    }

    private static func peakAnkleSpeed(_ bodies: [(Double, BodyPose)], aspect: Double) -> Double {
        var peak = 0.0
        for i in bodies.indices.dropFirst() {
            let dt = bodies[i].0 - bodies[i - 1].0
            guard dt > 0 else { continue }
            for joint in [PoseJoint.leftAnkle, .rightAnkle] {
                guard let a = bodies[i].1.point(joint), let b = bodies[i - 1].1.point(joint) else { continue }
                let speed = distance(NormalizedPoint(x: a.x, y: a.y), NormalizedPoint(x: b.x, y: b.y), aspect: aspect) / dt
                peak = max(peak, speed)
            }
        }
        return peak
    }
}
