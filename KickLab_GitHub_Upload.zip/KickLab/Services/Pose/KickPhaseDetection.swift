import Foundation

/// The phases of a kick, in order.
enum KickPhase: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    /// Standing still before the approach.
    case setup
    /// Steps toward the ball.
    case approach
    /// The plant foot lands and stays fixed through contact.
    case plant
    /// Foot meets ball. Without ball tracking this is an ESTIMATE (peak kicking-foot speed).
    case contact
    /// The kicking leg continues after contact.
    case followThrough
}

enum PhaseDetectionStatus: String, Codable, Sendable {
    /// Found with clear evidence.
    case detected
    /// Found, but from indirect evidence or with weak support (e.g. contact without a ball).
    case estimated
    /// More than one plausible answer; the reported times are the best guess only.
    case ambiguous
    /// Not found (missing data, outside the clip, or unsupported for this kick type).
    case unavailable
}

/// One phase on the timeline. Times are seconds from the start of the analyzed video.
struct DetectedKickPhase: Codable, Equatable, Sendable {
    let phase: KickPhase
    let startTime: Double?
    let endTime: Double?
    /// The single instant that best represents the phase (e.g. plant touchdown, contact).
    let representativeTime: Double?
    /// 0...1
    let confidence: Double
    /// The signals the decision was based on.
    let evidence: [PoseSignalKey]
    let status: PhaseDetectionStatus

    static func unavailable(_ phase: KickPhase, evidence: [PoseSignalKey] = []) -> DetectedKickPhase {
        DetectedKickPhase(phase: phase, startTime: nil, endTime: nil, representativeTime: nil,
                          confidence: 0, evidence: evidence, status: .unavailable)
    }

    var isAvailable: Bool { status != .unavailable }
}

/// How well this version of KickLab understands a kick type's phases.
enum KickPhaseSupport: String, Codable, Sendable {
    case full
    /// Only some phases are detected (punts: contact and follow-through).
    case limited
    case unsupported
}

struct KickPhaseDetectionResult: Codable, Equatable, Sendable {
    let kickType: KickType
    let support: KickPhaseSupport
    /// One entry per `KickPhase`, in order.
    let phases: [DetectedKickPhase]
    /// 0...1
    let overallConfidence: Double
    /// Fraction of samples with the kicking-ankle signal.
    let dataCoverage: Double
    /// Plain-language notes for diagnostics (not coaching).
    let notes: [String]
    /// Step 12B: the evidence behind contact, plant and follow-through (nil in files
    /// written before Step 12B).
    var evidence: PhaseDetectionEvidence? = nil

    func phase(_ phase: KickPhase) -> DetectedKickPhase {
        phases.first { $0.phase == phase } ?? .unavailable(phase)
    }

    /// Plant-foot touchdown, when found.
    var plantTime: Double? {
        let plant = phase(.plant)
        return plant.isAvailable ? plant.representativeTime : nil
    }

    /// Estimated foot–ball contact, when found. Never "measured" without ball tracking.
    var estimatedContactTime: Double? {
        let contact = phase(.contact)
        return contact.isAvailable ? contact.representativeTime : nil
    }

    static func unavailable(kickType: KickType, support: KickPhaseSupport, coverage: Double, notes: [String]) -> KickPhaseDetectionResult {
        KickPhaseDetectionResult(kickType: kickType, support: support,
                                 phases: KickPhase.allCases.map { .unavailable($0) },
                                 overallConfidence: 0, dataCoverage: coverage, notes: notes)
    }
}

/// Step 12B: what the detector measured around contact. Times in seconds, speeds in
/// body lengths per second. For diagnostics and validation only; nothing here is a score.
struct PhaseDetectionEvidence: Codable, Equatable, Sendable {
    /// The contact anchor: the sample with the highest kicking-ankle speed.
    var contactPeakTime: Double?
    var contactPeakSpeed: Double?
    /// Sub-frame peak time from a parabola through the three samples around the peak.
    var refinedContactTime: Double?
    /// When the kicking ankle passed the plant ankle along the direction of travel
    /// (independent of foot speed). Nil when not seen or the direction is unknown.
    var anklePassTime: Double?
    /// refinedContactTime − anklePassTime.
    var contactCueOffset: Double?
    /// Plant-ankle speed while the athlete was standing still: the measurement noise.
    var plantNoiseFloor: Double?
    /// The plant-still threshold actually used.
    var plantStillThreshold: Double?
    /// Slowest filtered plant-ankle speed in the plant search window.
    var slowestPlantSpeedBeforeContact: Double?
    /// Filtered plant-ankle speed at the contact anchor.
    var plantSpeedAtContact: Double?
    var plantTouchdownTime: Double?
    /// True when the plant foot stayed still through contact; false when it landed but
    /// was moving again by contact; nil when no touchdown was found.
    var plantStillThroughContact: Bool?
    /// Seconds from contact until the kicking ankle slowed to the follow-through end
    /// fraction (nil when it never did before the clip ended).
    var followThroughSeconds: Double?

    // Step 12C (all optional so Step 12B files still decode)

    /// The contact/phase rules that produced this result.
    var algorithmVersion: String? = nil
    /// Every contact candidate considered, with its evidence and why it was or wasn't chosen.
    var contactCandidates: [ContactCandidate]? = nil
    /// ± seconds around the estimated contact.
    var contactUncertaintySeconds: Double? = nil
    /// Conflicts between independent cues, in plain language.
    var contactConflicts: [String]? = nil
    /// Which of the four plant outcomes applies.
    var plantState: PlantState? = nil
    var plantCandidates: [PhaseEndpointCandidate]? = nil
    /// Plant ankle relative to the plant hip at touchdown, body lengths along travel.
    var plantFootAheadOfHip: Double? = nil
    var followThroughCandidates: [PhaseEndpointCandidate]? = nil
    /// The leg labeled as the plant leg made the fastest swing near contact while the
    /// kicking leg was at rest: the profile's kicking foot or the pose labels may be wrong.
    var legRoleConflict: Bool? = nil
}

/// Step 12C: the four plant outcomes.
enum PlantState: String, Codable, Sendable {
    /// Plant foot came to rest and stayed still through contact.
    case touchdownDetected
    /// Plant found from weaker evidence (clipped, interrupted, or a foot behind the hip).
    case estimated
    /// Plant foot landed but was moving again by contact (a biomechanical finding).
    case unstableAfterTouchdown
    /// No plant evidence: none is reported.
    case notDetected
}

/// Step 12C: a candidate time for a phase boundary (plant touchdown, follow-through end)
/// and whether it was used.
struct PhaseEndpointCandidate: Codable, Equatable, Sendable {
    var kind: String
    var time: Double
    var accepted: Bool
    var reason: String
}

/// Thresholds per kick type. Speeds are in body lengths per second; times in seconds.
struct KickPhaseProfile: Codable, Equatable, Sendable {
    var support: KickPhaseSupport
    /// Shortest approach that counts as `.detected` (shorter → `.estimated`).
    var minimumApproachSeconds: Double
    /// Body-center speed that counts as moving.
    var approachSpeedThreshold: Double
    /// Plant-ankle speed that counts as planted (still).
    var plantStillSpeedThreshold: Double
    /// Plant touchdown is searched for within this long before contact.
    var plantMaximumLeadSeconds: Double
    /// The kicking-ankle peak must reach this speed to count as a kick.
    var contactMinimumPeakSpeed: Double
    /// A second peak at least this fraction of the highest makes contact ambiguous…
    var contactAmbiguityRatio: Double
    /// …when it is at least this far away in time.
    var contactPeakSeparationSeconds: Double
    /// Follow-through ends when kicking-ankle speed falls to this fraction of the peak.
    var followThroughEndFraction: Double
    var minimumFollowThroughSeconds: Double
    /// Stillness before the approach must last this long to report a setup phase.
    var minimumSetupSeconds: Double
    /// Below this kicking-ankle coverage nothing is detected.
    var minimumCoverage: Double

    static let placeKick = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Kickoffs: longer, faster approach.
    static let kickoff = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 1.0, approachSpeedThreshold: 1.0,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.35, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Punts: drop and swing differ from place kicks; only contact and follow-through.
    static let punt = KickPhaseProfile(
        support: .limited, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    static func `for`(_ kickType: KickType) -> KickPhaseProfile {
        switch kickType {
        case .fieldGoal, .pat: .placeKick
        case .kickoff: .kickoff
        case .punt: .punt
        case .unknown: KickPhaseProfile(
            support: .unsupported, minimumApproachSeconds: 0, approachSpeedThreshold: 0,
            plantStillSpeedThreshold: 0, plantMaximumLeadSeconds: 0, contactMinimumPeakSpeed: 0,
            contactAmbiguityRatio: 1, contactPeakSeparationSeconds: 0, followThroughEndFraction: 0,
            minimumFollowThroughSeconds: 0, minimumSetupSeconds: 0, minimumCoverage: 1
        )
        }
    }
}

/// Pure, rule-based phase detection from pose signals. Separate from signal extraction
/// so it can be tested on synthetic timelines and later replaced by a learned model.
///
/// Anchor: contact is estimated at the peak kicking-ankle speed. Plant, approach and
/// setup are found by walking BACK from contact; follow-through by walking forward.
enum KickPhaseDetector {
    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile? = nil
    ) -> KickPhaseDetectionResult {
        let profile = profile ?? .for(kickType)
        let times = signals.timestamps
        let ankle = signals.values(.kickingAnkleSpeed)
        let coverage = signals.coverage(.kickingAnkleSpeed)

        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases."])
        }

        // MARK: Contact (anchor)
        // Step 12C: contact is chosen among candidates by independent evidence (see
        // `ContactEstimator`), not as the single highest kicking-ankle speed.
        let contactEstimate = ContactEstimator.estimate(signals, profile: profile)
        guard let chosen = contactEstimate.selected, let peakIndex = times.firstIndex(where: { abs($0 - chosen.time) < 1e-9 }) else {
            var result = KickPhaseDetectionResult.unavailable(
                kickType: kickType, support: profile.support, coverage: coverage,
                notes: [contactEstimate.unavailableReason ?? "No kicking motion was found."]
            )
            result.evidence = PhaseDetectionEvidence(
                plantNoiseFloor: contactEstimate.plantNoiseFloor, plantStillThreshold: contactEstimate.plantStillThreshold,
                algorithmVersion: ContactEstimator.algorithmVersion,
                contactCandidates: contactEstimate.candidates.isEmpty ? nil : contactEstimate.candidates
            )
            return result
        }
        let peak = chosen.peakSpeed
        let contactTime = times[peakIndex]
        var evidence = PhaseDetectionEvidence(contactPeakTime: contactTime, contactPeakSpeed: peak)
        evidence.algorithmVersion = ContactEstimator.algorithmVersion
        evidence.refinedContactTime = chosen.refinedTime
        evidence.contactCandidates = contactEstimate.candidates
        evidence.contactUncertaintySeconds = contactEstimate.uncertaintySeconds
        let isAmbiguous = contactEstimate.isAmbiguous
        let localCoverage = windowCoverage(ankle, times, around: contactTime, radius: 0.1)
        var notes: [String] = ["Contact is estimated from kicking-foot motion with supporting cues (no ball tracking)."]
        if isAmbiguous { notes.append("More than one kicking motion was found; phase times are uncertain.") }
        var conflicts = contactEstimate.conflicts

        if signals.travelDirection != 0,
           let pass = anklePassTime(signals.values(.kickingAnkleAheadOfPlant), times, near: contactTime) {
            evidence.anklePassTime = pass
            evidence.contactCueOffset = chosen.refinedTime - pass
        }

        // Leg roles: the "plant" leg swinging fastest while the "kicking" leg rests.
        let roleConflict = profile.support == .full && legRoleConflict(signals, times, contactTime: contactTime, kickingPeak: peak,
                                                                          threshold: contactEstimate.plantStillThreshold)
        evidence.legRoleConflict = roleConflict
        var roleFactor = 1.0
        if roleConflict {
            roleFactor = 0.5
            conflicts.append("Near contact the leg labeled as the plant leg swung fastest while the kicking leg was at rest. Check the kicking foot in the athlete's profile, or the pose labels may be reversed.")
        }
        evidence.contactConflicts = conflicts
        notes.append(contentsOf: conflicts)

        // Anything derived from an ambiguous anchor is ambiguous too.
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus {
            isAmbiguous ? .ambiguous : base
        }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }

        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: min(1, max(0, contactEstimate.confidence * localCoverage * roleFactor)),
            evidence: [.kickingAnkleSpeed, .kickingAnkleForwardVelocity, .plantAnkleSpeed, .bodyForwardVelocity, .kickingAnkleAheadOfPlant],
            status: status(.estimated)
        )

        // MARK: Follow-through
        // Endpoint candidates: (a) kicking-foot speed down to the end fraction of the
        // peak and staying there for a second sample; (b) the swing apex — the foot's
        // furthest point ahead of the hip after contact; (c) the end of the clip. The later
        // of (a) and (b) is used, so a quick speed dip doesn't cut the swing short. It never
        // depends on the plant.
        var followCandidates: [PhaseEndpointCandidate] = []
        var slowdownIndex: Int?
        let endSpeed = profile.followThroughEndFraction * peak
        for i in (peakIndex + 1)..<max(peakIndex + 1, times.count) {
            guard let v = ankle[i], v <= endSpeed else { continue }
            let confirmed = i + 1 >= times.count || (ankle[i + 1].map { $0 <= endSpeed } ?? false)
            if confirmed { slowdownIndex = i; break }
        }
        let apexIndex = swingApex(signals.values(.kickingAnkleForwardOffset), times, after: peakIndex)
        var followEndIndex: Int?
        let minimumEnd = contactTime + profile.minimumFollowThroughSeconds - 1e-9
        let usable = [slowdownIndex, apexIndex].compactMap { $0 }.filter { times[$0] >= minimumEnd }
        followEndIndex = usable.max()
        // An endpoint was seen but too soon: the follow-through is not long enough to measure.
        let endedTooSoon = followEndIndex == nil && (slowdownIndex != nil || apexIndex != nil)
        if let i = slowdownIndex {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "slowdown", time: times[i], accepted: i == followEndIndex,
                reason: times[i] < minimumEnd ? "too soon after contact" : (i == followEndIndex ? "used" : "the swing continued after the slow-down")
            ))
        }
        if let i = apexIndex {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "swingApex", time: times[i], accepted: i == followEndIndex,
                reason: times[i] < minimumEnd ? "too soon after contact" : (i == followEndIndex ? "used" : "the foot was still moving fast after the apex")
            ))
        }
        let followThrough: DetectedKickPhase
        let tooSoonEnd = [slowdownIndex, apexIndex].compactMap { $0 }.max()
        let followEnd = times[followEndIndex ?? (endedTooSoon ? (tooSoonEnd ?? peakIndex) : times.count - 1)]
        evidence.followThroughSeconds = slowdownIndex.map { times[$0] - contactTime }
        if followEndIndex == nil && !endedTooSoon {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "clipEnd", time: times[times.count - 1], accepted: followEnd - contactTime >= profile.minimumFollowThroughSeconds,
                reason: followEnd - contactTime >= profile.minimumFollowThroughSeconds ? "clip ends during the follow-through" : "clip ends too soon after contact"
            ))
        }
        evidence.followThroughCandidates = followCandidates
        if followEnd - contactTime >= profile.minimumFollowThroughSeconds {
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: followEnd, representativeTime: contactTime,
                confidence: scaled(followEndIndex == nil ? 0.4 : 0.8 * localCoverage * roleFactor),
                evidence: [.kickingAnkleSpeed, .kickingAnkleForwardOffset],
                status: status(followEndIndex == nil ? .estimated : .detected)
            )
            if followEndIndex == nil { notes.append("The clip ends during the follow-through.") }
        } else {
            followThrough = .unavailable(.followThrough, evidence: [.kickingAnkleSpeed])
            if slowdownIndex == nil && apexIndex == nil {
                notes.append("The clip ends right after the estimated contact, so there is no follow-through to measure.")
            } else {
                notes.append(String(format: "The kicking foot slowed to %d%% of its peak speed only %.2f s after the estimated contact — too soon for a follow-through, so the estimate may not be the strike.",
                                    Int((profile.followThroughEndFraction * 100).rounded()), (slowdownIndex.map { times[$0] } ?? followEnd) - contactTime))
            }
        }

        guard profile.support == .full else {
            notes.append("Only contact and follow-through are detected for this kick type.")
            let phases = [DetectedKickPhase.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough]
            return finish(kickType, profile, phases, coverage, notes, evidence)
        }

        // MARK: Plant
        // The plant is the plant foot COMING TO REST before contact (median-filtered speed,
        // adaptive still threshold), checked against leg configuration (a planted foot is
        // not far behind the hip). Whether it STAYED still through contact is reported
        // separately: an unstable plant is a biomechanical finding, not a missing plant.
        // Four outcomes: touchdown detected, estimated, unstable after touchdown, not detected.
        let plantSpeed = medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let noiseFloor = contactEstimate.plantNoiseFloor
        let stillThreshold = contactEstimate.plantStillThreshold
        if let noiseFloor, stillThreshold > profile.plantStillSpeedThreshold {
            notes.append(String(format: "Pose jitter while standing still (%.2f body lengths/s) raised the plant-still threshold to %.2f.", noiseFloor, stillThreshold))
        }
        evidence.plantNoiseFloor = noiseFloor
        evidence.plantStillThreshold = stillThreshold
        evidence.plantSpeedAtContact = plantSpeed[peakIndex]
        let window = times.indices.filter { $0 <= peakIndex && contactTime - times[$0] <= profile.plantMaximumLeadSeconds + 1e-9 }
        evidence.slowestPlantSpeedBeforeContact = window.compactMap { plantSpeed[$0] }.min()
        let isStill = { (i: Int) -> Bool in plantSpeed[i].map { $0 <= stillThreshold } ?? false }
        let minimumRun = max(2, Int((minimumStillSeconds * framesPerSecond(times)).rounded(.up)))
        let footAhead = signals.values(.plantAnkleForwardOffset)

        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantIndex: Int?
        var plantCandidates: [PhaseEndpointCandidate] = []
        // Still runs in the window; the one ending closest to contact is used.
        var runs: [ClosedRange<Int>] = []
        var runStart: Int?
        for i in window {
            if isStill(i) {
                if runStart == nil { runStart = i }
            } else if let start = runStart {
                runs.append(start...(i - 1))
                runStart = nil
            }
        }
        if let start = runStart, let last = window.last { runs.append(start...last) }
        let longRuns = runs.filter { $0.count >= minimumRun }
        for run in runs where run.count < minimumRun {
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[run.lowerBound], accepted: false,
                                                          reason: String(format: "still for only %d sample(s)", run.count)))
        }
        let best = longRuns.last
        for run in longRuns where run != best {
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[run.lowerBound], accepted: false,
                                                          reason: "an earlier rest; a later one is closer to contact"))
        }
        // A foot coming to rest AFTER the estimate means the estimate may be early.
        let afterContact = times.indices.filter { $0 > peakIndex && times[$0] - contactTime <= 0.3 + 1e-9 }
        var lateRun = 0
        for i in afterContact {
            lateRun = isStill(i) ? lateRun + 1 : 0
            if lateRun == minimumRun, best == nil {
                plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[i - minimumRun + 1], accepted: false,
                                                              reason: "after the estimated contact — the contact estimate may be early"))
                break
            }
        }
        if let run = best {
            let start = run.lowerBound
            // Still before the window began: touchdown is earlier than we looked.
            let clipped = start == window.first && start > 0 && isStill(start - 1)
            let interrupted = start > 0 && plantSpeed[start - 1] == nil
            let throughContact = times[run.upperBound] >= contactTime - plantContactToleranceSeconds - 1e-9
            let ahead = footAhead[start]
            let behindHip = (ahead ?? 0) < plantBehindHipLimit
            plantIndex = start
            evidence.plantTouchdownTime = times[start]
            evidence.plantStillThroughContact = throughContact
            evidence.plantFootAheadOfHip = ahead.map { (($0 * 1000).rounded()) / 1000 }
            let base: PhaseDetectionStatus = (clipped || interrupted || !throughContact || behindHip) ? .estimated : .detected
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[start], radius: 0.1)
            let strength = base == .detected ? 0.85 : (throughContact ? 0.5 : 0.4)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[start], endTime: contactTime, representativeTime: times[start],
                confidence: scaled(strength * plantCoverage * roleFactor),
                evidence: [.plantAnkleSpeed, .plantAnkleForwardOffset, .kickingAnkleSpeed], status: status(base)
            )
            var reason = "used"
            if clipped { reason += "; already still when the search began (touchdown may be earlier)" }
            if interrupted { reason += "; plant ankle missing just before" }
            if behindHip { reason += "; foot behind the hip, more like push-off than a plant" }
            if !throughContact { reason += "; moving again before contact" }
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[start], accepted: true, reason: reason))
            evidence.plantState = !throughContact ? .unstableAfterTouchdown : (base == .detected ? .touchdownDetected : .estimated)
            if !throughContact {
                let moving = ((run.upperBound + 1)...max(run.upperBound + 1, peakIndex)).compactMap { plantSpeed.indices.contains($0) ? plantSpeed[$0] : nil }.max()
                notes.append(String(format: "The plant foot came to rest at %.2f s but was moving again by the estimated contact (up to %.2f body lengths/s): an unstable plant, or the contact estimate is off.",
                                    times[start], moving ?? .nan))
            }
            if behindHip { notes.append("At touchdown the plant foot was behind the hip, so the plant time is only an estimate.") }
        } else if let brief = briefPlant(signals.values(.plantAnkleSpeed), times, window: window, peakIndex: peakIndex,
                                         stillThreshold: stillThreshold) {
            // A sharp stop that lasted a single sample at this frame rate, then motion
            // again before contact: the touchdown is identifiable, the plant unstable.
            plantIndex = brief
            evidence.plantTouchdownTime = times[brief]
            evidence.plantStillThroughContact = false
            evidence.plantFootAheadOfHip = footAhead[brief].map { (($0 * 1000).rounded()) / 1000 }
            evidence.plantState = .unstableAfterTouchdown
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[brief], radius: 0.1)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[brief], endTime: contactTime, representativeTime: times[brief],
                confidence: scaled(0.3 * plantCoverage * roleFactor),
                evidence: [.plantAnkleSpeed, .kickingAnkleSpeed], status: status(.estimated)
            )
            plantCandidates.append(PhaseEndpointCandidate(kind: "briefStop", time: times[brief], accepted: true,
                                                          reason: "a one-sample stop after a sharp slow-down"))
            notes.append(String(format: "The plant foot stopped sharply at %.2f s but only for one frame, and was moving again by the estimated contact: an unstable plant (a higher frame rate would show it better).",
                                times[brief]))
        } else {
            evidence.plantState = .notDetected
            let slowest = evidence.slowestPlantSpeedBeforeContact
            notes.append(slowest.map {
                String(format: "The plant foot never came to rest in the %.1f s before the estimated contact (slowest %.2f body lengths/s; still means ≤ %.2f).",
                       profile.plantMaximumLeadSeconds, $0, stillThreshold)
            } ?? "The plant ankle wasn't visible before the estimated contact.")
        }
        evidence.plantCandidates = plantCandidates

        // MARK: Approach
        let bodySpeed = signals.values(.bodyCenterSpeed)
        var approach = DetectedKickPhase.unavailable(.approach, evidence: [.bodyCenterSpeed])
        var approachStartIndex: Int?
        let approachEndIndex = plantIndex ?? peakIndex
        // The last moving sample at or shortly before plant (bodies slow as they plant).
        let moving = { (i: Int) -> Bool in (bodySpeed[i] ?? 0) >= profile.approachSpeedThreshold }
        if let last = stride(from: approachEndIndex, through: 0, by: -1)
            .first(where: { times[approachEndIndex] - times[$0] <= 0.3 && moving($0) }) {
            var start = last
            while start > 0, moving(start - 1) { start -= 1 }
            approachStartIndex = start
            let duration = times[approachEndIndex] - times[start]
            let longEnough = duration >= profile.minimumApproachSeconds
            if !longEnough { notes.append("The approach was shorter than expected for this kick type.") }
            let reachesStart = start == 0
            if reachesStart { notes.append("The clip starts during the approach.") }
            let base: PhaseDetectionStatus = (longEnough && !reachesStart && plantIndex != nil) ? .detected : .estimated
            approach = DetectedKickPhase(
                phase: .approach, startTime: times[start], endTime: times[approachEndIndex],
                representativeTime: times[start],
                confidence: scaled(base == .detected ? 0.8 : 0.4),
                evidence: [.bodyCenterSpeed, .bodyForwardVelocity], status: status(base)
            )
        }

        // MARK: Setup
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.bodyCenterSpeed])
        if let approachStart = approachStartIndex, approachStart > 0,
           times[approachStart] - times[0] >= profile.minimumSetupSeconds {
            let window = 0..<approachStart
            let known = window.filter { bodySpeed[$0] != nil }
            let still = known.filter { !moving($0) }
            let fraction = known.isEmpty ? 0 : Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(
                    phase: .setup, startTime: times[0], endTime: times[approachStart], representativeTime: times[0],
                    confidence: scaled(0.7 * fraction), evidence: [.bodyCenterSpeed],
                    status: status(fraction >= 0.8 ? .detected : .estimated)
                )
            }
        }

        return finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes, evidence)
    }

    private static func finish(
        _ kickType: KickType,
        _ profile: KickPhaseProfile,
        _ phases: [DetectedKickPhase],
        _ coverage: Double,
        _ notes: [String],
        _ evidence: PhaseDetectionEvidence
    ) -> KickPhaseDetectionResult {
        let found = phases.filter(\.isAvailable)
        let mean = found.isEmpty ? 0 : found.map(\.confidence).reduce(0, +) / Double(found.count)
        return KickPhaseDetectionResult(kickType: kickType, support: profile.support, phases: phases,
                                        overallConfidence: min(1, mean * coverage), dataCoverage: coverage, notes: notes,
                                        evidence: evidence)
    }

    // MARK: Step 12C helpers

    /// Body lengths. A "plant" whose foot is further than this behind the hip at touchdown
    /// looks like push-off, so it is only an estimate.
    static let plantBehindHipLimit = -0.5

    /// The foot's furthest point ahead of the hip within 0.8 s after contact, when the foot
    /// travelled at least 0.3 body lengths further forward first (a real swing, not noise).
    static func swingApex(_ offset: [Double?], _ times: [Double], after i: Int) -> Int? {
        guard let start = offset[i] else { return nil }
        let window = times.indices.filter { $0 > i && times[$0] - times[i] <= 0.8 + 1e-9 }
        guard let highest = window.compactMap({ offset[$0] }).max(), highest - start >= 0.3 else { return nil }
        // The first sample within 0.05 body lengths of the highest point: robust to pose
        // jitter and rounding on a plateau (mirrored clips give identical results).
        guard let apex = window.first(where: { (offset[$0] ?? -.infinity) >= highest - 0.05 }) else { return nil }
        // Still rising at the window's end: not a turning point.
        guard apex != window.last else { return nil }
        return apex
    }

    /// The plant-labeled ankle moving much faster than the kicking ankle's peak around
    /// contact while the kicking ankle rests.
    static func legRoleConflict(_ signals: PoseSignalSet, _ times: [Double], contactTime: Double, kickingPeak: Double,
                                threshold: Double) -> Bool {
        let near = times.indices.filter { abs(times[$0] - contactTime) <= 0.3 + 1e-9 }
        let plant = signals.values(.plantAnkleSpeed)
        let kicking = medianFilter(signals.values(.kickingAnkleSpeed), radius: 2)
        guard let plantPeak = near.compactMap({ plant[$0] }).max() else { return false }
        let restingBefore = times.indices.filter { times[$0] >= contactTime - 0.15 - 1e-9 && times[$0] <= contactTime + 1e-9 }
            .compactMap { kicking[$0] }
        let kickingRests = !restingBefore.isEmpty && restingBefore.allSatisfy { $0 <= threshold }
        return plantPeak > 1.2 * kickingPeak && kickingRests
    }

    // MARK: Step 12B constants and helpers

    /// The still threshold may rise to this multiple of the standing-still noise floor…
    static let noiseFloorMultiplier = 3.0
    /// …but never above this (body lengths/s). A stepping foot moves several times faster.
    static let plantStillSpeedCeiling = 1.5
    /// A plant must stay still at least this long (and at least two samples).
    static let minimumStillSeconds = 0.05
    /// "Still through contact" allows the foot to start moving this long before the anchor.
    static let plantContactToleranceSeconds = 0.05
    /// Speed peak and ankle-pass cue further apart than this lower contact confidence.
    static let contactCueToleranceSeconds = 0.2
    /// A one-sample stop counts as a (brief) touchdown only when the foot slowed to this
    /// fraction of its speed in the half second before the search window.
    static let briefPlantSpeedRatio = 0.35

    /// The single slowest unfiltered plant-ankle sample in the window, when it is a clear
    /// stop: at or below the still threshold, a local minimum strictly inside the window,
    /// and far slower than the foot moved just before (so jitter on a moving foot doesn't
    /// qualify).
    static func briefPlant(_ plant: [Double?], _ times: [Double], window: [Int], peakIndex: Int, stillThreshold: Double) -> Int? {
        guard let first = window.first,
              let j = window.filter({ plant[$0] != nil }).min(by: { plant[$0]! < plant[$1]! }),
              let m = plant[j], m <= stillThreshold, j > first, j < peakIndex,
              let before = plant[j - 1], let after = plant[j + 1], m < before, m < after else { return nil }
        let earlier = times.indices.filter { times[$0] < times[first] && times[first] - times[$0] <= 0.5 + 1e-9 }
            .compactMap { plant[$0] }.sorted()
        guard earlier.count >= 3 else { return nil }
        let moving = earlier[earlier.count / 2]
        return m <= briefPlantSpeedRatio * moving ? j : nil
    }

    /// Noise floor needs this many standing-still samples.
    static let minimumNoiseSamples = 8

    /// Running median over each sample and its available neighbors within `radius`
    /// samples. Removes bursts of up to `radius` samples (one jittery position disturbs
    /// two central-difference speeds) while keeping steps — a foot stopping — and
    /// monotone stretches where they are. Missing samples stay missing.
    static func medianFilter(_ values: [Double?], radius: Int) -> [Double?] {
        values.indices.map { i in
            guard values[i] != nil else { return nil }
            // Symmetric window, narrowed at the ends so it stays centered.
            let r = min(radius, i, values.count - 1 - i)
            let window = (i - r...i + r).compactMap { values[$0] }.sorted()
            guard window.count >= 3 else { return values[i] }
            let mid = window.count / 2
            return window.count % 2 == 1 ? window[mid] : (window[mid - 1] + window[mid]) / 2
        }
    }

    /// Median sample rate (samples per second); 30 when unknown.
    static func framesPerSecond(_ times: [Double]) -> Double {
        var gaps: [Double] = []
        for i in times.indices.dropFirst() where times[i] > times[i - 1] { gaps.append(times[i] - times[i - 1]) }
        gaps.sort()
        return gaps.isEmpty ? 30 : 1 / gaps[gaps.count / 2]
    }

    /// Typical plant-ankle speed while the body is NOT moving (setup, after the kick): the
    /// measurement jitter of a foot that is really still.
    static func plantNoiseFloor(_ plant: [Double?], _ body: [Double?], profile: KickPhaseProfile) -> Double? {
        let quiet = plant.indices.compactMap { i -> Double? in
            guard i < body.count, let b = body[i], b < profile.approachSpeedThreshold else { return nil }
            return plant[i]
        }.sorted()
        return quiet.count >= minimumNoiseSamples ? quiet[quiet.count / 2] : nil
    }

    /// Sub-sample time of the peak from a parabola through its neighbors.
    static func refinedPeakTime(_ values: [Double?], _ times: [Double], _ i: Int) -> Double {
        guard i > 0, i + 1 < values.count, let a = values[i - 1], let b = values[i], let c = values[i + 1] else { return times[i] }
        let denominator = a - 2 * b + c
        guard denominator < 0 else { return times[i] }
        let delta = max(-0.5, min(0.5, 0.5 * (a - c) / denominator))
        let step = delta >= 0 ? times[i + 1] - times[i] : times[i] - times[i - 1]
        return times[i] + delta * step
    }

    /// When the kicking ankle crosses from behind to ahead of the plant ankle, closest to
    /// `contactTime` within −0.5…+0.3 s (linear interpolation between samples).
    static func anklePassTime(_ ahead: [Double?], _ times: [Double], near contactTime: Double) -> Double? {
        var best: Double?
        for i in times.indices.dropFirst() {
            guard times[i] >= contactTime - 0.5 - 1e-9, times[i - 1] <= contactTime + 0.3 + 1e-9,
                  let a = ahead[i - 1], let b = ahead[i], a < 0, b >= 0 else { continue }
            let t = times[i - 1] + (times[i] - times[i - 1]) * (-a / (b - a))
            if best.map({ abs(t - contactTime) < abs($0 - contactTime) }) ?? true { best = t }
        }
        return best
    }

    /// Fraction of samples within ±radius seconds of `time` that have a value.
    static func windowCoverage(_ values: [Double?], _ times: [Double], around time: Double, radius: Double) -> Double {
        let window = times.indices.filter { abs(times[$0] - time) <= radius + 1e-9 }
        guard !window.isEmpty else { return 0 }
        return Double(window.filter { values[$0] != nil }.count) / Double(window.count)
    }
}
