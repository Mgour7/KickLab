import Foundation

/// The phases of a kick, in order.
enum KickPhase: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    /// Standing still before the approach.
    case setup
    /// Steps toward the ball.
    case approach
    /// The plant foot lands and stays fixed through contact.
    case plant
    /// Foot meets ball. Without ball tracking this is an ESTIMATE (peak kicking-foot speed).
    case contact
    /// The kicking leg continues after contact.
    case followThrough
}

enum PhaseDetectionStatus: String, Codable, Sendable {
    /// Found with clear evidence.
    case detected
    /// Found, but from indirect evidence or with weak support (e.g. contact without a ball).
    case estimated
    /// More than one plausible answer; the reported times are the best guess only.
    case ambiguous
    /// Not found (missing data, outside the clip, or unsupported for this kick type).
    case unavailable
}

/// One phase on the timeline. Times are seconds from the start of the analyzed video.
struct DetectedKickPhase: Codable, Equatable, Sendable {
    let phase: KickPhase
    let startTime: Double?
    let endTime: Double?
    /// The single instant that best represents the phase (e.g. plant touchdown, contact).
    let representativeTime: Double?
    /// 0...1
    let confidence: Double
    /// The signals the decision was based on.
    let evidence: [PoseSignalKey]
    let status: PhaseDetectionStatus

    static func unavailable(_ phase: KickPhase, evidence: [PoseSignalKey] = []) -> DetectedKickPhase {
        DetectedKickPhase(phase: phase, startTime: nil, endTime: nil, representativeTime: nil,
                          confidence: 0, evidence: evidence, status: .unavailable)
    }

    var isAvailable: Bool { status != .unavailable }
}

/// How well this version of KickLab understands a kick type's phases.
enum KickPhaseSupport: String, Codable, Sendable {
    case full
    /// Only some phases are detected (punts: contact and follow-through).
    case limited
    case unsupported
}

struct KickPhaseDetectionResult: Codable, Equatable, Sendable {
    let kickType: KickType
    let support: KickPhaseSupport
    /// One entry per `KickPhase`, in order.
    let phases: [DetectedKickPhase]
    /// 0...1
    let overallConfidence: Double
    /// Fraction of samples with the kicking-ankle signal.
    let dataCoverage: Double
    /// Plain-language notes for diagnostics (not coaching).
    let notes: [String]
    /// Step 12B: the evidence behind contact, plant and follow-through (nil in files
    /// written before Step 12B).
    var evidence: PhaseDetectionEvidence? = nil
    /// Step 12D: the kick windows found (the selected one is where phases were looked for).
    var kickWindows: KickWindowAnalysis? = nil
    /// Step 12D: what the user supplied for a user-assisted analysis (nil = fully automatic).
    var assistance: PhaseDetectionAssistance? = nil

    var isUserAssisted: Bool { assistance?.isEmpty == false }

    func phase(_ phase: KickPhase) -> DetectedKickPhase {
        phases.first { $0.phase == phase } ?? .unavailable(phase)
    }

    /// Plant-foot touchdown, when found.
    var plantTime: Double? {
        let plant = phase(.plant)
        return plant.isAvailable ? plant.representativeTime : nil
    }

    /// Estimated foot–ball contact, when found. Never "measured" without ball tracking.
    var estimatedContactTime: Double? {
        let contact = phase(.contact)
        return contact.isAvailable ? contact.representativeTime : nil
    }

    static func unavailable(kickType: KickType, support: KickPhaseSupport, coverage: Double, notes: [String]) -> KickPhaseDetectionResult {
        KickPhaseDetectionResult(kickType: kickType, support: support,
                                 phases: KickPhase.allCases.map { .unavailable($0) },
                                 overallConfidence: 0, dataCoverage: coverage, notes: notes)
    }
}

/// Step 12B: what the detector measured around contact. Times in seconds, speeds in
/// body lengths per second. For diagnostics and validation only; nothing here is a score.
struct PhaseDetectionEvidence: Codable, Equatable, Sendable {
    /// The contact anchor: the sample with the highest kicking-ankle speed.
    var contactPeakTime: Double?
    var contactPeakSpeed: Double?
    /// Sub-frame peak time from a parabola through the three samples around the peak.
    var refinedContactTime: Double?
    /// When the kicking ankle passed the plant ankle along the direction of travel
    /// (independent of foot speed). Nil when not seen or the direction is unknown.
    var anklePassTime: Double?
    /// refinedContactTime − anklePassTime.
    var contactCueOffset: Double?
    /// Plant-ankle speed while the athlete was standing still: the measurement noise.
    var plantNoiseFloor: Double?
    /// The plant-still threshold actually used.
    var plantStillThreshold: Double?
    /// Slowest filtered plant-ankle speed in the plant search window.
    var slowestPlantSpeedBeforeContact: Double?
    /// Filtered plant-ankle speed at the contact anchor.
    var plantSpeedAtContact: Double?
    var plantTouchdownTime: Double?
    /// True when the plant foot stayed still through contact; false when it landed but
    /// was moving again by contact; nil when no touchdown was found.
    var plantStillThroughContact: Bool?
    /// Seconds from contact until the kicking ankle slowed to the follow-through end
    /// fraction (nil when it never did before the clip ended).
    var followThroughSeconds: Double?

    // Step 12C (all optional so Step 12B files still decode)

    /// The contact/phase rules that produced this result.
    var algorithmVersion: String? = nil
    /// Every contact candidate considered, with its evidence and why it was or wasn't chosen.
    var contactCandidates: [ContactCandidate]? = nil
    /// ± seconds around the estimated contact.
    var contactUncertaintySeconds: Double? = nil
    /// Conflicts between independent cues, in plain language.
    var contactConflicts: [String]? = nil
    /// Which of the four plant outcomes applies.
    var plantState: PlantState? = nil
    var plantCandidates: [PhaseEndpointCandidate]? = nil
    /// Plant ankle relative to the plant hip at touchdown, body lengths along travel.
    var plantFootAheadOfHip: Double? = nil
    var followThroughCandidates: [PhaseEndpointCandidate]? = nil
    /// The leg labeled as the plant leg made the fastest swing near contact while the
    /// kicking leg was at rest: the profile's kicking foot or the pose labels may be wrong.
    var legRoleConflict: Bool? = nil

    // Step 12D (optional)

    /// WHO set the contact time: "automatic" (the detector) or "user" (a user-assisted
    /// analysis). Files written by 2.3.0 builds before the reanalysis fix stored the
    /// timing method here instead ("speedPeak" / "plantAndFootPassing"); read
    /// `contactTimingSource` and `contactTimingMethodResolved`, which handle both.
    var contactTimingBasis: String? = nil
    /// After contact the kicking ankle stays within 0.2 body lengths of the plant ankle:
    /// the kicking foot is no longer tracked separately (often motion blur at 30 fps).
    var kickingAnkleMergedAfterContact: Bool? = nil
    /// After contact the whole athlete moves backward in the frame: the camera is probably
    /// panning, so foot movement after contact is not reliable.
    var cameraMotionSuspected: Bool? = nil
    /// The plant touchdown found from the kick window before contact was chosen.
    var plantPriorTime: Double? = nil
    var userAssistedContactTime: Double? = nil
    /// HOW the contact time was found: "speedPeak", "plantAndFootPassing" (moved to the
    /// plant landing / foot passing bound) or "user" (the user's frame).
    var contactTimingMethod: String? = nil

    // Step 12E (optional)

    /// How "kicking ankle merged with the plant ankle" was decided: "separation2D" (the
    /// straight-line distance between the ankles) or "alongTravelLegacy" (only the
    /// distance along the direction of travel — files without the separation signal).
    var kickingAnkleTrackingRule: String? = nil
    /// When the ankles came together after contact (nil = they didn't).
    var kickingAnkleMergeOnsetTime: Double? = nil
    /// Straight-line ankle and knee distances at the contact sample, body lengths.
    var ankleSeparationAtContact: Double? = nil
    var kneeSeparationAtContact: Double? = nil
    /// Which joint timed the follow-through: "kickingAnkle", or "kickingKnee" when the
    /// kicking ankle wasn't tracked separately after contact.
    var followThroughBasis: String? = nil
    /// The physically possible contact interval: never before the plant landing (+1
    /// frame) when contact is timed from it. Replaces a symmetric ± that could extend
    /// before the plant.
    var contactEarliestTime: Double? = nil
    var contactLatestTime: Double? = nil
    /// Step 12F (contact-intelligence-3): the independent evidence groups considered for
    /// first contact, and whether each agreed. Correlated cues inside one group count once.
    var contactEvidenceGroups: [ContactEvidenceGroup]? = nil
    /// Step 12F: the strike approach (knee drive starting) — before first contact.
    var strikeApproachStartTime: Double? = nil
    /// Step 12F: post-contact swing milestones (knee extension completed, foot lowest);
    /// these are never first contact.
    var postContactMarkers: [PhaseEndpointCandidate]? = nil
    /// Step 12F: "poseOnly", "ballAware" or "user".
    var contactProvenance: String? = nil
    /// Step 12G: "beforeKneeDrive" when the plant was found by the drive-anchored search.
    var plantSearchBasis: String? = nil
    /// Step 12F: what the football detector contributed (nil when it didn't run).
    var ballEvidence: BallContactEvidence? = nil

    // Step 12G — Computer Vision Intelligence Rebuild (optional)

    /// Which kind of contact answer this is (see `ContactOutcome`).
    var contactOutcome: ContactOutcome? = nil
    /// How the football was found for this analysis.
    var ballAnalysisMethod: FootballAnalysisMethod? = nil
    /// Engine 2.8.1: how the football's movement was combined with the pose (depth views).
    var ballFusion: BallFusionReport? = nil
    /// Build 16: the pose-only contact timing score before any ball evidence (heuristic,
    /// 0–0.6, not a probability). Nil in older analyses.
    var poseTimingScore: Double? = nil
}

/// Who set the contact time of an analysis.
enum ContactTimingSource: String, Codable, Sendable {
    case automatic
    case user
}

extension PhaseDetectionEvidence {
    static let automaticBasis = "automatic"
    static let userBasis = "user"

    /// Who set the contact time (nil when the file has no contact timing information).
    var contactTimingSource: ContactTimingSource? {
        if contactTimingBasis == Self.userBasis || userAssistedContactTime != nil { return .user }
        if contactTimingBasis != nil || contactTimingMethod != nil { return .automatic }
        return nil
    }

    /// How the contact time was found, also for files that stored the method in
    /// `contactTimingBasis`.
    var contactTimingMethodResolved: String? {
        if let contactTimingMethod { return contactTimingMethod }
        guard let basis = contactTimingBasis, basis != Self.automaticBasis else { return nil }
        return basis
    }

    /// Contact was moved to the plant-landing / foot-passing bound (no measured strike).
    var contactTimedByConstraints: Bool { contactTimingMethodResolved == "plantAndFootPassing" }
}

/// Step 12D: what the user supplied when automatic detection was uncertain. Recorded
/// exactly; never mixed into automatic-accuracy statistics.
struct PhaseDetectionAssistance: Codable, Equatable, Sendable {
    /// The frame the user chose as foot–ball contact (seconds into the video).
    var contactTime: Double?
    /// The interval the user chose to analyze (the video itself is untouched).
    var windowStart: Double?
    var windowEnd: Double?
    /// Step 12G: the plant frame the user chose (overrides automatic plant detection for
    /// this user-assisted analysis only).
    var plantTime: Double? = nil
    /// Step 12G: the ball's movement measured from the video after the user located the
    /// ball. Its first disturbed frame is used as contact.
    var ballMotion: BallMotionResult? = nil

    init(contactTime: Double? = nil, windowStart: Double? = nil, windowEnd: Double? = nil,
         plantTime: Double? = nil, ballMotion: BallMotionResult? = nil) {
        self.contactTime = contactTime
        self.windowStart = windowStart
        self.windowEnd = windowEnd
        self.plantTime = plantTime
        self.ballMotion = ballMotion
    }

    /// The contact the analysis must use: the user's frame, else the ball's first
    /// disturbed frame (when the ball measurably departed).
    var effectiveContactTime: Double? {
        contactTime ?? (ballMotion?.outcome == .departed ? ballMotion?.firstDisturbedTime : nil)
    }

    var window: ClosedRange<Double>? {
        guard let a = windowStart, let b = windowEnd, b > a else { return nil }
        return a...b
    }

    var isEmpty: Bool { contactTime == nil && window == nil && plantTime == nil && effectiveContactTime == nil }
}

/// Step 12C: the four plant outcomes.
enum PlantState: String, Codable, Sendable {
    /// Plant foot came to rest and stayed still through contact.
    case touchdownDetected
    /// Plant found from weaker evidence (clipped, interrupted, or a foot behind the hip).
    case estimated
    /// Plant foot landed but was moving again by contact (a biomechanical finding).
    case unstableAfterTouchdown
    /// No plant evidence: none is reported.
    case notDetected
    /// Step 12G: the plant frame was chosen by the user.
    case userSupplied
}

/// Step 12C: a candidate time for a phase boundary (plant touchdown, follow-through end)
/// and whether it was used.
struct PhaseEndpointCandidate: Codable, Equatable, Sendable {
    var kind: String
    var time: Double
    var accepted: Bool
    var reason: String
}

/// Thresholds per kick type. Speeds are in body lengths per second; times in seconds.
struct KickPhaseProfile: Codable, Equatable, Sendable {
    var support: KickPhaseSupport
    /// Shortest approach that counts as `.detected` (shorter → `.estimated`).
    var minimumApproachSeconds: Double
    /// Body-center speed that counts as moving.
    var approachSpeedThreshold: Double
    /// Plant-ankle speed that counts as planted (still).
    var plantStillSpeedThreshold: Double
    /// Plant touchdown is searched for within this long before contact.
    var plantMaximumLeadSeconds: Double
    /// The kicking-ankle peak must reach this speed to count as a kick.
    var contactMinimumPeakSpeed: Double
    /// A second peak at least this fraction of the highest makes contact ambiguous…
    var contactAmbiguityRatio: Double
    /// …when it is at least this far away in time.
    var contactPeakSeparationSeconds: Double
    /// Follow-through ends when kicking-ankle speed falls to this fraction of the peak.
    var followThroughEndFraction: Double
    var minimumFollowThroughSeconds: Double
    /// Stillness before the approach must last this long to report a setup phase.
    var minimumSetupSeconds: Double
    /// Below this kicking-ankle coverage nothing is detected.
    var minimumCoverage: Double

    static let placeKick = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Kickoffs: longer, faster approach.
    static let kickoff = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 1.0, approachSpeedThreshold: 1.0,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.35, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Punts: drop and swing differ from place kicks; only contact and follow-through.
    static let punt = KickPhaseProfile(
        support: .limited, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    static func `for`(_ kickType: KickType) -> KickPhaseProfile {
        switch kickType {
        case .fieldGoal, .pat: .placeKick
        case .kickoff: .kickoff
        case .punt: .punt
        case .unknown: KickPhaseProfile(
            support: .unsupported, minimumApproachSeconds: 0, approachSpeedThreshold: 0,
            plantStillSpeedThreshold: 0, plantMaximumLeadSeconds: 0, contactMinimumPeakSpeed: 0,
            contactAmbiguityRatio: 1, contactPeakSeparationSeconds: 0, followThroughEndFraction: 0,
            minimumFollowThroughSeconds: 0, minimumSetupSeconds: 0, minimumCoverage: 1
        )
        }
    }
}

/// Pure, rule-based phase detection from pose signals. Separate from signal extraction
/// so it can be tested on synthetic timelines and later replaced by a learned model.
///
/// Anchor: contact is estimated at the peak kicking-ankle speed. Plant, approach and
/// setup are found by walking BACK from contact; follow-through by walking forward.
enum KickPhaseDetector {
    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile? = nil,
        assistance: PhaseDetectionAssistance? = nil,
        perspective: CameraPerspective = .side,
        ballContact: AutomaticBallContact? = nil
    ) -> KickPhaseDetectionResult {
        let result = detectPhases(signals, kickType: kickType, profile: profile, assistance: assistance, perspective: perspective,
                                  ballContact: ballContact)
        guard let plant = assistance?.plantTime else { return result }
        return applyUserPlant(result, plantTime: plant, times: signals.timestamps)
    }

    /// Step 12G: a user-chosen plant frame replaces the detected plant in that
    /// user-assisted analysis only (labeled `userSupplied`; never automatic accuracy).
    static func applyUserPlant(_ result: KickPhaseDetectionResult, plantTime: Double, times: [Double]) -> KickPhaseDetectionResult {
        guard let i = times.indices.min(by: { abs(times[$0] - plantTime) < abs(times[$1] - plantTime) }) else { return result }
        let t = times[i]
        let contact = result.estimatedContactTime
        var notes = result.notes
        var evidence = result.evidence ?? PhaseDetectionEvidence(contactPeakTime: nil, contactPeakSpeed: nil)
        if let c = contact, t >= c {
            notes.append(String(format: "The plant frame you chose (%.3f s) is not before contact (%.3f s), so it wasn't used.", t, c))
            var r = KickPhaseDetectionResult(kickType: result.kickType, support: result.support, phases: result.phases,
                                             overallConfidence: result.overallConfidence, dataCoverage: result.dataCoverage, notes: notes)
            r.evidence = result.evidence
            r.kickWindows = result.kickWindows
            r.assistance = result.assistance
            return r
        }
        evidence.plantState = .userSupplied
        evidence.plantTouchdownTime = t
        evidence.plantCandidates = (evidence.plantCandidates ?? []).map {
            PhaseEndpointCandidate(kind: $0.kind, time: $0.time, accepted: false, reason: "replaced by the plant frame you chose")
        } + [PhaseEndpointCandidate(kind: "user", time: t, accepted: true, reason: "chosen by the user")]
        let phases = result.phases.map { p -> DetectedKickPhase in
            switch p.phase {
            case .plant:
                return DetectedKickPhase(phase: .plant, startTime: t, endTime: contact ?? t, representativeTime: t,
                                         confidence: 0.6, evidence: p.evidence, status: .estimated)
            case .approach where p.isAvailable:
                return DetectedKickPhase(phase: .approach, startTime: p.startTime, endTime: t, representativeTime: p.representativeTime,
                                         confidence: p.confidence, evidence: p.evidence, status: p.status)
            default:
                return p
            }
        }
        notes.insert(String(format: "Plant frame chosen by the user: %.3f s.", t), at: 0)
        var r = KickPhaseDetectionResult(kickType: result.kickType, support: result.support, phases: phases,
                                         overallConfidence: result.overallConfidence, dataCoverage: result.dataCoverage, notes: notes)
        r.evidence = evidence
        r.kickWindows = result.kickWindows
        r.assistance = result.assistance
        return r
    }

    static func detectPhases(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile? = nil,
        assistance: PhaseDetectionAssistance? = nil,
        perspective: CameraPerspective = .side,
        ballContact: AutomaticBallContact? = nil
    ) -> KickPhaseDetectionResult {
        let profile = profile ?? .for(kickType)
        // Step 12E: filmed from behind or in front, a separate detector that doesn't treat
        // horizontal image motion as forward.
        if perspective.isDepthView {
            return DepthViewPhaseDetector.detect(signals, kickType: kickType, profile: profile,
                                                 perspective: perspective, assistance: assistance, ballContact: ballContact)
        }
        let times = signals.timestamps
        let ankle = signals.values(.kickingAnkleSpeed)
        let coverage = signals.coverage(.kickingAnkleSpeed)

        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases."])
        }

        // MARK: Kick window (Step 12D)
        // Where the kick is, from the hips' approach and braking (a different body part from
        // the kicking foot), before any contact candidate is ranked.
        var windows = KickWindowDetector.detect(signals, profile: profile, restrictTo: assistance?.window)
        if let range = assistance?.window, windows.selected == nil {
            windows = KickWindowAnalysis(windows: [KickWindowDetector.userWindow(range, signals: signals)], selectedIndex: 0,
                                         needsSelection: false, notes: ["Analyzing the interval chosen by the user."])
        }
        if assistance?.window != nil, windows.needsSelection {
            windows.needsSelection = false
            windows.notes.append("The user chose this interval; other kicks in it were not analyzed separately.")
        }
        let kickWindow = windows.selected

        // Plant touchdown from the window alone (independent of which contact is chosen).
        let plantSpeedFiltered = medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let priorThreshold = stillThreshold(signals, profile: profile)
        let plantPrior: Int? = (profile.support == .full) ? kickWindow.flatMap {
            plantTouchdown(in: $0, signals: signals, filtered: plantSpeedFiltered, threshold: priorThreshold)
        } : nil

        // MARK: Contact (anchor)
        // Step 12C: contact is chosen among candidates by independent evidence (see
        // `ContactEstimator`); Step 12D ranks only candidates in the kick window and keeps
        // contact after the plant landing and the foot passing.
        let contactEstimate = ContactEstimator.estimate(signals, profile: profile, window: kickWindow,
                                                        plantTouchdown: plantPrior.map { times[$0] })
        let userContact = assistance?.effectiveContactTime.flatMap { t in times.indices.min { abs(times[$0] - t) < abs(times[$1] - t) } }
        guard let chosenAnchor = contactEstimate.selected ?? userContact.map({ i in
            ContactCandidate(time: times[i], refinedTime: times[i], peakSpeed: 0, relativeSpeed: 0, swingSupport: 0,
                             forwardDirection: nil, plantSupport: nil, passTiming: nil, bodyTransition: nil, followThrough: nil,
                             score: 0, independentSupport: 0, supportingSignals: [], rejectionReasons: [], selected: true)
        }) else {
            var result = KickPhaseDetectionResult.unavailable(
                kickType: kickType, support: profile.support, coverage: coverage,
                notes: [contactEstimate.unavailableReason ?? "No kicking motion was found."] + windows.notes
            )
            result.evidence = PhaseDetectionEvidence(
                plantNoiseFloor: contactEstimate.plantNoiseFloor, plantStillThreshold: contactEstimate.plantStillThreshold,
                algorithmVersion: ContactEstimator.algorithmVersion,
                contactCandidates: contactEstimate.candidates.isEmpty ? nil : contactEstimate.candidates
            )
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }
        var chosen = chosenAnchor
        var strikeTime = contactEstimate.strikeTime ?? chosen.time
        if let i = userContact {
            // User-assisted: the user's frame is the contact; the speed for follow-through
            // is the fastest kicking-foot speed within 0.15 s of it.
            strikeTime = times[i]
            let near = times.indices.filter { abs(times[$0] - times[i]) <= 0.15 + 1e-9 }
            chosen.peakSpeed = near.compactMap { ankle[$0] }.max() ?? 0
        }
        guard let peakIndex = times.firstIndex(where: { abs($0 - strikeTime) < 1e-9 }) else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage, notes: ["No kicking motion was found."])
        }
        let peak = max(chosen.peakSpeed, ankle[peakIndex] ?? 0)
        let contactTime = times[peakIndex]
        var evidence = PhaseDetectionEvidence(contactPeakTime: chosen.time, contactPeakSpeed: chosen.peakSpeed)
        evidence.algorithmVersion = ContactEstimator.algorithmVersion
        evidence.refinedContactTime = chosen.refinedTime
        evidence.contactCandidates = contactEstimate.candidates
        evidence.contactUncertaintySeconds = contactEstimate.uncertaintySeconds
        evidence.contactTimingBasis = userContact != nil ? PhaseDetectionEvidence.userBasis : PhaseDetectionEvidence.automaticBasis
        evidence.contactTimingMethod = userContact != nil ? "user" : (contactEstimate.selected?.timingBasis ?? "speedPeak")
        evidence.plantPriorTime = plantPrior.map { times[$0] }
        evidence.userAssistedContactTime = userContact.map { times[$0] }
        let isAmbiguous = userContact == nil && (contactEstimate.isAmbiguous || windows.needsSelection)
        let localCoverage = windowCoverage(ankle, times, around: contactTime, radius: 0.1)
        var notes: [String] = ["Contact is estimated from kicking-foot motion with supporting cues (no ball tracking)."]
        if userContact != nil {
            notes = ["Contact time was chosen by the user (user-assisted analysis); everything else was measured around it."]
        }
        notes.append(contentsOf: windows.notes)
        if contactEstimate.isAmbiguous && userContact == nil { notes.append("More than one kicking motion was found; phase times are uncertain.") }
        var conflicts = userContact == nil ? contactEstimate.conflicts : []

        if signals.travelDirection != 0,
           let pass = anklePassTime(signals.values(.kickingAnkleAheadOfPlant), times, near: contactTime) {
            evidence.anklePassTime = pass
            evidence.contactCueOffset = contactTime - pass
        }

        // After contact: is the kicking foot still tracked, and is the camera still?
        // Step 12E: decided from the straight-line distance between the ankles when it is
        // available. The old rule looked only along the direction of travel, so a foot
        // rising straight up beside the plant foot (a normal follow-through) counted as
        // "merged".
        let tracking = kickingAnkleTracking(separation: signals.values(.ankleSeparation),
                                            ahead: signals.values(.kickingAnkleAheadOfPlant), times, after: contactTime)
        let merged = tracking.merged
        evidence.kickingAnkleMergedAfterContact = merged
        evidence.kickingAnkleTrackingRule = tracking.rule
        evidence.kickingAnkleMergeOnsetTime = tracking.onset
        evidence.ankleSeparationAtContact = signals.values(.ankleSeparation)[peakIndex].map(ContactEstimator.round3)
        evidence.kneeSeparationAtContact = signals.values(.kneeSeparation)[peakIndex].map(ContactEstimator.round3)
        if merged {
            conflicts.append(tracking.rule == "separation2D"
                ? String(format: "From %.3f s the kicking ankle stays within %.2f body lengths of the plant ankle (straight-line distance): both ankle labels sit on one foot, so the kicking foot isn't tracked separately (often motion blur at this frame rate).", tracking.onset ?? contactTime, ankleCollapseDistance)
                : "After contact the kicking ankle stays level with the plant ankle along the direction of travel (older rule; no straight-line distance available): the kicking foot may not be tracked separately, so the swing after contact can't be measured from the ankle.")
        }
        // The contact interval: never before the plant landing when timed from it.
        let uncertainty = contactEstimate.uncertaintySeconds ?? 0
        if userContact == nil {
            let earliestAllowed = evidence.contactTimingMethodResolved == "plantAndFootPassing" ? contactTime : contactTime - uncertainty
            evidence.contactEarliestTime = ContactEstimator.round3(max(earliestAllowed, plantPrior.map { times[$0] } ?? -.infinity))
            evidence.contactLatestTime = ContactEstimator.round3(contactTime + uncertainty)
        }
        let panning = cameraMotion(signals.values(.bodyForwardVelocity), times, after: contactTime)
        evidence.cameraMotionSuspected = panning
        if panning {
            conflicts.append("After contact the whole athlete moves backward in the frame: the camera is probably panning, so foot movement after contact is unreliable. Keep the camera still.")
        }

        // Leg roles: the "plant" leg swinging fastest while the "kicking" leg rests.
        let roleConflict = profile.support == .full && legRoleConflict(signals, times, contactTime: contactTime, kickingPeak: peak,
                                                                          threshold: contactEstimate.plantStillThreshold)
        evidence.legRoleConflict = roleConflict
        var roleFactor = 1.0
        if roleConflict {
            roleFactor = 0.5
            conflicts.append("Near contact the leg labeled as the plant leg swung fastest while the kicking leg was at rest. Check the kicking foot in the athlete's profile, or the pose labels may be reversed.")
        }
        evidence.contactConflicts = conflicts
        notes.append(contentsOf: conflicts)

        // Anything derived from an ambiguous anchor is ambiguous too.
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus {
            isAmbiguous ? .ambiguous : base
        }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }

        var contactConfidence = userContact != nil ? 0.6 : contactEstimate.confidence * localCoverage * roleFactor
        if windows.needsSelection && userContact == nil && !contactEstimate.isAmbiguous { contactConfidence *= 0.4 }
        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: min(1, max(0, contactConfidence)),
            evidence: [.kickingAnkleSpeed, .kickingAnkleForwardVelocity, .plantAnkleSpeed, .bodyForwardVelocity, .kickingAnkleAheadOfPlant],
            status: status(.estimated)
        )

        // MARK: Follow-through
        // Endpoint candidates: (a) kicking-foot speed down to the end fraction of the
        // peak and staying there for a second sample; (b) the swing apex — the foot's
        // furthest point ahead of the hip after contact; (c) the end of the clip. The later
        // of (a) and (b) is used, so a quick speed dip doesn't cut the swing short. It never
        // depends on the plant.
        var followCandidates: [PhaseEndpointCandidate] = []
        var slowdownIndex: Int?
        let endSpeed = profile.followThroughEndFraction * peak
        for i in (peakIndex + 1)..<max(peakIndex + 1, times.count) {
            guard let v = ankle[i], v <= endSpeed else { continue }
            let confirmed = i + 1 >= times.count || (ankle[i + 1].map { $0 <= endSpeed } ?? false)
            if confirmed { slowdownIndex = i; break }
        }
        let apexIndex = swingApex(signals.values(.kickingAnkleForwardOffset), times, after: peakIndex)
        var followEndIndex: Int?
        let minimumEnd = contactTime + profile.minimumFollowThroughSeconds - 1e-9
        let usable = [slowdownIndex, apexIndex].compactMap { $0 }.filter { times[$0] >= minimumEnd }
        followEndIndex = merged ? nil : usable.max()
        // An endpoint was seen but too soon: the follow-through is not long enough to measure.
        let endedTooSoon = merged || (followEndIndex == nil && (slowdownIndex != nil || apexIndex != nil))
        if let i = slowdownIndex {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "slowdown", time: times[i], accepted: i == followEndIndex,
                reason: times[i] < minimumEnd ? "too soon after contact" : (i == followEndIndex ? "used" : "the swing continued after the slow-down")
            ))
        }
        if let i = apexIndex {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "swingApex", time: times[i], accepted: i == followEndIndex,
                reason: times[i] < minimumEnd ? "too soon after contact" : (i == followEndIndex ? "used" : "the foot was still moving fast after the apex")
            ))
        }
        let followThrough: DetectedKickPhase
        let tooSoonEnd = [slowdownIndex, apexIndex].compactMap { $0 }.max()
        let followEnd = times[followEndIndex ?? (endedTooSoon ? (tooSoonEnd ?? peakIndex) : times.count - 1)]
        evidence.followThroughSeconds = slowdownIndex.map { times[$0] - contactTime }
        if followEndIndex == nil && !endedTooSoon {
            followCandidates.append(PhaseEndpointCandidate(
                kind: "clipEnd", time: times[times.count - 1], accepted: followEnd - contactTime >= profile.minimumFollowThroughSeconds,
                reason: followEnd - contactTime >= profile.minimumFollowThroughSeconds ? "clip ends during the follow-through" : "clip ends too soon after contact"
            ))
        }
        // Step 12E: with the kicking ankle lost after contact, the kicking KNEE (a
        // different joint, tracked separately) can still time the follow-through: the knee
        // swings forward relative to the hips and stops at the end of the swing. Metrics
        // that need the ankle stay unavailable.
        var kneeEndIndex: Int?
        if merged {
            kneeEndIndex = kneeFollowThroughEnd(signals, times, contactIndex: peakIndex,
                                                minimumSeconds: profile.minimumFollowThroughSeconds)
            followCandidates.append(PhaseEndpointCandidate(
                kind: "kneeSwingEnd", time: kneeEndIndex.map { times[$0] } ?? contactTime, accepted: kneeEndIndex != nil,
                reason: kneeEndIndex != nil
                    ? "used: the kicking knee's forward swing relative to the hips ended here (the ankle wasn't tracked separately)"
                    : "the kicking knee showed no clear forward swing relative to the hips after contact"
            ))
        }
        evidence.followThroughCandidates = followCandidates
        if !merged, followEnd - contactTime >= profile.minimumFollowThroughSeconds {
            evidence.followThroughBasis = "kickingAnkle"
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: followEnd, representativeTime: contactTime,
                confidence: scaled(followEndIndex == nil ? 0.4 : 0.8 * localCoverage * roleFactor),
                evidence: [.kickingAnkleSpeed, .kickingAnkleForwardOffset],
                status: status(followEndIndex == nil ? .estimated : .detected)
            )
            if followEndIndex == nil { notes.append("The clip ends during the follow-through.") }
        } else if let k = kneeEndIndex {
            evidence.followThroughBasis = "kickingKnee"
            let kneeCoverage = windowCoverage(signals.values(.kickingKneeForwardVelocity), times, around: contactTime, radius: 0.1)
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: times[k], representativeTime: contactTime,
                confidence: scaled(0.5 * kneeCoverage * roleFactor),
                evidence: [.kickingKneeForwardVelocity, .bodyForwardVelocity],
                status: status(.estimated)
            )
            notes.append(String(format: "Follow-through timed from the kicking knee (ends %.3f s): the kicking ankle wasn't tracked separately after contact, so ankle-based follow-through values stay unavailable.", times[k]))
        } else {
            followThrough = .unavailable(.followThrough, evidence: [.kickingAnkleSpeed])
            if merged {
                notes.append("Follow-through can't be measured: the kicking foot isn't tracked separately after contact.")
            } else if slowdownIndex == nil && apexIndex == nil {
                notes.append("The clip ends right after the estimated contact, so there is no follow-through to measure.")
            } else {
                notes.append(String(format: "The kicking foot slowed to %d%% of its peak speed only %.2f s after the estimated contact — too soon for a follow-through, so the estimate may not be the strike.",
                                    Int((profile.followThroughEndFraction * 100).rounded()), (slowdownIndex.map { times[$0] } ?? followEnd) - contactTime))
            }
        }

        guard profile.support == .full else {
            notes.append("Only contact and follow-through are detected for this kick type.")
            let phases = [DetectedKickPhase.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough]
            var result = finish(kickType, profile, phases, coverage, notes, evidence)
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }

        // MARK: Plant
        // The plant is the plant foot COMING TO REST before contact (median-filtered speed,
        // adaptive still threshold), checked against leg configuration (a planted foot is
        // not far behind the hip). Whether it STAYED still through contact is reported
        // separately: an unstable plant is a biomechanical finding, not a missing plant.
        // Four outcomes: touchdown detected, estimated, unstable after touchdown, not detected.
        let plantSpeed = medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let noiseFloor = contactEstimate.plantNoiseFloor
        let stillThreshold = contactEstimate.plantStillThreshold
        if let noiseFloor, stillThreshold > profile.plantStillSpeedThreshold {
            notes.append(String(format: "Pose jitter while standing still (%.2f body lengths/s) raised the plant-still threshold to %.2f.", noiseFloor, stillThreshold))
        }
        evidence.plantNoiseFloor = noiseFloor
        evidence.plantStillThreshold = stillThreshold
        evidence.plantSpeedAtContact = plantSpeed[peakIndex]
        // Step 12D: with a kick window, the plant is searched where the approach brakes
        // (not only relative to the chosen contact); it must still come before contact.
        let window: [Int]
        if let kw = kickWindow, kw.source != "swingOnly" {
            let range = plantSearchRange(kw)
            window = times.indices.filter { $0 <= peakIndex && times[$0] >= range.lowerBound - 1e-9 && times[$0] <= range.upperBound + 1e-9 }
        } else {
            window = times.indices.filter { $0 <= peakIndex && contactTime - times[$0] <= profile.plantMaximumLeadSeconds + 1e-9 }
        }
        evidence.slowestPlantSpeedBeforeContact = window.compactMap { plantSpeed[$0] }.min()
        let isStill = { (i: Int) -> Bool in plantSpeed[i].map { $0 <= stillThreshold } ?? false }
        let minimumRun = max(2, Int((minimumStillSeconds * framesPerSecond(times)).rounded(.up)))
        let footAhead = signals.values(.plantAnkleForwardOffset)

        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantIndex: Int?
        var plantCandidates: [PhaseEndpointCandidate] = []
        // Still runs in the window; the one ending closest to contact is used.
        var runs: [ClosedRange<Int>] = []
        var runStart: Int?
        for i in window {
            if isStill(i) {
                if runStart == nil { runStart = i }
            } else if let start = runStart {
                runs.append(start...(i - 1))
                runStart = nil
            }
        }
        if let start = runStart, let last = window.last { runs.append(start...last) }
        let longRuns = runs.filter { $0.count >= minimumRun }
        for run in runs where run.count < minimumRun {
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[run.lowerBound], accepted: false,
                                                          reason: String(format: "still for only %d sample(s)", run.count)))
        }
        let best = longRuns.last
        for run in longRuns where run != best {
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[run.lowerBound], accepted: false,
                                                          reason: "an earlier rest; a later one is closer to contact"))
        }
        // A foot coming to rest AFTER the estimate means the estimate may be early.
        let afterContact = times.indices.filter { $0 > peakIndex && times[$0] - contactTime <= 0.3 + 1e-9 }
        var lateRun = 0
        for i in afterContact {
            lateRun = isStill(i) ? lateRun + 1 : 0
            if lateRun == minimumRun, best == nil {
                plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[i - minimumRun + 1], accepted: false,
                                                              reason: "after the estimated contact — the contact estimate may be early"))
                break
            }
        }
        if let run = best {
            let start = run.lowerBound
            // Still before the window began: touchdown is earlier than we looked.
            let clipped = start == window.first && start > 0 && isStill(start - 1)
            let interrupted = start > 0 && plantSpeed[start - 1] == nil
            let throughContact = times[run.upperBound] >= contactTime - plantContactToleranceSeconds - 1e-9
            let ahead = footAhead[start]
            let behindHip = (ahead ?? 0) < plantBehindHipLimit
            plantIndex = start
            evidence.plantTouchdownTime = times[start]
            evidence.plantStillThroughContact = throughContact
            evidence.plantFootAheadOfHip = ahead.map { (($0 * 1000).rounded()) / 1000 }
            let base: PhaseDetectionStatus = (clipped || interrupted || !throughContact || behindHip) ? .estimated : .detected
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[start], radius: 0.1)
            let strength = base == .detected ? 0.85 : (throughContact ? 0.5 : 0.4)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[start], endTime: contactTime, representativeTime: times[start],
                confidence: scaled(strength * plantCoverage * roleFactor),
                evidence: [.plantAnkleSpeed, .plantAnkleForwardOffset, .kickingAnkleSpeed], status: status(base)
            )
            var reason = "used"
            if clipped { reason += "; already still when the search began (touchdown may be earlier)" }
            if interrupted { reason += "; plant ankle missing just before" }
            if behindHip { reason += "; foot behind the hip, more like push-off than a plant" }
            if !throughContact { reason += "; moving again before contact" }
            plantCandidates.append(PhaseEndpointCandidate(kind: "stillRun", time: times[start], accepted: true, reason: reason))
            evidence.plantState = !throughContact ? .unstableAfterTouchdown : (base == .detected ? .touchdownDetected : .estimated)
            if !throughContact {
                let moving = ((run.upperBound + 1)...max(run.upperBound + 1, peakIndex)).compactMap { plantSpeed.indices.contains($0) ? plantSpeed[$0] : nil }.max()
                notes.append(String(format: "The plant foot came to rest at %.2f s but was moving again by the estimated contact (up to %.2f body lengths/s): an unstable plant, or the contact estimate is off.",
                                    times[start], moving ?? .nan))
            }
            if behindHip { notes.append("At touchdown the plant foot was behind the hip, so the plant time is only an estimate.") }
        } else if let brief = briefPlant(signals.values(.plantAnkleSpeed), times, window: window, peakIndex: peakIndex,
                                         stillThreshold: stillThreshold) {
            // A sharp stop that lasted a single sample at this frame rate, then motion
            // again before contact: the touchdown is identifiable, the plant unstable.
            plantIndex = brief
            evidence.plantTouchdownTime = times[brief]
            evidence.plantStillThroughContact = false
            evidence.plantFootAheadOfHip = footAhead[brief].map { (($0 * 1000).rounded()) / 1000 }
            evidence.plantState = .unstableAfterTouchdown
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[brief], radius: 0.1)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[brief], endTime: contactTime, representativeTime: times[brief],
                confidence: scaled(0.3 * plantCoverage * roleFactor),
                evidence: [.plantAnkleSpeed, .kickingAnkleSpeed], status: status(.estimated)
            )
            plantCandidates.append(PhaseEndpointCandidate(kind: "briefStop", time: times[brief], accepted: true,
                                                          reason: "a one-sample stop after a sharp slow-down"))
            notes.append(String(format: "The plant foot stopped sharply at %.2f s but only for one frame, and was moving again by the estimated contact: an unstable plant (a higher frame rate would show it better).",
                                times[brief]))
        } else {
            evidence.plantState = .notDetected
            let slowest = evidence.slowestPlantSpeedBeforeContact
            notes.append(slowest.map {
                String(format: "The plant foot never came to rest in the %.1f s before the estimated contact (slowest %.2f body lengths/s; still means ≤ %.2f).",
                       profile.plantMaximumLeadSeconds, $0, stillThreshold)
            } ?? "The plant ankle wasn't visible before the estimated contact.")
        }
        evidence.plantCandidates = plantCandidates

        // MARK: Approach
        let bodySpeed = signals.values(.bodyCenterSpeed)
        var approach = DetectedKickPhase.unavailable(.approach, evidence: [.bodyCenterSpeed])
        var approachStartIndex: Int?
        let approachEndIndex = plantIndex ?? peakIndex
        // The last moving sample at or shortly before plant (bodies slow as they plant).
        let moving = { (i: Int) -> Bool in (bodySpeed[i] ?? 0) >= profile.approachSpeedThreshold }
        if let last = stride(from: approachEndIndex, through: 0, by: -1)
            .first(where: { times[approachEndIndex] - times[$0] <= 0.3 && moving($0) }) {
            var start = last
            while start > 0, moving(start - 1) { start -= 1 }
            approachStartIndex = start
            let duration = times[approachEndIndex] - times[start]
            let longEnough = duration >= profile.minimumApproachSeconds
            if !longEnough { notes.append("The approach was shorter than expected for this kick type.") }
            let reachesStart = start == 0
            if reachesStart { notes.append("The clip starts during the approach.") }
            let base: PhaseDetectionStatus = (longEnough && !reachesStart && plantIndex != nil) ? .detected : .estimated
            approach = DetectedKickPhase(
                phase: .approach, startTime: times[start], endTime: times[approachEndIndex],
                representativeTime: times[start],
                confidence: scaled(base == .detected ? 0.8 : 0.4),
                evidence: [.bodyCenterSpeed, .bodyForwardVelocity], status: status(base)
            )
        }

        // MARK: Setup
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.bodyCenterSpeed])
        if let approachStart = approachStartIndex, approachStart > 0,
           times[approachStart] - times[0] >= profile.minimumSetupSeconds {
            let window = 0..<approachStart
            let known = window.filter { bodySpeed[$0] != nil }
            let still = known.filter { !moving($0) }
            let fraction = known.isEmpty ? 0 : Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(
                    phase: .setup, startTime: times[0], endTime: times[approachStart], representativeTime: times[0],
                    confidence: scaled(0.7 * fraction), evidence: [.bodyCenterSpeed],
                    status: status(fraction >= 0.8 ? .detected : .estimated)
                )
            }
        }

        var result = finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes, evidence)
        result.kickWindows = windows
        result.assistance = assistance
        return result
    }

    static func finish(
        _ kickType: KickType,
        _ profile: KickPhaseProfile,
        _ phases: [DetectedKickPhase],
        _ coverage: Double,
        _ notes: [String],
        _ evidence: PhaseDetectionEvidence
    ) -> KickPhaseDetectionResult {
        let found = phases.filter(\.isAvailable)
        let mean = found.isEmpty ? 0 : found.map(\.confidence).reduce(0, +) / Double(found.count)
        return KickPhaseDetectionResult(kickType: kickType, support: profile.support, phases: phases,
                                        overallConfidence: min(1, mean * coverage), dataCoverage: coverage, notes: notes,
                                        evidence: evidence)
    }

    // MARK: Step 12D helpers

    /// Where the plant can be in a kick window: from shortly before the approach ends to
    /// shortly after braking ends.
    static func plantSearchRange(_ w: KickWindow) -> ClosedRange<Double> {
        (w.approachEnd - 0.35)...max(w.approachEnd - 0.35, w.brakingEnd + 0.3)
    }

    /// The plant-still threshold (profile value, raised by standing-still jitter, capped).
    static func stillThreshold(_ signals: PoseSignalSet, profile: KickPhaseProfile) -> Double {
        let plant = medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        var threshold = profile.plantStillSpeedThreshold
        if let floor = plantNoiseFloor(plant, signals.values(.bodyCenterSpeed), profile: profile), noiseFloorMultiplier * floor > threshold {
            threshold = min(noiseFloorMultiplier * floor, plantStillSpeedCeiling)
        }
        return threshold
    }

    /// Plant touchdown in a kick window, before any contact is chosen: the FIRST time the
    /// plant foot comes to rest in the search range (a still run, or a sharp one-sample stop
    /// after which it stays slower). Later rests are re-plants or slides.
    static func plantTouchdown(in w: KickWindow, signals: PoseSignalSet, filtered: [Double?], threshold: Double) -> Int? {
        guard w.source != "swingOnly" else { return nil }
        let times = signals.timestamps
        let range = plantSearchRange(w)
        let search = times.indices.filter { range.contains(times[$0]) }
        guard let last = search.last else { return nil }
        let minimumRun = max(2, Int((minimumStillSeconds * framesPerSecond(times)).rounded(.up)))
        var starts: [Int] = []
        var run = 0
        for i in search {
            if (filtered[i] ?? .infinity) <= threshold {
                run += 1
                if run == minimumRun { starts.append(i - minimumRun + 1) }
            } else {
                run = 0
            }
        }
        let stops = briefStops(signals.values(.plantAnkleSpeed), times, window: search, before: last + 1, stillThreshold: threshold)
        return (starts + stops).min()
    }

    /// Within 0.25 s after contact the kicking ankle comes within 0.2 body lengths of the
    /// plant ankle and STAYS there (at least 80% of the next 0.3 s): the two are no longer
    /// told apart (a blurred kicking foot snapped onto the plant leg). A foot swinging past
    /// the plant foot is near it only for a moment.
    /// Step 12D rule (along the direction of travel only), kept for older signal files.
    static func kickingAnkleMerged(_ ahead: [Double?], _ times: [Double], after t: Double) -> Bool {
        merge(ahead, times, after: t, limit: 0.2) != nil
    }

    /// Step 12E: straight-line ankle distance (body lengths) below which, held after
    /// contact, both ankle labels are taken to be on one foot.
    static let ankleCollapseDistance = 0.12

    /// Whether the kicking ankle was tracked separately after contact. Uses the
    /// straight-line separation when at least 4 samples of it follow contact; otherwise the
    /// legacy along-travel rule (Step 12D) so older signal files replay unchanged.
    static func kickingAnkleTracking(separation: [Double?], ahead: [Double?], _ times: [Double], after t: Double)
        -> (merged: Bool, rule: String, onset: Double?) {
        let following = times.indices.filter { times[$0] > t + 1e-9 && times[$0] <= t + 0.55 + 1e-9 }
        if following.compactMap({ separation[$0] }).count >= 4 {
            let onset = merge(separation, times, after: t, limit: ankleCollapseDistance)
            return (onset != nil, "separation2D", onset)
        }
        let onset = merge(ahead, times, after: t, limit: 0.2)
        return (onset != nil, "alongTravelLegacy", onset)
    }

    /// The first time within 0.25 s after `t` from which |value| stays within `limit` for
    /// at least 80% of the next 0.3 s (at least 4 samples).
    static func merge(_ values: [Double?], _ times: [Double], after t: Double, limit: Double) -> Double? {
        let onsets = times.indices.filter { times[$0] > t + 1e-9 && times[$0] <= t + 0.25 + 1e-9 && abs(values[$0] ?? .infinity) <= limit }
        for onset in onsets {
            let following = times.indices.filter { times[$0] >= times[onset] - 1e-9 && times[$0] <= times[onset] + 0.3 + 1e-9 }
                .compactMap { values[$0] }
            guard following.count >= 4 else { continue }
            if Double(following.filter { abs($0) <= limit }.count) >= 0.8 * Double(following.count) { return times[onset] }
        }
        return nil
    }

    /// Step 12E: the end of the kicking knee's forward swing after contact, relative to the
    /// hips (so camera panning cancels): the knee must first move forward faster than the
    /// hips by at least 1 body length/s, then fall back to the hips' pace. Nil without a
    /// clear swing or knee data, or when the knees sit on top of each other.
    static func kneeFollowThroughEnd(_ signals: PoseSignalSet, _ times: [Double], contactIndex c: Int, minimumSeconds: Double) -> Int? {
        let knee = signals.values(.kickingKneeForwardVelocity)
        let body = signals.values(.bodyForwardVelocity)
        let separation = signals.values(.kneeSeparation)
        guard signals.travelDirection != 0 else { return nil }
        let window = times.indices.filter { $0 >= c && times[$0] - times[c] <= 0.8 + 1e-9 }
        let relative: [Int: Double] = Dictionary(uniqueKeysWithValues: window.compactMap { i in
            guard let k = knee[i], let b = body[i] else { return nil }
            return (i, k - b)
        })
        guard Double(relative.count) >= 0.7 * Double(window.count), window.count >= 5 else { return nil }
        let collapsed = window.compactMap { separation[$0] }.filter { $0 <= ankleCollapseDistance / 2 }.count
        guard Double(collapsed) < 0.5 * Double(window.count) else { return nil }
        var swung = false
        for i in window {
            guard let r = relative[i] else { continue }
            if r >= 1.0 { swung = true }
            guard swung, times[i] - times[c] >= minimumSeconds - 1e-9, r <= 0 else { continue }
            let next = relative[i + 1]
            if next == nil || next! <= 0.3 { return i }
        }
        return nil
    }

    /// Within 0.6 s after contact the hips move backward in the frame (forward velocity
    /// below −0.5 body lengths/s) for at least 0.15 s: the camera is probably panning.
    static func cameraMotion(_ forward: [Double?], _ times: [Double], after t: Double) -> Bool {
        let after = times.indices.filter { times[$0] > t + 1e-9 && times[$0] <= t + 0.6 + 1e-9 }
        var run = 0.0
        for i in after {
            if (forward[i] ?? 0) < -0.5, i > 0 { run += times[i] - times[i - 1] } else { run = 0 }
            if run >= 0.15 - 1e-9 { return true }
        }
        return false
    }

    // MARK: Step 12C helpers

    /// Body lengths. A "plant" whose foot is further than this behind the hip at touchdown
    /// looks like push-off, so it is only an estimate.
    static let plantBehindHipLimit = -0.5

    /// The foot's furthest point ahead of the hip within 0.8 s after contact, when the foot
    /// travelled at least 0.3 body lengths further forward first (a real swing, not noise).
    static func swingApex(_ offset: [Double?], _ times: [Double], after i: Int) -> Int? {
        guard let start = offset[i] else { return nil }
        let window = times.indices.filter { $0 > i && times[$0] - times[i] <= 0.8 + 1e-9 }
        guard let highest = window.compactMap({ offset[$0] }).max(), highest - start >= 0.3 else { return nil }
        // The first sample within 0.05 body lengths of the highest point: robust to pose
        // jitter and rounding on a plateau (mirrored clips give identical results).
        guard let apex = window.first(where: { (offset[$0] ?? -.infinity) >= highest - 0.05 }) else { return nil }
        // Still rising at the window's end: not a turning point.
        guard apex != window.last else { return nil }
        return apex
    }

    /// The plant-labeled ankle moving much faster than the kicking ankle's peak around
    /// contact while the kicking ankle rests.
    static func legRoleConflict(_ signals: PoseSignalSet, _ times: [Double], contactTime: Double, kickingPeak: Double,
                                threshold: Double) -> Bool {
        let near = times.indices.filter { abs(times[$0] - contactTime) <= 0.3 + 1e-9 }
        let plant = signals.values(.plantAnkleSpeed)
        let kicking = medianFilter(signals.values(.kickingAnkleSpeed), radius: 2)
        guard let plantPeak = near.compactMap({ plant[$0] }).max() else { return false }
        let restingBefore = times.indices.filter { times[$0] >= contactTime - 0.15 - 1e-9 && times[$0] <= contactTime + 1e-9 }
            .compactMap { kicking[$0] }
        let kickingRests = !restingBefore.isEmpty && restingBefore.allSatisfy { $0 <= threshold }
        return plantPeak > 1.2 * kickingPeak && kickingRests
    }

    // MARK: Step 12B constants and helpers

    /// The still threshold may rise to this multiple of the standing-still noise floor…
    static let noiseFloorMultiplier = 3.0
    /// …but never above this (body lengths/s). A stepping foot moves several times faster.
    static let plantStillSpeedCeiling = 1.5
    /// A plant must stay still at least this long (and at least two samples).
    static let minimumStillSeconds = 0.05
    /// "Still through contact" allows the foot to start moving this long before the anchor.
    static let plantContactToleranceSeconds = 0.05
    /// Speed peak and ankle-pass cue further apart than this lower contact confidence.
    static let contactCueToleranceSeconds = 0.2
    /// A one-sample stop counts as a (brief) touchdown only when the foot slowed to this
    /// fraction of its speed in the half second before the search window.
    static let briefPlantSpeedRatio = 0.35

    /// The single slowest unfiltered plant-ankle sample in the window, when it is a clear
    /// stop: at or below the still threshold, a local minimum strictly inside the window,
    /// and far slower than the foot moved just before (so jitter on a moving foot doesn't
    /// qualify).
    /// Step 12D: every sharp one-sample stop in the window (see `briefPlant`), earliest first.
    static func briefStops(_ plant: [Double?], _ times: [Double], window: [Int], before limit: Int, stillThreshold: Double) -> [Int] {
        window.filter { j in
            guard j > (window.first ?? 0), j < limit, j + 1 < plant.count, let m = plant[j], m <= stillThreshold,
                  let a = plant[j - 1], let b = plant[j + 1], m < a, m < b else { return false }
            return isSharpStop(plant, times, at: j)
        }
    }

    /// A one-sample stop that is far slower than the foot's last 0.3 s (a step coming in)
    /// and after which the foot stays slower (it landed), so jitter on a moving foot doesn't
    /// qualify.
    static func isSharpStop(_ plant: [Double?], _ times: [Double], at j: Int) -> Bool {
        guard let m = plant[j] else { return false }
        let earlier = times.indices.filter { $0 < j && times[j] - times[$0] <= 0.3 + 1e-9 }.compactMap { plant[$0] }.sorted()
        let lastLater: Int = min(plant.count - 1, j + 3)
        guard lastLater > j else { return false }
        let laterRange: ClosedRange<Int> = (j + 1)...lastLater
        let later: [Double] = laterRange.compactMap { plant[$0] }.sorted()
        guard earlier.count >= 3, later.count >= 2 else { return false }
        let moving = earlier[earlier.count / 2]
        let after = later[later.count / 2]
        return m <= briefPlantSpeedRatio * moving && after <= 0.6 * moving
    }

    static func briefPlant(_ plant: [Double?], _ times: [Double], window: [Int], peakIndex: Int, stillThreshold: Double) -> Int? {
        guard let first = window.first,
              let j = window.filter({ plant[$0] != nil }).min(by: { plant[$0]! < plant[$1]! }),
              let m = plant[j], m <= stillThreshold, j > first, j < peakIndex,
              let before = plant[j - 1], let after = plant[j + 1], m < before, m < after else { return nil }
        // Step 12D: compared with the foot's own last step, and it must stay slower after.
        return isSharpStop(plant, times, at: j) ? j : nil
    }

    /// Noise floor needs this many standing-still samples.
    static let minimumNoiseSamples = 8

    /// Running median over each sample and its available neighbors within `radius`
    /// samples. Removes bursts of up to `radius` samples (one jittery position disturbs
    /// two central-difference speeds) while keeping steps — a foot stopping — and
    /// monotone stretches where they are. Missing samples stay missing.
    static func medianFilter(_ values: [Double?], radius: Int) -> [Double?] {
        values.indices.map { i in
            guard values[i] != nil else { return nil }
            // Symmetric window, narrowed at the ends so it stays centered.
            let r = min(radius, i, values.count - 1 - i)
            let window = (i - r...i + r).compactMap { values[$0] }.sorted()
            guard window.count >= 3 else { return values[i] }
            let mid = window.count / 2
            return window.count % 2 == 1 ? window[mid] : (window[mid - 1] + window[mid]) / 2
        }
    }

    /// Median sample rate (samples per second); 30 when unknown.
    static func framesPerSecond(_ times: [Double]) -> Double {
        var gaps: [Double] = []
        for i in times.indices.dropFirst() where times[i] > times[i - 1] { gaps.append(times[i] - times[i - 1]) }
        gaps.sort()
        return gaps.isEmpty ? 30 : 1 / gaps[gaps.count / 2]
    }

    /// Typical plant-ankle speed while the body is NOT moving (setup, after the kick): the
    /// measurement jitter of a foot that is really still.
    static func plantNoiseFloor(_ plant: [Double?], _ body: [Double?], profile: KickPhaseProfile) -> Double? {
        let quiet = plant.indices.compactMap { i -> Double? in
            guard i < body.count, let b = body[i], b < profile.approachSpeedThreshold else { return nil }
            return plant[i]
        }.sorted()
        return quiet.count >= minimumNoiseSamples ? quiet[quiet.count / 2] : nil
    }

    /// Sub-sample time of the peak from a parabola through its neighbors.
    static func refinedPeakTime(_ values: [Double?], _ times: [Double], _ i: Int) -> Double {
        guard i > 0, i + 1 < values.count, let a = values[i - 1], let b = values[i], let c = values[i + 1] else { return times[i] }
        let denominator = a - 2 * b + c
        guard denominator < 0 else { return times[i] }
        let delta = max(-0.5, min(0.5, 0.5 * (a - c) / denominator))
        let step = delta >= 0 ? times[i + 1] - times[i] : times[i] - times[i - 1]
        return times[i] + delta * step
    }

    /// When the kicking ankle crosses from behind to ahead of the plant ankle, closest to
    /// `contactTime` within −0.5…+0.3 s (linear interpolation between samples).
    static func anklePassTime(_ ahead: [Double?], _ times: [Double], near contactTime: Double) -> Double? {
        var best: Double?
        for i in times.indices.dropFirst() {
            guard times[i] >= contactTime - 0.5 - 1e-9, times[i - 1] <= contactTime + 0.3 + 1e-9,
                  let a = ahead[i - 1], let b = ahead[i], a < 0, b >= 0 else { continue }
            let t = times[i - 1] + (times[i] - times[i - 1]) * (-a / (b - a))
            if best.map({ abs(t - contactTime) < abs($0 - contactTime) }) ?? true { best = t }
        }
        return best
    }

    /// Fraction of samples within ±radius seconds of `time` that have a value.
    static func windowCoverage(_ values: [Double?], _ times: [Double], around time: Double, radius: Double) -> Double {
        let window = times.indices.filter { abs(times[$0] - time) <= radius + 1e-9 }
        guard !window.isEmpty else { return 0 }
        return Double(window.filter { values[$0] != nil }.count) / Double(window.count)
    }
}
