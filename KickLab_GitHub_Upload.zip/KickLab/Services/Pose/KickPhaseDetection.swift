import Foundation

/// The phases of a kick, in order.
enum KickPhase: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    /// Standing still before the approach.
    case setup
    /// Steps toward the ball.
    case approach
    /// The plant foot lands and stays fixed through contact.
    case plant
    /// Foot meets ball. Without ball tracking this is an ESTIMATE (peak kicking-foot speed).
    case contact
    /// The kicking leg continues after contact.
    case followThrough
}

enum PhaseDetectionStatus: String, Codable, Sendable {
    /// Found with clear evidence.
    case detected
    /// Found, but from indirect evidence or with weak support (e.g. contact without a ball).
    case estimated
    /// More than one plausible answer; the reported times are the best guess only.
    case ambiguous
    /// Not found (missing data, outside the clip, or unsupported for this kick type).
    case unavailable
}

/// One phase on the timeline. Times are seconds from the start of the analyzed video.
struct DetectedKickPhase: Codable, Equatable, Sendable {
    let phase: KickPhase
    let startTime: Double?
    let endTime: Double?
    /// The single instant that best represents the phase (e.g. plant touchdown, contact).
    let representativeTime: Double?
    /// 0...1
    let confidence: Double
    /// The signals the decision was based on.
    let evidence: [PoseSignalKey]
    let status: PhaseDetectionStatus

    static func unavailable(_ phase: KickPhase, evidence: [PoseSignalKey] = []) -> DetectedKickPhase {
        DetectedKickPhase(phase: phase, startTime: nil, endTime: nil, representativeTime: nil,
                          confidence: 0, evidence: evidence, status: .unavailable)
    }

    var isAvailable: Bool { status != .unavailable }
}

/// How well this version of KickLab understands a kick type's phases.
enum KickPhaseSupport: String, Codable, Sendable {
    case full
    /// Only some phases are detected (punts: contact and follow-through).
    case limited
    case unsupported
}

struct KickPhaseDetectionResult: Codable, Equatable, Sendable {
    let kickType: KickType
    let support: KickPhaseSupport
    /// One entry per `KickPhase`, in order.
    let phases: [DetectedKickPhase]
    /// 0...1
    let overallConfidence: Double
    /// Fraction of samples with the kicking-ankle signal.
    let dataCoverage: Double
    /// Plain-language notes for diagnostics (not coaching).
    let notes: [String]
    /// Step 12B: the evidence behind contact, plant and follow-through (nil in files
    /// written before Step 12B).
    var evidence: PhaseDetectionEvidence? = nil

    func phase(_ phase: KickPhase) -> DetectedKickPhase {
        phases.first { $0.phase == phase } ?? .unavailable(phase)
    }

    /// Plant-foot touchdown, when found.
    var plantTime: Double? {
        let plant = phase(.plant)
        return plant.isAvailable ? plant.representativeTime : nil
    }

    /// Estimated foot–ball contact, when found. Never "measured" without ball tracking.
    var estimatedContactTime: Double? {
        let contact = phase(.contact)
        return contact.isAvailable ? contact.representativeTime : nil
    }

    static func unavailable(kickType: KickType, support: KickPhaseSupport, coverage: Double, notes: [String]) -> KickPhaseDetectionResult {
        KickPhaseDetectionResult(kickType: kickType, support: support,
                                 phases: KickPhase.allCases.map { .unavailable($0) },
                                 overallConfidence: 0, dataCoverage: coverage, notes: notes)
    }
}

/// Step 12B: what the detector measured around contact. Times in seconds, speeds in
/// body lengths per second. For diagnostics and validation only; nothing here is a score.
struct PhaseDetectionEvidence: Codable, Equatable, Sendable {
    /// The contact anchor: the sample with the highest kicking-ankle speed.
    var contactPeakTime: Double?
    var contactPeakSpeed: Double?
    /// Sub-frame peak time from a parabola through the three samples around the peak.
    var refinedContactTime: Double?
    /// When the kicking ankle passed the plant ankle along the direction of travel
    /// (independent of foot speed). Nil when not seen or the direction is unknown.
    var anklePassTime: Double?
    /// refinedContactTime − anklePassTime.
    var contactCueOffset: Double?
    /// Plant-ankle speed while the athlete was standing still: the measurement noise.
    var plantNoiseFloor: Double?
    /// The plant-still threshold actually used.
    var plantStillThreshold: Double?
    /// Slowest filtered plant-ankle speed in the plant search window.
    var slowestPlantSpeedBeforeContact: Double?
    /// Filtered plant-ankle speed at the contact anchor.
    var plantSpeedAtContact: Double?
    var plantTouchdownTime: Double?
    /// True when the plant foot stayed still through contact; false when it landed but
    /// was moving again by contact; nil when no touchdown was found.
    var plantStillThroughContact: Bool?
    /// Seconds from contact until the kicking ankle slowed to the follow-through end
    /// fraction (nil when it never did before the clip ended).
    var followThroughSeconds: Double?
}

/// Thresholds per kick type. Speeds are in body lengths per second; times in seconds.
struct KickPhaseProfile: Codable, Equatable, Sendable {
    var support: KickPhaseSupport
    /// Shortest approach that counts as `.detected` (shorter → `.estimated`).
    var minimumApproachSeconds: Double
    /// Body-center speed that counts as moving.
    var approachSpeedThreshold: Double
    /// Plant-ankle speed that counts as planted (still).
    var plantStillSpeedThreshold: Double
    /// Plant touchdown is searched for within this long before contact.
    var plantMaximumLeadSeconds: Double
    /// The kicking-ankle peak must reach this speed to count as a kick.
    var contactMinimumPeakSpeed: Double
    /// A second peak at least this fraction of the highest makes contact ambiguous…
    var contactAmbiguityRatio: Double
    /// …when it is at least this far away in time.
    var contactPeakSeparationSeconds: Double
    /// Follow-through ends when kicking-ankle speed falls to this fraction of the peak.
    var followThroughEndFraction: Double
    var minimumFollowThroughSeconds: Double
    /// Stillness before the approach must last this long to report a setup phase.
    var minimumSetupSeconds: Double
    /// Below this kicking-ankle coverage nothing is detected.
    var minimumCoverage: Double

    static let placeKick = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Kickoffs: longer, faster approach.
    static let kickoff = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 1.0, approachSpeedThreshold: 1.0,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.35, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Punts: drop and swing differ from place kicks; only contact and follow-through.
    static let punt = KickPhaseProfile(
        support: .limited, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    static func `for`(_ kickType: KickType) -> KickPhaseProfile {
        switch kickType {
        case .fieldGoal, .pat: .placeKick
        case .kickoff: .kickoff
        case .punt: .punt
        case .unknown: KickPhaseProfile(
            support: .unsupported, minimumApproachSeconds: 0, approachSpeedThreshold: 0,
            plantStillSpeedThreshold: 0, plantMaximumLeadSeconds: 0, contactMinimumPeakSpeed: 0,
            contactAmbiguityRatio: 1, contactPeakSeparationSeconds: 0, followThroughEndFraction: 0,
            minimumFollowThroughSeconds: 0, minimumSetupSeconds: 0, minimumCoverage: 1
        )
        }
    }
}

/// Pure, rule-based phase detection from pose signals. Separate from signal extraction
/// so it can be tested on synthetic timelines and later replaced by a learned model.
///
/// Anchor: contact is estimated at the peak kicking-ankle speed. Plant, approach and
/// setup are found by walking BACK from contact; follow-through by walking forward.
enum KickPhaseDetector {
    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile? = nil
    ) -> KickPhaseDetectionResult {
        let profile = profile ?? .for(kickType)
        let times = signals.timestamps
        let ankle = signals.values(.kickingAnkleSpeed)
        let coverage = signals.coverage(.kickingAnkleSpeed)

        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases."])
        }

        // MARK: Contact (anchor)
        // Contact is ESTIMATED at the highest kicking-ankle speed. That is a proxy, not
        // the strike itself: the speed peak can sit a frame or two from the strike, and a
        // pose error can create a false peak. Step 12B therefore (a) repairs leg-label
        // swaps before signals are computed (`PoseLegRepair`), (b) checks the peak
        // against an independent cue — when the kicking foot passes the plant foot — and
        // (c) records the evidence so estimates can be validated against marked contact.
        guard let peakIndex = ankle.indices.filter({ ankle[$0] != nil }).max(by: { ankle[$0]! < ankle[$1]! }),
              let peak = ankle[peakIndex], peak >= profile.contactMinimumPeakSpeed
        else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["No kicking motion was found."])
        }
        let contactTime = times[peakIndex]
        var evidence = PhaseDetectionEvidence(contactPeakTime: contactTime, contactPeakSpeed: peak)
        evidence.refinedContactTime = refinedPeakTime(ankle, times, peakIndex)
        let rivals = ankle.indices.filter { i in
            guard let v = ankle[i] else { return false }
            return abs(times[i] - contactTime) >= profile.contactPeakSeparationSeconds && v >= profile.contactAmbiguityRatio * peak
        }
        let isAmbiguous = !rivals.isEmpty
        let farValues = ankle.indices.compactMap { i -> Double? in
            abs(times[i] - contactTime) >= profile.contactPeakSeparationSeconds ? ankle[i] : nil
        }
        let prominence = max(0, 1 - (farValues.max() ?? 0) / peak)
        let localCoverage = windowCoverage(ankle, times, around: contactTime, radius: 0.1)
        var notes: [String] = ["Contact is estimated from peak kicking-foot speed (no ball tracking)."]
        if isAmbiguous { notes.append("More than one kicking motion was found; phase times are uncertain.") }

        // Independent cue: the kicking foot passes the plant foot near the strike.
        var cueFactor = 1.0
        if signals.travelDirection != 0,
           let pass = anklePassTime(signals.values(.kickingAnkleAheadOfPlant), times, near: contactTime) {
            evidence.anklePassTime = pass
            let offset = (evidence.refinedContactTime ?? contactTime) - pass
            evidence.contactCueOffset = offset
            if abs(offset) > contactCueToleranceSeconds {
                cueFactor = 0.7
                notes.append(String(format: "Peak foot speed is %.2f s from when the kicking foot passes the plant foot; the contact time is uncertain.", abs(offset)))
            }
        }

        // Anything derived from an ambiguous anchor is ambiguous too.
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus {
            isAmbiguous ? .ambiguous : base
        }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }

        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: scaled((0.4 + 0.5 * prominence) * localCoverage * cueFactor),
            evidence: [.kickingAnkleSpeed], status: status(.estimated)
        )

        // MARK: Follow-through
        // Ends when kicking-ankle speed has fallen to the end fraction of the peak and
        // STAYS there for a second sample (a single low sample is not the end). The
        // follow-through does not depend on the plant.
        var followEndIndex: Int?
        let endSpeed = profile.followThroughEndFraction * peak
        for i in (peakIndex + 1)..<max(peakIndex + 1, times.count) {
            guard let v = ankle[i], v <= endSpeed else { continue }
            let confirmed = i + 1 >= times.count || (ankle[i + 1].map { $0 <= endSpeed } ?? false)
            if confirmed { followEndIndex = i; break }
        }
        let followThrough: DetectedKickPhase
        let followEnd = times[followEndIndex ?? (times.count - 1)]
        evidence.followThroughSeconds = followEndIndex.map { times[$0] - contactTime }
        if followEnd - contactTime >= profile.minimumFollowThroughSeconds {
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: followEnd, representativeTime: contactTime,
                confidence: scaled(followEndIndex == nil ? 0.4 : 0.8 * localCoverage),
                evidence: [.kickingAnkleSpeed],
                status: status(followEndIndex == nil ? .estimated : .detected)
            )
            if followEndIndex == nil { notes.append("The clip ends during the follow-through.") }
        } else {
            followThrough = .unavailable(.followThrough, evidence: [.kickingAnkleSpeed])
            if followEndIndex == nil {
                notes.append("The clip ends right after the estimated contact, so there is no follow-through to measure.")
            } else {
                notes.append(String(format: "The kicking foot slowed to %d%% of its peak speed only %.2f s after the speed peak — too soon for a follow-through, so the peak may not be the strike.",
                                    Int((profile.followThroughEndFraction * 100).rounded()), followEnd - contactTime))
            }
        }

        guard profile.support == .full else {
            notes.append("Only contact and follow-through are detected for this kick type.")
            let phases = [DetectedKickPhase.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough]
            return finish(kickType, profile, phases, coverage, notes, evidence)
        }

        // MARK: Plant
        // Step 12B: the plant is the plant foot COMING TO REST before contact, found in a
        // filtered signal, with a still threshold that rises above the profile's only when
        // the athlete's own standing-still jitter demands it (bounded). Whether the foot
        // then STAYED still through contact is reported separately: an unstable plant is
        // still a plant (estimated, lower confidence), and plant-foot drift is measured by
        // its own metric. Before Step 12B a single sample at the speed peak decided.
        let plantSpeed = medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let bodySpeed = signals.values(.bodyCenterSpeed)
        let noiseFloor = plantNoiseFloor(plantSpeed, bodySpeed, times, contactTime: contactTime, profile: profile)
        var stillThreshold = profile.plantStillSpeedThreshold
        if let noiseFloor, noiseFloorMultiplier * noiseFloor > stillThreshold {
            stillThreshold = min(noiseFloorMultiplier * noiseFloor, plantStillSpeedCeiling)
            notes.append(String(format: "Pose jitter while standing still (%.2f body lengths/s) raised the plant-still threshold to %.2f.", noiseFloor, stillThreshold))
        }
        evidence.plantNoiseFloor = noiseFloor
        evidence.plantStillThreshold = stillThreshold
        evidence.plantSpeedAtContact = plantSpeed[peakIndex]
        let window = times.indices.filter { $0 <= peakIndex && contactTime - times[$0] <= profile.plantMaximumLeadSeconds + 1e-9 }
        evidence.slowestPlantSpeedBeforeContact = window.compactMap { plantSpeed[$0] }.min()
        let isStill = { (i: Int) -> Bool in plantSpeed[i].map { $0 <= stillThreshold } ?? false }
        let minimumRun = max(2, Int((minimumStillSeconds * framesPerSecond(times)).rounded(.up)))

        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantIndex: Int?
        // The still run that ends closest to contact.
        var best: ClosedRange<Int>?
        var runStart: Int?
        for i in window {
            if isStill(i) {
                if runStart == nil { runStart = i }
                if let start = runStart, i - start + 1 >= minimumRun { best = start...i }
            } else {
                runStart = nil
            }
        }
        if let run = best {
            let start = run.lowerBound
            // Still before the window began: touchdown is earlier than we looked.
            let clipped = start == window.first && start > 0 && isStill(start - 1)
            let interrupted = start > 0 && plantSpeed[start - 1] == nil
            let throughContact = times[run.upperBound] >= contactTime - plantContactToleranceSeconds - 1e-9
            plantIndex = start
            evidence.plantTouchdownTime = times[start]
            evidence.plantStillThroughContact = throughContact
            let base: PhaseDetectionStatus = (clipped || interrupted || !throughContact) ? .estimated : .detected
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[start], radius: 0.1)
            let strength = base == .detected ? 0.85 : (throughContact ? 0.5 : 0.4)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[start], endTime: contactTime, representativeTime: times[start],
                confidence: scaled(strength * plantCoverage),
                evidence: [.plantAnkleSpeed, .kickingAnkleSpeed], status: status(base)
            )
            if !throughContact {
                notes.append(String(format: "The plant foot came to rest at %.2f s but was moving again by the estimated contact (%.2f body lengths/s): an unstable plant, or the contact estimate is off.",
                                    times[start], plantSpeed[peakIndex] ?? .nan))
            }
        } else if let brief = briefPlant(signals.values(.plantAnkleSpeed), times, window: window, peakIndex: peakIndex,
                                         stillThreshold: stillThreshold) {
            // A sharp stop that lasted a single sample at this frame rate, then motion
            // again before contact: the touchdown is identifiable, the plant unstable.
            plantIndex = brief
            evidence.plantTouchdownTime = times[brief]
            evidence.plantStillThroughContact = false
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[brief], radius: 0.1)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[brief], endTime: contactTime, representativeTime: times[brief],
                confidence: scaled(0.3 * plantCoverage),
                evidence: [.plantAnkleSpeed, .kickingAnkleSpeed], status: status(.estimated)
            )
            notes.append(String(format: "The plant foot stopped sharply at %.2f s but only for one frame, and was moving again by the estimated contact: an unstable plant (a higher frame rate would show it better).",
                                times[brief]))
        } else {
            let slowest = evidence.slowestPlantSpeedBeforeContact
            notes.append(slowest.map {
                String(format: "The plant foot never came to rest in the %.1f s before the estimated contact (slowest %.2f body lengths/s; still means ≤ %.2f).",
                       profile.plantMaximumLeadSeconds, $0, stillThreshold)
            } ?? "The plant ankle wasn't visible before the estimated contact.")
        }

        // MARK: Approach
        var approach = DetectedKickPhase.unavailable(.approach, evidence: [.bodyCenterSpeed])
        var approachStartIndex: Int?
        let approachEndIndex = plantIndex ?? peakIndex
        // The last moving sample at or shortly before plant (bodies slow as they plant).
        let moving = { (i: Int) -> Bool in (bodySpeed[i] ?? 0) >= profile.approachSpeedThreshold }
        if let last = stride(from: approachEndIndex, through: 0, by: -1)
            .first(where: { times[approachEndIndex] - times[$0] <= 0.3 && moving($0) }) {
            var start = last
            while start > 0, moving(start - 1) { start -= 1 }
            approachStartIndex = start
            let duration = times[approachEndIndex] - times[start]
            let longEnough = duration >= profile.minimumApproachSeconds
            if !longEnough { notes.append("The approach was shorter than expected for this kick type.") }
            let reachesStart = start == 0
            if reachesStart { notes.append("The clip starts during the approach.") }
            let base: PhaseDetectionStatus = (longEnough && !reachesStart && plantIndex != nil) ? .detected : .estimated
            approach = DetectedKickPhase(
                phase: .approach, startTime: times[start], endTime: times[approachEndIndex],
                representativeTime: times[start],
                confidence: scaled(base == .detected ? 0.8 : 0.4),
                evidence: [.bodyCenterSpeed, .bodyForwardVelocity], status: status(base)
            )
        }

        // MARK: Setup
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.bodyCenterSpeed])
        if let approachStart = approachStartIndex, approachStart > 0,
           times[approachStart] - times[0] >= profile.minimumSetupSeconds {
            let window = 0..<approachStart
            let known = window.filter { bodySpeed[$0] != nil }
            let still = known.filter { !moving($0) }
            let fraction = known.isEmpty ? 0 : Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(
                    phase: .setup, startTime: times[0], endTime: times[approachStart], representativeTime: times[0],
                    confidence: scaled(0.7 * fraction), evidence: [.bodyCenterSpeed],
                    status: status(fraction >= 0.8 ? .detected : .estimated)
                )
            }
        }

        return finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes, evidence)
    }

    private static func finish(
        _ kickType: KickType,
        _ profile: KickPhaseProfile,
        _ phases: [DetectedKickPhase],
        _ coverage: Double,
        _ notes: [String],
        _ evidence: PhaseDetectionEvidence
    ) -> KickPhaseDetectionResult {
        let found = phases.filter(\.isAvailable)
        let mean = found.isEmpty ? 0 : found.map(\.confidence).reduce(0, +) / Double(found.count)
        return KickPhaseDetectionResult(kickType: kickType, support: profile.support, phases: phases,
                                        overallConfidence: min(1, mean * coverage), dataCoverage: coverage, notes: notes,
                                        evidence: evidence)
    }

    // MARK: Step 12B constants and helpers

    /// The still threshold may rise to this multiple of the standing-still noise floor…
    static let noiseFloorMultiplier = 3.0
    /// …but never above this (body lengths/s). A stepping foot moves several times faster.
    static let plantStillSpeedCeiling = 1.5
    /// A plant must stay still at least this long (and at least two samples).
    static let minimumStillSeconds = 0.05
    /// "Still through contact" allows the foot to start moving this long before the anchor.
    static let plantContactToleranceSeconds = 0.05
    /// Speed peak and ankle-pass cue further apart than this lower contact confidence.
    static let contactCueToleranceSeconds = 0.2
    /// A one-sample stop counts as a (brief) touchdown only when the foot slowed to this
    /// fraction of its speed in the half second before the search window.
    static let briefPlantSpeedRatio = 0.35

    /// The single slowest unfiltered plant-ankle sample in the window, when it is a clear
    /// stop: at or below the still threshold, a local minimum strictly inside the window,
    /// and far slower than the foot moved just before (so jitter on a moving foot doesn't
    /// qualify).
    static func briefPlant(_ plant: [Double?], _ times: [Double], window: [Int], peakIndex: Int, stillThreshold: Double) -> Int? {
        guard let first = window.first,
              let j = window.filter({ plant[$0] != nil }).min(by: { plant[$0]! < plant[$1]! }),
              let m = plant[j], m <= stillThreshold, j > first, j < peakIndex,
              let before = plant[j - 1], let after = plant[j + 1], m < before, m < after else { return nil }
        let earlier = times.indices.filter { times[$0] < times[first] && times[first] - times[$0] <= 0.5 + 1e-9 }
            .compactMap { plant[$0] }.sorted()
        guard earlier.count >= 3 else { return nil }
        let moving = earlier[earlier.count / 2]
        return m <= briefPlantSpeedRatio * moving ? j : nil
    }

    /// Noise floor needs this many standing-still samples.
    static let minimumNoiseSamples = 8

    /// Running median over each sample and its available neighbors within `radius`
    /// samples. Removes bursts of up to `radius` samples (one jittery position disturbs
    /// two central-difference speeds) while keeping steps — a foot stopping — and
    /// monotone stretches where they are. Missing samples stay missing.
    static func medianFilter(_ values: [Double?], radius: Int) -> [Double?] {
        values.indices.map { i in
            guard values[i] != nil else { return nil }
            // Symmetric window, narrowed at the ends so it stays centered.
            let r = min(radius, i, values.count - 1 - i)
            let window = (i - r...i + r).compactMap { values[$0] }.sorted()
            guard window.count >= 3 else { return values[i] }
            let mid = window.count / 2
            return window.count % 2 == 1 ? window[mid] : (window[mid - 1] + window[mid]) / 2
        }
    }

    /// Median sample rate (samples per second); 30 when unknown.
    static func framesPerSecond(_ times: [Double]) -> Double {
        var gaps: [Double] = []
        for i in times.indices.dropFirst() where times[i] > times[i - 1] { gaps.append(times[i] - times[i - 1]) }
        gaps.sort()
        return gaps.isEmpty ? 30 : 1 / gaps[gaps.count / 2]
    }

    /// Typical plant-ankle speed while the body is NOT moving (setup, after the kick),
    /// away from contact: the measurement jitter of a foot that is really still.
    static func plantNoiseFloor(_ plant: [Double?], _ body: [Double?], _ times: [Double], contactTime: Double,
                                profile: KickPhaseProfile) -> Double? {
        let quiet = times.indices.compactMap { i -> Double? in
            guard abs(times[i] - contactTime) > 0.5, let b = body[i], b < profile.approachSpeedThreshold else { return nil }
            return plant[i]
        }.sorted()
        return quiet.count >= minimumNoiseSamples ? quiet[quiet.count / 2] : nil
    }

    /// Sub-sample time of the peak from a parabola through its neighbors.
    static func refinedPeakTime(_ values: [Double?], _ times: [Double], _ i: Int) -> Double {
        guard i > 0, i + 1 < values.count, let a = values[i - 1], let b = values[i], let c = values[i + 1] else { return times[i] }
        let denominator = a - 2 * b + c
        guard denominator < 0 else { return times[i] }
        let delta = max(-0.5, min(0.5, 0.5 * (a - c) / denominator))
        let step = delta >= 0 ? times[i + 1] - times[i] : times[i] - times[i - 1]
        return times[i] + delta * step
    }

    /// When the kicking ankle crosses from behind to ahead of the plant ankle, closest to
    /// `contactTime` within −0.5…+0.3 s (linear interpolation between samples).
    static func anklePassTime(_ ahead: [Double?], _ times: [Double], near contactTime: Double) -> Double? {
        var best: Double?
        for i in times.indices.dropFirst() {
            guard times[i] >= contactTime - 0.5 - 1e-9, times[i - 1] <= contactTime + 0.3 + 1e-9,
                  let a = ahead[i - 1], let b = ahead[i], a < 0, b >= 0 else { continue }
            let t = times[i - 1] + (times[i] - times[i - 1]) * (-a / (b - a))
            if best.map({ abs(t - contactTime) < abs($0 - contactTime) }) ?? true { best = t }
        }
        return best
    }

    /// Fraction of samples within ±radius seconds of `time` that have a value.
    static func windowCoverage(_ values: [Double?], _ times: [Double], around time: Double, radius: Double) -> Double {
        let window = times.indices.filter { abs(times[$0] - time) <= radius + 1e-9 }
        guard !window.isEmpty else { return 0 }
        return Double(window.filter { values[$0] != nil }.count) / Double(window.count)
    }
}
