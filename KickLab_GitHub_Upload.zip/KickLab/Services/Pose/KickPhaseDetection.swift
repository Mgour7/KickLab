import Foundation

/// The phases of a kick, in order.
enum KickPhase: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    /// Standing still before the approach.
    case setup
    /// Steps toward the ball.
    case approach
    /// The plant foot lands and stays fixed through contact.
    case plant
    /// Foot meets ball. Without ball tracking this is an ESTIMATE (peak kicking-foot speed).
    case contact
    /// The kicking leg continues after contact.
    case followThrough
}

enum PhaseDetectionStatus: String, Codable, Sendable {
    /// Found with clear evidence.
    case detected
    /// Found, but from indirect evidence or with weak support (e.g. contact without a ball).
    case estimated
    /// More than one plausible answer; the reported times are the best guess only.
    case ambiguous
    /// Not found (missing data, outside the clip, or unsupported for this kick type).
    case unavailable
}

/// One phase on the timeline. Times are seconds from the start of the analyzed video.
struct DetectedKickPhase: Codable, Equatable, Sendable {
    let phase: KickPhase
    let startTime: Double?
    let endTime: Double?
    /// The single instant that best represents the phase (e.g. plant touchdown, contact).
    let representativeTime: Double?
    /// 0...1
    let confidence: Double
    /// The signals the decision was based on.
    let evidence: [PoseSignalKey]
    let status: PhaseDetectionStatus

    static func unavailable(_ phase: KickPhase, evidence: [PoseSignalKey] = []) -> DetectedKickPhase {
        DetectedKickPhase(phase: phase, startTime: nil, endTime: nil, representativeTime: nil,
                          confidence: 0, evidence: evidence, status: .unavailable)
    }

    var isAvailable: Bool { status != .unavailable }
}

/// How well this version of KickLab understands a kick type's phases.
enum KickPhaseSupport: String, Codable, Sendable {
    case full
    /// Only some phases are detected (punts: contact and follow-through).
    case limited
    case unsupported
}

struct KickPhaseDetectionResult: Codable, Equatable, Sendable {
    let kickType: KickType
    let support: KickPhaseSupport
    /// One entry per `KickPhase`, in order.
    let phases: [DetectedKickPhase]
    /// 0...1
    let overallConfidence: Double
    /// Fraction of samples with the kicking-ankle signal.
    let dataCoverage: Double
    /// Plain-language notes for diagnostics (not coaching).
    let notes: [String]

    func phase(_ phase: KickPhase) -> DetectedKickPhase {
        phases.first { $0.phase == phase } ?? .unavailable(phase)
    }

    /// Plant-foot touchdown, when found.
    var plantTime: Double? {
        let plant = phase(.plant)
        return plant.isAvailable ? plant.representativeTime : nil
    }

    /// Estimated foot–ball contact, when found. Never "measured" without ball tracking.
    var estimatedContactTime: Double? {
        let contact = phase(.contact)
        return contact.isAvailable ? contact.representativeTime : nil
    }

    static func unavailable(kickType: KickType, support: KickPhaseSupport, coverage: Double, notes: [String]) -> KickPhaseDetectionResult {
        KickPhaseDetectionResult(kickType: kickType, support: support,
                                 phases: KickPhase.allCases.map { .unavailable($0) },
                                 overallConfidence: 0, dataCoverage: coverage, notes: notes)
    }
}

/// Thresholds per kick type. Speeds are in body lengths per second; times in seconds.
struct KickPhaseProfile: Codable, Equatable, Sendable {
    var support: KickPhaseSupport
    /// Shortest approach that counts as `.detected` (shorter → `.estimated`).
    var minimumApproachSeconds: Double
    /// Body-center speed that counts as moving.
    var approachSpeedThreshold: Double
    /// Plant-ankle speed that counts as planted (still).
    var plantStillSpeedThreshold: Double
    /// Plant touchdown is searched for within this long before contact.
    var plantMaximumLeadSeconds: Double
    /// The kicking-ankle peak must reach this speed to count as a kick.
    var contactMinimumPeakSpeed: Double
    /// A second peak at least this fraction of the highest makes contact ambiguous…
    var contactAmbiguityRatio: Double
    /// …when it is at least this far away in time.
    var contactPeakSeparationSeconds: Double
    /// Follow-through ends when kicking-ankle speed falls to this fraction of the peak.
    var followThroughEndFraction: Double
    var minimumFollowThroughSeconds: Double
    /// Stillness before the approach must last this long to report a setup phase.
    var minimumSetupSeconds: Double
    /// Below this kicking-ankle coverage nothing is detected.
    var minimumCoverage: Double

    static let placeKick = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Kickoffs: longer, faster approach.
    static let kickoff = KickPhaseProfile(
        support: .full, minimumApproachSeconds: 1.0, approachSpeedThreshold: 1.0,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.35, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    /// Punts: drop and swing differ from place kicks; only contact and follow-through.
    static let punt = KickPhaseProfile(
        support: .limited, minimumApproachSeconds: 0.25, approachSpeedThreshold: 0.6,
        plantStillSpeedThreshold: 1.0, plantMaximumLeadSeconds: 0.4, contactMinimumPeakSpeed: 3.0,
        contactAmbiguityRatio: 0.85, contactPeakSeparationSeconds: 0.25, followThroughEndFraction: 0.25,
        minimumFollowThroughSeconds: 0.1, minimumSetupSeconds: 0.2, minimumCoverage: 0.5
    )

    static func `for`(_ kickType: KickType) -> KickPhaseProfile {
        switch kickType {
        case .fieldGoal, .pat: .placeKick
        case .kickoff: .kickoff
        case .punt: .punt
        case .unknown: KickPhaseProfile(
            support: .unsupported, minimumApproachSeconds: 0, approachSpeedThreshold: 0,
            plantStillSpeedThreshold: 0, plantMaximumLeadSeconds: 0, contactMinimumPeakSpeed: 0,
            contactAmbiguityRatio: 1, contactPeakSeparationSeconds: 0, followThroughEndFraction: 0,
            minimumFollowThroughSeconds: 0, minimumSetupSeconds: 0, minimumCoverage: 1
        )
        }
    }
}

/// Pure, rule-based phase detection from pose signals. Separate from signal extraction
/// so it can be tested on synthetic timelines and later replaced by a learned model.
///
/// Anchor: contact is estimated at the peak kicking-ankle speed. Plant, approach and
/// setup are found by walking BACK from contact; follow-through by walking forward.
enum KickPhaseDetector {
    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile? = nil
    ) -> KickPhaseDetectionResult {
        let profile = profile ?? .for(kickType)
        let times = signals.timestamps
        let ankle = signals.values(.kickingAnkleSpeed)
        let coverage = signals.coverage(.kickingAnkleSpeed)

        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases."])
        }

        // MARK: Contact (anchor)
        guard let peakIndex = ankle.indices.filter({ ankle[$0] != nil }).max(by: { ankle[$0]! < ankle[$1]! }),
              let peak = ankle[peakIndex], peak >= profile.contactMinimumPeakSpeed
        else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["No kicking motion was found."])
        }
        let contactTime = times[peakIndex]
        let rivals = ankle.indices.filter { i in
            guard let v = ankle[i] else { return false }
            return abs(times[i] - contactTime) >= profile.contactPeakSeparationSeconds && v >= profile.contactAmbiguityRatio * peak
        }
        let isAmbiguous = !rivals.isEmpty
        let farValues = ankle.indices.compactMap { i -> Double? in
            abs(times[i] - contactTime) >= profile.contactPeakSeparationSeconds ? ankle[i] : nil
        }
        let prominence = max(0, 1 - (farValues.max() ?? 0) / peak)
        let localCoverage = windowCoverage(ankle, times, around: contactTime, radius: 0.1)
        var notes: [String] = ["Contact is estimated from peak kicking-foot speed (no ball tracking)."]
        if isAmbiguous { notes.append("More than one kicking motion was found; phase times are uncertain.") }

        // Anything derived from an ambiguous anchor is ambiguous too.
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus {
            isAmbiguous ? .ambiguous : base
        }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }

        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: scaled((0.4 + 0.5 * prominence) * localCoverage),
            evidence: [.kickingAnkleSpeed], status: status(.estimated)
        )

        // MARK: Follow-through
        var followEndIndex: Int?
        for i in peakIndex..<times.count {
            if let v = ankle[i], v <= profile.followThroughEndFraction * peak { followEndIndex = i; break }
        }
        let followThrough: DetectedKickPhase
        let followEnd = times[followEndIndex ?? (times.count - 1)]
        if followEnd - contactTime >= profile.minimumFollowThroughSeconds {
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: followEnd, representativeTime: contactTime,
                confidence: scaled(followEndIndex == nil ? 0.4 : 0.8 * localCoverage),
                evidence: [.kickingAnkleSpeed],
                status: status(followEndIndex == nil ? .estimated : .detected)
            )
            if followEndIndex == nil { notes.append("The clip ends during the follow-through.") }
        } else {
            followThrough = .unavailable(.followThrough, evidence: [.kickingAnkleSpeed])
        }

        guard profile.support == .full else {
            notes.append("Only contact and follow-through are detected for this kick type.")
            let phases = [DetectedKickPhase.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough]
            return finish(kickType, profile, phases, coverage, notes)
        }

        // MARK: Plant
        let plantSpeed = signals.values(.plantAnkleSpeed)
        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantIndex: Int?
        if let still = plantSpeed[peakIndex], still <= profile.plantStillSpeedThreshold {
            var start = peakIndex
            while start > 0,
                  contactTime - times[start - 1] <= profile.plantMaximumLeadSeconds + 1e-9,
                  let v = plantSpeed[start - 1], v <= profile.plantStillSpeedThreshold {
                start -= 1
            }
            // If the foot was already still at the edge of the search window, touchdown is
            // earlier than we looked: report it, but only as an estimate.
            let clipped = start > 0
                && contactTime - times[start - 1] > profile.plantMaximumLeadSeconds + 1e-9
                && (plantSpeed[start - 1].map { $0 <= profile.plantStillSpeedThreshold } ?? false)
            let interrupted = start > 0 && plantSpeed[start - 1] == nil
            plantIndex = start
            let base: PhaseDetectionStatus = (clipped || interrupted) ? .estimated : .detected
            let plantCoverage = windowCoverage(plantSpeed, times, around: times[start], radius: 0.1)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[start], endTime: contactTime, representativeTime: times[start],
                confidence: scaled((base == .detected ? 0.85 : 0.5) * plantCoverage),
                evidence: [.plantAnkleSpeed, .kickingAnkleSpeed], status: status(base)
            )
        } else {
            notes.append("The plant foot was not still at contact.")
        }

        // MARK: Approach
        let bodySpeed = signals.values(.bodyCenterSpeed)
        var approach = DetectedKickPhase.unavailable(.approach, evidence: [.bodyCenterSpeed])
        var approachStartIndex: Int?
        let approachEndIndex = plantIndex ?? peakIndex
        // The last moving sample at or shortly before plant (bodies slow as they plant).
        let moving = { (i: Int) -> Bool in (bodySpeed[i] ?? 0) >= profile.approachSpeedThreshold }
        if let last = stride(from: approachEndIndex, through: 0, by: -1)
            .first(where: { times[approachEndIndex] - times[$0] <= 0.3 && moving($0) }) {
            var start = last
            while start > 0, moving(start - 1) { start -= 1 }
            approachStartIndex = start
            let duration = times[approachEndIndex] - times[start]
            let longEnough = duration >= profile.minimumApproachSeconds
            if !longEnough { notes.append("The approach was shorter than expected for this kick type.") }
            let reachesStart = start == 0
            if reachesStart { notes.append("The clip starts during the approach.") }
            let base: PhaseDetectionStatus = (longEnough && !reachesStart && plantIndex != nil) ? .detected : .estimated
            approach = DetectedKickPhase(
                phase: .approach, startTime: times[start], endTime: times[approachEndIndex],
                representativeTime: times[start],
                confidence: scaled(base == .detected ? 0.8 : 0.4),
                evidence: [.bodyCenterSpeed, .bodyForwardVelocity], status: status(base)
            )
        }

        // MARK: Setup
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.bodyCenterSpeed])
        if let approachStart = approachStartIndex, approachStart > 0,
           times[approachStart] - times[0] >= profile.minimumSetupSeconds {
            let window = 0..<approachStart
            let known = window.filter { bodySpeed[$0] != nil }
            let still = known.filter { !moving($0) }
            let fraction = known.isEmpty ? 0 : Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(
                    phase: .setup, startTime: times[0], endTime: times[approachStart], representativeTime: times[0],
                    confidence: scaled(0.7 * fraction), evidence: [.bodyCenterSpeed],
                    status: status(fraction >= 0.8 ? .detected : .estimated)
                )
            }
        }

        return finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes)
    }

    private static func finish(
        _ kickType: KickType,
        _ profile: KickPhaseProfile,
        _ phases: [DetectedKickPhase],
        _ coverage: Double,
        _ notes: [String]
    ) -> KickPhaseDetectionResult {
        let found = phases.filter(\.isAvailable)
        let mean = found.isEmpty ? 0 : found.map(\.confidence).reduce(0, +) / Double(found.count)
        return KickPhaseDetectionResult(kickType: kickType, support: profile.support, phases: phases,
                                        overallConfidence: min(1, mean * coverage), dataCoverage: coverage, notes: notes)
    }

    /// Fraction of samples within ±radius seconds of `time` that have a value.
    static func windowCoverage(_ values: [Double?], _ times: [Double], around time: Double, radius: Double) -> Double {
        let window = times.indices.filter { abs(times[$0] - time) <= radius + 1e-9 }
        guard !window.isEmpty else { return 0 }
        return Double(window.filter { values[$0] != nil }.count) / Double(window.count)
    }
}
