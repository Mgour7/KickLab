import Foundation

/// Step 12E: kick phases in a DEPTH view — filmed from behind the kicker (running
/// away from the camera) or in front (running toward it).
///
/// Nothing here uses horizontal image motion as "forward". depth-view-2 (Step 12E) was
/// rebuilt on the REAL rear-view clip from TestFlight build 10, where depth-view-1's
/// single rule ("contact = the bottom of a ≥ 0.5 torso-length heel arc") found nothing:
/// - kick window and approach: the perspective approach rate (apparent size changing),
///   and a backswing in its strike interval;
/// - plant: the plant leg's final swing visibly stops while the run-up brakes, found
///   before and independently of contact (a user contact only bounds the search);
/// - contact (Step 12F, contact-intelligence-3, `ContactIntelligence`): the earliest frame
///   inside the kicking knee's drive that the independent trunk-lean evidence also
///   supports, reported as an interval; NOT established when the groups disagree or two
///   drives compete. (depth-view-2's five-cue frame turned out to be the post-contact
///   swing on the real rear clip; `contactCues` keeps that rule for comparison only.)
/// - follow-through: the kicking foot keeps moving after contact and then settles (it
///   needn't rise); recovery follows.
/// Contact is never "detected" without ball tracking, and never above 0.6 confidence.
enum DepthViewPhaseDetector {
    static let algorithmVersion = ContactIntelligence.version
    static let maximumContactConfidence = 0.6

    /// Engine 2.8.1: the plant must land within this many seconds before the ball's
    /// departure (longer gaps are a run-up stride, not this kick's plant; both real rear
    /// clips measured 0.13 s).
    static let maximumPlantLeadSeconds = 0.35

    /// Engine 2.8.1: was the kicking foot swinging when the ball left? Its fastest speed
    /// from two frames before the last resting frame to one frame after the first movement,
    /// against its fastest anywhere in the kick window's strike interval.
    static let footSupportRatio = 0.5

    static func kickingFootAtBall(_ ball: AutomaticBallContact, signals: PoseSignalSet, times: [Double], window: KickWindow,
                                  frame: Double, stillThreshold: Double) -> (supports: Bool, ratio: Double?, note: String) {
        let speed = signals.values(.kickingAnkleSpeed)
        let near = times.indices.filter { times[$0] >= ball.lastStationaryTime - 2 * frame - 1e-9 && times[$0] <= ball.firstMovementTime + frame + 1e-9 }
        let strike = times.indices.filter { times[$0] >= window.strikeStart - 0.2 && times[$0] <= window.strikeEnd + 0.5 }
            + near
        guard let atBall = near.compactMap({ speed[$0] }).max(), let peak = strike.compactMap({ speed[$0] }).max(), peak > 0 else {
            return (false, nil, "The kicking foot wasn't tracked when the ball left, so the ball's movement can't be tied to the kick.")
        }
        let ratio = atBall / peak
        let supports = ratio >= footSupportRatio && atBall >= 2 * stillThreshold
        return (supports, ratio, supports
            ? String(format: "The kicking foot was swinging when the ball left (%.0f%% of its strike speed).", ratio * 100)
            : String(format: "The ball left at %.3f s, but the kicking foot wasn't swinging then (%.0f%% of its strike speed): the ball's movement isn't tied to this kick.",
                     ball.firstMovementTime, ratio * 100))
    }

    /// Step 12G: checks the football detector's contact bounds against the pose evidence.
    /// Resolved (index and the possible-contact frames) only when they agree and the
    /// interval is within `ContactTimingCheck.toleranceSeconds` either side.
    static func ballContact(_ ball: AutomaticBallContact, times: [Double], poseBounds: ClosedRange<Double>)
        -> (evidence: BallContactEvidence, resolved: (index: Int, earliest: Int, latest: Int)?) {
        // Engine 2.8.1: the last frame the ball still looks at rest stays a possible contact
        // frame (the foot can already be on a ball that hasn't visibly moved yet), so two
        // adjacent frames are a two-frame interval, never a single verified frame.
        let candidates = times.indices.filter { times[$0] >= ball.lastStationaryTime - 1e-6 && times[$0] <= ball.firstMovementTime + 1e-6 }
        var e = BallContactEvidence(outcome: .consistent, detectorName: ball.detectorName, framesExamined: ball.framesExamined,
                                    framesWithBall: ball.framesWithBall, lastStationaryTime: ball.lastStationaryTime,
                                    firstDisplacementTime: ball.firstMovementTime, proximityStartTime: nil, proximityEndTime: nil,
                                    contactEarliestTime: ball.lastStationaryTime, contactLatestTime: ball.firstMovementTime, note: "")
        let overlaps = max(poseBounds.lowerBound, ball.lastStationaryTime) <= min(poseBounds.upperBound, ball.firstMovementTime) + 1e-9
        guard overlaps else {
            e.outcome = .conflicting
            e.note = String(format: "The football detector saw the ball leave between %.3f and %.3f s, outside the body-pose strike (%.3f–%.3f s).",
                            ball.lastStationaryTime, ball.firstMovementTime, poseBounds.lowerBound, poseBounds.upperBound)
            return (e, nil)
        }
        guard let lo = candidates.first, let hi = candidates.last else {
            e.outcome = .unreliable
            e.note = "No analyzed frame falls between the ball's last resting frame and its first movement."
            return (e, nil)
        }
        let half = (ball.firstMovementTime - ball.lastStationaryTime) / 2
        guard half <= ContactTimingCheck.toleranceSeconds + 1e-9 else {
            e.note = String(format: "The ball rested until %.3f s and was moving by %.3f s — too wide (±%.3f s) to time contact; the pose answer is kept.",
                            ball.lastStationaryTime, ball.firstMovementTime, half)
            return (e, nil)
        }
        e.note = String(format: "The ball rested until %.3f s and was first seen moving at %.3f s, agreeing with the body-pose strike.",
                        ball.lastStationaryTime, ball.firstMovementTime)
        // The middle candidate (the earlier one of two): the frames can't say more.
        return (e, (candidates[(candidates.count - 1) / 2], lo, hi))
    }

    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile,
        perspective: CameraPerspective,
        assistance: PhaseDetectionAssistance?,
        ballContact: AutomaticBallContact? = nil
    ) -> KickPhaseDetectionResult {
        let times = signals.timestamps
        let lift = KickPhaseDetector.medianFilter(signals.values(.kickingAnkleLift), radius: 1)
        let coverage = signals.coverage(.kickingAnkleLift)
        let view = perspective == .depthAway ? "from behind the kicker" : "from in front of the kicker"
        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases (filmed \(view))."])
        }
        let fps = KickPhaseDetector.framesPerSecond(times)
        let frame = 1 / fps

        // MARK: Kick window
        var windows = KickWindowDetector.detectDepthView(signals, profile: profile, restrictTo: assistance?.window)
        if let range = assistance?.window, windows.selected == nil {
            windows = KickWindowAnalysis(windows: [KickWindowDetector.userWindow(range, signals: signals)], selectedIndex: 0,
                                         needsSelection: false, notes: ["Analyzing the interval chosen by the user."])
        }
        if assistance?.window != nil, windows.needsSelection {
            windows.needsSelection = false
            windows.notes.append("The user chose this interval; other kicks in it were not analyzed separately.")
        }
        var notes: [String] = ["Filmed \(view): phases come from the kicker's apparent size (run-up), the plant foot coming to rest, and the kicking leg's vertical swing in the image. Side-view measurements are not made."]
        notes.append(contentsOf: windows.notes)
        var evidence = PhaseDetectionEvidence(contactPeakTime: nil, contactPeakSpeed: nil)
        evidence.algorithmVersion = algorithmVersion
        // A user-chosen contact frame stands even when no swing was seen around it.
        if windows.selected == nil, let t = assistance?.effectiveContactTime {
            windows = KickWindowAnalysis(windows: [KickWindowDetector.userWindow((t - 0.8)...(t + 0.8), signals: signals)], selectedIndex: 0,
                                         needsSelection: false, notes: ["Analyzing around the contact frame chosen by the user."])
        }
        // Build 15: no run-up was seen (the clip starts at the kick, or the approach is cut
        // off), but the football detector saw the kicked ball leave. The window is anchored
        // on the ball's departure — automatic, labelled "ballAnchored" — only when the
        // kicking foot was visibly swinging as the ball left; otherwise nothing is invented.
        var ballAnchoredNote: String?
        if windows.selected == nil, assistance?.isEmpty != false, let ball = ballContact {
            var w = KickWindowDetector.userWindow((ball.firstMovementTime - 0.8)...(ball.firstMovementTime + 0.8), signals: signals)
            w.source = "ballAnchored"
            w.confidence = 0.4
            w.uncertaintyReasons = ["no run-up was seen; the window is anchored on the football's departure"]
            let foot = kickingFootAtBall(ball, signals: signals, times: times, window: w, frame: frame,
                                         stillThreshold: KickPhaseDetector.stillThreshold(signals, profile: profile))
            if foot.supports {
                windows = KickWindowAnalysis(windows: [w] + windows.windows, selectedIndex: 0, needsSelection: false,
                                             notes: windows.notes + ["No run-up was found; the kick was located from the football leaving its spot (the kicking foot was swinging then)."])
                ballAnchoredNote = "Kick window anchored on the football's departure (no run-up seen)."
            } else {
                notes.append("No run-up was found, and the football's departure couldn't be tied to a kicking-foot swing: " + foot.note)
            }
        }
        if let n = ballAnchoredNote { notes.append(n) }
        guard let kickWindow = windows.selected else {
            var result = KickPhaseDetectionResult.unavailable(
                kickType: kickType, support: profile.support, coverage: coverage,
                notes: notes + ["No kick was found: no run-up followed by a backswing of the kicking leg."]
            )
            result.evidence = evidence
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }

        // MARK: Plant landing (found before, and independent of, contact)
        // depth-view-2: the plant leg's final swing visibly stops AND the run-up brakes.
        // A user-chosen contact only limits the search to frames before it.
        let stillThreshold = KickPhaseDetector.stillThreshold(signals, profile: profile)
        evidence.plantStillThreshold = stillThreshold
        let userContact = assistance?.effectiveContactTime.flatMap { t in times.indices.min { abs(times[$0] - t) < abs(times[$1] - t) } }
        var landing = profile.support == .full
            ? plantLanding(signals, times, window: kickWindow, lift: lift, before: userContact, stillThreshold: stillThreshold)
            : nil
        if landing == nil, profile.support == .full {
            // Step 12G: independent plant path anchored on the strike drive.
            let knee = signals.values(.kickingKneeAngle).map { a in a.flatMap { $0 >= ContactIntelligence.minimumPlausibleKneeAngle ? $0 : nil } }
            let strike = (kickWindow.strikeStart - 1e-9)...(kickWindow.strikeEnd + 1e-9)
            let drives = ContactIntelligence.drives(knee: knee, speed: signals.values(.kickingAnkleSpeed), times: times, in: strike, frame: frame)
                .filter { $0.footKeepsMoving && $0.extensionDegrees >= ContactIntelligence.minimumDriveExtension }
            if let best = drives.max(by: { $0.rate < $1.rate }) {
                landing = plantLanding(signals, times, window: kickWindow, lift: lift, before: userContact, stillThreshold: stillThreshold,
                                       driveAnchor: times[best.index] + frame / 2)
                if landing != nil { evidence.plantSearchBasis = "beforeKneeDrive" }
            }
        }
        // Engine 2.8.1: the football's departure bounds when the plant can have landed.
        // A plant estimate at or after the ball's first movement is physically impossible
        // (the plant foot lands before the strike): it is rejected, flagged, and the plant
        // is searched again only before the ball left. The ball is never vetoed by it.
        var fusion: BallFusionReport?
        var rejectedPlant: Double?
        if userContact == nil, let ball = ballContact {
            var f = BallFusionReport(detectorRan: true, ballSelected: true)
            f.lastStationaryTime = ball.lastStationaryTime
            f.firstMovementTime = ball.firstMovementTime
            f.plantCandidateTime = landing.map { times[$0.index] }
            let latestPlant = ball.firstMovementTime - frame / 2
            let earliestPlant = ball.firstMovementTime - maximumPlantLeadSeconds
            if let l = landing, times[l.index] >= latestPlant || times[l.index] < earliestPlant {
                // Too late (after the ball left) or too early (more than the contact search
                // span before it — a run-up stride, which would anchor contact in the wrong place).
                f.plantPrecedesBall = times[l.index] < latestPlant
                f.plantRejected = true
                rejectedPlant = times[l.index]
                let limit = times.firstIndex { $0 >= latestPlant }
                var again = profile.support == .full
                    ? plantLanding(signals, times, window: kickWindow, lift: lift, before: limit, stillThreshold: stillThreshold) : nil
                if again == nil, profile.support == .full {
                    again = plantLanding(signals, times, window: kickWindow, lift: lift, before: limit, stillThreshold: stillThreshold,
                                         driveAnchor: ball.firstMovementTime)
                }
                // Only a landing shortly before the ball left can be this kick's plant; an
                // earlier stop is a run-up stride, so the plant is then left unreported.
                landing = again.flatMap { times[$0.index] < latestPlant && times[$0.index] >= earliestPlant ? $0 : nil }
                evidence.plantSearchBasis = landing == nil ? nil : "beforeBallDeparture"
                notes.append(String(format: "The first plant estimate (%.3f s) came %@ the football left (%.3f s), so it was rejected; %@",
                                    times[l.index], times[l.index] >= latestPlant ? "after" : "too long before", ball.firstMovementTime,
                                    landing.map { String(format: "the plant was found again at %.3f s, before the ball moved.", times[$0.index]) }
                                        ?? "no plant landing was found before the ball moved, so the plant is not reported."))
            } else if landing != nil {
                f.plantPrecedesBall = true
            }
            f.plantUsedTime = landing.map { times[$0.index] }
            fusion = f
        }
        evidence.plantPriorTime = landing.map { times[$0.index] }

        // MARK: Contact
        var conflicts: [String] = []
        var contactIndex: Int?
        var contactConfidence = 0.0
        var uncertainty = max(frame, 0.05)
        var firstContactInterval: (Int, Int)?
        var strikeWindowOnly = false
        var ballResolved = false
        if let u = userContact {
            contactIndex = u
            contactConfidence = 0.6
            uncertainty = 0
            if let l = landing, l.index >= u {
                conflicts.append("The chosen contact frame comes before the plant landing found in the video.")
            }
        } else {
            // Step 12F: contact-intelligence-3 — first contact inside the knee drive,
            // checked against the trunk lean; the 2.5.0 five-cue frame is reported as the
            // post-contact swing.
            let range: ClosedRange<Double> = landing.map { (times[$0.index] + frame - 1e-9)...(times[$0.index] + 0.45 + 1e-9) }
                ?? (kickWindow.strikeStart - 1e-9)...(kickWindow.strikeEnd + 0.5 + 1e-9)
            let first = ContactIntelligence.firstContact(signals, lift: lift, searchRange: range,
                                                         landingTime: landing.map { times[$0.index] }, frame: frame)
            evidence.contactCandidates = first.candidates
            evidence.ballEvidence = .unavailable
            evidence.contactEvidenceGroups = first.groups
            evidence.postContactMarkers = first.postContactMarkers
            evidence.strikeApproachStartTime = first.strikeApproachStart.map { times[$0] }
            // Step 12G (CV rebuild): the football detector followed the kicked ball on the
            // video's frames. Contact lies after its last clear resting frame and no later
            // than its first persistent movement; when that is within the timing tolerance
            // it replaces the pose-only answer (automatic evidence, not user assistance).
            if let ball = ballContact {
                let poseBounds: ClosedRange<Double>
                switch first.decision {
                case .established(_, let e, let l), .strikeWindow(_, let e, let l):
                    poseBounds = (times[e] - frame)...(times[l] + frame)
                case .notEstablished:
                    poseBounds = range
                }
                var r = Self.ballContact(ball, times: times, poseBounds: poseBounds)
                var f = fusion ?? BallFusionReport(detectorRan: true, ballSelected: true)
                f.poseSearchStart = ContactEstimator.round3(range.lowerBound)
                f.poseSearchEnd = ContactEstimator.round3(range.upperBound)
                switch first.decision {
                case .established(_, let e, let l), .strikeWindow(_, let e, let l):
                    f.poseFoundStrike = true
                    f.poseStrikeEarliest = times[e]
                    f.poseStrikeLatest = times[l]
                case .notEstablished:
                    f.poseFoundStrike = false
                }
                f.overlapsPose = r.evidence.outcome != .conflicting
                f.withinKickWindow = ball.firstMovementTime >= kickWindow.strikeStart - frame
                    && ball.lastStationaryTime <= kickWindow.strikeEnd + 0.5
                let foot = Self.kickingFootAtBall(ball, signals: signals, times: times, window: kickWindow, frame: frame,
                                                  stillThreshold: stillThreshold)
                f.kickingFootSpeedRatio = foot.ratio.map(ContactEstimator.round3)
                f.kickingFootSupports = foot.supports
                // With no pose strike to agree with, the ball alone stands only when the
                // kicking foot was visibly swinging as the ball left; otherwise it's a conflict.
                if r.resolved != nil, case .notEstablished = first.decision, !foot.supports {
                    r.resolved = nil
                    r.evidence.outcome = .conflicting
                    r.evidence.note = foot.note
                }
                if r.resolved != nil {
                    f.accepted = true
                } else {
                    f.rejectionReason = r.evidence.note
                    if f.withinKickWindow == false {
                        f.rejectionReason = (f.rejectionReason ?? "") + " The ball left outside the selected kick window, so the kick window choice may be wrong."
                    }
                }
                fusion = f
                evidence.ballEvidence = r.evidence
                if let resolved = r.resolved {
                    ballResolved = true
                    contactIndex = resolved.index
                    firstContactInterval = (resolved.earliest, resolved.latest)
                    uncertainty = max(frame / 2, (ball.firstMovementTime - ball.lastStationaryTime) / 2)
                    contactConfidence = resolved.earliest == resolved.latest ? maximumContactConfidence : 0.5
                    evidence.contactOutcome = resolved.earliest == resolved.latest ? .ballVerifiedContact : .ballConstrainedContactInterval
                } else if r.evidence.outcome == .conflicting {
                    conflicts.append(r.evidence.note + " Verify the contact frame yourself.")
                }
            }
            if !ballResolved {
            switch first.decision {
            case .established(let index, let earliest, let latest):
                contactIndex = index
                firstContactInterval = (earliest, latest)
                uncertainty = max(frame, times[latest] - times[earliest])
                var confidence = first.confidence
                if landing == nil { confidence *= 0.7 }
                if windows.needsSelection { confidence *= 0.4 }
                contactConfidence = min(maximumContactConfidence,
                                        confidence * KickPhaseDetector.windowCoverage(signals.values(.kickingKneeAngle), times, around: times[index], radius: 0.1))
            case .strikeWindow(let index, let earliest, let latest):
                // Step 12G: a strike window, not a contact time.
                contactIndex = index
                firstContactInterval = (earliest, latest)
                strikeWindowOnly = true
                uncertainty = (times[latest] - times[earliest]) / 2
                contactConfidence = first.confidence
                conflicts.append(String(format: "The strike happened between %.3f and %.3f s, but body pose alone can't place the moment of contact within ±%.2f s. Contact timing is uncertain: verify the contact frame (or mark the ball) to get timing measurements.",
                                        times[earliest], times[latest], ContactTimingCheck.toleranceSeconds))
            case .notEstablished(let reason):
                conflicts.append(reason + " Contact was not established automatically; choose the contact frame yourself.")
            }
            }
        }
        evidence.contactTimingBasis = userContact != nil ? PhaseDetectionEvidence.userBasis : PhaseDetectionEvidence.automaticBasis
        let ballMarked = assistance?.ballMotion?.outcome == .departed && userContact != nil
        evidence.contactTimingMethod = userContact != nil ? (ballMarked ? "ballMotion" : "user")
            : (ballResolved ? "ballDetector" : (strikeWindowOnly ? "strikeWindow" : "firstContactInterval"))
        evidence.contactProvenance = userContact != nil ? (ballMarked ? "ballMotionUserMarked" : "user") : (ballResolved ? "ballAware" : "poseOnly")
        if userContact != nil {
            evidence.contactOutcome = .userSelectedContact
        } else if !ballResolved {
            evidence.contactOutcome = strikeWindowOnly ? .strikeWindowOnly : (contactIndex == nil ? .contactUnavailable : .poseEstimatedContact)
        }
        evidence.userAssistedContactTime = userContact.map { times[$0] }
        if ballMarked { evidence.ballAnalysisMethod = .userInitializedBallTracking }

        // MARK: Plant phase (before contact)
        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantCandidates: [PhaseEndpointCandidate] = []
        if let l = landing, contactIndex.map({ l.index < $0 }) ?? true {
            evidence.plantTouchdownTime = times[l.index]
            // Never "detected" from this angle: the foot's last movement before landing runs
            // partly along the line of sight.
            evidence.plantState = .estimated
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[l.index], endTime: contactIndex.map { times[$0] } ?? times[l.index],
                representativeTime: times[l.index],
                confidence: (l.cues.count >= 2 ? 0.5 : 0.35) * KickPhaseDetector.windowCoverage(signals.values(.plantAnkleSpeed), times, around: times[l.index], radius: 0.1),
                evidence: [.plantAnkleSpeed, .approachRate], status: .estimated
            )
            plantCandidates.append(PhaseEndpointCandidate(kind: "landing", time: times[l.index], accepted: true,
                                                          reason: "used: " + l.cues.joined(separator: "; ")))
        } else {
            evidence.plantState = .notDetected
            notes.append("The plant landing wasn't found: the plant leg's final swing didn't visibly stop while the run-up braked.")
        }
        if let r = rejectedPlant {
            plantCandidates.insert(PhaseEndpointCandidate(kind: "landing", time: r, accepted: false,
                                                          reason: fusion?.plantPrecedesBall == true
                                                              ? "rejected: too long before the football left to be this kick's plant"
                                                              : "rejected: after the football had already left"), at: 0)
        }
        evidence.plantCandidates = plantCandidates
        evidence.ballFusion = fusion
        let (setup, approach) = approachPhases(signals, times, kickWindow, endIndex: landing?.index ?? contactIndex, profile: profile)

        guard let ci = contactIndex else {
            evidence.contactConflicts = conflicts
            let phases = [setup, approach, profile.support == .full ? plant : .unavailable(.plant),
                          .unavailable(.contact, evidence: [.kickingAnkleLift, .kickingKneeAngle]), .unavailable(.followThrough)]
            var result = KickPhaseDetector.finish(kickType, profile, phases, coverage, notes + conflicts, evidence)
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }
        let contactTime = times[ci]
        evidence.contactUncertaintySeconds = ContactEstimator.round3(uncertainty)
        if userContact == nil, let (e, l) = firstContactInterval {
            evidence.contactEarliestTime = ContactEstimator.round3(times[e])
            evidence.contactLatestTime = ContactEstimator.round3(times[l])
        }
        evidence.ankleSeparationAtContact = signals.values(.ankleSeparation)[ci].map(ContactEstimator.round3)
        evidence.kneeSeparationAtContact = signals.values(.kneeSeparation)[ci].map(ContactEstimator.round3)
        evidence.plantSpeedAtContact = signals.values(.plantAnkleSpeed)[ci].map(ContactEstimator.round3)
        let isAmbiguous = userContact == nil && (windows.needsSelection || strikeWindowOnly)
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus { isAmbiguous ? .ambiguous : base }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }
        if ballMarked, let b = assistance?.ballMotion {
            evidence.contactEarliestTime = b.lastAtRestTime.map(ContactEstimator.round3)
            evidence.contactLatestTime = b.firstDisturbedTime.map(ContactEstimator.round3)
            notes.insert(String(format: "Contact from the video's frames: the ball you marked was at rest through %.3f s and disturbed at %.3f s (user-assisted: you located the ball). Plant and follow-through were searched independently.",
                                b.lastAtRestTime ?? contactTime, contactTime), at: 1)
        } else if userContact != nil {
            notes.insert("Contact time was chosen by the user (user-assisted analysis); plant and follow-through were searched independently around it.", at: 1)
        } else if ballResolved, let ball = ballContact {
            notes.append(String(format: "Contact from the football detector (automatic, from the video's frames): the kicked ball was clearly at rest through %.3f s and first seen moving at %.3f s, so contact happened between those frames — possible contact frames %.3f–%.3f s.",
                                ball.lastStationaryTime, ball.firstMovementTime,
                                evidence.contactEarliestTime ?? contactTime, evidence.contactLatestTime ?? contactTime))
        } else if strikeWindowOnly {
            notes.append(String(format: "Strike window %.3f–%.3f s (pose only, no ball tracking); contact timing uncertain.",
                                evidence.contactEarliestTime ?? contactTime, evidence.contactLatestTime ?? contactTime))
        } else {
            let groupCount = evidence.contactEvidenceGroups?.filter { $0.agrees == true }.count ?? 0
            notes.append(String(format: "First contact estimated at %.3f s (possible %.3f–%.3f s; pose only, no ball tracking): during the kicking knee's fastest extension, before the leg straightened; %d independent evidence group%@ agreed.",
                                contactTime, evidence.contactEarliestTime ?? contactTime, evidence.contactLatestTime ?? contactTime,
                                groupCount, groupCount == 1 ? "" : "s"))
        }
        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: scaled(contactConfidence), evidence: [.kickingKneeAngle, .kickingAnkleSpeed, .lateralTrunkLean],
            status: status(.estimated)
        )
        if userContact == nil, plant.isAvailable, let p = plant.representativeTime, p >= contactTime {
            conflicts.append("The plant landing came after the estimated contact.")
        }

        // MARK: Kicking-ankle tracking after contact
        let tracking = KickPhaseDetector.kickingAnkleTracking(separation: signals.values(.ankleSeparation),
                                                                ahead: Array(repeating: nil, count: times.count), times, after: contactTime)
        let merged = tracking.rule == "separation2D" && tracking.merged
        evidence.kickingAnkleMergedAfterContact = merged
        evidence.kickingAnkleTrackingRule = tracking.rule == "separation2D" ? tracking.rule : nil
        evidence.kickingAnkleMergeOnsetTime = merged ? tracking.onset : nil
        if merged {
            conflicts.append(String(format: "From %.3f s the kicking ankle stays on top of the plant ankle: the kicking foot isn't tracked separately after contact.", tracking.onset ?? contactTime))
        }

        // MARK: Follow-through: the kicking leg keeps moving after contact until it settles
        // (the foot needn't rise; from behind the swing can look flat). What follows is
        // recovery.
        var followCandidates: [PhaseEndpointCandidate] = []
        var followThrough = DetectedKickPhase.unavailable(.followThrough, evidence: [.kickingAnkleSpeed])
        if !merged, let end = settleAfter(signals.values(.kickingAnkleSpeed), times, after: ci),
           times[end] - contactTime >= profile.minimumFollowThroughSeconds - 1e-9 {
            evidence.followThroughBasis = "kickingAnkleSettle"
            evidence.followThroughSeconds = ContactEstimator.round3(times[end] - contactTime)
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: times[end], representativeTime: contactTime,
                confidence: scaled(0.5 * KickPhaseDetector.windowCoverage(signals.values(.kickingAnkleSpeed), times, around: times[end], radius: 0.1)),
                evidence: [.kickingAnkleSpeed], status: status(.estimated)
            )
            followCandidates.append(PhaseEndpointCandidate(kind: "settle", time: times[end], accepted: true,
                                                           reason: "used: the kicking foot settled after its post-contact swing; recovery follows"))
        } else {
            notes.append(merged
                ? "Follow-through can't be measured: the kicking foot isn't tracked separately after contact."
                : "The kicking foot didn't swing on and settle within 0.8 s of contact, so the follow-through wasn't measured.")
        }
        evidence.followThroughCandidates = followCandidates

        guard profile.support == .full else {
            evidence.contactConflicts = conflicts
            notes.append(contentsOf: conflicts)
            notes.append("Only contact and follow-through are detected for this kick type.")
            var result = KickPhaseDetector.finish(kickType, profile,
                                                  [.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough],
                                                  coverage, notes, evidence)
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }
        evidence.contactConflicts = conflicts
        notes.append(contentsOf: conflicts)
        var result = KickPhaseDetector.finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes, evidence)
        result.kickWindows = windows
        result.assistance = assistance
        return result
    }

    // MARK: - depth-view-2 helpers

    /// Step 12E: the plant landing. The plant leg's final swing is the fastest plant-ankle
    /// motion where the run-up ends (at least 2× the still threshold); it has landed when
    /// (a) that motion has visibly stopped — at most 35% of the swing's peak, still slowed
    /// in the next frame — and (b) the run-up has begun braking (`brakingOnset`). The
    /// later of the two is the landing (a foot can't have landed before either). With a
    /// user contact, only frames before it are searched.
    static func plantLanding(_ signals: PoseSignalSet, _ times: [Double], window w: KickWindow, lift: [Double?], before limit: Int?,
                             stillThreshold: Double, driveAnchor: Double? = nil) -> (index: Int, cues: [String])? {
        let speed = signals.values(.plantAnkleSpeed)
        // Step 12G: when the run-up gives no plant (or there is no run-up — IMG_1709's
        // swing-only window made 2.6.0 skip the plant entirely), the plant is searched in
        // the 0.6 s before the kicking knee's fastest extension: the plant foot lands before
        // the leg is driven at the ball. The plant itself is still found from the plant
        // foot's own swing-and-stop, never by subtracting frames from anything.
        var ranges: [ClosedRange<Double>] = []
        if w.source != "swingOnly" { ranges.append(KickPhaseDetector.plantSearchRange(w)) }
        if let drive = driveAnchor {
            ranges = [(drive - driveAnchoredPlantSearchSeconds)...drive]
        }
        guard !ranges.isEmpty else { return nil }
        var search = times.indices.filter { i in ranges.contains { $0.contains(times[i]) } }
        if let limit { search = search.filter { $0 < limit } }
        guard let peak = search.max(by: { (speed[$0] ?? 0) < (speed[$1] ?? 0) }), let top = speed[peak],
              top >= 2 * stillThreshold else { return nil }
        let after = times.indices.filter { i in i > peak && times[i] - times[peak] <= 0.5 + 1e-9 && (limit.map { i < $0 } ?? true) }
        let stop = after.first { i in
            guard let v = speed[i], v <= 0.35 * top else { return false }
            return i + 1 >= times.count || (speed[i + 1] ?? .infinity) <= 0.5 * top
        }
        let braking = brakingOnset(signals.values(.approachRate), times, from: peak, limit: limit)
        var cues: [String] = []
        if let stop { cues.append(String(format: "the plant leg's final swing (%.1f bl/s at %.3f s) stopped at %.3f s", top, times[peak], times[stop])) }
        if let braking { cues.append(String(format: "the run-up began braking at %.3f s", times[braking])) }
        guard let landing = [stop, braking].compactMap({ $0 }).max(), stop != nil else { return nil }
        return (landing, cues)
    }

    /// Step 12G: the drive-anchored plant search looks this far back from the drive.
    static let driveAnchoredPlantSearchSeconds = 0.6

    /// Relative deceleration (1/s) at or below which the run-up is braking.
    static let brakingRelativeDeceleration = -2.0

    /// The first sample within 0.5 s after `start` where the run-up brakes. The approach
    /// rate is v ÷ Z, so d ln(rate)/dt + rate = (dv/dt) ÷ v — the speed's own relative
    /// change, free of the distance to the camera.
    static func brakingOnset(_ rate: [Double?], _ times: [Double], from start: Int, limit: Int?) -> Int? {
        let window = times.indices.filter { i in i >= start && times[i] - times[start] <= 0.5 + 1e-9 && (limit.map { i < $0 } ?? true) }
        for i in window where i > 0 && i + 1 < times.count {
            guard let r0 = rate[i - 1], let r1 = rate[i + 1], let r = rate[i], r0 > 0.05, r1 > 0.05, r > 0.05 else { continue }
            let dlog = (log(r1) - log(r0)) / (times[i + 1] - times[i - 1])
            if dlog + r <= brakingRelativeDeceleration { return i }
        }
        return nil
    }

    enum ContactDecision: Equatable {
        /// Contact at `index` ± `halfWidth` seconds.
        case established(index: Int, halfWidth: Double)
        case notEstablished(String)
    }

    /// The cue weights (they sum to 1). A frame needs at least `minimumContactScore`.
    static let contactCueWeights: [(name: String, weight: Double)] = [
        ("foot at its lowest", 0.25), ("heel-high backswing just before", 0.2), ("knee just extended", 0.25),
        ("foot keeps moving after", 0.15), ("foot dropping into it", 0.15),
    ]
    static let minimumContactScore = 0.85
    /// Torso lengths above the foot's lowest point that still count as "at its lowest"
    /// (the struck ball sits a little above the stance foot).
    static let lowestFootTolerance = 0.35

    /// LEGACY (engine 2.5.0, depth-view-2) — no longer used for contact. Kept so tests and
    /// diagnostics can show what 2.5.0 picked. Its five cues were not independent: three
    /// describe the leg finishing its extension, which happens after the ball is struck.
    ///
    /// Step 12E: contact from independent cues, evaluated at every frame where contact is
    /// physically possible (after the plant landing and within 0.45 s of it; without a
    /// landing, the strike interval extended by 0.5 s, because the braking signal ends
    /// early from behind). No single image-plane minimum is assumed to be contact:
    /// 1. the kicking foot is at its lowest (within 0.35 torso lengths of its lowest point
    ///    around the kick) — the ball sits on the ground;
    /// 2. within the 0.3 s before, the heel was at least 0.3 higher — a backswing;
    /// 3. the knee has just extended: it rose at least 15° within 0.25 s and is within 5°
    ///    of its straightest in that time (foreshortened from behind, but the direction of
    ///    change survives);
    /// 4. the foot keeps moving afterwards (≥ 2 body lengths/s within 0.15 s) — not a
    ///    recovery step landing;
    /// 5. the foot is dropping into it, not rising.
    /// The frames scoring highest (≥ 0.85) form a run; contact is its center, the
    /// uncertainty its half-width plus half a frame. Two separate top runs ≥ 0.15 s apart
    /// are ambiguous: contact is then NOT established.
    static func contactCues(_ signals: PoseSignalSet, _ lift: [Double?], _ times: [Double], window w: KickWindow,
                            landing: Int?, frame: Double) -> (decision: ContactDecision, bestScore: Double, candidates: [ContactCandidate]) {
        let knee = signals.values(.kickingKneeAngle)
        let speed = signals.values(.kickingAnkleSpeed)
        let range: ClosedRange<Double> = landing.map { (times[$0] + frame - 1e-9)...(times[$0] + 0.45 + 1e-9) }
            ?? (w.strikeStart - 1e-9)...(w.strikeEnd + 0.5 + 1e-9)
        let candidates = times.indices.filter { range.contains(times[$0]) && $0 > 0 }
        guard !candidates.isEmpty else { return (.notEstablished("No frames after the plant landing to search."), 0, []) }
        let regionStart = (landing.map { times[$0] } ?? range.lowerBound) - 0.3
        let region = times.indices.filter { times[$0] >= regionStart - 1e-9 && times[$0] <= range.upperBound }
        guard let lowest = region.compactMap({ lift[$0] }).min() else {
            return (.notEstablished("The kicking foot wasn't tracked through the strike."), 0, [])
        }
        var scores: [Int: (score: Double, met: [String])] = [:]
        for i in candidates {
            guard let l = lift[i] else { continue }
            var met: [String] = []
            if l <= lowest + lowestFootTolerance { met.append(contactCueWeights[0].name) }
            let before = times.indices.filter { times[$0] >= times[i] - 0.3 - 1e-9 && $0 < i }.compactMap { lift[$0] }
            if let high = before.max(), high >= l + 0.3 { met.append(contactCueWeights[1].name) }
            let kneeWindow = times.indices.filter { times[$0] >= times[i] - 0.25 - 1e-9 && $0 <= i }.compactMap { knee[$0] }
            if let k = knee[i], let lo = kneeWindow.min(), let hi = kneeWindow.max(), k >= hi - 5, k - lo >= 15 {
                met.append(contactCueWeights[2].name)
            }
            let next = times.indices.filter { $0 > i && times[$0] - times[i] <= 0.15 + 1e-9 }.compactMap { speed[$0] }
            if (next.max() ?? 0) >= 2.0 { met.append(contactCueWeights[3].name) }
            if let p = lift[i - 1], p - l >= 0 { met.append(contactCueWeights[4].name) }
            let score = contactCueWeights.filter { met.contains($0.name) }.map(\.weight).reduce(0, +)
            scores[i] = ((score * 1000).rounded() / 1000, met)
        }
        let best = scores.values.map(\.score).max() ?? 0
        // Runs of consecutive frames at the best score.
        var runs: [[Int]] = []
        for i in candidates where (scores[i]?.score ?? -1) >= best - 1e-9 {
            if let last = runs.last?.last, last == i - 1 { runs[runs.count - 1].append(i) } else { runs.append([i]) }
        }
        func candidate(_ run: [Int], selected: Bool, rejection: String?) -> ContactCandidate {
            let center = run[(run.count - 1) / 2]
            let met = scores[center]?.met ?? []
            return ContactCandidate(
                time: times[center], refinedTime: times[center], peakSpeed: ContactEstimator.round3(speed[center] ?? 0),
                relativeSpeed: 0, swingSupport: met.contains(contactCueWeights[1].name) ? 1 : 0, forwardDirection: nil,
                plantSupport: landing == nil ? nil : 1, passTiming: nil, bodyTransition: nil,
                followThrough: met.contains(contactCueWeights[3].name) ? 1 : 0, score: scores[center]?.score ?? 0,
                independentSupport: Double(met.count), supportingSignals: met,
                rejectionReasons: rejection.map { [$0] } ?? [], selected: selected
            )
        }
        guard best >= minimumContactScore, let first = runs.first else {
            let top = runs.map { candidate($0, selected: false, rejection: "too few independent cues agree") }
            return (.notEstablished(String(format: "No frame after the plant landing had enough independent contact cues (best %.2f of 1, %.2f needed).", best, minimumContactScore)), best, top)
        }
        if runs.count > 1, let last = runs.last, times[last[0]] - times[first.last ?? first[0]] >= 0.15 - 1e-9 {
            let all = runs.map { candidate($0, selected: false, rejection: "another frame range has the same cues") }
            return (.notEstablished(String(format: "Two separate moments (%.3f s and %.3f s) match the contact cues equally well.", times[first[0]], times[last[0]])), best, all)
        }
        let merged = runs.flatMap { $0 }.sorted()
        let center = merged[(merged.count - 1) / 2]
        let halfWidth = (times[merged.last ?? center] - times[merged.first ?? center]) / 2 + frame / 2
        return (.established(index: center, halfWidth: halfWidth), best, [candidate(merged, selected: true, rejection: nil)])
    }

    /// Step 12E: the end of the follow-through: after contact the kicking foot keeps
    /// moving (a peak of at least 2 body lengths/s within 0.5 s) and then settles — at most
    /// 25% of that peak, still slow in the next frame — within 0.8 s of contact.
    static func settleAfter(_ speed: [Double?], _ times: [Double], after c: Int) -> Int? {
        let post = times.indices.filter { $0 > c && times[$0] - times[c] <= 0.5 + 1e-9 }
        guard let peak = post.max(by: { (speed[$0] ?? 0) < (speed[$1] ?? 0) }), let top = speed[peak], top >= 2.0 else { return nil }
        return times.indices.first { i in
            guard i > peak, times[i] - times[c] <= 0.8 + 1e-9, let v = speed[i], v <= 0.25 * top else { return false }
            return i + 1 >= times.count || (speed[i + 1] ?? .infinity) <= 0.35 * top
        }
    }





    /// Setup (still before the run-up) and approach (run-up to the plant), from the
    /// perspective approach rate.
    static func approachPhases(_ signals: PoseSignalSet, _ times: [Double], _ w: KickWindow, endIndex: Int?, profile: KickPhaseProfile)
        -> (DetectedKickPhase, DetectedKickPhase) {
        guard w.source == "approach", let start = times.firstIndex(where: { $0 >= w.approachStart - 1e-9 }) else {
            return (.unavailable(.setup, evidence: [.approachRate]), .unavailable(.approach, evidence: [.approachRate]))
        }
        let end = endIndex ?? times.firstIndex(where: { $0 >= w.approachEnd - 1e-9 }) ?? start
        guard end > start else {
            return (.unavailable(.setup, evidence: [.approachRate]), .unavailable(.approach, evidence: [.approachRate]))
        }
        let duration = times[end] - times[start]
        let reachesStart = start == 0
        let longEnough = duration >= profile.minimumApproachSeconds
        let approach = DetectedKickPhase(
            phase: .approach, startTime: times[start], endTime: times[end], representativeTime: times[start],
            confidence: longEnough && !reachesStart ? 0.6 : 0.35, evidence: [.approachRate],
            status: longEnough && !reachesStart ? .detected : .estimated
        )
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.approachRate])
        if start > 0, times[start] - times[0] >= profile.minimumSetupSeconds {
            let rate = signals.values(.approachRate)
            let window = 0..<start
            let still = window.filter { abs(rate[$0] ?? .infinity) < KickWindowDetector.depthMinimumApproachRate }
            let fraction = Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(phase: .setup, startTime: times[0], endTime: times[start], representativeTime: times[0],
                                          confidence: 0.6 * fraction, evidence: [.approachRate], status: .estimated)
            }
        }
        return (setup, approach)
    }
}
