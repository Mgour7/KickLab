import Foundation

/// Step 12E: kick phases in a DEPTH view — filmed from behind the kicker (running away
/// from the camera) or in front (running toward it).
///
/// Nothing here uses horizontal image motion as "forward". The evidence:
/// - kick window and approach: the perspective approach rate (apparent size changing
///   steadily, see `PoseSignalKey.approachRate`), and a backswing in its strike interval;
/// - plant: the plant ankle coming to rest in the image (a planted foot is still in the
///   world, so it is still in the image from any fixed camera), measured in each frame's
///   own torso lengths;
/// - contact: from behind or in front the instep swing is vertical in the image — the
///   kicking heel rises toward the hips in the backswing (the apex), then the foot drops
///   to the BOTTOM of its arc, where it meets the ball beside the plant foot, and rises
///   again in the follow-through. Contact is estimated at that bottom, after the plant
///   landing. It is never "detected": the ball isn't tracked and the arc's bottom can sit
///   a frame from the strike, so the uncertainty is at least one frame;
/// - follow-through: the kicking ankle rising again after contact to its highest point.
///
/// When the bottom of the arc can't be found the contact is unavailable and the
/// user-assisted contact workflow is offered.
enum DepthViewPhaseDetector {
    static let algorithmVersion = "depth-view-1"
    /// Frame torso lengths the heel must rise above its low point to count as a backswing.
    static let minimumBackswingLift = 0.5
    /// …and the foot must come back down at least this much from the apex at the bottom.
    static let minimumDownswingDrop = 0.5
    /// Longest backswing apex → arc bottom (s).
    static let maximumDownswingSeconds = 0.4
    /// The kicking ankle beside the plant ankle at contact (frame torso lengths).
    static let besidePlantDistance = 1.0
    /// A follow-through must rise at least this much (frame torso lengths).
    static let minimumFollowThroughRise = 0.3
    /// Contact confidence never exceeds this without ball tracking in a depth view.
    static let maximumContactConfidence = 0.6

    static func detect(
        _ signals: PoseSignalSet,
        kickType: KickType,
        profile: KickPhaseProfile,
        perspective: CameraPerspective,
        assistance: PhaseDetectionAssistance?
    ) -> KickPhaseDetectionResult {
        let times = signals.timestamps
        let lift = KickPhaseDetector.medianFilter(signals.values(.kickingAnkleLift), radius: 1)
        let coverage = signals.coverage(.kickingAnkleLift)
        let view = perspective == .depthAway ? "from behind the kicker" : "from in front of the kicker"
        guard profile.support != .unsupported else {
            return .unavailable(kickType: kickType, support: .unsupported, coverage: coverage,
                                notes: ["Phase detection is not supported for this kick type."])
        }
        guard times.count >= 5, coverage >= profile.minimumCoverage else {
            return .unavailable(kickType: kickType, support: profile.support, coverage: coverage,
                                notes: ["Not enough of the kicking leg was visible to detect kick phases (filmed \(view))."])
        }
        let fps = KickPhaseDetector.framesPerSecond(times)
        let frame = 1 / fps

        // MARK: Kick window
        var windows = KickWindowDetector.detectDepthView(signals, profile: profile, restrictTo: assistance?.window)
        if let range = assistance?.window, windows.selected == nil {
            windows = KickWindowAnalysis(windows: [KickWindowDetector.userWindow(range, signals: signals)], selectedIndex: 0,
                                         needsSelection: false, notes: ["Analyzing the interval chosen by the user."])
        }
        if assistance?.window != nil, windows.needsSelection {
            windows.needsSelection = false
            windows.notes.append("The user chose this interval; other kicks in it were not analyzed separately.")
        }
        var notes: [String] = ["Filmed \(view): phases come from the kicker's apparent size (run-up), the plant foot coming to rest, and the kicking leg's vertical swing in the image. Side-view measurements are not made."]
        notes.append(contentsOf: windows.notes)
        var evidence = PhaseDetectionEvidence(contactPeakTime: nil, contactPeakSpeed: nil)
        evidence.algorithmVersion = algorithmVersion
        // A user-chosen contact frame stands even when no swing was seen around it.
        if windows.selected == nil, let t = assistance?.contactTime {
            windows = KickWindowAnalysis(windows: [KickWindowDetector.userWindow((t - 0.8)...(t + 0.8), signals: signals)], selectedIndex: 0,
                                         needsSelection: false, notes: ["Analyzing around the contact frame chosen by the user."])
        }
        guard let kickWindow = windows.selected else {
            var result = KickPhaseDetectionResult.unavailable(
                kickType: kickType, support: profile.support, coverage: coverage,
                notes: notes + ["No kick was found: no run-up followed by a backswing of the kicking leg."]
            )
            result.evidence = evidence
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }

        // MARK: The swing (found before, and independent of, the plant)
        let search = times.indices.filter { times[$0] >= kickWindow.strikeStart - 1e-9 && times[$0] <= kickWindow.strikeEnd + 1e-9 }
        let arcs = arcBottoms(lift, times, in: search)
        // The kick is the largest swing near the end of the run-up (strides make smaller ones).
        let arc = arcs.max { a, b in a.drop != b.drop ? a.drop < b.drop : a.bottom > b.bottom }

        // MARK: Plant: the plant foot at rest while the kicking leg swings down
        // (a planted foot is still in the world, so still in the image).
        let plantSpeed = KickPhaseDetector.medianFilter(signals.values(.plantAnkleSpeed), radius: 2)
        let stillThreshold = KickPhaseDetector.stillThreshold(signals, profile: profile)
        evidence.plantStillThreshold = stillThreshold
        let minimumRun = max(2, Int((KickPhaseDetector.minimumStillSeconds * fps).rounded(.up)))
        let userContact = assistance?.contactTime.flatMap { t in times.indices.min { abs(times[$0] - t) < abs(times[$1] - t) } }
        let anchor = userContact ?? arc?.bottom
        // From behind or in front a foot moving along the line of sight barely moves in the
        // image, so the plant foot's still run can start too early (it includes the final
        // stride). The landing is where the run-up BRAKES: the perspective-corrected speed
        // change (dv/dt ÷ v) drops sharply as the body decelerates over the planted leg.
        var plantPrior: Int?
        var plantFromBraking = false
        if profile.support == .full, let anchor,
           let still = stillRunStart(plantSpeed, threshold: stillThreshold, containing: max(0, anchor - 1), minimumRun: minimumRun) {
            plantPrior = still
            if let braking = brakingOnset(signals.values(.approachRate), times, before: anchor), braking > still {
                plantPrior = braking
                plantFromBraking = true
            }
            if let p = plantPrior, let apex = arc?.apex, times[apex] - times[p] > 0.6 { plantPrior = nil }
        }
        evidence.plantPriorTime = plantPrior.map { times[$0] }

        // MARK: Contact
        var conflicts: [String] = []
        var contactIndex: Int?
        var apexIndex: Int?
        var contactConfidence = 0.0
        if let u = userContact {
            contactIndex = u
            contactConfidence = 0.6
        } else if let arc {
            apexIndex = arc.apex
            var bottom = arc.bottom
            // Contact can't come before the plant foot lands.
            if let p = plantPrior, bottom <= p {
                conflicts.append(String(format: "The kicking foot's lowest point (%.3f s) came before the plant landing (%.3f s); contact was placed one frame after the landing.", times[bottom], times[p]))
                bottom = min(times.count - 1, p + 1)
            }
            contactIndex = bottom
            var confidence = 0.5
            let plantStill = (plantSpeed[bottom] ?? .infinity) <= stillThreshold
            let beside = (signals.values(.ankleSeparation)[bottom] ?? .infinity) <= besidePlantDistance
            if !plantStill { confidence *= 0.7; conflicts.append("The plant foot was still moving at the estimated contact.") }
            if !beside { confidence *= 0.7; conflicts.append("At the estimated contact the kicking foot wasn't beside the plant foot.") }
            if plantPrior == nil { confidence *= 0.7 }
            if windows.needsSelection { confidence *= 0.4 }
            if arcs.count > 1, let second = arcs.map(\.drop).sorted(by: >).dropFirst().first, second >= 0.85 * arc.drop {
                confidence *= 0.5
                conflicts.append("Another swing of similar size was found near the kick; the contact estimate may belong to the wrong swing.")
            }
            contactConfidence = min(maximumContactConfidence, confidence * KickPhaseDetector.windowCoverage(lift, times, around: times[bottom], radius: 0.1))
        } else {
            conflicts.append("No backswing followed by the kicking foot dropping to the bottom of its swing was found, so contact couldn't be placed. Choose the contact frame yourself.")
        }
        evidence.contactTimingBasis = userContact != nil ? PhaseDetectionEvidence.userBasis : PhaseDetectionEvidence.automaticBasis
        evidence.contactTimingMethod = userContact != nil ? "user" : "swingArcBottom"
        evidence.userAssistedContactTime = userContact.map { times[$0] }
        evidence.contactPeakTime = apexIndex.map { times[$0] }

        guard let ci = contactIndex else {
            evidence.contactConflicts = conflicts
            var phases = [DetectedKickPhase.unavailable(.setup), .unavailable(.approach), .unavailable(.plant),
                          .unavailable(.contact, evidence: [.kickingAnkleLift]), .unavailable(.followThrough)]
            // The run-up and plant are still reported when found.
            let (setup, approach) = approachPhases(signals, times, kickWindow, endIndex: plantPrior, profile: profile)
            phases[0] = setup
            phases[1] = approach
            if let p = plantPrior {
                phases[2] = DetectedKickPhase(phase: .plant, startTime: times[p], endTime: times[p], representativeTime: times[p],
                                              confidence: 0.4, evidence: [.plantAnkleSpeed], status: .estimated)
                evidence.plantTouchdownTime = times[p]
                evidence.plantState = .estimated
            }
            var result = KickPhaseDetector.finish(kickType, profile, phases, coverage, notes + conflicts, evidence)
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }
        let contactTime = times[ci]
        let uncertainty = max(frame, 0.05)
        evidence.contactUncertaintySeconds = ContactEstimator.round3(userContact != nil ? 0 : uncertainty)
        if userContact == nil {
            evidence.contactEarliestTime = ContactEstimator.round3(max(contactTime - uncertainty, plantPrior.map { times[$0] + frame } ?? -.infinity))
            evidence.contactLatestTime = ContactEstimator.round3(contactTime + uncertainty)
        }
        evidence.ankleSeparationAtContact = signals.values(.ankleSeparation)[ci].map(ContactEstimator.round3)
        evidence.kneeSeparationAtContact = signals.values(.kneeSeparation)[ci].map(ContactEstimator.round3)
        let isAmbiguous = userContact == nil && windows.needsSelection
        func status(_ base: PhaseDetectionStatus) -> PhaseDetectionStatus { isAmbiguous ? .ambiguous : base }
        func scaled(_ c: Double) -> Double { min(1, max(0, isAmbiguous ? c * 0.4 : c)) }
        if userContact != nil {
            notes.insert("Contact time was chosen by the user (user-assisted analysis); everything else was measured around it.", at: 1)
        } else {
            notes.append(String(format: "Contact estimated at %.3f s: the bottom of the kicking foot's swing after the backswing%@ (±%.2f s; no ball tracking).",
                                contactTime, apexIndex.map { String(format: " (apex %.3f s)", times[$0]) } ?? "", uncertainty))
        }
        let contact = DetectedKickPhase(
            phase: .contact, startTime: contactTime, endTime: contactTime, representativeTime: contactTime,
            confidence: scaled(contactConfidence), evidence: [.kickingAnkleLift, .plantAnkleSpeed, .ankleSeparation],
            status: status(.estimated)
        )

        // MARK: Kicking-ankle tracking after contact
        let tracking = KickPhaseDetector.kickingAnkleTracking(separation: signals.values(.ankleSeparation),
                                                                ahead: Array(repeating: nil, count: times.count), times, after: contactTime)
        let merged = tracking.rule == "separation2D" && tracking.merged
        evidence.kickingAnkleMergedAfterContact = merged
        evidence.kickingAnkleTrackingRule = tracking.rule == "separation2D" ? tracking.rule : nil
        evidence.kickingAnkleMergeOnsetTime = merged ? tracking.onset : nil
        if merged {
            conflicts.append(String(format: "From %.3f s the kicking ankle stays on top of the plant ankle: the kicking foot isn't tracked separately after contact.", tracking.onset ?? contactTime))
        }

        // MARK: Follow-through: the kicking ankle rising again to its highest point.
        var followCandidates: [PhaseEndpointCandidate] = []
        var followThrough = DetectedKickPhase.unavailable(.followThrough, evidence: [.kickingAnkleLift])
        if !merged, let end = riseApex(lift, times, after: ci, minimumRise: minimumFollowThroughRise),
           times[end] - contactTime >= profile.minimumFollowThroughSeconds - 1e-9 {
            evidence.followThroughBasis = "kickingAnkleLift"
            evidence.followThroughSeconds = ContactEstimator.round3(times[end] - contactTime)
            followThrough = DetectedKickPhase(
                phase: .followThrough, startTime: contactTime, endTime: times[end], representativeTime: contactTime,
                confidence: scaled(0.5 * KickPhaseDetector.windowCoverage(lift, times, around: times[end], radius: 0.1)),
                evidence: [.kickingAnkleLift], status: status(.estimated)
            )
            followCandidates.append(PhaseEndpointCandidate(kind: "liftApex", time: times[end], accepted: true,
                                                           reason: "used: the kicking foot's highest point after contact"))
        } else {
            notes.append(merged
                ? "Follow-through can't be measured: the kicking foot isn't tracked separately after contact."
                : "No follow-through rise of the kicking foot was found after contact.")
        }
        evidence.followThroughCandidates = followCandidates

        guard profile.support == .full else {
            evidence.contactConflicts = conflicts
            notes.append(contentsOf: conflicts)
            notes.append("Only contact and follow-through are detected for this kick type.")
            var result = KickPhaseDetector.finish(kickType, profile,
                                                  [.unavailable(.setup), .unavailable(.approach), .unavailable(.plant), contact, followThrough],
                                                  coverage, notes, evidence)
            result.kickWindows = windows
            result.assistance = assistance
            return result
        }

        // MARK: Plant
        evidence.plantSpeedAtContact = plantSpeed[ci].map(ContactEstimator.round3)
        var plant = DetectedKickPhase.unavailable(.plant, evidence: [.plantAnkleSpeed])
        var plantIndex: Int?
        var plantCandidates: [PhaseEndpointCandidate] = []
        if let p = plantPrior, p < ci {
            plantIndex = p
            let throughContact = (p...ci).allSatisfy { (plantSpeed[$0] ?? .infinity) <= stillThreshold }
            evidence.plantTouchdownTime = times[p]
            evidence.plantStillThroughContact = throughContact
            // Never "detected" from this angle: the foot's last movement before landing runs
            // along the line of sight.
            evidence.plantState = throughContact ? .estimated : .unstableAfterTouchdown
            let plantCoverage = KickPhaseDetector.windowCoverage(plantSpeed, times, around: times[p], radius: 0.1)
            plant = DetectedKickPhase(
                phase: .plant, startTime: times[p], endTime: contactTime, representativeTime: times[p],
                confidence: scaled((throughContact ? 0.6 : 0.4) * plantCoverage),
                evidence: [.plantAnkleSpeed, .approachRate], status: status(.estimated)
            )
            plantCandidates.append(PhaseEndpointCandidate(
                kind: plantFromBraking ? "brakingOnset" : "stillRun", time: times[p], accepted: true,
                reason: (plantFromBraking ? "used: the run-up braked here while the plant foot was at rest" : "used: the plant foot came to rest")
                    + (throughContact ? "" : "; moving again before contact")))
            if !throughContact {
                notes.append(String(format: "The plant foot came to rest at %.2f s but was moving again by the estimated contact.", times[p]))
            }
        } else {
            evidence.plantState = .notDetected
            notes.append("The plant foot wasn't seen coming to rest before the estimated contact.")
        }
        evidence.plantCandidates = plantCandidates

        let (setup, approach) = approachPhases(signals, times, kickWindow, endIndex: plantIndex ?? ci, profile: profile)
        evidence.contactConflicts = conflicts
        notes.append(contentsOf: conflicts)
        var result = KickPhaseDetector.finish(kickType, profile, [setup, approach, plant, contact, followThrough], coverage, notes, evidence)
        result.kickWindows = windows
        result.assistance = assistance
        return result
    }

    /// Every backswing apex in `search` (heel at least `minimumBackswingLift` above its
    /// low point in the preceding 0.4 s, a local maximum within ±0.1 s) with the bottom of
    /// the downswing that follows: the lowest kicking-ankle lift within
    /// `maximumDownswingSeconds`, at least `minimumDownswingDrop` below the apex, after
    /// which the foot rises again (not just the end of the data).
    static func arcBottoms(_ lift: [Double?], _ times: [Double], in search: [Int]) -> [(apex: Int, bottom: Int, drop: Double)] {
        var out: [(apex: Int, bottom: Int, drop: Double)] = []
        for i in search {
            guard let v = lift[i] else { continue }
            let before = times.indices.filter { times[$0] < times[i] && times[i] - times[$0] <= 0.4 + 1e-9 }.compactMap { lift[$0] }
            let around = times.indices.filter { abs(times[$0] - times[i]) <= 0.1 + 1e-9 }.compactMap { lift[$0] }
            guard let low = before.min(), v - low >= minimumBackswingLift, v >= (around.max() ?? v) else { continue }
            if let last = out.last, last.apex == i - 1 { continue }
            let after = times.indices.filter { $0 > i && times[$0] - times[i] <= maximumDownswingSeconds + 1e-9 }
            guard let bottom = after.min(by: { (lift[$0] ?? .infinity) < (lift[$1] ?? .infinity) }),
                  let b = lift[bottom], v - b >= minimumDownswingDrop else { continue }
            let next = times.indices.filter { $0 > bottom && times[$0] - times[bottom] <= 0.2 + 1e-9 }.compactMap { lift[$0] }
            guard (next.max() ?? -.infinity) > b + 0.05 else { continue }
            out.append((i, bottom, v - b))
        }
        return out
    }

    /// Relative deceleration (1/s) at or below which the run-up is braking.
    static let brakingRelativeDeceleration = -2.0

    /// Step 12E: the first sample within 0.5 s before `anchor` where the run-up brakes.
    /// The approach rate is v ÷ Z, so d ln(rate)/dt + rate = (dv/dt) ÷ v — the speed's own
    /// relative change, free of the distance to the camera.
    static func brakingOnset(_ rate: [Double?], _ times: [Double], before anchor: Int) -> Int? {
        let window = times.indices.filter { $0 < anchor && times[anchor] - times[$0] <= 0.5 + 1e-9 }
        for i in window where i > 0 && i + 1 < times.count {
            guard let r0 = rate[i - 1], let r1 = rate[i + 1], let r = rate[i], r0 > 0.05, r1 > 0.05, r > 0.05 else { continue }
            let dlog = (log(r1) - log(r0)) / (times[i + 1] - times[i - 1])
            if dlog + r <= brakingRelativeDeceleration { return i }
        }
        return nil
    }

    /// The start of the plant ankle's still run (filtered speed at or below `threshold`
    /// for at least `minimumRun` samples) that contains sample `i`.
    static func stillRunStart(_ speed: [Double?], threshold: Double, containing i: Int, minimumRun: Int) -> Int? {
        guard speed.indices.contains(i), (speed[i] ?? .infinity) <= threshold else { return nil }
        var start = i, end = i
        while start > 0, (speed[start - 1] ?? .infinity) <= threshold { start -= 1 }
        while end + 1 < speed.count, (speed[end + 1] ?? .infinity) <= threshold { end += 1 }
        return end - start + 1 >= minimumRun ? start : nil
    }

    /// The kicking ankle's highest point after `start` (within 0.8 s), when it rose at
    /// least `minimumRise` and then came down (not still rising at the end).
    static func riseApex(_ lift: [Double?], _ times: [Double], after start: Int, minimumRise: Double) -> Int? {
        guard let base = lift[start] else { return nil }
        let window = times.indices.filter { $0 > start && times[$0] - times[start] <= 0.8 + 1e-9 }
        guard let highest = window.compactMap({ lift[$0] }).max(), highest - base >= minimumRise else { return nil }
        guard let apex = window.first(where: { (lift[$0] ?? -.infinity) >= highest - 0.05 }), apex != window.last else { return nil }
        return apex
    }

    /// Setup (still before the run-up) and approach (run-up to the plant), from the
    /// perspective approach rate.
    static func approachPhases(_ signals: PoseSignalSet, _ times: [Double], _ w: KickWindow, endIndex: Int?, profile: KickPhaseProfile)
        -> (DetectedKickPhase, DetectedKickPhase) {
        guard w.source == "approach", let start = times.firstIndex(where: { $0 >= w.approachStart - 1e-9 }) else {
            return (.unavailable(.setup, evidence: [.approachRate]), .unavailable(.approach, evidence: [.approachRate]))
        }
        let end = endIndex ?? times.firstIndex(where: { $0 >= w.approachEnd - 1e-9 }) ?? start
        guard end > start else {
            return (.unavailable(.setup, evidence: [.approachRate]), .unavailable(.approach, evidence: [.approachRate]))
        }
        let duration = times[end] - times[start]
        let reachesStart = start == 0
        let longEnough = duration >= profile.minimumApproachSeconds
        let approach = DetectedKickPhase(
            phase: .approach, startTime: times[start], endTime: times[end], representativeTime: times[start],
            confidence: longEnough && !reachesStart ? 0.6 : 0.35, evidence: [.approachRate],
            status: longEnough && !reachesStart ? .detected : .estimated
        )
        var setup = DetectedKickPhase.unavailable(.setup, evidence: [.approachRate])
        if start > 0, times[start] - times[0] >= profile.minimumSetupSeconds {
            let rate = signals.values(.approachRate)
            let window = 0..<start
            let still = window.filter { abs(rate[$0] ?? .infinity) < KickWindowDetector.depthMinimumApproachRate }
            let fraction = Double(still.count) / Double(window.count)
            if fraction >= 0.5 {
                setup = DetectedKickPhase(phase: .setup, startTime: times[0], endTime: times[start], representativeTime: times[0],
                                          confidence: 0.6 * fraction, evidence: [.approachRate], status: .estimated)
            }
        }
        return (setup, approach)
    }
}
