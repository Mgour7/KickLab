import Foundation

// Step 12E: camera-aware analysis.
//
// Before this step every movement calculation assumed the kicker runs ACROSS the image
// (a side view): "forward" was the image x axis, the approach was found from horizontal
// hip speed, contact from the kicking foot passing the plant foot along x, and the camera
// angle only lowered metric confidence afterwards. Filmed from behind (or in front), the
// kicker runs along the camera's line of sight: horizontal image motion is tiny, so no
// approach was found, the swing had no "forward" direction, and every metric that
// survived was halved in confidence — the analysis could only fail.
//
// A depth view is now analyzed with cues it can actually show:
// - approach: the kicker shrinks (running away) or grows (running toward the camera); the
//   rate of change of apparent size is a PERSPECTIVE rate (speed ÷ distance), never a speed;
// - lengths at one instant are measured in that frame's own torso length (joints at the
//   same depth), not in a clip-wide median distorted by perspective;
// - the swing: the kicking heel rises toward the hips in the backswing and the foot drops
//   to the bottom of its arc at the strike — vertical in the image from behind or in front.

/// How the athlete moves relative to the camera.
enum CameraPerspective: String, Codable, Equatable, Sendable {
    /// The kicker runs across the image (side view).
    case side
    /// The kicker runs away from the camera (filmed from behind).
    case depthAway
    /// The kicker runs toward the camera (filmed from in front / behind the goal).
    case depthToward
    /// Both: a diagonal run-up across and into the image.
    case oblique

    var isDepthView: Bool { self == .depthAway || self == .depthToward }

    /// Whether the athlete faces away from the camera (rear) or toward it (front); nil when
    /// the facing can't be used to check left/right labels (side and oblique views).
    var facesAwayFromCamera: Bool? {
        switch self {
        case .depthAway: true
        case .depthToward: false
        case .side, .oblique: nil
        }
    }
}

/// Movement evidence that tells the perspectives apart.
struct PerspectiveCues: Codable, Equatable, Sendable {
    /// Hip-center horizontal displacement, first to last, in median torso lengths.
    var horizontalTravel: Double
    /// Apparent body size near the end ÷ near the start (> 1 = toward the camera).
    var sizeRatio: Double
    /// The perspective the movement looks like.
    var observed: CameraPerspective?
}

/// What was used, and why.
struct PerspectiveDecision: Codable, Equatable, Sendable {
    var declared: VideoAngleType
    var used: CameraPerspective
    var cues: PerspectiveCues?
    /// True when the movement clearly contradicted the selected camera angle.
    var declaredContradicted: Bool
    var explanation: String
}

enum CameraPerspectiveResolver {
    /// Apparent size must change by at least this factor to count as moving in depth.
    static let depthSizeRatio = 1.25
    /// Body lengths of horizontal travel that count as moving across the image.
    static let acrossTravel = 1.5

    /// Per-sample apparent body size: the torso length (shoulder midpoint to hip
    /// midpoint, aspect-corrected), which is visible from the side, behind and in front.
    static func apparentSize(_ sample: KickerPoseSample, aspect: Double) -> Double? {
        guard let ls = sample.point(.leftShoulder), let rs = sample.point(.rightShoulder),
              let lh = sample.point(.leftHip), let rh = sample.point(.rightHip) else { return nil }
        let d = hypot((ls.x + rs.x - lh.x - rh.x) / 2 * aspect, (ls.y + rs.y - lh.y - rh.y) / 2)
        return d > 0 ? d : nil
    }

    /// Torso length per sample, median-smoothed (radius 3) so single-frame jitter doesn't
    /// move per-frame normalization.
    static func frameScale(_ timeline: KickerPoseTimeline) -> [Double?] {
        let aspect = timeline.displayAspectRatio ?? 1
        let raw = timeline.samples.map { apparentSize($0, aspect: aspect) }
        return KickPhaseDetector.medianFilter(raw, radius: 3)
    }

    static func cues(_ timeline: KickerPoseTimeline) -> PerspectiveCues? {
        let aspect = timeline.displayAspectRatio ?? 1
        let scale = frameScale(timeline)
        let known = scale.compactMap { $0 }.sorted()
        guard known.count >= 10 else { return nil }
        let median = known[known.count / 2]
        let centers: [Double?] = timeline.samples.map { s in
            guard let l = s.point(.leftHip), let r = s.point(.rightHip) else { return nil }
            return (l.x + r.x) / 2 * aspect
        }
        let validCenters = centers.compactMap { $0 }
        guard let first = validCenters.first, let last = validCenters.last else { return nil }
        // Size at the start (first fifth of the known sizes), and the most extreme sizes
        // reached afterwards (the strike can be anywhere in the clip). `scale` is already
        // median-smoothed, so single-frame jitter can't make an extreme.
        let ordered = scale.compactMap { $0 }
        let head = Array(ordered.prefix(max(3, ordered.count / 5))).sorted()
        let headSize = head[head.count / 2]
        let tailMin = ordered.min() ?? headSize
        let tailMax = ordered.max() ?? headSize
        let shrink = headSize / max(tailMin, 1e-9)
        let grow = tailMax / max(headSize, 1e-9)
        let ratio = grow >= shrink ? grow : 1 / shrink
        let travel = abs(last - first) / median
        let inDepth = max(shrink, grow) >= depthSizeRatio
        let across = travel >= acrossTravel
        let observed: CameraPerspective?
        switch (inDepth, across) {
        case (true, true): observed = .oblique
        case (true, false): observed = ratio > 1 ? .depthToward : .depthAway
        case (false, true): observed = .side
        case (false, false): observed = nil
        }
        return PerspectiveCues(horizontalTravel: (travel * 1000).rounded() / 1000,
                               sizeRatio: (ratio * 1000).rounded() / 1000, observed: observed)
    }

    /// The perspective to analyze with. The selected camera angle is trusted unless the
    /// movement clearly contradicts it (e.g. "rear" chosen for a run across the frame);
    /// "unknown" uses the movement.
    static func resolve(declared: VideoAngleType, timeline: KickerPoseTimeline?) -> PerspectiveDecision {
        let cues = timeline.flatMap(cues)
        let fromAngle: CameraPerspective? = switch declared {
        case .side: .side
        case .rear: .depthAway
        case .front, .behindGoal: .depthToward
        case .oblique: .oblique
        case .unknown: nil
        }
        guard let fromAngle else {
            let used = cues?.observed ?? .side
            return PerspectiveDecision(declared: declared, used: used, cues: cues, declaredContradicted: false,
                                       explanation: cues?.observed == nil
                                           ? "Camera angle not set and the movement didn't show it; analyzed as a side view."
                                           : "Camera angle not set; the movement looks like a \(Self.name(used)), so it was analyzed as one.")
        }
        // A depth view contradicted by a clear run across the frame with no size change, or
        // a side view contradicted by a clear depth run with no horizontal travel.
        // A run-up filmed from behind or in front always changes the kicker's apparent
        // size; a clear run with no size change at all is a run across the frame.
        let observedForCheck: CameraPerspective? = {
            guard let c = cues else { return nil }
            if c.observed == nil, c.horizontalTravel >= 1.0, c.sizeRatio < 1.1, c.sizeRatio > 1 / 1.1 { return .side }
            return c.observed
        }()
        let contradicted: Bool = {
            guard let observed = observedForCheck else { return false }
            switch fromAngle {
            case .depthAway, .depthToward: return observed == .side
            case .side: return observed.isDepthView
            case .oblique: return false
            }
        }()
        if contradicted, let observed = observedForCheck {
            return PerspectiveDecision(declared: declared, used: observed, cues: cues, declaredContradicted: true,
                                       explanation: "The camera angle is set to \(declared.displayName), but the kicker's movement looks like a \(Self.name(observed)); analyzed as a \(Self.name(observed)). Check the camera angle on this video.")
        }
        return PerspectiveDecision(declared: declared, used: fromAngle, cues: cues, declaredContradicted: false,
                                   explanation: "Analyzed as a \(Self.name(fromAngle)) (camera angle: \(declared.displayName)).")
    }

    static func name(_ p: CameraPerspective) -> String {
        switch p {
        case .side: "side view"
        case .depthAway: "view from behind the kicker"
        case .depthToward: "view from in front of the kicker"
        case .oblique: "diagonal view"
        }
    }
}

/// Step 12E: left/right labels checked against which way the athlete faces.
///
/// Facing away from an unmirrored camera, the athlete's RIGHT side is on the image's
/// right; facing the camera it is on the image's left; a mirrored recording flips both.
/// Pose detection usually gets this right, but from behind it can label the body as if
/// it faced the camera — then every left/right label (and so the kicking leg) is swapped.
/// When shoulders AND hips contradict the expected side in most frames where they are
/// clearly apart, all left/right labels are exchanged for the whole clip. Side and
/// diagonal views can't be checked this way and are left unchanged.
struct LegIdentityCheck: Codable, Equatable, Sendable {
    enum Outcome: String, Codable, Sendable {
        case consistent
        /// Labels contradicted the facing direction and were exchanged.
        case swapped
        /// Too few frames with shoulders and hips clearly apart, or mixed evidence.
        case undetermined
        /// Side or diagonal view: facing can't be used.
        case notApplicable
    }

    var outcome: Outcome
    var framesChecked: Int
    /// Of the frames checked, the fraction whose labels matched the facing direction.
    var agreeingFraction: Double?
    var explanation: String

    static let minimumFrames = 10
    static let decisiveFraction = 0.7

    static let pairs: [(PoseJoint, PoseJoint)] = [
        (.leftShoulder, .rightShoulder), (.leftElbow, .rightElbow), (.leftWrist, .rightWrist),
        (.leftHip, .rightHip), (.leftKnee, .rightKnee), (.leftAnkle, .rightAnkle),
        (.leftEye, .rightEye), (.leftEar, .rightEar),
    ]

    static func check(_ timeline: KickerPoseTimeline, perspective: CameraPerspective, isMirrored: Bool) -> LegIdentityCheck {
        guard let facesAway = perspective.facesAwayFromCamera else {
            return LegIdentityCheck(outcome: .notApplicable, framesChecked: 0, agreeingFraction: nil,
                                    explanation: "Side or diagonal view: left/right labels can't be checked against the facing direction.")
        }
        // Expected sign of (right − left) in image x.
        let expected: Double = (facesAway != isMirrored) ? 1 : -1
        let aspect = timeline.displayAspectRatio ?? 1
        var agree = 0, disagree = 0
        for s in timeline.samples {
            guard let ls = s.point(.leftShoulder), let rs = s.point(.rightShoulder),
                  let lh = s.point(.leftHip), let rh = s.point(.rightHip) else { continue }
            let torso = hypot((ls.x + rs.x - lh.x - rh.x) / 2 * aspect, (ls.y + rs.y - lh.y - rh.y) / 2)
            guard torso > 0 else { continue }
            let shoulders = (rs.x - ls.x) * aspect / torso
            let hips = (rh.x - lh.x) * aspect / torso
            // Clearly apart: a turned body (shoulders or hips edge-on) proves nothing.
            guard abs(shoulders) >= 0.25, abs(hips) >= 0.15 else { continue }
            let s1 = shoulders * expected > 0, s2 = hips * expected > 0
            if s1 && s2 { agree += 1 } else if !s1 && !s2 { disagree += 1 }
        }
        let checked = agree + disagree
        guard checked >= minimumFrames else {
            return LegIdentityCheck(outcome: .undetermined, framesChecked: checked, agreeingFraction: nil,
                                    explanation: "Too few frames with shoulders and hips clearly apart to check left/right labels.")
        }
        let fraction = Double(agree) / Double(checked)
        let rounded = (fraction * 1000).rounded() / 1000
        if fraction >= decisiveFraction {
            return LegIdentityCheck(outcome: .consistent, framesChecked: checked, agreeingFraction: rounded,
                                    explanation: String(format: "Left/right labels match the facing direction in %.0f%% of %d frames.", fraction * 100, checked))
        }
        if 1 - fraction >= decisiveFraction {
            return LegIdentityCheck(outcome: .swapped, framesChecked: checked, agreeingFraction: rounded,
                                    explanation: String(format: "Left/right labels contradicted the facing direction in %.0f%% of %d frames (labeled as if the athlete faced the other way); all left/right labels were exchanged.", (1 - fraction) * 100, checked))
        }
        return LegIdentityCheck(outcome: .undetermined, framesChecked: checked, agreeingFraction: rounded,
                                explanation: String(format: "Left/right labels are mixed (%.0f%% match the facing direction); left unchanged.", fraction * 100))
    }

    /// Exchanges every left/right label in every sample.
    static func swapped(_ timeline: KickerPoseTimeline) -> KickerPoseTimeline {
        var t = timeline
        for i in t.samples.indices {
            for (l, r) in pairs {
                let a = t.samples[i].joints[l]
                t.samples[i].joints[l] = t.samples[i].joints[r]
                t.samples[i].joints[r] = a
            }
        }
        return t
    }
}
