import Foundation

/// Step 12F: reads the presentation timestamp of EVERY frame in a video, without
/// decoding images. Frame N is never assumed to sit at N ÷ frame rate: phones record
/// variable-frame-rate video, and the analysis itself uses true presentation times.
protocol SourceFrameTimestampReading: Sendable {
    func frameTimes(for url: URL) async throws -> [Double]
}

/// Where AVFoundation isn't available (Linux tests). Reports no frames.
struct UnavailableSourceFrameTimestampReader: SourceFrameTimestampReading {
    func frameTimes(for url: URL) async throws -> [Double] { [] }
}

/// The source video's frames as an ordered list of presentation times. Frame numbers
/// shown to the user are 1-based positions in this list.
struct SourceFrameTable: Equatable, Sendable {
    let times: [Double]

    init(times raw: [Double]) {
        times = Self.normalized(raw)
    }

    /// Sorted (decode order can differ from presentation order), finite, de-duplicated.
    static func normalized(_ raw: [Double]) -> [Double] {
        var out: [Double] = []
        for t in raw.filter(\.isFinite).sorted() where out.last.map({ t - $0 > 1e-6 }) ?? true {
            out.append(t)
        }
        return out
    }

    var count: Int { times.count }
    var isEmpty: Bool { times.isEmpty }

    func time(at index: Int) -> Double? { times.indices.contains(index) ? times[index] : nil }

    /// The frame shown at time `t`: the last frame presented at or before it (a frame
    /// stays on screen until the next one), or the first frame.
    func index(at t: Double) -> Int? {
        guard !times.isEmpty else { return nil }
        var lo = 0, hi = times.count - 1
        if t <= times[0] { return 0 }
        while lo < hi {
            let mid = (lo + hi + 1) / 2
            if times[mid] <= t + 1e-6 { lo = mid } else { hi = mid - 1 }
        }
        return lo
    }

    /// The frame whose presentation time is closest to `t` (for analysis times, which are
    /// themselves frame presentation times, rounded in exports).
    func nearestIndex(to t: Double) -> Int? {
        guard let i = index(at: t) else { return nil }
        if i + 1 < times.count, abs(times[i + 1] - t) < abs(times[i] - t) { return i + 1 }
        return i
    }

    func clamped(_ index: Int) -> Int { min(max(0, index), max(0, times.count - 1)) }

    /// Frames from `a` to `b` (positive when `b` is later).
    func frameDifference(from a: Double, to b: Double) -> Int? {
        guard let i = nearestIndex(to: a), let j = nearestIndex(to: b) else { return nil }
        return j - i
    }

    /// Median frame rate from the frame intervals.
    var medianFrameRate: Double? {
        let gaps = zip(times.dropFirst(), times).map { $0 - $1 }.filter { $0 > 0 }.sorted()
        guard !gaps.isEmpty else { return nil }
        return 1 / gaps[gaps.count / 2]
    }

    /// Frame intervals differ by more than 10% from the median somewhere.
    var isVariableFrameRate: Bool {
        let gaps = zip(times.dropFirst(), times).map { $0 - $1 }.filter { $0 > 0 }.sorted()
        guard let median = gaps.isEmpty ? nil : gaps[gaps.count / 2] else { return false }
        return gaps.contains { abs($0 - median) > 0.1 * median }
    }
}

/// Step 12F: the user's verified contact frame, as saved on the analyzed video.
enum ContactAnnotation: Equatable, Sendable {
    case none
    case contact(time: Double)
    case cannotTell
}

/// The automatic estimate next to the user's verification.
struct ContactVerificationComparison: Equatable, Sendable {
    var automaticTime: Double?
    var automaticInterval: ClosedRange<Double>?
    var userTime: Double?
    var frames: Int?
    var seconds: Double?

    /// "Your frame is 5 frames (0.167 s) earlier than the automatic estimate."
    var text: String {
        guard let user = userTime else { return "No contact frame verified yet." }
        guard let auto = automaticTime else {
            return String(format: "Your frame: %.3f s. This analysis has no automatic estimate to compare.", user)
        }
        guard let seconds else { return "" }
        if abs(seconds) < 1e-4 || frames == 0 { return "Your frame matches the automatic estimate." }
        let direction = seconds < 0 ? "earlier" : "later"
        let frameText = frames.map { "\(abs($0)) frame\(abs($0) == 1 ? "" : "s") " } ?? ""
        var s = String(format: "Your frame is %@(%.3f s) %@ than the automatic estimate (%.3f s).", frameText, abs(seconds), direction, auto)
        if let range = automaticInterval, range.contains(user) || abs(range.lowerBound - user) < 1e-4 || abs(range.upperBound - user) < 1e-4 {
            s += " It is inside the automatic uncertainty interval."
        }
        return s
    }

    static func make(automatic: Double?, interval: ClosedRange<Double>?, annotation: ContactAnnotation, table: SourceFrameTable) -> ContactVerificationComparison {
        guard case .contact(let user) = annotation else {
            return ContactVerificationComparison(automaticTime: automatic, automaticInterval: interval, userTime: nil, frames: nil, seconds: nil)
        }
        let seconds = automatic.map { user - $0 }
        let frames = automatic.flatMap { table.frameDifference(from: $0, to: user) }
        return ContactVerificationComparison(automaticTime: automatic, automaticInterval: interval, userTime: user, frames: frames, seconds: seconds)
    }
}
