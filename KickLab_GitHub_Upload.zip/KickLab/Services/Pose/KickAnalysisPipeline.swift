import Foundation

/// Inputs to the pure part of the analysis, after pose detection.
struct KickAnalysisPipelineInput: Sendable {
    /// Pose detection output (track IDs not yet assigned).
    var sequence: PoseSequence
    var kickType: KickType
    var kickingFoot: KickingFoot
    var kickerSeed: KickerSeed?
    var kickLocationHint: NormalizedPoint?
    var tracking: PoseTrackingConfiguration
    var processing: PoseProcessingConfiguration
    /// Camera position of the analyzed video (affects biomechanics confidence).
    var cameraAngle: VideoAngleType
    /// Supplies the biomechanics thresholds for this kick.
    var profiles: any BiomechanicsProfileProviding
    /// Seeds deterministic coaching-observation IDs (use the analysis or request ID).
    var idSeed: UUID
    /// Step 12D: user-supplied contact frame or kick interval (nil = automatic).
    var assistance: PhaseDetectionAssistance?
    /// Step 12F: the football tracker's result (unavailable in the shipping app).
    var ball: BallTrackingResult = .unavailable

    init(
        sequence: PoseSequence,
        kickType: KickType,
        kickingFoot: KickingFoot,
        kickerSeed: KickerSeed? = nil,
        kickLocationHint: NormalizedPoint? = nil,
        tracking: PoseTrackingConfiguration = .standard,
        processing: PoseProcessingConfiguration = .standard,
        cameraAngle: VideoAngleType = .side,
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles(),
        idSeed: UUID = UUID(uuid: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
        assistance: PhaseDetectionAssistance? = nil,
        ball: BallTrackingResult = .unavailable
    ) {
        self.sequence = sequence
        self.kickType = kickType
        self.kickingFoot = kickingFoot
        self.kickerSeed = kickerSeed
        self.kickLocationHint = kickLocationHint
        self.tracking = tracking
        self.processing = processing
        self.cameraAngle = cameraAngle
        self.profiles = profiles
        self.idSeed = idSeed
        self.assistance = assistance
        self.ball = ball
    }
}

struct KickAnalysisPipelineOutput: Equatable, Sendable {
    /// Tracked sequence with `kickerTrackID` set when a kicker was selected.
    var sequence: PoseSequence
    var tracking: KickerTrackingResult
    /// The processed kicker timeline (nil without a kicker).
    var kickerTimeline: KickerPoseTimeline?
    var signals: PoseSignalSet
    var phases: KickPhaseDetectionResult
    /// 0...1: how much usable pose data was extracted for the kicker.
    var extractionConfidence: Double
    /// Step 8: metrics, category scores and coaching findings.
    var biomechanics: KickBiomechanicsResult
    /// Step 12B: leg-label swaps and jumps repaired during processing.
    var repair: PoseRepairReport = .none
    /// Step 12D: recording-suitability findings (guidance, never a score input).
    var suitability: [SuitabilityFinding] = []
    /// Step 12E: the camera perspective analyzed with, the left/right label check, every
    /// checkpoint of the run, and whether it stands as a completed analysis.
    var perspective: PerspectiveDecision? = nil
    var legIdentity: LegIdentityCheck? = nil
    var gates: [AnalysisGate] = []
    var completionBasis: AnalysisCompletion.Basis = .insufficient
    /// Step 12E
    var outcome: AnalysisOutcome = .insufficientEvidence
}

/// Operational facts about a pose run, returned with the analysis result. These are
/// NOT biomechanics metrics or scores; they describe whether the foundation worked.
struct PoseAnalysisSummary: Codable, Equatable, Sendable {
    var primaryVideoID: UUID
    var kickerStatus: KickerSelectionStatus
    var kickerSelectionMethod: KickerSelectionMethod
    var kickerTrackConfidence: Double
    var candidateCount: Int
    var extractionConfidence: Double
    var phaseSupport: KickPhaseSupport
    var phaseConfidence: Double
    var plantTime: Double?
    var estimatedContactTime: Double?
    var analyzedFrameCount: Int
    var droppedFrameCount: Int
    var framesWithKicker: Int
    /// Step 8: metrics that could be measured, and categories that could be scored.
    var availableMetricCount: Int
    var scoredCategoryCount: Int
    /// Step 12A: why nothing could be scored (nil when something was, or no kicker).
    var failureCause: AnalysisFailureCause?
    /// Step 12D
    var isUserAssisted: Bool = false
    var contactStatus: PhaseDetectionStatus?
    var kickWindowCount: Int?
    var needsKickSelection: Bool = false
    var suitability: [SuitabilityFinding] = []
    /// Step 12E
    var perspective: CameraPerspective?
    var completionBasis: AnalysisCompletion.Basis?
    var gates: [AnalysisGate]?
    /// Step 12E
    var outcome: AnalysisOutcome?

    init(primaryVideoID: UUID, output: KickAnalysisPipelineOutput) {
        let stats = output.sequence.confidenceStatistics
        self.primaryVideoID = primaryVideoID
        kickerStatus = output.tracking.status
        kickerSelectionMethod = output.tracking.method
        kickerTrackConfidence = output.tracking.confidence
        candidateCount = output.tracking.candidates.count
        extractionConfidence = output.extractionConfidence
        phaseSupport = output.phases.support
        phaseConfidence = output.phases.overallConfidence
        plantTime = output.phases.plantTime
        estimatedContactTime = output.phases.estimatedContactTime
        analyzedFrameCount = stats.frameCount - stats.droppedFrameCount
        droppedFrameCount = stats.droppedFrameCount
        framesWithKicker = stats.framesWithKicker
        availableMetricCount = output.biomechanics.availableMetricCount
        scoredCategoryCount = output.biomechanics.availableCategoryCount
        failureCause = output.failureCause
        isUserAssisted = output.phases.isUserAssisted
        contactStatus = output.phases.phase(.contact).status
        kickWindowCount = output.phases.kickWindows.map { $0.windows.filter(\.hasSwing).count }
        needsKickSelection = output.phases.kickWindows?.needsSelection ?? false
        suitability = output.suitability
        perspective = output.perspective?.used
        completionBasis = output.completionBasis
        gates = output.gates
        outcome = output.outcome
    }
}

/// The pure analysis chain: tracking → kicker timeline → processing → signals → phases
/// → biomechanics (metrics, scores, coaching).
/// Deterministic and platform-independent, so it is fully tested on synthetic data.
enum KickAnalysisPipeline {
    static func run(_ input: KickAnalysisPipelineInput) -> KickAnalysisPipelineOutput {
        var sequence = input.sequence
        let aspect = sequence.displayAspectRatio
        let tracked = PoseTracker.assignTracks(sequence.frames, aspectRatio: aspect, configuration: input.tracking)
        sequence.frames = tracked.frames

        let tracking = PoseTracker.selectKicker(
            frames: tracked.frames, tracks: tracked.tracks, seed: input.kickerSeed,
            kickLocationHint: input.kickLocationHint, aspectRatio: aspect, configuration: input.tracking
        )

        var context = BiomechanicsContext(kickType: input.kickType, kickingFoot: input.kickingFoot, cameraAngle: input.cameraAngle)

        guard let kickerID = tracking.selectedTrackID else {
            sequence.kickerTrackID = nil
            let signals = PoseSignalSet(timestamps: [], series: [:], travelDirection: 0, kickingFoot: input.kickingFoot)
            let phases = KickPhaseDetectionResult.unavailable(
                kickType: input.kickType, support: KickPhaseProfile.for(input.kickType).support,
                coverage: 0, notes: [tracking.message]
            )
            var output = KickAnalysisPipelineOutput(
                sequence: sequence, tracking: tracking, kickerTimeline: nil,
                signals: signals, phases: phases, extractionConfidence: 0,
                biomechanics: KickBiomechanicsAnalyzer.analyze(
                    timeline: nil, signals: signals, phases: phases, context: context,
                    profiles: input.profiles, idSeed: input.idSeed
                ),
                suitability: RecordingSuitability.assess(sequence: sequence, kickerTimeline: nil, signals: nil,
                                                         cameraAngle: input.cameraAngle, phases: nil)
            )
            output.gates = AnalysisGates.make(sequence: sequence, tracking: tracking, perspective: nil, legIdentity: nil, timeline: nil,
                                              kickingFoot: input.kickingFoot, phases: nil, measurements: nil, scoredCategoryCount: nil,
                                              completion: (.insufficient, tracking.message))
            return output
        }
        sequence.kickerTrackID = kickerID

        let prepared = prepare(sequence: sequence, kickerID: kickerID, cameraAngle: input.cameraAngle,
                               processing: input.processing, kickingFoot: input.kickingFoot)
        let processed = prepared.processed, repair = prepared.repair, signals = prepared.signals
        context.perspective = prepared.perspective.used
        let posePhases = KickPhaseDetector.detect(signals, kickType: input.kickType, assistance: input.assistance,
                                                  perspective: prepared.perspective.used)
        // Step 12F: ball-aware verification (records "unavailable" when no tracker ran).
        let phases = BallContactFusion.apply(posePhases, ball: input.ball, timeline: processed, kickingFoot: input.kickingFoot)

        let stats = sequence.confidenceStatistics
        let analyzed = max(stats.frameCount - stats.droppedFrameCount, 0)
        let presence = stats.frameCount == 0 ? 0 : Double(stats.framesWithKicker) / Double(stats.frameCount)
        let extraction = analyzed == 0 ? 0 : min(1, presence * (stats.meanKickerConfidence ?? 0))

        let biomechanics = KickBiomechanicsAnalyzer.analyze(
            timeline: processed, signals: signals, phases: phases, context: context,
            profiles: input.profiles, idSeed: input.idSeed
        )
        var suitability = RecordingSuitability.assess(sequence: sequence, kickerTimeline: processed, signals: signals,
                                                      cameraAngle: input.cameraAngle, phases: phases)
        if prepared.perspective.declaredContradicted {
            suitability.insert(SuitabilityFinding(kind: .cameraAngle, severity: .limiting, message: prepared.perspective.explanation), at: 0)
        }
        let completion = AnalysisCompletion.evaluate(
            kickerSelected: true, perspective: prepared.perspective.used, phases: phases,
            availableMetricCount: biomechanics.availableMetricCount, scoredCategoryCount: biomechanics.availableCategoryCount
        )
        var output = KickAnalysisPipelineOutput(
            sequence: sequence, tracking: tracking, kickerTimeline: processed,
            signals: signals, phases: phases, extractionConfidence: extraction, biomechanics: biomechanics,
            repair: repair, suitability: suitability
        )
        output.perspective = prepared.perspective
        output.legIdentity = prepared.legIdentity
        output.completionBasis = completion.basis
        output.outcome = AnalysisOutcome.classify(
            kickerSelected: true, completion: completion.basis, phases: phases,
            availableMetricCount: biomechanics.availableMetricCount, kickingAnkleCoverage: phases.dataCoverage
        )
        output.gates = AnalysisGates.make(
            sequence: sequence, tracking: tracking, perspective: prepared.perspective, legIdentity: prepared.legIdentity,
            timeline: processed, kickingFoot: input.kickingFoot, phases: phases, measurements: biomechanics.measurements,
            scoredCategoryCount: biomechanics.availableCategoryCount, completion: completion
        )
        return output
    }

    /// Step 12E: the camera-aware preparation shared by analysis and diagnostics replay:
    /// kicker timeline → perspective (selected angle checked against the movement) →
    /// left/right labels checked against the facing direction (behind / in front) →
    /// processing → signals for that perspective.
    struct Prepared {
        var raw: KickerPoseTimeline
        var processed: KickerPoseTimeline
        var repair: PoseRepairReport
        var signals: PoseSignalSet
        var perspective: PerspectiveDecision
        var legIdentity: LegIdentityCheck
    }

    static func prepare(sequence: PoseSequence, kickerID: Int, cameraAngle: VideoAngleType,
                        processing: PoseProcessingConfiguration, kickingFoot: KickingFoot) -> Prepared {
        var raw = KickerPoseTimeline.make(from: sequence.frames, trackID: kickerID, displayAspectRatio: sequence.displayAspectRatio)
        let perspective = CameraPerspectiveResolver.resolve(declared: cameraAngle, timeline: raw)
        let identity = LegIdentityCheck.check(raw, perspective: perspective.used, isMirrored: sequence.isMirrored)
        if identity.outcome == .swapped { raw = LegIdentityCheck.swapped(raw) }
        let (processed, repair) = PoseTimelineProcessor.processWithReport(raw, configuration: processing, perspective: perspective.used)
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: kickingFoot, perspective: perspective.used)
        return Prepared(raw: raw, processed: processed, repair: repair, signals: signals, perspective: perspective, legIdentity: identity)
    }
}
