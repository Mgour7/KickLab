import Foundation

/// Inputs to the pure part of the analysis, after pose detection.
struct KickAnalysisPipelineInput: Sendable {
    /// Pose detection output (track IDs not yet assigned).
    var sequence: PoseSequence
    var kickType: KickType
    var kickingFoot: KickingFoot
    var kickerSeed: KickerSeed?
    var kickLocationHint: NormalizedPoint?
    var tracking: PoseTrackingConfiguration
    var processing: PoseProcessingConfiguration

    init(
        sequence: PoseSequence,
        kickType: KickType,
        kickingFoot: KickingFoot,
        kickerSeed: KickerSeed? = nil,
        kickLocationHint: NormalizedPoint? = nil,
        tracking: PoseTrackingConfiguration = .standard,
        processing: PoseProcessingConfiguration = .standard
    ) {
        self.sequence = sequence
        self.kickType = kickType
        self.kickingFoot = kickingFoot
        self.kickerSeed = kickerSeed
        self.kickLocationHint = kickLocationHint
        self.tracking = tracking
        self.processing = processing
    }
}

struct KickAnalysisPipelineOutput: Equatable, Sendable {
    /// Tracked sequence with `kickerTrackID` set when a kicker was selected.
    var sequence: PoseSequence
    var tracking: KickerTrackingResult
    /// The processed kicker timeline (nil without a kicker).
    var kickerTimeline: KickerPoseTimeline?
    var signals: PoseSignalSet
    var phases: KickPhaseDetectionResult
    /// 0...1: how much usable pose data was extracted for the kicker.
    var extractionConfidence: Double
}

/// Operational facts about a pose run, returned with the analysis result. These are
/// NOT biomechanics metrics or scores; they describe whether the foundation worked.
struct PoseAnalysisSummary: Codable, Equatable, Sendable {
    var primaryVideoID: UUID
    var kickerStatus: KickerSelectionStatus
    var kickerSelectionMethod: KickerSelectionMethod
    var kickerTrackConfidence: Double
    var candidateCount: Int
    var extractionConfidence: Double
    var phaseSupport: KickPhaseSupport
    var phaseConfidence: Double
    var plantTime: Double?
    var estimatedContactTime: Double?
    var analyzedFrameCount: Int
    var droppedFrameCount: Int
    var framesWithKicker: Int

    init(primaryVideoID: UUID, output: KickAnalysisPipelineOutput) {
        let stats = output.sequence.confidenceStatistics
        self.primaryVideoID = primaryVideoID
        kickerStatus = output.tracking.status
        kickerSelectionMethod = output.tracking.method
        kickerTrackConfidence = output.tracking.confidence
        candidateCount = output.tracking.candidates.count
        extractionConfidence = output.extractionConfidence
        phaseSupport = output.phases.support
        phaseConfidence = output.phases.overallConfidence
        plantTime = output.phases.plantTime
        estimatedContactTime = output.phases.estimatedContactTime
        analyzedFrameCount = stats.frameCount - stats.droppedFrameCount
        droppedFrameCount = stats.droppedFrameCount
        framesWithKicker = stats.framesWithKicker
    }
}

/// The pure analysis chain: tracking → kicker timeline → processing → signals → phases.
/// Deterministic and platform-independent, so it is fully tested on synthetic data.
enum KickAnalysisPipeline {
    static func run(_ input: KickAnalysisPipelineInput) -> KickAnalysisPipelineOutput {
        var sequence = input.sequence
        let aspect = sequence.displayAspectRatio
        let tracked = PoseTracker.assignTracks(sequence.frames, aspectRatio: aspect, configuration: input.tracking)
        sequence.frames = tracked.frames

        let tracking = PoseTracker.selectKicker(
            frames: tracked.frames, tracks: tracked.tracks, seed: input.kickerSeed,
            kickLocationHint: input.kickLocationHint, aspectRatio: aspect, configuration: input.tracking
        )

        guard let kickerID = tracking.selectedTrackID else {
            sequence.kickerTrackID = nil
            return KickAnalysisPipelineOutput(
                sequence: sequence, tracking: tracking, kickerTimeline: nil,
                signals: PoseSignalSet(timestamps: [], series: [:], travelDirection: 0, kickingFoot: input.kickingFoot),
                phases: .unavailable(kickType: input.kickType, support: KickPhaseProfile.for(input.kickType).support,
                                     coverage: 0, notes: [tracking.message]),
                extractionConfidence: 0
            )
        }
        sequence.kickerTrackID = kickerID

        let raw = KickerPoseTimeline.make(from: sequence.frames, trackID: kickerID, displayAspectRatio: aspect)
        let processed = PoseTimelineProcessor.process(raw, configuration: input.processing)
        let signals = PoseSignalExtractor.extract(from: processed, kickingFoot: input.kickingFoot)
        let phases = KickPhaseDetector.detect(signals, kickType: input.kickType)

        let stats = sequence.confidenceStatistics
        let analyzed = max(stats.frameCount - stats.droppedFrameCount, 0)
        let presence = stats.frameCount == 0 ? 0 : Double(stats.framesWithKicker) / Double(stats.frameCount)
        let extraction = analyzed == 0 ? 0 : min(1, presence * (stats.meanKickerConfidence ?? 0))

        return KickAnalysisPipelineOutput(
            sequence: sequence, tracking: tracking, kickerTimeline: processed,
            signals: signals, phases: phases, extractionConfidence: extraction
        )
    }
}
