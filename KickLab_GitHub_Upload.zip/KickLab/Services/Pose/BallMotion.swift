import Foundation

/// Step 12G: an 8-bit grayscale image (a crop of a video frame's luma plane).
struct LumaImage: Equatable, Sendable {
    var width: Int
    var height: Int
    var pixels: [UInt8]

    init(width: Int, height: Int, pixels: [UInt8]) {
        precondition(pixels.count == width * height, "pixel count must match size")
        self.width = width
        self.height = height
        self.pixels = pixels
    }

    subscript(x: Int, y: Int) -> UInt8 { pixels[y * width + x] }
}

/// Step 12G: what the ball did, measured from the video's own frames after the user
/// located the ball once. This is image analysis of real frames — NOT football
/// recognition: the user says where the ball is; the app measures when it leaves.
struct BallMotionResult: Codable, Equatable, Sendable {
    enum Outcome: String, Codable, Sendable {
        /// The ball was clearly at rest, then was disturbed and never came back.
        case departed
        /// The ball never left its spot in the examined frames.
        case neverMoved
        /// The ball wasn't clearly visible at rest at the start (wrong tap, blur, occluded).
        case notFoundAtRest
        /// The spot changed and recovered repeatedly (people walking past, camera shake).
        case unstable
    }

    var outcome: Outcome
    var framesExamined: Int
    /// Last frame where the ball matched its resting appearance.
    var lastAtRestTime: Double?
    /// First frame where the resting ball was disturbed (foot over it, or moving).
    var firstDisturbedTime: Double?
    /// First frame of the persistent absence that confirms the ball left.
    var departureConfirmedTime: Double?
    /// Per-frame similarity to the resting ball (0…1), for diagnostics.
    var scores: [Double]
    var times: [Double]
    var note: String

    /// The contact interval the frames support: after the last at-rest frame and no
    /// later than the first disturbed frame.
    var contactInterval: ClosedRange<Double>? {
        guard outcome == .departed, let a = lastAtRestTime, let b = firstDisturbedTime, a < b else { return nil }
        return a...b
    }
}

/// Step 12G: finds when a placed football leaves its spot, from real frames.
///
/// The user taps the ball on a frame before the kick. A template of the ball is cut from
/// that frame; every later frame is searched near the resting position (tolerating small
/// camera drift) with normalized cross-correlation. The ball is AT REST while the best
/// match is strong; it is DISTURBED once the match drops; it has DEPARTED when the match
/// stays low for several frames and never recovers. Only the region around the tapped
/// ball is examined, so spare footballs elsewhere in the frame can't be confused with it.
enum BallMotionTracker {
    static let restThreshold = 0.75
    static let disturbedThreshold = 0.65
    /// Consecutive low frames that confirm departure.
    static let persistenceFrames = 3
    /// How far (in ball radii) the resting ball may appear to shift between frames
    /// (camera drift) and still count as the same resting ball.
    static let restDriftFraction = 0.35

    /// - Parameters:
    ///   - frames: crops, in time order, all the same size and centered on the tapped ball.
    ///   - referenceIndex: the frame the user tapped on (ball at rest, unobstructed).
    ///   - ballRadius: the ball's radius in crop pixels.
    static func analyze(_ frames: [(time: Double, image: LumaImage)], referenceIndex: Int, ballRadius: Double) -> BallMotionResult {
        let times = frames.map(\.time)
        func result(_ o: BallMotionResult.Outcome, _ scores: [Double], _ note: String,
                    rest: Double? = nil, disturbed: Double? = nil, departed: Double? = nil) -> BallMotionResult {
            BallMotionResult(outcome: o, framesExamined: frames.count, lastAtRestTime: rest, firstDisturbedTime: disturbed,
                             departureConfirmedTime: departed, scores: scores.map { ($0 * 1000).rounded() / 1000 }, times: times, note: note)
        }
        guard frames.indices.contains(referenceIndex), ballRadius >= 3 else {
            return result(.notFoundAtRest, [], "The ball location wasn't usable.")
        }
        let ref = frames[referenceIndex].image
        let r = Int(ballRadius.rounded())
        let cx = ref.width / 2, cy = ref.height / 2
        guard let template = patch(ref, cx - r, cy - r, 2 * r, 2 * r), variance(template) > 4 else {
            return result(.notFoundAtRest, [], "The tapped spot has no visible detail; tap the center of the ball.")
        }
        // The ball is "at rest" only within a small radius of where it rested (camera drift
        // between frames is small); the center follows drift only while the ball clearly
        // matches, so a ball that is kicked away is never "followed".
        let search = max(1, Int((ballRadius * restDriftFraction).rounded()))
        var center = (x: cx, y: cy)
        var scores: [Double] = []
        for f in frames {
            var best = -1.0, bestAt = center
            for dy in -search...search {
                for dx in -search...search {
                    let x = center.x + dx - r, y = center.y + dy - r
                    guard let p = patch(f.image, x, y, 2 * r, 2 * r) else { continue }
                    let s = ncc(template, p)
                    if s > best { best = s; bestAt = (center.x + dx, center.y + dy) }
                }
            }
            scores.append(max(0, best))
            if best >= restThreshold { center = bestAt }
        }
        guard scores[referenceIndex] >= restThreshold else {
            return result(.notFoundAtRest, scores, "The ball wasn't clearly visible at the tapped spot.")
        }
        // Departure: the first run of ≥ persistence low frames after the reference that is
        // never followed by a return to rest.
        var departureStart: Int?
        var i = referenceIndex + 1
        while i < scores.count {
            if scores[i] < disturbedThreshold {
                var j = i
                while j < scores.count, scores[j] < restThreshold { j += 1 }
                let lowRun = (i..<j).filter { scores[$0] < disturbedThreshold }.count
                if j == scores.count, lowRun >= persistenceFrames {
                    departureStart = i
                    break
                }
                i = j
            } else {
                i += 1
            }
        }
        guard let start = departureStart else {
            let dips = scores[referenceIndex...].filter { $0 < disturbedThreshold }.count
            return dips > 0
                ? result(.unstable, scores, "The ball spot was disturbed and then looked normal again; no lasting departure.")
                : result(.neverMoved, scores, "The ball stayed in place in the examined frames.")
        }
        guard let lastRest = (referenceIndex..<start).last(where: { scores[$0] >= restThreshold }) else {
            return result(.unstable, scores, "The ball wasn't clearly at rest just before it left.")
        }
        let disturbed = lastRest + 1
        let confirm = (disturbed..<scores.count).first { k in
            k + persistenceFrames <= scores.count && (k..<(k + persistenceFrames)).allSatisfy { scores[$0] < disturbedThreshold }
        }
        return result(.departed, scores,
                      String(format: "The ball matched its resting look through %.3f s, was disturbed at %.3f s and didn't return.",
                             times[lastRest], times[disturbed]),
                      rest: times[lastRest], disturbed: times[disturbed], departed: confirm.map { times[$0] })
    }

    static func patch(_ img: LumaImage, _ x: Int, _ y: Int, _ w: Int, _ h: Int) -> [Double]? {
        guard x >= 0, y >= 0, x + w <= img.width, y + h <= img.height else { return nil }
        var out = [Double]()
        out.reserveCapacity(w * h)
        for yy in y..<(y + h) {
            let row = yy * img.width
            for xx in x..<(x + w) { out.append(Double(img.pixels[row + xx])) }
        }
        return out
    }

    static func variance(_ p: [Double]) -> Double {
        let m = p.reduce(0, +) / Double(p.count)
        return p.reduce(0) { $0 + ($1 - m) * ($1 - m) } / Double(p.count)
    }

    /// Zero-mean normalized cross-correlation of two equal-size patches (−1…1).
    static func ncc(_ a: [Double], _ b: [Double]) -> Double {
        let n = Double(a.count)
        let ma = a.reduce(0, +) / n, mb = b.reduce(0, +) / n
        var num = 0.0, da = 0.0, db = 0.0
        for k in a.indices {
            let x = a[k] - ma, y = b[k] - mb
            num += x * y
            da += x * x
            db += y * y
        }
        guard da > 0, db > 0 else { return 0 }
        return num / (da * db).squareRoot()
    }

    /// Converts a ball result into the observations the existing fusion understands
    /// (`.tracked` at rest; `.lost` once disturbed). The position is the tapped point.
    static func observations(_ r: BallMotionResult, at point: NormalizedPoint, radius: Double) -> BallTrackingResult {
        guard r.outcome == .departed, let lastRest = r.lastAtRestTime else { return .unavailable }
        let obs = zip(r.times, r.scores).map { t, s -> BallObservation in
            let atRest = t <= lastRest + 1e-9 && s >= restThreshold
            return BallObservation(timestamp: t, position: atRest ? point : nil, radius: atRest ? radius : nil,
                                   confidence: s, status: atRest ? .tracked : .lost)
        }
        return BallTrackingResult(status: .tracked, observations: obs, launchTime: r.firstDisturbedTime)
    }
}
