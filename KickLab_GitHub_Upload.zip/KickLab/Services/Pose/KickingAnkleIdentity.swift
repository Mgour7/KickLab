import Foundation

/// Build 19 (engine 3.1.0): is the KICKING-ANKLE label still on the kicking foot after the
/// strike, and when does a lost foot come back?
///
/// Root cause found on the real side reference clip (6.502 s; Apple Vision series exported
/// from the iPhone, `RealReferenceClip220`): the kicking ankle peaked at 18.8 torso
/// lengths/s at 2.333 s, then fell to 12.5 and 3.2 in the next two frames and stayed level
/// with the plant ankle until ≈ 3.0 s — while the football was still at rest until 2.467 s.
/// A foot about to strike a ball can't lose three quarters of its speed in one frame:
/// Vision had put BOTH ankle labels on the visible plant foot (motion blur at 30 fps). The
/// Step 12E merge rule (≥ 80% of 0.3 s within 0.12 torso lengths, starting AFTER contact)
/// missed it because the collapse began before contact and wobbled, so the follow-through
/// search saw the label's sudden stop as the foot "slowing down too soon".
///
/// Rule (all three required, so a normal foot passing the plant foot never qualifies):
/// 1. coincidence: the two ankles within `ankleCollapseDistance` (straight line), or, for
///    older signal files, within `aheadTolerance` along the run;
/// 2. an abrupt stop into it: within two frames the speed falls from ≥ 50% of the strike
///    peak to ≤ 35% of it;
/// 3. persistence: coincident on ≥ 60% of the following 0.2 s.
enum KickingAnkleIdentity {
    static let aheadTolerance = 0.15
    static let fastFraction = 0.5
    static let stoppedFraction = 0.35
    static let persistenceSeconds = 0.2
    static let persistenceShare = 0.6
    /// A lost foot "reappears" when it is apart from the plant foot for this many frames in a row.
    static let reappearFrames = 3
    /// …and only within this long after contact (later, it is recovery, not follow-through).
    static let reappearWithinSeconds = 0.5

    static func coincident(_ i: Int, separation: [Double?], ahead: [Double?]) -> Bool? {
        if separation.indices.contains(i), let s = separation[i] { return s <= KickPhaseDetector.ankleCollapseDistance }
        if ahead.indices.contains(i), let a = ahead[i] { return abs(a) <= aheadTolerance }
        return nil
    }

    /// The first frame of the label collapse after the strike peak (nil: identity kept).
    static func collapseOnset(speed: [Double?], separation: [Double?], ahead: [Double?], times: [Double],
                              peakIndex: Int, peak: Double, searchSeconds: Double = 0.3) -> Int? {
        guard peak > 0, times.indices.contains(peakIndex) else { return nil }
        let end = times[peakIndex] + searchSeconds + 1e-9
        var i = peakIndex + 1
        while i < times.count, times[i] <= end {
            defer { i += 1 }
            guard let v = speed[i], v <= stoppedFraction * peak else { continue }
            // An abrupt stop: fast within the two previous frames.
            let fastBefore = [i - 1, i - 2].contains { j in j >= peakIndex && (speed[j] ?? 0) >= fastFraction * peak }
            guard fastBefore else { continue }
            // The coincident run containing the stop; the onset is its first frame.
            guard coincident(i, separation: separation, ahead: ahead) == true else { continue }
            var start = i
            while start - 1 > peakIndex, coincident(start - 1, separation: separation, ahead: ahead) == true { start -= 1 }
            let following = times.indices.filter { times[$0] >= times[start] - 1e-9 && times[$0] <= times[start] + persistenceSeconds + 1e-9 }
            let states = following.compactMap { coincident($0, separation: separation, ahead: ahead) }
            guard states.count >= 4, Double(states.filter { $0 }.count) >= persistenceShare * Double(states.count) else { continue }
            return start
        }
        return nil
    }

    /// The first frame after `lostFrom` where the kicking foot is apart from the plant foot
    /// for `reappearFrames` frames in a row, within `reappearWithinSeconds` of contact.
    static func reappearance(separation: [Double?], ahead: [Double?], times: [Double], lostFrom: Int, contactTime: Double) -> Int? {
        var i = lostFrom + 1
        while i + reappearFrames - 1 < times.count, times[i] - contactTime <= reappearWithinSeconds + 1e-9 {
            let run = (i..<(i + reappearFrames)).map { coincident($0, separation: separation, ahead: ahead) }
            if run.allSatisfy({ $0 == false }) { return i }
            i += 1
        }
        return nil
    }

    /// Follow-through end after a lost-and-reappeared kicking foot: the endpoint (the foot
    /// slowing to the end fraction of its strike peak) must be SEEN after reappearance, and
    /// the foot must still be moving at ≥ 50% of the peak just after it reappears — otherwise it
    /// may have slowed while hidden, and nothing is reported.
    static func endAfterReappearance(speed: [Double?], times: [Double], reappeared r: Int, peak: Double,
                                     endFraction: Double, contactTime: Double) -> Int? {
        // Judged one frame AFTER reappearance: the reappearing frame's speed contains the
        // label's jump back to the foot.
        guard r + 1 < times.count, let v = speed[r + 1], v >= fastFraction * peak else { return nil }
        var i = r + 2
        while i < times.count, times[i] - contactTime <= 0.8 + 1e-9 {
            if let s = speed[i], s <= endFraction * peak {
                let confirmed = i + 1 >= times.count || (speed[i + 1].map { $0 <= endFraction * peak * 1.4 } ?? false)
                if confirmed { return i }
            }
            i += 1
        }
        return nil
    }
}

/// Build 19: how much of the follow-through was actually observed.
enum FollowThroughObservation: String, Codable, Sendable {
    /// The kicking foot was followed from contact to the end of its swing.
    case observed
    /// The foot was hidden for part of the swing but its end was seen (or the clip ended
    /// during the swing).
    case partiallyObserved
    /// Timed from another joint (the kicking knee) with limited evidence; ankle-based
    /// values stay unavailable.
    case inferredLimited
    case unavailable

    var title: String {
        switch self {
        case .observed: "Follow-through observed"
        case .partiallyObserved: "Follow-through partly observed"
        case .inferredLimited: "Follow-through inferred from the knee (limited)"
        case .unavailable: "Follow-through not observed"
        }
    }
}
