import Foundation

/// How a stored video must be rotated to display upright. Mirrors the meaning of
/// `CGImagePropertyOrientation` (.up/.right/.down/.left) without depending on it.
enum VideoOrientation: String, Codable, Sendable, CaseIterable {
    /// No rotation.
    case up
    /// Rotate 90° clockwise (typical iPhone portrait recording).
    case right
    /// Rotate 180°.
    case down
    /// Rotate 90° counter-clockwise.
    case left
}

/// The four values of a 2D affine transform's linear part (a, b, c, d), as in
/// `CGAffineTransform`. Kept separate so orientation logic is platform-independent.
struct AffineTransformValues: Equatable, Sendable {
    var a: Double
    var b: Double
    var c: Double
    var d: Double

    init(a: Double, b: Double, c: Double, d: Double) {
        self.a = a
        self.b = b
        self.c = c
        self.d = d
    }
}

enum PoseCoordinates {
    // MARK: Orientation

    /// The orientation (and mirroring) encoded by a video track's preferred transform.
    /// Rotation is snapped to the nearest 90°; a negative determinant means mirrored.
    static func orientation(from transform: AffineTransformValues) -> (orientation: VideoOrientation, isMirrored: Bool) {
        let isMirrored = (transform.a * transform.d - transform.b * transform.c) < 0
        // For a mirrored transform, undo the horizontal flip before reading the rotation.
        let a = isMirrored ? -transform.a : transform.a
        let b = isMirrored ? -transform.b : transform.b
        var degrees = atan2(b, a) * 180 / .pi
        if degrees < 0 { degrees += 360 }
        let quarterTurns = Int((degrees / 90).rounded()) % 4
        let orientation: VideoOrientation = switch quarterTurns {
        case 1: .right
        case 2: .down
        case 3: .left
        default: .up
        }
        return (orientation, isMirrored)
    }

    /// Converts a point given in the STORED frame (top-left origin, before rotation) into
    /// app-normalized upright coordinates.
    static func upright(_ point: NormalizedPoint, from orientation: VideoOrientation) -> NormalizedPoint {
        switch orientation {
        case .up: point
        case .right: NormalizedPoint(x: 1 - point.y, y: point.x)
        case .down: NormalizedPoint(x: 1 - point.x, y: 1 - point.y)
        case .left: NormalizedPoint(x: point.y, y: 1 - point.x)
        }
    }

    /// Display aspect ratio (width / height) after applying the orientation.
    static func displayAspectRatio(naturalWidth: Double, naturalHeight: Double, orientation: VideoOrientation) -> Double? {
        guard naturalWidth > 0, naturalHeight > 0 else { return nil }
        switch orientation {
        case .up, .down: return naturalWidth / naturalHeight
        case .left, .right: return naturalHeight / naturalWidth
        }
    }

    // MARK: Vision

    /// Vision reports normalized points with a BOTTOM-left origin in the upright image
    /// (KickLab passes the track orientation to Vision). App coordinates use a top-left origin.
    static func fromVision(x: Double, y: Double) -> NormalizedPoint {
        NormalizedPoint(x: x, y: 1 - y)
    }

    // MARK: Mirroring

    /// Converts raw detector output (Vision coordinates in the upright, UN-mirrored image)
    /// into app coordinates for the DISPLAYED video.
    ///
    /// KickLab runs detection on the un-mirrored image so left/right labels are the
    /// person's true anatomical sides. When the video displays mirrored (front camera),
    /// x is then flipped to match what the viewer sees, keeping the labels.
    /// Points with zero confidence or non-finite values become unavailable.
    static func appJoints(
        fromVision raw: [PoseJoint: (x: Double, y: Double, confidence: Double)],
        isMirrored: Bool
    ) -> [PoseJoint: PosePoint] {
        var joints: [PoseJoint: PosePoint] = [:]
        for joint in PoseJoint.allCases {
            guard let value = raw[joint], value.confidence > 0, value.x.isFinite, value.y.isFinite else {
                joints[joint] = .unavailable
                continue
            }
            let point = fromVision(x: value.x, y: value.y)
            joints[joint] = PosePoint(x: point.x, y: point.y, confidence: min(1, value.confidence))
        }
        return isMirrored ? mirrored(joints, swapSides: false) : joints
    }

    /// Mirrors a pose horizontally (x → 1 − x). With `swapSides`, left/right labels are
    /// also exchanged: use that only for poses detected ON a mirrored image, where the
    /// detector labels sides as they appear in the mirror (`appJoints` avoids this case).
    static func mirrored(_ joints: [PoseJoint: PosePoint], swapSides: Bool) -> [PoseJoint: PosePoint] {
        var result: [PoseJoint: PosePoint] = [:]
        for (joint, point) in joints {
            var flipped = point
            if point.isAvailable { flipped.x = 1 - point.x }
            result[swapSides ? joint.opposite : joint] = flipped
        }
        return result
    }
}

/// The joints the biomechanics layer needs, resolved for the athlete's kicking foot,
/// so metric code never assumes a right-footed kicker.
struct KickingSideJoints: Equatable, Sendable {
    let kickingFoot: KickingFoot

    var kickingSide: BodySide { kickingFoot == .right ? .right : .left }
    var plantSide: BodySide { kickingSide.opposite }

    var kickingHip: PoseJoint { Self.joint(.hip, kickingSide) }
    var kickingKnee: PoseJoint { Self.joint(.knee, kickingSide) }
    var kickingAnkle: PoseJoint { Self.joint(.ankle, kickingSide) }
    var kickingShoulder: PoseJoint { Self.joint(.shoulder, kickingSide) }
    var kickingElbow: PoseJoint { Self.joint(.elbow, kickingSide) }
    var kickingWrist: PoseJoint { Self.joint(.wrist, kickingSide) }

    var plantHip: PoseJoint { Self.joint(.hip, plantSide) }
    var plantKnee: PoseJoint { Self.joint(.knee, plantSide) }
    var plantAnkle: PoseJoint { Self.joint(.ankle, plantSide) }
    var plantShoulder: PoseJoint { Self.joint(.shoulder, plantSide) }
    var plantElbow: PoseJoint { Self.joint(.elbow, plantSide) }
    var plantWrist: PoseJoint { Self.joint(.wrist, plantSide) }

    var head: PoseJoint { .nose }

    init(kickingFoot: KickingFoot) {
        self.kickingFoot = kickingFoot
    }

    enum Segment { case shoulder, elbow, wrist, hip, knee, ankle }

    static func joint(_ segment: Segment, _ side: BodySide) -> PoseJoint {
        switch (segment, side) {
        case (.shoulder, .left): .leftShoulder
        case (.shoulder, .right): .rightShoulder
        case (.elbow, .left): .leftElbow
        case (.elbow, .right): .rightElbow
        case (.wrist, .left): .leftWrist
        case (.wrist, .right): .rightWrist
        case (.hip, .left): .leftHip
        case (.hip, .right): .rightHip
        case (.knee, .left): .leftKnee
        case (.knee, .right): .rightKnee
        case (.ankle, .left): .leftAnkle
        case (.ankle, .right): .rightAnkle
        }
    }
}
