import Foundation

// MARK: - Format
//
// Analysis artifacts are versioned JSON files under the analysis root:
//
//   Analysis/<analysis-uuid>/
//     manifest.json      ← written LAST; its presence means the set is complete
//     pose-v1.json       ← every detected body per sampled frame + kicker tracking
//     signals-v1.json    ← derived kicker signals
//     phases-v1.json     ← detected kick phases
//     biomechanics-v1.json ← Step 8 metrics, scores and coaching findings (manifest v2+)
//
// Each file starts with `kind` and `formatVersion`. Readers decode that header first
// and refuse files of another kind or of a NEWER format version than they understand,
// instead of misreading them. Bulk pose data never goes into SwiftData; the database
// stores only the directory (`BiomechanicsAnalysis.artifactsRelativePath`).

/// A file-backed analysis artifact with a self-describing header.
protocol VersionedArtifact: Codable, Sendable {
    static var kind: String { get }
    /// The newest format this build reads and writes.
    static var currentFormatVersion: Int { get }
    var kind: String { get }
    var formatVersion: Int { get }
}

/// Pose detection output for one video: every person, tracking, and the processed kicker.
struct PoseArtifact: VersionedArtifact, Equatable {
    static let kind = "kicklab.pose"
    static let currentFormatVersion = 1

    var kind: String = PoseArtifact.kind
    var formatVersion: Int = PoseArtifact.currentFormatVersion
    var videoID: UUID
    var sampling: FrameSamplingPlan
    var trackingConfiguration: PoseTrackingConfiguration
    var processingConfiguration: PoseProcessingConfiguration
    /// All bodies in all sampled frames, with track IDs.
    var sequence: PoseSequence
    var tracking: KickerTrackingResult
    /// The kicker after thresholding, gap filling and smoothing (nil when no kicker).
    var kickerTimeline: KickerPoseTimeline?
}

struct SignalArtifact: VersionedArtifact, Equatable {
    static let kind = "kicklab.signals"
    static let currentFormatVersion = 1

    var kind: String = SignalArtifact.kind
    var formatVersion: Int = SignalArtifact.currentFormatVersion
    var videoID: UUID
    var signals: PoseSignalSet
}

struct PhaseArtifact: VersionedArtifact, Equatable {
    static let kind = "kicklab.phases"
    static let currentFormatVersion = 1

    var kind: String = PhaseArtifact.kind
    var formatVersion: Int = PhaseArtifact.currentFormatVersion
    var videoID: UUID
    var phases: KickPhaseDetectionResult
    var ball: BallTrackingResult
}

/// One video of the request, as recorded in the manifest.
struct ArtifactVideoEntry: Codable, Equatable, Sendable {
    var videoID: UUID
    var angle: VideoAngleType
    var isPrimary: Bool
    /// Offset relative to the primary video, preserved for future multi-angle fusion.
    var syncOffsetSeconds: Double?
    /// Whether pose artifacts were produced for this video (only the primary in V1).
    var analyzed: Bool
}

/// The index of an artifact set.
///
/// Format history: v1 (Step 7) had pose, signals and phases; v2 (Step 8) adds the
/// optional `biomechanicsPath`. A v2 reader reads v1 manifests (no biomechanics file);
/// a v1 reader refuses v2 manifests instead of misreading them.
///
/// Multi-angle extension point: V1 analyzes only `primaryVideoID`. A future fusion
/// engine adds per-video pose/signal files and a fused phase file; it bumps
/// `formatVersion` and adds paths here, and `syncOffsetSeconds` lets it align timelines.
struct AnalysisArtifactManifest: VersionedArtifact, Equatable {
    static let kind = "kicklab.manifest"
    static let currentFormatVersion = 2

    var kind: String = AnalysisArtifactManifest.kind
    var formatVersion: Int = AnalysisArtifactManifest.currentFormatVersion
    var engineVersion: String
    var requestID: UUID
    var kickID: UUID
    var kickType: KickType
    var primaryVideoID: UUID
    var videos: [ArtifactVideoEntry]
    /// File names relative to the manifest's directory.
    var posePath: String
    var signalsPath: String
    var phasesPath: String
    /// Step 8 biomechanics file; nil in v1 manifests.
    var biomechanicsPath: String?
    var createdAt: Date
    /// Step 12D (optional): what the user supplied for a user-assisted analysis.
    var assistance: PhaseDetectionAssistance? = nil
    /// Step 12D (optional): recording-suitability findings.
    var suitability: [SuitabilityFinding]? = nil

    var videoIDs: [UUID] { videos.map(\.videoID) }

    static let fileName = "manifest.json"
    static let defaultPosePath = "pose-v1.json"
    static let defaultSignalsPath = "signals-v1.json"
    static let defaultPhasesPath = "phases-v1.json"
    static let defaultBiomechanicsPath = "biomechanics-v1.json"
}

enum AnalysisArtifactError: Error, Equatable, Sendable {
    /// The file is a different artifact kind.
    case wrongKind(expected: String, found: String)
    /// Written by a newer KickLab; this build cannot read it safely.
    case unsupportedFormatVersion(kind: String, version: Int, supported: Int)
    case invalidPath(String)
    case missing(String)
    case corrupt(String)
}

/// JSON encoding with header checks.
enum AnalysisArtifactCoder {
    private struct Header: Decodable {
        let kind: String
        let formatVersion: Int
    }

    static func encode<A: VersionedArtifact>(_ artifact: A) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        encoder.nonConformingFloatEncodingStrategy = .convertToString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        return try encoder.encode(artifact)
    }

    static func decode<A: VersionedArtifact>(_ type: A.Type, from data: Data) throws -> A {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        decoder.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "inf", negativeInfinity: "-inf", nan: "nan")
        let header: Header
        do {
            header = try decoder.decode(Header.self, from: data)
        } catch {
            throw AnalysisArtifactError.corrupt("Missing artifact header.")
        }
        guard header.kind == A.kind else {
            throw AnalysisArtifactError.wrongKind(expected: A.kind, found: header.kind)
        }
        guard header.formatVersion >= 1, header.formatVersion <= A.currentFormatVersion else {
            throw AnalysisArtifactError.unsupportedFormatVersion(kind: header.kind, version: header.formatVersion, supported: A.currentFormatVersion)
        }
        do {
            return try decoder.decode(A.self, from: data)
        } catch {
            throw AnalysisArtifactError.corrupt("\(A.kind): \(error)")
        }
    }
}

/// Everything one analysis run writes.
struct AnalysisArtifactBundle: Equatable, Sendable {
    var manifest: AnalysisArtifactManifest
    var pose: PoseArtifact
    var signals: SignalArtifact
    var phases: PhaseArtifact
    /// Present when the manifest names a biomechanics file.
    var biomechanics: BiomechanicsArtifact?
}

/// The manifest plus the phase artifact of one analysis.
struct PhaseArtifactSummary: Equatable, Sendable {
    var manifest: AnalysisArtifactManifest
    var phases: PhaseArtifact
}

/// Reads and writes artifact sets under the analysis root. Paths are validated with
/// `ManagedPath`, so nothing outside the root can be addressed.
struct AnalysisArtifactStore: Sendable {
    let analysisRootURL: URL
    let fileSystem: any MediaFileSystem

    init(analysisRootURL: URL, fileSystem: any MediaFileSystem = LocalMediaFileSystem()) {
        self.analysisRootURL = analysisRootURL
        self.fileSystem = fileSystem
    }

    /// Writes the set into `directory` (relative to the analysis root) and returns it.
    /// The manifest is written last. On failure, the partly written directory is removed.
    @discardableResult
    func write(_ bundle: AnalysisArtifactBundle, to directory: String) throws -> String {
        let folder = try url(directory)
        let manifest = bundle.manifest
        guard (manifest.biomechanicsPath == nil) == (bundle.biomechanics == nil) else {
            throw AnalysisArtifactError.invalidPath(manifest.biomechanicsPath ?? "biomechanics")
        }
        for name in [manifest.posePath, manifest.signalsPath, manifest.phasesPath] + [manifest.biomechanicsPath].compactMap({ $0 }) {
            guard Self.isPlainFileName(name) else { throw AnalysisArtifactError.invalidPath(name) }
        }
        do {
            try fileSystem.createDirectory(at: folder)
            try AnalysisArtifactCoder.encode(bundle.pose).write(to: folder.appendingPathComponent(manifest.posePath), options: .atomic)
            try AnalysisArtifactCoder.encode(bundle.signals).write(to: folder.appendingPathComponent(manifest.signalsPath), options: .atomic)
            try AnalysisArtifactCoder.encode(bundle.phases).write(to: folder.appendingPathComponent(manifest.phasesPath), options: .atomic)
            if let path = manifest.biomechanicsPath, let biomechanics = bundle.biomechanics {
                try AnalysisArtifactCoder.encode(biomechanics).write(to: folder.appendingPathComponent(path), options: .atomic)
            }
            try AnalysisArtifactCoder.encode(manifest).write(to: folder.appendingPathComponent(AnalysisArtifactManifest.fileName), options: .atomic)
        } catch {
            try? fileSystem.removeItem(at: folder)
            throw error
        }
        return directory
    }

    /// The manifest and phase file only (small), for screens that don't need pose data.
    func readPhases(in directory: String) throws -> PhaseArtifactSummary {
        let manifest = try readManifest(in: directory)
        let phases = try read(PhaseArtifact.self, directory: directory, file: manifest.phasesPath)
        return PhaseArtifactSummary(manifest: manifest, phases: phases)
    }

    func readManifest(in directory: String) throws -> AnalysisArtifactManifest {
        try read(AnalysisArtifactManifest.self, directory: directory, file: AnalysisArtifactManifest.fileName)
    }

    func readBundle(in directory: String) throws -> AnalysisArtifactBundle {
        let manifest = try readManifest(in: directory)
        return AnalysisArtifactBundle(
            manifest: manifest,
            pose: try read(PoseArtifact.self, directory: directory, file: manifest.posePath),
            signals: try read(SignalArtifact.self, directory: directory, file: manifest.signalsPath),
            phases: try read(PhaseArtifact.self, directory: directory, file: manifest.phasesPath),
            biomechanics: try manifest.biomechanicsPath.map { try read(BiomechanicsArtifact.self, directory: directory, file: $0) }
        )
    }

    // MARK: Helpers

    private func read<A: VersionedArtifact>(_ type: A.Type, directory: String, file: String) throws -> A {
        guard Self.isPlainFileName(file) else { throw AnalysisArtifactError.invalidPath(file) }
        let fileURL = try url(directory).appendingPathComponent(file)
        guard fileSystem.itemExists(at: fileURL) else { throw AnalysisArtifactError.missing(file) }
        return try AnalysisArtifactCoder.decode(type, from: Data(contentsOf: fileURL))
    }

    private func url(_ directory: String) throws -> URL {
        do {
            return try ManagedPath.url(for: directory, under: analysisRootURL)
        } catch {
            throw AnalysisArtifactError.invalidPath(directory)
        }
    }

    /// A single, valid path component (no folders).
    static func isPlainFileName(_ name: String) -> Bool {
        ManagedPath.isValid(name) && !name.contains("/")
    }
}
