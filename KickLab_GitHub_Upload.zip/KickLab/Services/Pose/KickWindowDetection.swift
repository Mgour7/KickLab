import Foundation

// Step 12D: kick-window detection.
//
// A recording may contain standing, walking into position, an approach, the kick, the
// follow-through, walking away and unrelated movement. Engine 2.2.0 ranked every kicking-
// foot speed peak in the whole clip on its own, and on the real reference clip a calm
// post-kick movement at 6.04 s (foot speed 4.4 body lengths/s, athlete standing, so "plant
// at rest" and "foot passing" were trivially true) outranked the actual kick at about
// 2.3–2.5 s (18.8 body lengths/s, at the end of a 5 body-lengths/s approach).
//
// The window is found from the HIPS first, a different body part from the kicking foot:
// a kick is the end of an approach — forward hip speed rises, peaks and brakes sharply as
// the plant foot lands. The strike happens late in the approach or during the braking.
// Kicking-foot peaks outside every window are preparation or recovery, never contact.
// The user's video is never trimmed: the window only says where to look.

struct KickWindow: Codable, Equatable, Sendable {
    /// Where meaningful preparation begins (0.5 s before the approach).
    var preparationStart: Double
    var approachStart: Double
    var approachPeakTime: Double
    /// Forward hip speed at the peak, body lengths/s.
    var approachPeakSpeed: Double
    /// Last sample at or above the window's approach level.
    var approachEnd: Double
    /// When forward hip speed fell back below 30% of the peak.
    var brakingEnd: Double
    /// Where the primary swing and strike can be.
    var strikeStart: Double
    var strikeEnd: Double
    var followThroughEnd: Double
    var movementEnd: Double
    /// Body lengths travelled forward during the approach.
    var momentum: Double
    /// A kicking-foot speed peak (≥ the profile's kick speed) lies in the strike interval.
    var hasSwing: Bool
    var score: Double
    var confidence: Double
    var uncertaintyReasons: [String]
    /// "approach", "swingOnly" (no approach found), or "user".
    var source: String

    func containsStrike(_ t: Double) -> Bool { t >= strikeStart - 1e-9 && t <= strikeEnd + 1e-9 }
}

struct KickWindowAnalysis: Codable, Equatable, Sendable {
    /// Ranked best first.
    var windows: [KickWindow]
    var selectedIndex: Int?
    /// Two or more windows look like genuine kicks: the user should choose.
    var needsSelection: Bool
    var notes: [String]

    var selected: KickWindow? { selectedIndex.map { windows[$0] } }

    static let none = KickWindowAnalysis(windows: [], selectedIndex: nil, needsSelection: false, notes: [])
}

enum KickWindowDetector {
    /// A window's approach is where forward hip speed is at least this fraction of the
    /// clip's highest (and at least the profile's approach speed)…
    static let approachLevelFraction = 0.4
    /// …braking ends when it is back below this fraction of the window's peak.
    static let brakingFraction = 0.3
    /// Approach runs closer than this belong to one approach (stride-to-stride dips).
    static let mergeGapSeconds = 0.3
    /// The strike can be from this long before the end of the approach…
    static let strikeLeadSeconds = 0.25
    /// …to this long after braking ends.
    static let strikeLagSeconds = 0.35
    /// Two kick windows each scoring at least this fraction of the best, with real
    /// approaches, are reported as multiple kicks.
    static let multipleKickFraction = 0.75

    static func detect(_ signals: PoseSignalSet, profile: KickPhaseProfile, restrictTo range: ClosedRange<Double>? = nil) -> KickWindowAnalysis {
        let times = signals.timestamps
        guard times.count >= 5 else { return .none }
        let directionKnown = signals.travelDirection != 0
        let raw = directionKnown ? signals.values(.bodyForwardVelocity) : signals.values(.bodyCenterSpeed)
        let v = KickPhaseDetector.medianFilter(raw, radius: 2)
        let inRange = { (i: Int) -> Bool in range.map { $0.contains(times[i]) } ?? true }
        let kicking = signals.values(.kickingAnkleSpeed)

        func hasSwing(_ from: Double, _ to: Double) -> Bool {
            times.indices.contains { i in
                times[i] >= from - 1e-9 && times[i] <= to + 1e-9 && (kicking[i] ?? 0) >= profile.contactMinimumPeakSpeed
            }
        }

        let peak = times.indices.filter(inRange).compactMap { v[$0] }.max() ?? 0
        var windows: [KickWindow] = []
        var notes: [String] = []

        if peak >= profile.approachSpeedThreshold {
            let level = max(profile.approachSpeedThreshold, approachLevelFraction * peak)
            // Runs at or above the level, merging short dips.
            var runs: [(Int, Int)] = []
            var start: Int?
            for i in times.indices {
                let above = inRange(i) && (v[i] ?? 0) >= level
                if above, start == nil { start = i }
                if !above, let s = start {
                    runs.append((s, i - 1))
                    start = nil
                }
            }
            if let s = start { runs.append((s, times.count - 1)) }
            var merged: [(Int, Int)] = []
            for run in runs {
                if let last = merged.last, times[run.0] - times[last.1] < mergeGapSeconds {
                    merged[merged.count - 1].1 = run.1
                } else {
                    merged.append(run)
                }
            }
            for (s, e) in merged {
                var a = s
                while a > 0, inRange(a - 1), (v[a - 1] ?? 0) >= profile.approachSpeedThreshold { a -= 1 }
                let runIndices = Array(s...e)
                let peakIndex = runIndices.max { (v[$0] ?? 0) < (v[$1] ?? 0) } ?? s
                let runPeak = v[peakIndex] ?? 0
                var brake = e
                while brake + 1 < times.count, times[brake + 1] - times[e] <= 0.8 + 1e-9, (v[brake] ?? 0) > brakingFraction * runPeak {
                    brake += 1
                }
                var momentum = 0.0
                for i in max(a, 1)...e { momentum += max(0, v[i] ?? 0) * (times[i] - times[i - 1]) }
                let strikeStart = max(times[0], times[e] - strikeLeadSeconds)
                let strikeEnd = min(times[times.count - 1], times[brake] + strikeLagSeconds)
                let after = times.indices.first { times[$0] >= times[brake] + 0.1 } ?? brake
                let sharpness = runPeak > 0 ? max(0, min(1, (runPeak - (v[after] ?? runPeak)) / runPeak)) : 0
                let swing = hasSwing(strikeStart, strikeEnd)
                var reasons: [String] = []
                if !swing { reasons.append("no kicking-foot swing at the end of this approach") }
                if times[e] >= times[times.count - 1] - 1e-9 { reasons.append("the clip ends during the approach") }
                if times[a] <= times[0] + 1e-9 { reasons.append("the clip starts during the approach") }
                windows.append(KickWindow(
                    preparationStart: max(times[0], times[a] - 0.5), approachStart: times[a],
                    approachPeakTime: times[peakIndex], approachPeakSpeed: round3(runPeak), approachEnd: times[e],
                    brakingEnd: times[brake], strikeStart: strikeStart, strikeEnd: strikeEnd,
                    followThroughEnd: min(times[times.count - 1], strikeEnd + 0.5),
                    movementEnd: min(times[times.count - 1], strikeEnd + 1.0),
                    momentum: round3(momentum), hasSwing: swing, score: 0, confidence: 0,
                    uncertaintyReasons: reasons, source: "approach"
                ))
                windows[windows.count - 1].score = sharpness // provisional, finished below
            }
        }

        if !windows.contains(where: \.hasSwing) {
            // No approach (a standing kick, or one where the hips barely move in the frame):
            // fall back to the kicking-foot swings themselves, with low confidence.
            let swings = ContactEstimator.localPeaks(kicking, times, minimum: profile.contactMinimumPeakSpeed).filter(inRange)
            if let best = swings.max(by: { (kicking[$0] ?? 0) < (kicking[$1] ?? 0) }) {
                let t = times[best]
                windows.append(KickWindow(
                    preparationStart: max(times[0], t - 1.0), approachStart: max(times[0], t - 0.6), approachPeakTime: t,
                    approachPeakSpeed: 0, approachEnd: t, brakingEnd: t,
                    strikeStart: max(times[0], t - 0.6), strikeEnd: min(times[times.count - 1], t + 0.6),
                    followThroughEnd: min(times[times.count - 1], t + 1.0), movementEnd: min(times[times.count - 1], t + 1.5),
                    momentum: 0, hasSwing: true, score: 0, confidence: 0.3,
                    uncertaintyReasons: ["no approach was found, so the kick was located from the fastest kicking-foot swing alone"],
                    source: "swingOnly"
                ))
                notes.append("No approach was found; the kick window comes from the kicking-foot swing alone.")
            }
        }

        // Score: approach momentum (relative), a swing at its end, and how sharply it braked.
        let maxMomentum = windows.map(\.momentum).max() ?? 0
        for i in windows.indices where windows[i].source == "approach" {
            let relative = maxMomentum > 0 ? windows[i].momentum / maxMomentum : 0
            let sharpness = windows[i].score
            var score = 0.5 * relative + 0.3 * (windows[i].hasSwing ? 1 : 0) + 0.2 * sharpness
            if !windows[i].hasSwing { score *= 0.3 }
            windows[i].score = round3(score)
        }
        for i in windows.indices where windows[i].source == "swingOnly" { windows[i].score = 0.3 }
        windows.sort { a, b in
            if a.score != b.score { return a.score > b.score }
            return a.approachStart < b.approachStart
        }
        guard let best = windows.first, best.hasSwing else {
            if !windows.isEmpty { notes.append("Approaches were found, but none ended in a kicking-foot swing.") }
            return KickWindowAnalysis(windows: windows, selectedIndex: nil, needsSelection: false, notes: notes)
        }
        let rivals = windows.dropFirst().filter {
            $0.hasSwing && $0.source == "approach" && $0.score >= multipleKickFraction * best.score
                && $0.momentum >= 0.5 * best.momentum
        }
        let needsSelection = !rivals.isEmpty
        for i in windows.indices {
            var c = windows[i].source == "approach" ? 0.8 : 0.3
            if !windows[i].hasSwing { c = 0.1 }
            if needsSelection && windows[i].hasSwing { c *= 0.5 }
            if windows[i].uncertaintyReasons.contains(where: { $0.hasPrefix("the clip") }) { c *= 0.8 }
            windows[i].confidence = round3(c)
        }
        if needsSelection {
            notes.append(String(format: "%d kicks were found in this video (at about %@ s). Choose which one to analyze.",
                                rivals.count + 1,
                                ([best] + rivals).map { String(format: "%.1f", $0.strikeStart + 0.25) }.joined(separator: ", ")))
        }
        let others = windows.dropFirst().filter { !$0.hasSwing }.count
        if others > 0 { notes.append("\(others) other movement(s) without a kick were treated as walking, preparation or recovery.") }
        return KickWindowAnalysis(windows: windows, selectedIndex: 0, needsSelection: needsSelection, notes: notes)
    }

    /// A user-chosen interval as the kick window (the video itself is untouched).
    static func userWindow(_ range: ClosedRange<Double>, signals: PoseSignalSet) -> KickWindow {
        let first = signals.timestamps.first ?? range.lowerBound
        let last = signals.timestamps.last ?? range.upperBound
        let start = max(first, range.lowerBound), end = min(last, range.upperBound)
        return KickWindow(
            preparationStart: start, approachStart: start, approachPeakTime: start, approachPeakSpeed: 0,
            approachEnd: start, brakingEnd: start, strikeStart: start, strikeEnd: end, followThroughEnd: end,
            movementEnd: end, momentum: 0, hasSwing: true, score: 1, confidence: 0.6,
            uncertaintyReasons: ["the kick window was chosen by the user"], source: "user"
        )
    }

    static func round3(_ x: Double) -> Double { (x * 1000).rounded() / 1000 }
}
