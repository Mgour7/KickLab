import Foundation

/// Which frames of a video to analyze. Always time-based: the reader uses each
/// frame's true presentation timestamp and never assumes a frame rate.
struct FrameSamplingPlan: Codable, Equatable, Sendable {
    enum Rate: Codable, Equatable, Sendable {
        /// Every decoded frame (e.g. all 240 per second of a slow-motion clip).
        case everyFrame
        /// At most this many frames per second, chosen by timestamp.
        case target(framesPerSecond: Double)
    }

    var rate: Rate
    /// Seconds from the start of the video, inclusive. Nil means the whole video.
    var timeRange: ClosedRange<Double>?

    init(rate: Rate = .target(framesPerSecond: 60), timeRange: ClosedRange<Double>? = nil) {
        self.rate = rate
        self.timeRange = timeRange
    }

    /// 60 analysis frames per second: enough for kick timing, affordable for pose detection.
    static let standard = FrameSamplingPlan()
    static let everyFrame = FrameSamplingPlan(rate: .everyFrame)

    var targetFrameRate: Double? {
        if case .target(let fps) = rate, fps > 0 { return fps }
        return nil
    }
}

enum FrameSamplingDecision: Equatable, Sendable {
    case keep
    case skip
    /// Past the end of the time range; the reader can stop decoding.
    case stop
}

/// Decides, frame by frame, which decoded frames to analyze.
///
/// For a target rate, frames are kept on a fixed time grid anchored at the first kept
/// frame, so a 240 fps source sampled at 60 fps keeps exactly every 4th frame and never
/// drifts. A source slower than the target keeps every frame.
struct FrameSampler: Sendable {
    let plan: FrameSamplingPlan
    private var nextDueTime: Double?
    /// Tolerance for timestamp rounding in the container.
    private let epsilon = 1e-4

    init(plan: FrameSamplingPlan) {
        self.plan = plan
    }

    mutating func decide(presentationTime t: Double) -> FrameSamplingDecision {
        guard t.isFinite else { return .skip }
        if let range = plan.timeRange {
            if t < range.lowerBound - epsilon { return .skip }
            if t > range.upperBound + epsilon { return .stop }
        }
        guard let fps = plan.targetFrameRate else { return .keep }

        let interval = 1 / fps
        guard let due = nextDueTime else {
            nextDueTime = t + interval
            return .keep
        }
        guard t + epsilon >= due else { return .skip }
        var next = due + interval
        while next <= t + epsilon { next += interval }
        nextDueTime = next
        return .keep
    }
}
