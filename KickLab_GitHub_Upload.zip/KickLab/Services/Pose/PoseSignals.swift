import Foundation

/// Named time series derived from the kicker's pose. Units:
/// - positions: aspect-corrected normalized units (see `PoseModel.swift`);
/// - speeds and velocities: BODY LENGTHS per second (torso length), so they compare
///   across zoom levels and resolutions;
/// - angles: degrees.
/// "Forward" is the athlete's direction of travel in the frame.
enum PoseSignalKey: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    case bodyCenterX
    case bodyCenterY
    case bodyCenterSpeed
    /// Body-center velocity along the direction of travel.
    case bodyForwardVelocity
    case plantAnkleSpeed
    case kickingAnkleSpeed
    case kickingKneeSpeed
    /// Kicking-knee velocity along the direction of travel.
    case kickingKneeForwardVelocity
    /// Kicking ankle relative to the kicking hip along the direction of travel, in body
    /// lengths. Negative = behind the hip (backswing).
    case kickingAnkleForwardOffset
    /// Hip–knee–ankle angle (180 = straight).
    case kickingKneeAngle
    case plantKneeAngle
    /// Shoulder–hip–knee angle on the kicking side.
    case kickingHipAngle
    /// Trunk angle from vertical; positive leans in the direction of travel.
    case torsoLean
    /// Step 12B: kicking ankle relative to the plant ankle along the direction of travel,
    /// in body lengths. It crosses zero as the kicking foot swings past the plant foot,
    /// a second, independent cue for when contact can happen.
    case kickingAnkleAheadOfPlant
    /// Step 12C: kicking-ankle velocity along the direction of travel (body lengths/s).
    /// Separates a forward strike from a backswing or recovery of the same speed.
    case kickingAnkleForwardVelocity
    /// Step 12C: plant ankle relative to the plant hip along the direction of travel,
    /// in body lengths (a planted foot usually lands ahead of the hip).
    case plantAnkleForwardOffset
    /// Step 12E: straight-line (2D) distance between the two ankles, in body lengths. A
    /// value near zero for a long time means both ankle labels sit on one foot.
    case ankleSeparation
    /// Step 12E: straight-line (2D) distance between the two knees, in body lengths.
    case kneeSeparation
    /// Step 12E: plant-ankle speed relative to the hip center (body lengths/s). Camera
    /// panning moves the whole body in the frame and cancels here; a planted foot under a
    /// moving body does NOT read zero (the hips keep moving over it).
    case plantAnkleSpeedRelativeToHips

    // Step 12E: depth views (filmed from behind or in front). Lengths are in THAT frame's
    // torso length, because perspective makes a clip-wide median wrong as the kicker
    // moves away from or toward the camera.

    /// Perspective approach rate (1/s): how fast the kicker's apparent size changes,
    /// signed so the run-up is positive (shrinking from behind, growing from in front).
    /// Speed ÷ distance to the camera — a rate, not a speed.
    case approachRate
    /// The kicker's own torso length in the image per frame (median-smoothed).
    case frameScale
    /// Kicking ankle height above the hip center, in frame torso lengths (negative = below).
    /// From behind or in front the heel rising in the backswing and the foot dropping to
    /// the ball are vertical in the image.
    case kickingAnkleLift
    /// Sideways trunk tilt from vertical (degrees), positive toward the plant-leg side.
    case lateralTrunkLean
    /// Plant ankle sideways from the hip center, toward the plant-leg side, in frame torso
    /// lengths.
    case plantAnkleLateralOffset
}

extension PoseSignalKey {
    /// Step 12E: produced only for depth views (behind / in front of the kicker).
    static let depthViewOnly: Set<PoseSignalKey> = [.approachRate, .frameScale, .kickingAnkleLift, .lateralTrunkLean, .plantAnkleLateralOffset]
}

/// All signals on a common timeline (one value per kicker sample; nil where the inputs
/// were unavailable).
struct PoseSignalSet: Codable, Equatable, Sendable {
    var timestamps: [Double]
    var series: [PoseSignalKey: [Double?]]
    /// Torso length used to convert to body lengths (aspect-corrected normalized units).
    var bodyScale: Double?
    /// +1 when the athlete travels toward larger x, −1 toward smaller x, 0 when unknown.
    var travelDirection: Int
    var kickingFoot: KickingFoot

    init(
        timestamps: [Double],
        series: [PoseSignalKey: [Double?]],
        bodyScale: Double? = nil,
        travelDirection: Int = 1,
        kickingFoot: KickingFoot = .right
    ) {
        self.timestamps = timestamps
        self.series = series
        self.bodyScale = bodyScale
        self.travelDirection = travelDirection
        self.kickingFoot = kickingFoot
    }

    func values(_ key: PoseSignalKey) -> [Double?] {
        series[key] ?? Array(repeating: nil, count: timestamps.count)
    }

    /// Fraction of samples where `key` has a value.
    func coverage(_ key: PoseSignalKey) -> Double {
        guard !timestamps.isEmpty else { return 0 }
        return Double(values(key).compactMap { $0 }.count) / Double(timestamps.count)
    }

    static let empty = PoseSignalSet(timestamps: [], series: [:], travelDirection: 0)
}

/// Pure conversion of a processed kicker timeline into signals.
enum PoseSignalExtractor {
    static func extract(from timeline: KickerPoseTimeline, kickingFoot: KickingFoot,
                        perspective: CameraPerspective = .side) -> PoseSignalSet {
        if perspective.isDepthView { return extractDepthView(from: timeline, kickingFoot: kickingFoot, perspective: perspective) }
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        let aspect = timeline.displayAspectRatio ?? 1
        let samples = timeline.samples
        let times = samples.map(\.timestamp)
        guard !samples.isEmpty else { return PoseSignalSet(timestamps: [], series: [:], travelDirection: 0, kickingFoot: kickingFoot) }

        func position(_ joint: PoseJoint, _ i: Int) -> NormalizedPoint? {
            samples[i].point(joint).map { NormalizedPoint(x: $0.x * aspect, y: $0.y) }
        }
        func midpoint(_ a: PoseJoint, _ b: PoseJoint, _ i: Int) -> NormalizedPoint? {
            guard let p = position(a, i), let q = position(b, i) else { return nil }
            return NormalizedPoint(x: (p.x + q.x) / 2, y: (p.y + q.y) / 2)
        }
        let centers: [NormalizedPoint?] = samples.indices.map { midpoint(.leftHip, .rightHip, $0) ?? position(.root, $0) }
        let shoulders: [NormalizedPoint?] = samples.indices.map { midpoint(.leftShoulder, .rightShoulder, $0) }

        // Body scale: median torso length.
        let torso = samples.indices.compactMap { i -> Double? in
            guard let s = shoulders[i], let c = centers[i] else { return nil }
            let d = hypot(s.x - c.x, s.y - c.y)
            return d > 0 ? d : nil
        }.sorted()
        let scale = torso.isEmpty ? nil : torso[torso.count / 2]
        let unit = scale ?? 1

        // Direction of travel from the overall body-center displacement.
        let validCenters = centers.compactMap { $0 }
        var direction = 0
        if let first = validCenters.first, let last = validCenters.last {
            let dx = last.x - first.x
            if abs(dx) >= 0.5 * unit { direction = dx > 0 ? 1 : -1 }
        }
        let forward = Double(direction == 0 ? 1 : direction)

        let plantAnkle = samples.indices.map { position(sides.plantAnkle, $0) }
        let kickingAnkle = samples.indices.map { position(sides.kickingAnkle, $0) }
        let kickingKnee = samples.indices.map { position(sides.kickingKnee, $0) }
        let kickingHip = samples.indices.map { position(sides.kickingHip, $0) }
        let plantHip = samples.indices.map { position(sides.plantHip, $0) }
        let plantKnee = samples.indices.map { position(sides.plantKnee, $0) }
        let kickingShoulder = samples.indices.map { position(sides.kickingShoulder, $0) }

        let centerVelocity = velocity(centers, times)
        let kneeVelocity = velocity(kickingKnee, times)

        var series: [PoseSignalKey: [Double?]] = [:]
        series[.bodyCenterX] = centers.map { $0.map { $0.x } }
        series[.bodyCenterY] = centers.map { $0.map { $0.y } }
        series[.bodyCenterSpeed] = centerVelocity.map { $0.map { hypot($0.x, $0.y) / unit } }
        series[.bodyForwardVelocity] = centerVelocity.map { $0.map { $0.x * forward / unit } }
        series[.plantAnkleSpeed] = velocity(plantAnkle, times).map { $0.map { hypot($0.x, $0.y) / unit } }
        let kickingAnkleVelocity = velocity(kickingAnkle, times)
        series[.kickingAnkleSpeed] = kickingAnkleVelocity.map { $0.map { hypot($0.x, $0.y) / unit } }
        series[.kickingAnkleForwardVelocity] = kickingAnkleVelocity.map { $0.map { $0.x * forward / unit } }
        series[.plantAnkleForwardOffset] = samples.indices.map { i in
            guard let a = plantAnkle[i], let h = plantHip[i] else { return nil }
            return (a.x - h.x) * forward / unit
        }
        series[.kickingKneeSpeed] = kneeVelocity.map { $0.map { hypot($0.x, $0.y) / unit } }
        series[.kickingKneeForwardVelocity] = kneeVelocity.map { $0.map { $0.x * forward / unit } }
        series[.kickingAnkleForwardOffset] = samples.indices.map { i in
            guard let a = kickingAnkle[i], let h = kickingHip[i] else { return nil }
            return (a.x - h.x) * forward / unit
        }
        series[.kickingAnkleAheadOfPlant] = samples.indices.map { i in
            guard let k = kickingAnkle[i], let p = plantAnkle[i] else { return nil }
            return (k.x - p.x) * forward / unit
        }
        series[.ankleSeparation] = samples.indices.map { i in
            guard let k = kickingAnkle[i], let p = plantAnkle[i] else { return nil }
            return hypot(k.x - p.x, k.y - p.y) / unit
        }
        series[.kneeSeparation] = samples.indices.map { i in
            guard let k = kickingKnee[i], let p = plantKnee[i] else { return nil }
            return hypot(k.x - p.x, k.y - p.y) / unit
        }
        let plantVelocity = velocity(plantAnkle, times)
        series[.plantAnkleSpeedRelativeToHips] = samples.indices.map { i in
            guard let a = plantVelocity[i], let c = centerVelocity[i] else { return nil }
            return hypot(a.x - c.x, a.y - c.y) / unit
        }
        series[.kickingKneeAngle] = samples.indices.map { angle(kickingHip[$0], kickingKnee[$0], kickingAnkle[$0]) }
        series[.plantKneeAngle] = samples.indices.map { angle(plantHip[$0], plantKnee[$0], plantAnkle[$0]) }
        series[.kickingHipAngle] = samples.indices.map { angle(kickingShoulder[$0], kickingHip[$0], kickingKnee[$0]) }
        series[.torsoLean] = samples.indices.map { i in
            guard let s = shoulders[i], let c = centers[i] else { return nil }
            // Up is −y. Positive lean = shoulders ahead of hips in the direction of travel.
            return atan2((s.x - c.x) * forward, c.y - s.y) * 180 / .pi
        }

        return PoseSignalSet(timestamps: times, series: series, bodyScale: scale, travelDirection: direction, kickingFoot: kickingFoot)
    }

    /// Step 12E: signals for a depth view. Nothing here assumes horizontal = forward:
    /// there is no travel direction, no forward velocity and no forward offsets (those
    /// series are absent, so everything built on them is unavailable rather than wrong).
    /// Speeds and lengths use each frame's own torso length.
    static func extractDepthView(from timeline: KickerPoseTimeline, kickingFoot: KickingFoot,
                                 perspective: CameraPerspective) -> PoseSignalSet {
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        let aspect = timeline.displayAspectRatio ?? 1
        let samples = timeline.samples
        let times = samples.map(\.timestamp)
        guard !samples.isEmpty else { return PoseSignalSet(timestamps: [], series: [:], travelDirection: 0, kickingFoot: kickingFoot) }
        func position(_ joint: PoseJoint, _ i: Int) -> NormalizedPoint? {
            samples[i].point(joint).map { NormalizedPoint(x: $0.x * aspect, y: $0.y) }
        }
        func midpoint(_ a: PoseJoint, _ b: PoseJoint, _ i: Int) -> NormalizedPoint? {
            guard let p = position(a, i), let q = position(b, i) else { return nil }
            return NormalizedPoint(x: (p.x + q.x) / 2, y: (p.y + q.y) / 2)
        }
        let centers: [NormalizedPoint?] = samples.indices.map { midpoint(.leftHip, .rightHip, $0) ?? position(.root, $0) }
        let shoulders: [NormalizedPoint?] = samples.indices.map { midpoint(.leftShoulder, .rightShoulder, $0) }
        let frameScale = CameraPerspectiveResolver.frameScale(timeline)
        let known = frameScale.compactMap { $0 }.sorted()
        let medianScale = known.isEmpty ? nil : known[known.count / 2]
        func unit(_ i: Int) -> Double? { frameScale[i] ?? medianScale }

        let plantAnkle = samples.indices.map { position(sides.plantAnkle, $0) }
        let kickingAnkle = samples.indices.map { position(sides.kickingAnkle, $0) }
        let kickingKnee = samples.indices.map { position(sides.kickingKnee, $0) }
        let plantKnee = samples.indices.map { position(sides.plantKnee, $0) }
        let kickingHip = samples.indices.map { position(sides.kickingHip, $0) }
        let plantHip = samples.indices.map { position(sides.plantHip, $0) }

        // Which image side the plant leg is on (labels already checked against facing).
        let sideOffsets = samples.indices.compactMap { i -> Double? in
            guard let p = plantHip[i], let k = kickingHip[i] else { return nil }
            return p.x - k.x
        }.sorted()
        let plantSide: Double = (sideOffsets.isEmpty ? 0 : sideOffsets[sideOffsets.count / 2]) >= 0 ? 1 : -1

        func speeds(_ positions: [NormalizedPoint?]) -> [Double?] {
            velocity(positions, times).enumerated().map { i, v in
                guard let v, let u = unit(i) else { return nil }
                return hypot(v.x, v.y) / u
            }
        }
        let centerVelocity = velocity(centers, times)
        let plantVelocity = velocity(plantAnkle, times)

        var series: [PoseSignalKey: [Double?]] = [:]
        series[.bodyCenterX] = centers.map { $0.map { $0.x } }
        series[.bodyCenterY] = centers.map { $0.map { $0.y } }
        series[.frameScale] = frameScale
        series[.bodyCenterSpeed] = speeds(centers)
        series[.plantAnkleSpeed] = speeds(plantAnkle)
        series[.kickingAnkleSpeed] = speeds(kickingAnkle)
        series[.kickingKneeSpeed] = speeds(kickingKnee)
        series[.plantAnkleSpeedRelativeToHips] = samples.indices.map { i in
            guard let a = plantVelocity[i], let c = centerVelocity[i], let u = unit(i) else { return nil }
            return hypot(a.x - c.x, a.y - c.y) / u
        }
        series[.ankleSeparation] = samples.indices.map { i in
            guard let k = kickingAnkle[i], let p = plantAnkle[i], let u = unit(i) else { return nil }
            return hypot(k.x - p.x, k.y - p.y) / u
        }
        series[.kneeSeparation] = samples.indices.map { i in
            guard let k = kickingKnee[i], let p = plantKnee[i], let u = unit(i) else { return nil }
            return hypot(k.x - p.x, k.y - p.y) / u
        }
        series[.kickingAnkleLift] = samples.indices.map { i in
            guard let a = kickingAnkle[i], let c = centers[i], let u = unit(i) else { return nil }
            return (c.y - a.y) / u
        }
        series[.lateralTrunkLean] = samples.indices.map { i in
            guard let s = shoulders[i], let c = centers[i] else { return nil }
            return atan2((s.x - c.x) * plantSide, c.y - s.y) * 180 / .pi
        }
        series[.plantAnkleLateralOffset] = samples.indices.map { i in
            guard let a = plantAnkle[i], let c = centers[i], let u = unit(i) else { return nil }
            return (a.x - c.x) * plantSide / u
        }
        // Perspective approach rate: slope of ln(size) over ±3 samples (0.1 s at 30 fps),
        // signed so the run-up is positive.
        let sign: Double = perspective == .depthAway ? -1 : 1
        let logs: [Double?] = frameScale.map { $0.map { log($0) } }
        series[.approachRate] = samples.indices.map { i in logSlope(logs, times, at: i).map { sign * $0 } }
        series[.kickingKneeAngle] = samples.indices.map { angle(kickingHip[$0], kickingKnee[$0], kickingAnkle[$0]) }
        series[.plantKneeAngle] = samples.indices.map { angle(plantHip[$0], plantKnee[$0], plantAnkle[$0]) }
        return PoseSignalSet(timestamps: times, series: series, bodyScale: medianScale, travelDirection: 0, kickingFoot: kickingFoot)
    }

    /// Least-squares slope of `values` against time over ±3 samples around `i` (nil with
    /// fewer than 4 values).
    static func logSlope(_ values: [Double?], _ times: [Double], at i: Int) -> Double? {
        let lower = max(0, i - 3)
        let upper = min(values.count - 1, i + 3)
        var ts: [Double] = []
        var vs: [Double] = []
        for j in lower...upper {
            if let v = values[j] {
                ts.append(times[j])
                vs.append(v)
            }
        }
        guard ts.count >= 4 else { return nil }
        let n = Double(ts.count)
        let mt: Double = ts.reduce(0, +) / n
        let mv: Double = vs.reduce(0, +) / n
        var num = 0.0
        var den = 0.0
        for k in ts.indices {
            let dt: Double = ts[k] - mt
            num += dt * (vs[k] - mv)
            den += dt * dt
        }
        return den > 0 ? num / den : nil
    }

    /// Central differences where both neighbors exist; one-sided at gaps and ends.
    static func velocity(_ positions: [NormalizedPoint?], _ times: [Double]) -> [NormalizedPoint?] {
        positions.indices.map { i in
            let previous = i > 0 ? positions[i - 1].map { ($0, times[i - 1]) } : nil
            let next = i + 1 < positions.count ? positions[i + 1].map { ($0, times[i + 1]) } : nil
            let here = positions[i].map { ($0, times[i]) }
            let pair: ((NormalizedPoint, Double), (NormalizedPoint, Double))?
            if let previous, let next, here != nil { pair = (previous, next) }
            else if let here, let next { pair = (here, next) }
            else if let previous, let here { pair = (previous, here) }
            else { pair = nil }
            guard let (a, b) = pair, b.1 > a.1 else { return nil }
            let dt = b.1 - a.1
            return NormalizedPoint(x: (b.0.x - a.0.x) / dt, y: (b.0.y - a.0.y) / dt)
        }
    }

    /// Angle at `vertex` between the rays to `a` and `c`, in degrees.
    static func angle(_ a: NormalizedPoint?, _ vertex: NormalizedPoint?, _ c: NormalizedPoint?) -> Double? {
        guard let a, let vertex, let c else { return nil }
        let v1 = (a.x - vertex.x, a.y - vertex.y)
        let v2 = (c.x - vertex.x, c.y - vertex.y)
        let n1 = hypot(v1.0, v1.1)
        let n2 = hypot(v2.0, v2.1)
        guard n1 > 0, n2 > 0 else { return nil }
        let cosine = max(-1, min(1, (v1.0 * v2.0 + v1.1 * v2.1) / (n1 * n2)))
        return acos(cosine) * 180 / .pi
    }
}
