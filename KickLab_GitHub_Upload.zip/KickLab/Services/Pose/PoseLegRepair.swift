import Foundation

/// What leg repair changed in a kicker timeline (Step 12B). Counts and sample indices
/// only — no coordinates.
struct PoseRepairReport: Codable, Equatable, Sendable {
    /// Samples whose left/right knee and ankle labels were exchanged back.
    var legSwapSamples: [Int] = []
    /// Samples where at least one knee or ankle was rejected as a one- or two-frame jump.
    var outlierSamples: [Int] = []
    /// Individual knee/ankle points rejected as jumps (they become unavailable and may be
    /// refilled by short-gap interpolation, which marks them `.interpolated`).
    var outlierPoints: Int = 0

    static let none = PoseRepairReport()

    var changedAnything: Bool { !legSwapSamples.isEmpty || outlierPoints > 0 }
}

/// Repairs the two Vision errors that are most common exactly when a kick happens: when
/// the kicking leg swings past the plant leg (seen from the side the legs overlap), Vision
/// can (1) swap the left/right labels of the knees and ankles for a frame or two, or
/// (2) put both ankles on the same leg for a frame or two.
///
/// Either error makes the planted foot appear to jump by a leg's width and back, so the
/// plant ankle looks fast exactly at contact, and the kicking ankle shows a false speed
/// spike that can be mistaken for contact (Step 12B investigation of a real 30 fps clip).
///
/// The repair is conservative and never invents a position:
/// - a swap is undone only when the swapped labels continue both legs' motion far better
///   (at most half the mismatch, and at least half a torso length less in total);
/// - a jump is rejected (made unavailable) only when a knee or ankle leaves the line
///   between its neighbors by more than half a torso length AND by more than the
///   neighbors' own separation, then returns. Rejected points are refilled only by the
///   normal short-gap interpolation, as `.interpolated` (which lowers confidence).
enum PoseLegRepair {
    /// Body lengths. A swap must reduce the four-joint mismatch by at least this much.
    static let minimumSwapImprovement = 0.5
    /// A swap must at least halve the mismatch.
    static let swapRatio = 0.5
    /// Body lengths. Smaller departures are treated as noise.
    static let minimumJumpDistance = 0.5
    /// Longest jump (in samples) that is rejected.
    static let maximumJumpSamples = 2

    static let pairs: [(PoseJoint, PoseJoint)] = [(.leftKnee, .rightKnee), (.leftAnkle, .rightAnkle)]

    /// - Parameter sidewaysJumpsOnly: Step 12E, for depth views: a jump is measured across
    ///   the image only, so a fast vertical heel lift (the backswing seen from behind) is
    ///   never rejected, while a label snapping to the other leg (sideways) still is.
    static func repair(_ timeline: KickerPoseTimeline, sidewaysJumpsOnly: Bool = false) -> (KickerPoseTimeline, PoseRepairReport) {
        guard timeline.samples.count >= 3, let scale = bodyScale(timeline) else { return (timeline, .none) }
        var report = PoseRepairReport()
        var result = fixSwaps(timeline, scale: scale, report: &report)
        result = rejectJumps(result, scale: scale, sidewaysOnly: sidewaysJumpsOnly, report: &report)
        return (result, report)
    }

    /// Median shoulder-midpoint to hip-midpoint distance (aspect-corrected).
    static func bodyScale(_ timeline: KickerPoseTimeline) -> Double? {
        let aspect = timeline.displayAspectRatio ?? 1
        let lengths = timeline.samples.compactMap { s -> Double? in
            guard let ls = s.point(.leftShoulder), let rs = s.point(.rightShoulder),
                  let lh = s.point(.leftHip), let rh = s.point(.rightHip) else { return nil }
            let d = hypot((ls.x + rs.x - lh.x - rh.x) / 2 * aspect, (ls.y + rs.y - lh.y - rh.y) / 2)
            return d > 0 ? d : nil
        }.sorted()
        return lengths.isEmpty ? nil : lengths[lengths.count / 2]
    }

    private static func distance(_ a: PosePoint, _ b: (x: Double, y: Double), aspect: Double) -> Double {
        hypot((a.x - b.x) * aspect, a.y - b.y)
    }

    private static func legJoints(_ s: KickerPoseSample) -> [PoseJoint: PosePoint]? {
        var out: [PoseJoint: PosePoint] = [:]
        for (l, r) in pairs {
            guard let a = s.point(l), let b = s.point(r) else { return nil }
            out[l] = a
            out[r] = b
        }
        return out
    }

    static func fixSwaps(_ timeline: KickerPoseTimeline, scale: Double, report: inout PoseRepairReport) -> KickerPoseTimeline {
        var result = timeline
        let aspect = timeline.displayAspectRatio ?? 1
        let samples = timeline.samples
        for i in samples.indices.dropFirst() {
            guard let now = legJoints(result.samples[i]), let previous = legJoints(result.samples[i - 1]) else { continue }
            // Constant-velocity prediction from the two previous (already repaired) samples.
            let before = i >= 2 ? legJoints(result.samples[i - 2]) : nil
            let dt = samples[i].timestamp - samples[i - 1].timestamp
            let dtBefore = i >= 2 ? samples[i - 1].timestamp - samples[i - 2].timestamp : 0
            func predicted(_ joint: PoseJoint) -> (x: Double, y: Double) {
                let p = previous[joint]!
                guard let b = before?[joint], dtBefore > 0, dt > 0 else { return (p.x, p.y) }
                let k = dt / dtBefore
                return (p.x + (p.x - b.x) * k, p.y + (p.y - b.y) * k)
            }
            var keep = 0.0
            var swapped = 0.0
            for (l, r) in pairs {
                keep += distance(now[l]!, predicted(l), aspect: aspect) + distance(now[r]!, predicted(r), aspect: aspect)
                swapped += distance(now[r]!, predicted(l), aspect: aspect) + distance(now[l]!, predicted(r), aspect: aspect)
            }
            if swapped < swapRatio * keep, (keep - swapped) / scale >= minimumSwapImprovement {
                for (l, r) in pairs {
                    let a = result.samples[i].joints[l]
                    result.samples[i].joints[l] = result.samples[i].joints[r]
                    result.samples[i].joints[r] = a
                }
                report.legSwapSamples.append(i)
            }
        }
        return result
    }

    static func rejectJumps(_ timeline: KickerPoseTimeline, scale: Double, sidewaysOnly: Bool = false,
                            report: inout PoseRepairReport) -> KickerPoseTimeline {
        var result = timeline
        let aspect = timeline.displayAspectRatio ?? 1
        let samples = timeline.samples
        var flagged = Set<Int>()
        for joint in pairs.flatMap({ [$0.0, $0.1] }) {
            var i = 1
            while i < samples.count - 1 {
                var rejected = 0
                for k in 1...maximumJumpSamples where i + k < samples.count {
                    guard let a = result.samples[i - 1].point(joint), let b = result.samples[i + k].point(joint) else { break }
                    let t0 = samples[i - 1].timestamp
                    let t1 = samples[i + k].timestamp
                    guard t1 > t0 else { break }
                    let inner = (i..<(i + k)).compactMap { j -> Double? in
                        guard let p = result.samples[j].point(joint) else { return nil }
                        let f = (samples[j].timestamp - t0) / (t1 - t0)
                        if sidewaysOnly { return abs(p.x - (a.x + (b.x - a.x) * f)) * aspect }
                        return distance(p, (a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f), aspect: aspect)
                    }
                    guard inner.count == k else { break }
                    let departure = inner.min() ?? 0
                    let bracket = sidewaysOnly ? abs(b.x - a.x) * aspect : hypot((b.x - a.x) * aspect, b.y - a.y)
                    if departure / scale > minimumJumpDistance, departure > bracket {
                        rejected = k
                        break
                    }
                }
                if rejected > 0 {
                    for j in i..<(i + rejected) {
                        result.samples[j].joints[joint] = .unavailable
                        report.outlierPoints += 1
                        flagged.insert(j)
                    }
                    i += rejected
                } else {
                    i += 1
                }
            }
        }
        report.outlierSamples = flagged.sorted()
        return result
    }
}
