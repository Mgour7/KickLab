#if canImport(Vision) && canImport(AVFoundation) && canImport(CoreML)
import AVFoundation
import CoreML
import CoreVideo
import Foundation
import ImageIO
import Vision

/// On-device 2D body-pose extraction with Apple Vision.
///
/// - Uses `VNDetectHumanBodyPoseRequest`: 19 body landmarks per person, several people
///   per frame, each landmark with its own confidence.
/// - Body pose only. No face recognition, identity recognition or biometric
///   identification is performed, and nothing leaves the device.
/// - Frames are streamed from `VideoFrameReader`; each frame's pixel buffer is released
///   after detection.
/// - Before any frame is read, `probeRuntime()` runs the request once on a synthetic
///   blank image. If Vision cannot execute even that (typical of the iOS Simulator), the
///   extractor throws `PoseDetectionError.runtimeUnavailable` instead of reporting every
///   frame of a healthy video as failed. No pose data is produced in that case.
/// - Once the runtime works, a frame on which Vision throws is recorded as `.failed`
///   (a dropped frame) rather than ending the run; a frame with nobody in it is
///   `.analyzed` with no bodies.
struct VisionPoseSequenceExtractor: PoseSequenceExtracting {
    init() {}

    var isAvailable: Bool { true }

    func extract(
        videoURL: URL,
        videoID: UUID,
        sampling: FrameSamplingPlan,
        progress: @escaping @Sendable (Double) -> Void
    ) async throws -> PoseSequence {
        let probe = Self.probeRuntime()
        guard probe.status.isAvailable else {
            throw PoseDetectionError.runtimeUnavailable(environment: Self.environment)
        }
        let info = try await VideoFrameReader.trackInfo(for: videoURL)
        let request = Self.makeRequest(cpuOnly: probe.usesCPUOnly)
        // Detection runs on the upright, UN-mirrored image (see `PoseCoordinates.appJoints`).
        let orientation = Self.imageOrientation(info.orientation)
        let span = Self.progressSpan(info: info, sampling: sampling)

        var frames: [PoseFrame] = []
        try await VideoFrameReader.read(url: videoURL, plan: sampling) { index, time, pixelBuffer in
            frames.append(Self.detect(in: pixelBuffer, orientation: orientation, isMirrored: info.isMirrored,
                                      request: request, index: index, time: time))
            if let span, span.length > 0 {
                progress(min(1, max(0, (time - span.start) / span.length)))
            }
        }
        progress(1)

        // Decoded frames arrive in presentation order; sort defensively so the timeline
        // is monotonic even if a container delivers them otherwise.
        if !zip(frames, frames.dropFirst()).allSatisfy({ $0.timestamp <= $1.timestamp }) {
            frames.sort { $0.timestamp < $1.timestamp }
            for i in frames.indices { frames[i].frameIndex = i }
        }

        return PoseSequence(
            videoID: videoID,
            durationSeconds: info.durationSeconds,
            nominalFrameRate: info.nominalFrameRate,
            analysisFrameRate: sampling.targetFrameRate,
            orientation: info.orientation,
            isMirrored: info.isMirrored,
            displayAspectRatio: info.displayAspectRatio,
            frames: frames,
            kickerTrackID: nil
        )
    }

    // MARK: Detection

    /// The runtime KickLab is running in.
    static var environment: PoseRuntimeEnvironment {
        #if targetEnvironment(simulator)
        return .simulator
        #else
        return .device
        #endif
    }

    /// The outcome of running pose detection once on a synthetic blank image.
    struct RuntimeProbe: Equatable, Sendable {
        let status: PoseDetectionRuntimeStatus
        /// True when the detector only worked after being restricted to the CPU (simulator only).
        let usesCPUOnly: Bool
    }

    /// Checks whether Vision body-pose detection can execute here, independent of any
    /// video. On a device this tries the standard configuration only, exactly as
    /// analysis uses it. In the simulator it also tries a CPU-only configuration.
    /// The blank image contains no person; a successful probe produces no pose data.
    static func probeRuntime() -> RuntimeProbe {
        guard let image = makeProbeImage() else {
            return RuntimeProbe(status: .unavailable(environment: environment), usesCPUOnly: false)
        }
        if canPerform(makeRequest(cpuOnly: false), on: image) {
            return RuntimeProbe(status: .available, usesCPUOnly: false)
        }
        if environment == .simulator, canPerform(makeRequest(cpuOnly: true), on: image) {
            return RuntimeProbe(status: .available, usesCPUOnly: true)
        }
        return RuntimeProbe(status: .unavailable(environment: environment), usesCPUOnly: false)
    }

    static func makeRequest(cpuOnly: Bool) -> VNDetectHumanBodyPoseRequest {
        let request = VNDetectHumanBodyPoseRequest()
        if cpuOnly,
           let cpu = MLComputeDevice.allComputeDevices.first(where: { if case .cpu(_) = $0 { return true } else { return false } }) {
            request.setComputeDevice(cpu, for: .main)
        }
        return request
    }

    private static func canPerform(_ request: VNDetectHumanBodyPoseRequest, on image: CVPixelBuffer) -> Bool {
        let handler = VNImageRequestHandler(cvPixelBuffer: image, orientation: .up, options: [:])
        do {
            try handler.perform([request])
            return true
        } catch {
            return false
        }
    }

    /// A small mid-gray image (no person).
    private static func makeProbeImage() -> CVPixelBuffer? {
        let width = 256
        let height = 192
        var buffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, nil, &buffer)
        guard status == kCVReturnSuccess, let buffer else { return nil }
        CVPixelBufferLockBaseAddress(buffer, [])
        if let base = CVPixelBufferGetBaseAddress(buffer) {
            memset(base, 0x80, CVPixelBufferGetDataSize(buffer))
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        return buffer
    }

    static func detect(
        in pixelBuffer: CVPixelBuffer,
        orientation: CGImagePropertyOrientation,
        isMirrored: Bool,
        request: VNDetectHumanBodyPoseRequest,
        index: Int,
        time: Double
    ) -> PoseFrame {
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation, options: [:])
        do {
            try handler.perform([request])
        } catch {
            return PoseFrame(frameIndex: index, timestamp: time, bodies: [], status: .failed)
        }
        let bodies = (request.results ?? []).compactMap { observation -> BodyPose? in
            guard let points = try? observation.recognizedPoints(.all) else { return nil }
            var raw: [PoseJoint: (x: Double, y: Double, confidence: Double)] = [:]
            for (name, joint) in jointNames {
                guard let point = points[name] else { continue }
                raw[joint] = (Double(point.location.x), Double(point.location.y), Double(point.confidence))
            }
            let joints = PoseCoordinates.appJoints(fromVision: raw, isMirrored: isMirrored)
            let body = BodyPose(joints: joints)
            return body.availablePoints.isEmpty ? nil : body
        }
        return PoseFrame(frameIndex: index, timestamp: time, bodies: bodies, status: .analyzed)
    }

    /// Vision joint names → KickLab joints. Computed, so there is no shared mutable state.
    static var jointNames: [(VNHumanBodyPoseObservation.JointName, PoseJoint)] {
        [
            (.nose, .nose), (.leftEye, .leftEye), (.rightEye, .rightEye),
            (.leftEar, .leftEar), (.rightEar, .rightEar), (.neck, .neck),
            (.leftShoulder, .leftShoulder), (.rightShoulder, .rightShoulder),
            (.leftElbow, .leftElbow), (.rightElbow, .rightElbow),
            (.leftWrist, .leftWrist), (.rightWrist, .rightWrist),
            (.root, .root), (.leftHip, .leftHip), (.rightHip, .rightHip),
            (.leftKnee, .leftKnee), (.rightKnee, .rightKnee),
            (.leftAnkle, .leftAnkle), (.rightAnkle, .rightAnkle),
        ]
    }

    static func imageOrientation(_ orientation: VideoOrientation) -> CGImagePropertyOrientation {
        switch orientation {
        case .up: .up
        case .right: .right
        case .down: .down
        case .left: .left
        }
    }

    private static func progressSpan(info: VideoTrackInfo, sampling: FrameSamplingPlan) -> (start: Double, length: Double)? {
        guard let duration = info.durationSeconds else { return nil }
        let start = max(0, sampling.timeRange?.lowerBound ?? 0)
        let end = min(duration, sampling.timeRange?.upperBound ?? duration)
        return (start, end - start)
    }
}
#endif
