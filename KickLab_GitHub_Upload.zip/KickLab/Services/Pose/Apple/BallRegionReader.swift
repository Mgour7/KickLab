#if canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
import AVFoundation
import CoreMedia
import CoreVideo
import Foundation

/// Step 12G: reads the marked ball's region from the real decoded frames (luma plane of
/// 8-bit 4:2:0 buffers from `VideoFrameReader`), with true presentation times.
struct AVBallRegionReader: BallRegionReading {
    func crops(url: URL, mark: VideoVerification.BallMark, duration: Double, targetRadius: Double) async throws
        -> (frames: [(time: Double, image: LumaImage)], radius: Double) {
        let info = try await VideoFrameReader.trackInfo(for: url)
        let plan = FrameSamplingPlan(rate: .everyFrame, timeRange: mark.time...(mark.time + duration))
        var frames: [(time: Double, image: LumaImage)] = []
        var radius = 0.0
        try await VideoFrameReader.read(url: url, plan: plan) { _, time, buffer in
            let width = CVPixelBufferGetWidthOfPlane(buffer, 0), height = CVPixelBufferGetHeightOfPlane(buffer, 0)
            guard let g = LumaCropGeometry.crop(mark: mark, bufferWidth: width, bufferHeight: height, orientation: info.orientation,
                                                isMirrored: info.isMirrored, targetRadius: targetRadius) else { return }
            CVPixelBufferLockBaseAddress(buffer, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
            guard let base = CVPixelBufferGetBaseAddressOfPlane(buffer, 0) else { return }
            let stride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 0)
            let bytes = base.assumingMemoryBound(to: UInt8.self)
            let image = LumaCropGeometry.downsample({ x, y in bytes[y * stride + x] }, x0: g.cx - g.half, y0: g.cy - g.half,
                                                    size: 2 * g.half, factor: g.factor)
            radius = g.radius
            frames.append((time, image))
        }
        return (frames, radius)
    }
}
#endif
