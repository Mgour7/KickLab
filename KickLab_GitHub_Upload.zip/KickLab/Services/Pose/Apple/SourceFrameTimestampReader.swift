#if canImport(AVFoundation) && canImport(CoreMedia)
import AVFoundation
import CoreMedia
import Foundation

/// Step 12F: every frame's presentation time, read from the compressed samples
/// (`outputSettings: nil`, so nothing is decoded). Sorted by `SourceFrameTable`, because
/// samples arrive in decode order.
struct AVSourceFrameTimestampReader: SourceFrameTimestampReading {
    func frameTimes(for url: URL) async throws -> [Double] {
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw VideoFrameReaderError.noVideoTrack
        }
        let reader = try AVAssetReader(asset: asset)
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw VideoFrameReaderError.cannotRead("Can't read this video track.") }
        reader.add(output)
        guard reader.startReading() else {
            throw VideoFrameReaderError.cannotRead(reader.error?.localizedDescription ?? "Can't start reading.")
        }
        var times: [Double] = []
        while let sample = output.copyNextSampleBuffer() {
            if Task.isCancelled {
                reader.cancelReading()
                throw CancellationError()
            }
            guard CMSampleBufferGetNumSamples(sample) > 0 else { continue }
            let time = CMSampleBufferGetPresentationTimeStamp(sample)
            if time.isValid, time.seconds.isFinite { times.append(time.seconds) }
        }
        if reader.status == .failed {
            throw VideoFrameReaderError.cannotRead(reader.error?.localizedDescription ?? "Reading failed.")
        }
        return SourceFrameTable.normalized(times)
    }
}
#endif
