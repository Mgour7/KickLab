#if canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
import AVFoundation
import CoreMedia
import CoreVideo
import Foundation

/// Facts about a video track that pose analysis needs.
struct VideoTrackInfo: Equatable, Sendable {
    let naturalWidth: Double
    let naturalHeight: Double
    let nominalFrameRate: Double?
    let durationSeconds: Double?
    let orientation: VideoOrientation
    let isMirrored: Bool

    var displayAspectRatio: Double? {
        PoseCoordinates.displayAspectRatio(naturalWidth: naturalWidth, naturalHeight: naturalHeight, orientation: orientation)
    }
}

enum VideoFrameReaderError: Error, Equatable, Sendable {
    case noVideoTrack
    case cannotRead(String)
}

/// Streams decoded frames of a local video with AVAssetReader.
///
/// - Frames are delivered one at a time to a synchronous handler and released right
///   after, so memory stays flat for long or high-frame-rate (e.g. 240 fps) clips.
/// - Timestamps are each frame's TRUE presentation time; no frame rate is assumed.
/// - `FrameSampler` decides which frames to keep (every frame, a target rate, a time range).
/// - Cancellation is checked before every frame; reading stops and `CancellationError` is thrown.
/// - Pixel buffers are 8-bit 4:2:0 full range, which Vision consumes without conversion.
///
/// Runs on the caller's executor; call it from a background task, never the main actor.
enum VideoFrameReader {
    static func trackInfo(for url: URL) async throws -> VideoTrackInfo {
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw VideoFrameReaderError.noVideoTrack
        }
        let (size, transform, rate) = try await track.load(.naturalSize, .preferredTransform, .nominalFrameRate)
        let duration = try await asset.load(.duration).seconds
        let oriented = PoseCoordinates.orientation(from: AffineTransformValues(
            a: Double(transform.a), b: Double(transform.b), c: Double(transform.c), d: Double(transform.d)
        ))
        return VideoTrackInfo(
            naturalWidth: Double(size.width),
            naturalHeight: Double(size.height),
            nominalFrameRate: rate > 0 ? Double(rate) : nil,
            durationSeconds: duration.isFinite && duration > 0 ? duration : nil,
            orientation: oriented.orientation,
            isMirrored: oriented.isMirrored
        )
    }

    /// Decodes the video and calls `handle(index, presentationTime, pixelBuffer)` for every
    /// kept frame. `index` counts kept frames from 0. Returns the number of kept frames.
    @discardableResult
    static func read(
        url: URL,
        plan: FrameSamplingPlan,
        handle: (Int, Double, CVPixelBuffer) throws -> Void
    ) async throws -> Int {
        try Task.checkCancellation()
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw VideoFrameReaderError.noVideoTrack
        }
        try Task.checkCancellation()

        let reader = try AVAssetReader(asset: asset)
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange,
        ])
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw VideoFrameReaderError.cannotRead("Can't decode this video track.") }
        reader.add(output)
        if let range = plan.timeRange {
            // Start a little early; the sampler applies the exact bounds.
            let start = max(0, range.lowerBound - 0.05)
            reader.timeRange = CMTimeRange(
                start: CMTime(seconds: start, preferredTimescale: 600),
                duration: CMTime(seconds: range.upperBound - start + 0.05, preferredTimescale: 600)
            )
        }
        guard reader.startReading() else {
            throw VideoFrameReaderError.cannotRead(reader.error?.localizedDescription ?? "Can't start reading.")
        }

        var sampler = FrameSampler(plan: plan)
        var kept = 0
        reading: while let sample = output.copyNextSampleBuffer() {
            if Task.isCancelled {
                reader.cancelReading()
                throw CancellationError()
            }
            let time = CMSampleBufferGetPresentationTimeStamp(sample).seconds
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
            switch sampler.decide(presentationTime: time) {
            case .skip:
                continue
            case .stop:
                reader.cancelReading()
                break reading
            case .keep:
                try autoreleasepool {
                    try handle(kept, time, pixelBuffer)
                }
                kept += 1
            }
        }
        if Task.isCancelled {
            reader.cancelReading()
            throw CancellationError()
        }
        if reader.status == .failed {
            throw VideoFrameReaderError.cannotRead(reader.error?.localizedDescription ?? "Reading failed.")
        }
        return kept
    }
}
#endif
