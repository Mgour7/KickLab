import Foundation

/// Where pose detection is running. The iOS Simulator is reported separately because
/// Apple's on-device pose models may not run there at all.
enum PoseRuntimeEnvironment: String, Codable, Equatable, Sendable {
    case device
    case simulator
}

/// Whether the pose detector can execute in this runtime, independent of any video.
enum PoseDetectionRuntimeStatus: Equatable, Sendable {
    case available
    /// The detector failed on a synthetic blank image, so it cannot run here at all.
    case unavailable(environment: PoseRuntimeEnvironment)

    var isAvailable: Bool { self == .available }
}

/// Typed pose-extraction errors that are NOT about the video's content.
enum PoseDetectionError: Error, Equatable, Sendable {
    /// The detector cannot execute in this runtime (for example, the iOS Simulator lacks
    /// the inference backend). The video was not analyzed; it is not corrupt.
    case runtimeUnavailable(environment: PoseRuntimeEnvironment)
}

/// Runs pose detection over one video file and returns every detected body per sampled
/// frame (track IDs unassigned). The production implementation uses Apple Vision on
/// device (`VisionPoseSequenceExtractor`); tests can supply synthetic sequences.
///
/// Implementations must run entirely on-device, must not identify people (pose only:
/// no face, identity or biometric recognition), and must honor task cancellation.
/// When the detector cannot run at all in this runtime they throw
/// `PoseDetectionError.runtimeUnavailable` before analyzing any frame, rather than
/// reporting every frame as failed.
protocol PoseSequenceExtracting: Sendable {
    var isAvailable: Bool { get }

    func extract(
        videoURL: URL,
        videoID: UUID,
        sampling: FrameSamplingPlan,
        progress: @escaping @Sendable (Double) -> Void
    ) async throws -> PoseSequence
}

/// The real `VideoAnalysisService` engine: pose foundation (Step 7) plus biomechanics
/// metrics, category scores and rule-based coaching (Step 8).
///
/// It extracts pose from the primary video, selects the kicker, cleans the pose
/// timeline, derives signals, detects kick phases, and writes versioned artifacts.
/// The result carries metric, score and observation drafts for `AnalysisService`, the
/// overall score and confidence, and operational facts in `poseSummary`. Unmeasurable
/// metrics are `.unavailable` drafts, never invented numbers.
///
/// Everything runs locally. No video or pose data leaves the device.
///
/// Multi-video: every input is validated, but only the primary video is analyzed in V1.
/// Other videos are listed in the manifest with their `syncOffsetSeconds` (see
/// `AnalysisArtifactManifest` for the fusion extension point).
struct PoseVideoAnalysisService: VideoAnalysisService {
    static let version = "pose-biomechanics-2.1.0"

    let mediaStore: ManagedMediaStore
    let extractor: any PoseSequenceExtracting
    let ballTracker: any BallTrackingService
    let trackingConfiguration: PoseTrackingConfiguration
    let processingConfiguration: PoseProcessingConfiguration
    let biomechanicsProfiles: any BiomechanicsProfileProviding
    let now: @Sendable () -> Date

    init(
        mediaStore: ManagedMediaStore,
        extractor: any PoseSequenceExtracting,
        ballTracker: any BallTrackingService = UnavailableBallTrackingService(),
        trackingConfiguration: PoseTrackingConfiguration = .standard,
        processingConfiguration: PoseProcessingConfiguration = .standard,
        biomechanicsProfiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles(),
        now: @escaping @Sendable () -> Date = { Date.now }
    ) {
        self.mediaStore = mediaStore
        self.extractor = extractor
        self.ballTracker = ballTracker
        self.trackingConfiguration = trackingConfiguration
        self.processingConfiguration = processingConfiguration
        self.biomechanicsProfiles = biomechanicsProfiles
        self.now = now
    }

    var engineVersion: String { Self.version }

    var availability: VideoAnalysisAvailability {
        extractor.isAvailable ? .available : .unavailable(reason: "Pose detection isn't available on this device.")
    }

    // MARK: Prepare

    func prepare(_ request: VideoAnalysisRequest) async throws -> PreparedVideoAnalysis {
        try Self.checkCancellation()
        guard availability.isAvailable else { throw VideoAnalysisError.unavailable(reason: "Pose detection isn't available on this device.") }
        guard !request.inputs.isEmpty else { throw VideoAnalysisError.noInputs }

        var usable: [VideoAnalysisInput] = []
        var rejected: [RejectedAnalysisInput] = []
        for input in request.inputs {
            if let reason = rejectionReason(for: input) {
                rejected.append(RejectedAnalysisInput(videoID: input.videoID, reason: reason))
            } else {
                usable.append(input)
            }
        }
        guard let primary = Self.choosePrimary(from: usable) else { throw VideoAnalysisError.noUsableInputs }
        let ordered = [primary] + usable.filter { $0.videoID != primary.videoID }

        return PreparedVideoAnalysis(
            requestID: request.id,
            engineVersion: engineVersion,
            usableVideoIDs: ordered.map(\.videoID),
            rejectedInputs: rejected,
            estimatedFrameCount: Self.estimatedFrameCount(for: primary, sampling: request.options.sampling)
        )
    }

    /// The designated primary video when usable; otherwise a side view; otherwise the first usable.
    static func choosePrimary(from usable: [VideoAnalysisInput]) -> VideoAnalysisInput? {
        usable.first(where: \.isPrimary) ?? usable.first(where: { $0.angle == .side }) ?? usable.first
    }

    static func estimatedFrameCount(for input: VideoAnalysisInput, sampling: FrameSamplingPlan) -> Int? {
        guard let duration = input.durationSeconds, duration > 0 else { return nil }
        var seconds = duration
        if let range = sampling.timeRange {
            seconds = max(0, min(duration, range.upperBound) - max(0, range.lowerBound))
        }
        let sourceRate = input.frameRate ?? 30
        let rate = sampling.targetFrameRate.map { min($0, sourceRate) } ?? sourceRate
        return Int((seconds * rate).rounded(.up))
    }

    private func rejectionReason(for input: VideoAnalysisInput) -> String? {
        guard let path = input.relativeFilePath else { return "The video has no file stored in KickLab." }
        guard let url = try? mediaStore.url(for: path, in: .media) else { return "The video's stored path is invalid." }
        guard mediaStore.fileSystem.itemExists(at: url) else { return "The video file is missing." }
        return nil
    }

    // MARK: Analyze

    func analyze(
        _ request: VideoAnalysisRequest,
        progress: @escaping @Sendable (VideoAnalysisProgress) -> Void
    ) async throws -> VideoAnalysisResult {
        progress(VideoAnalysisProgress(stage: .preparing, fractionCompleted: 0))
        let prepared = try await prepare(request)
        guard
            let primaryID = prepared.usableVideoIDs.first,
            let primary = request.inputs.first(where: { $0.videoID == primaryID }),
            let path = primary.relativeFilePath
        else { throw VideoAnalysisError.noUsableInputs }

        let videoURL: URL
        do {
            videoURL = try mediaStore.url(for: path, in: .media)
        } catch {
            throw VideoAnalysisError.noUsableInputs
        }

        // 1. Pose extraction (streamed frame by frame; the heavy part).
        progress(VideoAnalysisProgress(stage: .detectingPose, fractionCompleted: 0.02, message: "Detecting body pose"))
        let sequence: PoseSequence
        do {
            sequence = try await extractor.extract(
                videoURL: videoURL, videoID: primary.videoID, sampling: request.options.sampling
            ) { fraction in
                progress(VideoAnalysisProgress(stage: .detectingPose, fractionCompleted: 0.02 + 0.83 * fraction))
            }
        } catch {
            throw Self.mapped(error)
        }
        try Self.checkCancellation()

        guard !sequence.frames.isEmpty else { throw VideoAnalysisError.failed("No frames could be read from the video.") }
        guard sequence.frames.contains(where: { $0.status == .analyzed }) else {
            throw VideoAnalysisError.failed("Pose detection failed on every frame.")
        }

        // 2. Ball tracking (unavailable in V1; contact stays an estimate).
        let ball: BallTrackingResult
        do {
            ball = try await ballTracker.track(videoID: primary.videoID, timestamps: sequence.frames.map(\.timestamp))
        } catch {
            throw Self.mapped(error)
        }

        // 3. Pure pipeline: tracking → processing → signals → phases → biomechanics.
        progress(VideoAnalysisProgress(stage: .detectingEvents, fractionCompleted: 0.88, message: "Finding kick phases"))
        let resultID = request.options.artifactsDirectoryID ?? request.id
        let output = KickAnalysisPipeline.run(KickAnalysisPipelineInput(
            sequence: sequence,
            kickType: request.kickType,
            kickingFoot: request.options.kickingFoot,
            kickerSeed: request.options.kickerSeed,
            kickLocationHint: request.options.kickLocationHint,
            tracking: trackingConfiguration,
            processing: processingConfiguration,
            cameraAngle: primary.angle,
            profiles: biomechanicsProfiles,
            idSeed: resultID
        ))
        progress(VideoAnalysisProgress(stage: .scoring, fractionCompleted: 0.92, message: "Measuring mechanics"))
        try Self.checkCancellation()

        // 4. Artifacts.
        progress(VideoAnalysisProgress(stage: .finishing, fractionCompleted: 0.95, message: "Saving analysis data"))
        let directory = ManagedPath.analysisDirectory(analysisID: resultID)
        let bundle = makeBundle(request: request, prepared: prepared, primary: primary, output: output, ball: ball)
        do {
            try AnalysisArtifactStore(analysisRootURL: mediaStore.analysisRootURL, fileSystem: mediaStore.fileSystem)
                .write(bundle, to: directory)
        } catch {
            throw VideoAnalysisError.failed("Couldn't save analysis data: \(error)")
        }

        progress(VideoAnalysisProgress(stage: .finishing, fractionCompleted: 1))
        let biomechanics = output.biomechanics
        return VideoAnalysisResult(
            requestID: request.id,
            engineVersion: engineVersion,
            metrics: biomechanics.metricDrafts,
            categoryScores: biomechanics.scoreDrafts,
            observations: biomechanics.observationDrafts,
            overallConfidence: biomechanics.overallConfidence,
            overallScore: biomechanics.overallScore,
            artifactsRelativePath: directory,
            poseSummary: PoseAnalysisSummary(primaryVideoID: primary.videoID, output: output)
        )
    }

    private func makeBundle(
        request: VideoAnalysisRequest,
        prepared: PreparedVideoAnalysis,
        primary: VideoAnalysisInput,
        output: KickAnalysisPipelineOutput,
        ball: BallTrackingResult
    ) -> AnalysisArtifactBundle {
        let usable = Set(prepared.usableVideoIDs)
        let videos = request.inputs.filter { usable.contains($0.videoID) }.map { input in
            ArtifactVideoEntry(
                videoID: input.videoID,
                angle: input.angle,
                isPrimary: input.videoID == primary.videoID,
                syncOffsetSeconds: input.syncOffsetSeconds,
                analyzed: input.videoID == primary.videoID
            )
        }
        let manifest = AnalysisArtifactManifest(
            engineVersion: engineVersion,
            requestID: request.id,
            kickID: request.kickID,
            kickType: request.kickType,
            primaryVideoID: primary.videoID,
            videos: videos,
            posePath: AnalysisArtifactManifest.defaultPosePath,
            signalsPath: AnalysisArtifactManifest.defaultSignalsPath,
            phasesPath: AnalysisArtifactManifest.defaultPhasesPath,
            biomechanicsPath: AnalysisArtifactManifest.defaultBiomechanicsPath,
            createdAt: now()
        )
        return AnalysisArtifactBundle(
            manifest: manifest,
            pose: PoseArtifact(
                videoID: primary.videoID,
                sampling: request.options.sampling,
                trackingConfiguration: trackingConfiguration,
                processingConfiguration: processingConfiguration,
                sequence: output.sequence,
                tracking: output.tracking,
                kickerTimeline: output.kickerTimeline
            ),
            signals: SignalArtifact(videoID: primary.videoID, signals: output.signals),
            phases: PhaseArtifact(videoID: primary.videoID, phases: output.phases, ball: ball),
            biomechanics: BiomechanicsArtifact(videoID: primary.videoID, result: output.biomechanics)
        )
    }

    // MARK: Errors

    private static func checkCancellation() throws {
        if Task.isCancelled { throw VideoAnalysisError.cancelled }
    }

    static func mapped(_ error: any Error) -> VideoAnalysisError {
        if let error = error as? VideoAnalysisError { return error }
        if case .runtimeUnavailable(let environment)? = error as? PoseDetectionError {
            return .poseDetectionUnavailable(environment: environment)
        }
        if error is CancellationError || Task.isCancelled { return .cancelled }
        return .failed(String(describing: error))
    }
}
