import Foundation

/// Step 12F: what the football detector contributed to a contact estimate. Stored in the
/// phase evidence and diagnostics. With no football model in the app, `detectorAvailable`
/// is false and nothing else is claimed.
struct BallContactEvidence: Codable, Equatable, Sendable {
    enum Outcome: String, Codable, Sendable {
        /// No football-recognition model is installed; nothing was looked for.
        case detectorUnavailable
        /// The detector ran but the ball wasn't seen reliably near the strike.
        case ballNotVisible
        /// Detections were too inconsistent to use (jumping, low confidence).
        case unreliable
        /// The ball's first movement agrees with the pose interval.
        case consistent
        /// The ball's first movement contradicts the pose interval.
        case conflicting
    }

    var outcome: Outcome
    var detectorName: String?
    var framesExamined: Int
    var framesWithBall: Int
    /// Last frame where the placed ball was still in its resting position.
    var lastStationaryTime: Double?
    /// First frame where the ball had clearly moved.
    var firstDisplacementTime: Double?
    /// Frames where the kicking foot was within reach of the ball.
    var proximityStartTime: Double?
    var proximityEndTime: Double?
    /// The contact interval the ball supports (between the last resting frame and the
    /// first moved frame).
    var contactEarliestTime: Double?
    var contactLatestTime: Double?
    var note: String

    static let unavailable = BallContactEvidence(
        outcome: .detectorUnavailable, detectorName: nil, framesExamined: 0, framesWithBall: 0,
        lastStationaryTime: nil, firstDisplacementTime: nil, proximityStartTime: nil, proximityEndTime: nil,
        contactEarliestTime: nil, contactLatestTime: nil,
        note: "Automatic football detection is not available in this build: no football-recognition model is installed, so contact is estimated from body pose only."
    )
}

/// Step 12F: fuses a football track (when one exists) with the pose-only first-contact
/// interval. Pure and testable; production only ever passes REAL detections — tests use
/// clearly test-only observations.
enum BallContactFusion {
    /// The ball counts as moved when its center shifts by more than this many ball
    /// diameters from its resting position.
    static let displacementBallSizes = 0.5
    /// Observations below this confidence are ignored.
    static let minimumConfidence = 0.5
    /// The foot is "at the ball" within this many ball diameters.
    static let proximityBallSizes = 1.5
    /// At least this share of examined frames around the strike must contain the ball.
    static let minimumVisibleShare = 0.6

    /// - Parameters:
    ///   - ball: the tracker's result for the analyzed frames. Only `.tracked`
    ///     observations count (predicted positions are not evidence).
    ///   - kickingAnkle: the kicking ankle per frame time, in the same normalized image
    ///     coordinates as the ball.
    ///   - aspect: display width ÷ height, so distances are measured in true proportions.
    ///   - poseInterval: the pose-only first-contact interval (nil when not established).
    ///   - window: the times to examine around the strike.
    static func evaluate(ball: BallTrackingResult, kickingAnkle: [(time: Double, point: NormalizedPoint)], aspect: Double,
                         poseInterval: ClosedRange<Double>?, window: ClosedRange<Double>) -> BallContactEvidence {
        guard ball.status != .unavailable else { return .unavailable }
        let inWindow = ball.observations.filter { window.contains($0.timestamp) }.sorted { $0.timestamp < $1.timestamp }
        let seen = inWindow.filter { $0.status == .tracked && $0.position != nil && $0.confidence >= minimumConfidence && ($0.radius ?? 0) > 0 }
        var e = BallContactEvidence(outcome: .ballNotVisible, detectorName: "ballTracker", framesExamined: inWindow.count,
                                    framesWithBall: seen.count, lastStationaryTime: nil, firstDisplacementTime: nil,
                                    proximityStartTime: nil, proximityEndTime: nil, contactEarliestTime: nil, contactLatestTime: nil,
                                    note: "")
        guard !inWindow.isEmpty, Double(seen.count) / Double(inWindow.count) >= minimumVisibleShare, seen.count >= 3 else {
            e.note = "The football wasn't visible in enough examined frames around the strike; contact stays pose-only."
            return e
        }
        func distance(_ a: NormalizedPoint, _ b: NormalizedPoint) -> Double { hypot((a.x - b.x) * aspect, a.y - b.y) }
        // Resting position and size: medians of the first three confident sightings.
        let first3 = Array(seen.prefix(3))
        let xs = first3.compactMap { $0.position?.x }.sorted(), ys = first3.compactMap { $0.position?.y }.sorted()
        let rest = NormalizedPoint(x: xs[xs.count / 2], y: ys[ys.count / 2])
        let diameter = 2 * (first3.compactMap(\.radius).sorted()[first3.count / 2])
        let restSpread = first3.compactMap { $0.position.map { distance($0, rest) } }.max() ?? 0
        guard restSpread <= displacementBallSizes * diameter else {
            e.outcome = .unreliable
            e.note = "The football's position jumped before the kick (detections unstable), so it wasn't used."
            return e
        }
        func moved(_ o: BallObservation) -> Bool { o.position.map { distance($0, rest) > displacementBallSizes * diameter } ?? false }
        guard let firstMoved = seen.firstIndex(where: moved) else {
            e.outcome = .unreliable
            e.note = "The football never left its resting position in the examined frames."
            return e
        }
        // Once moved, it must stay moved (a single jump is a misdetection).
        let afterMove = seen[firstMoved...].prefix(3)
        guard afterMove.count >= 2, afterMove.allSatisfy(moved) else {
            e.outcome = .unreliable
            e.note = "The football's apparent movement didn't persist — likely a misdetection."
            return e
        }
        guard firstMoved > 0 else {
            e.outcome = .unreliable
            e.note = "The ball was already moving in the first examined frames."
            return e
        }
        let lastRest = seen[firstMoved - 1]
        e.lastStationaryTime = lastRest.timestamp
        e.firstDisplacementTime = seen[firstMoved].timestamp
        let near = kickingAnkle.filter { window.contains($0.time) && distance($0.point, rest) <= proximityBallSizes * diameter }.map(\.time).sorted()
        e.proximityStartTime = near.first
        e.proximityEndTime = near.last
        // Contact lies after the last resting frame and no later than the first moved one.
        let earliest = lastRest.timestamp, latest = seen[firstMoved].timestamp
        e.contactEarliestTime = earliest
        e.contactLatestTime = latest
        guard let reach = near.first, reach <= latest + 1e-9 else {
            e.outcome = .unreliable
            e.note = "The ball moved without the kicking foot reaching it first — not consistent with a strike."
            return e
        }
        if let pose = poseInterval {
            let overlaps = max(pose.lowerBound, earliest) <= min(pose.upperBound, latest) + 1e-9
            e.outcome = overlaps ? .consistent : .conflicting
            e.note = overlaps
                ? String(format: "The ball rested until %.3f s and had moved by %.3f s, overlapping the pose estimate.", earliest, latest)
                : String(format: "The ball rested until %.3f s and had moved by %.3f s, outside the pose estimate (%.3f–%.3f s).",
                         earliest, latest, pose.lowerBound, pose.upperBound)
        } else {
            e.outcome = .consistent
            e.note = String(format: "The ball rested until %.3f s and had moved by %.3f s (no pose estimate to compare).", earliest, latest)
        }
        return e
    }

    /// The fused first-contact interval: where the ball interval and the pose interval
    /// overlap (the ball's alone when there is no pose interval); nil on conflict.
    static func fusedInterval(pose: ClosedRange<Double>?, ball: BallContactEvidence) -> (interval: ClosedRange<Double>?, provenance: String) {
        switch ball.outcome {
        case .consistent:
            guard let a = ball.contactEarliestTime, let b = ball.contactLatestTime else { return (pose, "poseOnly") }
            if let pose {
                let lo = max(a, pose.lowerBound), hi = min(b, pose.upperBound)
                return (lo <= hi ? lo...hi : a...b, "ballAware")
            }
            return (a...b, "ballAware")
        case .conflicting:
            return (nil, "conflict")
        case .detectorUnavailable, .ballNotVisible, .unreliable:
            return (pose, "poseOnly")
        }
    }

    /// Applies the ball evidence to an automatic phase result. With no ball tracker (the
    /// shipping app) only `ballEvidence = .unavailable` is recorded. User-assisted results
    /// are never changed.
    static func apply(_ phases: KickPhaseDetectionResult, ball: BallTrackingResult, timeline: KickerPoseTimeline,
                      kickingFoot: KickingFoot) -> KickPhaseDetectionResult {
        guard var evidence = phases.evidence, !phases.isUserAssisted else { return phases }
        guard ball.status != .unavailable else {
            var result = phases
            evidence.ballEvidence = .unavailable
            if evidence.contactProvenance == nil, phases.phase(.contact).isAvailable { evidence.contactProvenance = "poseOnly" }
            result.evidence = evidence
            return result
        }
        let contact = phases.phase(.contact)
        let pose: ClosedRange<Double>? = contact.representativeTime.map { t in
            (evidence.contactEarliestTime ?? t)...(evidence.contactLatestTime ?? t)
        }
        let center = contact.representativeTime ?? phases.plantTime ?? timeline.samples.first?.timestamp ?? 0
        let window = (center - 0.6)...(center + 0.6)
        let joint = KickingSideJoints(kickingFoot: kickingFoot).kickingAnkle
        let ankle = timeline.samples.compactMap { s in s.point(joint).map { (time: s.timestamp, point: NormalizedPoint(x: $0.x, y: $0.y)) } }
        let e = evaluate(ball: ball, kickingAnkle: ankle, aspect: timeline.displayAspectRatio ?? 1, poseInterval: pose, window: window)
        evidence.ballEvidence = e
        let fused = fusedInterval(pose: pose, ball: e)
        evidence.contactProvenance = fused.provenance == "conflict" ? "poseOnly" : fused.provenance
        var phaseList = phases.phases
        var notes = phases.notes
        if let i = phaseList.firstIndex(where: { $0.phase == .contact }), contact.isAvailable {
            let c = phaseList[i]
            if fused.provenance == "conflict" {
                phaseList[i] = DetectedKickPhase(phase: .contact, startTime: c.startTime, endTime: c.endTime,
                                                 representativeTime: c.representativeTime, confidence: c.confidence * 0.4,
                                                 evidence: c.evidence, status: .ambiguous)
                evidence.contactConflicts = (evidence.contactConflicts ?? []) + [e.note + " Verify the contact frame yourself."]
                notes.append(e.note)
            } else if fused.provenance == "ballAware", let interval = fused.interval {
                let inside = timeline.samples.map(\.timestamp).filter { interval.contains($0) }
                if !inside.isEmpty {
                    let t = inside[(inside.count - 1) / 2]
                    phaseList[i] = DetectedKickPhase(phase: .contact, startTime: t, endTime: t, representativeTime: t,
                                                     confidence: c.confidence, evidence: c.evidence, status: c.status)
                    evidence.contactEarliestTime = ContactEstimator.round3(interval.lowerBound)
                    evidence.contactLatestTime = ContactEstimator.round3(interval.upperBound)
                    notes.append(e.note)
                }
            }
        }
        var rebuilt = KickPhaseDetectionResult(kickType: phases.kickType, support: phases.support, phases: phaseList,
                                               overallConfidence: phases.overallConfidence, dataCoverage: phases.dataCoverage, notes: notes)
        rebuilt.evidence = evidence
        rebuilt.kickWindows = phases.kickWindows
        rebuilt.assistance = phases.assistance
        return rebuilt
    }
}
