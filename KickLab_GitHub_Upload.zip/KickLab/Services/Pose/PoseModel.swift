import Foundation

// MARK: - Coordinate system
//
// KickLab pose coordinates ("app-normalized"):
// - Measured in the video as it is DISPLAYED upright (the track's rotation applied).
// - Origin at the TOP-LEFT; x grows right, y grows DOWN.
// - Both axes are 0...1 across the displayed frame, so values are resolution independent.
// - Because x and y are normalized separately, distances must be measured after scaling
//   x by the frame's aspect ratio (width / height). `PoseSignalExtractor` does this.
//
// Vision reports points with the origin at the BOTTOM-left; `PoseCoordinates` converts.

/// A body landmark. Matches the 19 joints of Apple's 2D human-body pose detection.
/// Left and right are the PERSON's anatomical sides, not the viewer's.
enum PoseJoint: String, CaseIterable, Codable, Sendable, CodingKeyRepresentable {
    case nose, leftEye, rightEye, leftEar, rightEar
    case neck, leftShoulder, rightShoulder
    case leftElbow, rightElbow, leftWrist, rightWrist
    case root, leftHip, rightHip
    case leftKnee, rightKnee, leftAnkle, rightAnkle

    var side: BodySide? {
        switch self {
        case .leftEye, .leftEar, .leftShoulder, .leftElbow, .leftWrist, .leftHip, .leftKnee, .leftAnkle: .left
        case .rightEye, .rightEar, .rightShoulder, .rightElbow, .rightWrist, .rightHip, .rightKnee, .rightAnkle: .right
        case .nose, .neck, .root: nil
        }
    }

    /// The same joint on the other side of the body (center joints map to themselves).
    var opposite: PoseJoint {
        switch self {
        case .leftEye: .rightEye
        case .rightEye: .leftEye
        case .leftEar: .rightEar
        case .rightEar: .leftEar
        case .leftShoulder: .rightShoulder
        case .rightShoulder: .leftShoulder
        case .leftElbow: .rightElbow
        case .rightElbow: .leftElbow
        case .leftWrist: .rightWrist
        case .rightWrist: .leftWrist
        case .leftHip: .rightHip
        case .rightHip: .leftHip
        case .leftKnee: .rightKnee
        case .rightKnee: .leftKnee
        case .leftAnkle: .rightAnkle
        case .rightAnkle: .leftAnkle
        case .nose, .neck, .root: self
        }
    }
}

enum BodySide: String, Codable, Sendable {
    case left, right

    var opposite: BodySide { self == .left ? .right : .left }
}

/// Where a pose point's value came from.
enum PosePointStatus: String, Codable, Sendable {
    /// Reported by pose detection with sufficient confidence.
    case measured
    /// Filled by short-gap interpolation between measured points.
    case interpolated
    /// Not detected, below the confidence threshold, or in a gap too long to fill.
    case unavailable
}

/// One landmark position in app-normalized coordinates (see the top of this file).
struct PosePoint: Codable, Equatable, Sendable {
    var x: Double
    var y: Double
    /// 0...1 as reported by pose detection (interpolated points keep the lower bounding confidence).
    var confidence: Double
    var status: PosePointStatus

    init(x: Double, y: Double, confidence: Double, status: PosePointStatus = .measured) {
        self.x = x
        self.y = y
        self.confidence = confidence
        self.status = status
    }

    static let unavailable = PosePoint(x: 0, y: 0, confidence: 0, status: .unavailable)

    var isAvailable: Bool { status != .unavailable }

    /// True when both coordinates are inside the frame (0...1).
    var isWithinFrame: Bool { (0...1).contains(x) && (0...1).contains(y) }
}

/// A 2D position in app-normalized coordinates.
struct NormalizedPoint: Codable, Equatable, Sendable {
    var x: Double
    var y: Double

    init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
}

/// An axis-aligned box in app-normalized coordinates.
struct NormalizedRect: Codable, Equatable, Sendable {
    var minX: Double
    var minY: Double
    var maxX: Double
    var maxY: Double

    var width: Double { maxX - minX }
    var height: Double { maxY - minY }
    var center: NormalizedPoint { NormalizedPoint(x: (minX + maxX) / 2, y: (minY + maxY) / 2) }

    func contains(_ point: NormalizedPoint) -> Bool {
        (minX...maxX).contains(point.x) && (minY...maxY).contains(point.y)
    }

    /// The box around the given points, or nil when there are none.
    static func bounding(_ points: [NormalizedPoint]) -> NormalizedRect? {
        guard let first = points.first else { return nil }
        return points.dropFirst().reduce(NormalizedRect(minX: first.x, minY: first.y, maxX: first.x, maxY: first.y)) {
            NormalizedRect(minX: min($0.minX, $1.x), minY: min($0.minY, $1.y), maxX: max($0.maxX, $1.x), maxY: max($0.maxY, $1.y))
        }
    }
}

/// One person detected in one frame. Pose detection identifies body pose only:
/// KickLab does no face, identity or biometric recognition.
struct BodyPose: Codable, Equatable, Sendable {
    var joints: [PoseJoint: PosePoint]
    /// Mean confidence of the available joints.
    var confidence: Double
    /// Assigned by `PoseTracker`; nil until tracked or when too weak to track.
    var trackID: Int?

    init(joints: [PoseJoint: PosePoint], confidence: Double? = nil, trackID: Int? = nil) {
        self.joints = joints
        let available = joints.values.filter(\.isAvailable)
        self.confidence = confidence ?? (available.isEmpty ? 0 : available.map(\.confidence).reduce(0, +) / Double(available.count))
        self.trackID = trackID
    }

    /// The joint's point if it is available.
    func point(_ joint: PoseJoint) -> PosePoint? {
        guard let point = joints[joint], point.isAvailable else { return nil }
        return point
    }

    var availablePoints: [NormalizedPoint] {
        joints.values.filter(\.isAvailable).map { NormalizedPoint(x: $0.x, y: $0.y) }
    }

    var boundingBox: NormalizedRect? { NormalizedRect.bounding(availablePoints) }

    /// Mid-hip when available, else root, else the bounding-box center.
    var center: NormalizedPoint? {
        if let left = point(.leftHip), let right = point(.rightHip) {
            return NormalizedPoint(x: (left.x + right.x) / 2, y: (left.y + right.y) / 2)
        }
        if let root = point(.root) { return NormalizedPoint(x: root.x, y: root.y) }
        return boundingBox?.center
    }
}

/// Whether a sampled frame produced pose data.
enum PoseFrameStatus: String, Codable, Sendable {
    /// Pose detection ran; `bodies` may still be empty (no one visible).
    case analyzed
    /// Pose detection failed on this frame (the frame is "dropped").
    case failed
}

/// Pose detection output for one sampled frame.
struct PoseFrame: Codable, Equatable, Sendable {
    /// Index among the frames sampled for analysis (0, 1, 2…).
    var frameIndex: Int
    /// True presentation time in seconds from the start of the video.
    var timestamp: Double
    var bodies: [BodyPose]
    var status: PoseFrameStatus

    init(frameIndex: Int, timestamp: Double, bodies: [BodyPose], status: PoseFrameStatus = .analyzed) {
        self.frameIndex = frameIndex
        self.timestamp = timestamp
        self.bodies = bodies
        self.status = status
    }

    func body(trackID: Int) -> BodyPose? {
        bodies.first { $0.trackID == trackID }
    }
}

/// Every detected person across the analyzed frames of one video.
struct PoseSequence: Codable, Equatable, Sendable {
    var videoID: UUID
    var durationSeconds: Double?
    /// The source's nominal frame rate (e.g. 240 for slow motion).
    var nominalFrameRate: Double?
    /// The sampling rate actually used for analysis (nil = every frame).
    var analysisFrameRate: Double?
    /// How the stored video had to be rotated to display upright.
    var orientation: VideoOrientation
    var isMirrored: Bool
    /// Displayed width / height. Needed to measure distances in normalized coordinates.
    var displayAspectRatio: Double?
    var frames: [PoseFrame]
    /// The tracked person chosen as the kicker, if any.
    var kickerTrackID: Int?

    /// Frames on which pose detection failed.
    var droppedFrameIndices: [Int] { frames.filter { $0.status == .failed }.map(\.frameIndex) }

    /// Frames that were analyzed but contained no person.
    var framesWithoutBodies: [Int] {
        frames.filter { $0.status == .analyzed && $0.bodies.isEmpty }.map(\.frameIndex)
    }

    var confidenceStatistics: PoseConfidenceStatistics {
        PoseConfidenceStatistics(sequence: self)
    }
}

/// Summary of detection quality for a sequence.
struct PoseConfidenceStatistics: Codable, Equatable, Sendable {
    let frameCount: Int
    let droppedFrameCount: Int
    let framesWithBodies: Int
    /// Frames where the kicker track was present (0 when no kicker was selected).
    let framesWithKicker: Int
    /// Mean body confidence over every detected body.
    let meanBodyConfidence: Double?
    /// Mean confidence of the kicker's bodies.
    let meanKickerConfidence: Double?

    init(sequence: PoseSequence) {
        frameCount = sequence.frames.count
        droppedFrameCount = sequence.droppedFrameIndices.count
        framesWithBodies = sequence.frames.filter { !$0.bodies.isEmpty }.count
        let allBodies = sequence.frames.flatMap(\.bodies)
        meanBodyConfidence = allBodies.isEmpty ? nil : allBodies.map(\.confidence).reduce(0, +) / Double(allBodies.count)
        let kickerBodies = sequence.kickerTrackID.map { id in sequence.frames.compactMap { $0.body(trackID: id) } } ?? []
        framesWithKicker = kickerBodies.count
        meanKickerConfidence = kickerBodies.isEmpty ? nil : kickerBodies.map(\.confidence).reduce(0, +) / Double(kickerBodies.count)
    }
}

/// One sample of the kicker's pose. Every sampled frame has a sample; frames where the
/// kicker was not seen hold only unavailable joints, so time gaps stay visible.
struct KickerPoseSample: Codable, Equatable, Sendable {
    var frameIndex: Int
    var timestamp: Double
    var joints: [PoseJoint: PosePoint]

    func point(_ joint: PoseJoint) -> PosePoint? {
        guard let point = joints[joint], point.isAvailable else { return nil }
        return point
    }
}

/// The selected kicker's pose over time, ready for processing and signal extraction.
struct KickerPoseTimeline: Codable, Equatable, Sendable {
    var samples: [KickerPoseSample]
    var displayAspectRatio: Double?

    init(samples: [KickerPoseSample], displayAspectRatio: Double? = nil) {
        self.samples = samples
        self.displayAspectRatio = displayAspectRatio
    }

    /// Builds the kicker's timeline from tracked frames.
    static func make(from frames: [PoseFrame], trackID: Int, displayAspectRatio: Double?) -> KickerPoseTimeline {
        let samples = frames.map { frame in
            KickerPoseSample(
                frameIndex: frame.frameIndex,
                timestamp: frame.timestamp,
                joints: frame.body(trackID: trackID)?.joints ?? [:]
            )
        }
        return KickerPoseTimeline(samples: samples, displayAspectRatio: displayAspectRatio)
    }
}
