import Foundation

/// Errors thrown by `KickService`. Inspect cases directly in code and tests.
enum KickServiceError: Error, Equatable, Sendable, LocalizedError {
    /// The draft failed `KickValidator`. Nothing was written.
    case invalidDraft([KickValidationIssue])
    /// New kicks cannot be recorded for an archived athlete.
    case athleteArchived(athleteID: UUID)
    /// The session belongs to a different athlete (or to none).
    case sessionBelongsToDifferentAthlete(sessionID: UUID, sessionAthleteID: UUID?, athleteID: UUID?)
    /// The kick has no athlete, so it cannot be placed in a session.
    case kickHasNoAthlete(kickID: UUID)
    /// The kick's current session is owned by another athlete; clear or move the
    /// session assignment before reassigning the athlete.
    case reassignmentConflictsWithSession(kickID: UUID, sessionID: UUID, newAthleteID: UUID)
    /// A model passed to the service is not managed by the service's ModelContext.
    case notInServiceContext
    /// `ModelContext.save()` failed. The context was rolled back; nothing was persisted.
    case persistenceFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidDraft(let issues):
            issues.map(\.description).joined(separator: "\n")
        case .athleteArchived:
            "Kicks can't be added for an archived athlete."
        case .sessionBelongsToDifferentAthlete:
            "That session belongs to a different athlete."
        case .kickHasNoAthlete:
            "This kick has no athlete, so it can't be added to a session."
        case .reassignmentConflictsWithSession:
            "This kick is in another athlete's session. Remove it from the session first."
        case .notInServiceContext:
            "The record isn't available in this data context."
        case .persistenceFailed:
            "KickLab couldn't save the change."
        }
    }
}
