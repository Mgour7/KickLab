import Foundation

/// Pure rules for the values KickService fills in when a draft leaves them open.
enum KickCreationDefaults {
    /// 1. An explicit draft context wins.
    /// 2. Otherwise the session type's default context.
    /// 3. Otherwise `.training`.
    static func resolvedContext(explicit: KickContext?, sessionType: KickingSessionType?) -> KickContext {
        explicit ?? sessionType?.defaultKickContext ?? .training
    }

    /// An explicit draft level wins; otherwise the athlete's current level is snapshotted.
    static func resolvedPlayingLevel(explicit: PlayingLevel?, athleteCurrentLevel: PlayingLevel) -> PlayingLevel {
        explicit ?? athleteCurrentLevel
    }

    /// A copy of `draft` with context and playing level resolved for creation.
    static func resolvedDraft(
        _ draft: KickDraft,
        sessionType: KickingSessionType?,
        athleteCurrentLevel: PlayingLevel
    ) -> KickDraft {
        var resolved = draft
        resolved.context = resolvedContext(explicit: draft.context, sessionType: sessionType)
        resolved.playingLevelAtKick = resolvedPlayingLevel(
            explicit: draft.playingLevelAtKick,
            athleteCurrentLevel: athleteCurrentLevel
        )
        return resolved
    }
}
