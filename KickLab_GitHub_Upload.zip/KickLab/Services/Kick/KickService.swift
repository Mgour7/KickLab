import Foundation
import SwiftData

/// The authoritative path for creating, updating, assigning, moving and deleting kicks.
///
/// Invariants enforced here:
/// - K1  A kick is created for an athlete; a session, if given, must belong to that athlete.
/// - K2  `athleteID` is only ever written together with `athlete` (via `Kick.assignAthlete`).
/// - K3  `playingLevelAtKick` is snapshotted from the athlete unless the draft supplies one.
/// - K4  Context: draft value, else the session type's default, else `.training`.
/// - K5/K6  Every write is validated by `KickValidator`; invalid input throws, never "fixed".
/// - K7  Type changes rewrite every outcome column (values, sources, confidences).
/// - K9  Deletion: capture media paths → delete → save → only then clean up media.
///
/// Save policy: see `ModelCommit`. Every mutating method saves before returning.
struct KickService {
    let context: ModelContext
    let mediaCleanup: any MediaCleanupHandling
    let saveHandler: ModelSaveHandler

    init(
        context: ModelContext,
        mediaCleanup: any MediaCleanupHandling = NoOpMediaCleanup(),
        saveHandler: @escaping ModelSaveHandler = ModelCommit.defaultSave
    ) {
        self.context = context
        self.mediaCleanup = mediaCleanup
        self.saveHandler = saveHandler
    }

    // MARK: Create

    /// Creates, validates, inserts and saves a kick.
    @discardableResult
    func createKick(for athlete: Athlete, in session: KickingSession? = nil, draft: KickDraft) throws -> Kick {
        try requireManaged(athlete)
        if let session { try requireManaged(session) }
        guard !athlete.isArchived else {
            throw KickServiceError.athleteArchived(athleteID: athlete.id)
        }
        if let session, session.athlete?.id != athlete.id {
            throw KickServiceError.sessionBelongsToDifferentAthlete(
                sessionID: session.id,
                sessionAthleteID: session.athlete?.id,
                athleteID: athlete.id
            )
        }

        let resolved = KickCreationDefaults.resolvedDraft(
            draft,
            sessionType: session?.sessionType,
            athleteCurrentLevel: athlete.currentPlayingLevel
        )
        let kick: Kick
        do {
            kick = try Kick.make(from: resolved)
        } catch let error as KickValidationError {
            throw KickServiceError.invalidDraft(error.issues)
        }

        context.insert(kick)
        kick.assignAthlete(athlete)
        kick.session = session
        try commit()
        return kick
    }

    // MARK: Update

    /// Applies a draft to an existing kick. Athlete and session are preserved; use
    /// `assign(_:to:)` or `reassignAthlete(of:to:)` to change them. A nil draft
    /// context or playing level keeps the stored value.
    func updateKick(_ kick: Kick, with draft: KickDraft) throws {
        try requireManaged(kick)
        do {
            try kick.update(from: draft)
        } catch let error as KickValidationError {
            throw KickServiceError.invalidDraft(error.issues)
        }
        try commit()
    }

    // MARK: Session assignment

    /// Moves a kick into a session, or out of any session when `session` is nil.
    /// The session must belong to the kick's athlete. The kick's athlete is never
    /// changed to make an assignment work.
    func assign(_ kick: Kick, to session: KickingSession?) throws {
        try requireManaged(kick)
        if let session {
            try requireManaged(session)
            guard let kickAthleteID = kick.athlete?.id else {
                throw KickServiceError.kickHasNoAthlete(kickID: kick.id)
            }
            guard session.athlete?.id == kickAthleteID else {
                throw KickServiceError.sessionBelongsToDifferentAthlete(
                    sessionID: session.id,
                    sessionAthleteID: session.athlete?.id,
                    athleteID: kickAthleteID
                )
            }
        }
        kick.session = session
        kick.updatedAt = .now
        try commit()
    }

    // MARK: Athlete reassignment

    /// Changes a kick's athlete, keeping `athlete` and `athleteID` together.
    /// Rejected when the kick sits in a session owned by a different athlete;
    /// clear or move the session assignment first.
    func reassignAthlete(of kick: Kick, to athlete: Athlete) throws {
        try requireManaged(kick)
        try requireManaged(athlete)
        if let session = kick.session, session.athlete?.id != athlete.id {
            throw KickServiceError.reassignmentConflictsWithSession(
                kickID: kick.id,
                sessionID: session.id,
                newAthleteID: athlete.id
            )
        }
        kick.assignAthlete(athlete)
        try commit()
    }

    // MARK: Delete

    /// Deletes a kick. Its videos and analyses (and their results) cascade.
    /// Media files are removed only after the deletion is saved.
    func deleteKick(_ kick: Kick) throws {
        try requireManaged(kick)
        let cleanup = stageDeletion(of: kick)
        try commit()
        if !cleanup.isEmpty {
            mediaCleanup.cleanUp(cleanup)
        }
    }

    /// Marks a kick for deletion without saving and returns the media to clean up
    /// once the caller's save succeeds. Shared with `AthleteService` so permanent
    /// athlete deletion uses identical semantics.
    func stageDeletion(of kick: Kick) -> MediaCleanupRequest {
        let request = Self.mediaReferences(for: kick)
        context.delete(kick)
        return request
    }

    /// Every app-managed file owned by a kick: video files and thumbnails (media
    /// area) and analysis artifacts (analysis area). Photos-library assets are never included.
    static func mediaReferences(for kick: Kick) -> MediaCleanupRequest {
        var mediaPaths: [String] = []
        for video in kick.videos ?? [] {
            if let path = video.relativeFilePath { mediaPaths.append(path) }
            if let path = video.thumbnailRelativePath { mediaPaths.append(path) }
        }
        let analysisPaths = (kick.analyses ?? []).compactMap(\.artifactsRelativePath)
        return MediaCleanupRequest(mediaRelativePaths: mediaPaths, analysisRelativePaths: analysisPaths)
    }

    // MARK: Audit

    /// Read-only integrity audit: outcome validation, athlete/athleteID agreement,
    /// and session/athlete agreement. Empty means the kick is consistent. Never saves.
    func audit(_ kick: Kick) -> [KickIntegrityIssue] {
        let links = KickLinkSnapshot(
            kickID: kick.id,
            linkedAthleteID: kick.athlete?.id,
            storedAthleteID: kick.athleteID,
            sessionID: kick.session?.id,
            sessionAthleteID: kick.session?.athlete?.id
        )
        return KickIntegrityAuditor.audit(links: links, outcomeIssues: kick.validationIssues)
    }

    // MARK: Helpers

    private func requireManaged(_ model: any PersistentModel) throws {
        guard context.manages(model) else { throw KickServiceError.notInServiceContext }
    }

    private func commit() throws {
        do {
            try ModelCommit.commit(context, using: saveHandler)
        } catch let failure as CommitFailure {
            throw KickServiceError.persistenceFailed(failure.underlyingDescription)
        }
    }
}
