import Foundation

/// The relationship facts about one kick that integrity auditing needs.
/// Built from a `Kick` by `KickService.audit(_:)`; a plain value so the rules are
/// testable without a database.
struct KickLinkSnapshot: Equatable, Sendable {
    var kickID: UUID
    /// `kick.athlete?.id`
    var linkedAthleteID: UUID?
    /// `kick.athleteID` (the denormalized copy)
    var storedAthleteID: UUID?
    /// `kick.session?.id`
    var sessionID: UUID?
    /// `kick.session?.athlete?.id`
    var sessionAthleteID: UUID?
}

/// A problem found when auditing a stored kick.
enum KickIntegrityIssue: Equatable, Sendable, CustomStringConvertible {
    /// The kick has no athlete relationship. `storedAthleteID` may still identify
    /// the former owner (for example after a direct athlete-row deletion).
    case missingAthlete(storedAthleteID: UUID?)
    /// `athleteID` does not equal `athlete.id`.
    case athleteIDMismatch(storedAthleteID: UUID?, linkedAthleteID: UUID)
    /// The kick's session has no athlete.
    case sessionWithoutAthlete(sessionID: UUID)
    /// The kick's session belongs to a different athlete than the kick.
    case sessionAthleteMismatch(sessionID: UUID, sessionAthleteID: UUID, kickAthleteID: UUID?)
    /// The stored outcome columns fail `KickValidator`.
    case outcome(KickValidationIssue)

    var description: String {
        switch self {
        case .missingAthlete:
            "The kick has no athlete."
        case .athleteIDMismatch:
            "The kick's stored athlete ID does not match its athlete."
        case .sessionWithoutAthlete:
            "The kick's session has no athlete."
        case .sessionAthleteMismatch:
            "The kick's session belongs to a different athlete."
        case .outcome(let issue):
            issue.description
        }
    }
}

/// Pure integrity rules for a stored kick.
enum KickIntegrityAuditor {
    static func audit(links: KickLinkSnapshot, outcomeIssues: [KickValidationIssue]) -> [KickIntegrityIssue] {
        var issues: [KickIntegrityIssue] = []

        if let linked = links.linkedAthleteID {
            if links.storedAthleteID != linked {
                issues.append(.athleteIDMismatch(storedAthleteID: links.storedAthleteID, linkedAthleteID: linked))
            }
        } else {
            issues.append(.missingAthlete(storedAthleteID: links.storedAthleteID))
        }

        if let sessionID = links.sessionID {
            if let sessionAthleteID = links.sessionAthleteID {
                if sessionAthleteID != links.linkedAthleteID {
                    issues.append(.sessionAthleteMismatch(
                        sessionID: sessionID,
                        sessionAthleteID: sessionAthleteID,
                        kickAthleteID: links.linkedAthleteID
                    ))
                }
            } else {
                issues.append(.sessionWithoutAthlete(sessionID: sessionID))
            }
        }

        issues += outcomeIssues.map(KickIntegrityIssue.outcome)
        return issues
    }
}
