import Foundation

// Build 21 — EXPERIMENTAL ball-flight observation (never scored, never used by any
// technique score). It follows the kicked football in IMAGE space after contact, from
// YOLOX-S detections, and says how far it could follow it and why it stopped.
//
// What it never reports from one uncalibrated video: height in feet, distance, launch
// angle, or total hang time unless a landing/catch was actually seen (it never is in this
// build: no landing detector exists). See Docs/BALL_FLIGHT_LIMITATIONS.md.

struct BallFlightPoint: Codable, Equatable, Sendable {
    var time: Double
    var cx: Double
    var cy: Double
    var width: Double
    /// Detected on this frame (true) or filled in across a short gap (false).
    var measured: Bool
    var score: Double?
}

enum BallFlightEnd: String, Codable, Sendable {
    /// The box got smaller than the detector can follow.
    case tooSmall
    /// It reached the edge of the picture.
    case leftFrame
    /// No consistent detection for longer than the allowed gap.
    case lost
    /// The analyzed window (or the clip) ended while it was still visible.
    case windowEnded
    /// Nothing consistent was seen after contact.
    case notTracked

    var text: String {
        switch self {
        case .tooSmall: "The ball became too small to follow."
        case .leftFrame: "The ball left the picture."
        case .lost: "The ball was lost (no consistent detection)."
        case .windowEnded: "The video ended while the ball was still visible."
        case .notTracked: "The kicked ball wasn't followed after contact."
        }
    }
}

struct BallFlightObservation: Codable, Equatable, Sendable {
    var contactTime: Double
    var points: [BallFlightPoint]
    var end: BallFlightEnd
    var rejectedDetections: Int

    var measuredCount: Int { points.filter(\.measured).count }
    var inferredCount: Int { points.filter { !$0.measured }.count }
    /// Seconds from contact to the last MEASURED point.
    var observedSeconds: Double? { points.last(where: \.measured).map { $0.time - contactTime } }

    /// Never a hang time: a partial observation, said as such.
    var summary: String {
        guard let s = observedSeconds, measuredCount >= 2 else { return "Ball flight not observed. \(end.text)" }
        return String(format: "Ball followed for %.2f s after contact (%d detections, %d filled-in frames) — a partial flight observation, not hang time. ", s, measuredCount, inferredCount) + end.text
    }
}

enum BallFlightObserver {
    /// Detections below this score are ignored.
    static let minimumScore = 0.25
    /// A gap up to this long may be filled in (marked inferred); longer ends the track.
    static let maximumGapSeconds = 0.1
    /// Smallest followable box (fraction of the frame width).
    static let minimumWidth = 0.006
    /// The kicked ball must start near its resting spot (in ball widths) right after contact.
    static let startRadiusInWidths = 4.0
    /// Frame-to-frame size change beyond this ratio is a different object.
    static let maximumSizeRatio = 1.8
    /// Gating: predicted position ± this many ball widths (+ speed term).
    static let gateInWidths = 3.0
    static let edgeMargin = 0.02

    /// - Parameters:
    ///   - detections: per frame (time, boxes) after contact, in time order.
    ///   - rest: the kicked ball's resting box.
    ///   - windowEnd: last time examined.
    static func observe(contactTime: Double, rest: NormalizedBox, detections: [(time: Double, boxes: [FootballDetection])],
                        windowEnd: Double) -> BallFlightObservation {
        var points: [BallFlightPoint] = []
        var rejected = 0
        var end: BallFlightEnd = .windowEnded
        let frames = detections.filter { $0.time > contactTime }.sorted { $0.time < $1.time }
        var lastMeasured: BallFlightPoint?
        var velocity: (x: Double, y: Double)?

        for f in frames {
            let boxes = f.boxes.filter { $0.score >= minimumScore }
            let reference = lastMeasured ?? BallFlightPoint(time: contactTime, cx: rest.cx, cy: rest.cy, width: rest.w, measured: true)
            let dt = f.time - reference.time
            if lastMeasured != nil, dt > maximumGapSeconds + 1e-9 {
                end = .lost
                break
            }
            let predicted = (x: reference.cx + (velocity?.x ?? 0) * dt, y: reference.cy + (velocity?.y ?? 0) * dt)
            let gate = (lastMeasured == nil ? startRadiusInWidths : gateInWidths) * reference.width
                + hypot(velocity?.x ?? 0, velocity?.y ?? 0) * dt * 0.5
            let candidates = boxes.filter { b in
                let d = hypot(b.box.cx - predicted.x, b.box.cy - predicted.y)
                let ratio = max(b.box.w, reference.width) / max(min(b.box.w, reference.width), 1e-6)
                return d <= gate && ratio <= maximumSizeRatio
            }
            rejected += boxes.count - candidates.count
            // A box sitting on the resting spot is a ball at rest (the next ball on the tee),
            // never the kicked one in flight.
            let moving = candidates.filter { hypot($0.box.cx - rest.cx, $0.box.cy - rest.cy) > 0.5 * rest.w }
            rejected += candidates.count - moving.count
            guard let best = moving.min(by: { hypot($0.box.cx - predicted.x, $0.box.cy - predicted.y) < hypot($1.box.cx - predicted.x, $1.box.cy - predicted.y) }) else {
                continue
            }
            let p = BallFlightPoint(time: f.time, cx: best.box.cx, cy: best.box.cy, width: best.box.w, measured: true, score: best.score)
            // Fill a short gap (one or two missing frames) by straight-line interpolation, marked inferred.
            if let last = lastMeasured {
                let missing = frames.filter { $0.time > last.time + 1e-9 && $0.time < p.time - 1e-9 }
                for g in missing {
                    let u = (g.time - last.time) / (p.time - last.time)
                    points.append(BallFlightPoint(time: g.time, cx: last.cx + u * (p.cx - last.cx), cy: last.cy + u * (p.cy - last.cy),
                                                  width: last.width + u * (p.width - last.width), measured: false, score: nil))
                }
                velocity = ((p.cx - last.cx) / (p.time - last.time), (p.cy - last.cy) / (p.time - last.time))
            }
            points.append(p)
            lastMeasured = p
            if p.width < minimumWidth { end = .tooSmall; break }
            if p.cx < edgeMargin || p.cx > 1 - edgeMargin || p.cy < edgeMargin || p.cy > 1 - edgeMargin { end = .leftFrame; break }
        }
        if lastMeasured == nil { end = .notTracked }
        else if end == .windowEnded, let last = lastMeasured, (frames.last?.time ?? windowEnd) - last.time > maximumGapSeconds + 1e-9 { end = .lost }
        // Trailing filled-in points are never kept (only gaps BETWEEN detections are filled).
        while let last = points.last, !last.measured { points.removeLast() }
        // A "track" of a single detection is not a flight.
        if points.filter(\.measured).count < 2 { return BallFlightObservation(contactTime: contactTime, points: points, end: .notTracked, rejectedDetections: rejected) }
        return BallFlightObservation(contactTime: contactTime, points: points, end: end, rejectedDetections: rejected)
    }
}
