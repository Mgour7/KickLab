import Foundation

// Step 12G (Computer Vision Intelligence Rebuild) — Layer C: multi-frame football
// tracking, and the ball-motion events it supports.
//
// Two stages, both on REAL detections from the video's frames:
// 1. Broad scan: the whole clip, sampled (about 5 frames a second), full frame. Detections
//    that stay in one place form RESTING SITES. The kicked ball is the site that is there
//    before the strike, is gone afterwards, and that the kicking foot reaches. Sites that
//    are still there after the kick (spare footballs) are rejected, with the reason kept.
// 2. Precision pass: every frame around the strike, a crop around the chosen ball. Each
//    frame is classified (at rest / obscured / moving / other football / not seen) from
//    the detections and, when available, the ball's appearance match (`BallMotionTracker`).
//
// Movement is only reported when the ball stops being seen at rest AND never returns AND
// is seen moving away (or its resting spot stays empty). A box that jumps for one frame is
// not movement. The first persistent movement CONSTRAINS contact (contact happened before
// it and after the last clear resting frame); it is not the contact time.

/// How the football was found for an analysis.
enum FootballAnalysisMethod: String, Codable, Sendable {
    /// The bundled detector found and selected the kicked ball by itself.
    case automaticFootballDetection
    /// The user located the ball; the app measured its movement from the frames.
    case userInitializedBallTracking
    /// No football evidence was available (no detector, or the ball wasn't found).
    case ballUnavailable
}

/// Where a per-frame ball position came from. Only `detected` and `tracked` are
/// observations; nothing is ever interpolated or extrapolated in this version.
enum FootballObservationSource: String, Codable, Sendable {
    /// A detector box on this frame.
    case detected
    /// No usable box, but the resting ball's appearance matched on this frame.
    case tracked
    case interpolated
    case unavailable
}

/// The ball's state on one examined frame.
enum FootballFrameState: String, Codable, Sendable {
    /// Seen at its resting spot, clearly.
    case atRest
    /// Seen at its resting spot, but partly covered or changed (foot over it, motion).
    case obscured
    /// Seen away from its resting spot, moving away.
    case moving
    /// A detection matched another resting football (a spare ball), not the kicked one.
    case otherFootball
    /// Not seen at all on this frame.
    case notSeen
}

/// One raw detection of the football class, in app-normalized displayed coordinates.
struct FootballDetection: Codable, Equatable, Sendable {
    enum Pass: String, Codable, Sendable { case broadScan, precision }
    var time: Double
    var box: NormalizedBox
    var score: Double
    var pass: Pass
}

/// A place where a football rested during the broad scan.
struct FootballRestSite: Codable, Equatable, Sendable {
    var center: NormalizedPoint
    /// Ball size in displayed-height units.
    var size: Double
    var firstSeen: Double
    var lastSeen: Double
    var detections: Int
    var meanScore: Double
    /// Share of broad-scan frames after the strike in which this site was still detected.
    var afterStrikeShare: Double?
    /// Closest the kicking ankle came to the site around its last sighting, in ball sizes.
    var closestAnkleSizes: Double?
    var selected: Bool
    var reason: String
}

/// The ball on one precision-pass frame.
struct FootballFrameObservation: Codable, Equatable, Sendable {
    var time: Double
    var state: FootballFrameState
    var source: FootballObservationSource
    /// The detection used for this frame (nil when not seen).
    var box: NormalizedBox?
    var score: Double?
    /// Appearance match with the resting ball (0…1), when measured.
    var appearance: Double?
}

/// Global camera movement measured from the background around the strike.
struct CameraMotionSummary: Codable, Equatable, Sendable {
    /// Largest apparent background shift from the first examined frame, in ball sizes.
    var maximumShiftBallSizes: Double
    var framesMeasured: Int
    var cameraMoved: Bool
    var note: String
}

/// Everything the football layer found for one analysis (stored in the phase artifact).
struct FootballTrack: Codable, Equatable, Sendable {
    var method: FootballAnalysisMethod
    var detector: FootballDetectorInfo?
    var sites: [FootballRestSite] = []
    /// The kicked ball's resting box (nil when not selected).
    var rest: NormalizedBox?
    var restSize: Double?
    var broadScanFrames: Int = 0
    var precisionFrames: Int = 0
    var observations: [FootballFrameObservation] = []
    /// Last frame where the kicked ball was clearly at rest.
    var lastStationaryTime: Double?
    /// First frame of the ball's persistent movement away from its spot.
    var firstPersistentMovementTime: Double?
    /// "displacedDetections" (seen moving away) or "restVanished" (its spot stayed empty).
    var movementBasis: String?
    var cameraMotion: CameraMotionSummary?
    /// Measured on the device that ran the analysis (nil when not measured).
    var runtimeSeconds: Double?
    var note: String

    static func unavailable(_ note: String, detector: FootballDetectorInfo? = nil) -> FootballTrack {
        FootballTrack(method: .ballUnavailable, detector: detector, note: note)
    }

    /// The contact interval the ball supports: after `lastStationaryTime`, no later than
    /// `firstPersistentMovementTime`.
    var contactBounds: (afterTime: Double, byTime: Double)? {
        guard method != .ballUnavailable, let a = lastStationaryTime, let b = firstPersistentMovementTime, a < b else { return nil }
        return (a, b)
    }
}

/// What the automatic football layer tells the phase detector (automatic evidence, never
/// user assistance).
struct AutomaticBallContact: Codable, Equatable, Sendable {
    var lastStationaryTime: Double
    var firstMovementTime: Double
    var basis: String
    var detectorName: String
    var framesExamined: Int
    var framesWithBall: Int

    init(lastStationaryTime: Double, firstMovementTime: Double, basis: String, detectorName: String,
         framesExamined: Int = 0, framesWithBall: Int = 0) {
        self.lastStationaryTime = lastStationaryTime
        self.firstMovementTime = firstMovementTime
        self.basis = basis
        self.detectorName = detectorName
        self.framesExamined = framesExamined
        self.framesWithBall = framesWithBall
    }

    init?(_ track: FootballTrack) {
        guard track.method == .automaticFootballDetection, let b = track.contactBounds else { return nil }
        self.init(lastStationaryTime: b.afterTime, firstMovementTime: b.byTime, basis: track.movementBasis ?? "",
                  detectorName: track.detector?.name ?? "football detector", framesExamined: track.precisionFrames,
                  framesWithBall: track.observations.filter { $0.source == .detected && $0.state != .otherFootball }.count)
    }
}

enum FootballTrackAnalyzer {
    // Broad scan
    static let siteMinimumScore = 0.25
    /// Detections within this many ball sizes of a site's center join it.
    static let siteJoinSizes = 0.75
    static let siteMinimumDetections = 3
    /// A site still detected in more than this share of post-strike frames didn't leave.
    static let vanishedMaximumShare = 0.2
    /// A detection within this many ball sizes of a site counts as the ball still there
    /// (allows slow camera drift over several seconds).
    static let presenceSizes = 1.0
    /// The kicking ankle must come within this many ball sizes of the kicked ball (2D;
    /// the ankle keypoint sits above the foot, and depth views compress distances).
    static let ankleReachSizes = 3.0
    /// The kicked ball's last broad-scan sighting must be this close to the strike.
    static let strikeSlackSeconds = 0.6
    // Precision pass
    static let restMatchSizes = 0.5
    static let restMinimumScore = 0.3
    static let displacedMinimumScore = 0.4
    static let displacedMinimumSizes = 0.75
    static let displacedMaximumSizes = 12.0
    static let persistenceFrames = 3
    /// Appearance match (normalized cross-correlation) that counts as "clearly at rest".
    static let appearanceRest = BallMotionTracker.restThreshold

    struct AnkleSample: Equatable, Sendable {
        var time: Double
        var point: NormalizedPoint
    }

    static func distance(_ a: NormalizedPoint, _ b: NormalizedPoint, aspect: Double) -> Double {
        hypot((a.x - b.x) * aspect, a.y - b.y)
    }

    // MARK: Stage 1 — resting sites and the kicked ball

    /// Groups confident detections that stay in one place.
    static func sites(_ detections: [FootballDetection], aspect: Double) -> [FootballRestSite] {
        struct Group { var points: [NormalizedPoint]; var sizes: [Double]; var times: [Double]; var scores: [Double] }
        var groups: [Group] = []
        for d in detections.sorted(by: { $0.time < $1.time }) where d.score >= siteMinimumScore {
            let size = d.box.size(aspect: aspect)
            guard size > 0 else { continue }
            let center = d.box.center
            let match = groups.indices.min { a, b in
                distance(median(groups[a].points), center, aspect: aspect) < distance(median(groups[b].points), center, aspect: aspect)
            }
            if let m = match, distance(median(groups[m].points), center, aspect: aspect) <= siteJoinSizes * max(size, median(groups[m].sizes)) {
                groups[m].points.append(center); groups[m].sizes.append(size); groups[m].times.append(d.time); groups[m].scores.append(d.score)
            } else {
                groups.append(Group(points: [center], sizes: [size], times: [d.time], scores: [d.score]))
            }
        }
        return groups.filter { $0.times.count >= siteMinimumDetections }.map { g in
            FootballRestSite(center: median(g.points), size: median(g.sizes), firstSeen: g.times.min() ?? 0, lastSeen: g.times.max() ?? 0,
                             detections: g.times.count, meanScore: g.scores.reduce(0, +) / Double(g.scores.count),
                             afterStrikeShare: nil, closestAnkleSizes: nil, selected: false, reason: "")
        }.sorted { $0.firstSeen < $1.firstSeen }
    }

    /// Picks the kicked ball among the resting sites. `scanTimes` are all broad-scan frame
    /// times (with or without detections); `strike` is the pose strike window when known.
    static func selectKickedBall(sites input: [FootballRestSite], detections: [FootballDetection], scanTimes: [Double],
                                 ankle: [AnkleSample], strike: ClosedRange<Double>?, aspect: Double) -> (sites: [FootballRestSite], selected: Int?) {
        var sites = input
        var best: (index: Int, reach: Double)?
        for i in sites.indices {
            let site = sites[i]
            // Presence after the kick counts weak detections too: a ball still lying there
            // often scores low, and a kicked ball leaves nothing at its spot.
            func atSite(_ d: FootballDetection) -> Bool {
                d.score >= YOLOXDecoder.minimumScore && distance(d.box.center, site.center, aspect: aspect) <= presenceSizes * site.size
            }
            let leaveBy = (strike?.upperBound ?? site.lastSeen) + 0.5
            let after = scanTimes.filter { $0 > leaveBy }
            let seenAfter = Set(detections.filter { $0.time > leaveBy && atSite($0) }.map(\.time))
            let share = after.isEmpty ? nil : Double(seenAfter.count) / Double(after.count)
            sites[i].afterStrikeShare = share.map { ($0 * 100).rounded() / 100 }
            let nearby = ankle.filter { $0.time >= site.lastSeen - strikeSlackSeconds && $0.time <= site.lastSeen + 0.4 }
            let reach = nearby.map { distance($0.point, site.center, aspect: aspect) / site.size }.min()
            sites[i].closestAnkleSizes = reach.map { ($0 * 100).rounded() / 100 }
            if let share, share > vanishedMaximumShare {
                sites[i].reason = "still there after the kick (a spare or different football)"
                continue
            }
            if share == nil {
                sites[i].reason = "the clip ends too soon after the kick to see whether this ball left"
                continue
            }
            if let strike, site.lastSeen < strike.lowerBound - strikeSlackSeconds || site.firstSeen > strike.upperBound {
                sites[i].reason = "it wasn't at rest when the kick happened"
                continue
            }
            guard let r = reach else {
                sites[i].reason = "the kicking foot wasn't tracked near it"
                continue
            }
            guard r <= ankleReachSizes else {
                sites[i].reason = String(format: "the kicking foot never came near it (closest %.1f ball sizes)", r)
                continue
            }
            sites[i].reason = "candidate"
            if best == nil || r < best!.reach { best = (i, r) }
        }
        if let b = best {
            sites[b.index].selected = true
            sites[b.index].reason = "selected: at rest before the strike, gone after it, and the kicking foot reached it"
            for i in sites.indices where i != b.index && sites[i].reason == "candidate" {
                sites[i].reason = "another ball the foot also came near; the closer one was chosen"
            }
        }
        return (sites, best?.index)
    }

    /// The precision-pass time range around the kicked ball's departure.
    static func precisionWindow(site: FootballRestSite, strike: ClosedRange<Double>?, duration: Double) -> ClosedRange<Double> {
        let lo = min(strike.map { $0.lowerBound - 0.3 } ?? site.lastSeen - 0.6, site.lastSeen - 0.3)
        let hi = max(strike.map { $0.upperBound + 0.4 } ?? site.lastSeen + 0.6, site.lastSeen + 0.5)
        return max(0, lo)...min(duration, hi)
    }

    // MARK: Stage 2 — per-frame states and movement

    /// Classifies every precision frame. `appearance` maps frame time → match with the
    /// resting ball's look; `shift` maps time → camera shift (normalized displayed units)
    /// so the resting spot follows a moving camera.
    static func classify(frames: [(time: Double, detections: [FootballDetection])], site: FootballRestSite,
                         otherSites: [FootballRestSite], aspect: Double, appearance: [Double: Double] = [:],
                         shift: (Double) -> (dx: Double, dy: Double) = { _ in (0, 0) }) -> [FootballFrameObservation] {
        var obs = classifyFrames(frames, site: site, otherSites: otherSites, aspect: aspect, appearance: appearance, shift: shift)
        // A resting box whose score falls well below the ball's usual resting score is
        // partly covered (typically the foot arriving): obscured, not clearly at rest.
        var restScores: [Double] = []
        for i in obs.indices where obs[i].source == .detected && (obs[i].state == .atRest || obs[i].state == .obscured) {
            let s = obs[i].score ?? 0
            if obs[i].state == .atRest, restScores.count >= 3, s < obscuredScoreFraction * median(restScores) {
                obs[i].state = .obscured
            }
            if obs[i].state == .atRest { restScores.append(s) }
        }
        return obs
    }

    /// A resting detection below this fraction of the usual resting score is "obscured".
    static let obscuredScoreFraction = 0.6

    private static func classifyFrames(_ frames: [(time: Double, detections: [FootballDetection])], site: FootballRestSite,
                                       otherSites: [FootballRestSite], aspect: Double, appearance: [Double: Double],
                                       shift: (Double) -> (dx: Double, dy: Double)) -> [FootballFrameObservation] {
        frames.sorted { $0.time < $1.time }.map { f in
            let s = shift(f.time)
            let rest = NormalizedPoint(x: site.center.x + s.dx, y: site.center.y + s.dy)
            let look = appearance.first { abs($0.key - f.time) < 1e-4 }?.value
            func dist(_ d: FootballDetection) -> Double { distance(d.box.center, rest, aspect: aspect) / site.size }
            let restBox = f.detections.filter { $0.score >= restMinimumScore && dist($0) <= restMatchSizes }.max { $0.score < $1.score }
            if let r = restBox {
                let clear = look.map { $0 >= appearanceRest } ?? true
                return FootballFrameObservation(time: f.time, state: clear ? .atRest : .obscured, source: .detected,
                                                box: r.box, score: round3(r.score), appearance: look.map(round3))
            }
            let displaced = f.detections.filter { d in
                let size = d.box.size(aspect: aspect) / site.size
                return d.score >= displacedMinimumScore && dist(d) > displacedMinimumSizes && dist(d) <= displacedMaximumSizes
                    && size >= 0.4 && size <= 2.5
            }
            let atOther = displaced.filter { d in
                otherSites.contains { distance(d.box.center, $0.center, aspect: aspect) <= siteJoinSizes * $0.size }
            }
            if let m = displaced.filter({ d in !atOther.contains(d) }).max(by: { $0.score < $1.score }) {
                return FootballFrameObservation(time: f.time, state: .moving, source: .detected, box: m.box, score: round3(m.score),
                                                appearance: look.map(round3))
            }
            if let look, look >= appearanceRest {
                // No box, but the resting ball still looks the same: tracked at rest.
                return FootballFrameObservation(time: f.time, state: .atRest, source: .tracked, box: nil, score: nil, appearance: round3(look))
            }
            if let o = atOther.max(by: { $0.score < $1.score }) {
                return FootballFrameObservation(time: f.time, state: .otherFootball, source: .detected, box: o.box, score: round3(o.score),
                                                appearance: look.map(round3))
            }
            return FootballFrameObservation(time: f.time, state: .notSeen, source: .unavailable, box: nil, score: nil, appearance: look.map(round3))
        }
    }

    /// The last clear resting frame and the first frame of persistent movement, or nil
    /// with the reason.
    static func motionEvents(_ obs: [FootballFrameObservation], site: FootballRestSite, aspect: Double)
        -> (lastStationary: Double, firstMovement: Double, basis: String)? {
        func isRest(_ o: FootballFrameObservation) -> Bool { o.state == .atRest || o.state == .obscured }
        guard let firstRest = obs.firstIndex(where: isRest) else { return nil }
        var i = firstRest + 1
        while i < obs.count {
            defer { i += 1 }
            guard !isRest(obs[i]) else { continue }
            // Never back at rest afterwards, and gone for at least `persistenceFrames`.
            guard !obs[i...].contains(where: isRest), obs.count - i >= persistenceFrames else { return nil }
            let lead = obs[i..<min(obs.count, i + persistenceFrames + 1)]
            let moving = lead.filter { $0.state == .moving }
            let basis: String
            var movedAt = obs[i].time
            if moving.count >= 2 {
                // Moving AWAY: the second sighting is no closer to the resting spot.
                let d = moving.compactMap { $0.box.map { distance($0.center, site.center, aspect: aspect) } }
                guard d.count >= 2, d[1] >= d[0] - 0.25 * site.size else { return nil }
                basis = "displacedDetections"
                // Frames between the last resting sighting and the first moving one (the
                // ball hidden under the foot) are not movement.
                movedAt = moving[moving.startIndex].time
            } else {
                // Seen moving at most once: an empty resting spot counts only when the
                // ball's appearance confirms it's gone (a detector that merely stops firing
                // is not movement).
                let looks = lead.compactMap(\.appearance)
                guard looks.count >= persistenceFrames, looks.allSatisfy({ $0 < BallMotionTracker.disturbedThreshold }) else { return nil }
                basis = "restVanished"
            }
            let before = obs[..<i]
            guard let lastClear = before.last(where: { $0.state == .atRest }) ?? before.last(where: isRest) else { return nil }
            return (lastClear.time, movedAt, basis)
        }
        return nil
    }

    // MARK: Results

    /// Builds the track from both stages' real detections.
    static func analyze(broadScan: [FootballDetection], scanTimes: [Double],
                        precision: [(time: Double, detections: [FootballDetection])]?,
                        ankle: [AnkleSample], strike: ClosedRange<Double>?, aspect: Double, duration: Double,
                        appearance: [Double: Double] = [:], camera: CameraMotionSummary? = nil,
                        shift: (Double) -> (dx: Double, dy: Double) = { _ in (0, 0) },
                        detector: FootballDetectorInfo) -> FootballTrack {
        let found = sites(broadScan, aspect: aspect)
        var track = FootballTrack(method: .ballUnavailable, detector: detector, broadScanFrames: scanTimes.count, note: "")
        guard !found.isEmpty else {
            track.note = "The detector found no football resting in one place in the sampled frames."
            return track
        }
        let selection = selectKickedBall(sites: found, detections: broadScan, scanTimes: scanTimes, ankle: ankle, strike: strike, aspect: aspect)
        track.sites = selection.sites
        guard let k = selection.selected else {
            track.note = "None of the footballs the detector found could be identified as the kicked ball: "
                + selection.sites.map { String(format: "ball at (%.2f, %.2f) — %@", $0.center.x, $0.center.y, $0.reason) }.joined(separator: "; ") + "."
            return track
        }
        let site = selection.sites[k]
        let others = selection.sites.enumerated().filter { $0.offset != k }.map(\.element)
        track.restSize = round3(site.size)
        guard let precision, !precision.isEmpty else {
            track.method = .automaticFootballDetection
            track.note = "The kicked ball was found, but the frames around the strike weren't examined."
            return track
        }
        let obs = classify(frames: precision, site: site, otherSites: others, aspect: aspect, appearance: appearance, shift: shift)
        track.method = .automaticFootballDetection
        track.precisionFrames = obs.count
        track.observations = obs
        track.cameraMotion = camera
        track.rest = obs.first { $0.state == .atRest && $0.box != nil }?.box
            ?? NormalizedBox(cx: site.center.x, cy: site.center.y, w: site.size / max(aspect, 1e-6), h: site.size)
        if let e = motionEvents(obs, site: site, aspect: aspect) {
            track.lastStationaryTime = e.lastStationary
            track.firstPersistentMovementTime = e.firstMovement
            track.movementBasis = e.basis
            track.note = String(format: "The detector found the kicked ball at rest and followed it frame by frame: last clearly at rest at %.3f s, first persistent movement at %.3f s (%@). Contact happened no earlier than %.3f s (the foot may already touch a ball that hasn't visibly moved) and no later than %.3f s.",
                                e.lastStationary, e.firstMovement,
                                e.basis == "displacedDetections" ? "seen moving away" : "its spot stayed empty",
                                e.lastStationary, e.firstMovement)
        } else {
            track.note = "The kicked ball was found, but its departure wasn't clear in the frames around the strike (no persistent movement away from its spot)."
        }
        return track
    }

    /// The track as legacy observations for the side-view ball fusion: clear resting
    /// frames at the resting position; moving frames at their detected positions; nothing
    /// else counts as seen. Confidence is the detector score.
    static func trackingResult(_ track: FootballTrack) -> BallTrackingResult {
        guard track.method == .automaticFootballDetection, let rest = track.rest, let size = track.restSize else { return .unavailable }
        let obs = track.observations.map { o -> BallObservation in
            switch o.state {
            case .atRest where o.source == .detected:
                return BallObservation(timestamp: o.time, position: rest.center, radius: size / 2, confidence: max(0.5, o.score ?? 0), status: .tracked)
            case .moving:
                return BallObservation(timestamp: o.time, position: o.box?.center, radius: size / 2, confidence: max(0.5, o.score ?? 0), status: .tracked)
            default:
                return BallObservation(timestamp: o.time, position: nil, radius: nil, confidence: o.score ?? 0, status: .lost)
            }
        }
        return BallTrackingResult(status: .tracked, observations: obs, launchTime: track.firstPersistentMovementTime)
    }

    static func median(_ v: [Double]) -> Double {
        let s = v.sorted()
        return s.isEmpty ? 0 : s[s.count / 2]
    }

    static func median(_ p: [NormalizedPoint]) -> NormalizedPoint {
        NormalizedPoint(x: median(p.map(\.x)), y: median(p.map(\.y)))
    }

    static func round3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
}
