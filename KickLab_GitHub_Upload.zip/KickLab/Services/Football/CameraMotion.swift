import Foundation

extension NormalizedRect {
    /// Step 12G: true when the two rectangles overlap.
    func intersects(_ o: NormalizedRect) -> Bool { minX < o.maxX && o.minX < maxX && minY < o.maxY && o.minY < maxY }
}

/// Step 12G: small upright grayscale thumbnails of whole frames, for background (camera)
/// motion. Built from the STORED luma plane through the display orientation.
enum LumaThumbnail {
    /// - Parameters:
    ///   - storedWidth/storedHeight: the luma plane's size.
    ///   - luma: reads the stored luma plane at (x, y).
    ///   - targetHeight: thumbnail height in pixels (width follows the display aspect).
    static func make(storedWidth: Int, storedHeight: Int, orientation: VideoOrientation, isMirrored: Bool,
                     targetHeight: Int, luma: (Int, Int) -> UInt8) -> LumaImage? {
        let quarter = orientation == .right || orientation == .left
        let dw = Double(quarter ? storedHeight : storedWidth), dh = Double(quarter ? storedWidth : storedHeight)
        guard dw > 0, dh > 0, targetHeight > 1 else { return nil }
        let th = targetHeight, tw = max(2, Int((Double(targetHeight) * dw / dh).rounded()))
        var px = [UInt8](repeating: 0, count: tw * th)
        for y in 0..<th {
            for x in 0..<tw {
                // Average of 4 samples inside the thumbnail pixel (light anti-aliasing).
                var sum = 0
                for (ox, oy) in [(0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)] {
                    let p = PoseCoordinates.stored(NormalizedPoint(x: (Double(x) + ox) / Double(tw), y: (Double(y) + oy) / Double(th)),
                                                   from: orientation, isMirrored: isMirrored)
                    let sx = min(storedWidth - 1, max(0, Int(p.x * Double(storedWidth))))
                    let sy = min(storedHeight - 1, max(0, Int(p.y * Double(storedHeight))))
                    sum += Int(luma(sx, sy))
                }
                px[y * tw + x] = UInt8(sum / 4)
            }
        }
        return LumaImage(width: tw, height: th, pixels: px)
    }

    /// Build 22: a region of the DISPLAYED frame (normalized rect) as a `width`×`height` luma
    /// image, each pixel the mean of up to 2×2 stored-plane samples (area averaging, so a
    /// downscaled ball keeps its contrast). Used by the strike-site ball finder.
    static func region(storedWidth: Int, storedHeight: Int, orientation: VideoOrientation, isMirrored: Bool,
                       region: NormalizedRect, width: Int, height: Int, luma: (Int, Int) -> UInt8) -> LumaImage? {
        guard width > 1, height > 1, storedWidth > 0, storedHeight > 0, region.width > 0, region.height > 0 else { return nil }
        let quarter = orientation == .right || orientation == .left
        let dw = Double(quarter ? storedHeight : storedWidth), dh = Double(quarter ? storedWidth : storedHeight)
        // Samples per output pixel along each axis: about one per displayed pixel, at most 2.
        let k = max(1, min(2, Int((max(region.width * dw / Double(width), region.height * dh / Double(height))).rounded(.up))))
        var px = [UInt8](repeating: 0, count: width * height)
        for y in 0..<height {
            for x in 0..<width {
                var sum = 0
                for sy in 0..<k {
                    for sx in 0..<k {
                        let nx = region.minX + (Double(x) + (Double(sx) + 0.5) / Double(k)) / Double(width) * region.width
                        let ny = region.minY + (Double(y) + (Double(sy) + 0.5) / Double(k)) / Double(height) * region.height
                        let p = PoseCoordinates.stored(NormalizedPoint(x: nx, y: ny), from: orientation, isMirrored: isMirrored)
                        let ix = min(storedWidth - 1, max(0, Int(p.x * Double(storedWidth))))
                        let iy = min(storedHeight - 1, max(0, Int(p.y * Double(storedHeight))))
                        sum += Int(luma(ix, iy))
                    }
                }
                px[y * width + x] = UInt8(sum / (k * k))
            }
        }
        return LumaImage(width: width, height: height, pixels: px)
    }
}

/// Step 12G: global camera movement from the BACKGROUND, so a ball box that moves only
/// because the camera moved isn't mistaken for the ball moving. Blocks of the frame away
/// from the athlete and the ball are matched between frames (normalized cross-correlation);
/// the median block displacement is the camera's apparent shift.
enum CameraMotionEstimator {
    static let blockSize = 12
    static let searchRadius = 4
    static let minimumMatch = 0.8
    static let minimumBlocks = 4
    /// Background blocks need visible texture.
    static let minimumVariance = 25.0
    /// Shifts above this many ball sizes mean the camera moved during the strike.
    static let movedBallSizes = 0.25

    /// Shift of `next` relative to `reference` as a fraction of the thumbnail width and
    /// height (displayed coordinates), or nil when too few background blocks matched.
    static func shift(reference: LumaImage, next: LumaImage, exclude: [NormalizedRect]) -> (dx: Double, dy: Double, blocks: Int)? {
        guard reference.width == next.width, reference.height == next.height else { return nil }
        let b = blockSize, r = searchRadius
        var dxs: [Double] = [], dys: [Double] = []
        var y = r
        while y + b + r <= reference.height {
            var x = r
            while x + b + r <= reference.width {
                defer { x += b }
                let rect = NormalizedRect(minX: Double(x - r) / Double(reference.width), minY: Double(y - r) / Double(reference.height),
                                          maxX: Double(x + b + r) / Double(reference.width), maxY: Double(y + b + r) / Double(reference.height))
                guard !exclude.contains(where: { $0.intersects(rect) }),
                      let template = BallMotionTracker.patch(reference, x, y, b, b),
                      BallMotionTracker.variance(template) >= minimumVariance else { continue }
                var best = -1.0, at = (0, 0)
                for oy in -r...r {
                    for ox in -r...r {
                        guard let p = BallMotionTracker.patch(next, x + ox, y + oy, b, b) else { continue }
                        let s = BallMotionTracker.ncc(template, p)
                        if s > best { best = s; at = (ox, oy) }
                    }
                }
                if best >= minimumMatch {
                    dxs.append(Double(at.0))
                    dys.append(Double(at.1))
                }
            }
            y += b
        }
        guard dxs.count >= minimumBlocks else { return nil }
        return (FootballTrackAnalyzer.median(dxs) / Double(reference.width), FootballTrackAnalyzer.median(dys) / Double(reference.height), dxs.count)
    }

    /// Shifts of every thumbnail relative to the first one, by time (displayed normalized
    /// units), and a summary in ball sizes. Frames that couldn't be matched get no entry.
    static func track(_ frames: [(time: Double, image: LumaImage)], exclude: (Double) -> [NormalizedRect],
                      ballSize: Double, aspect: Double) -> (shifts: [Double: (dx: Double, dy: Double)], summary: CameraMotionSummary) {
        guard let first = frames.first else {
            return ([:], CameraMotionSummary(maximumShiftBallSizes: 0, framesMeasured: 0, cameraMoved: false,
                                             note: "Camera movement wasn't measured."))
        }
        var shifts: [Double: (dx: Double, dy: Double)] = [first.time: (0, 0)]
        var largest = 0.0
        for f in frames.dropFirst() {
            guard let s = shift(reference: first.image, next: f.image, exclude: exclude(f.time) + exclude(first.time)) else { continue }
            shifts[f.time] = (s.dx, s.dy)
            if ballSize > 0 { largest = max(largest, hypot(s.dx * aspect, s.dy) / ballSize) }
        }
        let moved = largest > movedBallSizes
        let note = shifts.count < 2
            ? "Camera movement couldn't be measured (too little background texture)."
            : (moved ? String(format: "The camera moved during the strike (up to %.1f ball sizes); the ball's resting spot was followed with it.", largest)
                     : "The camera was steady around the strike.")
        return (shifts, CameraMotionSummary(maximumShiftBallSizes: (largest * 100).rounded() / 100, framesMeasured: shifts.count,
                                            cameraMoved: moved, note: note))
    }

    /// The shift at `time` (nearest measured frame within 0.1 s; zero otherwise).
    static func lookup(_ shifts: [Double: (dx: Double, dy: Double)], at time: Double) -> (dx: Double, dy: Double) {
        guard let k = shifts.keys.min(by: { abs($0 - time) < abs($1 - time) }), abs(k - time) <= 0.1 else { return (0, 0) }
        return shifts[k] ?? (0, 0)
    }
}
