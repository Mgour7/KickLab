import Foundation

/// Step 12G (Computer Vision Intelligence Rebuild) — Layer E: records the football
/// detector's track in the phase result.
/// - Depth views (behind / in front): the detector already used the ball's contact bounds
///   (`DepthViewPhaseDetector.ballContact`); this only fills in the evidence when the ball
///   wasn't usable.
/// - Side view: the ball's observations go through the Step 12F fusion, which moves the
///   contact time inside the ball interval only when ball and pose agree.
/// User-assisted results are never changed; only the method is recorded.
enum FootballContactFusion {
    static func apply(_ phases: KickPhaseDetectionResult, football: FootballTrack, perspective: CameraPerspective,
                      timeline: KickerPoseTimeline, kickingFoot: KickingFoot) -> KickPhaseDetectionResult {
        var result = phases
        if !perspective.isDepthView, !phases.isUserAssisted {
            result = BallContactFusion.apply(phases, ball: FootballTrackAnalyzer.trackingResult(football), timeline: timeline,
                                             kickingFoot: kickingFoot)
        }
        guard var evidence = result.evidence else { return result }
        evidence.ballAnalysisMethod = football.method
        if !phases.isUserAssisted {
            let usable = football.contactBounds != nil && football.method == .automaticFootballDetection
            if !usable || evidence.ballEvidence == nil || evidence.ballEvidence?.outcome == .detectorUnavailable {
                var e = evidence.ballEvidence ?? .unavailable
                if !usable {
                    e.outcome = football.detector == nil ? .detectorUnavailable : .ballNotVisible
                    e.detectorName = football.detector?.name
                    e.framesExamined = football.broadScanFrames + football.precisionFrames
                    e.framesWithBall = football.observations.filter { $0.source == .detected }.count
                    e.lastStationaryTime = football.lastStationaryTime
                    e.firstDisplacementTime = football.firstPersistentMovementTime
                    e.note = football.note
                }
                evidence.ballEvidence = e
            }
            if evidence.contactOutcome == nil { evidence.contactOutcome = ContactOutcome.of(result) }
            if perspective.isDepthView, evidence.ballFusion == nil {
                // No usable ball departure reached the detector: say whether the football
                // analysis ran at all, and why it gave nothing.
                var f = BallFusionReport(detectorRan: football.detector != nil, ballSelected: football.sites.contains(where: \.selected))
                f.lastStationaryTime = football.lastStationaryTime
                f.firstMovementTime = football.firstPersistentMovementTime
                f.rejectionReason = usable ? nil : (football.detector == nil ? "The football detector didn't run: " : "No usable ball departure: ") + football.note
                evidence.ballFusion = f
            }
        }
        result.evidence = evidence
        return result
    }
}
