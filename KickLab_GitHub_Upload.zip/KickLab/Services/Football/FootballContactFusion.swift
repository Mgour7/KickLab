import Foundation

/// Step 12G (Computer Vision Intelligence Rebuild) — Layer E: records the football
/// detector's track in the phase result.
/// - Depth views (behind / in front): the detector already used the ball's contact bounds
///   (`DepthViewPhaseDetector.ballContact`); this only fills in the evidence when the ball
///   wasn't usable.
/// - Side view: the ball's observations go through the Step 12F fusion, which moves the
///   contact time inside the ball interval only when ball and pose agree.
/// User-assisted results are never changed; only the method is recorded.
enum FootballContactFusion {
    static func apply(_ phases: KickPhaseDetectionResult, football: FootballTrack, perspective: CameraPerspective,
                      timeline: KickerPoseTimeline, kickingFoot: KickingFoot) -> KickPhaseDetectionResult {
        var result = phases
        if !perspective.isDepthView, !phases.isUserAssisted {
            if let ball = AutomaticBallContact(football) {
                // Build 15: the side view uses the same ball-departure bounds as the depth
                // views (the Step 12F visibility-share rule discarded tracks with frames hidden
                // under the foot, which is exactly where contact is).
                result = refineSideContact(phases, ball: ball, timeline: timeline)
            } else {
                result = BallContactFusion.apply(phases, ball: FootballTrackAnalyzer.trackingResult(football), timeline: timeline,
                                                 kickingFoot: kickingFoot)
            }
        }
        guard var evidence = result.evidence else { return result }
        evidence.ballAnalysisMethod = football.method
        if !phases.isUserAssisted {
            let usable = football.contactBounds != nil && football.method.isAutomatic
            if !usable || evidence.ballEvidence == nil || evidence.ballEvidence?.outcome == .detectorUnavailable {
                var e = evidence.ballEvidence ?? .unavailable
                if !usable {
                    e.outcome = football.detector == nil ? .detectorUnavailable : .ballNotVisible
                    e.detectorName = football.detector?.name
                    e.framesExamined = football.broadScanFrames + football.precisionFrames
                    e.framesWithBall = football.observations.filter { $0.source == .detected }.count
                    e.lastStationaryTime = football.lastStationaryTime
                    e.firstDisplacementTime = football.firstPersistentMovementTime
                    e.note = football.note
                }
                evidence.ballEvidence = e
            }
            if evidence.contactOutcome == nil { evidence.contactOutcome = ContactOutcome.of(result) }
            if perspective.isDepthView, evidence.ballFusion == nil {
                // No usable ball departure reached the detector: say whether the football
                // analysis ran at all, and why it gave nothing.
                var f = BallFusionReport(detectorRan: football.detector != nil, ballSelected: football.sites.contains(where: \.selected))
                f.lastStationaryTime = football.lastStationaryTime
                f.firstMovementTime = football.firstPersistentMovementTime
                f.rejectionReason = usable ? nil : (football.detector == nil ? "The football detector didn't run: " : "No usable ball departure: ") + football.note
                evidence.ballFusion = f
            }
        }
        result.evidence = evidence
        return result
    }

    /// Build 15: side view. The pose contact stands unless the ball's departure narrows it:
    /// only when the ball interval overlaps the pose interval (±1 frame) and is within the
    /// contact tolerance does contact move to the middle of the frames the ball allows.
    static func refineSideContact(_ phases: KickPhaseDetectionResult, ball: AutomaticBallContact,
                                  timeline: KickerPoseTimeline) -> KickPhaseDetectionResult {
        guard var evidence = phases.evidence else { return phases }
        let contact = phases.phase(.contact)
        guard contact.isAvailable, contact.status != .ambiguous, let t = contact.representativeTime else { return phases }
        let times = timeline.samples.map(\.timestamp)
        let frame = times.count > 1 ? 1 / KickPhaseDetector.framesPerSecond(times) : 1.0 / 30
        let lo = min(evidence.contactEarliestTime ?? t, t), hi = max(evidence.contactLatestTime ?? t, t)
        let r = DepthViewPhaseDetector.ballContact(ball, times: times, poseBounds: (lo - frame)...(hi + frame))
        evidence.ballEvidence = r.evidence
        // Build 16: the side view's pose timing score is the pose contact's own confidence,
        // recorded before (and never changed by) the ball evidence.
        evidence.poseTimingScore = evidence.poseTimingScore ?? ContactEstimator.round3(contact.confidence)
        var f = evidence.ballFusion ?? BallFusionReport(detectorRan: true, ballSelected: true)
        f.lastStationaryTime = ball.lastStationaryTime
        f.firstMovementTime = ball.firstMovementTime
        f.poseFoundStrike = true
        f.poseStrikeEarliest = ContactEstimator.round3(lo)
        f.poseStrikeLatest = ContactEstimator.round3(hi)
        f.overlapsPose = r.evidence.outcome != .conflicting
        f.departure = FootballDepartureKind(basis: ball.basis).rawValue
        f.fusionVersion = BallFusionReport.version
        f.accepted = r.resolved != nil
        f.acceptancePath = r.resolved != nil ? BallFusionReport.Path.poseStrikeAgreement.rawValue : nil
        f.rejectionReason = r.resolved != nil ? nil : r.evidence.note
        evidence.ballFusion = f
        var notes = phases.notes
        var phaseList = phases.phases
        if let res = r.resolved, let i = phaseList.firstIndex(where: { $0.phase == .contact }) {
            let c = phaseList[i]
            let time = times[res.index]
            phaseList[i] = DetectedKickPhase(phase: .contact, startTime: time, endTime: time, representativeTime: time,
                                             confidence: c.confidence, evidence: c.evidence, status: c.status)
            evidence.contactEarliestTime = ContactEstimator.round3(times[res.earliest])
            evidence.contactLatestTime = ContactEstimator.round3(times[res.latest])
            evidence.contactUncertaintySeconds = ContactEstimator.round3(max(frame / 2, (ball.firstMovementTime - ball.lastStationaryTime) / 2))
            evidence.contactTimingMethod = "ballDetector"
            evidence.contactProvenance = "ballAware"
            evidence.contactOutcome = .ballConstrainedContactInterval
            notes.append(String(format: "Contact narrowed by the football (%@): the ball was last at rest at %.3f s and first seen moving at %.3f s (pose estimate %.3f s); contact shown at %.3f s.",
                                ball.detectorName, ball.lastStationaryTime, ball.firstMovementTime, t, time))
        } else {
            evidence.contactProvenance = evidence.contactProvenance ?? "poseOnly"
            if r.evidence.outcome == .conflicting {
                evidence.contactConflicts = (evidence.contactConflicts ?? []) + [r.evidence.note]
                notes.append(r.evidence.note)
            }
        }
        var rebuilt = KickPhaseDetectionResult(kickType: phases.kickType, support: phases.support, phases: phaseList,
                                               overallConfidence: phases.overallConfidence, dataCoverage: phases.dataCoverage, notes: notes)
        rebuilt.evidence = evidence
        rebuilt.kickWindows = phases.kickWindows
        rebuilt.assistance = phases.assistance
        return rebuilt
    }
}
