import Foundation

// Step 12G (Computer Vision Intelligence Rebuild) — Layer B: object detection on real
// pixels. This file is the platform-independent part of the football detector: model
// facts, the letterbox that turns a (rotated, possibly mirrored) video frame into the
// model's input, and the YOLOX output decoder with non-maximum suppression. The Core ML
// call itself lives in `Apple/CoreMLFootballDetector.swift`.
//
// The model is the official YOLOX-S release (Megvii, Apache-2.0) trained on COCO 2017,
// converted to Core ML by `Scripts/cv/convert_yolox_to_coreml.py`. COCO has no
// "American football" class: KickLab uses its "sports ball" class (index 32). On the real
// IMG_1709 rear-view frames that class fires on the placed American football (see
// Docs/FOOTBALL_DETECTOR_MODEL_CARD.md); that is ONE development clip, not validation, so
// every automatic result is checked by the tracking rules in `FootballTracking.swift`.

/// Facts about the detector model, recorded with every result.
struct FootballDetectorInfo: Codable, Equatable, Sendable {
    var name: String
    var modelVersion: String
    var license: String
    /// The model class used as "football".
    var classIndex: Int
    var className: String
    /// Square model input, in pixels.
    var inputSize: Int

    static let yoloxS = FootballDetectorInfo(
        name: "YOLOX-S (COCO, Megvii)", modelVersion: "yolox_s 0.1.1rc0, Core ML fp16 conversion (KickLab 12G)",
        license: "Apache-2.0 (code and weights); trained on COCO 2017", classIndex: 32, className: "sports ball", inputSize: 640
    )
    /// The compiled model's resource name in the app bundle (`.mlmodelc`).
    static let resourceName = "YOLOXSportsBall"
    static let inputName = "images"
    static let outputName = "output"
}

/// A box in app-normalized DISPLAYED coordinates: top-left origin, x as a fraction of the
/// displayed width, y and h of the displayed height.
struct NormalizedBox: Codable, Equatable, Sendable {
    var cx: Double
    var cy: Double
    var w: Double
    var h: Double

    var center: NormalizedPoint { NormalizedPoint(x: cx, y: cy) }

    func iou(_ o: NormalizedBox) -> Double {
        let ix = max(0, min(cx + w / 2, o.cx + o.w / 2) - max(cx - w / 2, o.cx - o.w / 2))
        let iy = max(0, min(cy + h / 2, o.cy + o.h / 2) - max(cy - h / 2, o.cy - o.h / 2))
        let inter = ix * iy
        let union = w * h + o.w * o.h - inter
        return union > 0 ? inter / union : 0
    }

    /// The ball's size in displayed-HEIGHT units (geometric mean of width and height,
    /// with the width converted by the display aspect ratio).
    func size(aspect: Double) -> Double { (max(0, w * aspect) * max(0, h)).squareRoot() }
}

/// A rectangle of the displayed (upright, as-viewed) frame, in displayed pixels.
struct DisplayRect: Codable, Equatable, Sendable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double
}

/// Where the model input came from: `region` of the displayed frame, scaled by `scale`
/// and placed at the top-left of the square input (the rest is padding), exactly like the
/// YOLOX reference preprocessing.
struct LetterboxGeometry: Equatable, Sendable {
    let region: DisplayRect
    let inputSize: Int

    var scale: Double { min(Double(inputSize) / region.width, Double(inputSize) / region.height) }

    /// Model-input pixels → displayed pixels.
    func displayPoint(modelX: Double, modelY: Double) -> (x: Double, y: Double) {
        (region.x + modelX / scale, region.y + modelY / scale)
    }

    /// Displayed pixels → model-input pixels.
    func modelPoint(displayX: Double, displayY: Double) -> (x: Double, y: Double) {
        ((displayX - region.x) * scale, (displayY - region.y) * scale)
    }
}

/// Reads one pixel of a STORED (un-rotated) video frame as blue, green, red (0…255).
protocol BGRPixelSource {
    var width: Int { get }
    var height: Int { get }
    func bgr(x: Int, y: Int) -> (b: Float, g: Float, r: Float)
}

/// A packed BGR test/fixture image (row-major, 3 bytes per pixel).
struct PackedBGRImage: BGRPixelSource, Equatable, Sendable {
    let width: Int
    let height: Int
    let bytes: [UInt8]

    func bgr(x: Int, y: Int) -> (b: Float, g: Float, r: Float) {
        let i = (y * width + x) * 3
        return (Float(bytes[i]), Float(bytes[i + 1]), Float(bytes[i + 2]))
    }
}

enum DetectorInputBuilder {
    /// YOLOX pads with this gray value.
    static let padValue: Float = 114

    /// Builds the model input (planar B, G, R, 0…255, no normalization) for `region` of
    /// the DISPLAYED frame. The stored frame is sampled through the inverse of its display
    /// orientation (and mirroring), with bilinear interpolation, so the model sees the
    /// frame upright as the user does.
    static func makeInput<Source: BGRPixelSource>(
        source: Source, orientation: VideoOrientation, isMirrored: Bool, region: DisplayRect, inputSize: Int
    ) -> (input: [Float], geometry: LetterboxGeometry) {
        let geometry = LetterboxGeometry(region: region, inputSize: inputSize)
        let n = inputSize
        var out = [Float](repeating: padValue, count: 3 * n * n)
        let quarter = orientation == .right || orientation == .left
        let displayWidth = Double(quarter ? source.height : source.width)
        let displayHeight = Double(quarter ? source.width : source.height)
        let s = geometry.scale
        let usedW = min(n, Int((region.width * s).rounded(.down)))
        let usedH = min(n, Int((region.height * s).rounded(.down)))
        guard usedW > 0, usedH > 0, displayWidth > 0, displayHeight > 0 else { return (out, geometry) }
        let sw = Double(source.width), sh = Double(source.height)
        let plane = n * n
        for my in 0..<usedH {
            let dy = region.y + (Double(my) + 0.5) / s
            for mx in 0..<usedW {
                let dx = region.x + (Double(mx) + 0.5) / s
                // Displayed → stored, in normalized units, then stored pixel centers.
                let p = PoseCoordinates.stored(NormalizedPoint(x: dx / displayWidth, y: dy / displayHeight),
                                               from: orientation, isMirrored: isMirrored)
                let fx = p.x * sw - 0.5, fy = p.y * sh - 0.5
                let px = sample(source, fx, fy)
                let o = my * n + mx
                out[o] = px.b
                out[plane + o] = px.g
                out[2 * plane + o] = px.r
            }
        }
        return (out, geometry)
    }

    /// Bilinear sample at a continuous stored-pixel position (edges clamped).
    static func sample<Source: BGRPixelSource>(_ s: Source, _ x: Double, _ y: Double) -> (b: Float, g: Float, r: Float) {
        let maxX = s.width - 1, maxY = s.height - 1
        let cx = min(max(x, 0), Double(maxX)), cy = min(max(y, 0), Double(maxY))
        let x0 = Int(cx.rounded(.down)), y0 = Int(cy.rounded(.down))
        let x1 = min(x0 + 1, maxX), y1 = min(y0 + 1, maxY)
        let ax = Float(cx - Double(x0)), ay = Float(cy - Double(y0))
        let p00 = s.bgr(x: x0, y: y0), p10 = s.bgr(x: x1, y: y0), p01 = s.bgr(x: x0, y: y1), p11 = s.bgr(x: x1, y: y1)
        func mix(_ a: Float, _ b: Float, _ c: Float, _ d: Float) -> Float {
            (a * (1 - ax) + b * ax) * (1 - ay) + (c * (1 - ax) + d * ax) * ay
        }
        return (mix(p00.b, p10.b, p01.b, p11.b), mix(p00.g, p10.g, p01.g, p11.g), mix(p00.r, p10.r, p01.r, p11.r))
    }

    /// A square crop of the displayed frame around a point (displayed pixels), clamped
    /// inside the frame. Used by the precision pass around the resting ball.
    static func cropRegion(centerX: Double, centerY: Double, side: Double, displayWidth: Double, displayHeight: Double) -> DisplayRect {
        let s = min(side, displayWidth, displayHeight)
        let x = min(max(0, centerX - s / 2), displayWidth - s)
        let y = min(max(0, centerY - s / 2), displayHeight - s)
        return DisplayRect(x: x, y: y, width: s, height: s)
    }
}

/// One raw model detection in model-input pixels.
struct ModelBox: Equatable, Sendable {
    var cx: Double
    var cy: Double
    var w: Double
    var h: Double
    var score: Double
}

/// Decodes the YOLOX head output ([1, anchors, 5 + classes]: box offsets, objectness and
/// class probabilities — the released ONNX already applies the sigmoid) for one class.
enum YOLOXDecoder {
    static let strides = [8, 16, 32]
    /// Detections below this objectness × class score are not reported at all.
    static let minimumScore = 0.05
    static let nmsIoU = 0.45
    static let maximumDetections = 20

    static func anchorCount(inputSize: Int) -> Int { strides.reduce(0) { $0 + (inputSize / $1) * (inputSize / $1) } }

    /// - Parameter value: reads output element (anchor, column).
    static func decode(inputSize: Int, classIndex: Int, threshold: Double = minimumScore,
                       value: (Int, Int) -> Float) -> [ModelBox] {
        var boxes: [ModelBox] = []
        var anchor = 0
        for stride in strides {
            let cells = inputSize / stride
            for gy in 0..<cells {
                for gx in 0..<cells {
                    defer { anchor += 1 }
                    let score = Double(value(anchor, 4)) * Double(value(anchor, 5 + classIndex))
                    guard score >= threshold, score.isFinite else { continue }
                    let s = Double(stride)
                    let cx = (Double(value(anchor, 0)) + Double(gx)) * s
                    let cy = (Double(value(anchor, 1)) + Double(gy)) * s
                    let w = exp(Double(value(anchor, 2))) * s
                    let h = exp(Double(value(anchor, 3))) * s
                    guard cx.isFinite, cy.isFinite, w.isFinite, h.isFinite, w > 0, h > 0 else { continue }
                    boxes.append(ModelBox(cx: cx, cy: cy, w: w, h: h, score: score))
                }
            }
        }
        return nonMaximumSuppression(boxes)
    }

    /// Greedy suppression: highest score first; drops boxes overlapping a kept one.
    static func nonMaximumSuppression(_ boxes: [ModelBox], iou threshold: Double = nmsIoU, limit: Int = maximumDetections) -> [ModelBox] {
        var kept: [ModelBox] = []
        for b in boxes.sorted(by: { $0.score > $1.score }) {
            if kept.allSatisfy({ iou($0, b) <= threshold }) { kept.append(b) }
            if kept.count == limit { break }
        }
        return kept
    }

    static func iou(_ a: ModelBox, _ b: ModelBox) -> Double {
        NormalizedBox(cx: a.cx, cy: a.cy, w: a.w, h: a.h).iou(NormalizedBox(cx: b.cx, cy: b.cy, w: b.w, h: b.h))
    }

    /// Model-input boxes → app-normalized displayed boxes. Boxes centered in the padding
    /// (outside the sampled region) are dropped.
    static func displayBoxes(_ boxes: [ModelBox], geometry: LetterboxGeometry, displayWidth: Double, displayHeight: Double)
        -> [(box: NormalizedBox, score: Double)] {
        boxes.compactMap { b in
            let c = geometry.displayPoint(modelX: b.cx, modelY: b.cy)
            let r = geometry.region
            guard c.x >= r.x, c.x <= r.x + r.width, c.y >= r.y, c.y <= r.y + r.height else { return nil }
            let s = geometry.scale
            return (NormalizedBox(cx: c.x / displayWidth, cy: c.y / displayHeight, w: b.w / s / displayWidth, h: b.h / s / displayHeight),
                    b.score)
        }
    }
}
