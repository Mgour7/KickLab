import Foundation

/// Step 12G (Computer Vision Intelligence Rebuild) — Layer E: what kind of contact
/// answer an analysis has, from strongest to weakest. Shown in results, diagnostics and the
/// coaching report so a pose estimate is never presented as a ball-verified contact, and a
/// user's choice never as automatic.
enum ContactOutcome: String, Codable, Sendable, CaseIterable {
    /// The football detector saw the ball at rest on one frame and moving on the next:
    /// contact happened within that single frame interval.
    case ballVerifiedContact
    /// The football detector's frames limit contact to a short interval (a few frames).
    case ballConstrainedContactInterval
    /// Body pose alone placed contact within the timing tolerance.
    case poseEstimatedContact
    /// Body pose only found the strike window; the moment of contact is uncertain.
    case strikeWindowOnly
    /// A contact time exists but its evidence conflicts or several kicks compete.
    case contactUncertain
    /// No contact was found.
    case contactUnavailable
    /// The user chose the contact frame (user-assisted; never automatic accuracy).
    case userSelectedContact

    var title: String {
        switch self {
        case .ballVerifiedContact: "Contact verified from the ball"
        case .ballConstrainedContactInterval: "Contact narrowed by the ball"
        case .poseEstimatedContact: "Contact estimated from body pose"
        case .strikeWindowOnly: "Strike window only"
        case .contactUncertain: "Contact uncertain"
        case .contactUnavailable: "Contact not found"
        case .userSelectedContact: "Contact chosen by you"
        }
    }

    var isAutomatic: Bool { self != .userSelectedContact }
    var usesBallEvidence: Bool { self == .ballVerifiedContact || self == .ballConstrainedContactInterval }

    /// The outcome of a phase result (also for files written before Step 12G).
    static func of(_ phases: KickPhaseDetectionResult) -> ContactOutcome {
        let contact = phases.phase(.contact)
        guard contact.isAvailable else { return .contactUnavailable }
        let e = phases.evidence
        if phases.isUserAssisted || e?.contactTimingSource == .user { return .userSelectedContact }
        if let stored = e?.contactOutcome, stored != .userSelectedContact { return contact.status == .ambiguous && stored.usesBallEvidence ? .contactUncertain : stored }
        if e?.contactTimingMethod == "strikeWindow" { return .strikeWindowOnly }
        if contact.status == .ambiguous { return .contactUncertain }
        if e?.contactProvenance == "ballAware" { return .ballConstrainedContactInterval }
        return .poseEstimatedContact
    }
}
