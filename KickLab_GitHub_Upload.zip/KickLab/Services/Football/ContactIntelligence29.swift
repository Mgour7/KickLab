import Foundation

// Build 16 — Contact Intelligence 2.9.0 (engine pose-biomechanics-2.9.0).
//
// Three additions, all diagnostic or derived; none changes how a ball is detected:
// - `FootballDeparture`: how the kicked ball's departure was (or wasn't) seen, keeping
//   "seen moving", "its spot emptied", "hidden at the moment it left" and "unclear" apart;
// - `DriveCandidateRecord`: every credible knee drive the ball/pose fusion compared;
// - `ContactConfidenceBreakdown`: the separate measures that used to be folded into one
//   "contact confidence" number.

/// Build 16: how the kicked ball's departure was observed. Disappearance, occlusion and
/// observed movement are never merged: only the first two kinds bound contact.
enum FootballDepartureKind: String, Codable, Equatable, Sendable, CaseIterable {
    /// The detector saw the ball moving away from its resting spot on ≥ 2 frames.
    case observedMovingBall
    /// The ball was seen moving at most once, but its resting spot stayed empty — confirmed
    /// by the spot's appearance on ≥ 3 frames — and the ball never returned.
    case restSiteVacated
    /// The ball was hidden (foot / body over it, or no box) when it would have left, and no
    /// persistent movement or empty-spot confirmation followed.
    case occludedAtDeparture
    /// The frames don't say when (or whether) the ball left.
    case departureUncertain

    /// The kind a recorded movement basis stands for.
    init(basis: String) {
        switch basis {
        case "displacedDetections": self = .observedMovingBall
        case "restVanished": self = .restSiteVacated
        default: self = .departureUncertain
        }
    }

    /// True for the kinds that may bound contact.
    var boundsContact: Bool { self == .observedMovingBall || self == .restSiteVacated }

    /// Short, athlete-facing wording.
    var athleteText: String {
        switch self {
        case .observedMovingBall: "Ball seen leaving"
        case .restSiteVacated: "Ball's spot seen empty"
        case .occludedAtDeparture: "Ball hidden as it left"
        case .departureUncertain: "Ball departure unclear"
        }
    }
}

struct FootballDeparture: Codable, Equatable, Sendable {
    var kind: FootballDepartureKind
    var framesMovingAfterRest: Int
    var framesObscuredAfterRest: Int
    var framesNotSeenAfterRest: Int
    /// The safeguards this classification passed (or the one that failed).
    var reason: String

    var line: String {
        "    departure: \(kind.rawValue) — \(reason) (after rest: moving \(framesMovingAfterRest), obscured \(framesObscuredAfterRest), not seen \(framesNotSeenAfterRest))"
    }

    /// Classifies a track's departure (nil when no kicked ball was followed frame by frame).
    static func classify(_ track: FootballTrack) -> FootballDeparture? {
        guard track.method == .automaticFootballDetection, !track.observations.isEmpty else { return nil }
        let obs = track.observations
        let lastRest = obs.lastIndex { $0.state == .atRest }
        let after = lastRest.map { Array(obs[($0 + 1)...]) } ?? obs
        let moving = after.filter { $0.state == .moving }.count
        let obscured = after.filter { $0.state == .obscured }.count
        let notSeen = after.filter { $0.state == .notSeen }.count
        func make(_ k: FootballDepartureKind, _ r: String) -> FootballDeparture {
            FootballDeparture(kind: k, framesMovingAfterRest: moving, framesObscuredAfterRest: obscured, framesNotSeenAfterRest: notSeen, reason: r)
        }
        if track.lastStationaryTime != nil, track.firstPersistentMovementTime != nil {
            switch track.movementBasis {
            case "displacedDetections":
                return make(.observedMovingBall, "seen moving away on ≥ 2 frames, never back at its spot")
            case "restVanished":
                return make(.restSiteVacated, "spot stayed empty (appearance confirmed on ≥ 3 frames), ball never back at rest, at most one moving sighting")
            default:
                return make(.departureUncertain, "a departure was recorded with an unknown basis")
            }
        }
        if lastRest == nil { return make(.departureUncertain, "the ball was never clearly at rest in the examined frames") }
        if after.isEmpty { return make(.departureUncertain, "the ball was still at rest in the last examined frame") }
        if moving >= 2 { return make(.departureUncertain, "movement was seen, but not persistently away from the spot") }
        if obscured + notSeen > 0 {
            return make(.occludedAtDeparture, "the ball was hidden or unseen after its last resting frame and no empty-spot confirmation followed")
        }
        return make(.departureUncertain, "no persistent movement and no empty-spot confirmation")
    }
}

extension FootballTrack {
    /// Build 18: the kicked ball's resting box, only when the automatic detector selected a
    /// kicked ball (used for rear/front-view plant placement).
    static func kickedBallRest(_ track: FootballTrack) -> NormalizedBox? {
        guard track.method == .automaticFootballDetection, track.sites.contains(where: \.selected) else { return nil }
        return track.rest
    }

    /// Build 16: the departure classification (derived; nothing extra is stored).
    var departure: FootballDeparture? { FootballDeparture.classify(self) }

    /// Build 16: one diagnostic line on whether the selected ball is plausibly the kicked one.
    var selectionCheck: String? {
        guard let s = sites.first(where: \.selected) else { return sites.isEmpty ? nil : "    ball selection: none of \(sites.count) ball(s) qualified" }
        let others = sites.filter { !$0.selected }
        let rivals = others.filter { $0.reason.hasPrefix("another ball the foot also came near") }
        var text = String(format: "    ball selection: %d ball(s) found · selected ball: foot came within %@ ball sizes · seen at its spot after the kick on %@ of frames",
                          sites.count, s.closestAnkleSizes.map { String(format: "%.2f", $0) } ?? "—",
                          s.afterStrikeShare.map { String(format: "%.0f%%", $0 * 100) } ?? "—")
        text += rivals.isEmpty ? " · no rival ball near the foot" : " · \(rivals.count) other ball(s) the foot also came near (check the kicked ball in Verify Contact)"
        return text
    }
}

/// Build 16: one credible knee drive the fusion considered.
struct DriveCandidateRecord: Codable, Equatable, Sendable {
    var startTime: Double
    var completeTime: Double
    var rateDegreesPerSecond: Double
    var extensionDegrees: Double
    /// Overlaps the ball interval (±1 frame).
    var overlapsBall: Bool
    /// Begins after the ball was already moving: it can't be the initial strike.
    var startsAfterBallLeft: Bool
    /// "selectedByPose", "usedWithBall", "followThroughExtension", "notUsed".
    var role: String
}

/// Build 16: the separate measures behind a contact result. None is a probability.
struct ContactConfidenceBreakdown: Codable, Equatable, Sendable {
    enum Level: String, Codable, Equatable, Sendable {
        case strong, moderate, weak, unavailable
        var rank: Int {
            switch self {
            case .strong: 3
            case .moderate: 2
            case .weak: 1
            case .unavailable: 0
            }
        }
    }
    enum Agreement: String, Codable, Equatable, Sendable {
        /// The pose strike and the ball interval overlap.
        case agree
        /// The pose's fastest drive came after the ball left; an earlier credible drive overlaps.
        case agreeWithEarlierDrive
        /// No pose strike; the kicking foot was swinging when the ball left.
        case ballWithFootSwing
        /// Pose and ball disagree.
        case conflict
        /// One of the two wasn't available.
        case notApplicable
    }

    /// The pose-only timing heuristic (0–1 scale, not a probability; capped at 0.6).
    var poseTimingScore: Double?
    /// Football tracking reliability, from the departure kind and how often the ball was seen.
    var footballTracking: Level
    var footballFramesWithBallShare: Double?
    var agreement: Agreement
    /// The final contact result's strength: the weaker of `contactEvent` and `timePrecision`.
    var finalContact: Level
    /// Build 18: whether a contact happened where it is placed (basis, agreement, tracking).
    var contactEvent: Level? = nil
    /// Build 18: how narrow the possible-contact interval is (precision, not confidence).
    var timePrecision: Level? = nil
    /// Width of the possible-contact interval (seconds) and ± uncertainty.
    var intervalWidthSeconds: Double?
    var uncertaintySeconds: Double?
    var basis: String

    static let method = "rule-based levels; the pose timing score is a heuristic, not a probability"

    var line: String {
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        return "  contact confidence (\(Self.method)): pose timing score \(n(poseTimingScore)) · football tracking \(footballTracking.rawValue)\(footballFramesWithBallShare.map { String(format: " (ball seen on %.0f%% of examined frames)", $0 * 100) } ?? "") · ball/pose agreement \(agreement.rawValue) · contact event \(contactEvent?.rawValue ?? "—") · time precision \(timePrecision?.rawValue ?? "—") · final contact \(finalContact.rawValue) · interval \(n(intervalWidthSeconds)) s (±\(n(uncertaintySeconds)) s) · basis \(basis)"
    }

    /// Football tracking reliability: rule-based, never a probability.
    static func trackingLevel(_ track: FootballTrack?) -> (Level, Double?) {
        guard let track, let d = track.departure else { return (.unavailable, nil) }
        let seen = track.observations.filter { $0.source == .detected }.count
        let share = track.observations.isEmpty ? nil : ContactEstimator.round3(Double(seen) / Double(track.observations.count))
        switch d.kind {
        case .observedMovingBall: return ((share ?? 0) >= 0.5 ? .strong : .moderate, share)
        case .restSiteVacated: return (.moderate, share)
        case .occludedAtDeparture, .departureUncertain: return (.weak, share)
        }
    }

    /// Build 18: did a contact event happen where it is placed? From the basis, the
    /// agreement of independent evidence and how well the ball was tracked — never from the
    /// interval width alone.
    static func eventLevel(outcome: ContactOutcome?, agreement: Agreement, tracking: Level, poseTimingScore: Double?) -> Level {
        switch outcome {
        case .ballVerifiedContact?, .ballConstrainedContactInterval?:
            switch agreement {
            case .conflict: return .weak
            case .agree:
                switch tracking {
                case .strong: return .strong
                case .moderate, .unavailable: return .moderate
                case .weak: return .weak
                }
            case .agreeWithEarlierDrive: return tracking == .weak ? .weak : .moderate
            case .ballWithFootSwing: return tracking == .strong ? .moderate : .weak
            case .notApplicable: return tracking == .weak ? .weak : .moderate
            }
        case .poseEstimatedContact?: return (poseTimingScore ?? 0) >= 0.45 ? .moderate : .weak
        case .strikeWindowOnly?, .contactUncertain?: return .weak
        case .userSelectedContact?, .contactUnavailable?, nil: return .unavailable
        }
    }

    /// Build 18: how precisely the time is pinned down (the possible-contact interval):
    /// ≤ 2 frames strong, ≤ 0.1 s moderate, wider weak. Precision is NOT confidence.
    static func precisionLevel(width: Double?, uncertainty: Double?, frame: Double) -> Level {
        guard let w = width ?? uncertainty.map({ 2 * $0 }) else { return .unavailable }
        if w <= 2 * frame + 1e-6 { return .strong }
        if w <= 0.1 + 1e-6 { return .moderate }
        return .weak
    }

    /// The final contact level is the weaker of event confidence and timing precision, so a
    /// narrow interval never raises it on its own.
    static func finalLevel(event: Level, precision: Level) -> Level {
        event.rank <= precision.rank ? event : precision
    }

    static func make(phases: KickPhaseDetectionResult, football: FootballTrack?, poseTimingScore: Double?, frame: Double) -> ContactConfidenceBreakdown {
        let e = phases.evidence
        let (tracking, share) = trackingLevel(football)
        let agreement: Agreement = {
            if phases.isUserAssisted { return .notApplicable }
            if let path = e?.ballFusion?.acceptancePath {
                switch path {
                case BallFusionReport.Path.earlierCredibleDrive.rawValue: return .agreeWithEarlierDrive
                case BallFusionReport.Path.kickingFootSwing.rawValue: return .ballWithFootSwing
                default: return .agree
                }
            }
            switch e?.ballEvidence?.outcome {
            case .consistent?: return .agree
            case .conflicting?: return .conflict
            default: return .notApplicable
            }
        }()
        let outcome = e?.contactOutcome ?? ContactOutcome.of(phases)
        let width: Double? = {
            guard let a = e?.contactEarliestTime, let b = e?.contactLatestTime else { return nil }
            return ContactEstimator.round3(b - a)
        }()
        let basis = phases.isUserAssisted ? "user-selected (not automatic)" : (e?.contactTimingMethod ?? "none")
        let event = eventLevel(outcome: outcome, agreement: agreement, tracking: tracking, poseTimingScore: poseTimingScore)
        let precision = precisionLevel(width: width, uncertainty: e?.contactUncertaintySeconds, frame: frame)
        return ContactConfidenceBreakdown(poseTimingScore: poseTimingScore.map(ContactEstimator.round3), footballTracking: tracking,
                                          footballFramesWithBallShare: share, agreement: agreement,
                                          finalContact: finalLevel(event: event, precision: precision),
                                          contactEvent: event, timePrecision: precision,
                                          intervalWidthSeconds: width, uncertaintySeconds: e?.contactUncertaintySeconds, basis: basis)
    }
}
