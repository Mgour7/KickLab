#if canImport(CoreML) && canImport(AVFoundation) && canImport(CoreMedia) && canImport(CoreVideo)
import AVFoundation
import CoreML
import CoreVideo
import Foundation

/// Step 12G (CV rebuild): the two-stage football analysis on the video's real frames.
///
/// 1. Broad scan — every `broadScanInterval` seconds of the whole clip, the full frame
///    goes through the detector. Resting footballs are grouped; the kicked one is chosen
///    (`FootballTrackAnalyzer.selectKickedBall`).
/// 2. Precision pass — every frame around the strike: the detector on a crop around the
///    chosen ball, the ball's appearance (luma crop, `BallMotionTracker`) and a small
///    whole-frame thumbnail for camera motion.
/// The video is decoded twice (once per stage). Everything stays on the device.
struct CoreMLFootballVideoAnalyzer: FootballVideoAnalyzing {
    static let broadScanInterval = 0.2
    /// Precision crop: at least this share of the longer display side, and this many ball sizes.
    static let cropShare = 0.3
    static let cropBallSizes = 14.0
    static let thumbnailHeight = 160

    let bundle: Bundle

    init(bundle: Bundle = .main) {
        self.bundle = bundle
    }

    var isAvailable: Bool { CoreMLFootballDetector.modelURL(in: bundle) != nil }

    func analyze(videoURL: URL, context: FootballAnalysisContext,
                 progress: @escaping @Sendable (Double) -> Void) async throws -> FootballTrack {
        let started = Date()
        let detector: CoreMLFootballDetector
        do {
            detector = try CoreMLFootballDetector.load(bundle: bundle)
        } catch {
            return .unavailable("The football detector model couldn't be loaded (\(error)); contact stays pose-only.")
        }
        let info = try await VideoFrameReader.trackInfo(for: videoURL)
        let quarter = info.orientation == .right || info.orientation == .left
        let displayWidth = quarter ? info.naturalHeight : info.naturalWidth
        let displayHeight = quarter ? info.naturalWidth : info.naturalHeight
        let aspect = context.aspect ?? info.displayAspectRatio ?? displayWidth / max(displayHeight, 1)
        let duration = info.durationSeconds ?? 0

        // Stage 1: broad scan.
        var broad: [FootballDetection] = []
        var scanTimes: [Double] = []
        var nextScan = 0.0
        let full = DisplayRect(x: 0, y: 0, width: displayWidth, height: displayHeight)
        try await VideoFrameReader.read(url: videoURL, plan: FrameSamplingPlan(rate: .everyFrame, timeRange: nil)) { _, time, buffer in
            guard FootballTrackAnalyzer.broadScanIncludes(time: time, nextScheduled: nextScan) else { return }
            nextScan = time + Self.broadScanInterval
            scanTimes.append(time)
            broad += try detector.detect(pixelBuffer: buffer, orientation: info.orientation, isMirrored: info.isMirrored,
                                         region: full, time: time, pass: .broadScan)
            if duration > 0 { progress(min(0.6, 0.6 * time / duration)) }
        }
        try Task.checkCancellation()
        let sites = FootballTrackAnalyzer.sites(broad, aspect: aspect)
        let selection = FootballTrackAnalyzer.selectKickedBall(sites: sites, detections: broad, scanTimes: scanTimes,
                                                               ankle: context.ankle, strike: context.strike, aspect: aspect)
        guard let k = selection.selected else {
            var raw = FootballRawEvidence(scanTimes: scanTimes, broadScan: broad, precisionTimes: nil, precision: nil,
                                          appearanceTimes: [], appearanceScores: [], cameraShiftTimes: [], cameraShiftX: [], cameraShiftY: [],
                                          camera: nil, strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                          ankle: context.ankle, aspect: aspect, duration: duration)
            var track = FootballTrackAnalyzer.analyze(raw: raw, detector: detector.info)
            // Build 22: the detector didn't find the kicked ball — recognize it from the image.
            if track.contactBounds == nil {
                raw.strikeSite = try await Self.strikeSite(videoURL: videoURL, info: info, context: context, aspect: aspect, duration: duration)
                if raw.strikeSite != nil { track = FootballTrackAnalyzer.analyze(raw: raw, detector: detector.info) }
            }
            track.runtimeSeconds = Date().timeIntervalSince(started)
            progress(1)
            return track
        }
        let site = selection.sites[k]

        // Stage 2: precision pass around the strike.
        let window = FootballTrackAnalyzer.precisionWindow(site: site, strike: context.strike, duration: duration)
        let sizePx = site.size * displayHeight
        let side = max(Self.cropBallSizes * sizePx, Self.cropShare * max(displayWidth, displayHeight))
        let crop = DetectorInputBuilder.cropRegion(centerX: site.center.x * displayWidth, centerY: site.center.y * displayHeight,
                                                   side: side, displayWidth: displayWidth, displayHeight: displayHeight)
        let mark = VideoVerification.BallMark(time: window.lowerBound, x: site.center.x, y: site.center.y, radius: site.size / 2)
        var precision: [(time: Double, detections: [FootballDetection])] = []
        var looks: [(time: Double, image: LumaImage)] = []
        var lookRadius = 0.0
        var thumbnails: [(time: Double, image: LumaImage)] = []
        try await VideoFrameReader.read(url: videoURL, plan: FrameSamplingPlan(rate: .everyFrame, timeRange: window)) { _, time, buffer in
            let dets = try detector.detect(pixelBuffer: buffer, orientation: info.orientation, isMirrored: info.isMirrored,
                                           region: crop, time: time, pass: .precision)
            precision.append((time, dets))
            CVPixelBufferLockBaseAddress(buffer, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
            guard let source = YCbCrBufferSource(buffer) else { return }
            if let g = LumaCropGeometry.crop(mark: mark, bufferWidth: source.width, bufferHeight: source.height,
                                             orientation: info.orientation, isMirrored: info.isMirrored, targetRadius: 8) {
                looks.append((time, LumaCropGeometry.downsample({ source.lumaValue(x: $0, y: $1) }, x0: g.cx - g.half, y0: g.cy - g.half,
                                                                size: 2 * g.half, factor: g.factor)))
                lookRadius = g.radius
            }
            if let t = LumaThumbnail.make(storedWidth: source.width, storedHeight: source.height, orientation: info.orientation,
                                          isMirrored: info.isMirrored, targetHeight: Self.thumbnailHeight, luma: { source.lumaValue(x: $0, y: $1) }) {
                thumbnails.append((time, t))
            }
            let span = max(window.upperBound - window.lowerBound, 0.01)
            progress(0.6 + 0.35 * min(1, (time - window.lowerBound) / span))
        }
        try Task.checkCancellation()

        // Appearance: the resting ball's look, from the first precision frame where the
        // detector saw it clearly at rest.
        var appearance: [Double: Double] = [:]
        if let ref = precision.firstIndex(where: { f in
            f.detections.contains { $0.score >= 0.5 && FootballTrackAnalyzer.distance($0.box.center, site.center, aspect: aspect) <= FootballTrackAnalyzer.restMatchSizes * site.size }
        }), let refIndex = looks.firstIndex(where: { abs($0.time - precision[ref].time) < 1e-4 }), lookRadius >= 3 {
            let motion = BallMotionTracker.analyze(looks, referenceIndex: refIndex, ballRadius: lookRadius)
            for (t, s) in zip(motion.times, motion.scores) { appearance[t] = s }
        }
        // Camera motion from the background (athlete and the ball's path excluded).
        let corridor = NormalizedRect(minX: site.center.x - 6 * site.size / aspect, minY: 0,
                                      maxX: site.center.x + 6 * site.size / aspect, maxY: min(1, site.center.y + 3 * site.size))
        let camera = CameraMotionEstimator.track(thumbnails, exclude: { t in [corridor] + [context.kickerBox(at: t)].compactMap { $0 } },
                                                 ballSize: site.size, aspect: aspect)
        // Build 15: everything recorded, then analyzed through the same entry point that
        // evidence replay uses.
        let shiftTimes = camera.shifts.keys.sorted()
        let sortedAppearance = appearance.keys.sorted()
        var raw = FootballRawEvidence(scanTimes: scanTimes, broadScan: broad, precisionTimes: precision.map(\.time),
                                      precision: precision.flatMap(\.detections),
                                      appearanceTimes: sortedAppearance, appearanceScores: sortedAppearance.map { appearance[$0] ?? 0 },
                                      cameraShiftTimes: shiftTimes, cameraShiftX: shiftTimes.map { camera.shifts[$0]?.dx ?? 0 },
                                      cameraShiftY: shiftTimes.map { camera.shifts[$0]?.dy ?? 0 }, camera: camera.summary,
                                      strikeStart: context.strike?.lowerBound, strikeEnd: context.strike?.upperBound,
                                      ankle: context.ankle, aspect: aspect, duration: duration)
        var track = FootballTrackAnalyzer.analyze(raw: raw, detector: detector.info)
        // Build 22: the detector found a ball but couldn't time its departure — recognize the
        // kicked ball from the image instead.
        if track.contactBounds == nil {
            raw.strikeSite = try await Self.strikeSite(videoURL: videoURL, info: info, context: context, aspect: aspect, duration: duration)
            if raw.strikeSite != nil { track = FootballTrackAnalyzer.analyze(raw: raw, detector: detector.info) }
        }
        track.runtimeSeconds = (Date().timeIntervalSince(started) * 100).rounded() / 100
        progress(1)
        return track
    }

    /// Build 22: the strike-site pass — the region around the kicker's feet, every frame up to
    /// 60 a second, from 2 s before the likely strike to 1.6 s after, then
    /// `StrikeSiteBallFinder` (pure; same code in Linux tests and evidence replay).
    static func strikeSite(videoURL: URL, info: VideoTrackInfo, context: FootballAnalysisContext, aspect: Double,
                           duration: Double) async throws -> StrikeSiteBallResult? {
        guard let region = StrikeSiteBallFinder.region(pose: context.strikeSitePose, around: context.strikeSiteTimes, aspect: aspect) else {
            return nil
        }
        let size = StrikeSiteBallFinder.pixelSize(of: region, aspect: aspect)
        let poseTimes = context.strikeSitePose.map(\.time)
        let lo = max(0, (context.strikeSiteTimes.min() ?? poseTimes.min() ?? 0) - 2.0)
        let hi = min(duration > 0 ? duration : .greatestFiniteMagnitude, (context.strikeSiteTimes.max() ?? poseTimes.max() ?? 0) + 1.6)
        guard hi > lo else { return nil }
        var frames: [StrikeSiteFrame] = []
        try await VideoFrameReader.read(url: videoURL, plan: FrameSamplingPlan(rate: .target(framesPerSecond: 60), timeRange: lo...hi)) { _, time, buffer in
            CVPixelBufferLockBaseAddress(buffer, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
            guard let source = YCbCrBufferSource(buffer) else { return }
            if let image = LumaThumbnail.region(storedWidth: source.width, storedHeight: source.height, orientation: info.orientation,
                                                isMirrored: info.isMirrored, region: region, width: size.width, height: size.height,
                                                luma: { source.lumaValue(x: $0, y: $1) }) {
                frames.append(StrikeSiteFrame(time: time, image: image))
            }
        }
        try Task.checkCancellation()
        return StrikeSiteBallFinder.find(frames: frames, region: region, pose: context.strikeSitePose, aspect: aspect)
    }
}
#endif
