#if canImport(CoreML) && canImport(CoreVideo)
import CoreML
import CoreVideo
import Foundation

/// Step 12G (CV rebuild): runs the bundled YOLOX-S Core ML model on one frame region and
/// returns its "sports ball" detections in app-normalized displayed coordinates.
///
/// The model (`YOLOXSportsBall.mlpackage`, compiled by Xcode to `.mlmodelc`) is loaded
/// from the app bundle; when it is missing or fails to load, `load()` throws and the app
/// reports football detection as unavailable instead of guessing.
final class CoreMLFootballDetector: @unchecked Sendable {
    // MLModel predictions are thread-safe; this object has no mutable state.
    let model: MLModel
    let info: FootballDetectorInfo

    enum LoadError: Error, Equatable {
        case modelMissing
    }

    init(model: MLModel, info: FootballDetectorInfo = .yoloxS) {
        self.model = model
        self.info = info
    }

    static func modelURL(in bundle: Bundle = .main) -> URL? {
        bundle.url(forResource: FootballDetectorInfo.resourceName, withExtension: "mlmodelc")
    }

    static func load(bundle: Bundle = .main, computeUnits: MLComputeUnits = .all) throws -> CoreMLFootballDetector {
        guard let url = modelURL(in: bundle) else { throw LoadError.modelMissing }
        let configuration = MLModelConfiguration()
        configuration.computeUnits = computeUnits
        return CoreMLFootballDetector(model: try MLModel(contentsOf: url, configuration: configuration))
    }

    /// Runs the model on a prepared input (planar B, G, R, 0…255; `DetectorInputBuilder`).
    func predict(_ input: [Float]) throws -> [ModelBox] {
        let n = info.inputSize
        precondition(input.count == 3 * n * n, "input must be 3 × \(n) × \(n)")
        let array = try MLMultiArray(shape: [1, 3, NSNumber(value: n), NSNumber(value: n)], dataType: .float32)
        let pointer = array.dataPointer.bindMemory(to: Float.self, capacity: input.count)
        // A fresh MLMultiArray of this shape is contiguous, but follow its strides anyway.
        let strides = array.strides.map(\.intValue)
        if strides == [3 * n * n, n * n, n, 1] {
            input.withUnsafeBufferPointer { pointer.update(from: $0.baseAddress!, count: input.count) }
        } else {
            for c in 0..<3 { for y in 0..<n { for x in 0..<n {
                pointer[c * strides[1] + y * strides[2] + x * strides[3]] = input[c * n * n + y * n + x]
            } } }
        }
        let features = try MLDictionaryFeatureProvider(dictionary: [FootballDetectorInfo.inputName: MLFeatureValue(multiArray: array)])
        let result = try model.prediction(from: features)
        guard let output = result.featureValue(for: FootballDetectorInfo.outputName)?.multiArrayValue else { return [] }
        return Self.decode(output, inputSize: n, classIndex: info.classIndex)
    }

    /// Decodes a [1, anchors, 85] output of any float type and memory layout.
    static func decode(_ output: MLMultiArray, inputSize: Int, classIndex: Int) -> [ModelBox] {
        let shape = output.shape.map(\.intValue), strides = output.strides.map(\.intValue)
        guard shape.count == 3, shape[1] == YOLOXDecoder.anchorCount(inputSize: inputSize), shape[2] >= 5 + classIndex + 1 else { return [] }
        switch output.dataType {
        case .float32:
            let p = output.dataPointer.bindMemory(to: Float.self, capacity: output.count)
            return YOLOXDecoder.decode(inputSize: inputSize, classIndex: classIndex) { a, c in p[a * strides[1] + c * strides[2]] }
        case .double:
            let p = output.dataPointer.bindMemory(to: Double.self, capacity: output.count)
            return YOLOXDecoder.decode(inputSize: inputSize, classIndex: classIndex) { a, c in Float(p[a * strides[1] + c * strides[2]]) }
        default:
            // Float16 and anything else: through NSNumber (slower, but exact).
            return YOLOXDecoder.decode(inputSize: inputSize, classIndex: classIndex) { a, c in
                output[[0, NSNumber(value: a), NSNumber(value: c)]].floatValue
            }
        }
    }

    /// Detects footballs in `region` of a decoded video frame (8-bit 4:2:0 full-range).
    func detect(pixelBuffer: CVPixelBuffer, orientation: VideoOrientation, isMirrored: Bool, region: DisplayRect,
                time: Double, pass: FootballDetection.Pass) throws -> [FootballDetection] {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }
        guard let source = YCbCrBufferSource(pixelBuffer) else { return [] }
        let quarter = orientation == .right || orientation == .left
        let dw = Double(quarter ? source.height : source.width), dh = Double(quarter ? source.width : source.height)
        let prepared = DetectorInputBuilder.makeInput(source: source, orientation: orientation, isMirrored: isMirrored,
                                                      region: region, inputSize: info.inputSize)
        let boxes = try predict(prepared.input)
        return YOLOXDecoder.displayBoxes(boxes, geometry: prepared.geometry, displayWidth: dw, displayHeight: dh)
            .map { FootballDetection(time: time, box: $0.box, score: ($0.score * 10_000).rounded() / 10_000, pass: pass) }
    }
}

/// Reads B, G, R from a LOCKED bi-planar 4:2:0 full-range pixel buffer.
struct YCbCrBufferSource: BGRPixelSource {
    let width: Int
    let height: Int
    private let luma: UnsafePointer<UInt8>
    private let lumaStride: Int
    private let chroma: UnsafePointer<UInt8>
    private let chromaStride: Int

    /// The buffer must stay locked while this source is used.
    init?(_ buffer: CVPixelBuffer) {
        guard CVPixelBufferGetPlaneCount(buffer) >= 2,
              let y = CVPixelBufferGetBaseAddressOfPlane(buffer, 0),
              let c = CVPixelBufferGetBaseAddressOfPlane(buffer, 1) else { return nil }
        width = CVPixelBufferGetWidthOfPlane(buffer, 0)
        height = CVPixelBufferGetHeightOfPlane(buffer, 0)
        luma = UnsafePointer(y.assumingMemoryBound(to: UInt8.self))
        lumaStride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 0)
        chroma = UnsafePointer(c.assumingMemoryBound(to: UInt8.self))
        chromaStride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 1)
    }

    func lumaValue(x: Int, y: Int) -> UInt8 { luma[y * lumaStride + x] }

    func bgr(x: Int, y: Int) -> (b: Float, g: Float, r: Float) {
        let ci = (y / 2) * chromaStride + (x / 2) * 2
        return YCbCrConversion.bgr(y: luma[y * lumaStride + x], cb: chroma[ci], cr: chroma[ci + 1])
    }
}
#endif
