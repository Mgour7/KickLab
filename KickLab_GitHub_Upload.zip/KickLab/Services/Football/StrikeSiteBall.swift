import Foundation

// Build 22 (Ball recognition without a football detector).
//
// The bundled detector (COCO "sports ball") often cannot see an American football on a
// kicking holder: on the real IMG_4541 practice clips it scored the kicked ball 0.06 (end-on,
// backlit, black and white panels) and on the Kicker AI reel 0.08 — below every threshold —
// so contact could not be verified from the ball.
//
// This finder recognizes the kicked ball by what it DOES rather than what it looks like: a
// small object that sits still next to the kicker's feet and is gone the moment a fast
// foot reaches it. Body pose gives the rough time and place; the pixels give the rest:
//
// 1. For a candidate strike time, a region around the feet is compared before
//    (1.3–0.45 s earlier) and after (0.45–1.2 s later), using per-pixel medians so a
//    passing leg doesn't count. A compact, ball-sized blob that is stable in both windows,
//    different between them, and not covered by the kicker most of the time is the ball's
//    resting spot.
// 2. Every frame is then compared with the resting ball's pixels: contact lies after the
//    LAST frame that still shows the resting ball and no later than the next frame.
// 3. Candidate strike times come from the kicking-foot speed AND a sweep of the whole clip,
//    and each answer is re-centred on the departure the image itself showed; only answers
//    whose departure matches their window, whose ball was visible beforehand, and where an
//    ankle moved fast right next to the ball when it left are kept — so a ball picked up by
//    hand or a kicker walking away is not a kick.
//
// The answer is automatic ball evidence (labelled `strikeSiteChange`), never a user mark.
// Thresholds are provisional, chosen on the IMG_4541 / IMG_6269 session and the Kicker AI
// reel (9 kicks found, 0 false kicks in 8 non-kick clips) — no held-out set yet. See
// Docs/BALL_RECOGNITION_BUILD22.md.

/// The kicker's pose at one analyzed frame, in app-normalized displayed coordinates.
struct StrikeSitePoseSample: Codable, Equatable, Sendable {
    var time: Double
    var kickingAnkle: NormalizedPoint?
    var plantAnkle: NormalizedPoint?
    /// Bounding box of the kicker's visible joints.
    var body: NormalizedRect?
    /// Shoulder-midpoint to hip-midpoint distance, in displayed-HEIGHT units (x scaled by the aspect).
    var torso: Double?
}

/// One frame of the examined region (luma, square pixels).
struct StrikeSiteFrame: Sendable {
    var time: Double
    var image: LumaImage
}

/// The kicked ball found from image change, and when it left.
struct StrikeSiteBallResult: Codable, Equatable, Sendable {
    static let basis = "strikeSiteChange"
    var version: String = StrikeSiteBallFinder.version
    /// The resting ball's center and box size (app-normalized displayed coordinates).
    var center: NormalizedPoint
    var width: Double
    var height: Double
    /// Last frame that still shows the resting ball (contact can already be under way).
    var lastPresentTime: Double
    /// The next frame: the ball's spot no longer shows the resting ball.
    var firstGoneTime: Double
    /// First frame from which the spot shows the empty background for 3 frames (nil if never).
    var firstClearTime: Double?
    /// Fastest ankle speed within 0.2 s of the departure (torso lengths / s) and that ankle's
    /// closest distance to the ball then (torso lengths).
    var swingAtDeparture: Double
    var footDistanceAtDeparture: Double
    /// Share of the 0.8 s before the last resting frame on which the ball was clearly visible.
    var presentFraction: Double
    var score: Double
    var framesExamined: Int
    /// The region that was examined.
    var region: NormalizedRect

    /// Ball size in displayed-height units.
    func size(aspect: Double) -> Double { (max(0, width * aspect) * max(0, height)).squareRoot() }
}

enum StrikeSiteBallFinder {
    static let version = "strike-site-1"
    // Windows around a candidate strike time (seconds).
    static let beforeStart = 1.3, beforeEnd = 0.45, afterStart = 0.45, afterEnd = 1.2
    /// Frames used per window at most (evenly spread).
    static let maximumWindowFrames = 24
    // Change map.
    static let minimumDifference = 12.0
    static let noiseFactor = 4.0
    static let stabilityFloor = 6.0
    /// Frames on which the kicker's box (padded by this many torso lengths) covers a pixel
    /// are left out of that pixel's medians.
    static let kickerPadTorso = 0.35
    /// A resting ball (alone or on a holder) is not a thin line: longer side ÷ shorter side.
    static let maximumBlobElongation = 3.5
    // Blob shape, in torso lengths.
    static let minimumBlobSize = 0.12, maximumBlobSize = 1.2
    static let maximumBlobExtent = 1.6, minimumBlobExtent = 0.08
    /// The blob's longer side, in torso lengths. A football is about 0.3–0.6 torso lengths
    /// across; on the Build 22 clips the smallest real ball (the reel, partly behind the
    /// holder's hand) measured 0.19, and a walking shoe that passed every other test 0.11.
    static let minimumBlobLongSide = 0.15
    /// Search region around the feet, in torso lengths.
    static let searchRadiusTorso = 2.5
    // Per-frame presence: distance to the resting look below this share of the
    // resting-vs-empty difference.
    static let presentShare = 0.35
    // Consistency and the kick gate.
    static let minimumPresentFraction = 0.5
    /// An ankle must move at least this fast (torso lengths/s) within 0.2 s of the departure…
    static let minimumSwingSpeed = 10.0
    /// …and come this close to the ball (torso lengths).
    static let maximumFootDistance = 1.0
    static let sweepStep = 0.2
    /// Region resolution: the longer side, in pixels.
    static let regionLongSide = 480

    // MARK: Region

    /// The region to sample: around both ankles during the likely strike (`around` times;
    /// the whole clip when empty), padded by the search radius, at most 9 torso lengths wide.
    static func region(pose: [StrikeSitePoseSample], around times: [Double], aspect: Double) -> NormalizedRect? {
        let torso = median(pose.compactMap(\.torso))
        guard torso > 0 else { return nil }
        let picked = pose.filter { s in times.isEmpty || times.contains { abs($0 - s.time) <= 1.0 } }
        let feet = picked.flatMap { [$0.kickingAnkle, $0.plantAnkle].compactMap { $0 } }
        guard !feet.isEmpty else { return nil }
        let xs = feet.map(\.x).sorted(), ys = feet.map(\.y).sorted()
        func pct(_ v: [Double], _ p: Double) -> Double { v[min(v.count - 1, max(0, Int(Double(v.count - 1) * p)))] }
        let padX = (searchRadiusTorso + 0.5) * torso / max(aspect, 1e-6), padY = (searchRadiusTorso + 0.5) * torso
        var minX = pct(xs, 0.1) - padX, maxX = pct(xs, 0.9) + padX
        var minY = pct(ys, 0.1) - padY * 1.2, maxY = pct(ys, 0.9) + padY * 0.6
        // Cap the width (and height) at 9 torso lengths around the median foot.
        let capX = 9 * torso / max(aspect, 1e-6), capY = 7 * torso
        if maxX - minX > capX { let c = median(xs); minX = c - capX / 2; maxX = c + capX / 2 }
        if maxY - minY > capY { let c = median(ys); minY = c - capY * 0.6; maxY = c + capY * 0.4 }
        let r = NormalizedRect(minX: max(0, minX), minY: max(0, minY), maxX: min(1, maxX), maxY: min(1, maxY))
        return r.width > 0.01 && r.height > 0.01 ? r : nil
    }

    /// Pixel size of the region image (square pixels, longer side `regionLongSide`).
    static func pixelSize(of region: NormalizedRect, aspect: Double) -> (width: Int, height: Int) {
        let w = region.width * aspect, h = region.height
        if w >= h { return (regionLongSide, max(8, Int((Double(regionLongSide) * h / w).rounded()))) }
        return (max(8, Int((Double(regionLongSide) * w / h).rounded())), regionLongSide)
    }

    // MARK: Find

    static func find(frames input: [StrikeSiteFrame], region: NormalizedRect, pose: [StrikeSitePoseSample],
                     aspect: Double, stabilize: Bool = true) -> StrikeSiteBallResult? {
        findWithReport(frames: input, region: region, pose: pose, aspect: aspect, stabilize: stabilize).result
    }

    /// Build 22: the same search, plus one plain sentence on what it found or why nothing
    /// passed (shown in the analysis diagnostics, so a device run explains itself).
    static func findWithReport(frames input: [StrikeSiteFrame], region: NormalizedRect, pose: [StrikeSitePoseSample],
                               aspect: Double, stabilize: Bool = true) -> (result: StrikeSiteBallResult?, report: String) {
        guard input.count >= 10, let first = input.first else { return (nil, "only \(input.count) frames were decoded (10 needed)") }
        let W = first.image.width, H = first.image.height
        guard W >= 8, H >= 8, input.allSatisfy({ $0.image.width == W && $0.image.height == H }) else { return (nil, "the decoded frames had no usable size") }
        let frames = input.sorted { $0.time < $1.time }
        let geo = Geometry(region: region, width: W, height: H)
        let poseSorted = pose.sorted { $0.time < $1.time }
        let torsoPx = median(poseSorted.compactMap(\.torso)) * geo.pxPerHeight
        guard torsoPx >= 4 else { return (nil, "the kicker's torso wasn't measured (no scale)") }
        let stabilized = stabilize ? Stabilizer.stabilize(frames, pose: poseSorted, geo: geo, torsoPx: torsoPx) : frames
        var work = Work(frames: stabilized, times: stabilized.map(\.time), W: W, H: H, geo: geo, pose: poseSorted, torsoPx: torsoPx)

        // Candidate strike times: kicking-foot speed peaks, then a sweep.
        var candidates: [Double] = []
        let speeds = work.ankleSpeeds(\.kickingAnkle)
        for (t, _) in speeds.sorted(by: { $0.1 > $1.1 }) where candidates.count < 5 {
            if candidates.allSatisfy({ abs($0 - t) > 0.4 }) { candidates.append(t) }
        }
        let times = work.times
        // The sweep only visits times near a fast foot (either ankle): the gate below needs
        // one at the departure anyway, and it keeps the search short.
        let fast = (speeds + work.ankleSpeeds(\.plantAnkle)).filter { $0.1 >= 0.5 * minimumSwingSpeed }.map(\.0)
        var t = times[0] + 0.9
        while t < times[times.count - 1] - 0.45 {
            if candidates.allSatisfy({ abs($0 - t) > 0.1 }), fast.contains(where: { abs($0 - t) <= 0.6 }) { candidates.append(t) }
            t += sweepStep
        }
        var results: [Analysis] = []
        for c in candidates {
            guard var r = work.analyze(at: c) else { continue }
            results.append(r)
            // Re-centre on the departure the image showed; every step is kept (a re-centred
            // window can pick up a different object, which must not replace the first answer).
            for _ in 0..<2 {
                guard abs(r.firstGone - r.ts) > 0.05, let next = work.analyze(at: r.firstGone) else { break }
                r = next
                results.append(r)
            }
        }
        // The departure must fall in the gap between the analysis' before and after windows
        // (otherwise the "before" or "after" picture would include it).
        let consistent = results.filter {
            $0.firstGone > $0.ts - beforeEnd + 1e-9 && $0.firstGone < $0.ts + afterStart - 1e-9 && $0.presentFraction >= minimumPresentFraction
        }
        let gated = consistent.map { work.gate($0) }
        let kicks = gated.filter { $0.swing >= minimumSwingSpeed && $0.footDistance <= maximumFootDistance }
        let head = "\(frames.count) frames, \(candidates.count) candidate strike times, \(results.count) ball-sized changes, \(consistent.count) clean departures"
        guard let best = kicks.max(by: { $0.analysis.score < $1.analysis.score }) else {
            guard let near = gated.max(by: { $0.analysis.score < $1.analysis.score }) else {
                return (nil, head + "; no departure to check against the foot")
            }
            return (nil, head + String(format: "; none passed the kick check (best: gone at %.3f s, fastest foot %.1f torso lengths/s — %.0f needed — %.2f torso lengths from the ball — %.1f allowed)",
                                       near.analysis.firstGone, near.swing, minimumSwingSpeed, near.footDistance, maximumFootDistance))
        }
        let a = best.analysis
        let c = geo.normalized(x: a.cx, y: a.cy)
        let result = StrikeSiteBallResult(
            center: NormalizedPoint(x: round4(c.x), y: round4(c.y)),
            width: round4(Double(a.w) / geo.pxPerWidth), height: round4(Double(a.h) / geo.pxPerHeight),
            lastPresentTime: a.lastPresent, firstGoneTime: a.firstGone, firstClearTime: a.firstClear,
            swingAtDeparture: round3(best.swing), footDistanceAtDeparture: round3(best.footDistance),
            presentFraction: round3(a.presentFraction), score: round3(a.score), framesExamined: frames.count, region: region)
        return (result, head + String(format: "; ball left at %.3f s with the foot at %.1f torso lengths/s", a.firstGone, best.swing))
    }

    // MARK: - Internals

    struct Geometry {
        var region: NormalizedRect
        var width: Int, height: Int
        var pxPerWidth: Double { Double(width) / max(region.width, 1e-9) }
        var pxPerHeight: Double { Double(height) / max(region.height, 1e-9) }
        func px(_ p: NormalizedPoint) -> (x: Double, y: Double) {
            ((p.x - region.minX) * pxPerWidth, (p.y - region.minY) * pxPerHeight)
        }
        func normalized(x: Double, y: Double) -> NormalizedPoint {
            NormalizedPoint(x: region.minX + x / pxPerWidth, y: region.minY + y / pxPerHeight)
        }
    }

    struct Analysis {
        var ts: Double
        var cx: Double, cy: Double
        var w: Int, h: Int
        var score: Double
        var lastPresent: Double
        var firstGone: Double
        var firstClear: Double?
        var presentFraction: Double
    }

    struct Work {
        var frames: [StrikeSiteFrame]
        var times: [Double]
        var W: Int, H: Int
        var geo: Geometry
        var pose: [StrikeSitePoseSample]
        var torsoPx: Double
        var cache: [Int: Analysis?] = [:]

        func nearestPose(_ t: Double) -> StrikeSitePoseSample? {
            guard let p = pose.min(by: { abs($0.time - t) < abs($1.time - t) }), abs(p.time - t) <= 0.1 else { return nil }
            return p
        }

        /// Ankle speed (torso lengths/s) between consecutive pose samples, median-filtered.
        func ankleSpeeds(_ key: KeyPath<StrikeSitePoseSample, NormalizedPoint?>) -> [(Double, Double)] {
            var raw: [(Double, Double?)] = []
            for i in pose.indices {
                guard i > 0, let a = pose[i - 1][keyPath: key], let b = pose[i][keyPath: key], pose[i].time > pose[i - 1].time else {
                    raw.append((pose[i].time, nil)); continue
                }
                let pa = geo.px(a), pb = geo.px(b)
                raw.append((pose[i].time, hypot(pb.x - pa.x, pb.y - pa.y) / (pose[i].time - pose[i - 1].time) / torsoPx))
            }
            return raw.indices.compactMap { i in
                let w = raw[max(0, i - 2)...min(raw.count - 1, i + 2)].compactMap(\.1).sorted()
                guard raw[i].1 != nil, !w.isEmpty else { return nil }
                return (raw[i].0, w[w.count / 2])
            }
        }

        mutating func analyze(at ts: Double) -> Analysis? {
            // Cache per nearest frame.
            guard let k = times.indices.min(by: { abs(times[$0] - ts) < abs(times[$1] - ts) }) else { return nil }
            if let hit = cache[k] { return hit }
            let r = compute(at: times[k])
            cache[k] = r
            return r
        }

        func compute(at ts: Double) -> Analysis? {
            // Feet around the strike → the search box.
            var fxs: [Double] = [], fys: [Double] = []
            for s in pose where abs(s.time - ts) <= 0.6 {
                for p in [s.kickingAnkle, s.plantAnkle].compactMap({ $0 }) {
                    let q = geo.px(p); fxs.append(q.x); fys.append(q.y)
                }
            }
            guard !fxs.isEmpty else { return nil }
            // The kicker's size around this moment (the clip-wide median can be much smaller
            // when the kicker walks away from the camera later in the clip).
            let near = pose.filter { abs($0.time - ts) <= 0.6 }.compactMap(\.torso)
            let localTorsoPx = near.isEmpty ? torsoPx : max(torsoPx, StrikeSiteBallFinder.median(near) * geo.pxPerHeight)
            let fx = StrikeSiteBallFinder.median(fxs)
            let fy = StrikeSiteBallFinder.percentile(fys, 0.75)
            let R = searchRadiusTorso * torsoPx
            let x0 = max(0, Int(fx - R)), x1 = min(W, Int(fx + R))
            let y0 = max(0, Int(fy - 1.2 * R)), y1 = min(H, Int(fy + 0.6 * R))
            guard x1 - x0 >= 8, y1 - y0 >= 8 else { return nil }
            let bw = x1 - x0, bh = y1 - y0
            let before = indices(ts - beforeStart, ts - beforeEnd), after = indices(ts + afterStart, ts + afterEnd)
            guard before.count >= 3, after.count >= 3 else { return nil }

            // Per-pixel median and spread over the window's frames on which the kicker
            // (box padded by `kickerPadTorso`) does NOT cover that pixel: a passing or
            // standing kicker never becomes part of the resting scene.
            func boxes(_ idx: [Int]) -> [(Int, Int, Int, Int)?] {
                idx.map { i in
                    guard let body = nearestPose(times[i])?.body else { return nil }
                    let p0 = geo.px(NormalizedPoint(x: body.minX, y: body.minY)), p1 = geo.px(NormalizedPoint(x: body.maxX, y: body.maxY))
                    let pad = kickerPadTorso * torsoPx
                    return (Int(p0.x - pad) - x0, Int(p0.y - pad) - y0, Int(p1.x + pad) - x0, Int(p1.y + pad) - y0)
                }
            }
            func medians(_ idx: [Int]) -> (med: [Double], mad: [Double], valid: [Bool]) {
                var med = [Double](repeating: 0, count: bw * bh), mad = med
                var valid = [Bool](repeating: false, count: bw * bh)
                let bx = boxes(idx)
                var buf: [UInt8] = []
                buf.reserveCapacity(idx.count)
                var dev: [Double] = []
                dev.reserveCapacity(idx.count)
                for y in 0..<bh {
                    for x in 0..<bw {
                        buf.removeAll(keepingCapacity: true)
                        for (j, i) in idx.enumerated() {
                            if let b = bx[j], x >= b.0, x <= b.2, y >= b.1, y <= b.3 { continue }
                            buf.append(frames[i].image.pixels[(y + y0) * W + x + x0])
                        }
                        guard buf.count >= max(3, idx.count / 3) else { continue }
                        let m = medianU8(buf)
                        dev.removeAll(keepingCapacity: true)
                        for v in buf { dev.append(abs(Double(v) - m)) }
                        med[y * bw + x] = m
                        mad[y * bw + x] = StrikeSiteBallFinder.median(dev)
                        valid[y * bw + x] = true
                    }
                }
                return (med, mad, valid)
            }
            let b = medians(before), a = medians(after)
            var D = [Double](repeating: 0, count: bw * bh)
            let both = D.indices.filter { b.valid[$0] && a.valid[$0] }
            guard both.count >= 64 else { return nil }
            for i in both { D[i] = abs(b.med[i] - a.med[i]) }
            let noise = StrikeSiteBallFinder.median(both.map { D[$0] }) + 1e-3
            let stab = max(stabilityFloor, 2 * StrikeSiteBallFinder.median(both.map { b.mad[$0] }))
            let stabAfter = max(stab, 2 * StrikeSiteBallFinder.median(both.map { a.mad[$0] }))
            let threshold = max(minimumDifference, noiseFactor * noise, 2 * stab)
            var mask = [Bool](repeating: false, count: bw * bh)
            for i in mask.indices {
                mask[i] = b.valid[i] && a.valid[i] && D[i] > threshold && b.mad[i] < stab && a.mad[i] < stabAfter
            }
            mask = Morphology.close(Morphology.open(mask, bw, bh, 1), bw, bh, 2)
            let blobs = Morphology.components(mask, bw, bh)
            var best: (score: Double, pixels: [Int], cx: Double, cy: Double, w: Int, h: Int)?
            for blob in blobs {
                let area = Double(blob.count)
                let xs = blob.map { $0 % bw }, ys = blob.map { $0 / bw }
                let w = (xs.max() ?? 0) - (xs.min() ?? 0) + 1, h = (ys.max() ?? 0) - (ys.min() ?? 0) + 1
                let size = area.squareRoot()
                guard size >= minimumBlobSize * torsoPx, size <= maximumBlobSize * torsoPx,
                      Double(max(w, h)) <= maximumBlobExtent * torsoPx, Double(min(w, h)) >= minimumBlobExtent * torsoPx,
                      Double(max(w, h)) >= minimumBlobLongSide * localTorsoPx,
                      Double(max(w, h)) <= maximumBlobElongation * Double(min(w, h)) else { continue }
                let fill = area / Double(w * h)
                let cx = Double(xs.reduce(0, +)) / area + Double(x0), cy = Double(ys.reduce(0, +)) / area + Double(y0)
                let dist = hypot(cx - fx, cy - fy) / torsoPx
                let meanD = blob.map { D[$0] }.reduce(0, +) / area
                let score = meanD * fill / (1 + dist)
                if best == nil || score > best!.score { best = (score, blob, cx, cy, w, h) }
            }
            guard let ball = best else { return nil }
            // Presence of the resting ball on every frame.
            let bvals = ball.pixels.map { b.med[$0] }, avals = ball.pixels.map { a.med[$0] }
            let coords = ball.pixels.map { ($0 % bw + x0, $0 / bw + y0) }
            let sep = zip(bvals, avals).map { abs($0 - $1) }.reduce(0, +) / Double(bvals.count)
            guard sep > 0 else { return nil }
            var present = [Bool](repeating: false, count: frames.count), clear = present
            for i in frames.indices {
                var db = 0.0, da = 0.0
                for (j, c) in coords.enumerated() {
                    let v = Double(frames[i].image.pixels[c.1 * W + c.0])
                    db += abs(v - bvals[j]); da += abs(v - avals[j])
                }
                db /= Double(coords.count); da /= Double(coords.count)
                present[i] = db < presentShare * sep
                clear[i] = da < presentShare * sep
            }
            guard let lp = frames.indices.last(where: { present[$0] && times[$0] >= ts - 1.5 && times[$0] <= ts + 0.5 }), lp + 1 < frames.count else { return nil }
            let fc = ((lp + 1)..<frames.count).first { i in (i..<min(frames.count, i + 3)).allSatisfy { clear[$0] } }
            let pre = frames.indices.filter { times[$0] >= times[lp] - 0.8 && times[$0] <= times[lp] }
            let fraction = pre.isEmpty ? 0 : Double(pre.filter { present[$0] }.count) / Double(pre.count)
            return Analysis(ts: ts, cx: ball.cx, cy: ball.cy, w: ball.w, h: ball.h, score: ball.score,
                            lastPresent: times[lp], firstGone: times[lp + 1], firstClear: fc.map { times[$0] }, presentFraction: fraction)
        }

        func indices(_ from: Double, _ to: Double) -> [Int] {
            let all = times.indices.filter { times[$0] >= from - 1e-9 && times[$0] <= to + 1e-9 }
            guard all.count > maximumWindowFrames else { return all }
            return (0..<maximumWindowFrames).map { all[$0 * all.count / maximumWindowFrames] }
        }

        /// The kick gate. The ankle that swings fastest within 0.2 s of the departure is the
        /// striking foot; it must be fast and come close to the ball. `approachConsistent`
        /// (that foot closest to the ball while the ball leaves) is reported for diagnostics
        /// only: on the real IMG_4541 clips the ankle labels near contact were too unstable
        /// to require it.
        func gate(_ a: Analysis) -> (analysis: Analysis, swing: Double, footDistance: Double, approachConsistent: Bool) {
            var best: (swing: Double, dist: Double, closest: Double?)?
            for key in [\StrikeSitePoseSample.kickingAnkle, \StrikeSitePoseSample.plantAnkle] {
                var swing = 0.0, dist = Double.infinity, closestTime: Double?, closestDist = Double.infinity
                var prev: (Double, (x: Double, y: Double))?
                for s in pose {
                    guard let p = s[keyPath: key] else { prev = nil; continue }
                    let q = geo.px(p)
                    let d = hypot(q.x - a.cx, q.y - a.cy) / torsoPx
                    if abs(s.time - a.firstGone) <= 0.2 {
                        if let (t0, q0) = prev, s.time > t0 {
                            swing = max(swing, hypot(q.x - q0.x, q.y - q0.y) / (s.time - t0) / torsoPx)
                        }
                        dist = min(dist, d)
                    }
                    if abs(s.time - a.firstGone) <= 0.4, d < closestDist { closestDist = d; closestTime = s.time }
                    prev = (s.time, q)
                }
                if best == nil || swing > best!.swing { best = (swing, dist, closestTime) }
            }
            guard let g = best else { return (a, 0, .infinity, false) }
            let frame = times.count > 1 ? (times[times.count - 1] - times[0]) / Double(times.count - 1) : 1.0 / 30
            let end = a.firstClear ?? a.firstGone
            let consistent = g.closest.map { $0 >= a.lastPresent - 2 * frame - 1e-6 && $0 <= end + 2 * frame + 1e-6 } ?? false
            return (a, g.swing, g.dist, consistent)
        }
    }

    /// Undoes small camera movements (translation) relative to the first frame, measured on
    /// the region's background (the kicker's box excluded). A shift is used only when it
    /// matches clearly better than no shift.
    enum Stabilizer {
        static let radius = 12
        static let sampleStride = 4

        static func stabilize(_ frames: [StrikeSiteFrame], pose: [StrikeSitePoseSample], geo: Geometry, torsoPx: Double) -> [StrikeSiteFrame] {
            guard let ref = frames.first else { return frames }
            let W = ref.image.width, H = ref.image.height
            func box(_ t: Double) -> (Int, Int, Int, Int)? {
                guard let p = pose.min(by: { abs($0.time - t) < abs($1.time - t) }), abs(p.time - t) <= 0.1, let b = p.body else { return nil }
                let a = geo.px(NormalizedPoint(x: b.minX, y: b.minY)), c = geo.px(NormalizedPoint(x: b.maxX, y: b.maxY))
                let pad = 0.5 * torsoPx
                return (Int(a.x - pad), Int(a.y - pad), Int(c.x + pad), Int(c.y + pad))
            }
            // Sample grid inside the search margin.
            var grid: [(Int, Int)] = []
            var y = radius
            while y < H - radius {
                var x = radius
                while x < W - radius { grid.append((x, y)); x += sampleStride }
                y += sampleStride
            }
            let refBox = box(ref.time)
            func shift(of f: StrikeSiteFrame) -> (Int, Int) {
                let boxes = [refBox, box(f.time)].compactMap { $0 }
                let samples = grid.filter { g in !boxes.contains { g.0 >= $0.0 && g.0 <= $0.2 && g.1 >= $0.1 && g.1 <= $0.3 } }
                guard samples.count >= 50 else { return (0, 0) }
                let r = ref.image.pixels, p = f.image.pixels
                func cost(_ dx: Int, _ dy: Int) -> Int {
                    var sum = 0
                    for (x, y) in samples { sum += abs(Int(r[y * W + x]) - Int(p[(y + dy) * W + x + dx])) }
                    return sum
                }
                let zero = cost(0, 0)
                var best = (0, 0, zero)
                for dy in stride(from: -radius, through: radius, by: 3) {
                    for dx in stride(from: -radius, through: radius, by: 3) where dx != 0 || dy != 0 {
                        let c = cost(dx, dy)
                        if c < best.2 { best = (dx, dy, c) }
                    }
                }
                let (cx, cy) = (best.0, best.1)
                for dy in (cy - 2)...(cy + 2) where abs(dy) <= radius {
                    for dx in (cx - 2)...(cx + 2) where abs(dx) <= radius {
                        let c = cost(dx, dy)
                        if c < best.2 { best = (dx, dy, c) }
                    }
                }
                // Only a clearly better match counts as camera movement.
                return Double(best.2) < 0.9 * Double(zero) ? (best.0, best.1) : (0, 0)
            }
            // A steady camera (no probe frame shifted by more than a pixel) is left as it is.
            let probes = stride(from: 0, to: frames.count, by: max(1, frames.count / 12)).map { shift(of: frames[$0]) }
            guard probes.contains(where: { abs($0.0) > 1 || abs($0.1) > 1 }) else { return frames }
            return frames.map { f in
                let (dx, dy) = shift(of: f)
                guard dx != 0 || dy != 0 else { return f }
                var px = [UInt8](repeating: 0, count: W * H)
                let src = f.image.pixels
                for y in 0..<H {
                    let sy = min(H - 1, max(0, y + dy))
                    for x in 0..<W { px[y * W + x] = src[sy * W + min(W - 1, max(0, x + dx))] }
                }
                return StrikeSiteFrame(time: f.time, image: LumaImage(width: W, height: H, pixels: px))
            }
        }
    }

    /// Binary morphology with a 3×3 cross, and 4-connected components.
    enum Morphology {
        static func erode(_ m: [Bool], _ w: Int, _ h: Int) -> [Bool] {
            var out = [Bool](repeating: false, count: m.count)
            for y in 0..<h { for x in 0..<w {
                let i = y * w + x
                guard m[i] else { continue }
                out[i] = (x == 0 || m[i - 1]) && (x == w - 1 || m[i + 1]) && (y == 0 || m[i - w]) && (y == h - 1 || m[i + w])
            } }
            return out
        }
        static func dilate(_ m: [Bool], _ w: Int, _ h: Int) -> [Bool] {
            var out = m
            for y in 0..<h { for x in 0..<w where m[y * w + x] {
                if x > 0 { out[y * w + x - 1] = true }
                if x < w - 1 { out[y * w + x + 1] = true }
                if y > 0 { out[(y - 1) * w + x] = true }
                if y < h - 1 { out[(y + 1) * w + x] = true }
            } }
            return out
        }
        static func open(_ m: [Bool], _ w: Int, _ h: Int, _ n: Int) -> [Bool] {
            var r = m
            for _ in 0..<n { r = erode(r, w, h) }
            for _ in 0..<n { r = dilate(r, w, h) }
            return r
        }
        static func close(_ m: [Bool], _ w: Int, _ h: Int, _ n: Int) -> [Bool] {
            var r = m
            for _ in 0..<n { r = dilate(r, w, h) }
            for _ in 0..<n { r = erode(r, w, h) }
            return r
        }
        static func components(_ m: [Bool], _ w: Int, _ h: Int) -> [[Int]] {
            var seen = [Bool](repeating: false, count: m.count)
            var out: [[Int]] = []
            for start in m.indices where m[start] && !seen[start] {
                var stack = [start], blob: [Int] = []
                seen[start] = true
                while let i = stack.popLast() {
                    blob.append(i)
                    let x = i % w, y = i / w
                    for (nx, ny) in [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)] where nx >= 0 && nx < w && ny >= 0 && ny < h {
                        let j = ny * w + nx
                        if m[j] && !seen[j] { seen[j] = true; stack.append(j) }
                    }
                }
                out.append(blob)
            }
            return out
        }
    }

    // MARK: Helpers

    static func median(_ v: [Double]) -> Double {
        guard !v.isEmpty else { return 0 }
        let s = v.sorted()
        return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
    }

    static func medianU8(_ v: [UInt8]) -> Double {
        let s = v.sorted()
        return s.count % 2 == 1 ? Double(s[s.count / 2]) : (Double(s[s.count / 2 - 1]) + Double(s[s.count / 2])) / 2
    }

    static func percentile(_ v: [Double], _ p: Double) -> Double {
        let s = v.sorted()
        guard !s.isEmpty else { return 0 }
        let x = p * Double(s.count - 1)
        let lo = Int(x.rounded(.down)), hi = min(s.count - 1, lo + 1)
        return s[lo] + (s[hi] - s[lo]) * (x - Double(lo))
    }

    static func round3(_ v: Double) -> Double { (v * 1000).rounded() / 1000 }
    static func round4(_ v: Double) -> Double { (v * 10000).rounded() / 10000 }
}
