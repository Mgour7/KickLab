import Foundation

/// Build 14 (engine 2.8.1): every step of combining the football's movement with the body
/// pose in a depth view, recorded so diagnostics can say exactly why ball evidence was
/// accepted or rejected. Times only — no coordinates.
struct BallFusionReport: Codable, Equatable, Sendable {
    /// The football analysis ran and a kicked ball with a departure was available.
    var detectorRan: Bool
    var ballSelected: Bool
    var lastStationaryTime: Double?
    var firstMovementTime: Double?
    /// The plant the run-up search proposed first, and whether it came before the ball left.
    var plantCandidateTime: Double?
    var plantPrecedesBall: Bool?
    /// The first plant estimate was after the ball left (or too long before it), so it was not used.
    var plantRejected: Bool = false
    /// The plant actually used (nil: none found before the ball left).
    var plantUsedTime: Double?
    /// The body-pose contact search range, and the pose strike/contact interval when found.
    var poseSearchStart: Double?
    var poseSearchEnd: Double?
    var poseStrikeEarliest: Double?
    var poseStrikeLatest: Double?
    var poseFoundStrike: Bool?
    var overlapsPose: Bool?
    /// The kicking foot's fastest speed at the ball's departure ÷ its fastest in the strike.
    var kickingFootSpeedRatio: Double?
    var kickingFootSupports: Bool?
    /// The ball's departure lies inside the selected kick window's strike interval.
    var withinKickWindow: Bool?
    var accepted: Bool = false
    var rejectionReason: String?
    /// Build 16 (2.9.0): which rule accepted the ball evidence (`Path`), nil when rejected
    /// or recorded by an older engine.
    var acceptancePath: String? = nil
    /// Build 16: every credible knee drive compared with the ball interval.
    var drives: [DriveCandidateRecord]? = nil
    /// Build 16: the departure classification (`FootballDepartureKind`).
    var departure: String? = nil
    var fusionVersion: String? = nil

    static let version = "ball-pose-fusion-2"

    /// Build 16: the acceptance paths. Each is a distinct rule, reported as such.
    enum Path: String, Sendable {
        /// The pose's selected strike overlaps the ball interval (±1 frame). The kicking
        /// foot's speed ratio is informational on this path.
        case poseStrikeAgreement
        /// No pose strike was established; the kicking foot was swinging (≥ 50% of its strike
        /// peak) as the ball left.
        case kickingFootSwing
        /// The pose's fastest drive began after the ball had already left (a follow-through
        /// extension); an earlier credible drive — the only one — overlaps the ball interval.
        case earlierCredibleDrive

        var explanation: String {
            switch self {
            case .poseStrikeAgreement: "the body-pose strike overlaps the ball interval; the kicking-foot speed ratio is informational on this path"
            case .kickingFootSwing: "no body-pose strike was established; accepted because the kicking foot was swinging as the ball left"
            case .earlierCredibleDrive: "the fastest knee drive began after the ball had left (follow-through extension); an earlier credible knee drive overlaps the ball interval"
            }
        }
    }

    var lines: [String] {
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        func b(_ v: Bool?) -> String { v.map { $0 ? "yes" : "no" } ?? "—" }
        var out = ["  ball/pose fusion: detector ran \(b(detectorRan)) · kicked ball selected \(b(ballSelected)) · ball interval \(n(lastStationaryTime))–\(n(firstMovementTime))"]
        out.append("    plant proposed \(n(plantCandidateTime)) · precedes ball departure \(b(plantPrecedesBall))\(plantRejected ? (plantPrecedesBall == true ? " · REJECTED (too long before the ball left)" : " · REJECTED (after the ball left)") : "") · plant used \(n(plantUsedTime))")
        out.append("    pose search \(n(poseSearchStart))–\(n(poseSearchEnd)) · pose strike \(poseFoundStrike == true ? "\(n(poseStrikeEarliest))–\(n(poseStrikeLatest))" : "not found") · overlap \(b(overlapsPose)) · in kick window \(b(withinKickWindow))")
        let footRequired = acceptancePath == Path.kickingFootSwing.rawValue
        out.append("    kicking foot at the ball: \(kickingFootSpeedRatio.map { String(format: "%.2f of its strike peak", $0) } ?? "—") · meets the 50% foot-swing rule \(b(kickingFootSupports))\(acceptancePath == nil ? "" : (footRequired ? " (required on this path)" : " (informational on this path)"))")
        if let departure { out.append("    ball departure: \(departure)") }
        for d in drives ?? [] {
            out.append(String(format: "    knee drive %.3f–%.3f s · %.0f°/s · %.0f° · overlaps ball %@ · starts after ball left %@ · %@",
                              d.startTime, d.completeTime, d.rateDegreesPerSecond, d.extensionDegrees, b(d.overlapsBall), b(d.startsAfterBallLeft), d.role))
        }
        out.append("    ball evidence \(accepted ? "ACCEPTED" : "REJECTED")\(acceptancePath.flatMap(Path.init(rawValue:)).map { " via \($0.rawValue) — \($0.explanation)" } ?? "")\(rejectionReason.map { " — \($0)" } ?? "")")
        return out
    }
}
