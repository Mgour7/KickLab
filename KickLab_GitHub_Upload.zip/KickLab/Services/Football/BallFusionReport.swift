import Foundation

/// Build 14 (engine 2.8.1): every step of combining the football's movement with the body
/// pose in a depth view, recorded so diagnostics can say exactly why ball evidence was
/// accepted or rejected. Times only — no coordinates.
struct BallFusionReport: Codable, Equatable, Sendable {
    /// The football analysis ran and a kicked ball with a departure was available.
    var detectorRan: Bool
    var ballSelected: Bool
    var lastStationaryTime: Double?
    var firstMovementTime: Double?
    /// The plant the run-up search proposed first, and whether it came before the ball left.
    var plantCandidateTime: Double?
    var plantPrecedesBall: Bool?
    /// The first plant estimate was after the ball had already left, so it was not used.
    var plantRejected: Bool = false
    /// The plant actually used (nil: none found before the ball left).
    var plantUsedTime: Double?
    /// The body-pose contact search range, and the pose strike/contact interval when found.
    var poseSearchStart: Double?
    var poseSearchEnd: Double?
    var poseStrikeEarliest: Double?
    var poseStrikeLatest: Double?
    var poseFoundStrike: Bool?
    var overlapsPose: Bool?
    /// The kicking foot's fastest speed at the ball's departure ÷ its fastest in the strike.
    var kickingFootSpeedRatio: Double?
    var kickingFootSupports: Bool?
    /// The ball's departure lies inside the selected kick window's strike interval.
    var withinKickWindow: Bool?
    var accepted: Bool = false
    var rejectionReason: String?

    var lines: [String] {
        func n(_ v: Double?) -> String { v.map { String(format: "%.3f", $0) } ?? "—" }
        func b(_ v: Bool?) -> String { v.map { $0 ? "yes" : "no" } ?? "—" }
        var out = ["  ball/pose fusion: detector ran \(b(detectorRan)) · kicked ball selected \(b(ballSelected)) · ball interval \(n(lastStationaryTime))–\(n(firstMovementTime))"]
        out.append("    plant proposed \(n(plantCandidateTime)) · precedes ball departure \(b(plantPrecedesBall))\(plantRejected ? " · REJECTED (after the ball left)" : "") · plant used \(n(plantUsedTime))")
        out.append("    pose search \(n(poseSearchStart))–\(n(poseSearchEnd)) · pose strike \(poseFoundStrike == true ? "\(n(poseStrikeEarliest))–\(n(poseStrikeLatest))" : "not found") · overlap \(b(overlapsPose)) · in kick window \(b(withinKickWindow))")
        out.append("    kicking foot at the ball: \(kickingFootSpeedRatio.map { String(format: "%.2f of its strike peak", $0) } ?? "—") · supports \(b(kickingFootSupports))")
        out.append("    ball evidence \(accepted ? "ACCEPTED" : "REJECTED")\(rejectionReason.map { " — \($0)" } ?? "")")
        return out
    }
}
