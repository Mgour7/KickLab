import Foundation

/// Step 12G (CV rebuild): what the football analysis needs from the pose pass.
struct FootballAnalysisContext: Sendable {
    /// The body-pose strike (possible contact frames), when found.
    var strike: ClosedRange<Double>?
    /// The kicking ankle per analyzed frame (app-normalized displayed coordinates).
    var ankle: [FootballTrackAnalyzer.AnkleSample]
    /// The kicker's outline per analyzed frame (excluded from camera-motion matching).
    var kickerBoxes: [(time: Double, box: NormalizedRect)]
    var aspect: Double?
    /// Build 22: the kicker's feet, outline and torso per frame, for the strike-site ball
    /// finder, and the times where the strike most likely is (kick-window strikes).
    var strikeSitePose: [StrikeSitePoseSample] = []
    var strikeSiteTimes: [Double] = []

    init(strike: ClosedRange<Double>?, ankle: [FootballTrackAnalyzer.AnkleSample], kickerBoxes: [(time: Double, box: NormalizedRect)],
         aspect: Double?) {
        self.strike = strike
        self.ankle = ankle
        self.kickerBoxes = kickerBoxes
        self.aspect = aspect
    }

    /// From a pose-only pipeline pass.
    static func make(from output: KickAnalysisPipelineOutput, kickingFoot: KickingFoot) -> FootballAnalysisContext {
        let contact = output.phases.phase(.contact)
        var strike: ClosedRange<Double>?
        if let t = contact.representativeTime {
            let e = output.phases.evidence
            strike = min(e?.contactEarliestTime ?? t, t)...max(e?.contactLatestTime ?? t, t)
        }
        let joint = KickingSideJoints(kickingFoot: kickingFoot).kickingAnkle
        let samples = output.kickerTimeline?.samples ?? []
        let ankle = samples.compactMap { s in s.point(joint).map { FootballTrackAnalyzer.AnkleSample(time: s.timestamp, point: NormalizedPoint(x: $0.x, y: $0.y)) } }
        let boxes: [(time: Double, box: NormalizedRect)] = samples.compactMap { s in
            let pts = s.joints.values.filter(\.isAvailable).map { NormalizedPoint(x: $0.x, y: $0.y) }
            guard let b = NormalizedRect.bounding(pts) else { return nil }
            let mx = 0.15 * max(b.width, 0.05), my = 0.1 * max(b.height, 0.05)
            return (s.timestamp, NormalizedRect(minX: b.minX - mx, minY: b.minY - my, maxX: b.maxX + mx, maxY: b.maxY + my))
        }
        let aspect = output.kickerTimeline?.displayAspectRatio ?? output.sequence.displayAspectRatio
        var context = FootballAnalysisContext(strike: strike, ankle: ankle, kickerBoxes: boxes, aspect: aspect)
        let sides = KickingSideJoints(kickingFoot: kickingFoot)
        let a = aspect ?? 1
        context.strikeSitePose = samples.map { s in
            let pts = s.joints.values.filter(\.isAvailable).map { NormalizedPoint(x: $0.x, y: $0.y) }
            var torso: Double?
            if let ls = s.point(.leftShoulder), let rs = s.point(.rightShoulder), let lh = s.point(.leftHip), let rh = s.point(.rightHip) {
                torso = hypot((ls.x + rs.x - lh.x - rh.x) / 2 * a, (ls.y + rs.y - lh.y - rh.y) / 2)
            }
            return StrikeSitePoseSample(time: s.timestamp,
                                        kickingAnkle: s.point(sides.kickingAnkle).map { NormalizedPoint(x: $0.x, y: $0.y) },
                                        plantAnkle: s.point(sides.plantAnkle).map { NormalizedPoint(x: $0.x, y: $0.y) },
                                        body: NormalizedRect.bounding(pts), torso: torso)
        }
        var times = (output.phases.kickWindows?.windows ?? []).filter(\.hasSwing).map { ($0.strikeStart + $0.strikeEnd) / 2 }
        if let t = contact.representativeTime { times.append(t) }
        context.strikeSiteTimes = times
        return context
    }

    /// The kicker's box nearest `time` (within 0.1 s).
    func kickerBox(at time: Double) -> NormalizedRect? {
        guard let near = kickerBoxes.min(by: { abs($0.time - time) < abs($1.time - time) }), abs(near.time - time) <= 0.1 else { return nil }
        return near.box
    }
}

/// Step 12G (CV rebuild): finds and follows the football in a video. Runs on-device; the
/// production implementation is `CoreMLFootballVideoAnalyzer` (bundled YOLOX-S model).
protocol FootballVideoAnalyzing: Sendable {
    var isAvailable: Bool { get }
    func analyze(videoURL: URL, context: FootballAnalysisContext,
                 progress: @escaping @Sendable (Double) -> Void) async throws -> FootballTrack
}

/// No football detector (Linux tests, or the model couldn't be loaded).
struct UnavailableFootballVideoAnalyzer: FootballVideoAnalyzing {
    var reason = "No football detector is available on this device."
    var isAvailable: Bool { false }

    init(reason: String = "No football detector is available on this device.") {
        self.reason = reason
    }

    func analyze(videoURL: URL, context: FootballAnalysisContext,
                 progress: @escaping @Sendable (Double) -> Void) async throws -> FootballTrack {
        try Task.checkCancellation()
        return .unavailable(reason)
    }
}

/// Step 12G: full-range Y′CbCr (8-bit 4:2:0 video, BT.709 matrix) → B, G, R (0…255).
enum YCbCrConversion {
    static func bgr(y: UInt8, cb: UInt8, cr: UInt8) -> (b: Float, g: Float, r: Float) {
        let yy = Float(y), u = Float(cb) - 128, v = Float(cr) - 128
        func c(_ x: Float) -> Float { min(255, max(0, x)) }
        return (c(yy + 1.8556 * u), c(yy - 0.1873 * u - 0.4681 * v), c(yy + 1.5748 * v))
    }
}
