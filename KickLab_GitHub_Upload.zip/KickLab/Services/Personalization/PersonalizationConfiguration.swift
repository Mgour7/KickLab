import Foundation

// Step 10 personalization: a transparent, deterministic statistical profile of one
// athlete, built on top of the Step 8 metrics. It never replaces the Step 8 rules and
// it is not machine learning. Every number it uses is in this configuration so it can be
// explained, tested and re-tuned.

/// How much comparable history a profile (or one metric) has.
enum ProfileMaturity: String, Codable, Sendable, CaseIterable, Comparable {
    case insufficient
    case emerging
    case established
    case strong

    private var order: Int {
        switch self {
        case .insufficient: 0
        case .emerging: 1
        case .established: 2
        case .strong: 3
        }
    }

    static func < (a: ProfileMaturity, b: ProfileMaturity) -> Bool { a.order < b.order }

    var displayName: String {
        switch self {
        case .insufficient: "Not enough kicks yet"
        case .emerging: "Emerging"
        case .established: "Established"
        case .strong: "Strong"
        }
    }
}

/// Sample counts for each maturity level (defaults: <3 insufficient, 3–7 emerging,
/// 8–19 established, 20+ strong).
struct MaturityThresholds: Codable, Equatable, Sendable {
    var emerging = 3
    var established = 8
    var strong = 20

    func level(for count: Int) -> ProfileMaturity {
        if count >= strong { return .strong }
        if count >= established { return .established }
        if count >= emerging { return .emerging }
        return .insufficient
    }
}

/// Per-metric facts the personal model needs that Step 8 does not define.
struct PersonalMetricTraits: Codable, Equatable, Sendable {
    /// True when the value does not depend on where the camera stood (timings, speed
    /// ratios). Other metrics are only compared between videos from the same angle.
    var angleInvariant: Bool
    /// False when lower variation is not a meaningful goal for this metric.
    var repeatabilityMeaningful: Bool
    /// The spread (standard deviation, metric units) at which consistency scores 0.
    var consistencyScale: Double
    /// Differences smaller than this (metric units) are never called out, however
    /// "significant" they look statistically.
    var minimumMeaningfulDifference: Double
}

/// Optional, configurable definition of a "successful" kickoff. Nil by default:
/// KickLab does not invent a universal kickoff success formula.
struct KickoffSuccessCriteria: Codable, Equatable, Sendable {
    /// A touchback counts as successful.
    var touchbackIsSuccess = true
    /// Out of bounds counts as unsuccessful.
    var outOfBoundsIsFailure = true
    /// When set, the kick also needs a known distance of at least this many yards.
    var minimumDistanceYards: Double?
    /// When set, the kick also needs a known hang time of at least this many seconds.
    var minimumHangTimeSeconds: Double?
}

/// Optional, configurable definition of a "successful" punt. Nil by default.
struct PuntSuccessCriteria: Codable, Equatable, Sendable {
    var minimumDistanceYards: Double?
    var minimumHangTimeSeconds: Double?
}

/// Every threshold of the personal model.
struct PersonalizationConfiguration: Codable, Equatable, Sendable {
    /// Bumped whenever a default below changes meaning.
    static let currentVersion = 1

    var version = PersonalizationConfiguration.currentVersion

    // MARK: Eligibility
    /// Step 8 metric confidence needed for a value to be learned from.
    var minimumMetricConfidence = 0.5
    var maturity = MaturityThresholds()

    // MARK: Recency
    /// "Recent" = the last this-many eligible kicks.
    var recentKickCount = 10
    /// A second recent window: the last this-many days.
    var recentDays = 30
    /// A recent window needs at least this many samples, otherwise lifetime is used.
    var minimumRecentSamples = 3
    /// Recency weight halves every this-many days (weight = 0.5^(age ÷ half-life)).
    var recencyHalfLifeDays = 60.0

    // MARK: Successful kicks
    /// A successful-kick pattern exists with at least this many successful samples.
    var minimumSuccessfulSamples = 3
    /// A successful pattern counts as strong (it can outweigh a general rule) from here.
    var strongSuccessfulPatternSamples = 8
    /// Blocked field goals are usually a protection problem, so they are not counted
    /// as mechanical misses unless this is true.
    var blockedCountsAsMiss = false
    var kickoffSuccess: KickoffSuccessCriteria?
    var puntSuccess: PuntSuccessCriteria?

    // MARK: Outcome relationships
    /// Each group (successful and unsuccessful) needs at least this many samples.
    var minimumOutcomeGroupSize = 5
    /// Standardized separation (|mean difference| ÷ pooled SD) needed to report.
    var minimumEffectSize = 0.8
    /// Mean metric confidence of the samples needed to report.
    var minimumRelationshipConfidence = 0.6

    // MARK: Consistency
    var minimumConsistencySamples = 5
    var highlyRepeatableScore = 0.75
    var variableScore = 0.35
    /// The window before the recent window that recent consistency is compared with.
    var previousConsistencyKickCount = 20
    /// recent SD ÷ previous SD at or below this = more consistent (its inverse = less).
    var consistencyChangeRatio = 0.7
    /// Share of recent kicks inside the successful range for a "repeatable" strength.
    var repeatableWithinShare = 0.8

    // MARK: Trends
    var minimumTrendSamples = 6
    /// A change counts when it is at least this many standard errors.
    var trendStandardErrors = 2.0

    // MARK: Deviations
    /// A deviation is notable at this many spreads (robust SD, at least the metric's
    /// minimum meaningful difference) from the reference.
    var notableDeviation = 1.5
    /// …and large from here (changes coaching wording and score).
    var largeDeviation = 3.0

    // MARK: Distance
    /// A field-goal distance bucket gets its own profile from this many eligible kicks;
    /// until then the overall field-goal profile is used.
    var distanceBucketMinimumKicks = 8

    // MARK: Coaching output
    var maximumPrimaryFixes = 3
    var maximumStrengths = 2
    /// Fixes scoring below this are stored as secondary insights, not promoted.
    var minimumPrimaryScore = 25.0

    var metricTraits: [KickMetricKey: PersonalMetricTraits] = PersonalizationConfiguration.standardTraits

    init() {}

    func traits(_ key: KickMetricKey) -> PersonalMetricTraits {
        metricTraits[key] ?? PersonalMetricTraits(angleInvariant: false, repeatabilityMeaningful: false,
                                                  consistencyScale: 1, minimumMeaningfulDifference: 1)
    }

    /// Initial values, in Step 8 units. Timings and speed ratios are angle-invariant;
    /// angles, lengths and speeds measured in a 2D image are not.
    static let standardTraits: [KickMetricKey: PersonalMetricTraits] = [
        .approachSpeed: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 1.5, minimumMeaningfulDifference: 0.4),
        .approachSpeedVariation: .init(angleInvariant: true, repeatabilityMeaningful: false, consistencyScale: 20, minimumMeaningfulDifference: 8),
        .approachLateSpeedChange: .init(angleInvariant: true, repeatabilityMeaningful: true, consistencyScale: 30, minimumMeaningfulDifference: 8),
        .plantToContactTime: .init(angleInvariant: true, repeatabilityMeaningful: true, consistencyScale: 0.1, minimumMeaningfulDifference: 0.03),
        .plantFootDrift: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 0.2, minimumMeaningfulDifference: 0.05),
        .plantKneeAngleAtContact: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 20, minimumMeaningfulDifference: 6),
        .kickingKneeAngleAtContact: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 20, minimumMeaningfulDifference: 6),
        .kickingHipAngleAtContact: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 20, minimumMeaningfulDifference: 6),
        .backswingDepth: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 0.6, minimumMeaningfulDifference: 0.15),
        .peakFootSpeed: .init(angleInvariant: false, repeatabilityMeaningful: false, consistencyScale: 10, minimumMeaningfulDifference: 3),
        .footSpeedAtContact: .init(angleInvariant: false, repeatabilityMeaningful: false, consistencyScale: 10, minimumMeaningfulDifference: 3),
        .torsoLeanAtContact: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 15, minimumMeaningfulDifference: 4),
        .torsoLeanRange: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 15, minimumMeaningfulDifference: 4),
        .bodyForwardSpeedAtContact: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 1.5, minimumMeaningfulDifference: 0.4),
        .followThroughDuration: .init(angleInvariant: true, repeatabilityMeaningful: true, consistencyScale: 0.15, minimumMeaningfulDifference: 0.04),
        .followThroughFootHeight: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 0.6, minimumMeaningfulDifference: 0.15),
        .followThroughBodyTravel: .init(angleInvariant: false, repeatabilityMeaningful: true, consistencyScale: 0.6, minimumMeaningfulDifference: 0.15),
    ]
}

/// Converts evidence strength into the confidence of a personal finding.
enum PersonalizationConfidence {
    /// How much a personal comparison is trusted at each maturity level.
    static func maturityFactor(_ maturity: ProfileMaturity) -> Double {
        switch maturity {
        case .insufficient: 0
        case .emerging: 0.6
        case .established: 0.8
        case .strong: 0.95
        }
    }

    /// Confidence of a personal comparison: the current measurement's confidence × the
    /// maturity factor of the metric's history.
    static func personal(measurement: Double, maturity: ProfileMaturity) -> Double {
        PersonalStatistics.round3(min(1, max(0, measurement)) * maturityFactor(maturity))
    }

    enum Level: String, Codable, Sendable {
        case high, medium, low

        var displayName: String {
            switch self {
            case .high: "High"
            case .medium: "Medium"
            case .low: "Low"
            }
        }
    }

    static func level(_ confidence: Double) -> Level {
        if confidence >= 0.7 { return .high }
        if confidence >= 0.5 { return .medium }
        return .low
    }
}
