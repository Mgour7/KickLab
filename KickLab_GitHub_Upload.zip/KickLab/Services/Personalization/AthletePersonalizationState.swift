import Foundation

/// A recorded change of the athlete's kicking foot.
struct KickingFootChange: Codable, Equatable, Sendable {
    var changedAt: Date
    var from: KickingFoot
    var to: KickingFoot
}

/// Small per-athlete facts the personal model needs that the Step 3 schema does not
/// store: when the kicking foot changed, and baseline resets ("technique eras").
///
/// Kicks and analyses are never deleted or changed by anything here; this only decides
/// which of them a baseline learns from.
struct AthletePersonalizationState: Codable, Equatable, Sendable {
    var footChanges: [KickingFootChange] = []
    var epochs: [BaselineEpoch] = []

    init(footChanges: [KickingFootChange] = [], epochs: [BaselineEpoch] = []) {
        self.footChanges = footChanges
        self.epochs = epochs
    }

    /// The foot the athlete kicked with at `date`, given today's foot. Each analysis used
    /// the athlete's foot at the time it ran, so this recovers it from the change log:
    /// the `from` of the first change after `date`, otherwise the current foot.
    func kickingFoot(at date: Date, current: KickingFoot) -> KickingFoot {
        footChanges.sorted { $0.changedAt < $1.changedAt }.first { $0.changedAt > date }?.from ?? current
    }

    mutating func recordFootChange(from: KickingFoot, to: KickingFoot, at date: Date) {
        guard from != to else { return }
        footChanges.append(KickingFootChange(changedAt: date, from: from, to: to))
        footChanges.sort { $0.changedAt < $1.changedAt }
    }

    /// The active baseline epoch for a kick type (the latest generation), if any.
    func activeEpoch(for kickType: KickType) -> BaselineEpoch? {
        epochs.filter { $0.kickType == kickType }.max { $0.generation < $1.generation }
    }

    /// Starts a new baseline for `kickType` from `date`. Older kicks stay stored.
    @discardableResult
    mutating func startNewBaseline(for kickType: KickType, at date: Date, note: String? = nil) -> BaselineEpoch {
        let generation = (activeEpoch(for: kickType)?.generation ?? 0) + 1
        let epoch = BaselineEpoch(kickType: kickType, generation: generation, startsAt: date, note: note)
        epochs.append(epoch)
        return epoch
    }
}

/// Where personalization state lives. Production: `UserDefaults`; tests: in memory.
protocol PersonalizationStateStoring: AnyObject {
    func state(for athleteID: UUID) -> AthletePersonalizationState
    func setState(_ state: AthletePersonalizationState, for athleteID: UUID)
    func removeState(for athleteID: UUID)
}

extension PersonalizationStateStoring {
    func update(_ athleteID: UUID, _ change: (inout AthletePersonalizationState) -> Void) {
        var state = state(for: athleteID)
        change(&state)
        setState(state, for: athleteID)
    }
}

final class InMemoryPersonalizationState: PersonalizationStateStoring {
    private var states: [UUID: AthletePersonalizationState] = [:]

    init() {}

    func state(for athleteID: UUID) -> AthletePersonalizationState { states[athleteID] ?? AthletePersonalizationState() }
    func setState(_ state: AthletePersonalizationState, for athleteID: UUID) { states[athleteID] = state }
    func removeState(for athleteID: UUID) { states[athleteID] = nil }
}

final class UserDefaultsPersonalizationState: PersonalizationStateStoring {
    private let defaults: UserDefaults
    private let prefix = "personalization.state."

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    func state(for athleteID: UUID) -> AthletePersonalizationState {
        guard let data = defaults.data(forKey: prefix + athleteID.uuidString),
              let state = try? JSONDecoder().decode(AthletePersonalizationState.self, from: data) else {
            return AthletePersonalizationState()
        }
        return state
    }

    func setState(_ state: AthletePersonalizationState, for athleteID: UUID) {
        guard let data = try? JSONEncoder().encode(state) else { return }
        defaults.set(data, forKey: prefix + athleteID.uuidString)
    }

    func removeState(for athleteID: UUID) {
        defaults.removeObject(forKey: prefix + athleteID.uuidString)
    }
}
