import Foundation

/// Coach-voice wording for personal findings. Short, concrete, kicking language; no
/// metric IDs, no medical or injury claims, and association wording only ("tends to",
/// "in your recorded kicks"), never causation.
enum PersonalCoachCopy {
    struct Phrases: Sendable {
        /// Noun used in sentences, e.g. "plant timing".
        var noun: String
        /// "Your plant came {q}early" — `{q}` becomes "a little " or "noticeably ".
        var higher: String
        var lower: String
        /// Cue when the value was higher than the target (nil: higher is never a fault).
        var cueWhenHigher: String?
        /// Cue when the value was lower than the target (nil: lower is never a fault).
        var cueWhenLower: String?
    }

    static func phrases(_ key: KickMetricKey) -> Phrases {
        switch key {
        case .approachSpeed:
            Phrases(noun: "approach speed", higher: "Your approach was {q}faster", lower: "Your approach was {q}slower",
                    cueWhenHigher: "Take your approach at the speed of your best kicks; controlled speed beats extra speed.",
                    cueWhenLower: "Attack the ball a little more and carry the speed you use on your best kicks.")
        case .approachSpeedVariation:
            Phrases(noun: "approach rhythm", higher: "Your approach speed was {q}less even", lower: "Your approach speed was {q}more even",
                    cueWhenHigher: "Keep every step of the approach at the same rhythm.", cueWhenLower: nil)
        case .approachLateSpeedChange:
            Phrases(noun: "speed into the plant", higher: "You {q}sped up more into the plant", lower: "You {q}slowed down more into the plant",
                    cueWhenHigher: "Hold your speed steady into the plant instead of surging.",
                    cueWhenLower: "Don't brake into the plant; keep your speed through the last two steps.")
        case .plantToContactTime:
            Phrases(noun: "plant timing", higher: "Your plant came {q}early", lower: "Your plant came {q}late",
                    cueWhenHigher: "Keep the final step quick and let the plant arrive closer to the strike.",
                    cueWhenLower: "Get the plant down a touch sooner so the swing can flow from it.")
        case .plantFootDrift:
            Phrases(noun: "plant foot", higher: "Your plant foot moved {q}more", lower: "Your plant foot moved {q}less",
                    cueWhenHigher: "Drive the plant foot into the ground and keep it still through the ball.", cueWhenLower: nil)
        case .plantKneeAngleAtContact:
            Phrases(noun: "plant leg", higher: "Your plant leg was {q}straighter", lower: "Your plant leg was {q}more bent",
                    cueWhenHigher: "Keep a little softer bend in the plant knee, like on your best kicks.",
                    cueWhenLower: "Stand taller on the plant leg through the ball.")
        case .kickingKneeAngleAtContact:
            Phrases(noun: "kicking-leg extension", higher: "Your kicking leg was {q}straighter at contact", lower: "Your kicking leg was {q}more bent at contact",
                    cueWhenHigher: "Keep the swing loose; don't lock the leg before the ball.",
                    cueWhenLower: "Snap the knee straight through the ball.")
        case .kickingHipAngleAtContact:
            Phrases(noun: "kicking-hip position", higher: "Your kicking hip was {q}more open at contact", lower: "Your kicking hip was {q}more closed at contact",
                    cueWhenHigher: "Keep the kicking hip closed a beat longer into contact.",
                    cueWhenLower: "Let the hip open through the ball.")
        case .backswingDepth:
            Phrases(noun: "backswing", higher: "Your backswing was {q}deeper", lower: "Your backswing was {q}shorter",
                    cueWhenHigher: "Shorten the backswing slightly to match your best kicks.",
                    cueWhenLower: "Let the leg load back a little further before the swing.")
        case .peakFootSpeed:
            Phrases(noun: "foot speed", higher: "Your foot speed was {q}higher", lower: "Your foot speed was {q}lower",
                    cueWhenHigher: nil, cueWhenLower: "Stay loose and let the leg whip through the ball.")
        case .footSpeedAtContact:
            Phrases(noun: "foot speed at contact", higher: "Your foot speed at contact was {q}higher", lower: "Your foot speed at contact was {q}lower",
                    cueWhenHigher: nil, cueWhenLower: "Stay loose and let the leg whip through the ball.")
        case .lateralTrunkLeanAtContact:
            Phrases(noun: "sideways trunk lean", higher: "Your trunk tilted {q}more toward the plant side", lower: "Your trunk tilted {q}more toward the kicking side",
                    cueWhenHigher: nil, cueWhenLower: nil)
        case .plantFootWidth:
            Phrases(noun: "plant foot width", higher: "Your plant foot landed {q}wider", lower: "Your plant foot landed {q}narrower",
                    cueWhenHigher: nil, cueWhenLower: nil)
        case .plantBallLateralOffset:
            Phrases(noun: "plant foot distance beside the ball", higher: "Your plant foot landed {q}further from the ball", lower: "Your plant foot landed {q}closer to the ball",
                    cueWhenHigher: nil, cueWhenLower: nil)
        case .kneeSwingAfterContact:
            Phrases(noun: "knee swing after contact", higher: "Your kicking knee kept swinging {q}longer", lower: "Your kicking knee stopped swinging {q}sooner",
                    cueWhenHigher: nil, cueWhenLower: nil)
        case .plantLateralMovement:
            Phrases(noun: "plant-foot sideways movement", higher: "Your plant foot moved {q}more sideways", lower: "Your plant foot moved {q}less sideways",
                    cueWhenHigher: nil, cueWhenLower: nil)
        case .torsoLeanAtContact:
            Phrases(noun: "body position over the ball", higher: "You were leaning {q}further forward at contact", lower: "You were leaning {q}further back at contact",
                    cueWhenHigher: "Stay a little taller through the ball.",
                    cueWhenLower: "Keep your chest over the ball at contact.")
        case .torsoLeanRange:
            Phrases(noun: "upper-body control", higher: "Your upper body moved {q}more through the swing", lower: "Your upper body moved {q}less through the swing",
                    cueWhenHigher: "Keep your upper body quiet through the swing.", cueWhenLower: nil)
        case .bodyForwardSpeedAtContact:
            Phrases(noun: "speed through the ball", higher: "You were moving through the ball {q}faster", lower: "You were moving through the ball {q}slower",
                    cueWhenHigher: "Let the swing do the work; don't lunge through the ball.",
                    cueWhenLower: "Keep moving through the ball instead of stopping at the plant.")
        case .followThroughDuration:
            Phrases(noun: "follow-through", higher: "Your follow-through lasted {q}longer", lower: "Your follow-through was {q}shorter",
                    cueWhenHigher: "Finish with the same controlled follow-through as your best kicks.",
                    cueWhenLower: "Let the kicking leg swing up and through toward the target.")
        case .followThroughFootHeight:
            Phrases(noun: "finish height", higher: "Your leg finished {q}higher", lower: "Your leg finished {q}lower",
                    cueWhenHigher: nil, cueWhenLower: "Finish high, toward the target.")
        case .followThroughBodyTravel:
            Phrases(noun: "carry after contact", higher: "You carried {q}further after contact", lower: "You stopped {q}sooner after contact",
                    cueWhenHigher: "Stay balanced over the ball rather than drifting forward.",
                    cueWhenLower: "Let your body carry through toward the target after contact.")
        }
    }

    /// "Your plant came a little early" (|scaled deviation| below `large`) or "…noticeably early".
    static func comparison(_ key: KickMetricKey, higher: Bool, scaledDeviation: Double, large: Double) -> String {
        let p = phrases(key)
        let qualifier = abs(scaledDeviation) >= large ? "noticeably " : "a little "
        return (higher ? p.higher : p.lower).replacingOccurrences(of: "{q}", with: qualifier)
    }

    static func cue(_ key: KickMetricKey, higher: Bool) -> String? {
        let p = phrases(key)
        return higher ? p.cueWhenHigher : p.cueWhenLower
    }

    static func consistencyCue(_ key: KickMetricKey) -> String {
        switch key {
        case .plantToContactTime, .approachSpeed, .approachLateSpeedChange, .approachSpeedVariation:
            "Keep the final two approach steps at the same rhythm."
        case .plantFootDrift, .plantKneeAngleAtContact, .plantFootWidth, .plantBallLateralOffset, .plantLateralMovement:
            "Hit the same plant every rep: same steps, same spot, same rhythm."
        case .kickingKneeAngleAtContact, .kickingHipAngleAtContact, .backswingDepth, .peakFootSpeed, .footSpeedAtContact:
            "Make the same swing every time; don't change effort from kick to kick."
        case .torsoLeanAtContact, .torsoLeanRange, .bodyForwardSpeedAtContact, .lateralTrunkLeanAtContact:
            "Set the same body position over the ball on every kick."
        case .followThroughDuration, .followThroughFootHeight, .followThroughBodyTravel, .kneeSwingAfterContact:
            "Finish the same way every time, through the target."
        }
    }

    static func kicksNoun(_ kickType: KickType, count: Int) -> String {
        let one = count == 1
        switch kickType {
        case .fieldGoal: return one ? "field goal" : "field goals"
        case .pat: return one ? "PAT" : "PATs"
        case .kickoff: return one ? "kickoff" : "kickoffs"
        case .punt: return one ? "punt" : "punts"
        case .unknown: return one ? "kick" : "kicks"
        }
    }

    /// "makes" / "misses" for FG and PAT; "successful kicks" / "other kicks" otherwise.
    static func outcomeWords(_ kickType: KickType) -> (good: String, bad: String) {
        switch kickType {
        case .fieldGoal, .pat: ("makes", "misses")
        default: ("successful kicks", "less successful kicks")
        }
    }

    static func learningMessage(needed: Int) -> String {
        "KickLab is still learning your mechanics. Record \(needed) more comparable \(needed == 1 ? "kick" : "kicks") to improve personalized coaching."
    }

    static let deEmphasizedRationale = "Outside the general target range, but consistent with your successful kicks, so it isn't a priority right now."
    static let keptDespitePatternRationale = "This matches your successful kicks, but it is far outside the general range, so it stays on the list."
    static let elevatedRationale = "In your recorded kicks, this tends to occur on your less successful kicks, so it moves up the list."
    static let reinforcedRationale = "Both the general range and your own successful kicks point the same way."
    static let generalOnlyRationale = "Based on general kicking mechanics; KickLab doesn't have enough of your comparable kicks to personalize this yet."
    static let conflictingDirectionRationale = "Your own kicks point a different way here, so KickLab sticks with the general guidance for now."
    static let personalOnlyRationale = "Based on your own kicks; the general range doesn't flag it."
}

/// Locale-independent number formatting in Step 8 units.
enum PersonalCoachFormat {
    static func number(_ value: Double, _ unit: MetricUnit) -> String {
        let digits: Int
        switch unit {
        case .degrees, .percent: digits = 0
        case .bodyLengthsPerSecond: digits = 1
        default: digits = 2
        }
        let text = String(format: "%.\(digits)f", value)
        return text.hasPrefix("-") && Double(text) == 0 ? String(text.dropFirst()) : text
    }

    static func suffix(_ unit: MetricUnit) -> String {
        switch unit {
        case .degrees: "°"
        case .percent: "%"
        case .seconds: " s"
        case .bodyLengths: " torso lengths"
        case .bodyLengthsPerSecond: " torso lengths/s"
        default: unit.displayName.isEmpty ? "" : " " + unit.displayName
        }
    }

    static func value(_ value: Double, _ unit: MetricUnit) -> String { number(value, unit) + suffix(unit) }

    static func range(_ low: Double, _ high: Double, _ unit: MetricUnit) -> String {
        number(low, unit) + "–" + number(high, unit) + suffix(unit)
    }

    /// "± 0.02 s"
    static func spread(_ value: Double, _ unit: MetricUnit) -> String { "±" + Self.value(value, unit) }
}
