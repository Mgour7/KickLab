import Foundation

enum OutcomeRelationshipStatus: String, Codable, Sendable {
    /// Clear, sufficiently confident difference between successful and unsuccessful kicks.
    case associated
    /// Enough data, but the difference is too small to mention.
    case notMeaningful
    /// Enough data and a difference, but the measurements are not trustworthy enough.
    case lowConfidence
    case insufficientData
}

/// Whether one metric differs between the athlete's successful and unsuccessful kicks.
///
/// This is association in the recorded kicks, never causation. Effect size is the
/// standardized separation (successful mean − unsuccessful mean) ÷ pooled SD, with the
/// pooled SD floored at half the metric's minimum meaningful difference so a tiny spread
/// can't inflate it. Reported only with enough kicks in both groups, a large enough
/// effect and difference, and adequate measurement confidence.
struct MetricOutcomeRelationship: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var status: OutcomeRelationshipStatus
    var successfulCount: Int
    var unsuccessfulCount: Int
    var successfulMean: Double?
    var unsuccessfulMean: Double?
    /// Successful − unsuccessful.
    var meanDifference: Double?
    var medianDifference: Double?
    var pooledStandardDeviation: Double?
    var effectSize: Double?
    var meanConfidence: Double?

    var isReportable: Bool { status == .associated }

    /// True when successful kicks had the higher values.
    var successfulSideIsHigher: Bool? { meanDifference.map { $0 > 0 } }

    /// True when `value` is closer to the unsuccessful mean than to the successful mean.
    func isOnUnsuccessfulSide(_ value: Double) -> Bool {
        guard let s = successfulMean, let u = unsuccessfulMean else { return false }
        return abs(value - u) < abs(value - s)
    }

    static func make(key: KickMetricKey, samples: [PersonalSample], configuration: PersonalizationConfiguration) -> MetricOutcomeRelationship {
        let traits = configuration.traits(key)
        let successful = samples.filter { $0.success == .successful }
        let unsuccessful = samples.filter { $0.success == .unsuccessful }
        var relationship = MetricOutcomeRelationship(
            key: key, status: .insufficientData, successfulCount: successful.count, unsuccessfulCount: unsuccessful.count,
            successfulMean: nil, unsuccessfulMean: nil, meanDifference: nil, medianDifference: nil,
            pooledStandardDeviation: nil, effectSize: nil, meanConfidence: nil
        )
        guard successful.count >= configuration.minimumOutcomeGroupSize, unsuccessful.count >= configuration.minimumOutcomeGroupSize,
              let s = MetricDistribution(successful), let u = MetricDistribution(unsuccessful) else { return relationship }

        let n1 = Double(s.count)
        let n2 = Double(u.count)
        let pooledVariance = ((n1 - 1) * s.standardDeviation * s.standardDeviation + (n2 - 1) * u.standardDeviation * u.standardDeviation) / (n1 + n2 - 2)
        let pooled = pooledVariance.squareRoot()
        let difference = s.mean - u.mean
        let effect = difference / max(pooled, traits.minimumMeaningfulDifference / 2)
        let confidence = PersonalStatistics.round3(PersonalStatistics.mean((successful + unsuccessful).map(\.confidence)))

        relationship.successfulMean = s.mean
        relationship.unsuccessfulMean = u.mean
        relationship.meanDifference = difference
        relationship.medianDifference = s.median - u.median
        relationship.pooledStandardDeviation = pooled
        relationship.effectSize = effect
        relationship.meanConfidence = confidence

        if abs(effect) < configuration.minimumEffectSize || abs(difference) < traits.minimumMeaningfulDifference {
            relationship.status = .notMeaningful
        } else if confidence < configuration.minimumRelationshipConfidence {
            relationship.status = .lowConfidence
        } else {
            relationship.status = .associated
        }
        return relationship
    }
}
