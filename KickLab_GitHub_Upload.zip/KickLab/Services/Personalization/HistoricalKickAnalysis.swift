import Foundation

/// One stored metric of a past analysis, as the personal model sees it.
struct HistoricalMetricValue: Codable, Equatable, Sendable {
    /// Nil when the metric was unavailable. Never a placeholder.
    var value: Double?
    var confidence: Double?
    var status: MeasurementStatus
    var definitionVersion: Int
    /// The camera position of the video the value came from (nil = not recorded).
    var cameraAngle: VideoAngleType?

    init(value: Double?, confidence: Double?, status: MeasurementStatus, definitionVersion: Int = 1, cameraAngle: VideoAngleType? = .side) {
        self.value = value
        self.confidence = confidence
        self.status = status
        self.definitionVersion = definitionVersion
        self.cameraAngle = cameraAngle
    }
}

/// The manually logged (or video-measured) result of a kick, kept separate from the
/// pose-derived biomechanics. Unknown stays unknown; nothing is inferred from absence.
struct KickOutcomeSummary: Codable, Equatable, Sendable {
    /// FG/PAT result.
    var result: KickResult?
    var distanceYards: Double?
    var touchback: Bool?
    var outOfBounds: Bool?
    var landingZone: LandingZone?
    var landingYardLine: Double?
    var hangTimeSeconds: Double?

    init(result: KickResult? = nil, distanceYards: Double? = nil, touchback: Bool? = nil, outOfBounds: Bool? = nil,
         landingZone: LandingZone? = nil, landingYardLine: Double? = nil, hangTimeSeconds: Double? = nil) {
        self.result = result
        self.distanceYards = distanceYards
        self.touchback = touchback
        self.outOfBounds = outOfBounds
        self.landingZone = landingZone
        self.landingYardLine = landingYardLine
        self.hangTimeSeconds = hangTimeSeconds
    }
}

/// A kick plus its (current) analysis, flattened for learning. Storage-independent so
/// the whole personal model runs and is tested without SwiftData.
struct HistoricalKickAnalysis: Codable, Equatable, Sendable {
    var kickID: UUID
    var analysisID: UUID
    /// When the kick happened (used for recency, trends and baseline epochs).
    var kickDate: Date
    var kickType: KickType
    /// The kicking foot the analysis used. Nil when unknown: such kicks are never learned from.
    var kickingFoot: KickingFoot?
    /// True only for analyses that completed successfully.
    var analysisCompleted: Bool
    var outcome: KickOutcomeSummary
    var metrics: [KickMetricKey: HistoricalMetricValue]

    init(kickID: UUID = UUID(), analysisID: UUID = UUID(), kickDate: Date, kickType: KickType, kickingFoot: KickingFoot?,
         analysisCompleted: Bool = true, outcome: KickOutcomeSummary = KickOutcomeSummary(),
         metrics: [KickMetricKey: HistoricalMetricValue]) {
        self.kickID = kickID
        self.analysisID = analysisID
        self.kickDate = kickDate
        self.kickType = kickType
        self.kickingFoot = kickingFoot
        self.analysisCompleted = analysisCompleted
        self.outcome = outcome
        self.metrics = metrics
    }

    /// The camera angle most of this kick's measured metrics came from.
    var dominantCameraAngle: VideoAngleType? {
        var counts: [VideoAngleType: Int] = [:]
        for value in metrics.values where value.value != nil {
            counts[value.cameraAngle ?? .unknown, default: 0] += 1
        }
        return counts.sorted { a, b in a.value != b.value ? a.value > b.value : a.key.rawValue < b.key.rawValue }.first?.key
    }
}

/// The start of the athlete's active baseline for a kick type (a "technique era").
/// Kicks before `startsAt` stay stored and visible but are not learned from.
struct BaselineEpoch: Codable, Equatable, Sendable {
    var kickType: KickType
    /// 1 for the first reset, then 2, 3…
    var generation: Int
    var startsAt: Date
    var note: String?

    init(kickType: KickType, generation: Int, startsAt: Date, note: String? = nil) {
        self.kickType = kickType
        self.generation = generation
        self.startsAt = startsAt
        self.note = note
    }
}

/// Which kicks a profile describes.
struct PersonalizationScope: Codable, Equatable, Sendable {
    var kickType: KickType
    var kickingFoot: KickingFoot
    /// When set, metrics that depend on camera position only use videos from this angle.
    var cameraAngle: VideoAngleType?
    /// When set (field goals), only kicks in this distance bucket.
    var distanceBucket: DistanceBucket?
    /// When set, only kicks on or after the epoch's start.
    var epoch: BaselineEpoch?
    /// Never learn from this kick (the kick being coached).
    var excludingKickID: UUID?
    /// "Now" for recency and recent windows (passed in, so builds are reproducible).
    var now: Date

    init(kickType: KickType, kickingFoot: KickingFoot, cameraAngle: VideoAngleType? = nil, distanceBucket: DistanceBucket? = nil,
         epoch: BaselineEpoch? = nil, excludingKickID: UUID? = nil, now: Date) {
        self.kickType = kickType
        self.kickingFoot = kickingFoot
        self.cameraAngle = cameraAngle
        self.distanceBucket = distanceBucket
        self.epoch = epoch
        self.excludingKickID = excludingKickID
        self.now = now
    }
}

// MARK: - Success

enum KickSuccess: String, Codable, Sendable {
    case successful
    case unsuccessful
    /// No outcome, or not enough outcome data to judge. Never treated as either.
    case unknown
}

/// Decides whether a kick's logged outcome counts as successful.
protocol KickSuccessEvaluating: Sendable {
    func evaluate(_ kick: HistoricalKickAnalysis) -> KickSuccess
}

/// Field goals and PATs: made = successful, missed = unsuccessful, unknown excluded
/// (blocked excluded unless configured). Kickoffs and punts: only with configured
/// criteria, and only when every field the criteria need is known.
struct StandardKickSuccessEvaluator: KickSuccessEvaluating {
    var configuration: PersonalizationConfiguration

    init(configuration: PersonalizationConfiguration) {
        self.configuration = configuration
    }

    func evaluate(_ kick: HistoricalKickAnalysis) -> KickSuccess {
        let o = kick.outcome
        switch kick.kickType {
        case .fieldGoal, .pat:
            switch o.result {
            case .made: return .successful
            case .missedLeft, .missedRight, .short, .missedOther: return .unsuccessful
            case .blocked: return configuration.blockedCountsAsMiss ? .unsuccessful : .unknown
            case .unknown, .none: return .unknown
            }
        case .kickoff:
            guard let criteria = configuration.kickoffSuccess else { return .unknown }
            if criteria.outOfBoundsIsFailure, o.outOfBounds == true { return .unsuccessful }
            if criteria.touchbackIsSuccess, o.touchback == true { return .successful }
            return Self.meets(distance: o.distanceYards, minimumDistance: criteria.minimumDistanceYards,
                              hangTime: o.hangTimeSeconds, minimumHangTime: criteria.minimumHangTimeSeconds)
        case .punt:
            guard let criteria = configuration.puntSuccess else { return .unknown }
            return Self.meets(distance: o.distanceYards, minimumDistance: criteria.minimumDistanceYards,
                              hangTime: o.hangTimeSeconds, minimumHangTime: criteria.minimumHangTimeSeconds)
        case .unknown:
            return .unknown
        }
    }

    /// Successful when every configured minimum is met; unknown if a needed value is
    /// missing or nothing is configured.
    static func meets(distance: Double?, minimumDistance: Double?, hangTime: Double?, minimumHangTime: Double?) -> KickSuccess {
        guard minimumDistance != nil || minimumHangTime != nil else { return .unknown }
        var allMet = true
        if let minimumDistance {
            guard let distance else { return .unknown }
            allMet = allMet && distance >= minimumDistance
        }
        if let minimumHangTime {
            guard let hangTime else { return .unknown }
            allMet = allMet && hangTime >= minimumHangTime
        }
        return allMet ? .successful : .unsuccessful
    }
}
