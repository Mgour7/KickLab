import Foundation
import SwiftData

extension HistoricalKickAnalysis {
    /// A stored analysis of a stored kick, flattened for the personal model. Metric
    /// values, confidences, definition versions and camera angles come from the stored
    /// metrics; the outcome from the kick's own (manual or measured) outcome columns.
    init(analysis: BiomechanicsAnalysis, kick: Kick, kickingFoot: KickingFoot?) {
        var metrics: [KickMetricKey: HistoricalMetricValue] = [:]
        for metric in analysis.metrics ?? [] {
            guard let key = KickMetricKey(rawValue: metric.metricKey) else { continue }
            metrics[key] = HistoricalMetricValue(
                value: metric.value, confidence: metric.confidence, status: metric.measurementStatus,
                definitionVersion: metric.metricDefinitionVersion, cameraAngle: metric.sourceAngle
            )
        }
        self.init(
            kickID: kick.id,
            analysisID: analysis.id,
            kickDate: kick.timestamp,
            kickType: kick.kickType,
            kickingFoot: kickingFoot,
            analysisCompleted: analysis.processingStatus == .completed,
            outcome: KickOutcomeSummary(
                result: KickResult(optionalStoredValue: kick.storedResult),
                distanceYards: kick.distanceYards,
                touchback: kick.touchback,
                outOfBounds: kick.outOfBounds,
                landingZone: LandingZone(optionalStoredValue: kick.storedLandingZone),
                landingYardLine: kick.landingYardLine,
                hangTimeSeconds: kick.hangTimeSeconds
            ),
            metrics: metrics
        )
    }
}

extension StoredObservationRecord {
    init(observation o: CoachingObservation) {
        self.init(id: o.id, kind: o.kind, category: o.category, message: o.message, severity: o.severity,
                  confidence: o.confidence, priority: o.priority, ruleKey: o.ruleKey,
                  relatedObservationID: o.relatedObservationID, evidenceMetricKeys: o.evidenceMetricKeys)
    }
}

/// Connects the stored kicks to the personal model. Profiles are computed on demand from
/// the stored analyses every time (nothing learned is cached), so adding, editing or
/// deleting a kick is reflected on the next build and old analyses are never rewritten.
@MainActor
struct AthleteLearningService {
    let configuration: PersonalizationConfiguration
    let model: any AthleteLearningModel
    let profiles: any BiomechanicsProfileProviding
    let state: any PersonalizationStateStoring

    init(
        state: any PersonalizationStateStoring,
        configuration: PersonalizationConfiguration = PersonalizationConfiguration(),
        model: any AthleteLearningModel = StatisticalAthleteLearningModel(),
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles()
    ) {
        self.state = state
        self.configuration = configuration
        self.model = model
        self.profiles = profiles
    }

    /// The foot an analysis used: the athlete's foot at the time it ran.
    func kickingFoot(for analysis: BiomechanicsAnalysis, athlete: Athlete) -> KickingFoot {
        state.state(for: athlete.id).kickingFoot(at: analysis.createdAt, current: athlete.kickingFoot)
    }

    /// Every kick's current, completed analysis (one per kick), for learning.
    func history(for athlete: Athlete) -> [HistoricalKickAnalysis] {
        (athlete.kicks ?? []).compactMap { kick in
            guard let analysis = (kick.analyses ?? []).first(where: { $0.isCurrent && $0.processingStatus == .completed }) else { return nil }
            return HistoricalKickAnalysis(analysis: analysis, kick: kick, kickingFoot: kickingFoot(for: analysis, athlete: athlete))
        }
    }

    /// The analysis to coach, flattened.
    func current(_ analysis: BiomechanicsAnalysis) -> HistoricalKickAnalysis? {
        guard let kick = analysis.kick, let athlete = kick.athlete else { return nil }
        return HistoricalKickAnalysis(analysis: analysis, kick: kick, kickingFoot: kickingFoot(for: analysis, athlete: athlete))
    }

    /// The stored Step 8 observations of an analysis.
    func generalFindings(_ analysis: BiomechanicsAnalysis) -> [GeneralRuleFinding] {
        GeneralRuleFinding.from(stored: (analysis.observations ?? []).map(StoredObservationRecord.init(observation:)))
    }

    /// Personalized coaching for a completed analysis using everything KickLab knows now
    /// (the kick itself is never part of its own comparison). Nil for other analyses.
    func coaching(for analysis: BiomechanicsAnalysis, now: Date = .now) throws -> (report: PersonalizedCoachingReport, selection: PersonalProfileSelection?)? {
        guard analysis.processingStatus == .completed, let current = current(analysis),
              let athlete = analysis.kick?.athlete else { return nil }
        let epoch = state.state(for: athlete.id).activeEpoch(for: current.kickType)
        return try PersonalCoachingEngine.report(
            analysisID: analysis.id, current: current, history: history(for: athlete),
            generalFindings: generalFindings(analysis), epoch: epoch, now: now,
            model: model, profiles: profiles, configuration: configuration
        )
    }

    /// The snapshot to store with a newly completed analysis.
    func artifact(for analysis: BiomechanicsAnalysis, now: Date = .now) throws -> PersonalizationArtifact? {
        guard let current = current(analysis), let result = try coaching(for: analysis, now: now) else { return nil }
        return PersonalizationArtifact(
            analysisID: analysis.id, kickID: current.kickID, createdAt: now, modelVersion: model.modelVersion,
            configuration: configuration, current: current, selection: result.selection, report: result.report
        )
    }
}

/// Writes `personalization-v1.json` for each newly completed analysis: what KickLab
/// knew at that moment. Failures never fail the analysis itself.
@MainActor
struct PersonalizationRecorder {
    let learning: AthleteLearningService
    let artifactStore: AnalysisArtifactStore

    /// Returns true when the snapshot was written.
    @discardableResult
    func record(_ analysis: BiomechanicsAnalysis, now: Date = .now) -> Bool {
        guard let directory = analysis.artifactsRelativePath,
              let artifact = try? learning.artifact(for: analysis, now: now) else { return false }
        return (try? artifactStore.writePersonalization(artifact, in: directory)) != nil
    }

    /// The snapshot stored with an analysis, if any.
    func snapshot(for analysis: BiomechanicsAnalysis) -> PersonalizationArtifact? {
        guard let directory = analysis.artifactsRelativePath else { return nil }
        return try? artifactStore.readPersonalization(in: directory)
    }
}
