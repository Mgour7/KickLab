import Foundation

// Extension point for a future expert / peer reference dataset (successful high-school,
// college and professional kickers). Nothing is populated: KickLab ships no reference
// numbers until a real, sourced dataset exists. No fabricated NFL or college data.

/// Who an athlete can be compared with.
enum ComparisonGroup: String, Codable, Sendable {
    /// The athlete's own history.
    case athleteHistory
    /// The athlete's own successful kicks.
    case athleteSuccessful
    /// Successful kickers like this athlete.
    case successfulPeers
    /// A position / competition-level reference.
    case levelReference
}

/// Statistics of one metric in a reference dataset.
struct ReferenceMetricStatistics: Codable, Equatable, Sendable {
    var sampleCount: Int
    var mean: Double
    var median: Double
    var standardDeviation: Double
    var lowerQuartile: Double
    var upperQuartile: Double
}

/// A reference group's mechanics, with the metadata needed to use it honestly.
struct BiomechanicsReferenceProfile: Codable, Equatable, Sendable {
    var id: String
    var group: ComparisonGroup
    var kickType: KickType
    var competitionLevel: PlayingLevel?
    /// e.g. "16–18"; nil when not applicable.
    var ageGroup: String?
    var kickingFoot: KickingFoot?
    /// Number of kickers (not kicks) in the dataset.
    var athleteCount: Int
    var kickCount: Int
    /// Where the numbers came from (citation or dataset name).
    var source: String
    var version: String
    /// Must match the Step 8 metric definition versions it was measured with.
    var metricDefinitionVersions: [KickMetricKey: Int]
    var metrics: [KickMetricKey: ReferenceMetricStatistics]

    /// A reference is only usable with a real source, real samples and matching definitions.
    var isUsable: Bool {
        !source.trimmingCharacters(in: .whitespaces).isEmpty && athleteCount > 0 && kickCount > 0 && !metrics.isEmpty
            && metrics.keys.allSatisfy { metricDefinitionVersions[$0] == $0.definition.definitionVersion }
    }
}

struct ReferenceQuery: Codable, Equatable, Sendable {
    var kickType: KickType
    var kickingFoot: KickingFoot?
    var competitionLevel: PlayingLevel?
    var groups: [ComparisonGroup]
}

/// Supplies reference profiles. Step 10 ships only `NoBiomechanicsReferences`.
protocol BiomechanicsReferenceProviding: Sendable {
    func references(for query: ReferenceQuery) -> [BiomechanicsReferenceProfile]
}

/// The shipped provider: no reference data.
struct NoBiomechanicsReferences: BiomechanicsReferenceProviding {
    init() {}

    func references(for query: ReferenceQuery) -> [BiomechanicsReferenceProfile] { [] }
}
