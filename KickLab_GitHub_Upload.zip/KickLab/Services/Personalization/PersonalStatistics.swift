import Foundation

/// One eligible measurement of a metric, from one kick.
struct PersonalSample: Codable, Equatable, Sendable {
    var kickID: UUID
    var analysisID: UUID
    var date: Date
    var value: Double
    var confidence: Double
    var success: KickSuccess
}

/// Summary statistics of a set of samples. Standard deviation is the sample SD (n − 1);
/// robust spread is 1.4826 × the median absolute deviation (comparable to an SD, but
/// not pulled around by one odd kick). Quartiles use linear interpolation.
struct MetricDistribution: Codable, Equatable, Sendable {
    var count: Int
    var mean: Double
    var median: Double
    var standardDeviation: Double
    var robustSpread: Double
    var minimum: Double
    var maximum: Double
    var lowerQuartile: Double
    var upperQuartile: Double
    var meanConfidence: Double
    var firstDate: Date
    var lastDate: Date

    /// Nil for no samples.
    init?(_ samples: [PersonalSample]) {
        guard !samples.isEmpty else { return nil }
        let values = samples.map(\.value)
        let sorted = values.sorted()
        count = values.count
        mean = PersonalStatistics.mean(values)
        let median = PersonalStatistics.quantile(sorted, 0.5)
        let deviations: [Double] = values.map { abs($0 - median) }.sorted()
        self.median = median
        standardDeviation = PersonalStatistics.sampleStandardDeviation(values)
        robustSpread = 1.4826 * PersonalStatistics.quantile(deviations, 0.5)
        minimum = sorted[0]
        maximum = sorted[sorted.count - 1]
        lowerQuartile = PersonalStatistics.quantile(sorted, 0.25)
        upperQuartile = PersonalStatistics.quantile(sorted, 0.75)
        meanConfidence = PersonalStatistics.round3(PersonalStatistics.mean(samples.map(\.confidence)))
        let dates = samples.map(\.date)
        firstDate = dates.min() ?? samples[0].date
        lastDate = dates.max() ?? samples[0].date
    }
}

enum PersonalStatistics {
    static func round3(_ x: Double) -> Double { (x * 1000).rounded() / 1000 }

    static func mean(_ values: [Double]) -> Double {
        values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
    }

    /// Sample standard deviation (n − 1); 0 for fewer than two values.
    static func sampleStandardDeviation(_ values: [Double]) -> Double {
        guard values.count > 1 else { return 0 }
        let m = mean(values)
        let squares = values.map { ($0 - m) * ($0 - m) }
        return (squares.reduce(0, +) / Double(values.count - 1)).squareRoot()
    }

    /// Linear-interpolation quantile of already sorted values (q in 0...1).
    static func quantile(_ sorted: [Double], _ q: Double) -> Double {
        guard !sorted.isEmpty else { return 0 }
        let position = q * Double(sorted.count - 1)
        let lower = Int(position.rounded(.down))
        let upper = min(lower + 1, sorted.count - 1)
        let fraction = position - Double(lower)
        return sorted[lower] + (sorted[upper] - sorted[lower]) * fraction
    }

    /// Weight of a sample `ageDays` old: 0.5^(age ÷ half-life). Future dates count as age 0.
    static func recencyWeight(ageDays: Double, halfLifeDays: Double) -> Double {
        guard halfLifeDays > 0 else { return 1 }
        return pow(0.5, max(0, ageDays) / halfLifeDays)
    }

    static func weightedMean(_ samples: [PersonalSample], now: Date, halfLifeDays: Double) -> Double? {
        guard !samples.isEmpty else { return nil }
        var total = 0.0
        var weights = 0.0
        for sample in samples {
            let w = recencyWeight(ageDays: now.timeIntervalSince(sample.date) / 86_400, halfLifeDays: halfLifeDays)
            total += w * sample.value
            weights += w
        }
        return weights > 0 ? total / weights : nil
    }

    /// Samples in deterministic order: oldest first, ties by analysis ID.
    static func ordered(_ samples: [PersonalSample]) -> [PersonalSample] {
        samples.sorted { a, b in
            a.date != b.date ? a.date < b.date : a.analysisID.uuidString < b.analysisID.uuidString
        }
    }
}
