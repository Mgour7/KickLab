import Foundation

/// Where the "recent" numbers of a baseline came from.
enum RecentWindowSource: String, Codable, Sendable {
    /// The last `recentKickCount` eligible kicks.
    case lastKicks
    /// Too few kicks: the lifetime numbers are used instead.
    case lifetimeFallback
}

/// Values a metric was not learned from, and why (for explanations).
struct MetricExclusionCounts: Codable, Equatable, Sendable {
    var unavailable = 0
    var lowConfidence = 0
    var differentCameraAngle = 0
    var incompatibleDefinition = 0

    var total: Int { unavailable + lowConfidence + differentCameraAngle + incompatibleDefinition }
}

/// What the athlete's successful kicks look like for one metric.
struct SuccessfulKickProfile: Codable, Equatable, Sendable {
    var successful: MetricDistribution
    /// The same metric on unsuccessful kicks, when there are any.
    var unsuccessful: MetricDistribution?
    /// The athlete's "successful range": the middle half of successful values (quartiles),
    /// widened to at least ± half the metric's minimum meaningful difference around the median.
    var rangeLow: Double
    var rangeHigh: Double
    /// Enough successful kicks for the pattern to outweigh a general rule.
    var isStrong: Bool

    func contains(_ value: Double) -> Bool { value >= rangeLow && value <= rangeHigh }

    static func make(successful: [PersonalSample], unsuccessful: [PersonalSample], traits: PersonalMetricTraits,
                     configuration: PersonalizationConfiguration) -> SuccessfulKickProfile? {
        guard successful.count >= configuration.minimumSuccessfulSamples, let distribution = MetricDistribution(successful) else { return nil }
        let half = traits.minimumMeaningfulDifference / 2
        return SuccessfulKickProfile(
            successful: distribution,
            unsuccessful: MetricDistribution(unsuccessful),
            rangeLow: min(distribution.lowerQuartile, distribution.median - half),
            rangeHigh: max(distribution.upperQuartile, distribution.median + half),
            isStrong: successful.count >= configuration.strongSuccessfulPatternSamples
        )
    }
}

enum MetricTrendDirection: String, Codable, Sendable {
    case rising
    case falling
    /// Recent values are within normal variation of earlier ones.
    case stable
    case insufficientData
}

enum MetricTrendAssessment: String, Codable, Sendable {
    case improving
    case worsening
    /// Changing, but no direction is better for this metric, or not changing.
    case neutral
    case notAssessed
}

/// What "better" means when judging a trend.
enum MetricTarget: Codable, Equatable, Sendable {
    /// Toward the athlete's successful-kick median (preferred when it exists).
    case successfulMedian(Double)
    case higher
    case lower
    /// Toward the Step 8 ideal band.
    case band(ScoreBand)
    case none

    /// Lower is better.
    func badness(_ value: Double) -> Double? {
        switch self {
        case .successfulMedian(let median): abs(value - median)
        case .higher: -value
        case .lower: value
        case .band(let band): band.distanceFromIdeal(value)
        case .none: nil
        }
    }

    var basisName: String {
        switch self {
        case .successfulMedian: "successfulPattern"
        case .higher, .lower: "generalDirection"
        case .band: "generalRange"
        case .none: "none"
        }
    }
}

/// Recent kicks vs the kicks before them. A change counts only when it is at least the
/// metric's minimum meaningful difference AND `trendStandardErrors` standard errors.
struct MetricTrendSummary: Codable, Equatable, Sendable {
    var direction: MetricTrendDirection
    var assessment: MetricTrendAssessment
    var recentMean: Double?
    var previousMean: Double?
    var change: Double?
    var recentCount: Int
    var previousCount: Int
    var targetBasis: String

    static func make(_ ordered: [PersonalSample], traits: PersonalMetricTraits, target: MetricTarget,
                     configuration: PersonalizationConfiguration) -> MetricTrendSummary {
        let n = ordered.count
        let recentCount = min(configuration.recentKickCount, n / 2)
        guard n >= configuration.minimumTrendSamples, recentCount >= 3, n - recentCount >= 3 else {
            return MetricTrendSummary(direction: .insufficientData, assessment: .notAssessed, recentMean: nil, previousMean: nil,
                                      change: nil, recentCount: 0, previousCount: 0, targetBasis: target.basisName)
        }
        let recent = ordered.suffix(recentCount).map(\.value)
        let previous = ordered.prefix(n - recentCount).map(\.value)
        let recentMean = PersonalStatistics.mean(recent)
        let previousMean = PersonalStatistics.mean(previous)
        let change = recentMean - previousMean
        let s1 = PersonalStatistics.sampleStandardDeviation(recent)
        let s2 = PersonalStatistics.sampleStandardDeviation(previous)
        let standardError = (s1 * s1 / Double(recent.count) + s2 * s2 / Double(previous.count)).squareRoot()
        let meaningful = abs(change) >= traits.minimumMeaningfulDifference
        let significant = abs(change) >= configuration.trendStandardErrors * standardError
        let direction: MetricTrendDirection = (meaningful && significant) ? (change > 0 ? .rising : .falling) : .stable
        var assessment = MetricTrendAssessment.neutral
        if direction != .stable, let before = target.badness(previousMean), let after = target.badness(recentMean) {
            if after < before { assessment = .improving } else if after > before { assessment = .worsening }
        }
        return MetricTrendSummary(direction: direction, assessment: assessment, recentMean: recentMean, previousMean: previousMean,
                                  change: change, recentCount: recent.count, previousCount: previous.count, targetBasis: target.basisName)
    }
}

/// Everything the personal model knows about one metric for one scope.
struct PersonalMetricBaseline: Codable, Equatable, Sendable {
    var key: KickMetricKey
    var unit: MetricUnit
    var definitionVersion: Int
    var maturity: ProfileMaturity
    var sampleCount: Int { lifetime.count }
    /// Every eligible kick in the scope (the lifetime baseline).
    var lifetime: MetricDistribution
    /// The recent baseline (last `recentKickCount` kicks), or lifetime when too few.
    var recent: MetricDistribution
    var recentSource: RecentWindowSource
    /// The last `recentDays` days, when that window has enough samples.
    var lastDays: MetricDistribution?
    /// Recency-weighted mean: what the athlete "normally does" now.
    var recencyWeightedMean: Double
    /// The spread deviations are measured in: the lifetime robust spread, at least the
    /// metric's minimum meaningful difference.
    var deviationScale: Double
    var successfulPattern: SuccessfulKickProfile?
    var trend: MetricTrendSummary
    var consistency: ConsistencyProfile
    var excluded: MetricExclusionCounts

    /// The value used as "your normal".
    var normal: Double { recencyWeightedMean }

    /// (value − reference) ÷ deviationScale.
    func scaledDeviation(_ value: Double, from reference: Double) -> Double {
        (value - reference) / deviationScale
    }

    static func make(key: KickMetricKey, samples unordered: [PersonalSample], excluded: MetricExclusionCounts,
                     generalProfile: BiomechanicsProfile, now: Date,
                     configuration: PersonalizationConfiguration) -> PersonalMetricBaseline? {
        let samples = PersonalStatistics.ordered(unordered)
        guard let lifetime = MetricDistribution(samples) else { return nil }
        let traits = configuration.traits(key)
        let definition = key.definition

        let recentSamples = Array(samples.suffix(configuration.recentKickCount))
        let recent: MetricDistribution
        let recentSource: RecentWindowSource
        if recentSamples.count >= configuration.minimumRecentSamples, recentSamples.count < samples.count,
           let distribution = MetricDistribution(recentSamples) {
            recent = distribution
            recentSource = .lastKicks
        } else {
            recent = lifetime
            recentSource = .lifetimeFallback
        }
        let windowStart = now.addingTimeInterval(-Double(configuration.recentDays) * 86_400)
        let daySamples = samples.filter { $0.date >= windowStart }
        let lastDays = daySamples.count >= configuration.minimumRecentSamples ? MetricDistribution(daySamples) : nil

        let successful = samples.filter { $0.success == .successful }
        let unsuccessful = samples.filter { $0.success == .unsuccessful }
        let pattern = SuccessfulKickProfile.make(successful: successful, unsuccessful: unsuccessful, traits: traits, configuration: configuration)

        let target = Self.target(for: key, pattern: pattern, generalProfile: generalProfile)
        return PersonalMetricBaseline(
            key: key,
            unit: definition.unit,
            definitionVersion: definition.definitionVersion,
            maturity: configuration.maturity.level(for: lifetime.count),
            lifetime: lifetime,
            recent: recent,
            recentSource: recentSource,
            lastDays: lastDays,
            recencyWeightedMean: PersonalStatistics.weightedMean(samples, now: now, halfLifeDays: configuration.recencyHalfLifeDays) ?? lifetime.mean,
            deviationScale: max(lifetime.robustSpread, traits.minimumMeaningfulDifference),
            successfulPattern: pattern,
            trend: MetricTrendSummary.make(samples, traits: traits, target: target, configuration: configuration),
            consistency: ConsistencyProfile.make(samples, pattern: pattern, traits: traits, configuration: configuration),
            excluded: excluded
        )
    }

    /// The athlete's successful median when known; otherwise the Step 8 direction or band.
    static func target(for key: KickMetricKey, pattern: SuccessfulKickProfile?, generalProfile: BiomechanicsProfile) -> MetricTarget {
        if let pattern { return .successfulMedian(pattern.successful.median) }
        switch key.definition.betterDirection {
        case .higher: return .higher
        case .lower: return .lower
        case .towardIdealBand: return generalProfile.scoring[key].map { .band($0.band) } ?? .none
        case .none: return .none
        }
    }
}
