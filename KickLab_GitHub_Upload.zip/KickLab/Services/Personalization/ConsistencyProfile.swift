import Foundation

enum ConsistencyLevel: String, Codable, Sendable {
    case highlyRepeatable
    case typical
    case variable
    /// Too few kicks, or repeatability isn't a meaningful goal for this metric.
    case notAssessed
}

enum ConsistencyChange: String, Codable, Sendable {
    case moreConsistent
    case lessConsistent
    case unchanged
    case insufficientData
}

enum ConsistencyBasis: String, Codable, Sendable {
    /// Repeatability of the athlete's successful kicks (preferred).
    case successfulKicks
    /// All eligible kicks (used until there are enough successful ones).
    case allKicks
}

/// How repeatable a metric is.
///
/// - Score = 1 − SD ÷ `consistencyScale`, clamped to 0…1 (1 = identical every kick).
///   ≥ `highlyRepeatableScore` is highly repeatable, ≤ `variableScore` is variable.
/// - Recent change compares the SD of the last `recentKickCount` kicks with the SD of
///   up to `previousConsistencyKickCount` kicks before them.
/// - Metrics whose traits say repeatability isn't meaningful are never scored, so lower
///   variation is not automatically treated as better.
struct ConsistencyProfile: Codable, Equatable, Sendable {
    var basis: ConsistencyBasis?
    var sampleCount: Int
    var standardDeviation: Double?
    var robustSpread: Double?
    var score: Double?
    var level: ConsistencyLevel
    var recentStandardDeviation: Double?
    var previousStandardDeviation: Double?
    var recentCount: Int
    var previousCount: Int
    var change: ConsistencyChange
    /// Of the last `recentKickCount` kicks, how many were inside the successful range.
    var recentWithinSuccessfulRange: Int?
    var recentChecked: Int?

    static func make(_ ordered: [PersonalSample], pattern: SuccessfulKickProfile?, traits: PersonalMetricTraits,
                     configuration: PersonalizationConfiguration) -> ConsistencyProfile {
        var profile = ConsistencyProfile(basis: nil, sampleCount: 0, standardDeviation: nil, robustSpread: nil, score: nil,
                                         level: .notAssessed, recentStandardDeviation: nil, previousStandardDeviation: nil,
                                         recentCount: 0, previousCount: 0, change: .insufficientData,
                                         recentWithinSuccessfulRange: nil, recentChecked: nil)
        if let pattern {
            let recent = ordered.suffix(configuration.recentKickCount)
            profile.recentChecked = recent.count
            profile.recentWithinSuccessfulRange = recent.filter { pattern.contains($0.value) }.count
        }
        guard traits.repeatabilityMeaningful else { return profile }

        let successful = ordered.filter { $0.success == .successful }
        let basisSamples: [PersonalSample]
        if successful.count >= configuration.minimumConsistencySamples {
            profile.basis = .successfulKicks
            basisSamples = successful
        } else if ordered.count >= configuration.minimumConsistencySamples {
            profile.basis = .allKicks
            basisSamples = ordered
        } else {
            return profile
        }
        let distribution = MetricDistribution(basisSamples)
        let sd = distribution?.standardDeviation ?? 0
        profile.sampleCount = basisSamples.count
        profile.standardDeviation = sd
        profile.robustSpread = distribution?.robustSpread
        let score = PersonalStatistics.round3(min(1, max(0, 1 - sd / traits.consistencyScale)))
        profile.score = score
        if score >= configuration.highlyRepeatableScore {
            profile.level = .highlyRepeatable
        } else if score <= configuration.variableScore {
            profile.level = .variable
        } else {
            profile.level = .typical
        }

        // Recent vs previous repeatability (all kicks, oldest first).
        let recentCount = min(configuration.recentKickCount, ordered.count)
        let recent = ordered.suffix(recentCount).map(\.value)
        let previous = ordered.dropLast(recentCount).suffix(configuration.previousConsistencyKickCount).map(\.value)
        profile.recentCount = recent.count
        profile.previousCount = previous.count
        guard recent.count >= configuration.minimumConsistencySamples, previous.count >= configuration.minimumConsistencySamples else {
            return profile
        }
        let recentSD = PersonalStatistics.sampleStandardDeviation(recent)
        let previousSD = PersonalStatistics.sampleStandardDeviation(previous)
        profile.recentStandardDeviation = recentSD
        profile.previousStandardDeviation = previousSD
        let meaningful = abs(recentSD - previousSD) >= traits.minimumMeaningfulDifference / 2
        if meaningful, recentSD <= configuration.consistencyChangeRatio * previousSD {
            profile.change = .moreConsistent
        } else if meaningful, recentSD * configuration.consistencyChangeRatio >= previousSD {
            profile.change = .lessConsistent
        } else {
            profile.change = .unchanged
        }
        return profile
    }
}
