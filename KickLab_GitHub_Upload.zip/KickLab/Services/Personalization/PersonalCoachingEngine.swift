import Foundation

/// The profiles used for one kick: the overall profile for its scope, and a distance-
/// bucket profile for field goals once that bucket has enough kicks.
struct PersonalProfileSelection: Codable, Equatable, Sendable {
    var overall: AthleteBiomechanicsProfile
    var distanceBucket: AthleteBiomechanicsProfile?

    /// The bucket profile when it is mature enough, otherwise the overall profile.
    var active: AthleteBiomechanicsProfile { distanceBucket ?? overall }
    var usesDistanceProfile: Bool { distanceBucket != nil }
}

/// End to end, storage-independent: history + current kick → profiles → coaching report.
enum PersonalCoachingEngine {
    /// Builds the comparison profiles for `current` from `history` (the current kick is
    /// always excluded, so a kick is never compared with itself).
    static func profiles(
        for current: HistoricalKickAnalysis,
        history: [HistoricalKickAnalysis],
        epoch: BaselineEpoch?,
        now: Date,
        model: any AthleteLearningModel,
        configuration: PersonalizationConfiguration
    ) throws -> PersonalProfileSelection? {
        guard let foot = current.kickingFoot, current.kickType != .unknown else { return nil }
        let scope = PersonalizationScope(
            kickType: current.kickType, kickingFoot: foot, cameraAngle: current.dominantCameraAngle,
            epoch: epoch, excludingKickID: current.kickID, now: now
        )
        let overall = try model.buildProfile(from: history, scope: scope, configuration: configuration)
        var bucketProfile: AthleteBiomechanicsProfile?
        if current.kickType == .fieldGoal, let yards = current.outcome.distanceYards, let bucket = DistanceBucket.bucket(forYards: yards) {
            var bucketScope = scope
            bucketScope.distanceBucket = bucket
            let candidate = try model.buildProfile(from: history, scope: bucketScope, configuration: configuration)
            if candidate.eligibleKickCount >= configuration.distanceBucketMinimumKicks {
                bucketProfile = candidate
            }
        }
        return PersonalProfileSelection(overall: overall, distanceBucket: bucketProfile)
    }

    static func report(
        analysisID: UUID,
        current: HistoricalKickAnalysis,
        history: [HistoricalKickAnalysis],
        generalFindings: [GeneralRuleFinding],
        epoch: BaselineEpoch?,
        now: Date,
        model: any AthleteLearningModel = StatisticalAthleteLearningModel(),
        profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles(),
        configuration: PersonalizationConfiguration = PersonalizationConfiguration()
    ) throws -> (report: PersonalizedCoachingReport, selection: PersonalProfileSelection?) {
        let selection = try Self.profiles(for: current, history: history, epoch: epoch, now: now, model: model, configuration: configuration)
        let generalProfile = profiles.profile(for: BiomechanicsContext(
            kickType: current.kickType, kickingFoot: current.kickingFoot ?? .right, cameraAngle: current.dominantCameraAngle ?? .side
        ))
        let report = PersonalizedCoach.coach(PersonalCoachingInput(
            analysisID: analysisID, current: current, generalFindings: generalFindings, profile: selection?.active,
            usedDistanceProfile: selection?.usesDistanceProfile ?? false, generalProfile: generalProfile, configuration: configuration
        ))
        return (report, selection)
    }
}
