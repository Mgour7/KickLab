import Foundation

/// `personalization-v1.json`: what KickLab knew about the athlete when this kick was
/// analyzed — the comparison profile, the configuration and the ranked personal coaching.
///
/// Written once, after the analysis completes, next to the Step 7/8 artifacts. It is a
/// standalone, optional file: the Step 7/8 manifest (v2) and its readers are unchanged,
/// older analyses simply have no personalization file, and a file from a newer KickLab
/// (higher `formatVersion`) is refused instead of misread. Later rebuilds never edit it;
/// "how this kick compares now" is computed fresh from the stored analyses.
struct PersonalizationArtifact: VersionedArtifact, Equatable {
    static let kind = "kicklab.personalization"
    static let currentFormatVersion = 1
    static let fileName = "personalization-v1.json"

    var kind: String = PersonalizationArtifact.kind
    var formatVersion: Int = PersonalizationArtifact.currentFormatVersion
    var analysisID: UUID
    var kickID: UUID
    var createdAt: Date
    var modelVersion: String
    var coachVersion: String
    var configuration: PersonalizationConfiguration
    /// The kick being coached (its metrics and outcome as analyzed).
    var current: HistoricalKickAnalysis
    /// The profile the kick was compared with (nil when none could be built).
    var profile: AthleteBiomechanicsProfile?
    var usedDistanceProfile: Bool
    var report: PersonalizedCoachingReport

    init(analysisID: UUID, kickID: UUID, createdAt: Date, modelVersion: String, configuration: PersonalizationConfiguration,
         current: HistoricalKickAnalysis, selection: PersonalProfileSelection?, report: PersonalizedCoachingReport) {
        self.analysisID = analysisID
        self.kickID = kickID
        self.createdAt = createdAt
        self.modelVersion = modelVersion
        coachVersion = PersonalizedCoach.version
        self.configuration = configuration
        self.current = current
        profile = selection?.active
        usedDistanceProfile = selection?.usesDistanceProfile ?? false
        self.report = report
    }
}

extension AnalysisArtifactStore {
    /// Writes `personalization-v1.json` into an analysis directory (creating it if needed).
    func writePersonalization(_ artifact: PersonalizationArtifact, in directory: String) throws {
        let folder = try ManagedPath.url(for: directory, under: analysisRootURL)
        try fileSystem.createDirectory(at: folder)
        try AnalysisArtifactCoder.encode(artifact).write(to: folder.appendingPathComponent(PersonalizationArtifact.fileName), options: .atomic)
    }

    /// The personalization snapshot, or nil for analyses that have none (Step 7/8 sets).
    func readPersonalization(in directory: String) throws -> PersonalizationArtifact? {
        let folder: URL
        do {
            folder = try ManagedPath.url(for: directory, under: analysisRootURL)
        } catch {
            throw AnalysisArtifactError.invalidPath(directory)
        }
        let file = folder.appendingPathComponent(PersonalizationArtifact.fileName)
        guard fileSystem.itemExists(at: file) else { return nil }
        return try AnalysisArtifactCoder.decode(PersonalizationArtifact.self, from: Data(contentsOf: file))
    }
}
