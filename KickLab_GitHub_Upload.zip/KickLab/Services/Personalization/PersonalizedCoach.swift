import Foundation

// MARK: - Inputs

/// One Step 8 coaching observation, as the personalized coach sees it. Built from the
/// engine's `CoachingFinding`s at analysis time or from stored observations later.
struct GeneralRuleFinding: Codable, Equatable, Sendable {
    var ruleKey: String
    /// `.improve` or `.keep`.
    var kind: ObservationKind
    var category: AnalysisCategory
    /// The rule's main evidence metric, when known.
    var metric: KickMetricKey?
    var observed: String
    var whyItMatters: String?
    var cue: String?
    var severity: CoachingSeverity?
    var confidence: Double
    /// Step 8 rank within its kind (0 = first).
    var rank: Int

    init(ruleKey: String, kind: ObservationKind, category: AnalysisCategory, metric: KickMetricKey?, observed: String,
         whyItMatters: String? = nil, cue: String? = nil, severity: CoachingSeverity? = nil, confidence: Double, rank: Int = 0) {
        self.ruleKey = ruleKey
        self.kind = kind
        self.category = category
        self.metric = metric
        self.observed = observed
        self.whyItMatters = whyItMatters
        self.cue = cue
        self.severity = severity
        self.confidence = confidence
        self.rank = rank
    }

    /// The issued Step 8 findings.
    static func from(_ findings: [CoachingFinding]) -> [GeneralRuleFinding] {
        findings.filter(\.issued).map {
            GeneralRuleFinding(ruleKey: $0.rule.rawValue, kind: $0.kind, category: $0.category, metric: $0.evidence.first,
                               observed: $0.observed, whyItMatters: $0.whyItMatters, cue: $0.cue, severity: $0.severity,
                               confidence: $0.confidence, rank: $0.rank ?? 0)
        }
    }
}

struct PersonalCoachingInput: Sendable {
    var analysisID: UUID
    var current: HistoricalKickAnalysis
    var generalFindings: [GeneralRuleFinding]
    /// The profile the kick is compared with (nil when none could be built).
    var profile: AthleteBiomechanicsProfile?
    var usedDistanceProfile: Bool
    var generalProfile: BiomechanicsProfile
    var configuration: PersonalizationConfiguration
}

// MARK: - Output

enum CoachingEvidenceSource: String, Codable, Sendable, CaseIterable {
    case generalRule
    case personalBaseline
    case successfulPattern
    case outcomeRelationship
    case consistency
    case trend
}

/// One piece of evidence behind a finding, with its numbers (for the detail screen).
struct CoachingEvidence: Codable, Equatable, Sendable {
    var source: CoachingEvidenceSource
    var summary: String
    var values: [String: Double]
}

enum PersonalFindingKind: String, Codable, Sendable {
    case fix
    case strength
    case insight
}

enum PersonalFindingRole: String, Codable, Sendable {
    case primaryFix
    case strength
    /// Stored and explainable, but not promoted to the main coaching list.
    case secondary
}

/// How a finding was weighed against the Step 8 rules.
enum CoachingResolution: String, Codable, Sendable {
    /// Step 8 rule; personal evidence too weak or absent, so Step 8 stays primary.
    case generalOnly
    /// Step 8 rule; personal evidence exists but neither supports nor contradicts it.
    case generalKept
    /// Step 8 rule plus an association with less successful kicks: raised.
    case elevatedByOutcomes
    /// Step 8 rule plus a deviation from the athlete's successful pattern: raised.
    case reinforcedByPersonalPattern
    /// Step 8 rule, but the value matches an established successful personal pattern: lowered.
    case deEmphasizedBySuccessfulPattern
    /// Strong Step 8 warning that also matches a successful pattern: kept, slightly lowered.
    case keptDespiteSuccessfulPattern
    /// Personal evidence only.
    case personalOnly
}

/// The deterministic priority score and its parts. Each part is capped so no single
/// statistic can dominate.
struct PriorityBreakdown: Codable, Equatable, Sendable {
    var ruleSeverity = 0.0
    var personalDeviation = 0.0
    var outcome = 0.0
    var confidence = 0.0
    var maturity = 0.0
    var trend = 0.0
    var repeatability = 0.0
    var multiplier = 1.0

    var total: Double {
        let sum = ruleSeverity + personalDeviation + outcome + confidence + maturity + trend + repeatability
        return (sum * multiplier * 10).rounded() / 10
    }
}

/// The numbers a finding shows: this kick, your normal, your successful range.
struct FindingNumbers: Codable, Equatable, Sendable {
    var unit: MetricUnit
    var thisKick: Double?
    var yourNormal: Double?
    var successfulLow: Double?
    var successfulHigh: Double?
    var successfulMedian: Double?
    var successfulCount: Int?
    var generalIdealLow: Double?
    var generalIdealHigh: Double?
}

struct PersonalCoachingFinding: Codable, Equatable, Sendable, Identifiable {
    var id: UUID
    var kind: PersonalFindingKind
    var role: PersonalFindingRole
    var metric: KickMetricKey?
    var category: AnalysisCategory
    var headline: String
    var detail: String?
    var cue: String?
    /// Evidence sources, most important first.
    var sources: [CoachingEvidenceSource]
    var evidence: [CoachingEvidence]
    var resolution: CoachingResolution
    var rationale: String
    var priority: PriorityBreakdown
    var confidence: Double
    var confidenceLevel: PersonalizationConfidence.Level
    var generalRuleKey: String?
    var severity: CoachingSeverity?
    var numbers: FindingNumbers?
}

/// A comparison that could not be made, and why.
struct UnavailableComparison: Codable, Equatable, Sendable {
    enum Reason: String, Codable, Sendable {
        case differentCameraAngle
        case notEnoughComparableKicks
    }

    var metric: KickMetricKey
    var reason: Reason
}

/// The personalized coaching for one analyzed kick.
struct PersonalizedCoachingReport: Codable, Equatable, Sendable {
    var analysisID: UUID
    var kickID: UUID
    var kickType: KickType
    var coachVersion: String
    var modelVersion: String?
    var configurationVersion: Int
    var maturity: ProfileMaturity
    var comparableKickCount: Int
    /// Shown while the profile is not yet established.
    var learningMessage: String?
    var cameraAngle: VideoAngleType?
    var distanceBucket: DistanceBucket?
    var usedDistanceProfile: Bool
    var profileFingerprint: UUID?
    /// Every finding, ranked (primary fixes, strengths, then secondary).
    var findings: [PersonalCoachingFinding]
    var unavailableComparisons: [UnavailableComparison]

    var primaryFixes: [PersonalCoachingFinding] { findings.filter { $0.role == .primaryFix } }
    var strengths: [PersonalCoachingFinding] { findings.filter { $0.role == .strength } }
    var secondary: [PersonalCoachingFinding] { findings.filter { $0.role == .secondary } }
}

// MARK: - Coach

/// Combines Step 8 rules with the athlete's personal profile. It never drops a Step 8
/// observation: every one appears in the report, possibly re-ranked with its reason.
///
/// Conflict resolution for a Step 8 IMPROVE on metric m (first match wins):
/// 1. m's value sits on the side associated with less successful kicks → elevated.
/// 2. m deviates notably from the athlete's successful pattern → reinforced.
/// 3. m matches a strong successful pattern (or the side associated with success):
///    high severity → kept, slightly lowered; otherwise → de-emphasized (secondary).
/// 4. m's personal history is below "established" → Step 8 stays primary (generalOnly).
/// 5. otherwise → kept.
enum PersonalizedCoach {
    static let version = "personal-coach-1.1"
    /// Build 18: metrics that are measured and compared but never turned into technique
    /// advice, because no validated criterion says which value is better (plant timing
    /// rests on two estimated events and on no established "good" interval).
    static let noTechniqueAdvice: Set<KickMetricKey> = [.plantToContactTime]

    static func coach(_ input: PersonalCoachingInput) -> PersonalizedCoachingReport {
        let config = input.configuration
        let profile = input.profile
        var findings: [PersonalCoachingFinding] = []
        var unavailable: [UnavailableComparison] = []
        var handledGeneral = Set<String>()

        for key in KickMetricKey.allCases {
            guard let (value, confidence) = currentValue(key, in: input.current, configuration: config) else { continue }
            let baseline = profile?.baseline(key).flatMap { $0.maturity >= .emerging ? $0 : nil }
            if baseline == nil, let exclusions = profile?.metricExclusions[key], exclusions.differentCameraAngle > 0 {
                unavailable.append(UnavailableComparison(metric: key, reason: .differentCameraAngle))
            }
            let generals = input.generalFindings.filter { $0.metric == key }
            let assessment = baseline.map {
                Assessment(key: key, value: value, confidence: confidence, baseline: $0,
                           relationship: profile?.relationship(key), configuration: config, generalProfile: input.generalProfile)
            }

            // Value findings (fix), merged with any Step 8 IMPROVE on the same metric.
            // Build 18: metrics without a validated coaching criterion get no fix (they can
            // still be compared with the athlete's normal, as an insight without a cue).
            let advisable = !Self.noTechniqueAdvice.contains(key)
            let improve = generals.first { $0.kind == .improve }
            if advisable, let finding = valueFinding(key: key, value: value, confidence: confidence, general: improve,
                                          assessment: assessment, input: input) {
                findings.append(finding)
            }
            if let improve { handledGeneral.insert(improve.ruleKey) }

            if let assessment {
                if advisable, let finding = consistencyFinding(assessment, input: input) { findings.append(finding) }
                if let finding = insightFinding(assessment, input: input, hasValueFix: findings.contains { $0.metric == key && $0.kind == .fix }) {
                    findings.append(finding)
                }
            }

            // Strengths, merged with any Step 8 KEEP on the same metric.
            let keep = generals.first { $0.kind == .keep }
            if let finding = strengthFinding(key: key, value: value, confidence: confidence, general: keep, assessment: assessment, input: input) {
                findings.append(finding)
            }
            if let keep { handledGeneral.insert(keep.ruleKey) }
        }

        // Step 8 findings not tied to an eligible current metric are kept as they are.
        for general in input.generalFindings where !handledGeneral.contains(general.ruleKey) {
            findings.append(generalOnlyFinding(general, input: input))
        }

        let ranked = rank(findings, configuration: config)
        let maturity = profile?.maturity ?? .insufficient
        let count = profile?.eligibleKickCount ?? 0
        let needed = max(0, config.maturity.established - count)
        return PersonalizedCoachingReport(
            analysisID: input.analysisID,
            kickID: input.current.kickID,
            kickType: input.current.kickType,
            coachVersion: version,
            modelVersion: profile?.modelVersion,
            configurationVersion: config.version,
            maturity: maturity,
            comparableKickCount: count,
            learningMessage: maturity < .established ? PersonalCoachCopy.learningMessage(needed: needed) : nil,
            cameraAngle: profile?.scope.cameraAngle,
            distanceBucket: profile?.scope.distanceBucket,
            usedDistanceProfile: input.usedDistanceProfile,
            profileFingerprint: profile?.sourceFingerprint,
            findings: ranked,
            unavailableComparisons: unavailable
        )
    }

    // MARK: Per-metric assessment

    /// Personal facts about the current value of one metric.
    struct Assessment {
        var key: KickMetricKey
        var value: Double
        var confidence: Double
        var baseline: PersonalMetricBaseline
        var relationship: MetricOutcomeRelationship?
        var traits: PersonalMetricTraits
        var zNormal: Double
        var pattern: SuccessfulKickProfile?
        var zSuccess: Double?
        /// Notably outside the successful pattern, in the worse direction.
        var deviatesFromSuccess: Bool
        /// On the side of the values associated with less successful kicks.
        var onUnsuccessfulSide: Bool
        /// Notably different from "normal" and worse by the general reference.
        var awayFromNormalAndWorse: Bool
        var notablyDifferentFromNormal: Bool

        init(key: KickMetricKey, value: Double, confidence: Double, baseline: PersonalMetricBaseline,
             relationship: MetricOutcomeRelationship?, configuration: PersonalizationConfiguration, generalProfile: BiomechanicsProfile) {
            self.key = key
            self.value = value
            self.confidence = confidence
            self.baseline = baseline
            self.relationship = relationship?.isReportable == true ? relationship : nil
            traits = configuration.traits(key)
            let minimum = traits.minimumMeaningfulDifference
            zNormal = baseline.scaledDeviation(value, from: baseline.normal)
            pattern = baseline.successfulPattern
            if let pattern {
                let z = baseline.scaledDeviation(value, from: pattern.successful.median)
                zSuccess = z
                deviatesFromSuccess = !pattern.contains(value)
                    && abs(value - pattern.successful.median) >= minimum
                    && abs(z) >= configuration.notableDeviation
                    && PersonalizedCoach.isWorse(key, value: value, than: pattern.successful.median)
            } else {
                zSuccess = nil
                deviatesFromSuccess = false
            }
            if let r = self.relationship, let successfulMean = r.successfulMean {
                onUnsuccessfulSide = r.isOnUnsuccessfulSide(value) && abs(value - successfulMean) >= minimum
            } else {
                onUnsuccessfulSide = false
            }
            notablyDifferentFromNormal = abs(value - baseline.normal) >= minimum && abs(zNormal) >= configuration.notableDeviation
            var worseThanNormal = false
            if notablyDifferentFromNormal, PersonalizedCoach.isWorse(key, value: value, than: baseline.normal) {
                let target = PersonalMetricBaseline.target(for: key, pattern: nil, generalProfile: generalProfile)
                if let now = target.badness(value), let before = target.badness(baseline.normal) {
                    worseThanNormal = now - before >= minimum / 2
                }
            }
            awayFromNormalAndWorse = pattern == nil && worseThanNormal
        }

        /// The reference the personal wording compares against.
        var personalReference: (value: Double, label: String)? {
            if deviatesFromSuccess, let pattern { return (pattern.successful.median, "your best kicks") }
            if onUnsuccessfulSide, let mean = relationship?.successfulMean { return (mean, "") }
            if awayFromNormalAndWorse { return (baseline.normal, "your normal") }
            return nil
        }

        var maturityPoints: Double {
            switch baseline.maturity {
            case .insufficient: 0
            case .emerging: 3
            case .established: 6
            case .strong: 10
            }
        }
    }

    // MARK: Finding builders

    static func valueFinding(key: KickMetricKey, value: Double, confidence: Double, general: GeneralRuleFinding?,
                             assessment original: Assessment?, input: PersonalCoachingInput) -> PersonalCoachingFinding? {
        let config = input.configuration
        let kickType = input.current.kickType
        // When the Step 8 rule and the personal evidence point in opposite directions, the
        // general guidance stays and the personal value evidence is set aside for this kick,
        // so the athlete never gets two contradictory cues.
        var a = original
        var directionConflict = false
        if general != nil, let assessment = original, let reference = assessment.personalReference,
           let generalSaysHigh = generalDirection(key, value: value, generalProfile: input.generalProfile),
           generalSaysHigh != (value > reference.value) {
            directionConflict = true
            a = nil
        }
        let personalFix = a.map { $0.deviatesFromSuccess || $0.onUnsuccessfulSide || $0.awayFromNormalAndWorse } ?? false
        guard general != nil || personalFix else { return nil }

        var evidence: [CoachingEvidence] = []
        var sources: [CoachingEvidenceSource] = []
        var priority = PriorityBreakdown()
        var headline: String
        var detail: String?
        var cue: String?
        var resolution: CoachingResolution
        var rationale: String

        if let general {
            sources.append(.generalRule)
            evidence.append(CoachingEvidence(source: .generalRule, summary: general.observed, values: ["confidence": general.confidence]))
            priority.ruleSeverity = severityPoints(general.severity)
            priority.confidence = 10 * general.confidence
            headline = general.observed
            detail = general.whyItMatters
            cue = general.cue
        } else {
            priority.confidence = 10 * confidence
            headline = ""
        }

        if let a {
            let unit = a.baseline.unit
            if a.deviatesFromSuccess, let pattern = a.pattern, let z = a.zSuccess {
                sources.append(.successfulPattern)
                let n = pattern.successful.count
                evidence.append(CoachingEvidence(
                    source: .successfulPattern,
                    summary: "Your best \(n) \(PersonalCoachCopy.kicksNoun(kickType, count: n)) averaged \(PersonalCoachFormat.value(pattern.successful.mean, unit)); this kick was \(PersonalCoachFormat.value(value, unit)).",
                    values: ["thisKick": value, "successfulMedian": pattern.successful.median, "successfulMean": pattern.successful.mean,
                             "rangeLow": pattern.rangeLow, "rangeHigh": pattern.rangeHigh, "scaledDeviation": z,
                             "successfulCount": Double(n)]
                ))
                priority.personalDeviation = min(25, 8 * abs(z)) * (pattern.isStrong ? 1 : 0.6)
            }
            if a.onUnsuccessfulSide, let r = a.relationship, let s = r.successfulMean, let u = r.unsuccessfulMean, let effect = r.effectSize {
                sources.append(.outcomeRelationship)
                let words = PersonalCoachCopy.outcomeWords(kickType)
                let name = key.definition.displayName.lowercased()
                evidence.append(CoachingEvidence(
                    source: .outcomeRelationship,
                    summary: "In your recorded kicks, \(name) tends to be \(PersonalCoachFormat.value(s, unit)) on your \(words.good) and \(PersonalCoachFormat.value(u, unit)) on your \(words.bad). This kick was closer to your \(words.bad).",
                    values: ["successfulMean": s, "unsuccessfulMean": u, "effectSize": effect,
                             "successfulCount": Double(r.successfulCount), "unsuccessfulCount": Double(r.unsuccessfulCount)]
                ))
                priority.outcome = min(20, 10 * abs(effect))
            }
            if a.awayFromNormalAndWorse {
                sources.append(.personalBaseline)
                evidence.append(CoachingEvidence(
                    source: .personalBaseline,
                    summary: "Your normal is \(PersonalCoachFormat.value(a.baseline.normal, unit)); this kick was \(PersonalCoachFormat.value(value, unit)).",
                    values: ["thisKick": value, "normal": a.baseline.normal, "scaledDeviation": a.zNormal]
                ))
                priority.personalDeviation = max(priority.personalDeviation, min(10, 3 * abs(a.zNormal)))
            }
            if a.baseline.trend.assessment == .worsening {
                sources.append(.trend)
                evidence.append(trendEvidence(a, improving: false))
                priority.trend = 5
            }
            if sources.contains(where: { $0 != .generalRule }) { priority.maturity = a.maturityPoints }
        }

        // Resolution against Step 8.
        if let general {
            if let a, a.onUnsuccessfulSide {
                resolution = .elevatedByOutcomes
                rationale = PersonalCoachCopy.elevatedRationale
            } else if let a, a.deviatesFromSuccess {
                resolution = .reinforcedByPersonalPattern
                rationale = PersonalCoachCopy.reinforcedRationale
            } else if let a, matchesSuccess(a) {
                if general.severity == .high {
                    resolution = .keptDespiteSuccessfulPattern
                    rationale = PersonalCoachCopy.keptDespitePatternRationale
                    priority.multiplier = 0.75
                } else {
                    resolution = .deEmphasizedBySuccessfulPattern
                    rationale = PersonalCoachCopy.deEmphasizedRationale
                    priority.multiplier = 0.35
                }
                sources.append(.successfulPattern)
                if let pattern = a.pattern {
                    evidence.append(CoachingEvidence(
                        source: .successfulPattern,
                        summary: "Your successful kicks are usually \(PersonalCoachFormat.range(pattern.rangeLow, pattern.rangeHigh, a.baseline.unit)), and this kick was inside that range.",
                        values: ["thisKick": value, "rangeLow": pattern.rangeLow, "rangeHigh": pattern.rangeHigh,
                                 "successfulCount": Double(pattern.successful.count)]
                    ))
                }
                priority.maturity = a.maturityPoints
            } else if directionConflict {
                resolution = .generalKept
                rationale = PersonalCoachCopy.conflictingDirectionRationale
            } else if a == nil || (a?.baseline.maturity ?? .insufficient) < .established {
                resolution = .generalOnly
                rationale = PersonalCoachCopy.generalOnlyRationale
            } else {
                resolution = .generalKept
                rationale = "Based on general kicking mechanics; your own kicks don't change the picture."
            }
        } else {
            resolution = .personalOnly
            rationale = PersonalCoachCopy.personalOnlyRationale
        }

        // Personal wording when personal evidence drives the finding.
        if let a, let reference = a.personalReference, general == nil || resolution == .reinforcedByPersonalPattern || resolution == .elevatedByOutcomes {
            let higher = value > reference.value
            let z = a.baseline.scaledDeviation(value, from: reference.value)
            let phrase = PersonalCoachCopy.comparison(key, higher: higher, scaledDeviation: z, large: config.largeDeviation)
            if a.deviatesFromSuccess || a.awayFromNormalAndWorse {
                headline = "\(phrase) compared with \(reference.label)."
            } else {
                headline = "\(phrase) — closer to your \(PersonalCoachCopy.outcomeWords(kickType).bad) than your \(PersonalCoachCopy.outcomeWords(kickType).good)."
            }
            if general == nil {
                cue = PersonalCoachCopy.cue(key, higher: higher)
                detail = evidence.first { $0.source != .generalRule }?.summary
            } else if detail == nil {
                detail = evidence.first { $0.source != .generalRule }?.summary
            }
        }

        let findingConfidence: Double
        if let a, sources.contains(where: { $0 != .generalRule }) {
            findingConfidence = PersonalizationConfidence.personal(measurement: a.confidence, maturity: a.baseline.maturity)
        } else {
            findingConfidence = PersonalStatistics.round3(general?.confidence ?? confidence)
        }
        return PersonalCoachingFinding(
            id: DeterministicID.make(seed: input.analysisID, name: "personal|fix|" + key.rawValue),
            kind: .fix, role: .secondary, metric: key, category: general?.category ?? key.definition.category,
            headline: headline, detail: detail, cue: cue, sources: sources, evidence: evidence,
            resolution: resolution, rationale: rationale, priority: priority, confidence: findingConfidence,
            confidenceLevel: PersonalizationConfidence.level(findingConfidence), generalRuleKey: general?.ruleKey,
            severity: general?.severity, numbers: numbers(key, value: value, baseline: a?.baseline, generalProfile: input.generalProfile)
        )
    }

    static func consistencyFinding(_ a: Assessment, input: PersonalCoachingInput) -> PersonalCoachingFinding? {
        let c = a.baseline.consistency
        guard a.baseline.maturity >= .established, c.level != .notAssessed else { return nil }
        let noun = PersonalCoachCopy.phrases(a.key).noun
        let unit = a.baseline.unit
        var priority = PriorityBreakdown()
        let headline: String
        if c.change == .lessConsistent, let recentSD = c.recentStandardDeviation, let previousSD = c.previousStandardDeviation {
            headline = "Your \(noun) has varied more over your last \(c.recentCount) kicks than over your previous \(c.previousCount)."
            priority.repeatability = 8 + (c.level == .variable ? 12 : 0)
            return make(a, input: input, kind: .fix, tag: "consistency", headline: headline,
                        detail: "Recent spread \(PersonalCoachFormat.spread(recentSD, unit)) vs \(PersonalCoachFormat.spread(previousSD, unit)) before.",
                        cue: PersonalCoachCopy.consistencyCue(a.key), sources: [.consistency],
                        evidence: [consistencyEvidence(a)], priority: priority)
        }
        guard c.level == .variable, let sd = c.standardDeviation else { return nil }
        headline = "Your \(noun) changes a lot from kick to kick (typically \(PersonalCoachFormat.spread(sd, unit)))."
        priority.repeatability = 12
        return make(a, input: input, kind: .fix, tag: "consistency", headline: headline, detail: nil,
                    cue: PersonalCoachCopy.consistencyCue(a.key), sources: [.consistency],
                    evidence: [consistencyEvidence(a)], priority: priority)
    }

    /// "Different from your normal" without being worse, or a worsening trend with no
    /// value fix: stored as secondary insights, never as fixes.
    static func insightFinding(_ a: Assessment, input: PersonalCoachingInput, hasValueFix: Bool) -> PersonalCoachingFinding? {
        guard !hasValueFix else { return nil }
        if a.notablyDifferentFromNormal {
            let higher = a.value > a.baseline.normal
            let phrase = PersonalCoachCopy.comparison(a.key, higher: higher, scaledDeviation: a.zNormal, large: input.configuration.largeDeviation)
            var priority = PriorityBreakdown()
            priority.personalDeviation = min(10, 3 * abs(a.zNormal))
            return make(a, input: input, kind: .insight, tag: "normal", headline: "\(phrase) compared with your normal.",
                        detail: "Different from your normal isn't necessarily a problem; it isn't flagged unless it moves away from your successful kicks or the general range.",
                        cue: nil, sources: [.personalBaseline],
                        evidence: [CoachingEvidence(source: .personalBaseline,
                                                    summary: "Your normal is \(PersonalCoachFormat.value(a.baseline.normal, a.baseline.unit)); this kick was \(PersonalCoachFormat.value(a.value, a.baseline.unit)).",
                                                    values: ["thisKick": a.value, "normal": a.baseline.normal, "scaledDeviation": a.zNormal])],
                        priority: priority)
        }
        if a.baseline.trend.assessment == .worsening {
            var priority = PriorityBreakdown()
            priority.trend = 8
            let noun = PersonalCoachCopy.phrases(a.key).noun
            return make(a, input: input, kind: .insight, tag: "trend",
                        headline: "Your \(noun) has been moving away from \(targetText(a)) recently.",
                        detail: nil, cue: nil, sources: [.trend], evidence: [trendEvidence(a, improving: false)], priority: priority)
        }
        return nil
    }

    static func strengthFinding(key: KickMetricKey, value: Double, confidence: Double, general: GeneralRuleFinding?,
                                assessment a: Assessment?, input: PersonalCoachingInput) -> PersonalCoachingFinding? {
        let config = input.configuration
        var options: [(score: Double, headline: String, source: CoachingEvidenceSource, evidence: CoachingEvidence)] = []
        // Never call something a personal strength while it is a personal fix (a Step 8
        // KEEP is still reported as it is).
        let isPersonalFix = a.map { $0.deviatesFromSuccess || $0.onUnsuccessfulSide } ?? false
        if let a, a.baseline.maturity >= .established, !isPersonalFix {
            let noun = PersonalCoachCopy.phrases(key).noun
            let unit = a.baseline.unit
            let c = a.baseline.consistency
            if let pattern = a.pattern, pattern.contains(value), let within = c.recentWithinSuccessfulRange, let checked = c.recentChecked,
               checked >= config.minimumConsistencySamples, Double(within) / Double(checked) >= config.repeatableWithinShare {
                options.append((10 + 10 * Double(within) / Double(checked) + a.maturityPoints,
                                "Your \(noun) has stayed within your successful range on \(within) of your last \(checked) kicks.",
                                .successfulPattern,
                                CoachingEvidence(source: .successfulPattern,
                                                 summary: "Successful range \(PersonalCoachFormat.range(pattern.rangeLow, pattern.rangeHigh, unit)); this kick \(PersonalCoachFormat.value(value, unit)).",
                                                 values: ["within": Double(within), "checked": Double(checked), "rangeLow": pattern.rangeLow, "rangeHigh": pattern.rangeHigh])))
            }
            let inPattern = a.pattern.map { $0.contains(value) } ?? (abs(a.zNormal) < 1)
            if c.level == .highlyRepeatable, let sd = c.standardDeviation, let score = c.score, inPattern {
                let basis = c.basis == .successfulKicks ? "on your successful kicks" : "across your kicks"
                options.append((8 + 10 * score + a.maturityPoints,
                                "Your \(noun) is very repeatable: it varies only \(PersonalCoachFormat.spread(sd, unit)) \(basis).",
                                .consistency, consistencyEvidence(a)))
            }
            if c.change == .moreConsistent, inPattern {
                options.append((8 + a.maturityPoints, "Your \(noun) has become more consistent recently.", .consistency, consistencyEvidence(a)))
            }
            if a.baseline.trend.assessment == .improving {
                options.append((6 + a.maturityPoints, "Your \(noun) has been moving toward \(targetText(a)) recently.", .trend, trendEvidence(a, improving: true)))
            }
        }
        if let general {
            options.append((15 + 10 * general.confidence, general.observed, .generalRule,
                            CoachingEvidence(source: .generalRule, summary: general.observed, values: ["confidence": general.confidence])))
        }
        guard let best = options.max(by: { $0.score < $1.score }) else { return nil }
        var sources = [best.source]
        var evidence = [best.evidence]
        for option in options where option.source != best.source && !sources.contains(option.source) {
            sources.append(option.source)
            evidence.append(option.evidence)
        }
        var priority = PriorityBreakdown()
        priority.repeatability = min(30, best.score + 3 * Double(sources.count - 1))
        let personal = sources.contains { $0 != .generalRule }
        let findingConfidence = personal && a != nil
            ? PersonalizationConfidence.personal(measurement: confidence, maturity: a?.baseline.maturity ?? .insufficient)
            : PersonalStatistics.round3(general?.confidence ?? confidence)
        return PersonalCoachingFinding(
            id: DeterministicID.make(seed: input.analysisID, name: "personal|strength|" + key.rawValue),
            kind: .strength, role: .secondary, metric: key, category: general?.category ?? key.definition.category,
            headline: best.headline, detail: general?.whyItMatters, cue: nil, sources: sources, evidence: evidence,
            resolution: general == nil ? .personalOnly : (personal ? .generalKept : .generalOnly),
            rationale: personal ? "Based on your own kicks." : "Based on general kicking mechanics.",
            priority: priority, confidence: findingConfidence, confidenceLevel: PersonalizationConfidence.level(findingConfidence),
            generalRuleKey: general?.ruleKey, severity: nil,
            numbers: numbers(key, value: value, baseline: a?.baseline, generalProfile: input.generalProfile)
        )
    }

    static func generalOnlyFinding(_ general: GeneralRuleFinding, input: PersonalCoachingInput) -> PersonalCoachingFinding {
        var priority = PriorityBreakdown()
        let isImprove = general.kind == .improve
        if isImprove {
            priority.ruleSeverity = severityPoints(general.severity)
            priority.confidence = 10 * general.confidence
        } else {
            priority.repeatability = 15 + 10 * general.confidence
        }
        return PersonalCoachingFinding(
            id: DeterministicID.make(seed: input.analysisID, name: "personal|general|" + general.ruleKey),
            kind: isImprove ? .fix : .strength, role: .secondary, metric: general.metric, category: general.category,
            headline: general.observed, detail: general.whyItMatters, cue: general.cue, sources: [.generalRule],
            evidence: [CoachingEvidence(source: .generalRule, summary: general.observed, values: ["confidence": general.confidence])],
            resolution: .generalOnly, rationale: PersonalCoachCopy.generalOnlyRationale, priority: priority,
            confidence: PersonalStatistics.round3(general.confidence),
            confidenceLevel: PersonalizationConfidence.level(general.confidence),
            generalRuleKey: general.ruleKey, severity: general.severity, numbers: nil
        )
    }

    // MARK: Ranking

    /// Deterministic: score, then category order, then metric order, then ID. Primary fixes
    /// are the top `maximumPrimaryFixes` fixes that aren't de-emphasized and either come
    /// from Step 8 or reach `minimumPrimaryScore`; strengths are the top `maximumStrengths`.
    static func rank(_ findings: [PersonalCoachingFinding], configuration: PersonalizationConfiguration) -> [PersonalCoachingFinding] {
        func categoryIndex(_ c: AnalysisCategory) -> Int { CoachingEngine.categoryOrder.firstIndex(of: c) ?? CoachingEngine.categoryOrder.count }
        func metricIndex(_ k: KickMetricKey?) -> Int { k.flatMap { KickMetricKey.allCases.firstIndex(of: $0) } ?? KickMetricKey.allCases.count }
        let sorted = findings.sorted { a, b in
            if a.priority.total != b.priority.total { return a.priority.total > b.priority.total }
            if categoryIndex(a.category) != categoryIndex(b.category) { return categoryIndex(a.category) < categoryIndex(b.category) }
            if metricIndex(a.metric) != metricIndex(b.metric) { return metricIndex(a.metric) < metricIndex(b.metric) }
            return a.id.uuidString < b.id.uuidString
        }
        var fixes = 0
        var strengths = 0
        var result: [PersonalCoachingFinding] = []
        for var finding in sorted {
            finding.role = .secondary
            switch finding.kind {
            case .fix:
                let fromGeneral = finding.generalRuleKey != nil
                let eligible = finding.resolution != .deEmphasizedBySuccessfulPattern
                    && (fromGeneral || finding.priority.total >= configuration.minimumPrimaryScore)
                if eligible, fixes < configuration.maximumPrimaryFixes {
                    finding.role = .primaryFix
                    fixes += 1
                }
            case .strength:
                if strengths < configuration.maximumStrengths {
                    finding.role = .strength
                    strengths += 1
                }
            case .insight:
                break
            }
            result.append(finding)
        }
        func roleIndex(_ r: PersonalFindingRole) -> Int {
            switch r {
            case .primaryFix: 0
            case .strength: 1
            case .secondary: 2
            }
        }
        // Stable regroup: primary fixes, strengths, secondary (each keeps score order).
        return result.enumerated().sorted { x, y in
            roleIndex(x.element.role) != roleIndex(y.element.role) ? roleIndex(x.element.role) < roleIndex(y.element.role) : x.offset < y.offset
        }.map(\.element)
    }

    // MARK: Helpers

    /// The current kick's value of a metric, when it is trustworthy enough to compare.
    static func currentValue(_ key: KickMetricKey, in kick: HistoricalKickAnalysis, configuration: PersonalizationConfiguration) -> (Double, Double)? {
        guard let m = kick.metrics[key], let value = m.value, value.isFinite, m.status != .unavailable,
              m.definitionVersion == key.definition.definitionVersion,
              let confidence = m.confidence, confidence >= configuration.minimumMetricConfidence else { return nil }
        return (value, confidence)
    }

    /// For one-directional metrics, moving in the better direction is never a fault.
    static func isWorse(_ key: KickMetricKey, value: Double, than reference: Double) -> Bool {
        switch key.definition.betterDirection {
        case .higher: value < reference
        case .lower: value > reference
        case .towardIdealBand, .none: value != reference
        }
    }

    /// Which way the Step 8 range says the value is off: true = too high, false = too low,
    /// nil = inside the range (or no range).
    static func generalDirection(_ key: KickMetricKey, value: Double, generalProfile: BiomechanicsProfile) -> Bool? {
        guard let band = generalProfile.scoring[key]?.band else { return nil }
        if value > band.idealHigh { return true }
        if value < band.idealLow { return false }
        return nil
    }

    /// The value matches an established successful personal pattern (or the side of a
    /// reportable relationship associated with success).
    static func matchesSuccess(_ a: Assessment) -> Bool {
        guard a.baseline.maturity >= .established else { return false }
        let inStrongPattern = a.pattern.map { $0.isStrong && $0.contains(a.value) } ?? false
        let onSuccessfulSide = a.relationship != nil && !a.onUnsuccessfulSide && (a.pattern?.contains(a.value) ?? false)
        return inStrongPattern || onSuccessfulSide
    }

    static func severityPoints(_ severity: CoachingSeverity?) -> Double {
        switch severity {
        case .high: 30
        case .moderate: 20
        case .low: 12
        case .info, .none: 5
        }
    }

    static func targetText(_ a: Assessment) -> String {
        a.pattern != nil ? "your successful range" : "the provisional target"
    }

    static func trendEvidence(_ a: Assessment, improving: Bool) -> CoachingEvidence {
        let t = a.baseline.trend
        let unit = a.baseline.unit
        let recent = t.recentMean.map { PersonalCoachFormat.value($0, unit) } ?? "—"
        let previous = t.previousMean.map { PersonalCoachFormat.value($0, unit) } ?? "—"
        return CoachingEvidence(
            source: .trend,
            summary: "Last \(t.recentCount) kicks averaged \(recent), the \(t.previousCount) before averaged \(previous) — \(improving ? "toward" : "away from") \(targetText(a)).",
            values: ["recentMean": t.recentMean ?? .nan, "previousMean": t.previousMean ?? .nan,
                     "recentCount": Double(t.recentCount), "previousCount": Double(t.previousCount)].filter { $0.value.isFinite }
        )
    }

    static func consistencyEvidence(_ a: Assessment) -> CoachingEvidence {
        let c = a.baseline.consistency
        var values: [String: Double] = ["sampleCount": Double(c.sampleCount)]
        if let sd = c.standardDeviation { values["standardDeviation"] = sd }
        if let score = c.score { values["consistencyScore"] = score }
        if let r = c.recentStandardDeviation { values["recentStandardDeviation"] = r }
        if let p = c.previousStandardDeviation { values["previousStandardDeviation"] = p }
        let basis = c.basis == .successfulKicks ? "successful kicks" : "kicks"
        let scoreText = c.score.map { String(format: "%.2f", $0) } ?? "—"
        return CoachingEvidence(source: .consistency,
                                summary: "Consistency score \(scoreText) over \(c.sampleCount) \(basis) (1 = identical every kick).",
                                values: values)
    }

    static func numbers(_ key: KickMetricKey, value: Double, baseline: PersonalMetricBaseline?, generalProfile: BiomechanicsProfile) -> FindingNumbers {
        let band = generalProfile.scoring[key]?.band
        let pattern = baseline?.successfulPattern
        return FindingNumbers(
            unit: key.definition.unit, thisKick: value, yourNormal: baseline?.normal,
            successfulLow: pattern?.rangeLow, successfulHigh: pattern?.rangeHigh, successfulMedian: pattern?.successful.median,
            successfulCount: pattern?.successful.count, generalIdealLow: band?.idealLow, generalIdealHigh: band?.idealHigh
        )
    }

    private static func make(_ a: Assessment, input: PersonalCoachingInput, kind: PersonalFindingKind, tag: String, headline: String,
                             detail: String?, cue: String?, sources: [CoachingEvidenceSource], evidence: [CoachingEvidence],
                             priority: PriorityBreakdown) -> PersonalCoachingFinding {
        var priority = priority
        priority.maturity = a.maturityPoints
        priority.confidence = 10 * a.confidence
        let confidence = PersonalizationConfidence.personal(measurement: a.confidence, maturity: a.baseline.maturity)
        return PersonalCoachingFinding(
            id: DeterministicID.make(seed: input.analysisID, name: "personal|\(tag)|" + a.key.rawValue),
            kind: kind, role: .secondary, metric: a.key, category: a.key.definition.category,
            headline: headline, detail: detail, cue: cue, sources: sources, evidence: evidence,
            resolution: .personalOnly, rationale: PersonalCoachCopy.personalOnlyRationale, priority: priority,
            confidence: confidence, confidenceLevel: PersonalizationConfidence.level(confidence),
            generalRuleKey: nil, severity: nil,
            numbers: numbers(a.key, value: a.value, baseline: a.baseline, generalProfile: input.generalProfile)
        )
    }
}
