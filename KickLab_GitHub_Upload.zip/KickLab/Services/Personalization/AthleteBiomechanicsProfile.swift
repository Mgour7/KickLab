import Foundation

/// Why whole kicks were left out of a profile.
struct KickExclusionCounts: Codable, Equatable, Sendable {
    var analysisNotCompleted = 0
    var differentKickType = 0
    var differentKickingFoot = 0
    var unknownKickingFoot = 0
    var beforeBaselineEpoch = 0
    var differentDistanceBucket = 0
    /// The kick being coached is never part of its own comparison.
    var excludedKick = 0
    /// Kicks that passed every kick-level check but had no eligible metric.
    var noEligibleMetrics = 0
}

/// The athlete's personal mechanical fingerprint for one scope (kick type, kicking foot,
/// optionally camera angle, distance bucket and baseline epoch).
///
/// A transparent statistical summary, fully rebuildable from the stored analyses; it is
/// never the source of truth and holds no learned state of its own.
struct AthleteBiomechanicsProfile: Codable, Equatable, Sendable {
    var modelVersion: String
    var configurationVersion: Int
    var scope: PersonalizationScope
    /// Kicks that contributed at least one eligible metric.
    var eligibleKickCount: Int
    var maturity: ProfileMaturity
    var successfulKickCount: Int
    var unsuccessfulKickCount: Int
    var unknownOutcomeCount: Int
    var metrics: [KickMetricKey: PersonalMetricBaseline]
    /// One entry per learned metric, in catalog order (most are `insufficientData` early on).
    var relationships: [MetricOutcomeRelationship]
    var kickExclusions: KickExclusionCounts
    /// Per metric, values that were not learned from and why (also for metrics with no baseline).
    var metricExclusions: [KickMetricKey: MetricExclusionCounts]
    /// The analyses learned from, sorted (what this profile was built on).
    var sourceAnalysisIDs: [UUID]
    /// A deterministic fingerprint of `sourceAnalysisIDs` + configuration version, so a
    /// stored snapshot can be matched to a rebuild.
    var sourceFingerprint: UUID
    var firstKickDate: Date?
    var lastKickDate: Date?

    func baseline(_ key: KickMetricKey) -> PersonalMetricBaseline? { metrics[key] }

    func relationship(_ key: KickMetricKey) -> MetricOutcomeRelationship? { relationships.first { $0.key == key } }

    /// Comparable kicks still needed to reach `level` (0 when already there).
    func kicksNeeded(for level: ProfileMaturity, thresholds: MaturityThresholds) -> Int {
        let target: Int
        switch level {
        case .insufficient: target = 0
        case .emerging: target = thresholds.emerging
        case .established: target = thresholds.established
        case .strong: target = thresholds.strong
        }
        return max(0, target - eligibleKickCount)
    }
}

enum PersonalizationError: Error, Equatable, Sendable {
    case unsupportedKickType
    case invalidConfiguration(String)
}

/// Builds an athlete profile from stored analyses. The statistical model below is the
/// production implementation; a future learned (e.g. Core ML) model can conform too.
protocol AthleteLearningModel: Sendable {
    var modelVersion: String { get }

    func buildProfile(
        from kicks: [HistoricalKickAnalysis],
        scope: PersonalizationScope,
        configuration: PersonalizationConfiguration
    ) throws -> AthleteBiomechanicsProfile
}

/// Transparent individualized statistics (means, medians, robust spreads, quartiles,
/// recency weighting, successful-vs-unsuccessful comparisons). Not machine learning.
///
/// A metric value is learned from only when: the analysis completed; kick type and
/// kicking foot match; the kick is inside the scope's epoch and distance bucket; the
/// value exists (missing is never zero); its Step 8 confidence is at least
/// `minimumMetricConfidence`; its definition version matches the current catalog; and
/// its camera angle matches the scope (unless the metric is angle-invariant).
struct StatisticalAthleteLearningModel: AthleteLearningModel {
    static let version = "statistical-1.0"

    var modelVersion: String { Self.version }
    let profiles: any BiomechanicsProfileProviding

    init(profiles: any BiomechanicsProfileProviding = StandardBiomechanicsProfiles()) {
        self.profiles = profiles
    }

    func buildProfile(
        from kicks: [HistoricalKickAnalysis],
        scope: PersonalizationScope,
        configuration: PersonalizationConfiguration
    ) throws -> AthleteBiomechanicsProfile {
        guard scope.kickType != .unknown else { throw PersonalizationError.unsupportedKickType }
        try Self.validate(configuration)
        let generalProfile = profiles.profile(for: BiomechanicsContext(
            kickType: scope.kickType, kickingFoot: scope.kickingFoot, cameraAngle: scope.cameraAngle ?? .side
        ))
        let evaluator = StandardKickSuccessEvaluator(configuration: configuration)

        var exclusions = KickExclusionCounts()
        let candidates = kicks
            .sorted { a, b in a.kickDate != b.kickDate ? a.kickDate < b.kickDate : a.analysisID.uuidString < b.analysisID.uuidString }
            .filter { kick in Self.kickIsEligible(kick, scope: scope, exclusions: &exclusions) }

        var samplesByKey: [KickMetricKey: [PersonalSample]] = [:]
        var excludedByKey: [KickMetricKey: MetricExclusionCounts] = [:]
        var contributing: [UUID: HistoricalKickAnalysis] = [:]
        for kick in candidates {
            let success = evaluator.evaluate(kick)
            var contributed = false
            for key in KickMetricKey.allCases {
                guard let metric = kick.metrics[key] else { continue }
                if let sample = Self.sample(metric, key: key, kick: kick, success: success, scope: scope,
                                            configuration: configuration, excluded: &excludedByKey[key, default: MetricExclusionCounts()]) {
                    samplesByKey[key, default: []].append(sample)
                    contributed = true
                }
            }
            if contributed {
                contributing[kick.analysisID] = kick
            } else {
                exclusions.noEligibleMetrics += 1
            }
        }

        var baselines: [KickMetricKey: PersonalMetricBaseline] = [:]
        var relationships: [MetricOutcomeRelationship] = []
        for key in KickMetricKey.allCases {
            let samples = samplesByKey[key] ?? []
            guard let baseline = PersonalMetricBaseline.make(
                key: key, samples: samples, excluded: excludedByKey[key] ?? MetricExclusionCounts(),
                generalProfile: generalProfile, now: scope.now, configuration: configuration
            ) else { continue }
            baselines[key] = baseline
            relationships.append(MetricOutcomeRelationship.make(key: key, samples: samples, configuration: configuration))
        }

        let used = contributing.values.sorted { $0.analysisID.uuidString < $1.analysisID.uuidString }
        let outcomes = used.map { evaluator.evaluate($0) }
        let ids = used.map(\.analysisID)
        return AthleteBiomechanicsProfile(
            modelVersion: modelVersion,
            configurationVersion: configuration.version,
            scope: scope,
            eligibleKickCount: used.count,
            maturity: configuration.maturity.level(for: used.count),
            successfulKickCount: outcomes.filter { $0 == .successful }.count,
            unsuccessfulKickCount: outcomes.filter { $0 == .unsuccessful }.count,
            unknownOutcomeCount: outcomes.filter { $0 == .unknown }.count,
            metrics: baselines,
            relationships: relationships,
            kickExclusions: exclusions,
            metricExclusions: excludedByKey,
            sourceAnalysisIDs: ids,
            sourceFingerprint: DeterministicID.make(
                seed: UUID(uuid: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10)),
                name: modelVersion + "|" + String(configuration.version) + "|" + ids.map(\.uuidString).joined(separator: ",")
            ),
            firstKickDate: used.map(\.kickDate).min(),
            lastKickDate: used.map(\.kickDate).max()
        )
    }

    static func validate(_ c: PersonalizationConfiguration) throws {
        guard (0...1).contains(c.minimumMetricConfidence) else { throw PersonalizationError.invalidConfiguration("minimumMetricConfidence") }
        guard c.maturity.emerging >= 1, c.maturity.emerging < c.maturity.established, c.maturity.established < c.maturity.strong else {
            throw PersonalizationError.invalidConfiguration("maturity")
        }
        guard c.recentKickCount >= 1, c.minimumRecentSamples >= 1, c.minimumOutcomeGroupSize >= 2, c.minimumConsistencySamples >= 2 else {
            throw PersonalizationError.invalidConfiguration("sample sizes")
        }
    }

    static func kickIsEligible(_ kick: HistoricalKickAnalysis, scope: PersonalizationScope, exclusions: inout KickExclusionCounts) -> Bool {
        guard kick.kickType == scope.kickType else { exclusions.differentKickType += 1; return false }
        guard kick.kickID != scope.excludingKickID else { exclusions.excludedKick += 1; return false }
        guard kick.analysisCompleted else { exclusions.analysisNotCompleted += 1; return false }
        guard let foot = kick.kickingFoot else { exclusions.unknownKickingFoot += 1; return false }
        guard foot == scope.kickingFoot else { exclusions.differentKickingFoot += 1; return false }
        if let epoch = scope.epoch, kick.kickDate < epoch.startsAt { exclusions.beforeBaselineEpoch += 1; return false }
        if let bucket = scope.distanceBucket {
            guard let yards = kick.outcome.distanceYards, DistanceBucket.bucket(forYards: yards) == bucket else {
                exclusions.differentDistanceBucket += 1
                return false
            }
        }
        return true
    }

    static func sample(
        _ metric: HistoricalMetricValue, key: KickMetricKey, kick: HistoricalKickAnalysis, success: KickSuccess,
        scope: PersonalizationScope, configuration: PersonalizationConfiguration, excluded: inout MetricExclusionCounts
    ) -> PersonalSample? {
        guard let value = metric.value, value.isFinite, metric.status != .unavailable else {
            excluded.unavailable += 1
            return nil
        }
        guard metric.definitionVersion == key.definition.definitionVersion else {
            excluded.incompatibleDefinition += 1
            return nil
        }
        guard let confidence = metric.confidence, confidence >= configuration.minimumMetricConfidence else {
            excluded.lowConfidence += 1
            return nil
        }
        guard angleIsComparable(metric.cameraAngle, to: scope.cameraAngle, key: key, configuration: configuration) else {
            excluded.differentCameraAngle += 1
            return nil
        }
        return PersonalSample(kickID: kick.kickID, analysisID: kick.analysisID, date: kick.kickDate,
                              value: value, confidence: confidence, success: success)
    }

    /// Same angle, or the metric does not depend on camera position, or no angle is required.
    static func angleIsComparable(_ angle: VideoAngleType?, to required: VideoAngleType?, key: KickMetricKey,
                                  configuration: PersonalizationConfiguration) -> Bool {
        guard let required else { return true }
        if configuration.traits(key).angleInvariant { return true }
        return (angle ?? .unknown) == required
    }
}
