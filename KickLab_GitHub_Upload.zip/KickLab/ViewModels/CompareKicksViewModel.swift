import Foundation
import Observation
import SwiftData

extension ComparisonKick {
    /// Build 20: a kick's CURRENT completed analysis as the comparison sees it (read-only).
    @MainActor
    init?(analysis: BiomechanicsAnalysis, hasVideo: Bool) {
        guard analysis.isCurrent, analysis.processingStatus == .completed, let kick = analysis.kick else { return nil }
        let video = ContactAnnotationStore.primaryVideo(of: analysis)
        var metrics: [KickMetricKey: ComparisonMetric] = [:]
        for m in analysis.metrics ?? [] where m.measurementStatus != .unavailable {
            guard let key = KickMetricKey(rawValue: m.metricKey), let v = m.value, v.isFinite,
                  (m.confidence ?? 0) >= KickComparison.minimumConfidence else { continue }
            metrics[key] = ComparisonMetric(value: v, definitionVersion: m.metricDefinitionVersion, confidence: m.confidence)
        }
        var scores: [AnalysisCategory: Double] = [:]
        for c in analysis.categoryScores ?? [] where c.measurementStatus != .unavailable {
            if let s = c.score, s.isFinite, c.category != .overall { scores[c.category] = s }
        }
        self.init(analysisID: analysis.id, kickID: kick.id, athleteID: kick.athleteID, date: kick.timestamp, kickType: kick.kickType,
                  view: ComparableView(angle: video?.angleType), result: KickResult(optionalStoredValue: kick.storedResult),
                  distanceYards: kick.distanceYards, sessionID: kick.session?.id, isReference: kick.isReferenceKick,
                  hasVideo: hasVideo, engineVersion: analysis.analysisVersion, metrics: metrics, categoryScores: scores)
    }
}

/// Build 20: choosing two analyzed kicks to compare, and the Personal Reference Kick.
@MainActor
@Observable
final class CompareKicksViewModel {
    private(set) var kicks: [ComparisonKick] = []
    private(set) var message: String?
    var selectedA: UUID?
    var selectedB: UUID?
    var filter: ComparisonFilter = .all
    var sort: ComparisonSort = .newest
    let preselected: UUID?

    init(preselected: UUID? = nil) {
        self.preselected = preselected
        self.selectedA = preselected
    }

    func load(app: AppModel) {
        guard let summary = app.selectedAthlete, let athlete = app.athleteModel(summary.id) else {
            message = "Add an athlete to get started."
            return
        }
        kicks = (athlete.kicks ?? []).compactMap { kick in
            guard let analysis = (kick.analyses ?? []).first(where: { $0.isCurrent && $0.processingStatus == .completed }) else { return nil }
            let video = ContactAnnotationStore.primaryVideo(of: analysis)
            let hasVideo = video.map { app.services.videos.fileExists(for: $0) } ?? false
            return ComparisonKick(analysis: analysis, hasVideo: hasVideo)
        }
        message = kicks.count < 2 ? "Analyze at least two kicks to compare them." : nil
        if let a = selectedA, selectedB == nil, let kick = kick(a) {
            selectedB = KickComparison.suggestedPartner(for: kick, among: kicks)?.analysisID
        }
    }

    func kick(_ analysisID: UUID?) -> ComparisonKick? { kicks.first { $0.analysisID == analysisID } }

    /// The list for picking Kick B (Kick A excluded), filtered and sorted.
    var candidates: [ComparisonKick] { KickComparison.filter(kicks, by: filter, excluding: selectedA, sort: sort) }

    /// Filters that make sense relative to Kick A.
    var availableFilters: [ComparisonFilter] {
        var out: [ComparisonFilter] = [.all, .made, .missed, .reference]
        if let a = kick(selectedA) {
            out.append(.sameView(a.view))
            if let d = a.distanceYards { out.append(.sameDistance(d)) }
            if let s = a.sessionID { out.append(.sameSession(s)) }
        }
        return out
    }

    var canCompare: Bool { selectedA != nil && selectedB != nil && selectedA != selectedB }

    func setReference(kickID: UUID, on: Bool, app: AppModel) {
        message = PersonalReferenceStore.set(kickID: kickID, on: on, app: app)
        load(app: app)
    }
}

/// Build 20: saves the Personal Reference Kick (user-selected; one per kick type). Only
/// `Kick.isReferenceKick` changes — no analysis, score or provenance is touched.
@MainActor
enum PersonalReferenceStore {
    /// Returns a user-facing problem, or nil on success.
    static func set(kickID: UUID, on: Bool, app: AppModel) -> String? {
        guard let kick = ModelLookup.kick(kickID, in: app.context) else { return "This kick no longer exists." }
        if on, let athlete = kick.athlete {
            let all = (athlete.kicks ?? []).map { (id: $0.id, kickType: $0.kickType, isReference: $0.isReferenceKick) }
            for id in PersonalReferencePolicy.kicksToClear(selected: kickID, kickType: kick.kickType, kicks: all) {
                ModelLookup.kick(id, in: app.context)?.isReferenceKick = false
            }
        }
        kick.isReferenceKick = on
        do {
            try app.context.save()
            app.dataDidChange()
            return nil
        } catch {
            return "Couldn't save the reference kick."
        }
    }
}

/// Build 20: one side of a loaded comparison.
struct ComparisonSideContent {
    var kick: ComparisonKick
    var timeline: PoseValidationTimeline?
    var storedTimeline: KickerPoseTimeline?
    var football: FootballTrack?
    var kickingFoot: KickingFoot
    var videoURL: URL?
    var side: ComparisonSide
    /// Build 21: a label for camera pairs ("Camera B · Rear"), and the display aspect when
    /// there is no stored pose timeline to take it from.
    var caption: String? = nil
    var displayAspectRatio: Double? = nil
}

/// Build 21: the synchronization uncertainty of a session pair's second camera.
@MainActor
enum SessionPairLookup {
    static func syncUncertainty(kickID: UUID, app: AppModel) -> Double? {
        for m in app.services.trainingSessions.loadAll() {
            let primaries = Set(m.pairs.map(\.primaryCandidateID))
            guard let primary = m.candidates.first(where: { $0.kickID == kickID && primaries.contains($0.id) }),
                  let pair = m.pairs.first(where: { $0.primaryCandidateID == primary.id }),
                  let secondary = m.candidate(pair.secondaryCandidateID), let a = m.source(primary.sourceID), let b = m.source(secondary.sourceID),
                  let u = MultiCameraSync.alignmentUncertainty(a.sync, b.sync) else { continue }
            return u
        }
        return nil
    }
}

