import Foundation
import Observation
import SwiftData

/// Step 12F: Verify Contact. The user steps through the ORIGINAL video one source frame at
/// a time (true presentation timestamps) and records the first frame with visible
/// foot–ball contact, or that they can't tell. The answer is saved on the video as a
/// reference annotation: it never changes the analysis, never becomes an automatic result,
/// and is not used to tune detection.
@MainActor
@Observable
final class VerifyContactViewModel {
    struct Content: Equatable, Sendable {
        var videoURL: URL?
        /// The stored analysis's own automatic estimate (nil for user-assisted analyses).
        var automaticTime: Double?
        var automaticInterval: ClosedRange<Double>?
        var isUserAssisted: Bool
        var engineVersion: String?
        var provenance: String?
    }

    let analysisID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var table = SourceFrameTable(times: [])
    private(set) var tableProblem: String?
    private(set) var annotation: ContactAnnotation = .none
    private(set) var message: String?

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    func load(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        annotation = ContactAnnotationStore.annotation(for: analysis)
        let video = ContactAnnotationStore.primaryVideo(of: analysis)
        let url = video.flatMap { app.services.videos.fileExists(for: $0) ? app.services.videos.fileURL(for: $0) : nil }
        var phases: KickPhaseDetectionResult?
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            phases = await Task.detached { try? store.readBundle(in: directory).phases.phases }.value
        }
        let assisted = phases?.isUserAssisted ?? false
        let automatic = assisted ? nil : phases?.estimatedContactTime
        let interval: ClosedRange<Double>? = automatic.flatMap { t in
            guard let e = phases?.evidence else { return nil }
            let lo = e.contactEarliestTime ?? t, hi = e.contactLatestTime ?? t
            return lo <= hi ? lo...hi : nil
        }
        state = .loaded(Content(videoURL: url, automaticTime: automatic, automaticInterval: interval, isUserAssisted: assisted,
                                engineVersion: analysis.analysisVersion, provenance: phases?.evidence?.contactProvenance))
        if let url {
            do {
                table = SourceFrameTable(times: try await app.services.frameTimestamps.frameTimes(for: url))
                tableProblem = table.isEmpty ? "Frame numbers aren't available for this video; times come from the player." : nil
            } catch {
                tableProblem = "The video's frame times couldn't be read; times come from the player."
            }
        }
    }

    var comparison: ContactVerificationComparison {
        let c = state.value
        return ContactVerificationComparison.make(automatic: c?.automaticTime, interval: c?.automaticInterval,
                                                  annotation: annotation, table: table)
    }

    /// "Frame 117 of 228 · 3.867 s" (1-based), or the time alone without a frame table.
    func frameLabel(time: Double) -> String {
        guard let i = table.nearestIndex(to: time) else { return String(format: "%.3f s", time) }
        return String(format: "Frame %d of %d · %.3f s", i + 1, table.count, table.times[i])
    }

    func saveFrame(_ time: Double, app: AppModel) {
        let exact = table.nearestIndex(to: time).flatMap { table.time(at: $0) } ?? time
        message = ContactAnnotationStore.save(exact, analysisID: analysisID, app: app) ?? "Saved as your verified contact frame."
        if let analysis = ModelLookup.analysis(analysisID, in: app.context) { annotation = ContactAnnotationStore.annotation(for: analysis) }
    }

    func saveCannotTell(app: AppModel) {
        message = ContactAnnotationStore.saveCannotTell(analysisID: analysisID, app: app) ?? "Saved: you couldn't tell which frame shows contact."
        if let analysis = ModelLookup.analysis(analysisID, in: app.context) { annotation = ContactAnnotationStore.annotation(for: analysis) }
    }

    func clear(app: AppModel) {
        message = ContactAnnotationStore.save(nil, analysisID: analysisID, app: app) ?? "Your answer was cleared."
        annotation = .none
    }
}
