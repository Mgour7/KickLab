import Foundation
import Observation
import SwiftData

/// Step 12F: Verify Contact. The user steps through the ORIGINAL video one source frame at
/// a time (true presentation timestamps) and records the first frame with visible
/// foot–ball contact, or that they can't tell. The answer is saved on the video as a
/// reference annotation: it never changes the analysis, never becomes an automatic result,
/// and is not used to tune detection.
@MainActor
@Observable
final class VerifyContactViewModel {
    struct Content: Equatable, Sendable {
        var videoURL: URL?
        /// The stored analysis's own automatic estimate (nil for user-assisted analyses).
        var automaticTime: Double?
        var automaticInterval: ClosedRange<Double>?
        var isUserAssisted: Bool
        var engineVersion: String?
        var provenance: String?
        /// Step 12G.
        var kickID: UUID?
        var automaticPlant: Double?
        var strikeWindowOnly: Bool = false
        var frameAspect: Double = 9.0 / 16.0
        /// Build 15: the analysis' phases and football track, for comparing with your marks.
        var phases: KickPhaseDetectionResult? = nil
        var football: FootballTrack? = nil
    }

    let analysisID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var table = SourceFrameTable(times: [])
    private(set) var tableProblem: String?
    private(set) var annotation: ContactAnnotation = .none
    private(set) var message: String?
    /// Step 12G: plant, first ball movement and ball location the user verified.
    private(set) var verification = VideoVerification()
    private(set) var isMeasuringBall = false

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    func load(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        annotation = ContactAnnotationStore.annotation(for: analysis)
        let video = ContactAnnotationStore.primaryVideo(of: analysis)
        verification = video?.verification ?? VideoVerification()
        let url = video.flatMap { app.services.videos.fileExists(for: $0) ? app.services.videos.fileURL(for: $0) : nil }
        var phases: KickPhaseDetectionResult?
        var football: FootballTrack?
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let artifact = await Task.detached { try? store.readBundle(in: directory).phases }.value
            phases = artifact?.phases
            football = artifact?.football
        }
        let assisted = phases?.isUserAssisted ?? false
        let automatic = assisted ? nil : phases?.estimatedContactTime
        let interval: ClosedRange<Double>? = automatic.flatMap { t in
            guard let e = phases?.evidence else { return nil }
            let lo = e.contactEarliestTime ?? t, hi = e.contactLatestTime ?? t
            return lo <= hi ? lo...hi : nil
        }
        // Stored pixel sizes are display-oriented (the track transform applied).
        let aspect: Double = {
            guard let w = video?.pixelWidth, let h = video?.pixelHeight, w > 0, h > 0 else { return 9.0 / 16.0 }
            return Double(w) / Double(h)
        }()
        state = .loaded(Content(videoURL: url, automaticTime: automatic, automaticInterval: interval, isUserAssisted: assisted,
                                engineVersion: analysis.analysisVersion, provenance: phases?.evidence?.contactProvenance,
                                kickID: analysis.kick?.id, automaticPlant: assisted ? nil : phases?.plantTime,
                                strikeWindowOnly: phases?.evidence?.contactTimingMethod == "strikeWindow", frameAspect: aspect,
                                phases: phases, football: football))
        if let url {
            do {
                table = SourceFrameTable(times: try await app.services.frameTimestamps.frameTimes(for: url))
                tableProblem = table.isEmpty ? "Frame numbers aren't available for this video; times come from the player." : nil
            } catch {
                tableProblem = "The video's frame times couldn't be read; times come from the player."
            }
        }
    }

    var comparison: ContactVerificationComparison {
        let c = state.value
        return ContactVerificationComparison.make(automatic: c?.automaticTime, interval: c?.automaticInterval,
                                                  annotation: annotation, table: table)
    }

    /// "Frame 117 of 228 · 3.867 s" (1-based), or the time alone without a frame table.
    func frameLabel(time: Double) -> String {
        guard let i = table.nearestIndex(to: time) else { return String(format: "%.3f s", time) }
        return String(format: "Frame %d of %d · %.3f s", i + 1, table.count, table.times[i])
    }

    func saveFrame(_ time: Double, app: AppModel) {
        let exact = table.nearestIndex(to: time).flatMap { table.time(at: $0) } ?? time
        message = ContactAnnotationStore.save(exact, analysisID: analysisID, app: app) ?? "Saved as your verified contact frame."
        if let analysis = ModelLookup.analysis(analysisID, in: app.context) { annotation = ContactAnnotationStore.annotation(for: analysis) }
    }

    func saveCannotTell(app: AppModel) {
        message = ContactAnnotationStore.saveCannotTell(analysisID: analysisID, app: app) ?? "Saved: you couldn't tell which frame shows contact."
        if let analysis = ModelLookup.analysis(analysisID, in: app.context) { annotation = ContactAnnotationStore.annotation(for: analysis) }
    }

    func clear(app: AppModel) {
        message = ContactAnnotationStore.save(nil, analysisID: analysisID, app: app) ?? "Your answer was cleared."
        annotation = .none
    }

    // MARK: Step 12G — plant, ball movement, ball location

    private func saveVerification(app: AppModel, _ change: (inout VideoVerification) -> Void, done: String) {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context),
              let video = ContactAnnotationStore.primaryVideo(of: analysis) else {
            message = "The analyzed video is no longer available."
            return
        }
        var v = video.verification
        change(&v)
        video.verification = v
        do {
            try app.context.save()
            verification = v
            message = done
        } catch {
            message = "Couldn't save."
        }
    }

    func markPlant(_ time: Double?, cannotTell: Bool = false, app: AppModel) {
        let exact = time.map { t in table.nearestIndex(to: t).flatMap { table.time(at: $0) } ?? t }
        saveVerification(app: app, { $0.plant = cannotTell ? .cannotTell : exact.map { .frame(time: $0) } },
                         done: cannotTell ? "Saved: you couldn't tell the plant frame." : (exact == nil ? "Plant mark cleared." : "Saved as the plant frame."))
    }

    func markFirstBallMovement(_ time: Double?, app: AppModel) {
        let exact = time.map { t in table.nearestIndex(to: t).flatMap { table.time(at: $0) } ?? t }
        saveVerification(app: app, { $0.firstBallMovement = exact.map { .frame(time: $0) } },
                         done: exact == nil ? "Ball-movement mark cleared." : "Saved as the first frame the ball moves.")
    }

    func markBall(at point: NormalizedPoint, radius: Double, time: Double, app: AppModel) {
        let exact = table.nearestIndex(to: time).flatMap { table.time(at: $0) } ?? time
        saveVerification(app: app, {
            $0.ballMark = VideoVerification.BallMark(time: exact, x: point.x, y: point.y, radius: radius)
            $0.ballMotion = nil
        }, done: "Ball marked. Measure its movement to time contact from the frames.")
    }

    func clearBall(app: AppModel) {
        saveVerification(app: app, { $0.ballMark = nil; $0.ballMotion = nil }, done: "Ball mark cleared.")
    }

    /// Reads the marked ball's region from the real frames and finds when it leaves.
    func measureBallMovement(app: AppModel) async {
        guard let mark = verification.ballMark, let url = state.value?.videoURL else { return }
        isMeasuringBall = true
        defer { isMeasuringBall = false }
        do {
            let read = try await app.services.ballRegions.crops(url: url, mark: mark, duration: 3, targetRadius: 9)
            guard !read.frames.isEmpty else {
                message = "The ball area couldn't be read from this video (too close to the edge?)."
                return
            }
            let result = BallMotionTracker.analyze(read.frames, referenceIndex: 0, ballRadius: read.radius)
            saveVerification(app: app, { $0.ballMotion = result }, done: result.note)
        } catch {
            message = "The video's frames couldn't be read."
        }
    }

    // MARK: Build 15 — contact range, which football, comparison

    func markContactRange(start: Double? = nil, end: Double? = nil, app: AppModel) {
        func exact(_ t: Double) -> Double { table.nearestIndex(to: t).flatMap { table.time(at: $0) } ?? t }
        var r = verification.contactRange ?? VideoVerification.RangeMark(start: start ?? end ?? 0, end: end ?? start ?? 0)
        if let start { r.start = exact(start) }
        if let end { r.end = exact(end) }
        if r.end < r.start { swap(&r.start, &r.end) }
        saveVerification(app: app, { $0.contactRange = r }, done: String(format: "Saved: contact between %.3f and %.3f s.", r.start, r.end))
    }

    func clearContactRange(app: AppModel) {
        saveVerification(app: app, { $0.contactRange = nil }, done: "Contact range cleared.")
    }

    /// The footballs the detector found (for "which football was kicked").
    var detectedBalls: [FootballRestSite] { state.value?.football?.sites ?? [] }

    /// Records the user's choice of kicked football and marks it for frame measurement.
    /// Human input: it never changes the automatic analysis unless the user reanalyzes in
    /// assisted mode.
    func chooseKickedBall(number: Int, app: AppModel) {
        let sites = detectedBalls
        guard sites.indices.contains(number - 1) else { return }
        let site = sites[number - 1]
        let restTime = max(site.firstSeen, site.lastSeen - 0.5)
        saveVerification(app: app, {
            $0.kickedBall = VideoVerification.KickedBallChoice(x: site.center.x, y: site.center.y, size: site.size, detectedBallNumber: number)
            $0.ballMark = VideoVerification.BallMark(time: restTime, x: site.center.x, y: site.center.y, radius: site.size / 2)
            $0.ballMotion = nil
        }, done: "Saved: ball \(number) was kicked. Measure its movement to time contact from the frames.")
    }

    var comparisonRows: [VerificationComparisonRow] {
        let c = state.value
        let frame = table.count > 1 ? (table.times[table.count - 1] - table.times[0]) / Double(table.count - 1) : 1.0 / 30
        return VerificationComparison.rows(phases: c?.isUserAssisted == true ? nil : c?.phases, football: c?.football,
                                           verification: verification, annotation: annotation, frame: frame)
    }

    /// The frames the user verified, as a request for a NEW user-assisted analysis.
    func verifiedAssistance() -> PhaseDetectionAssistance? {
        let contact: Double? = { if case .contact(let t) = annotation { return t } else { return nil } }()
        return verification.assistance(contactTime: contact)
    }

    func reanalyzeWithVerifiedFrames(app: AppModel) -> Bool {
        guard let kickID = state.value?.kickID, let assistance = verifiedAssistance() else { return false }
        app.analysisRun(for: kickID).reanalyze(app: app, mode: .verified(assistance))
        return true
    }
}
