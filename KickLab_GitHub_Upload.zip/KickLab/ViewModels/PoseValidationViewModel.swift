import Foundation
import Observation
import SwiftData

/// Step 12C developer Pose Validation player: the analyzed video with the stored pose
/// drawn on top, phase markers, and manual contact marking. Reads only local files.
@MainActor
@Observable
final class PoseValidationViewModel {
    struct Content: Equatable {
        var timeline: PoseValidationTimeline
        var videoURL: URL?
        var engineVersion: String?
        var algorithmVersion: String?
        var estimatedContact: Double?
        var sourceFrameRate: Double?
    }

    let analysisID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var markedContact: Double?
    private(set) var annotationError: String?

    // Player options (the view drives the AVPlayer from these).
    var source: PoseOverlaySource = .current
    var showsSkeleton = true
    var showsConfidence = true
    var playbackRate: Double = 0.25

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    static let playbackRates: [Double] = [0.1, 0.25, 0.5, 1]

    func load(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        guard let directory = analysis.artifactsRelativePath else {
            state = .failed("This analysis has no stored pose data, so there is nothing to overlay.")
            return
        }
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) } ?? .right
        let marked = ContactAnnotationStore.markedContact(for: analysis)
        markedContact = marked
        let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        let built = await Task.detached { () -> (PoseValidationTimeline, AnalysisArtifactBundle, Double?)? in
            guard let bundle = try? store.readBundle(in: directory) else { return nil }
            let input = AnalysisDiagnosticsInput(bundle: bundle)
            let replay = DiagnosticsReplay.run(input, kickingFoot: foot)
            guard let timeline = PoseValidationTimeline.make(
                sequence: bundle.pose.sequence, storedTimeline: bundle.pose.kickerTimeline,
                currentTimeline: replay?.timeline, repair: replay?.replay.repair,
                kickingFoot: input.context?.kickingFoot ?? foot, storedPhases: bundle.phases.phases,
                currentPhases: replay?.phases, markedContact: marked
            ) else { return nil }
            return (timeline, bundle, replay?.phases.estimatedContactTime)
        }.value
        guard let (timeline, bundle, estimate) = built else {
            state = .failed("The stored pose data couldn't be read, or no kicker was tracked.")
            return
        }
        let video = ModelLookup.video(bundle.manifest.primaryVideoID, in: app.context)
        let url = video.flatMap { app.services.videos.fileExists(for: $0) ? app.services.videos.fileURL(for: $0) : nil }
        if !timeline.availableSources.contains(source) { source = timeline.availableSources.last ?? .raw }
        state = .loaded(Content(
            timeline: timeline, videoURL: url, engineVersion: bundle.manifest.engineVersion,
            algorithmVersion: ContactEstimator.algorithmVersion, estimatedContact: estimate,
            sourceFrameRate: bundle.pose.sequence.nominalFrameRate
        ))
    }

    /// Marks the frame at `time` as contact (or clears it with nil). Evaluation data only:
    /// it never changes the automatic estimate or any score.
    func markContact(at time: Double?, app: AppModel) async {
        annotationError = ContactAnnotationStore.save(time, analysisID: analysisID, app: app)
        guard annotationError == nil else { return }
        markedContact = time
        if case .loaded(var content) = state {
            content.timeline.markers.removeAll { $0.kind == .markedContact }
            if let time { content.timeline.markers.append(ValidationMarker(kind: .markedContact, title: "Marked contact", time: time)) }
            content.timeline.markers.sort { $0.time < $1.time }
            state = .loaded(content)
        }
    }

    var comparison: ContactComparison? {
        guard let marked = markedContact, let content = state.value else { return nil }
        return ContactComparison(marked: marked, estimated: content.estimatedContact,
                                 framesPerSecond: 1 / content.timeline.sampleInterval)
    }
}
