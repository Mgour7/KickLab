import Foundation
import Observation
import SwiftData

/// Step 12C developer Pose Validation player: the analyzed video with the stored pose
/// drawn on top, phase markers, and manual contact marking. Reads only local files.
@MainActor
@Observable
final class PoseValidationViewModel {
    struct Content: Equatable {
        var timeline: PoseValidationTimeline
        var videoURL: URL?
        var engineVersion: String?
        var algorithmVersion: String?
        var estimatedContact: Double?
        var sourceFrameRate: Double?
        /// Step 12D: what is needed to re-run detection for another kick window (display only).
        var replaySignals: PoseSignalSet?
        var kickType: KickType = .unknown
        var sequence: PoseSequence?
        var storedTimeline: KickerPoseTimeline?
        var currentTimeline: KickerPoseTimeline?
        var repair: PoseRepairReport?
        var storedPhases: KickPhaseDetectionResult?
        var kickingFoot: KickingFoot = .right
        /// Index into the detected kick windows being shown.
        var shownWindow: Int?
        /// Step 12G: the stored football track (drawn by the debugger).
        var football: FootballTrack?
        /// Build 15: every decision layer on one time axis.
        var evidence: EvidenceTimelineModel?
    }

    let analysisID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var markedContact: Double?
    private(set) var annotationError: String?

    // Player options (the view drives the AVPlayer from these).
    var source: PoseOverlaySource = .current
    var showsSkeleton = true
    var showsConfidence = true
    /// Step 12G: football boxes, resting spot and observed path.
    var showsFootball = true
    /// Step 12G: magnification around the football's resting spot (1 = whole frame).
    var zoom: Double = 1
    var playbackRate: Double = 0.25

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    static let playbackRates: [Double] = [0.1, 0.25, 0.5, 1]
    static let zoomLevels: [Double] = [1, 2, 3]

    func load(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        guard let directory = analysis.artifactsRelativePath else {
            state = .failed("This analysis has no stored pose data, so there is nothing to overlay.")
            return
        }
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) } ?? .right
        let marked = ContactAnnotationStore.markedContact(for: analysis)
        markedContact = marked
        let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        let built = await Task.detached { () -> (PoseValidationTimeline, AnalysisArtifactBundle, DiagnosticsReplay.Output?, KickingFoot)? in
            guard let bundle = try? store.readBundle(in: directory) else { return nil }
            let input = AnalysisDiagnosticsInput(bundle: bundle)
            let replay = DiagnosticsReplay.run(input, kickingFoot: foot)
            let kickingFoot = input.context?.kickingFoot ?? foot
            guard let timeline = PoseValidationTimeline.make(
                sequence: bundle.pose.sequence, storedTimeline: bundle.pose.kickerTimeline,
                currentTimeline: replay?.timeline, repair: replay?.replay.repair,
                kickingFoot: kickingFoot, storedPhases: bundle.phases.phases,
                currentPhases: replay?.phases, markedContact: marked, football: bundle.phases.football
            ) else { return nil }
            return (timeline, bundle, replay, kickingFoot)
        }.value
        guard let (timeline, bundle, replay, kickingFoot) = built else {
            state = .failed("The stored pose data couldn't be read, or no kicker was tracked.")
            return
        }
        let estimate = replay?.phases.estimatedContactTime
        let video = ModelLookup.video(bundle.manifest.primaryVideoID, in: app.context)
        let url = video.flatMap { app.services.videos.fileExists(for: $0) ? app.services.videos.fileURL(for: $0) : nil }
        if !timeline.availableSources.contains(source) { source = timeline.availableSources.last ?? .raw }
        state = .loaded(Content(
            timeline: timeline, videoURL: url, engineVersion: bundle.manifest.engineVersion,
            algorithmVersion: ContactEstimator.algorithmVersion, estimatedContact: estimate,
            sourceFrameRate: bundle.pose.sequence.nominalFrameRate,
            replaySignals: replay?.signals, kickType: bundle.manifest.kickType, sequence: bundle.pose.sequence,
            storedTimeline: bundle.pose.kickerTimeline, currentTimeline: replay?.timeline, repair: replay?.replay.repair,
            storedPhases: bundle.phases.phases, kickingFoot: kickingFoot,
            shownWindow: replay?.phases.kickWindows?.selectedIndex, football: bundle.phases.football,
            evidence: EvidenceTimelineModel.make(signals: replay?.signals ?? bundle.signals.signals,
                                                 phases: replay?.phases ?? bundle.phases.phases, football: bundle.phases.football)
        ))
    }

    /// Step 12D: shows the phases the current detector finds in another detected kick
    /// window. Display only: nothing is stored and no analysis changes.
    func showKickWindow(_ index: Int) {
        guard case .loaded(var content) = state, let signals = content.replaySignals, let sequence = content.sequence,
              let windows = content.timeline.kickWindows, windows.windows.indices.contains(index) else { return }
        let w = windows.windows[index]
        let phases = KickPhaseDetector.detect(signals, kickType: content.kickType,
                                              assistance: PhaseDetectionAssistance(windowStart: w.preparationStart, windowEnd: w.movementEnd))
        guard var timeline = PoseValidationTimeline.make(
            sequence: sequence, storedTimeline: content.storedTimeline, currentTimeline: content.currentTimeline,
            repair: content.repair, kickingFoot: content.kickingFoot, storedPhases: content.storedPhases,
            currentPhases: phases, markedContact: markedContact, football: content.football
        ) else { return }
        timeline.kickWindows = windows
        content.timeline = timeline
        content.estimatedContact = phases.estimatedContactTime
        content.shownWindow = index
        state = .loaded(content)
    }

    /// Marks the frame at `time` as contact (or clears it with nil). Evaluation data only:
    /// it never changes the automatic estimate or any score.
    func markContact(at time: Double?, app: AppModel) async {
        annotationError = ContactAnnotationStore.save(time, analysisID: analysisID, app: app)
        guard annotationError == nil else { return }
        markedContact = time
        if case .loaded(var content) = state {
            content.timeline.markers.removeAll { $0.kind == .markedContact }
            if let time { content.timeline.markers.append(ValidationMarker(kind: .markedContact, title: "Marked contact", time: time)) }
            content.timeline.markers.sort { $0.time < $1.time }
            state = .loaded(content)
        }
    }

    var comparison: ContactComparison? {
        guard let marked = markedContact, let content = state.value else { return nil }
        return ContactComparison(marked: marked, estimated: content.estimatedContact,
                                 framesPerSecond: 1 / content.timeline.sampleInterval)
    }
}
