import Foundation
import Observation
import SwiftData

/// Kicks that have video, for the Analyze tab.
@MainActor
@Observable
final class AnalyzeListViewModel {
    private(set) var state: LoadState<[KickRowPresentation]> = .loading

    func load(app: AppModel) {
        guard let id = app.selectedAthleteID, let athlete = app.athleteModel(id) else {
            state = .failed("Add an athlete to get started.")
            return
        }
        let kicks = (athlete.kicks ?? [])
            .filter { !($0.videos ?? []).isEmpty }
            .sorted { $0.timestamp > $1.timestamp }
        state = .loaded(kicks.map(KickRowPresentation.init(kick:)))
    }
}

/// Runs an analysis of one kick through `KickAnalysisRunner`, with progress, cancel
/// and retry. All state changes go through `AnalysisFlowMachine`.
@MainActor
@Observable
final class AnalysisRunViewModel {
    let kickID: UUID
    private(set) var state: AnalysisFlowState = .idle
    /// The kicker point chosen by tapping, reused by "Try again".
    private(set) var kickerSeed: KickerSeed?
    /// The record of the latest run (for developer diagnostics), when one was created.
    private(set) var lastAnalysisID: UUID?
    @ObservationIgnored private var task: Task<Void, Never>?
    /// Set when the run was stopped because KickLab went to the background.
    @ObservationIgnored private var interruptedByBackground = false

    init(kickID: UUID) {
        self.kickID = kickID
    }

    /// The image and moment used for tapping the kicker (the video thumbnail).
    struct KickerSelectionSource: Equatable, Sendable {
        var thumbnailURL: URL
        var timestamp: Double
    }

    func kickerSelectionSource(app: AppModel) -> KickerSelectionSource? {
        guard let kick = ModelLookup.kick(kickID, in: app.context),
              let video = (kick.videos ?? []).first(where: \.isPrimary) ?? kick.videos?.first,
              let url = app.services.videos.thumbnailURL(for: video) else { return nil }
        return KickerSelectionSource(thumbnailURL: url, timestamp: ThumbnailTiming.time(forDuration: video.durationSeconds))
    }

    /// Records a tapped point (app-normalized, top-left origin) as the kicker.
    func chooseKicker(at point: NormalizedPoint, source: KickerSelectionSource) {
        kickerSeed = KickerSeed(timestamp: source.timestamp, point: point)
    }

    func clearKickerSeed() {
        kickerSeed = nil
    }

    /// The mode of the latest run (nil before the first run, or after `invalidate`).
    private(set) var lastRunMode: AnalysisRunMode?
    /// The engine version recorded on the latest run's analysis ("…+assisted" when user-assisted).
    private(set) var lastAnalysisVersion: String?
    /// The videos the latest run analyzed; when the kick's videos change, the finished
    /// run no longer describes them and the screen goes back to a fresh start.
    @ObservationIgnored private(set) var lastRunVideoIDs: [UUID] = []

    /// What the latest run was given by the user (nil = automatic).
    var lastAssistance: PhaseDetectionAssistance? { lastRunMode?.assistance }

    /// Starts an AUTOMATIC analysis (no user input). Used by "Start Analysis", "Try Again"
    /// and after tapping the kicker.
    func start(app: AppModel) {
        guard state.canStart else { return }
        begin(app: app, mode: .automatic)
    }

    /// "Reanalyze Automatically": a NEW analysis by the current engine on the original
    /// video, with no manual contact or kick interval — whatever earlier runs used.
    func startAutomatic(app: AppModel) {
        reanalyze(app: app, mode: .automatic)
    }

    /// "Reanalyze With Manual Contact" / "Analyze This Kick": a NEW user-assisted analysis
    /// with the choice the user just made. Earlier analyses are kept unchanged.
    func startAssisted(app: AppModel, assistance: PhaseDetectionAssistance) {
        guard !assistance.isEmpty else { return }
        reanalyze(app: app, mode: AnalysisRunMode(assistance: assistance))
    }

    /// Starts a new run in exactly `mode`, from any finished state.
    func reanalyze(app: AppModel, mode: AnalysisRunMode) {
        guard !state.isBusy else { return }
        apply(.reset)
        begin(app: app, mode: mode)
    }

    /// Forgets a finished run's outcome (the kick's videos or analyses changed), so the
    /// screen offers a fresh automatic analysis instead of an old result. A running
    /// analysis is left alone.
    func invalidate() {
        guard !state.isBusy else { return }
        state = .idle
        lastAnalysisID = nil
        lastRunMode = nil
        lastAnalysisVersion = nil
        lastRunVideoIDs = []
    }

    /// Invalidates a finished run whose analysis was deleted or whose videos changed.
    func refresh(app: AppModel) {
        guard !state.isBusy, lastRunMode != nil || lastAnalysisID != nil else { return }
        if let id = lastAnalysisID, ModelLookup.analysis(id, in: app.context) == nil {
            invalidate()
            return
        }
        let current = (ModelLookup.kick(kickID, in: app.context)?.videos ?? []).map(\.id)
        if Self.sortedIDs(current) != lastRunVideoIDs { invalidate() }
    }

    private static func sortedIDs(_ ids: [UUID]) -> [UUID] { ids.sorted { $0.uuidString < $1.uuidString } }

    private func begin(app: AppModel, mode: AnalysisRunMode) {
        guard state.canStart else { return }
        let assistance = mode.assistance
        guard let kick = ModelLookup.kick(kickID, in: app.context) else {
            state = .failed(.failed)
            return
        }
        let videos = kick.videos ?? []
        guard !videos.isEmpty else {
            state = .failed(.noVideo)
            return
        }
        guard videos.contains(where: { app.services.videos.fileExists(for: $0) }) else {
            state = .failed(.videoMissing)
            return
        }
        // Real-device protection: very long videos take minutes and a lot of memory.
        let primary = videos.first(where: \.isPrimary) ?? videos.first
        if let problem = AnalysisLimits.problem(forDurationSeconds: primary?.durationSeconds) {
            state = .failed(problem)
            return
        }
        interruptedByBackground = false
        apply(.start)
        let options = VideoAnalysisOptions(kickerSeed: kickerSeed, assistance: assistance)
        lastRunMode = mode
        lastAnalysisVersion = nil
        lastRunVideoIDs = Self.sortedIDs(videos.map(\.id))
        task = Task { [weak self] in
            await self?.run(app: app, options: options)
        }
    }

    /// Stops a running analysis because KickLab is going to the background (iOS limits
    /// background work, and pose detection can't run reliably there). The stopped run is
    /// recorded as cancelled and the screen offers "Try Again".
    func interruptForBackground() {
        guard state.isBusy else { return }
        interruptedByBackground = true
        apply(.cancelRequested)
        task?.cancel()
    }

    func cancel() {
        guard state.isBusy else { return }
        apply(.cancelRequested)
        task?.cancel()
    }

    /// "Try Again" always runs automatically: a manual choice is never reused implicitly.
    func retry(app: AppModel) {
        reanalyze(app: app, mode: .automatic)
    }

    func apply(_ event: AnalysisFlowEvent) {
        state = AnalysisFlowMachine.reduce(state, event)
    }

    private func run(app: AppModel, options: VideoAnalysisOptions) async {
        guard let kick = ModelLookup.kick(kickID, in: app.context) else {
            apply(.failed(.failed))
            return
        }
        let videos = kick.videos ?? []
        let progress: @Sendable (VideoAnalysisProgress) -> Void = { [weak self] update in
            Task { @MainActor [weak self] in self?.apply(.progress(update)) }
        }
        do {
            let outcome = try await app.services.analysisRunner.run(kick: kick, videos: videos, options: options, progress: progress)
            lastAnalysisID = outcome.analysis.id
            lastAnalysisVersion = outcome.analysis.analysisVersion
            switch outcome {
            case .completed(let analysis, _):
                apply(.completed(analysisID: analysis.id))
            case .failed(_, let reason, let summary):
                apply(.failed(AnalysisProblem.from(kickerStatus: summary?.kickerStatus, failureReason: reason)))
            case .cancelled:
                apply(interruptedByBackground ? .failed(.interruptedByBackground) : .cancelled)
            }
        } catch let error as VideoAnalysisError {
            if error == .cancelled {
                apply(interruptedByBackground ? .failed(.interruptedByBackground) : .cancelled)
            } else {
                apply(.failed(AnalysisProblem.from(engineError: error)))
            }
        } catch {
            apply(.failed(.failed))
        }
        app.dataDidChange()
    }
}

/// One stored analysis: results, coaching, personal references, comparisons and video.
@MainActor
@Observable
final class AnalysisResultsViewModel {
    struct Content: Equatable, Sendable {
        var record: AnalysisRecord
        var presentation: AnalysisResultsPresentation
        var insights: PersonalInsights
        var references: [MetricReferencePresentation]
        var previousAnalysis: ComparisonPresentation
        var baselineComparison: ComparisonPresentation
        /// Earlier kicks of the same type that can be compared.
        var earlierKicks: [KickHistoryEntry]
        /// Step 10 personalized coaching using what KickLab knows now (nil if it couldn't run).
        var coach: PersonalCoachPresentation?
    }

    let analysisID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var selectedComparison: ComparisonPresentation?
    private(set) var phaseMarkers: [PhaseMarker] = []
    private(set) var videoURL: URL?
    private(set) var phasesMessage: String?
    /// What KickLab knew when this kick was analyzed (from `personalization-v1.json`).
    private(set) var snapshotNote: String?

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    func load(app: AppModel, now: Date = .now) {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        let record = AnalysisRecord(analysis: analysis)
        let presentation = AnalysisPresentationBuilder.make(record)
        let kick = analysis.kick
        let history = kick?.athlete.map(AthleteHistory.entries(for:)) ?? []
        let others = history.filter { $0.kickID != record.kickID }
        let insights = app.insightsProvider.insights(history: others, kickType: record.kickType, now: now)
        let profile = BiomechanicsProfile.standard(for: record.kickType)
        let references = presentation.metrics.filter(\.isAvailable).map {
            MetricReferencePresentation.make(key: $0.key, currentValue: $0.value, profile: profile, insights: insights)
        }
        let snapshot = MetricSnapshot(analysis: analysis)
        state = .loaded(Content(
            record: record,
            presentation: presentation,
            insights: insights,
            references: references,
            previousAnalysis: Self.previousComparison(analysis: analysis, snapshot: snapshot, profile: profile),
            baselineComparison: Self.baselineComparison(snapshot: snapshot, insights: insights, profile: profile),
            earlierKicks: others.filter { $0.kickType == record.kickType }.sorted { $0.date > $1.date },
            coach: (try? app.services.learning.coaching(for: analysis, now: now)).map { PersonalCoachPresentation.make(report: $0.report) }
        ))
    }

    /// Reads the personalization snapshot stored with the analysis (off the main actor).
    func loadSnapshot(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context), let directory = analysis.artifactsRelativePath else {
            snapshotNote = nil
            return
        }
        let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        let artifact = await Task.detached { () -> PersonalizationArtifact? in
            try? store.readPersonalization(in: directory)
        }.value
        snapshotNote = artifact.map(PersonalCoachPresentation.snapshotNote)
    }

    static func previousComparison(analysis: BiomechanicsAnalysis, snapshot: MetricSnapshot?, profile: BiomechanicsProfile) -> ComparisonPresentation {
        let earlier = (analysis.kick?.analyses ?? [])
            .filter { $0.id != analysis.id && $0.processingStatus == .completed && $0.createdAt < analysis.createdAt }
            .max { $0.createdAt < $1.createdAt }
        guard let snapshot, let earlier, let reference = MetricSnapshot(analysis: earlier) else {
            return .unavailable(.previousAnalysis, message: "This is the first completed analysis of this kick.")
        }
        return .make(deltas: MetricComparison.compare(snapshot, to: reference, profile: profile), target: .previousAnalysis)
    }

    static func baselineComparison(snapshot: MetricSnapshot?, insights: PersonalInsights, profile: BiomechanicsProfile) -> ComparisonPresentation {
        guard let snapshot, let baseline = insights.baseline else {
            return .unavailable(.baseline, message: PersonalInsights.baselineNeededMessage)
        }
        return .make(deviations: MetricComparison.compare(snapshot, to: baseline, profile: profile))
    }

    /// Compares this kick with an earlier kick the person picked.
    func compare(with entry: KickHistoryEntry, app: AppModel) {
        guard let content = state.value, let analysis = ModelLookup.analysis(analysisID, in: app.context),
              let snapshot = MetricSnapshot(analysis: analysis) else { return }
        let profile = BiomechanicsProfile.standard(for: content.record.kickType)
        selectedComparison = .make(deltas: MetricComparison.compare(snapshot, to: entry.snapshot, profile: profile),
                                   target: .earlierKick(date: entry.date))
    }

    /// Loads the analyzed video and its phase jump points from the analysis artifacts
    /// (off the main actor; the files are only read).
    /// Step 12D: user-assisted recovery offered for this analysis, and recording guidance.
    private(set) var assistanceOffer: AssistanceOffer = .none
    private(set) var suitability: [SuitabilityFinding] = []
    /// Engine version and who set the contact time (nil until the phase file is read).
    private(set) var provenance: AnalysisProvenance?
    /// Step 12F: the numbered coaching-report overview (sections 1–6).
    private(set) var report: CoachingReportOverview?
    var deletionError: String?

    /// Deletes this analysis and its files (see `AnalysisDeletionService`). The kick, its
    /// videos and other analyses stay. Returns true when deleted.
    func deleteAnalysis(app: AppModel) -> Bool {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else { return true }
        let kickID = analysis.kick?.id
        let running = kickID.map { app.analysisRun(for: $0).state.isBusy } ?? false
        do {
            try app.services.analysisDeletion.delete(analysis, runInProgress: running)
            if let kickID { app.invalidateAnalysisRun(for: kickID) }
            app.dataDidChange()
            return true
        } catch let error as AnalysisDeletionService.DeletionError {
            deletionError = error.errorDescription
            return false
        } catch {
            deletionError = UserFacingError.message(for: error)
            return false
        }
    }

    func loadVideo(app: AppModel) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else { return }
        guard let directory = analysis.artifactsRelativePath else {
            provenance = AnalysisProvenance(engineVersion: analysis.analysisVersion, phases: nil)
            phasesMessage = "Phase markers aren't available for this analysis."
            videoURL = primaryVideoURL(analysis: analysis, app: app)
            return
        }
        let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        let result = await Task.detached { () -> PhaseArtifactSummary? in
            try? store.readPhases(in: directory)
        }.value
        if let result {
            phaseMarkers = PhaseMarker.markers(from: result.phases.phases)
            assistanceOffer = AssistanceOffer.make(phases: result.phases.phases, engineVersion: analysis.analysisVersion)
            provenance = AnalysisProvenance(engineVersion: analysis.analysisVersion, phases: result.phases.phases)
            suitability = (result.manifest.suitability ?? []).filter { $0.severity != .info }
            if let presentation = state.value?.presentation {
                report = CoachingReportOverview.make(CoachingReportOverview.Input(
                    kickType: analysis.kick?.kickType ?? .unknown,
                    date: analysis.kick?.timestamp ?? analysis.createdAt, engineVersion: analysis.analysisVersion,
                    perspective: result.manifest.perspective, outcome: presentation.header.outcome, phases: result.phases.phases,
                    metrics: presentation.metrics, annotation: ContactAnnotationStore.annotation(for: analysis),
                    nominalFrameRate: ContactAnnotationStore.primaryVideo(of: analysis)?.frameRate,
                    hasContactPriorities: presentation.priorities.contains { $0.category == .contact }
                ))
            }
            let analyzed = ModelLookup.video(result.manifest.primaryVideoID, in: app.context)
            videoURL = analyzed.flatMap { app.services.videos.fileURL(for: $0) } ?? primaryVideoURL(analysis: analysis, app: app)
            phasesMessage = phaseMarkers.isEmpty ? "No kick phases were found in this video." : nil
        } else {
            provenance = AnalysisProvenance(engineVersion: analysis.analysisVersion, phases: nil)
            phasesMessage = "Phase markers couldn't be loaded."
            videoURL = primaryVideoURL(analysis: analysis, app: app)
        }
    }

    private func primaryVideoURL(analysis: BiomechanicsAnalysis, app: AppModel) -> URL? {
        let videos = analysis.kick?.videos ?? []
        let video = videos.first(where: \.isPrimary) ?? videos.first
        return video.flatMap { video in
            app.services.videos.fileExists(for: video) ? app.services.videos.fileURL(for: video) : nil
        }
    }
}

/// All analyses of one kick, or of the whole athlete, newest first. Older analyses are
/// kept and listed; the current one is marked.
@MainActor
@Observable
final class AnalysisHistoryViewModel {
    enum Scope: Equatable, Sendable {
        case kick(UUID)
        case athlete
    }

    let scope: Scope
    private(set) var state: LoadState<[AnalysisRecord]> = .loading

    init(scope: Scope) {
        self.scope = scope
    }

    func load(app: AppModel) {
        switch scope {
        case .kick(let id):
            guard let kick = ModelLookup.kick(id, in: app.context) else {
                state = .failed("This kick no longer exists.")
                return
            }
            state = .loaded((kick.analyses ?? []).map(AnalysisRecord.init(analysis:)).sorted { $0.date > $1.date })
        case .athlete:
            guard let id = app.selectedAthleteID, let athlete = app.athleteModel(id) else {
                state = .failed("Add an athlete to get started.")
                return
            }
            state = .loaded(AthleteHistory.allAnalyses(for: athlete).map(AnalysisRecord.init(analysis:)))
        }
    }
}
