import Foundation
import Observation
import SwiftData

/// The home dashboard for the selected athlete. Reads only through services.
@MainActor
@Observable
final class HomeViewModel {
    private(set) var state: LoadState<DashboardPresentation> = .loading

    /// Recent stats cover this many days.
    static let recentDays = 30

    func load(app: AppModel, now: Date = .now) {
        guard let athlete = app.selectedAthlete else {
            state = .failed("Add an athlete to get started.")
            return
        }
        do {
            state = .loaded(try Self.dashboard(for: athlete, app: app, now: now))
        } catch {
            state = .failed(UserFacingError.message(for: error))
        }
    }

    static func dashboard(for athlete: AthleteSummary, app: AppModel, now: Date) throws -> DashboardPresentation {
        let statistics = app.services.statistics
        let filter = StatisticsFilter(athleteID: athlete.id)
        let recent = filter.with(dateRange: StatisticsPeriod.last(days: recentDays, endingAt: now))
        let total = try statistics.totalKickCount(filter)
        let fieldGoals = try statistics.fieldGoalStatistics(recent)
        let kickoffs = try statistics.kickoffStatistics(recent)
        let recentKicks = try statistics.recentKicks(limit: 5, filter)
        let trend = try statistics.trendForLast(days: recentDays, endingAt: now, filter)

        var latest: LatestAnalysisSummary?
        if let model = app.athleteModel(athlete.id), let analysis = AthleteHistory.latestAnalysis(for: model) {
            let record = AnalysisRecord(analysis: analysis)
            // Step 10: the personalized coach's first fix (it falls back to the Step 8
            // ranking whenever personal evidence is weak); Step 8 alone if it can't run.
            let topPriority: CoachingItemPresentation?
            if let coaching = try? app.services.learning.coaching(for: analysis, now: now) {
                topPriority = PersonalCoachPresentation.topPriority(coaching.report)
            } else {
                topPriority = AnalysisPresentationBuilder.coachingItems(record.observations).priorities.first
            }
            latest = LatestAnalysisSummary(
                analysisID: record.id, kickID: record.kickID, kickType: record.kickType, date: record.date,
                overallScore: record.overallScore, confidence: record.confidence, topPriority: topPriority
            )
        }
        return DashboardPresentation.make(
            athlete: athlete, totalKicks: total, recentFieldGoals: fieldGoals, recentKickoffs: kickoffs,
            recentKicks: recentKicks, latestAnalysis: latest, trend: trend
        )
    }
}
