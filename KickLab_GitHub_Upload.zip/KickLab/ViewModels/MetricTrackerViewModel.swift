import Foundation
import Observation

/// Build 23: the Metric Tracker's data — every kick's current analysis for the selected
/// athlete, grouped by kick type and camera view (`MetricTracker`). Read-only.
@MainActor
@Observable
final class MetricTrackerViewModel {
    private(set) var groups: [MetricTrackerGroup] = []
    private(set) var hasLoaded = false
    var selectedGroupID: String?

    init() {}

    var selectedGroup: MetricTrackerGroup? {
        groups.first { $0.id == selectedGroupID } ?? groups.first
    }

    func load(app: AppModel) {
        defer { hasLoaded = true }
        guard let id = app.selectedAthleteID, let athlete = app.athleteModel(id) else {
            groups = []
            return
        }
        let entries = (athlete.kicks ?? []).compactMap { kick in
            (kick.analyses ?? []).first(where: \.isCurrent).map(RankingEntry.init(analysis:))
        }
        groups = MetricTracker.groups(entries)
        if let selected = selectedGroupID, !groups.contains(where: { $0.id == selected }) { selectedGroupID = nil }
    }

    func track(group: String, key: String) -> MetricTrack? {
        groups.first { $0.id == group }?.tracks.first { $0.key.rawValue == key }
    }
}
