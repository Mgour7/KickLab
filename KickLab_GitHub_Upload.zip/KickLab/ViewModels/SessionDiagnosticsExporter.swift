import Foundation
import Observation
import SwiftData

/// Build 21 Hotfix 2 — builds the session diagnostics ZIP (and, only when chosen, sanitized
/// video copies) for the iOS share sheet. Reads only; nothing in the session, the Kick
/// records or the recordings is changed. See Docs/SESSION_DIAGNOSTICS.md.
@MainActor
@Observable
final class SessionDiagnosticsExporter {
    let sessionID: UUID
    private(set) var isWorking = false
    private(set) var shareURLs: [URL] = []
    private(set) var problem: String?
    private(set) var summary: String?

    init(sessionID: UUID) { self.sessionID = sessionID }

    func export(app: AppModel, video: SessionDiagnosticVideoChoice, selectedCandidateID: UUID?, includeSound: Bool) async {
        isWorking = true
        defer { isWorking = false }
        problem = nil
        shareURLs = []
        let store = app.services.trainingSessions
        guard let m = try? store.load(sessionID) else { problem = "This session couldn't be read."; return }
        let exportID = String(UUID().uuidString.prefix(8)).lowercased()
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("kicklab-diagnostics-\(exportID)", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        // Recordings: cached scans and measured timing.
        var scans: [UUID: [SessionScanSample]] = [:]
        var media: [UUID: MediaTimingInfo] = [:]
        for s in m.sources {
            if let samples = store.loadScan(session: sessionID, source: s.id) { scans[s.id] = samples }
            let url = store.url(session: sessionID, relativePath: s.relativePath)
            if FileManager.default.fileExists(atPath: url.path) { media[s.id] = await app.services.mediaTiming.timing(of: url) }
        }

        // Kicks: their clip timing, entered result and every analysis (with its Evidence Bundle).
        var kicks: [UUID: SessionDiagnosticsKickInput] = [:]
        var evidence: [(name: String, data: Data)] = []
        var clipURLs: [UUID: URL] = [:]
        var evidenceCounter = 0
        let artifactStore = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        for c in m.candidates {
            guard let kickID = c.kickID, let kick = ModelLookup.kick(kickID, in: app.context) else { continue }
            let primary = (kick.videos ?? []).first(where: \.isPrimary)
            var clipMedia: MediaTimingInfo?
            if let primary, app.services.videos.fileExists(for: primary), let url = app.services.videos.fileURL(for: primary) {
                clipMedia = await app.services.mediaTiming.timing(of: url)
                clipURLs[c.id] = url
            }
            let stat = KickStatRecord(kick: kick)
            var analyses: [(id: UUID, engineVersion: String, status: String, isCurrent: Bool, failureReason: String?, createdAt: Date, evidenceFile: String?)] = []
            for a in (kick.analyses ?? []).sorted(by: { $0.createdAt < $1.createdAt }) {
                var file: String?
                if let directory = a.artifactsRelativePath {
                    let bundle: AnalysisArtifactBundle? = await Task.detached { try? artifactStore.readBundle(in: directory) }.value
                    if let data = Self.evidenceData(bundle: bundle, analysis: a, kick: kick, angle: primary?.angleType) {
                        evidenceCounter += 1
                        let name = "evidence/analysis\(evidenceCounter).zip"
                        evidence.append((name, data))
                        file = name
                    }
                }
                analyses.append((a.id, a.analysisVersion, a.processingStatus.rawValue, a.isCurrent, a.failureReason, a.createdAt, file))
            }
            kicks[c.id] = SessionDiagnosticsKickInput(videoAngle: primary?.angleType.rawValue, clipMedia: clipMedia,
                                                      enteredResult: stat.result?.rawValue, enteredDistanceYards: stat.distanceYards,
                                                      analyses: analyses)
        }

        // Optional video (sanitized copies; the originals stay as they are).
        var videoFiles: [URL] = []
        var included: [String] = []
        do {
            let exporter = app.services.sharingVideoExporter
            func copy(_ source: URL, name: String) async throws {
                let dest = folder.appendingPathComponent(name)
                try await exporter.exportForSharing(source: source, includeAudio: includeSound, to: dest)
                videoFiles.append(dest)
                included.append(name)
            }
            switch video {
            case .none:
                break
            case .selectedKick:
                if let id = selectedCandidateID, let url = clipURLs[id] { try await copy(url, name: "kick-clip-\(exportID).mov") }
            case .allKickClips:
                for (n, c) in m.candidates.filter({ clipURLs[$0.id] != nil }).enumerated() {
                    if let url = clipURLs[c.id] { try await copy(url, name: "kick-clip-\(n + 1)-\(exportID).mov") }
                }
            case .originalRecordings:
                for (n, s) in m.sources.enumerated() {
                    let url = store.url(session: sessionID, relativePath: s.relativePath)
                    if FileManager.default.fileExists(atPath: url.path) { try await copy(url, name: "recording-\(n + 1)-\(exportID).mov") }
                }
            }
        } catch {
            problem = "The video couldn't be copied (\(error.localizedDescription)). The diagnostics file is still available."
        }

        let info = Bundle.main.infoDictionary
        let appInfo = SessionDiagnosticsReport.AppInfo(
            appVersion: info?["CFBundleShortVersionString"] as? String, appBuild: info?["CFBundleVersion"] as? String,
            osVersion: ProcessInfo.processInfo.operatingSystemVersionString, engineVersion: app.services.analysisEngine.engineVersion)
        let report = SessionDiagnosticsBuilder.make(m, scans: scans, media: media, kicks: kicks, app: appInfo, exportID: exportID,
                                                    includedVideos: included, now: .now)
        let zipURL = folder.appendingPathComponent("KickLab-session-diagnostics-\(exportID).zip")
        let scanFiles: [(String, Data)] = m.sources.compactMap { s in
            guard let samples = scans[s.id], let ref = report.recordings.first(where: { sourceRefMatches(s, $0, m) }), let name = ref.scanFile else { return nil }
            return (name, Data(SessionDiagnosticsBuilder.scanCSV(samples).utf8))
        }
        let evidenceEntries = evidence
        let result = await Task.detached { [evidenceEntries, scanFiles, report, zipURL] () -> Result<Void, Error> in
            do {
                var entries: [StoredZip.Entry] = [
                    StoredZip.Entry(path: "session.json", data: try SessionDiagnosticsBuilder.jsonEncoder().encode(report)),
                    StoredZip.Entry(path: "README.txt", data: Data(SessionDiagnosticsBuilder.readme(report).utf8)),
                ]
                entries += scanFiles.map { StoredZip.Entry(path: $0.0, data: $0.1) }
                entries += evidenceEntries.map { StoredZip.Entry(path: $0.name, data: $0.data) }
                try StoredZip.write(entries).write(to: zipURL, options: .atomic)
                return .success(())
            } catch {
                return .failure(error)
            }
        }.value
        switch result {
        case .success:
            shareURLs = [zipURL] + videoFiles
            summary = "\(report.recordings.count) recording(s), \(report.candidates.count) candidate(s), \(evidence.count) analysis bundle(s)"
                + (included.isEmpty ? ", no video." : ", \(included.count) video file(s).")
        case .failure(let error):
            problem = "The diagnostics file couldn't be created: \(error.localizedDescription)"
        }
    }

    /// The recording a report entry describes (same camera/segment order as the builder).
    private func sourceRefMatches(_ s: SessionSource, _ r: SessionDiagnosticsReport.Recording, _ m: TrainingSessionManifest) -> Bool {
        guard let cameraIndex = m.cameraIDs.firstIndex(of: m.cameraID(of: s)),
              let n = m.segments(ofCamera: m.cameraID(of: s)).firstIndex(where: { $0.id == s.id }) else { return false }
        return r.ref == "camera\(cameraIndex + 1)-recording\(n + 1)"
    }

    /// One analysis as an Evidence Bundle v1 (unchanged format; no video, no crops).
    private static func evidenceData(bundle: AnalysisArtifactBundle?, analysis a: BiomechanicsAnalysis, kick: Kick, angle: VideoAngleType?) -> Data? {
        guard let bundle else { return nil }
        var annotations = EvidenceAnnotations(contactAnnotation: {
            switch ContactAnnotationStore.annotation(for: a) {
            case .none: "none"
            case .contact: "contact"
            case .cannotTell: "cannotTell"
            }
        }())
        annotations.markedContactTime = ContactAnnotationStore.markedContact(for: a)
        annotations.verification = ContactAnnotationStore.primaryVideo(of: a)?.verification
        annotations.analysisAssistance = bundle.manifest.assistance
        let info = Bundle.main.infoDictionary
        let context = EvidenceExportContext(
            appVersion: info?["CFBundleShortVersionString"] as? String, appBuild: info?["CFBundleVersion"] as? String,
            osVersion: ProcessInfo.processInfo.operatingSystemVersionString, status: a.processingStatus.rawValue,
            failureReason: a.failureReason, kickType: kick.kickType, cameraAngle: angle, annotations: annotations,
            summaryText: "Exported with session diagnostics.", createdAt: .now)
        return try? EvidenceBundle.build(artifacts: bundle, context: context).data
    }
}
