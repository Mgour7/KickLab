import Foundation
import Observation
import SwiftData

/// Outcome statistics plus personal mechanics insights for one kick type.
@MainActor
@Observable
final class StatsViewModel {
    struct Content: Equatable, Sendable {
        var sections: [StatSection]
        var insights: PersonalInsights
    }

    var datePreset: StatsDatePreset = .last30
    var kickType: StatsKickTypeFilter = .fieldGoal
    private(set) var state: LoadState<Content> = .loading

    func load(app: AppModel, now: Date = .now) {
        guard let athlete = app.selectedAthlete else {
            state = .failed("Add an athlete to get started.")
            return
        }
        let filter = StatisticsFilter(athleteID: athlete.id, dateRange: datePreset.range(endingAt: now))
        let statistics = app.services.statistics
        do {
            let sections: [StatSection]
            switch kickType {
            case .fieldGoal:
                sections = StatisticsPresentation.fieldGoalSections(try statistics.fieldGoalStatistics(filter, kickType: .fieldGoal))
            case .pat:
                sections = StatisticsPresentation.fieldGoalSections(try statistics.fieldGoalStatistics(filter, kickType: .pat))
            case .kickoff:
                sections = StatisticsPresentation.kickoffSections(try statistics.kickoffStatistics(filter))
            case .punt:
                sections = StatisticsPresentation.puntSections(try statistics.puntStatistics(filter))
            }
            let history = app.athleteModel(athlete.id).map(AthleteHistory.entries(for:)) ?? []
            let insights = app.insightsProvider.insights(history: history, kickType: kickType.kickType, now: now)
            state = .loaded(Content(sections: sections, insights: insights))
        } catch {
            state = .failed(UserFacingError.message(for: error))
        }
    }
}

/// Creating or editing an athlete. Only fields that matter to kicking analysis are shown;
/// other stored profile fields are preserved untouched when editing.
@MainActor
@Observable
final class AthleteEditorViewModel {
    var firstName: String
    var lastName: String
    var kickingFoot: KickingFoot
    var playingLevel: PlayingLevel
    private(set) var issues: [AthleteProfileIssue] = []
    var errorMessage: String?
    let athleteID: UUID?
    @ObservationIgnored private var baseProfile: AthleteProfile

    init(athleteID: UUID? = nil, app: AppModel? = nil) {
        self.athleteID = athleteID
        if let athleteID, let app, let athlete = app.athleteModel(athleteID) {
            baseProfile = app.services.athletes.profile(of: athlete)
        } else {
            baseProfile = AthleteProfile(firstName: "")
        }
        firstName = baseProfile.firstName
        lastName = baseProfile.lastName
        kickingFoot = baseProfile.kickingFoot
        playingLevel = baseProfile.currentPlayingLevel
    }

    var profile: AthleteProfile {
        var p = baseProfile
        p.firstName = firstName
        p.lastName = lastName
        p.kickingFoot = kickingFoot
        p.currentPlayingLevel = playingLevel
        return p
    }

    var issueMessages: [String] { issues.map(Self.message) }

    nonisolated static func message(_ issue: AthleteProfileIssue) -> String {
        switch issue {
        case .missingName: "Enter a first or last name."
        case .dateOfBirthInFuture: "Date of birth can't be in the future."
        case .nonFiniteValue, .valueOutOfRange: "One of the profile values isn't valid."
        case .jerseyNumberTooLong: "Jersey number is too long."
        }
    }

    /// Saves and selects the athlete. Returns its ID.
    func save(app: AppModel, now: Date = .now) -> UUID? {
        issues = AthleteProfileValidator.validate(profile)
        guard issues.isEmpty else { return nil }
        do {
            if let athleteID, let athlete = app.athleteModel(athleteID) {
                let previousFoot = athlete.kickingFoot
                try app.services.athletes.updateProfile(athlete, with: profile)
                // Step 10: remember when the kicking foot changed, so earlier kicks keep
                // their own foot and never mix into the new foot's baseline.
                if previousFoot != kickingFoot {
                    app.services.personalizationState.update(athleteID) {
                        $0.recordFootChange(from: previousFoot, to: kickingFoot, at: now)
                    }
                }
                app.dataDidChange()
                return athleteID
            }
            let athlete = try app.services.athletes.createAthlete(profile)
            app.dataDidChange()
            app.select(athlete.id)
            return athlete.id
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return nil
        }
    }
}

/// Safe, confirmed permanent deletion using the service's deletion plan.
@MainActor
@Observable
final class AthleteDeletionViewModel {
    let athleteID: UUID
    private(set) var plan: AthleteDeletionPlan?
    var typedConfirmation = ""
    var errorMessage: String?

    init(athleteID: UUID) {
        self.athleteID = athleteID
    }

    func prepare(app: AppModel) {
        guard let athlete = app.athleteModel(athleteID) else {
            errorMessage = "This athlete no longer exists."
            return
        }
        do {
            plan = try app.services.athletes.deletionPlan(for: athlete)
        } catch {
            errorMessage = UserFacingError.message(for: error)
        }
    }

    var summary: String {
        guard let plan else { return "" }
        return "Deletes \(plan.sessionCount) sessions, \(plan.kickCount) kicks, \(plan.videoCount) videos and \(plan.analysisCount) analyses. Videos in your Photos library are not touched."
    }

    var canDelete: Bool {
        guard let plan else { return false }
        return plan.isConfirmed(by: AthleteDeletionConfirmation(typedText: typedConfirmation))
    }

    func delete(app: AppModel) -> Bool {
        guard let plan, canDelete else { return false }
        do {
            try app.services.athletes.permanentlyDelete(using: plan, confirmation: AthleteDeletionConfirmation(typedText: typedConfirmation))
            app.services.personalizationState.removeState(for: athleteID)
            app.dataDidChange()
            return true
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return false
        }
    }
}
