import Foundation
import Observation
import SwiftData

/// Builds the developer diagnostics report for one analysis on the iPhone, from the
/// analysis record and its stored files. Nothing is uploaded; the report is only shared
/// if the person chooses to.
@MainActor
@Observable
final class AnalysisDiagnosticsViewModel {
    let analysisID: UUID
    private(set) var state: LoadState<AnalysisDiagnosticsReport> = .loading

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    static var appVersion: String? {
        let info = Bundle.main.infoDictionary
        guard let version = info?["CFBundleShortVersionString"] as? String else { return nil }
        return "\(version) (\(info?["CFBundleVersion"] as? String ?? "?"))"
    }

    func load(app: AppModel, now: Date = .now) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        let kickType = analysis.kick?.kickType ?? .unknown
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) }
        let status = analysis.processingStatus.rawValue
        let reason = analysis.failureReason
        let angle = (analysis.metrics ?? []).compactMap(\.sourceAngle).first
            ?? (analysis.inputVideos ?? []).first(where: \.isPrimary)?.angleType
        let appVersion = Self.appVersion
        let fallback = AnalysisDiagnosticsInput(kickType: kickType, engineVersion: analysis.analysisVersion, cameraAngle: angle)
        var readProblem: String?
        var input = fallback
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let loaded = await Task.detached { () -> Result<AnalysisArtifactBundle, AnalysisArtifactError> in
                do {
                    return .success(try store.readBundle(in: directory))
                } catch let error as AnalysisArtifactError {
                    return .failure(error)
                } catch {
                    return .failure(.corrupt(String(describing: error)))
                }
            }.value
            switch loaded {
            case .success(let bundle): input = AnalysisDiagnosticsInput(bundle: bundle)
            case .failure(let error): readProblem = "Analysis files couldn't be read: \(error)"
            }
        }
        let reference = Self.primaryVideo(of: analysis).flatMap { $0.contactTimeSource == .manual ? $0.contactTimeSeconds : nil }
        referenceContactTime = reference
        let builderInput = input
        let report = await Task.detached {
            AnalysisDiagnosticsBuilder.build(
                builderInput, storedStatus: status, storedFailureReason: reason, kickingFoot: foot,
                appVersion: appVersion, generatedAt: now, referenceContactTime: reference
            )
        }.value
        var finished = report
        if let readProblem { finished.contributingFactors.insert(readProblem, at: 0) }
        state = .loaded(finished)
    }

    /// Step 12B: the contact time marked on the analyzed video (validation reference).
    private(set) var referenceContactTime: Double?
    private(set) var referenceError: String?

    private static func primaryVideo(of analysis: BiomechanicsAnalysis) -> VideoAsset? {
        let videos = analysis.inputVideos ?? []
        return videos.first(where: \.isPrimary) ?? videos.first
    }

    /// Marks (or clears, with nil) the visible strike time on the analyzed video, then
    /// rebuilds the report so the estimate can be compared with it. Only used for
    /// validation; analysis never reads it.
    func saveReferenceContact(_ seconds: Double?, app: AppModel) async {
        referenceError = nil
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context),
              let video = Self.primaryVideo(of: analysis) else {
            referenceError = "The analyzed video is no longer available."
            return
        }
        if let seconds {
            guard seconds.isFinite, seconds >= 0, seconds <= (video.durationSeconds ?? .greatestFiniteMagnitude) else {
                referenceError = "Enter a time within the video."
                return
            }
        }
        video.contactTimeSeconds = seconds
        video.contactTimeSource = seconds == nil ? nil : .manual
        do {
            try app.context.save()
        } catch {
            referenceError = "Couldn't save the contact time."
            return
        }
        await load(app: app)
    }
}
