import Foundation
import Observation
import SwiftData

/// Builds the developer diagnostics report for one analysis on the iPhone, from the
/// analysis record and its stored files. Nothing is uploaded; the report is only shared
/// if the person chooses to.
@MainActor
@Observable
final class AnalysisDiagnosticsViewModel {
    let analysisID: UUID
    private(set) var state: LoadState<AnalysisDiagnosticsReport> = .loading

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    static var appVersion: String? {
        let info = Bundle.main.infoDictionary
        guard let version = info?["CFBundleShortVersionString"] as? String else { return nil }
        return "\(version) (\(info?["CFBundleVersion"] as? String ?? "?"))"
    }

    func load(app: AppModel, now: Date = .now) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        let kickType = analysis.kick?.kickType ?? .unknown
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) }
        let status = analysis.processingStatus.rawValue
        let reason = analysis.failureReason
        let angle = (analysis.metrics ?? []).compactMap(\.sourceAngle).first
            ?? (analysis.inputVideos ?? []).first(where: \.isPrimary)?.angleType
        let appVersion = Self.appVersion
        let fallback = AnalysisDiagnosticsInput(kickType: kickType, engineVersion: analysis.analysisVersion, cameraAngle: angle)
        var readProblem: String?
        var input = fallback
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let loaded = await Task.detached { () -> Result<AnalysisArtifactBundle, AnalysisArtifactError> in
                do {
                    return .success(try store.readBundle(in: directory))
                } catch let error as AnalysisArtifactError {
                    return .failure(error)
                } catch {
                    return .failure(.corrupt(String(describing: error)))
                }
            }.value
            switch loaded {
            case .success(let bundle): input = AnalysisDiagnosticsInput(bundle: bundle)
            case .failure(let error): readProblem = "Analysis files couldn't be read: \(error)"
            }
        }
        let reference = ContactAnnotationStore.markedContact(for: analysis)
        referenceContactTime = reference
        let annotation: String = {
            switch ContactAnnotationStore.annotation(for: analysis) {
            case .none: "none"
            case .contact: "contact"
            case .cannotTell: "cannotTell"
            }
        }()
        let verification = ContactAnnotationStore.primaryVideo(of: analysis)?.verification
        let builderInput = input
        let report = await Task.detached {
            AnalysisDiagnosticsBuilder.build(
                builderInput, storedStatus: status, storedFailureReason: reason, kickingFoot: foot,
                appVersion: appVersion, generatedAt: now, referenceContactTime: reference, humanAnnotation: annotation,
                verification: verification
            )
        }.value
        var finished = report
        if let readProblem { finished.contributingFactors.insert(readProblem, at: 0) }
        state = .loaded(finished)
    }

    /// Step 12B: the contact time marked on the analyzed video (validation reference).
    private(set) var referenceContactTime: Double?
    private(set) var referenceError: String?

    /// Marks (or clears, with nil) the visible strike time on the analyzed video, then
    /// rebuilds the report so the estimate can be compared with it. Only used for
    /// validation; analysis never reads it.
    func saveReferenceContact(_ seconds: Double?, app: AppModel) async {
        referenceError = ContactAnnotationStore.save(seconds, analysisID: analysisID, app: app)
        if referenceError == nil { await load(app: app) }
    }

    /// Step 12C: the analysis' stored pose plus the marked contact as a reference clip for
    /// the private validation library. Contains body coordinates (no video frames or
    /// names), so it is only produced when the person explicitly asks.
    func validationClipJSON(app: AppModel, annotator: String, rightsNote: String) async -> String? {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context),
              let directory = analysis.artifactsRelativePath,
              let marked = ContactAnnotationStore.markedContact(for: analysis) else { return nil }
        let kickType = analysis.kick?.kickType ?? .unknown
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) } ?? .right
        let angle = ContactAnnotationStore.primaryVideo(of: analysis)?.angleType ?? .unknown
        let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
        let clipID = "\(kickType.rawValue)-\(angle.rawValue)-\(analysisID.uuidString.prefix(8).lowercased())"
        return await Task.detached { () -> String? in
            guard let bundle = try? store.readBundle(in: directory) else { return nil }
            let clip = ContactReferenceClip(
                clipID: clipID, kickType: kickType, kickingFoot: foot, cameraAngle: angle,
                sourceFrameRate: bundle.pose.sequence.nominalFrameRate, annotatedContactTime: marked,
                annotationUncertaintyFrames: 1, annotator: annotator, rightsNote: rightsNote,
                poseEngineVersion: bundle.manifest.engineVersion, sequence: bundle.pose.sequence
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.sortedKeys]
            return (try? encoder.encode(clip)).flatMap { String(data: $0, encoding: .utf8) }
        }.value
    }
}

/// Step 12C: the manually marked contact time (evaluation data only). Stored on the
/// analyzed video as `contactTimeSeconds` with source `.manual`. Analysis never reads it:
/// `VideoAnalysisRequest.make` leaves manual marks out of the engine's input.
@MainActor
enum ContactAnnotationStore {
    static func primaryVideo(of analysis: BiomechanicsAnalysis) -> VideoAsset? {
        let videos = analysis.inputVideos ?? []
        return videos.first(where: \.isPrimary) ?? videos.first
    }

    static func markedContact(for analysis: BiomechanicsAnalysis) -> Double? {
        primaryVideo(of: analysis).flatMap { $0.contactTimeSource == .manual ? $0.contactTimeSeconds : nil }
    }

    /// Step 12F: the verification state (a frame, "can't tell", or nothing).
    static func annotation(for analysis: BiomechanicsAnalysis) -> ContactAnnotation {
        guard let video = primaryVideo(of: analysis) else { return .none }
        switch video.contactTimeSource {
        case .manual: return video.contactTimeSeconds.map { .contact(time: $0) } ?? .none
        case .cannotTell: return .cannotTell
        case .detected, .unknown, .none: return .none
        }
    }

    /// Step 12F: records "reviewed, can't tell" (clears any saved frame).
    static func saveCannotTell(analysisID: UUID, app: AppModel) -> String? {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context), let video = primaryVideo(of: analysis) else {
            return "The analyzed video is no longer available."
        }
        video.contactTimeSeconds = nil
        video.contactTimeSource = .cannotTell
        do {
            try app.context.save()
        } catch {
            return "Couldn't save your answer."
        }
        return nil
    }

    /// Saves (or clears) the mark. Returns a user-facing problem, or nil on success.
    static func save(_ seconds: Double?, analysisID: UUID, app: AppModel) -> String? {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context), let video = primaryVideo(of: analysis) else {
            return "The analyzed video is no longer available."
        }
        if let seconds {
            guard seconds.isFinite, seconds >= 0, seconds <= (video.durationSeconds ?? .greatestFiniteMagnitude) else {
                return "Enter a time within the video."
            }
        }
        video.contactTimeSeconds = seconds
        video.contactTimeSource = seconds == nil ? nil : .manual
        do {
            try app.context.save()
        } catch {
            return "Couldn't save the contact time."
        }
        return nil
    }
}
