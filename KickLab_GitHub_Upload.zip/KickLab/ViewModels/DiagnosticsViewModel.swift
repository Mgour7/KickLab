import Foundation
import Observation
import SwiftData

/// Builds the developer diagnostics report for one analysis on the iPhone, from the
/// analysis record and its stored files. Nothing is uploaded; the report is only shared
/// if the person chooses to.
@MainActor
@Observable
final class AnalysisDiagnosticsViewModel {
    let analysisID: UUID
    private(set) var state: LoadState<AnalysisDiagnosticsReport> = .loading

    init(analysisID: UUID) {
        self.analysisID = analysisID
    }

    static var appVersion: String? {
        let info = Bundle.main.infoDictionary
        guard let version = info?["CFBundleShortVersionString"] as? String else { return nil }
        return "\(version) (\(info?["CFBundleVersion"] as? String ?? "?"))"
    }

    func load(app: AppModel, now: Date = .now) async {
        guard let analysis = ModelLookup.analysis(analysisID, in: app.context) else {
            state = .failed("This analysis no longer exists.")
            return
        }
        let kickType = analysis.kick?.kickType ?? .unknown
        let foot = analysis.kick?.athlete.map { app.services.learning.kickingFoot(for: analysis, athlete: $0) }
        let status = analysis.processingStatus.rawValue
        let reason = analysis.failureReason
        let angle = (analysis.metrics ?? []).compactMap(\.sourceAngle).first
            ?? (analysis.inputVideos ?? []).first(where: \.isPrimary)?.angleType
        let fallback = AnalysisDiagnosticsInput(kickType: kickType, engineVersion: analysis.analysisVersion, cameraAngle: angle)
        var readProblem: String?
        var input = fallback
        if let directory = analysis.artifactsRelativePath {
            let store = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
            let loaded = await Task.detached { () -> Result<AnalysisArtifactBundle, AnalysisArtifactError> in
                do {
                    return .success(try store.readBundle(in: directory))
                } catch let error as AnalysisArtifactError {
                    return .failure(error)
                } catch {
                    return .failure(.corrupt(String(describing: error)))
                }
            }.value
            switch loaded {
            case .success(let bundle): input = AnalysisDiagnosticsInput(bundle: bundle)
            case .failure(let error): readProblem = "Analysis files couldn't be read: \(error)"
            }
        }
        var report = AnalysisDiagnosticsBuilder.build(
            input, storedStatus: status, storedFailureReason: reason, kickingFoot: foot,
            appVersion: Self.appVersion, generatedAt: now
        )
        if let readProblem { report.contributingFactors.insert(readProblem, at: 0) }
        state = .loaded(report)
    }
}
