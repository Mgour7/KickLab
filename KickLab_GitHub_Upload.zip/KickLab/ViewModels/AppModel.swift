import Foundation
import Observation
import SwiftData

/// Remembers which athlete was selected between launches.
protocol AthleteSelectionStoring: AnyObject {
    var storedAthleteID: UUID? { get set }
}

/// Production store: `UserDefaults`.
final class UserDefaultsAthleteSelection: AthleteSelectionStoring {
    private let key = "selectedAthleteID"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    var storedAthleteID: UUID? {
        get { defaults.string(forKey: key).flatMap(UUID.init(uuidString:)) }
        set { defaults.set(newValue?.uuidString, forKey: key) }
    }
}

/// Test / preview store.
final class InMemoryAthleteSelection: AthleteSelectionStoring {
    var storedAthleteID: UUID?

    init(_ id: UUID? = nil) {
        storedAthleteID = id
    }
}

/// Whether developer diagnostics are shown (Profile → Developer).
protocol DeveloperSettingsStoring: AnyObject {
    var showsAnalysisDiagnostics: Bool { get set }
}

final class UserDefaultsDeveloperSettings: DeveloperSettingsStoring {
    private let key = "developer.showsAnalysisDiagnostics"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    var showsAnalysisDiagnostics: Bool {
        get { defaults.bool(forKey: key) }
        set { defaults.set(newValue, forKey: key) }
    }
}

final class InMemoryDeveloperSettings: DeveloperSettingsStoring {
    var showsAnalysisDiagnostics: Bool

    init(showsAnalysisDiagnostics: Bool = false) {
        self.showsAnalysisDiagnostics = showsAnalysisDiagnostics
    }
}

/// App-wide state: services, the athlete list and the selected athlete.
/// Screens read plain `AthleteSummary` values; `revision` changes whenever data changes so
/// every screen can reload.
@MainActor
@Observable
final class AppModel {
    let services: AppServices
    let insightsProvider: any PersonalInsightsProviding
    @ObservationIgnored private let selectionStore: any AthleteSelectionStoring
    @ObservationIgnored private let developerSettings: any DeveloperSettingsStoring

    /// Step 12A: shows the developer-only analysis diagnostics screens.
    var showsAnalysisDiagnostics: Bool {
        didSet { developerSettings.showsAnalysisDiagnostics = showsAnalysisDiagnostics }
    }

    private(set) var athletes: [AthleteSummary] = []
    private(set) var selectedAthleteID: UUID?
    private(set) var loadError: String?
    private(set) var hasLoaded = false
    /// Bumped after every change to stored data.
    private(set) var revision = 0

    init(
        services: AppServices,
        selectionStore: any AthleteSelectionStoring = UserDefaultsAthleteSelection(),
        insightsProvider: any PersonalInsightsProviding = RuleBasedPersonalInsights(),
        developerSettings: any DeveloperSettingsStoring = UserDefaultsDeveloperSettings()
    ) {
        self.services = services
        self.selectionStore = selectionStore
        self.insightsProvider = insightsProvider
        self.developerSettings = developerSettings
        showsAnalysisDiagnostics = developerSettings.showsAnalysisDiagnostics
    }

    var context: ModelContext { services.context }

    var selectedAthlete: AthleteSummary? {
        athletes.first { $0.id == selectedAthleteID }
    }

    /// Loads the athlete list and resolves the selection.
    func load() {
        do {
            athletes = try services.athletes.activeAthletes().map(AthleteSummary.init(athlete:))
            loadError = nil
        } catch {
            athletes = []
            loadError = UserFacingError.message(for: error)
        }
        let resolved = AthleteSelection.resolve(selected: selectedAthleteID ?? selectionStore.storedAthleteID, available: athletes)
        selectedAthleteID = resolved
        selectionStore.storedAthleteID = resolved
        hasLoaded = true
    }

    func select(_ athleteID: UUID) {
        guard athletes.contains(where: { $0.id == athleteID }) else { return }
        selectedAthleteID = athleteID
        selectionStore.storedAthleteID = athleteID
        revision += 1
    }

    /// Call after any change to stored data.
    func dataDidChange() {
        revision += 1
        load()
    }

    @ObservationIgnored private var analysisRuns: [UUID: AnalysisRunViewModel] = [:]
    /// Build 21: training-session processors (see `sessionProcessor(for:)`).
    @ObservationIgnored var sessionProcessors: [UUID: TrainingSessionProcessor] = [:]

    /// The analysis run for a kick, kept for the app's lifetime so a running analysis
    /// survives leaving its screen and only one run per kick can be started.
    func analysisRun(for kickID: UUID) -> AnalysisRunViewModel {
        if let existing = analysisRuns[kickID] { return existing }
        let run = AnalysisRunViewModel(kickID: kickID)
        analysisRuns[kickID] = run
        return run
    }

    /// The kick's videos or analyses changed: a finished run no longer describes them, so
    /// its screen goes back to a fresh automatic start (a running analysis is untouched).
    func invalidateAnalysisRun(for kickID: UUID) {
        analysisRuns[kickID]?.invalidate()
    }

    /// The kick was deleted: drop its run (unless one is still running).
    func forgetAnalysisRun(for kickID: UUID) {
        guard let run = analysisRuns[kickID], !run.state.isBusy else { return }
        analysisRuns[kickID] = nil
    }

    /// Stops every running analysis (called when KickLab goes to the background).
    func interruptRunningAnalyses() {
        for run in analysisRuns.values where run.state.isBusy {
            run.interruptForBackground()
        }
    }

    /// The stored athlete for an ID (for passing to services).
    func athleteModel(_ id: UUID) -> Athlete? {
        ModelLookup.athlete(id, in: context)
    }
}
