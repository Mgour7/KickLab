import Foundation
import Observation
import SwiftData

/// Step 12F: the progress dashboard for the selected athlete, built from saved kicks,
/// sessions and analyses only (`ProgressDashboard`).
@MainActor
@Observable
final class ProgressDashboardViewModel {
    var range: ProgressRange = .last30
    private(set) var state: LoadState<ProgressDashboard> = .loading

    func load(app: AppModel, now: Date = .now) {
        guard let summary = app.selectedAthlete, let athlete = app.athleteModel(summary.id) else {
            state = .failed("Add an athlete to get started.")
            return
        }
        let records = (athlete.kicks ?? []).map(KickStatRecord.init(kick:))
        let sessions = (athlete.kickingSessions ?? []).map { (id: $0.id, date: $0.date, name: $0.name) }
        let analyses = AthleteHistory.allAnalyses(for: athlete).compactMap { Self.trendRecord($0) }
        state = .loaded(ProgressDashboard.make(records: records, sessions: sessions, analyses: analyses, range: range, now: now))
    }

    /// Current, completed analyses only; the camera angle is the analyzed video's.
    static func trendRecord(_ a: BiomechanicsAnalysis) -> AnalysisTrendRecord? {
        guard a.isCurrent, a.processingStatus == .completed, let kick = a.kick else { return nil }
        let videos = a.inputVideos ?? []
        let angle = (videos.first(where: \.isPrimary) ?? videos.first)?.angleType ?? .unknown
        let assisted = AnalysisAssistanceLabel.isAssisted(a.analysisVersion)
        let version = assisted ? String(a.analysisVersion.dropLast(AnalysisAssistanceLabel.suffix.count)) : a.analysisVersion
        let plant = (a.metrics ?? []).first { $0.metricKey == KickMetricKey.plantToContactTime.rawValue }?.value
        return AnalysisTrendRecord(date: kick.timestamp, kickType: kick.kickType, cameraAngle: angle, engineVersion: version,
                                   isUserAssisted: assisted, overallScore: a.overallScore, plantToContact: plant)
    }
}
