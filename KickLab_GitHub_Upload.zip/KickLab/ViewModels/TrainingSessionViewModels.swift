import Foundation
import Observation
import SwiftData

// Build 21 — training sessions: creating them, processing their recordings (Stage A scan →
// Stage B analysis queue) and the actions of Session Review. The manifest is the source of
// truth for the session; Kick records are created through the existing `KickService` and
// analyzed by the existing `KickAnalysisRunner`.

extension AppModel {
    /// The processor for a session, kept for the app's lifetime (like analysis runs) so
    /// processing continues while the athlete moves between screens.
    func sessionProcessor(for sessionID: UUID) -> TrainingSessionProcessor {
        if let p = sessionProcessors[sessionID] { return p }
        let p = TrainingSessionProcessor(sessionID: sessionID)
        sessionProcessors[sessionID] = p
        return p
    }

    /// KickLab is leaving the foreground: iOS will suspend it, so processing stops cleanly
    /// (the current item goes back to the queue and resumes next time).
    func pauseSessionProcessingForBackground() {
        for p in sessionProcessors.values { p.stopForBackground(app: self) }
    }

    /// At launch: recordings interrupted by termination are kept as "recovered" and any
    /// analysis that was running goes back to the queue.
    func recoverTrainingSessions() {
        services.trainingSessions.recoverAfterLaunch()
    }
}

enum TrainingSessionLibrary {
    /// Creates the session: a `KickingSession` record (existing model) for its kicks, and
    /// the manifest file. Saved before any recording starts.
    @MainActor
    static func create(app: AppModel, name: String, location: String?, defaults: SessionKickDetails) throws -> TrainingSessionManifest {
        guard let summary = app.selectedAthlete, let athlete = app.athleteModel(summary.id) else {
            throw SessionMediaError.failed("Add an athlete first.")
        }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let title = trimmed.isEmpty ? "Training \(DisplayFormat.shortDate(.now))" : trimmed
        let kickingSession = try app.services.sessions.createSession(for: athlete, name: title, location: location)
        let m = TrainingSessionEditor.makeSession(athleteID: athlete.id, kickingSessionID: kickingSession.id, name: title,
                                                  location: location, defaults: defaults, now: .now)
        try app.services.trainingSessions.save(m)
        app.dataDidChange()
        return m
    }

    @MainActor
    static func sessions(app: AppModel) -> [TrainingSessionManifest] {
        guard let id = app.selectedAthleteID else { return [] }
        return app.services.trainingSessions.loadAll().filter { $0.athleteID == id }
    }
}

/// Processes one session: scans recordings that haven't been scanned, then analyzes the
/// queued kicks one at a time. Foreground only — stopped when KickLab leaves the
/// foreground and resumed (from the persisted queue) next time.
@MainActor
@Observable
final class TrainingSessionProcessor {
    enum Phase: Equatable, Sendable {
        case idle
        case scanning(sourceRole: String, fraction: Double)
        case analyzing(kickNumber: Int, of: Int)
        case paused
        case finished
        case failed(String)

        var text: String {
            switch self {
            case .idle: "Not started"
            case .scanning(let role, let f): "Finding kicks in the \(role.lowercased()) recording… \(Int((f * 100).rounded()))%"
            case .analyzing(let n, let total): "Analyzing kick \(n) of \(total)…"
            case .paused: "Paused"
            case .finished: "Processing queue: nothing waiting"
            case .failed(let s): s
            }
        }
    }

    let sessionID: UUID
    private(set) var phase: Phase = .idle
    /// Bumped after every manifest write, so screens reload.
    private(set) var revision = 0
    @ObservationIgnored private var task: Task<Void, Never>?
    @ObservationIgnored private var runID = UUID()

    init(sessionID: UUID) { self.sessionID = sessionID }

    var isRunning: Bool { task.map { !$0.isCancelled } ?? false }

    func start(app: AppModel) {
        // A run that was cancelled (background, pause) may still be finishing its current
        // step; the new run waits for it, so one candidate is never processed twice.
        if let task, !task.isCancelled { return }
        let previous = task
        let id = UUID()
        runID = id
        task = Task { [weak self] in
            await previous?.value
            await self?.run(app: app)
            if self?.runID == id { self?.task = nil }
        }
    }

    func pause(app: AppModel) {
        update(app) { $0.processing.paused = true }
        task?.cancel()
        phase = .paused
    }

    func resume(app: AppModel) {
        update(app) { $0.processing.paused = false }
        start(app: app)
    }

    func stopForBackground(app: AppModel) {
        guard task != nil else { return }
        task?.cancel()
        update(app) { SessionProcessingQueue.recoverAfterRelaunch(&$0) }
        phase = .idle
    }

    @discardableResult
    func update(_ app: AppModel, _ change: (inout TrainingSessionManifest) throws -> Void) rethrows -> TrainingSessionManifest? {
        let store = app.services.trainingSessions
        guard var m = try? store.load(sessionID) else { return nil }
        try change(&m)
        try? store.save(m)
        revision += 1
        return m
    }

    private func run(app: AppModel) async {
        let store = app.services.trainingSessions
        guard var m = try? store.load(sessionID) else { phase = .failed("The session couldn't be read."); return }
        if m.processing.paused { phase = .paused; return }
        var scannerUnavailable = false

        // Stage A: scan recordings not scanned yet.
        for source in m.sources where (m.processing.scan[source.id.uuidString] ?? .notStarted) != .done
            && (source.status == .finalized || source.status == .recovered) {
            if Task.isCancelled { return }
            guard app.services.sessionScanner.isAvailable else {
                scannerUnavailable = true
                break
            }
            update(app) { $0.processing.scan[source.id.uuidString] = .scanning }
            phase = .scanning(sourceRole: source.role.title, fraction: 0)
            let url = store.url(session: sessionID, relativePath: source.relativePath)
            let role = source.role.title
            do {
                let samples: [SessionScanSample]
                if let cached = store.loadScan(session: sessionID, source: source.id) {
                    samples = cached
                } else {
                    let scanner = app.services.sessionScanner
                    samples = try await Self.detached {
                        try await scanner.scan(videoURL: url, framesPerSecond: SessionScanSettings.framesPerSecond) { f in
                            Task { @MainActor [weak self] in self?.phase = .scanning(sourceRole: role, fraction: f) }
                        }
                    }
                    try? store.saveScan(samples, session: sessionID, source: source.id)
                }
                let marks = m.marks.filter { $0.sourceID == source.id }.map(\.sourceTime)
                let found = KickDiscovery.discover(samples, marks: marks)
                m = update(app) { TrainingSessionEditor.applyDiscovery(&$0, sourceID: source.id, found: found, now: .now) } ?? m
            } catch is CancellationError {
                update(app) { $0.processing.scan[source.id.uuidString] = .notStarted }
                return
            } catch where Task.isCancelled {
                // Stopped for the background/pause; a detector error on the way out isn't a failure.
                update(app) { $0.processing.scan[source.id.uuidString] = .notStarted }
                return
            } catch {
                update(app) {
                    $0.processing.scan[source.id.uuidString] = .failed
                    $0.processing.scanError[source.id.uuidString] = error.localizedDescription
                }
            }
        }

        // Pair automatically when a second, synchronized camera exists.
        // Camera A may have several recordings (segments); each is paired with every other
        // synchronized camera's recordings. Segments of one camera are never paired.
        if let primary = m.primaryCameraID {
            for a in m.segments(ofCamera: primary) {
                for other in m.sources where m.cameraID(of: other) != primary && other.sync.provenance != .none {
                    m = update(app) { _ = MultiCameraSync.pairAutomatically(&$0, primarySourceID: a.id, secondarySourceID: other.id, now: .now) } ?? m
                }
            }
        }

        // Stage B: analyze queued kicks, one at a time.
        m = update(app) { SessionProcessingQueue.enqueueReady(&$0) } ?? m
        while !Task.isCancelled, let current = try? store.load(sessionID), let next = SessionProcessingQueue.next(current) {
            let total = current.candidates.filter { $0.status.isActive && $0.analysis.status != .notQueued }.count
            let number = (current.attempts.firstIndex { $0.id == next.id } ?? current.candidates(of: next.sourceID).firstIndex { $0.id == next.id } ?? 0) + 1
            phase = .analyzing(kickNumber: number, of: max(total, number))
            update(app) { SessionProcessingQueue.markRunning(&$0, next.id) }
            do {
                try await process(next, manifest: current, app: app)
            } catch is CancellationError {
                update(app) { SessionProcessingQueue.recoverAfterRelaunch(&$0) }
                return
            } catch {
                update(app) { SessionProcessingQueue.recordFailure(&$0, next.id, error: error.localizedDescription, now: .now) }
            }
        }
        if !Task.isCancelled {
            phase = scannerUnavailable
                ? .failed("Automatic kick finding isn't available on this device. Add kicks by hand in Session Review.")
                : .finished
        }
        app.dataDidChange()
    }

    /// Runs `operation` off the main actor at utility priority, passing cancellation on
    /// (a plain detached task would keep decoding after Pause or going to the background).
    private static func detached<T: Sendable>(_ operation: @escaping @Sendable () async throws -> T) async throws -> T {
        let task = Task.detached(priority: .utility, operation: operation)
        return try await withTaskCancellationHandler {
            try await task.value
        } onCancel: {
            task.cancel()
        }
    }

    /// Cuts the candidate's interval out of its recording (no re-encoding) into the
    /// session folder; the caller imports it into KickLab's media and removes this copy.
    private func exportClip(_ c: SessionKickCandidate, source: SessionSource, manifest m: TrainingSessionManifest, app: AppModel) async throws -> ExportedClip {
        let store = app.services.trainingSessions
        let sourceURL = store.url(session: m.id, relativePath: source.relativePath)
        let temp = store.directory(m.id).appendingPathComponent("clip-\(c.id.uuidString).mov")
        let exporter = app.services.clipExporter
        let start = c.startTime, end = c.endTime
        return try await Self.detached {
            try await exporter.exportClip(from: sourceURL, start: start, end: end, to: temp)
        }
    }

    /// Stage B for one candidate: clip + Kick (once), then the existing analysis.
    private func process(_ c: SessionKickCandidate, manifest m: TrainingSessionManifest, app: AppModel) async throws {
        // A paired second-camera kick: its clip joins the primary's Kick (one attempt).
        if c.kickID == nil, case .some(let primaryKickID) = SessionProcessingQueue.primaryKickForSecondary(m, c),
           let pk = primaryKickID, let primaryKick = ModelLookup.kick(pk, in: app.context),
           let pair = m.pairs.first(where: { $0.secondaryCandidateID == c.id }), let primary = m.candidate(pair.primaryCandidateID),
           let source = m.source(c.sourceID), let primarySource = m.source(primary.sourceID), let primaryStart = primary.clipStartInSource {
            let clip = try await exportClip(c, source: source, manifest: m, app: app)
            defer { try? FileManager.default.removeItem(at: clip.url) }
            let video = try await app.services.videos.importVideo(from: clip.url, for: primaryKick, angle: source.role.angle, sourceType: .captured,
                                                                  makePrimary: false, recordedAt: primaryKick.timestamp)
            video.syncOffsetSeconds = SessionProcessingQueue.secondaryClipOffset(primaryClipStart: primaryStart, primarySync: primarySource.sync,
                                                                                 secondaryClipStart: clip.startInSource, secondarySync: source.sync)
            try? app.context.save()
            update(app) { SessionProcessingQueue.recordAttached(&$0, c.id, toKick: pk, clipStartInSource: clip.startInSource, now: .now) }
            app.dataDidChange()
            return
        }
        var kick: Kick? = c.kickID.flatMap { ModelLookup.kick($0, in: app.context) }
        if kick == nil {
            guard let source = m.source(c.sourceID), let athlete = app.athleteModel(m.athleteID) else {
                throw SessionMediaError.failed("The recording or athlete is missing.")
            }
            let clip = try await exportClip(c, source: source, manifest: m, app: app)
            defer { try? FileManager.default.removeItem(at: clip.url) }
            let session = m.kickingSessionID.flatMap { ModelLookup.session($0, in: app.context) }
            let draft = SessionKickDrafts.draft(details: c.details, timestamp: SessionKickDrafts.timestamp(
                recordingStart: source.recordedAt, sessionCreated: m.createdAt, contactInSource: c.contactTime))
            let created = try app.services.kicks.createKick(for: athlete, in: session, draft: draft)
            do {
                _ = try await app.services.videos.importVideo(from: clip.url, for: created, angle: source.role.angle, sourceType: .captured,
                                                              makePrimary: true, recordedAt: draft.timestamp)
            } catch {
                // No video → no Kick: a retry must not leave an empty Kick behind.
                try? app.services.kicks.deleteKick(created)
                throw error
            }
            update(app) { SessionProcessingQueue.recordMaterialized(&$0, c.id, kickID: created.id, clipStartInSource: clip.startInSource) }
            kick = created
        }
        guard let kick else { throw SessionMediaError.failed("The kick couldn't be created.") }
        try Task.checkCancellation()
        let outcome = try await app.services.analysisRunner.run(kick: kick, videos: kick.videos ?? [], options: VideoAnalysisOptions(),
                                                                progress: { _ in })
        var contactOutcome: ContactOutcome?
        var clipContact: Double?
        var uncertainty: Double?
        var completed = false
        var analysisID: UUID?
        switch outcome {
        case .completed(let analysis, _):
            completed = true
            analysisID = analysis.id
            if let dir = analysis.artifactsRelativePath {
                let artifacts = AnalysisArtifactStore(analysisRootURL: app.services.videos.analysisRootURL)
                if let phases = try? artifacts.readPhases(in: dir).phases.phases {
                    contactOutcome = ContactOutcome.of(phases)
                    clipContact = phases.estimatedContactTime
                    uncertainty = phases.evidence?.contactUncertaintySeconds
                }
            }
        case .failed(let analysis, _, _):
            analysisID = analysis.id
        case .cancelled:
            throw CancellationError()
        }
        update(app) {
            SessionProcessingQueue.recordAnalysis(&$0, c.id, analysisID: analysisID, completed: completed, contactOutcome: contactOutcome,
                                                  clipContact: clipContact, contactUncertainty: uncertainty, now: .now)
        }
        app.dataDidChange()
    }
}

/// Session Review actions that touch Kick records (results, details, removal).
@MainActor
enum SessionReviewActions {
    /// One-tap result. Field goals and PATs only; stored on the attempt's Kick.
    static func setResult(_ result: KickResult, kickID: UUID, app: AppModel) -> String? {
        guard let kick = ModelLookup.kick(kickID, in: app.context), let outcome = kick.outcome else { return "This kick no longer exists." }
        return save(kick, outcome: SessionKickDrafts.outcome(outcome, settingResult: result), app: app)
    }

    static func setDistance(_ yards: Double?, kickID: UUID, app: AppModel) -> String? {
        guard let kick = ModelLookup.kick(kickID, in: app.context), let outcome = kick.outcome else { return "This kick no longer exists." }
        return save(kick, outcome: SessionKickDrafts.outcome(outcome, settingDistance: yards), app: app)
    }

    static func setHash(_ hash: HashLocation, kickID: UUID, app: AppModel) -> String? {
        guard let kick = ModelLookup.kick(kickID, in: app.context), let outcome = kick.outcome else { return "This kick no longer exists." }
        return save(kick, outcome: outcome, hash: hash, app: app)
    }

    private static func save(_ kick: Kick, outcome: KickOutcome, hash: HashLocation? = nil, app: AppModel) -> String? {
        let draft = KickDraft(id: kick.id, timestamp: kick.timestamp, outcome: outcome, context: kick.context, playingLevelAtKick: nil,
                              spotDistanceToTargetGoalLine: kick.spotDistanceToTargetGoalLine, hashLocation: hash ?? kick.hashLocation,
                              isReferenceKick: kick.isReferenceKick, notes: kick.notes,
                              details: KickEnteredDetails(ballType: kick.ballType, setup: kick.kickSetup, conditions: kick.conditionsNote,
                                                          direction: kick.kickDirection, puntInsideTwenty: kick.puntInsideTwenty,
                                                          puntResult: kick.puntResult))
        do {
            try app.services.kicks.updateKick(kick, with: draft)
            app.dataDidChange()
            return nil
        } catch {
            return UserFacingError.message(for: error)
        }
    }

    /// "Not a kick": the candidate is marked (the recording is untouched) and the Kick that
    /// was created for it, with its clip and analysis, is deleted. Callers confirm first.
    static func reject(candidateID: UUID, practiceSwing: Bool, processor: TrainingSessionProcessor, app: AppModel) -> String? {
        var kickID: UUID?
        do {
            try processor.update(app) { m in
                kickID = m.candidate(candidateID)?.kickID
                try TrainingSessionEditor.reject(&m, candidateID: candidateID, practiceSwing: practiceSwing, now: .now)
                if let i = m.candidates.firstIndex(where: { $0.id == candidateID }) { m.candidates[i].kickID = nil }
            }
        } catch {
            return "Couldn't update the session."
        }
        // A Kick shared with another candidate (a camera pair) is kept.
        let shared = kickID.map { id in (try? app.services.trainingSessions.load(processor.sessionID))?.candidates
            .contains { $0.id != candidateID && $0.kickID == id && $0.status.isActive } ?? false } ?? false
        if !shared, let id = kickID, let kick = ModelLookup.kick(id, in: app.context) {
            do { try app.services.kicks.deleteKick(kick) } catch { return UserFacingError.message(for: error) }
            app.forgetAnalysisRun(for: id)
        }
        app.dataDidChange()
        return nil
    }

    /// Results of the session's attempts (by candidate) for the review summary.
    static func results(_ m: TrainingSessionManifest, app: AppModel) -> [UUID: KickStatRecord] {
        var out: [UUID: KickStatRecord] = [:]
        for c in m.candidates {
            if let id = c.kickID, let kick = ModelLookup.kick(id, in: app.context) { out[c.id] = KickStatRecord(kick: kick) }
        }
        return out
    }

    /// The attempts' current analyses, in kick order, for session trends.
    static func rankingEntries(_ m: TrainingSessionManifest, app: AppModel) -> [RankingEntry] {
        m.attempts.compactMap { c in
            c.kickID.flatMap { ModelLookup.kick($0, in: app.context) }
                .flatMap { k in (k.analyses ?? []).first { $0.isCurrent && $0.processingStatus == .completed } }
                .map(RankingEntry.init(analysis:))
        }
    }
}

/// Build 21 — bringing a recording into a session (a whole-practice video recorded with
/// another app, or camera B's recording). The file is COPIED into the session folder; the
/// original (Files, Photos) is never modified.
@MainActor
enum TrainingSessionImport {
    static func importSource(app: AppModel, sessionID: UUID, from url: URL, role: SessionCameraRole) async throws -> SessionSource {
        let store = app.services.trainingSessions
        var m = try store.load(sessionID)
        let ext = ManagedPath.videoFileExtension(for: url) ?? "mov"
        let id = UUID()
        let source = TrainingSessionEditor.addSource(&m, id: id, role: role, origin: .imported, fileExtension: ext, status: .recording,
                                                     now: .now, originalFilename: url.lastPathComponent)
        try store.prepare(sessionID)
        let destination = store.url(session: sessionID, relativePath: source.relativePath)
        // Files picked from outside KickLab are security-scoped on iOS.
        #if !os(Linux)
        let accessing = url.startAccessingSecurityScopedResource()
        defer { if accessing { url.stopAccessingSecurityScopedResource() } }
        #endif
        // Saved as "recording" first: an import interrupted by termination is found at launch.
        try store.save(m)
        try await Task.detached(priority: .utility) {
            try FileManager.default.copyItem(at: url, to: destination)
        }.value
        let metadata = await app.services.mediaStore.metadataReader.readMetadata(at: destination)
        let bytes = (try? FileManager.default.attributesOfItem(atPath: destination.path)[.size] as? NSNumber)?.int64Value
        m = try store.load(sessionID)
        TrainingSessionEditor.finalizeSource(&m, id: id, duration: metadata?.durationSeconds, frameRate: metadata?.frameRate, bytes: bytes, now: .now)
        if let i = m.sources.firstIndex(where: { $0.id == id }) {
            m.sources[i].recordedAt = (try? FileManager.default.attributesOfItem(atPath: destination.path)[.creationDate] as? Date) ?? nil
        }
        try store.save(m)
        app.dataDidChange()
        return m.source(id) ?? source
    }
}

