import Foundation
import SwiftData

/// Finds stored records by ID. Screens hold IDs and plain presentation values, never
/// long-lived references to SwiftData models.
@MainActor
enum ModelLookup {
    static func athlete(_ id: UUID, in context: ModelContext) -> Athlete? {
        let target = id
        return try? context.fetch(FetchDescriptor<Athlete>(predicate: #Predicate { $0.id == target })).first
    }

    static func kick(_ id: UUID, in context: ModelContext) -> Kick? {
        let target = id
        return try? context.fetch(FetchDescriptor<Kick>(predicate: #Predicate { $0.id == target })).first
    }

    static func session(_ id: UUID, in context: ModelContext) -> KickingSession? {
        let target = id
        return try? context.fetch(FetchDescriptor<KickingSession>(predicate: #Predicate { $0.id == target })).first
    }

    static func analysis(_ id: UUID, in context: ModelContext) -> BiomechanicsAnalysis? {
        let target = id
        return try? context.fetch(FetchDescriptor<BiomechanicsAnalysis>(predicate: #Predicate { $0.id == target })).first
    }

    static func video(_ id: UUID, in context: ModelContext) -> VideoAsset? {
        let target = id
        return try? context.fetch(FetchDescriptor<VideoAsset>(predicate: #Predicate { $0.id == target })).first
    }
}

// MARK: - Model → presentation values

extension AthleteSummary {
    init(athlete: Athlete) {
        self.init(
            id: athlete.id,
            name: athlete.fullName.isEmpty ? "Unnamed kicker" : athlete.fullName,
            kickingFoot: athlete.kickingFoot,
            playingLevel: athlete.currentPlayingLevel,
            kickCount: (athlete.kicks ?? []).count,
            nickname: athlete.nickname,
            role: athlete.primaryRole,
            hasPhoto: athlete.photoData != nil
        )
    }
}

extension AnalysisRecord {
    init(analysis: BiomechanicsAnalysis) {
        let kick = analysis.kick
        self.init(
            id: analysis.id,
            kickID: kick?.id,
            kickType: kick?.kickType ?? .unknown,
            kickDate: kick?.timestamp,
            createdAt: analysis.createdAt,
            completedAt: analysis.completedAt,
            status: analysis.processingStatus,
            isCurrent: analysis.isCurrent,
            overallScore: analysis.overallScore,
            confidence: analysis.confidence,
            failureReason: analysis.failureReason,
            engineVersion: analysis.analysisVersion,
            metrics: (analysis.metrics ?? []).map { metric in
                StoredMetricRecord(
                    key: metric.metricKey, value: metric.value, unit: metric.unit, confidence: metric.confidence,
                    status: metric.measurementStatus, phase: metric.phase, definitionVersion: metric.metricDefinitionVersion
                )
            },
            categories: (analysis.categoryScores ?? []).map { score in
                StoredCategoryRecord(category: score.category, score: score.score, confidence: score.confidence,
                                     status: score.measurementStatus, summary: score.summary)
            },
            observations: (analysis.observations ?? []).map { o in
                StoredObservationRecord(
                    id: o.id, kind: o.kind, category: o.category, message: o.message, severity: o.severity,
                    confidence: o.confidence, priority: o.priority, ruleKey: o.ruleKey,
                    relatedObservationID: o.relatedObservationID, evidenceMetricKeys: o.evidenceMetricKeys
                )
            }
        )
    }
}

extension RankingEntry {
    /// Build 16: a saved analysis as the personal ranking sees it (read-only).
    init(analysis: BiomechanicsAnalysis) {
        let kick = analysis.kick
        let videos = analysis.inputVideos ?? []
        let video = videos.first(where: \.isPrimary) ?? videos.first ?? (kick?.videos ?? []).first(where: \.isPrimary)
        let completed = analysis.processingStatus == .completed
        var scores: [AnalysisCategory: Double] = [:]
        for c in analysis.categoryScores ?? [] where c.measurementStatus != .unavailable {
            if let s = c.score, s.isFinite { scores[c.category] = s }
        }
        self.init(id: analysis.id, kickID: kick?.id, date: kick?.timestamp ?? analysis.createdAt, kickType: kick?.kickType ?? .unknown,
                  view: ComparableView(angle: video?.angleType), engineVersion: analysis.analysisVersion, completed: completed,
                  overallScore: completed ? analysis.overallScore.flatMap { $0.isFinite ? $0 : nil } : nil,
                  categoryScores: completed ? scores : [:])
    }

    /// Every other kick's CURRENT analysis for this athlete (one per kick).
    @MainActor
    static func others(for analysis: BiomechanicsAnalysis) -> [RankingEntry] {
        guard let athlete = analysis.kick?.athlete else { return [] }
        return (athlete.kicks ?? []).filter { $0.id != analysis.kick?.id }.compactMap { kick in
            (kick.analyses ?? []).first(where: \.isCurrent).map(RankingEntry.init(analysis:))
        }
    }
}

extension KickHistoryEntry {
    /// The kick's current completed analysis as a history entry, or nil.
    init?(kick: Kick) {
        guard let analysis = (kick.analyses ?? []).first(where: { $0.isCurrent && $0.processingStatus == .completed }),
              let snapshot = MetricSnapshot(analysis: analysis) else { return nil }
        self.init(
            kickID: kick.id,
            analysisID: analysis.id,
            date: kick.timestamp,
            kickType: kick.kickType,
            result: kick.fieldGoalOutcome?.result,
            touchback: kick.kickoffOutcome?.touchback,
            overallScore: analysis.overallScore,
            overallConfidence: analysis.confidence,
            snapshot: snapshot
        )
    }
}

extension KickRowPresentation {
    init(kick: Kick) {
        let current = (kick.analyses ?? []).first { $0.isCurrent && $0.processingStatus == .completed }
        self.init(
            id: kick.id,
            date: kick.timestamp,
            kickType: kick.kickType,
            title: kick.kickType.displayName,
            detail: KickPresentation.detail(outcome: kick.outcome, context: kick.context, hash: kick.hashLocation),
            videoCount: (kick.videos ?? []).count,
            hasCurrentAnalysis: current != nil,
            scoreText: current.map { DisplayFormat.score($0.overallScore) }
        )
    }
}

extension SessionRowPresentation {
    init(session: KickingSession) {
        self.init(id: session.id, name: session.name, date: session.date,
                  typeText: session.sessionType.displayName, kickCount: (session.kicks ?? []).count)
    }
}

extension VideoRowPresentation {
    init(video: VideoAsset) {
        self = .make(id: video.id, angle: video.angleType, isPrimary: video.isPrimary, status: video.storageStatus,
                     durationSeconds: video.durationSeconds, frameRate: video.frameRate)
    }
}

@MainActor
enum AthleteHistory {
    /// Every analyzed kick of the athlete (current, completed analyses only).
    static func entries(for athlete: Athlete) -> [KickHistoryEntry] {
        (athlete.kicks ?? []).compactMap { KickHistoryEntry(kick: $0) }.sorted { $0.date < $1.date }
    }

    /// The athlete's most recent completed, current analysis.
    static func latestAnalysis(for athlete: Athlete) -> BiomechanicsAnalysis? {
        (athlete.kicks ?? [])
            .compactMap { kick in (kick.analyses ?? []).first { $0.isCurrent && $0.processingStatus == .completed } }
            .max { ($0.completedAt ?? $0.createdAt) < ($1.completedAt ?? $1.createdAt) }
    }

    /// Every analysis of every kick, newest first.
    static func allAnalyses(for athlete: Athlete) -> [BiomechanicsAnalysis] {
        (athlete.kicks ?? []).flatMap { $0.analyses ?? [] }
            .sorted { ($0.completedAt ?? $0.createdAt) > ($1.completedAt ?? $1.createdAt) }
    }
}
