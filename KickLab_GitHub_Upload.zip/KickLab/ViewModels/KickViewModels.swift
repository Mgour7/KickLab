import Foundation
import Observation
import SwiftData

/// Sessions and kicks of the selected athlete.
@MainActor
@Observable
final class KicksViewModel {
    struct Content: Equatable, Sendable {
        var sessions: [SessionRowPresentation]
        var unassignedKicks: [KickRowPresentation]
        var recentKicks: [KickRowPresentation]

        var isEmpty: Bool { sessions.isEmpty && recentKicks.isEmpty }
    }

    private(set) var state: LoadState<Content> = .loading

    func load(app: AppModel) {
        guard let id = app.selectedAthleteID, let athlete = app.athleteModel(id) else {
            state = .failed("Add an athlete to get started.")
            return
        }
        let sessions = (athlete.kickingSessions ?? []).sorted { $0.date > $1.date }.map(SessionRowPresentation.init(session:))
        let kicks = (athlete.kicks ?? []).sorted { $0.timestamp > $1.timestamp }
        state = .loaded(Content(
            sessions: sessions,
            unassignedKicks: kicks.filter { $0.session == nil }.map(KickRowPresentation.init(kick:)),
            recentKicks: kicks.prefix(20).map(KickRowPresentation.init(kick:))
        ))
    }
}

/// One session and its kicks; create, edit and delete sessions.
@MainActor
@Observable
final class SessionViewModel {
    struct Content: Equatable, Sendable {
        var session: SessionRowPresentation
        var location: String?
        var notes: String?
        var kicks: [KickRowPresentation]
    }

    let sessionID: UUID
    private(set) var state: LoadState<Content> = .loading
    var errorMessage: String?

    init(sessionID: UUID) {
        self.sessionID = sessionID
    }

    func load(app: AppModel) {
        guard let session = ModelLookup.session(sessionID, in: app.context) else {
            state = .failed("This session no longer exists.")
            return
        }
        state = .loaded(Content(
            session: SessionRowPresentation(session: session),
            location: session.location,
            notes: session.notes,
            kicks: (session.kicks ?? []).sorted { $0.timestamp > $1.timestamp }.map(KickRowPresentation.init(kick:))
        ))
    }

    func deletionMessage(app: AppModel) -> String {
        guard let session = ModelLookup.session(sessionID, in: app.context) else { return "" }
        return app.services.sessions.deletionSummary(for: session).confirmationMessage
    }

    /// Deletes the session; its kicks are kept as unassigned.
    func delete(app: AppModel) -> Bool {
        guard let session = ModelLookup.session(sessionID, in: app.context) else { return false }
        do {
            try app.services.sessions.deleteSession(session)
            app.dataDidChange()
            return true
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return false
        }
    }
}

/// Creating or editing a session.
@MainActor
@Observable
final class SessionEditorViewModel {
    var name: String
    var date: Date
    var sessionType: KickingSessionType
    var location: String
    var errorMessage: String?
    let sessionID: UUID?

    init(sessionID: UUID? = nil, app: AppModel? = nil, now: Date = .now) {
        self.sessionID = sessionID
        if let sessionID, let app, let session = ModelLookup.session(sessionID, in: app.context) {
            name = session.name
            date = session.date
            sessionType = session.sessionType
            location = session.location ?? ""
        } else {
            name = "Practice"
            date = now
            sessionType = .training
            location = ""
        }
    }

    var canSave: Bool { !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    /// Saves and returns the session ID.
    func save(app: AppModel) -> UUID? {
        do {
            if let sessionID, let session = ModelLookup.session(sessionID, in: app.context) {
                let edit = KickingSessionEdit(name: name, date: date, sessionType: sessionType,
                                              location: location, notes: session.notes)
                try app.services.sessions.updateSession(session, with: edit)
                app.dataDidChange()
                return sessionID
            }
            guard let athleteID = app.selectedAthleteID, let athlete = app.athleteModel(athleteID) else {
                errorMessage = "Choose an athlete first."
                return nil
            }
            let session = try app.services.sessions.createSession(
                for: athlete, name: name, date: date, sessionType: sessionType, location: location
            )
            app.dataDidChange()
            return session.id
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return nil
        }
    }
}

/// Fast manual kick entry (new kicks and edits).
@MainActor
@Observable
final class KickEntryViewModel {
    var form: KickEntryForm
    private(set) var issues: [KickEntryIssue] = []
    var errorMessage: String?
    /// Kicks saved in this entry sheet (for "Save & add another").
    private(set) var savedCount = 0
    let sessionID: UUID?
    let editingKickID: UUID?

    init(sessionID: UUID? = nil, kickType: KickType = .fieldGoal, now: Date = .now) {
        self.sessionID = sessionID
        editingKickID = nil
        form = KickEntryForm(kickType: kickType, timestamp: now)
    }

    /// Editing an existing kick.
    init(editing kickID: UUID, app: AppModel) {
        editingKickID = kickID
        sessionID = nil
        if let kick = ModelLookup.kick(kickID, in: app.context), let outcome = kick.outcome {
            form = .editing(outcome: outcome, context: kick.context, hash: kick.hashLocation,
                            notes: kick.notes, timestamp: kick.timestamp)
        } else {
            form = KickEntryForm()
        }
    }

    var isEditing: Bool { editingKickID != nil }

    /// Validates without saving (for inline feedback).
    func validate() {
        issues = form.makeDraft().issues
    }

    /// Saves the kick. With `addAnother`, keeps the form ready for the next rep.
    /// Returns the kick ID on success.
    @discardableResult
    func save(app: AppModel, addAnother: Bool = false, now: Date = .now) -> UUID? {
        let built = form.makeDraft()
        issues = built.issues
        guard let draft = built.draft else { return nil }
        do {
            if let editingKickID {
                guard let kick = ModelLookup.kick(editingKickID, in: app.context) else {
                    errorMessage = "This kick no longer exists."
                    return nil
                }
                try app.services.kicks.updateKick(kick, with: draft)
                app.dataDidChange()
                return kick.id
            }
            guard let athleteID = app.selectedAthleteID, let athlete = app.athleteModel(athleteID) else {
                errorMessage = "Choose an athlete first."
                return nil
            }
            let session = sessionID.flatMap { ModelLookup.session($0, in: app.context) }
            let kick = try app.services.kicks.createKick(for: athlete, in: session, draft: draft)
            savedCount += 1
            if addAnother { form.prepareNextKick(at: now) }
            app.dataDidChange()
            return kick.id
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return nil
        }
    }
}

/// One kick: outcome, videos and analyses.
@MainActor
@Observable
final class KickDetailViewModel {
    struct Content: Equatable, Sendable {
        var kick: KickRowPresentation
        var notes: String?
        var sessionName: String?
        var videos: [VideoRowPresentation]
        var analyses: [AnalysisRecord]
        var currentAnalysisID: UUID?
    }

    let kickID: UUID
    private(set) var state: LoadState<Content> = .loading
    private(set) var isImporting = false
    /// Free space on the volume holding KickLab's files (replaceable in tests).
    @ObservationIgnored var availableBytes: (URL) -> Int64? = DeviceStorage.availableBytes(at:)
    var errorMessage: String?

    init(kickID: UUID) {
        self.kickID = kickID
    }

    func load(app: AppModel) {
        guard let kick = ModelLookup.kick(kickID, in: app.context) else {
            state = .failed("This kick no longer exists.")
            return
        }
        // Keep local / missing status accurate before showing it.
        try? app.services.videos.refreshStorageStatuses(for: kick)
        let videos = (kick.videos ?? []).sorted { a, b in
            if a.isPrimary != b.isPrimary { return a.isPrimary }
            return a.sortOrder < b.sortOrder
        }
        let analyses = (kick.analyses ?? []).map(AnalysisRecord.init(analysis:)).sorted { $0.date > $1.date }
        state = .loaded(Content(
            kick: KickRowPresentation(kick: kick),
            notes: kick.notes,
            sessionName: kick.session?.name,
            videos: videos.map(VideoRowPresentation.init(video:)),
            analyses: analyses,
            currentAnalysisID: analyses.first { $0.isCurrent && $0.status == .completed }?.id
        ))
    }

    func thumbnailURL(videoID: UUID, app: AppModel) -> URL? {
        ModelLookup.video(videoID, in: app.context).flatMap { app.services.videos.thumbnailURL(for: $0) }
    }

    func fileURL(videoID: UUID, app: AppModel) -> URL? {
        ModelLookup.video(videoID, in: app.context).flatMap { app.services.videos.fileURL(for: $0) }
    }

    /// Copies a picked video into KickLab's storage (through `VideoStorageService`).
    /// The source file (and any Photos original) is never modified or deleted.
    ///
    /// With `removeSourceAfterImport`, the temporary copy a picker handed over is removed
    /// afterwards (only ever used for KickLab's own temporary files).
    func importVideo(from url: URL, source: VideoSourceType, angle: VideoAngleType, makePrimary: Bool,
                     app: AppModel, photosIdentifier: String? = nil, removeSourceAfterImport: Bool = false) async {
        defer {
            if removeSourceAfterImport { try? FileManager.default.removeItem(at: url) }
        }
        guard let kick = ModelLookup.kick(kickID, in: app.context) else {
            errorMessage = "This kick no longer exists."
            return
        }
        // Real-device protection: don't start a copy that can't fit.
        let size = DeviceStorage.fileSize(at: url)
        guard StorageSpacePolicy.hasRoom(forFileOfSize: size, availableBytes: availableBytes(app.services.videos.analysisRootURL)) else {
            errorMessage = StorageSpacePolicy.notEnoughSpaceMessage(fileSize: size)
            return
        }
        isImporting = true
        defer { isImporting = false }
        do {
            _ = try await app.services.videos.importVideo(
                from: url, for: kick, angle: angle, sourceType: source,
                makePrimary: makePrimary, photosLocalIdentifier: photosIdentifier
            )
            app.invalidateAnalysisRun(for: kickID)
            app.dataDidChange()
            load(app: app)
        } catch {
            errorMessage = UserFacingError.message(for: error)
        }
    }

    func setPrimary(videoID: UUID, app: AppModel) {
        guard let video = ModelLookup.video(videoID, in: app.context) else { return }
        do {
            try app.services.videos.setPrimary(video)
            app.invalidateAnalysisRun(for: kickID)
            app.dataDidChange()
            load(app: app)
        } catch {
            errorMessage = UserFacingError.message(for: error)
        }
    }

    /// Removes the video record and KickLab's copy of the file. Photos originals are untouched.
    func removeVideo(videoID: UUID, app: AppModel) {
        guard let video = ModelLookup.video(videoID, in: app.context) else { return }
        do {
            try app.services.videos.removeVideo(video)
            app.invalidateAnalysisRun(for: kickID)
            app.dataDidChange()
            load(app: app)
        } catch {
            errorMessage = UserFacingError.message(for: error)
        }
    }

    /// Deletes the kick, its videos' managed files and its analyses.
    func deleteKick(app: AppModel) -> Bool {
        guard let kick = ModelLookup.kick(kickID, in: app.context) else { return false }
        do {
            try app.services.kicks.deleteKick(kick)
            app.forgetAnalysisRun(for: kickID)
            app.dataDidChange()
            return true
        } catch {
            errorMessage = UserFacingError.message(for: error)
            return false
        }
    }
}

extension KickEntryViewModel: Identifiable {
    nonisolated var id: ObjectIdentifier { ObjectIdentifier(self) }
}

/// Reads file sizes and free space. Free space is only known on Apple platforms.
enum DeviceStorage {
    static func fileSize(at url: URL) -> Int64? {
        (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize.map(Int64.init)
    }

    static func availableBytes(at url: URL) -> Int64? {
        #if os(iOS)
        let values = try? URL(fileURLWithPath: NSHomeDirectory()).resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return values?.volumeAvailableCapacityForImportantUsage
        #else
        return nil
        #endif
    }
}
