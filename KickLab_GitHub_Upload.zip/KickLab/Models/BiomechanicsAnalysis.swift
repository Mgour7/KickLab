import Foundation
import SwiftData

extension KickLabSchemaV1 {
    /// One run of the biomechanics engine over a kick's video(s).
    ///
    /// A kick keeps its full analysis history: re-running with a newer engine creates
    /// a new record and never edits an old one. Exactly one completed analysis per kick
    /// is normally `isCurrent`; `AnalysisService` (step 5) flips it in a single save.
    ///
    /// Bulk output (pose time-series, intermediate CV data, overlays) is stored as files
    /// referenced by `artifactsRelativePath`, never in SwiftData.
    @Model
    final class BiomechanicsAnalysis {
        #Index<BiomechanicsAnalysis>([\.isCurrent])

        var id: UUID = UUID()
        /// Engine version that produced this analysis, e.g. "2.1.0".
        var analysisVersion: String = ""
        /// Shape of the stored results, for readers of older records.
        var resultsFormatVersion: Int = 1
        var createdAt: Date = Date.now
        var completedAt: Date?
        /// Raw value of `ProcessingStatus`.
        var storedProcessingStatus: String = "queued"
        /// Overall confidence, 0...1.
        var confidence: Double?
        var overallScore: Double?
        var isCurrent: Bool = false
        var failureReason: String?
        /// Relative path of the file-backed artifacts for this analysis.
        var artifactsRelativePath: String?

        /// Inverse is declared on `Kick.analyses`.
        var kick: Kick?

        /// Videos used as input. Every one must belong to `kick`
        /// (enforced by `attachInputVideo(_:)` and `AnalysisIntegrityValidator`).
        @Relationship(deleteRule: .nullify, inverse: \VideoAsset.analyses)
        var inputVideos: [VideoAsset]? = []

        @Relationship(deleteRule: .cascade, inverse: \BiomechanicalMetric.analysis)
        var metrics: [BiomechanicalMetric]? = []

        @Relationship(deleteRule: .cascade, inverse: \CategoryScore.analysis)
        var categoryScores: [CategoryScore]? = []

        @Relationship(deleteRule: .cascade, inverse: \CoachingObservation.analysis)
        var observations: [CoachingObservation]? = []

        init(
            id: UUID = UUID(),
            analysisVersion: String = "",
            processingStatus: ProcessingStatus = .queued,
            createdAt: Date = .now
        ) {
            self.id = id
            self.analysisVersion = analysisVersion
            self.storedProcessingStatus = processingStatus.storedValue
            self.createdAt = createdAt
        }
    }
}

extension BiomechanicsAnalysis {
    var processingStatus: ProcessingStatus {
        get { ProcessingStatus(storedValue: storedProcessingStatus) }
        set { storedProcessingStatus = newValue.storedValue }
    }

    /// Adds an input video after checking it belongs to the same kick as this analysis.
    ///
    /// - Throws: `AnalysisIntegrityError` if the analysis has no kick, the video is
    ///   orphaned, or the video belongs to a different kick. Nothing changes when it throws.
    func attachInputVideo(_ video: VideoAsset) throws {
        let issues = AnalysisIntegrityValidator.issues(attaching: video, to: self)
        guard issues.isEmpty else { throw AnalysisIntegrityError(issues: issues) }
        if inputVideos?.contains(where: { $0.id == video.id }) == true { return }
        if inputVideos == nil { inputVideos = [] }
        inputVideos?.append(video)
    }
}
