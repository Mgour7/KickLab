import Foundation
import SwiftData

extension KickLabSchemaV1 {
    /// One kick: a field goal, PAT, kickoff or punt.
    ///
    /// ## Storage design
    /// Outcome fields are stored flat on this table (fast, indexable, single-table
    /// queries at 20k+ kicks). Nobody reads or writes them directly: the typed API in
    /// `Kick+Outcome.swift` (`outcome`, `fieldGoalOutcome`, `kickoffOutcome`,
    /// `puntOutcome`, `applyOutcome(_:)`) is the boundary, and it validates every
    /// write with `KickValidator`.
    ///
    /// ## Field-position convention
    /// Field positions are stored as an analytical 0–100 coordinate: **yards from the
    /// goal line the kick travels toward**. This is not the number painted on the field.
    /// Negative values (landing only) are inside that end zone.
    /// - Opponent 30 → `spotDistanceToTargetGoalLine == 30`; midfield → 50;
    ///   own 40 → 60; own 20 → 80.
    /// - A kickoff teed at the kicking team's own 35 → 65.
    /// - A kickoff caught 3 yards deep in the end zone → `landingYardLine == -3`.
    /// The UI never shows the raw coordinate; `FieldGeometry.footballNotation(...)`
    /// converts it to "Opp 30", "50", "Own 40".
    ///
    /// ## Distance semantics
    /// - Field goal / PAT: `distanceYards` is the actual kick distance from the hold
    ///   to the goal plane. A hold at Opp 30 is roughly a 40-yard field goal.
    ///   `spotDistanceToTargetGoalLine` is separate field-location information and is
    ///   never used to overwrite `distanceYards`; `FieldGeometry` offers an estimate
    ///   helper only. Display example: "Hold: Opp 30 · Distance: 40 yd".
    /// - Kickoff: `distanceYards` is the actual ball travel distance when known.
    ///   `landingYardLine` is where the ball landed or was first possessed.
    /// - Punt: `distanceYards` is the punt distance when known.
    ///
    /// ## Accuracy coordinates (FG/PAT)
    /// Normalized, never pixels, so they survive any screen or video resolution.
    /// Left/right are from the kicker's perspective, facing the goal.
    /// - `accuracyX`: -1 = left upright, 0 = center, +1 = right upright.
    ///   Values beyond ±1 are outside the uprights.
    /// - `accuracyY`: same unit as x (one unit = half the inside width between the
    ///   uprights), so the target keeps its true aspect ratio. 0 = crossbar height,
    ///   positive = above, negative = below. `nil` whenever vertical position is not
    ///   reliably known; it is never guessed.
    ///
    /// ## Provenance
    /// Each measured value group (distance, accuracy, landing, hang time) has a source
    /// (`OutcomeMeasurementSource` raw value) and an optional 0...1 confidence.
    /// Manual entries have no confidence.
    @Model
    final class Kick {
        #Index<Kick>(
            [\.timestamp],
            [\.athleteID, \.storedKickType, \.distanceYards],
            [\.athleteID, \.storedKickType, \.timestamp]
        )

        // MARK: Identity

        var id: UUID = UUID()
        var timestamp: Date = Date.now
        var createdAt: Date = Date.now
        var updatedAt: Date = Date.now

        /// Inverse is declared on `Athlete.kicks`. Set only via `assignAthlete(_:)`.
        var athlete: Athlete?

        /// Denormalized stable copy of `athlete.id` for indexed queries, sync re-linking
        /// and import/export.
        ///
        /// Invariant: whenever `athlete` is non-nil, `athleteID == athlete.id`. Written only
        /// by `assignAthlete(_:)`; never independently editable or shown in an editor.
        /// If an athlete row is ever deleted directly (bypassing `AthleteService`), the
        /// `.nullify` rule clears `athlete` but deliberately leaves `athleteID`, so the kick
        /// can be identified and re-linked rather than silently losing its owner.
        var athleteID: UUID?

        /// Optional. Inverse is declared on `KickingSession.kicks`.
        var session: KickingSession?

        // MARK: Kick information

        /// Raw value of `KickType`. Changed only through `applyOutcome(_:)`.
        var storedKickType: String = "fieldGoal"
        /// Raw value of `KickContext`.
        var storedContext: String = "training"
        /// Raw value of `PlayingLevel`, snapshotted from the athlete when the kick is created.
        var storedPlayingLevelAtKick: String?
        /// Spot of the hold (FG/PAT), tee (kickoff) or snap (punt) as a 0–100 coordinate:
        /// yards from the goal line the kick travels toward (Opp 30 = 30, own 40 = 60).
        /// Field-location information only; never overwrites `distanceYards`.
        var spotDistanceToTargetGoalLine: Int?
        /// Raw value of `HashLocation`.
        var storedHashLocation: String = "notApplicable"
        /// The athlete's "model" kicks used for comparison.
        var isReferenceKick: Bool = false
        var notes: String?

        // MARK: Outcome — FG/PAT

        /// Raw value of `KickResult`. Required for FG/PAT; must be nil otherwise.
        var storedResult: String?
        var accuracyX: Double?
        var accuracyY: Double?
        var storedAccuracySource: String?
        var accuracyConfidence: Double?

        // MARK: Outcome — all kick types

        /// Yards. Double so video measurements like 65.2 are preserved.
        var distanceYards: Double?
        var storedDistanceSource: String?
        var distanceConfidence: Double?

        // MARK: Outcome — kickoff

        var landingYardLine: Double?
        /// Raw value of `LandingZone`.
        var storedLandingZone: String?
        /// Source covering both `landingYardLine` and `storedLandingZone`.
        var storedLandingSource: String?
        var landingConfidence: Double?
        /// Optional so a field goal never carries a meaningless `false`.
        var touchback: Bool?
        var outOfBounds: Bool?

        // MARK: Outcome — kickoff and punt

        var hangTimeSeconds: Double?
        var storedHangTimeSource: String?
        var hangTimeConfidence: Double?

        // MARK: Children

        @Relationship(deleteRule: .cascade, inverse: \VideoAsset.kick)
        var videos: [VideoAsset]? = []

        /// Full analysis history. Exactly one completed analysis is normally `isCurrent`.
        @Relationship(deleteRule: .cascade, inverse: \BiomechanicsAnalysis.kick)
        var analyses: [BiomechanicsAnalysis]? = []

        /// Creates an empty kick shell. Prefer `Kick.make(from:)`, which validates a
        /// complete `KickDraft`; a shell has no outcome until `applyOutcome(_:)` runs.
        init(id: UUID = UUID(), timestamp: Date = .now, context: KickContext = .training) {
            self.id = id
            self.timestamp = timestamp
            self.storedContext = context.storedValue
            self.createdAt = .now
            self.updatedAt = .now
        }
    }
}
