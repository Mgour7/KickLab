import Foundation
import SwiftData

/// Step 12G: typed access to the user's verified frames (schema V3 column).
extension VideoAsset {
    var verification: VideoVerification {
        get { verificationData.flatMap(VideoVerification.decode) ?? VideoVerification() }
        set { verificationData = newValue.isEmpty ? nil : try? newValue.encoded() }
    }
}
