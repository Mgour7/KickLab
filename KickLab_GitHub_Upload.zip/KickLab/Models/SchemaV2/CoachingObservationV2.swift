import Foundation
import SwiftData

// Step 12F: KickLab schema V2 copy of `CoachingObservation`. V1 (in `CoachingObservation.swift`) stays frozen for
// migration; the app uses this version through the typealias in `KickLabSchemaV2.swift`.
// Computed accessors and helpers live in extensions on the typealias (`CoachingObservation.swift`,
// `CoachingObservation+Profile.swift` …), so they apply to this version.
extension KickLabSchemaV2 {
    /// A KEEP, IMPROVE or CUE item produced by an analysis.
    ///
    /// Example pair:
    /// - IMPROVE: "Plant is averaging farther outside than on successful kicks."
    /// - CUE: "Get the plant underneath you." — its `relatedObservationID` holds the
    ///   IMPROVE observation's `id`.
    ///
    /// `relatedObservationID` is a plain UUID, deliberately not a self-referencing
    /// relationship. A dangling reference is tolerated and shown as "no linked item".
    @Model
    final class CoachingObservation {
        var id: UUID = UUID()
        /// Raw value of `ObservationKind`.
        var storedKind: String = "improve"
        /// Raw value of `AnalysisCategory`.
        var storedCategory: String = "overall"
        /// The observation or cue text shown to the athlete.
        var message: String = ""
        /// Raw value of `CoachingSeverity`. Meaningful only for IMPROVE.
        var storedSeverity: String?
        /// 0...1.
        var confidence: Double?
        /// Display order within its kind.
        var priority: Int = 0
        /// Raw value of `ComparisonBasis`.
        var storedComparisonBasis: String?
        /// Metric keys that justify this statement, so every claim is traceable to data.
        var evidenceMetricKeys: [String] = []
        /// For a CUE: the `id` of the IMPROVE observation it addresses.
        var relatedObservationID: UUID?
        /// Identifier of the coaching rule that generated this observation.
        var ruleKey: String?
        /// Raw value of `ObservationSource`.
        var storedSource: String = "engine"

        /// Inverse is declared on `BiomechanicsAnalysis.observations`.
        var analysis: BiomechanicsAnalysis?

        init(
            id: UUID = UUID(),
            kind: ObservationKind,
            category: AnalysisCategory,
            message: String,
            severity: CoachingSeverity? = nil,
            confidence: Double? = nil,
            relatedObservationID: UUID? = nil,
            source: ObservationSource = .engine
        ) {
            self.id = id
            self.storedKind = kind.storedValue
            self.storedCategory = category.storedValue
            self.message = message
            self.storedSeverity = severity?.storedValue
            self.confidence = confidence
            self.relatedObservationID = relatedObservationID
            self.storedSource = source.storedValue
        }
    }
}
