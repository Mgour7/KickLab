import Foundation
import SwiftData

// Step 12F: KickLab schema V2 copy of `BiomechanicalMetric`. V1 (in `BiomechanicalMetric.swift`) stays frozen for
// migration; the app uses this version through the typealias in `KickLabSchemaV2.swift`.
// Computed accessors and helpers live in extensions on the typealias (`BiomechanicalMetric.swift`,
// `BiomechanicalMetric+Profile.swift` …), so they apply to this version.
extension KickLabSchemaV2 {
    /// One scalar measurement produced by an analysis.
    ///
    /// Generic by design: `metricKey` is an open string (e.g. "plant.lateralDistance",
    /// "plant.kneeAngle", "torso.lean", "swing.footVelocityPeak"), so a new engine can
    /// emit new metrics with no schema change. Display names and canonical units come
    /// from a code catalog keyed by `metricKey` (added with the analysis services), so
    /// they can change and be localized without touching stored data.
    ///
    /// `metricDefinitionVersion` changes whenever a metric's definition changes, so
    /// values measured under different definitions are never compared as equals.
    ///
    /// Time-series curves are not stored here; they go in the analysis artifacts file.
    @Model
    final class BiomechanicalMetric {
        #Index<BiomechanicalMetric>([\.metricKey])

        var id: UUID = UUID()
        var metricKey: String = ""
        var metricDefinitionVersion: Int = 1
        /// Nil whenever the measurement is unavailable — never a placeholder number.
        var value: Double?
        /// Raw value of `MetricUnit`.
        var storedUnit: String = "unitless"
        /// 0...1.
        var confidence: Double?
        /// Raw value of `MeasurementStatus`.
        var storedMeasurementStatus: String = "unavailable"
        /// Raw value of `MechanicsPhase`.
        var storedPhase: String = "unknown"
        /// When in the clip the value was measured, in seconds.
        var sampleTimeSeconds: Double?
        /// Raw value of `VideoAngleType` for the camera that produced the value.
        var storedSourceAngle: String?

        /// Inverse is declared on `BiomechanicsAnalysis.metrics`.
        var analysis: BiomechanicsAnalysis?

        init(
            id: UUID = UUID(),
            metricKey: String,
            value: Double? = nil,
            unit: MetricUnit = .unitless,
            confidence: Double? = nil,
            measurementStatus: MeasurementStatus = .unavailable,
            phase: MechanicsPhase = .unknown
        ) {
            self.id = id
            self.metricKey = metricKey
            self.value = value
            self.storedUnit = unit.storedValue
            self.confidence = confidence
            self.storedMeasurementStatus = measurementStatus.storedValue
            self.storedPhase = phase.storedValue
        }
    }
}
