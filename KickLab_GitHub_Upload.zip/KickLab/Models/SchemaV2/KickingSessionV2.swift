import Foundation
import SwiftData

// Step 12F: KickLab schema V2 copy of `KickingSession`. V1 (in `KickingSession.swift`) stays frozen for
// migration; the app uses this version through the typealias in `KickLabSchemaV2.swift`.
// Computed accessors and helpers live in extensions on the typealias (`KickingSession.swift`,
// `KickingSession+Profile.swift` …), so they apply to this version.
extension KickLabSchemaV2 {
    /// A training session, game, camp, competition or warmup.
    ///
    /// Deleting a session nullifies `Kick.session`; the kicks themselves are kept
    /// and become "unassigned".
    @Model
    final class KickingSession {
        var id: UUID = UUID()
        var date: Date = Date.now
        var name: String = ""
        /// Raw value of `KickingSessionType`.
        var storedSessionType: String = "training"
        var location: String?
        var notes: String?
        var createdAt: Date = Date.now
        var updatedAt: Date = Date.now

        /// Inverse is declared on `Athlete.kickingSessions`.
        var athlete: Athlete?

        @Relationship(deleteRule: .nullify, inverse: \Kick.session)
        var kicks: [Kick]? = []

        init(
            id: UUID = UUID(),
            date: Date = .now,
            name: String = "",
            sessionType: KickingSessionType = .training,
            location: String? = nil,
            notes: String? = nil
        ) {
            self.id = id
            self.date = date
            self.name = name
            self.storedSessionType = sessionType.storedValue
            self.location = location
            self.notes = notes
            self.createdAt = .now
            self.updatedAt = .now
        }
    }
}
