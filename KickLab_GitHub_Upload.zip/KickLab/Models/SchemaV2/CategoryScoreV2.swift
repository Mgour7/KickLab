import Foundation
import SwiftData

// Step 12F: KickLab schema V2 copy of `CategoryScore`. V1 (in `CategoryScore.swift`) stays frozen for
// migration; the app uses this version through the typealias in `KickLabSchemaV2.swift`.
// Computed accessors and helpers live in extensions on the typealias (`CategoryScore.swift`,
// `CategoryScore+Profile.swift` …), so they apply to this version.
extension KickLabSchemaV2 {
    /// A 0–100 score for one mechanics category within an analysis.
    @Model
    final class CategoryScore {
        var id: UUID = UUID()
        /// Raw value of `AnalysisCategory`.
        var storedCategory: String = "overall"
        /// 0–100. Nil when the category could not be scored.
        var score: Double?
        /// 0...1.
        var confidence: Double?
        /// Raw value of `MeasurementStatus`.
        var storedMeasurementStatus: String = "unavailable"
        var summary: String?

        /// Inverse is declared on `BiomechanicsAnalysis.categoryScores`.
        var analysis: BiomechanicsAnalysis?

        init(
            id: UUID = UUID(),
            category: AnalysisCategory,
            score: Double? = nil,
            confidence: Double? = nil,
            measurementStatus: MeasurementStatus = .unavailable,
            summary: String? = nil
        ) {
            self.id = id
            self.storedCategory = category.storedValue
            self.score = score
            self.confidence = confidence
            self.storedMeasurementStatus = measurementStatus.storedValue
            self.summary = summary
        }
    }
}
