import Foundation
import SwiftData

// Step 12F: KickLab schema V2 copy of `Athlete`. V1 (in `Athlete.swift`) stays frozen for
// migration; the app uses this version through the typealias in `KickLabSchemaV2.swift`.
// Computed accessors and helpers live in extensions on the typealias (`Athlete.swift`,
// `Athlete+Profile.swift` …), so they apply to this version.
extension KickLabSchemaV2 {
    /// A kicker. V1 shows one athlete in the UI, but the model supports many.
    ///
    /// Delete rules are `.nullify` on purpose: deleting an athlete row can never
    /// destroy kicking history. Removal is a soft delete (`isArchived`); permanent
    /// deletion is only ever done deliberately by `AthleteService` (step 5).
    @Model
    final class Athlete {
        var id: UUID = UUID()
        var firstName: String = ""
        var lastName: String = ""
        var dateOfBirth: Date?
        var graduationYear: Int?
        /// Raw value of `KickingFoot`.
        var storedKickingFoot: String = "right"
        /// Raw value of `PlayingLevel`. Snapshotted onto each new kick.
        var storedCurrentPlayingLevel: String = "highSchool"
        /// Canonical unit: inches.
        var heightInches: Double?
        /// Canonical unit: pounds.
        var weightPounds: Double?
        var schoolTeam: String?
        /// A string so values like "07" survive.
        var jerseyNumber: String?
        /// Soft delete. Archived athletes are hidden but fully preserved.
        var isArchived: Bool = false
        var createdAt: Date = Date.now
        var updatedAt: Date = Date.now

        // MARK: Step 12F profile (V2, all optional — lightweight migration)

        /// What the athlete likes to be called.
        var nickname: String?
        /// Optional profile photo (JPEG), stored outside the database file.
        @Attribute(.externalStorage) var photoData: Data?
        /// Used when no date of birth is entered.
        var birthYear: Int?
        /// Raw value of `AthleteRole`.
        var storedPrimaryRole: String?
        /// Raw value of `ExperienceLevel`.
        var storedExperienceLevel: String?
        /// The athlete's own goals, free text.
        var goals: String?
        /// Raw value of `FootballType`.
        var storedPreferredBallType: String?

        @Relationship(deleteRule: .nullify, inverse: \KickingSession.athlete)
        var kickingSessions: [KickingSession]? = []

        /// Direct link so per-athlete kick queries never traverse sessions.
        @Relationship(deleteRule: .nullify, inverse: \Kick.athlete)
        var kicks: [Kick]? = []

        init(
            id: UUID = UUID(),
            firstName: String = "",
            lastName: String = "",
            kickingFoot: KickingFoot = .right,
            currentPlayingLevel: PlayingLevel = .highSchool,
            createdAt: Date = .now
        ) {
            self.id = id
            self.firstName = firstName
            self.lastName = lastName
            self.storedKickingFoot = kickingFoot.storedValue
            self.storedCurrentPlayingLevel = currentPlayingLevel.storedValue
            self.createdAt = createdAt
            self.updatedAt = createdAt
        }
    }
}
