import Foundation

// The typed boundary around Kick's flat outcome columns.
// Views, view models and services use only these members; they never assign
// outcome columns directly (invariant G3).

extension Kick {
    // MARK: Typed accessors for simple enum columns

    /// Read-only. The type changes only through `applyOutcome(_:)`, which rewrites
    /// every outcome column in the same step.
    var kickType: KickType { KickType(storedValue: storedKickType) }

    var context: KickContext {
        get { KickContext(storedValue: storedContext) }
        set { storedContext = newValue.storedValue }
    }

    var hashLocation: HashLocation {
        get { HashLocation(storedValue: storedHashLocation) }
        set { storedHashLocation = newValue.storedValue }
    }

    var playingLevelAtKick: PlayingLevel? {
        get { PlayingLevel(optionalStoredValue: storedPlayingLevelAtKick) }
        set { storedPlayingLevelAtKick = newValue?.storedValue }
    }

    // MARK: Typed outcome (read)

    /// A snapshot of the flat outcome columns.
    var outcomeColumns: KickOutcomeColumns {
        KickOutcomeColumns(
            storedResult: storedResult,
            accuracyX: accuracyX,
            accuracyY: accuracyY,
            storedAccuracySource: storedAccuracySource,
            accuracyConfidence: accuracyConfidence,
            distanceYards: distanceYards,
            storedDistanceSource: storedDistanceSource,
            distanceConfidence: distanceConfidence,
            landingYardLine: landingYardLine,
            storedLandingZone: storedLandingZone,
            storedLandingSource: storedLandingSource,
            landingConfidence: landingConfidence,
            touchback: touchback,
            outOfBounds: outOfBounds,
            hangTimeSeconds: hangTimeSeconds,
            storedHangTimeSource: storedHangTimeSource,
            hangTimeConfidence: hangTimeConfidence
        )
    }

    /// The typed outcome, or nil for an `unknown` kick type.
    var outcome: KickOutcome? {
        KickOutcome(kickType: kickType, columns: outcomeColumns)
    }

    /// Non-nil for field goals and PATs.
    var fieldGoalOutcome: FieldGoalOutcome? {
        switch outcome {
        case .fieldGoal(let value)?, .pat(let value)?: value
        default: nil
        }
    }

    /// Non-nil for kickoffs.
    var kickoffOutcome: KickoffOutcome? {
        switch outcome {
        case .kickoff(let value)?: value
        default: nil
        }
    }

    /// Non-nil for punts.
    var puntOutcome: PuntOutcome? {
        switch outcome {
        case .punt(let value)?: value
        default: nil
        }
    }

    /// Audits the persisted columns. Empty means the stored state is valid.
    /// Used after imports and in debug consistency checks.
    var validationIssues: [KickValidationIssue] {
        var issues = KickValidator.validate(kickType: kickType, columns: outcomeColumns)
        issues += KickValidator.validateSpotDistanceToTargetGoalLine(spotDistanceToTargetGoalLine)
        return issues
    }

    // MARK: Writes

    /// The single write path for outcome data.
    ///
    /// Validates first, then sets `storedKickType` and rewrites **every** outcome
    /// column — values, sources and confidences. Columns that do not apply to the
    /// new type are cleared, so changing a kickoff into a field goal can never leave
    /// stale landing data or landing provenance behind.
    ///
    /// - Throws: `KickValidationError`; nothing is written when it throws.
    func applyOutcome(_ outcome: KickOutcome) throws {
        let columns = KickOutcomeColumns(outcome: outcome)
        try KickValidator.validateOrThrow(kickType: outcome.kickType, columns: columns)
        storedKickType = outcome.kickType.storedValue
        write(columns)
        updatedAt = .now
    }

    /// Creates a validated kick from a draft. The caller (KickService, step 5) still
    /// links the athlete and session and inserts the kick into a context.
    static func make(from draft: KickDraft) throws -> Kick {
        try KickValidator.validateOrThrow(draft)
        let kick = Kick(id: draft.id, timestamp: draft.timestamp, context: draft.context ?? .training)
        try kick.update(from: draft)
        return kick
    }

    /// Applies a draft to an existing kick. Validates the whole draft before
    /// changing anything. A nil `context` or `playingLevelAtKick` keeps the stored value.
    func update(from draft: KickDraft) throws {
        try KickValidator.validateOrThrow(draft)
        timestamp = draft.timestamp
        if let context = draft.context { self.context = context }
        if let level = draft.playingLevelAtKick { playingLevelAtKick = level }
        spotDistanceToTargetGoalLine = draft.spotDistanceToTargetGoalLine
        hashLocation = draft.hashLocation
        isReferenceKick = draft.isReferenceKick
        notes = draft.notes
        try applyOutcome(draft.outcome)
        // Step 12F: entered details (V2 columns), only those that apply to the type.
        let details = draft.details.applicable(to: draft.kickType)
        ballType = details.ballType
        kickSetup = details.setup
        conditionsNote = details.conditions
        kickDirection = details.direction
        puntInsideTwenty = details.puntInsideTwenty
        puntResult = details.puntResult
    }

    /// The only place `athleteID` is written: it always moves together with `athlete`.
    func assignAthlete(_ athlete: Athlete?) {
        self.athlete = athlete
        self.athleteID = athlete?.id
        updatedAt = .now
    }

    private func write(_ columns: KickOutcomeColumns) {
        storedResult = columns.storedResult
        accuracyX = columns.accuracyX
        accuracyY = columns.accuracyY
        storedAccuracySource = columns.storedAccuracySource
        accuracyConfidence = columns.accuracyConfidence
        distanceYards = columns.distanceYards
        storedDistanceSource = columns.storedDistanceSource
        distanceConfidence = columns.distanceConfidence
        landingYardLine = columns.landingYardLine
        storedLandingZone = columns.storedLandingZone
        storedLandingSource = columns.storedLandingSource
        landingConfidence = columns.landingConfidence
        touchback = columns.touchback
        outOfBounds = columns.outOfBounds
        hangTimeSeconds = columns.hangTimeSeconds
        storedHangTimeSource = columns.storedHangTimeSource
        hangTimeConfidence = columns.hangTimeConfidence
    }
}
