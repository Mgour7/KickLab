import Foundation

/// Fields that validation can report on. Not persisted.
enum KickField: String, CaseIterable, Sendable {
    case result
    case distance
    case accuracy
    case landing
    case touchback
    case outOfBounds
    case hangTime
    case spotDistanceToTargetGoalLine

    /// Fields that belong to the outcome (everything except field location).
    static let outcomeFields: [KickField] = [.result, .distance, .accuracy, .landing, .touchback, .outOfBounds, .hangTime]

    var displayName: String {
        switch self {
        case .result: "Result"
        case .distance: "Distance"
        case .accuracy: "Accuracy"
        case .landing: "Landing"
        case .touchback: "Touchback"
        case .outOfBounds: "Out of bounds"
        case .hangTime: "Hang time"
        case .spotDistanceToTargetGoalLine: "Ball spot"
        }
    }
}

/// One reason a kick's data is invalid.
enum KickValidationIssue: Equatable, Sendable, CustomStringConvertible {
    /// The kick type is `unknown` (written by a newer version); it cannot be written.
    case unknownKickType
    /// The field has data but does not apply to this kick type.
    case fieldNotAllowed(KickField, kickType: KickType)
    case missingRequiredField(KickField)
    /// A stored enum string is not a recognized raw value.
    case unrecognizedStoredValue(KickField, rawValue: String)
    case nonFiniteValue(KickField)
    case valueOutOfRange(KickField, value: Double)
    /// A measured value has no source.
    case valueWithoutSource(KickField)
    /// A source is recorded but there is no value.
    case sourceWithoutValue(KickField)
    /// A confidence is recorded but there is no value.
    case confidenceWithoutValue(KickField)
    case nonFiniteConfidence(KickField)
    case confidenceOutOfRange(KickField, value: Double)
    /// Manual entries must not carry a confidence.
    case manualMeasurementHasConfidence(KickField)
    /// `accuracyY` is set without `accuracyX`.
    case verticalAccuracyWithoutHorizontal
    case touchbackAndOutOfBounds
    /// The recorded result cannot be true given where the ball crossed.
    case resultContradictsAccuracy(KickResult, x: Double, y: Double?)

    var description: String {
        switch self {
        case .unknownKickType:
            "The kick type is not recognized by this version of KickLab."
        case .fieldNotAllowed(let field, let kickType):
            "\(field.displayName) does not apply to a \(kickType.displayName)."
        case .missingRequiredField(let field):
            "\(field.displayName) is required."
        case .unrecognizedStoredValue(let field, let rawValue):
            "\(field.displayName) has an unrecognized value \"\(rawValue)\"."
        case .nonFiniteValue(let field):
            "\(field.displayName) must be a finite number."
        case .valueOutOfRange(let field, let value):
            "\(field.displayName) value \(value) is outside the allowed range."
        case .valueWithoutSource(let field):
            "\(field.displayName) needs a measurement source."
        case .sourceWithoutValue(let field):
            "\(field.displayName) has a source but no value."
        case .confidenceWithoutValue(let field):
            "\(field.displayName) has a confidence but no value."
        case .nonFiniteConfidence(let field):
            "\(field.displayName) confidence must be a finite number."
        case .confidenceOutOfRange(let field, let value):
            "\(field.displayName) confidence \(value) must be between 0 and 1."
        case .manualMeasurementHasConfidence(let field):
            "\(field.displayName) was entered manually and cannot carry a confidence."
        case .verticalAccuracyWithoutHorizontal:
            "Vertical accuracy requires a horizontal position."
        case .touchbackAndOutOfBounds:
            "A kickoff cannot be both a touchback and out of bounds."
        case .resultContradictsAccuracy(let result, let x, _):
            "\(result.displayName) contradicts the recorded crossing point (x = \(x))."
        }
    }
}

/// Thrown when a kick write fails validation. Nothing is written.
struct KickValidationError: Error, Equatable, Sendable, LocalizedError {
    let issues: [KickValidationIssue]

    var errorDescription: String? {
        issues.map(\.description).joined(separator: "\n")
    }
}
