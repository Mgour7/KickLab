import Foundation

/// Enforces: every input video of an analysis belongs to the same kick as the analysis.
///
/// `BiomechanicsAnalysis.attachInputVideo(_:)` uses this to reject bad links before
/// they are made. `AnalysisService` and import code use `issues(for:)` to audit
/// existing records.
enum AnalysisIntegrityValidator {
    /// Problems that attaching `video` to `analysis` would create.
    static func issues(attaching video: VideoAsset, to analysis: BiomechanicsAnalysis) -> [AnalysisIntegrityIssue] {
        guard let analysisKick = analysis.kick else {
            return [.analysisHasNoKick(analysisID: analysis.id)]
        }
        return issues(attaching: video, toKick: analysisKick)
    }

    /// Problems with using `video` as input for an analysis of `kick`.
    /// Used before the analysis exists, so nothing is inserted on failure.
    static func issues(attaching video: VideoAsset, toKick kick: Kick) -> [AnalysisIntegrityIssue] {
        guard let videoKick = video.kick else {
            return [.videoIsOrphaned(videoID: video.id)]
        }
        guard videoKick.id == kick.id else {
            return [.videoBelongsToDifferentKick(videoID: video.id, videoKickID: videoKick.id, analysisKickID: kick.id)]
        }
        return []
    }

    /// Audits every input video already linked to `analysis`.
    static func issues(for analysis: BiomechanicsAnalysis) -> [AnalysisIntegrityIssue] {
        let videos = analysis.inputVideos ?? []
        guard analysis.kick != nil else {
            return videos.isEmpty ? [] : [.analysisHasNoKick(analysisID: analysis.id)]
        }
        return videos.flatMap { issues(attaching: $0, to: analysis) }
    }
}
