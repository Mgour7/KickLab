import Foundation

/// The single place for numeric sanity bounds used by `KickValidator`.
///
/// These are physical plausibility limits, not league rules: nothing here encodes
/// NFL, NCAA or high school rules.
enum KickValidationLimits {
    /// Kick distance in yards (FG/PAT, kickoff and punt).
    static let distanceYards: ClosedRange<Double> = 0...110
    /// Hold/tee/snap spot as a 0–100 coordinate: yards from the goal line the kick
    /// travels toward (0 = that goal line, 50 = midfield, 100 = the kicking team's goal line).
    static let spotDistanceToTargetGoalLine: ClosedRange<Int> = 0...100
    /// Landing spot; negative values are inside the end zone (or beyond the end line).
    static let landingYardLine: ClosedRange<Double> = -20...110
    /// Hang time in seconds. Zero is excluded: a kick with hang time stayed in the air.
    static let hangTimeSeconds: ClosedRange<Double> = 0.01...10
    /// Normalized goalpost coordinates (each axis).
    static let accuracyCoordinate: ClosedRange<Double> = -10...10
    static let confidence: ClosedRange<Double> = 0...1
    /// Slack around the uprights and crossbar when checking a result against a
    /// crossing point, so a ball grazing an upright is not treated as a contradiction.
    static let goalpostTolerance: Double = 0.05
}
