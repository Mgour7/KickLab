import Foundation

/// A reason an analysis's input videos are invalid.
enum AnalysisIntegrityIssue: Equatable, Sendable {
    /// The analysis is not attached to a kick.
    case analysisHasNoKick(analysisID: UUID)
    /// The video has no kick; it is orphaned and cannot be analysis input.
    case videoIsOrphaned(videoID: UUID)
    /// The video belongs to a different kick than the analysis.
    case videoBelongsToDifferentKick(videoID: UUID, videoKickID: UUID, analysisKickID: UUID)
}

struct AnalysisIntegrityError: Error, Equatable, Sendable {
    let issues: [AnalysisIntegrityIssue]
}
