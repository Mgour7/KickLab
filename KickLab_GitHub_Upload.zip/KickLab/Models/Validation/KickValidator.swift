import Foundation

/// Pure validation for kick outcome data. Holds no state and touches no database.
///
/// Used at the model boundary (`Kick.applyOutcome`, `Kick.make(from:)`,
/// `Kick.update(from:)`) and, from step 5, by `KickService` and importers.
/// SwiftUI views never contain validation logic.
///
/// Rules:
/// - FG/PAT: result (required), distance, accuracy. No kickoff fields, no hang time.
/// - Kickoff: distance, landing, touchback, out of bounds, hang time. No result or accuracy.
///   Touchback and out of bounds cannot both be true.
/// - Punt (V1): distance and hang time only.
/// - Each measured group (distance, accuracy, landing, hang time):
///   value ⇔ source; confidence requires a value, must be finite and within 0...1,
///   and is forbidden on manual entries.
/// - Values must be finite and within `KickValidationLimits`.
/// - A result must not contradict the recorded crossing point.
enum KickValidator {
    /// The outcome fields each kick type may carry.
    static func allowedFields(for kickType: KickType) -> Set<KickField> {
        switch kickType {
        case .fieldGoal, .pat: [.result, .distance, .accuracy]
        case .kickoff: [.distance, .landing, .touchback, .outOfBounds, .hangTime]
        case .punt: [.distance, .hangTime]
        case .unknown: []
        }
    }

    // MARK: Entry points

    /// Validates a complete draft.
    static func validate(_ draft: KickDraft) -> [KickValidationIssue] {
        let columns = KickOutcomeColumns(outcome: draft.outcome)
        return validate(kickType: draft.kickType, columns: columns) + validateSpotDistanceToTargetGoalLine(draft.spotDistanceToTargetGoalLine)
    }

    static func validateOrThrow(_ draft: KickDraft) throws {
        let issues = validate(draft)
        if !issues.isEmpty { throw KickValidationError(issues: issues) }
    }

    static func validateOrThrow(kickType: KickType, columns: KickOutcomeColumns) throws {
        let issues = validate(kickType: kickType, columns: columns)
        if !issues.isEmpty { throw KickValidationError(issues: issues) }
    }

    /// The spot must be a 0–100 coordinate. It is never compared with or used to
    /// derive `distanceYards`.
    static func validateSpotDistanceToTargetGoalLine(_ spot: Int?) -> [KickValidationIssue] {
        guard let spot, !KickValidationLimits.spotDistanceToTargetGoalLine.contains(spot) else { return [] }
        return [.valueOutOfRange(.spotDistanceToTargetGoalLine, value: Double(spot))]
    }

    /// Validates raw outcome columns for a kick type. Works on stored data that never
    /// went through a draft (imports, legacy rows), so it re-checks everything.
    static func validate(kickType: KickType, columns c: KickOutcomeColumns) -> [KickValidationIssue] {
        guard kickType != .unknown else { return [.unknownKickType] }

        var issues: [KickValidationIssue] = []

        // 1. Fields that do not belong to this kick type.
        let allowed = allowedFields(for: kickType)
        for field in KickField.outcomeFields where c.hasData(for: field) && !allowed.contains(field) {
            issues.append(.fieldNotAllowed(field, kickType: kickType))
        }

        // 2. Required fields.
        if kickType.usesGoalpostOutcome && c.storedResult == nil {
            issues.append(.missingRequiredField(.result))
        }

        // 3. Stored enum strings must be recognized.
        checkRecognized(c.storedResult, as: KickResult.self, field: .result, into: &issues)
        checkRecognized(c.storedLandingZone, as: LandingZone.self, field: .landing, into: &issues)
        checkRecognized(c.storedDistanceSource, as: OutcomeMeasurementSource.self, field: .distance, into: &issues)
        checkRecognized(c.storedAccuracySource, as: OutcomeMeasurementSource.self, field: .accuracy, into: &issues)
        checkRecognized(c.storedLandingSource, as: OutcomeMeasurementSource.self, field: .landing, into: &issues)
        checkRecognized(c.storedHangTimeSource, as: OutcomeMeasurementSource.self, field: .hangTime, into: &issues)

        // 4. Measured groups: ranges, provenance and confidence.
        validateMeasurement(
            .distance,
            values: [c.distanceYards],
            range: KickValidationLimits.distanceYards,
            hasValue: c.distanceYards != nil,
            source: c.storedDistanceSource,
            confidence: c.distanceConfidence,
            into: &issues
        )
        validateMeasurement(
            .accuracy,
            values: [c.accuracyX, c.accuracyY],
            range: KickValidationLimits.accuracyCoordinate,
            hasValue: c.accuracyX != nil || c.accuracyY != nil,
            source: c.storedAccuracySource,
            confidence: c.accuracyConfidence,
            into: &issues
        )
        validateMeasurement(
            .landing,
            values: [c.landingYardLine],
            range: KickValidationLimits.landingYardLine,
            hasValue: c.landingYardLine != nil || c.storedLandingZone != nil,
            source: c.storedLandingSource,
            confidence: c.landingConfidence,
            into: &issues
        )
        validateMeasurement(
            .hangTime,
            values: [c.hangTimeSeconds],
            range: KickValidationLimits.hangTimeSeconds,
            hasValue: c.hangTimeSeconds != nil,
            source: c.storedHangTimeSource,
            confidence: c.hangTimeConfidence,
            into: &issues
        )

        // 5. Cross-field rules.
        if c.accuracyY != nil && c.accuracyX == nil {
            issues.append(.verticalAccuracyWithoutHorizontal)
        }
        if c.touchback == true && c.outOfBounds == true {
            issues.append(.touchbackAndOutOfBounds)
        }
        if let issue = resultContradiction(c) {
            issues.append(issue)
        }

        return issues
    }

    // MARK: Helpers

    private static func checkRecognized<E: PersistedStringEnum>(
        _ stored: String?,
        as type: E.Type,
        field: KickField,
        into issues: inout [KickValidationIssue]
    ) {
        guard let stored, !E.isRecognized(stored) else { return }
        issues.append(.unrecognizedStoredValue(field, rawValue: stored))
    }

    private static func validateMeasurement(
        _ field: KickField,
        values: [Double?],
        range: ClosedRange<Double>,
        hasValue: Bool,
        source: String?,
        confidence: Double?,
        into issues: inout [KickValidationIssue]
    ) {
        for value in values.compactMap({ $0 }) {
            if !value.isFinite {
                issues.append(.nonFiniteValue(field))
            } else if !range.contains(value) {
                issues.append(.valueOutOfRange(field, value: value))
            }
        }

        if hasValue && source == nil {
            issues.append(.valueWithoutSource(field))
        }
        if !hasValue && source != nil {
            issues.append(.sourceWithoutValue(field))
        }

        guard let confidence else { return }
        if !hasValue {
            issues.append(.confidenceWithoutValue(field))
        }
        if !confidence.isFinite {
            issues.append(.nonFiniteConfidence(field))
        } else if !KickValidationLimits.confidence.contains(confidence) {
            issues.append(.confidenceOutOfRange(field, value: confidence))
        }
        if let source, OutcomeMeasurementSource(rawValue: source)?.allowsConfidence == false {
            issues.append(.manualMeasurementHasConfidence(field))
        }
    }

    /// A made kick must cross between the uprights (and above the crossbar when the
    /// vertical position is known). A miss left must cross at or outside the left
    /// upright; a miss right at or outside the right upright. Short, blocked and
    /// unknown results place no constraint on the crossing point.
    private static func resultContradiction(_ c: KickOutcomeColumns) -> KickValidationIssue? {
        guard
            let raw = c.storedResult,
            let result = KickResult(rawValue: raw),
            let x = c.accuracyX, x.isFinite
        else { return nil }

        let tolerance = KickValidationLimits.goalpostTolerance
        let y = c.accuracyY.flatMap { $0.isFinite ? $0 : nil }
        let contradicts: Bool

        switch result {
        case .made:
            let outsideUprights = abs(x) > AccuracyCoordinate.rightUpright + tolerance
            let belowCrossbar = y.map { $0 < AccuracyCoordinate.crossbar - tolerance } ?? false
            contradicts = outsideUprights || belowCrossbar
        case .missedLeft:
            contradicts = x > AccuracyCoordinate.leftUpright + tolerance
        case .missedRight:
            contradicts = x < AccuracyCoordinate.rightUpright - tolerance
        case .short, .blocked, .missedOther, .unknown:
            contradicts = false
        }

        return contradicts ? .resultContradictsAccuracy(result, x: x, y: c.accuracyY) : nil
    }
}
