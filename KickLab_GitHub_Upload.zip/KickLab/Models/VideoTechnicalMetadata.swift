import Foundation

/// Small capture metadata stored in `VideoAsset.technicalMetadata`.
///
/// Purpose: rarely-queried camera and codec details that should not each need a
/// schema migration. New optional keys can be added freely; `formatVersion` lets
/// readers handle older payloads.
///
/// Not for: video frames, pose arrays, rendered overlays, ML tensors or analysis
/// output. Those belong in file-backed artifacts referenced by
/// `BiomechanicsAnalysis.artifactsRelativePath`. The encoded size is capped at
/// `maximumEncodedBytes` to keep this honest.
struct VideoTechnicalMetadata: Codable, Equatable, Sendable {
    static let currentFormatVersion = 1
    static let maximumEncodedBytes = 4_096

    var formatVersion: Int = VideoTechnicalMetadata.currentFormatVersion
    var deviceModel: String?
    var lensDescription: String?
    var codec: String?
    var orientation: String?
    var colorSpace: String?
    var isoValue: Double?
    var shutterDurationSeconds: Double?
    var isSlowMotion: Bool?

    enum EncodingError: Error, Equatable {
        case tooLarge(byteCount: Int, limit: Int)
    }

    func encoded() throws -> Data {
        let data = try JSONEncoder().encode(self)
        guard data.count <= Self.maximumEncodedBytes else {
            throw EncodingError.tooLarge(byteCount: data.count, limit: Self.maximumEncodedBytes)
        }
        return data
    }

    static func decode(_ data: Data) -> VideoTechnicalMetadata? {
        try? JSONDecoder().decode(VideoTechnicalMetadata.self, from: data)
    }
}
