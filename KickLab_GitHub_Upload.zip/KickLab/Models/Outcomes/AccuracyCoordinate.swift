import Foundation

/// Where a field goal or PAT crossed (or would have crossed) the goal plane,
/// in normalized goalpost coordinates — never pixels.
///
/// Left/right are from the kicker's perspective, facing the goal. A behind-the-goal
/// camera sees the scene mirrored; converting is the analysis layer's job.
///
/// Horizontal (`x`):
/// - `-1` = left upright, `0` = center, `+1` = right upright.
/// - Values beyond ±1 are outside the uprights (e.g. `-1.8` is a clear miss left).
///
/// Vertical (`y`):
/// - Same unit as `x`: one unit is half the inside width between the uprights,
///   so the target keeps its true aspect ratio.
/// - `0` = crossbar height, positive = above, negative = below.
/// - `nil` when vertical position is not reliably known. V1 may record only `x`.
///   A vertical value is never guessed.
///
/// Because coordinates are relative to the uprights, the physical width they
/// represent depends on the goalposts used; `Kick.playingLevelAtKick` gives that context.
struct AccuracyCoordinate: Equatable, Sendable {
    static let leftUpright: Double = -1
    static let center: Double = 0
    static let rightUpright: Double = 1
    static let crossbar: Double = 0

    var x: Double
    var y: Double?

    init(x: Double, y: Double? = nil) {
        self.x = x
        self.y = y
    }

    enum HorizontalZone: Equatable, Sendable {
        case insideUprights
        case outsideLeft
        case outsideRight
    }

    /// A ball exactly on an upright line (|x| == 1) counts as inside.
    var horizontalZone: HorizontalZone {
        if x < Self.leftUpright { return .outsideLeft }
        if x > Self.rightUpright { return .outsideRight }
        return .insideUprights
    }

    var isVerticalKnown: Bool { y != nil }

    /// Nil when vertical position is unknown.
    var isAboveCrossbar: Bool? {
        guard let y else { return nil }
        return y >= Self.crossbar
    }
}
