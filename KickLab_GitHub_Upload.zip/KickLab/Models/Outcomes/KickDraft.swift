import Foundation

/// The input for creating or editing a kick.
///
/// The kick type is derived from `outcome`, so a draft cannot pair one kick type
/// with another type's outcome. Athlete and session linkage are not part of the
/// draft: `KickService` (step 5) supplies them so `athleteID` and the session's
/// athlete can be kept consistent.
struct KickDraft: Equatable, Sendable {
    var id: UUID = UUID()
    var timestamp: Date = .now
    var outcome: KickOutcome
    /// Nil means "use the session's default" (resolved by KickService), or keep the
    /// stored value when updating.
    var context: KickContext? = nil
    /// Nil means "snapshot the athlete's current level" (resolved by KickService),
    /// or keep the stored value when updating.
    var playingLevelAtKick: PlayingLevel? = nil
    /// Field location of the hold/tee/snap as a 0–100 coordinate: yards from the goal
    /// line the kick travels toward (Opp 30 = 30, own 40 = 60). Separate from distance:
    /// spot 30 with a 40-yard distance displays as "Hold: Opp 30 · Distance: 40 yd".
    var spotDistanceToTargetGoalLine: Int? = nil
    var hashLocation: HashLocation = .notApplicable
    var isReferenceKick: Bool = false
    var notes: String? = nil
    /// Step 12F: optional details the user enters (never measured).
    var details: KickEnteredDetails = KickEnteredDetails()

    var kickType: KickType { outcome.kickType }
}

/// Step 12F: optional entered details of a kick (schema V2 columns). All user-entered;
/// none is ever computed from video. Fields that don't apply to the kick type are cleared.
struct KickEnteredDetails: Equatable, Sendable {
    var ballType: FootballType?
    var setup: KickSetup?
    /// Wind and weather in the user's words.
    var conditions: String?
    /// Kickoffs and punts.
    var direction: KickDirection?
    /// Punts only.
    var puntInsideTwenty: Bool?
    var puntResult: PuntResult?

    init(ballType: FootballType? = nil, setup: KickSetup? = nil, conditions: String? = nil, direction: KickDirection? = nil,
         puntInsideTwenty: Bool? = nil, puntResult: PuntResult? = nil) {
        self.ballType = ballType
        self.setup = setup
        self.conditions = conditions
        self.direction = direction
        self.puntInsideTwenty = puntInsideTwenty
        self.puntResult = puntResult
    }

    /// Only the fields that apply to `type`.
    func applicable(to type: KickType) -> KickEnteredDetails {
        var d = self
        d.conditions = conditions.normalizedOptionalText
        if type != .kickoff && type != .punt { d.direction = nil }
        if type != .punt {
            d.puntInsideTwenty = nil
            d.puntResult = nil
        }
        return d
    }
}
