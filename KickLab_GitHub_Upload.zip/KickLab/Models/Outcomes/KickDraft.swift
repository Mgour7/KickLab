import Foundation

/// The input for creating or editing a kick.
///
/// The kick type is derived from `outcome`, so a draft cannot pair one kick type
/// with another type's outcome. Athlete and session linkage are not part of the
/// draft: `KickService` (step 5) supplies them so `athleteID` and the session's
/// athlete can be kept consistent.
struct KickDraft: Equatable, Sendable {
    var id: UUID = UUID()
    var timestamp: Date = .now
    var outcome: KickOutcome
    /// Nil means "use the session's default" (resolved by KickService), or keep the
    /// stored value when updating.
    var context: KickContext? = nil
    /// Nil means "snapshot the athlete's current level" (resolved by KickService),
    /// or keep the stored value when updating.
    var playingLevelAtKick: PlayingLevel? = nil
    /// Field location of the hold/tee/snap as a 0–100 coordinate: yards from the goal
    /// line the kick travels toward (Opp 30 = 30, own 40 = 60). Separate from distance:
    /// spot 30 with a 40-yard distance displays as "Hold: Opp 30 · Distance: 40 yd".
    var spotDistanceToTargetGoalLine: Int? = nil
    var hashLocation: HashLocation = .notApplicable
    var isReferenceKick: Bool = false
    var notes: String? = nil

    var kickType: KickType { outcome.kickType }
}
