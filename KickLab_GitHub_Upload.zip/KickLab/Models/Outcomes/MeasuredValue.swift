import Foundation

/// A value plus where it came from and how sure we are.
///
/// Pairing value, source and confidence in one type makes "a distance with no
/// source" impossible to express in a draft.
struct MeasuredValue<Value: Equatable & Sendable>: Equatable, Sendable {
    var value: Value
    var source: OutcomeMeasurementSource
    /// 0...1 for automated measurements. Always nil for manual entries.
    var confidence: Double?

    init(value: Value, source: OutcomeMeasurementSource, confidence: Double? = nil) {
        self.value = value
        self.source = source
        self.confidence = confidence
    }

    /// A manually entered value. Manual entries never carry a confidence.
    static func manual(_ value: Value) -> MeasuredValue<Value> {
        MeasuredValue(value: value, source: .manual, confidence: nil)
    }

    /// A value measured by an automated or external source.
    static func measured(
        _ value: Value,
        from source: OutcomeMeasurementSource,
        confidence: Double?
    ) -> MeasuredValue<Value> {
        MeasuredValue(value: value, source: source, confidence: confidence)
    }
}
