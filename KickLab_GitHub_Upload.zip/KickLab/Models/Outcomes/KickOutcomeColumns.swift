import Foundation

/// A plain value mirror of every flat outcome column on `Kick`.
///
/// It exists so the mapping between the typed outcome and storage is pure and
/// testable without a database, and so `KickValidator` can audit raw stored state
/// (including imports and legacy rows that never passed through a draft).
struct KickOutcomeColumns: Equatable, Sendable {
    // FG/PAT
    var storedResult: String?
    var accuracyX: Double?
    var accuracyY: Double?
    var storedAccuracySource: String?
    var accuracyConfidence: Double?

    // All types
    var distanceYards: Double?
    var storedDistanceSource: String?
    var distanceConfidence: Double?

    // Kickoff
    var landingYardLine: Double?
    var storedLandingZone: String?
    var storedLandingSource: String?
    var landingConfidence: Double?
    var touchback: Bool?
    var outOfBounds: Bool?

    // Kickoff and punt
    var hangTimeSeconds: Double?
    var storedHangTimeSource: String?
    var hangTimeConfidence: Double?

    init(
        storedResult: String? = nil,
        accuracyX: Double? = nil,
        accuracyY: Double? = nil,
        storedAccuracySource: String? = nil,
        accuracyConfidence: Double? = nil,
        distanceYards: Double? = nil,
        storedDistanceSource: String? = nil,
        distanceConfidence: Double? = nil,
        landingYardLine: Double? = nil,
        storedLandingZone: String? = nil,
        storedLandingSource: String? = nil,
        landingConfidence: Double? = nil,
        touchback: Bool? = nil,
        outOfBounds: Bool? = nil,
        hangTimeSeconds: Double? = nil,
        storedHangTimeSource: String? = nil,
        hangTimeConfidence: Double? = nil
    ) {
        self.storedResult = storedResult
        self.accuracyX = accuracyX
        self.accuracyY = accuracyY
        self.storedAccuracySource = storedAccuracySource
        self.accuracyConfidence = accuracyConfidence
        self.distanceYards = distanceYards
        self.storedDistanceSource = storedDistanceSource
        self.distanceConfidence = distanceConfidence
        self.landingYardLine = landingYardLine
        self.storedLandingZone = storedLandingZone
        self.storedLandingSource = storedLandingSource
        self.landingConfidence = landingConfidence
        self.touchback = touchback
        self.outOfBounds = outOfBounds
        self.hangTimeSeconds = hangTimeSeconds
        self.storedHangTimeSource = storedHangTimeSource
        self.hangTimeConfidence = hangTimeConfidence
    }

    /// Encodes a typed outcome. Starts from all-nil columns and fills only those
    /// that belong to the outcome's type — so every value, source and confidence
    /// from any other type is cleared by construction.
    init(outcome: KickOutcome) {
        self.init()
        switch outcome {
        case .fieldGoal(let o), .pat(let o):
            storedResult = o.result.storedValue
            setDistance(o.distance)
            if let accuracy = o.accuracy {
                accuracyX = accuracy.value.x
                accuracyY = accuracy.value.y
                storedAccuracySource = accuracy.source.storedValue
                accuracyConfidence = accuracy.confidence
            }

        case .kickoff(let o):
            setDistance(o.distance)
            if let landing = o.landing {
                landingYardLine = landing.value.yardLine
                storedLandingZone = landing.value.zone?.storedValue
                storedLandingSource = landing.source.storedValue
                landingConfidence = landing.confidence
            }
            touchback = o.touchback
            outOfBounds = o.outOfBounds
            setHangTime(o.hangTime)

        case .punt(let o):
            setDistance(o.distance)
            setHangTime(o.hangTime)
        }
    }

    private mutating func setDistance(_ distance: MeasuredValue<Double>?) {
        distanceYards = distance?.value
        storedDistanceSource = distance?.source.storedValue
        distanceConfidence = distance?.confidence
    }

    private mutating func setHangTime(_ hangTime: MeasuredValue<Double>?) {
        hangTimeSeconds = hangTime?.value
        storedHangTimeSource = hangTime?.source.storedValue
        hangTimeConfidence = hangTime?.confidence
    }

    // MARK: Field presence (any value, source or confidence counts as "present")

    func hasData(for field: KickField) -> Bool {
        switch field {
        case .result:
            storedResult != nil
        case .distance:
            distanceYards != nil || storedDistanceSource != nil || distanceConfidence != nil
        case .accuracy:
            accuracyX != nil || accuracyY != nil || storedAccuracySource != nil || accuracyConfidence != nil
        case .landing:
            landingYardLine != nil || storedLandingZone != nil || storedLandingSource != nil || landingConfidence != nil
        case .touchback:
            touchback != nil
        case .outOfBounds:
            outOfBounds != nil
        case .hangTime:
            hangTimeSeconds != nil || storedHangTimeSource != nil || hangTimeConfidence != nil
        case .spotDistanceToTargetGoalLine:
            false
        }
    }
}
