import Foundation

// Typed, non-persisted outcome API. These types are what editors, services and the
// future analysis engine work with. They are mapped to Kick's flat columns by
// `KickOutcomeColumns` and validated by `KickValidator`.

/// Outcome of a field goal or PAT.
struct FieldGoalOutcome: Equatable, Sendable {
    var result: KickResult
    /// Actual kick distance from the hold to the goal plane, in yards.
    var distance: MeasuredValue<Double>?
    var accuracy: MeasuredValue<AccuracyCoordinate>?

    init(
        result: KickResult = .unknown,
        distance: MeasuredValue<Double>? = nil,
        accuracy: MeasuredValue<AccuracyCoordinate>? = nil
    ) {
        self.result = result
        self.distance = distance
        self.accuracy = accuracy
    }
}

/// Where a kickoff landed. At least one of the two fields should be set.
struct KickoffLanding: Equatable, Sendable {
    /// Yards from the receiving team's goal line; negative = in the end zone.
    var yardLine: Double?
    var zone: LandingZone?

    init(yardLine: Double? = nil, zone: LandingZone? = nil) {
        self.yardLine = yardLine
        self.zone = zone
    }
}

/// Outcome of a kickoff.
struct KickoffOutcome: Equatable, Sendable {
    /// Actual ball travel distance in yards, when known.
    var distance: MeasuredValue<Double>?
    /// Where the ball landed or was first possessed.
    var landing: MeasuredValue<KickoffLanding>?
    var touchback: Bool?
    var outOfBounds: Bool?
    var hangTime: MeasuredValue<Double>?

    init(
        distance: MeasuredValue<Double>? = nil,
        landing: MeasuredValue<KickoffLanding>? = nil,
        touchback: Bool? = nil,
        outOfBounds: Bool? = nil,
        hangTime: MeasuredValue<Double>? = nil
    ) {
        self.distance = distance
        self.landing = landing
        self.touchback = touchback
        self.outOfBounds = outOfBounds
        self.hangTime = hangTime
    }
}

/// Outcome of a punt. V1 records distance and hang time only; punt-specific fields
/// (net yards, inside-20, fair catch, direction) arrive later as optional columns.
struct PuntOutcome: Equatable, Sendable {
    /// Punt distance in yards, when known.
    var distance: MeasuredValue<Double>?
    var hangTime: MeasuredValue<Double>?

    init(distance: MeasuredValue<Double>? = nil, hangTime: MeasuredValue<Double>? = nil) {
        self.distance = distance
        self.hangTime = hangTime
    }
}

/// The outcome of any kick. The case determines the kick type, so a draft cannot
/// pair a kick type with another type's outcome data.
enum KickOutcome: Equatable, Sendable {
    case fieldGoal(FieldGoalOutcome)
    case pat(FieldGoalOutcome)
    case kickoff(KickoffOutcome)
    case punt(PuntOutcome)

    var kickType: KickType {
        switch self {
        case .fieldGoal: .fieldGoal
        case .pat: .pat
        case .kickoff: .kickoff
        case .punt: .punt
        }
    }
}

extension KickOutcome {
    /// Reads a typed outcome from flat columns. Lenient by design: it reads only the
    /// columns that belong to `kickType` and treats a missing or unrecognized source
    /// as `.unknown`. Use `KickValidator` to audit stored state.
    ///
    /// Returns nil for `.unknown` kick types.
    init?(kickType: KickType, columns c: KickOutcomeColumns) {
        let distance = Self.measured(c.distanceYards, source: c.storedDistanceSource, confidence: c.distanceConfidence)

        switch kickType {
        case .fieldGoal, .pat:
            var accuracy: MeasuredValue<AccuracyCoordinate>?
            if let x = c.accuracyX {
                accuracy = MeasuredValue(
                    value: AccuracyCoordinate(x: x, y: c.accuracyY),
                    source: Self.source(c.storedAccuracySource),
                    confidence: c.accuracyConfidence
                )
            }
            let outcome = FieldGoalOutcome(
                result: KickResult(optionalStoredValue: c.storedResult) ?? .unknown,
                distance: distance,
                accuracy: accuracy
            )
            self = kickType == .fieldGoal ? .fieldGoal(outcome) : .pat(outcome)

        case .kickoff:
            var landing: MeasuredValue<KickoffLanding>?
            let zone = LandingZone(optionalStoredValue: c.storedLandingZone)
            if c.landingYardLine != nil || zone != nil {
                landing = MeasuredValue(
                    value: KickoffLanding(yardLine: c.landingYardLine, zone: zone),
                    source: Self.source(c.storedLandingSource),
                    confidence: c.landingConfidence
                )
            }
            self = .kickoff(KickoffOutcome(
                distance: distance,
                landing: landing,
                touchback: c.touchback,
                outOfBounds: c.outOfBounds,
                hangTime: Self.measured(c.hangTimeSeconds, source: c.storedHangTimeSource, confidence: c.hangTimeConfidence)
            ))

        case .punt:
            self = .punt(PuntOutcome(
                distance: distance,
                hangTime: Self.measured(c.hangTimeSeconds, source: c.storedHangTimeSource, confidence: c.hangTimeConfidence)
            ))

        case .unknown:
            return nil
        }
    }

    private static func source(_ stored: String?) -> OutcomeMeasurementSource {
        OutcomeMeasurementSource(optionalStoredValue: stored) ?? .unknown
    }

    private static func measured(_ value: Double?, source: String?, confidence: Double?) -> MeasuredValue<Double>? {
        guard let value else { return nil }
        return MeasuredValue(value: value, source: Self.source(source), confidence: confidence)
    }
}
