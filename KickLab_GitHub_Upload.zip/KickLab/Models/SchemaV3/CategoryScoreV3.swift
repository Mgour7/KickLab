import Foundation
import SwiftData

// Step 12G: KickLab schema V3 copy of `CategoryScore`. V1 (`CategoryScore.swift`) and V2
// (`SchemaV2/CategoryScoreV2.swift`) stay frozen for migration; the app uses this version through
// the typealias in `KickLabSchemaV3.swift`. Computed accessors live in extensions on the
// typealias, so they apply to this version.
extension KickLabSchemaV3 {
    /// A 0–100 score for one mechanics category within an analysis.
    @Model
    final class CategoryScore {
        var id: UUID = UUID()
        /// Raw value of `AnalysisCategory`.
        var storedCategory: String = "overall"
        /// 0–100. Nil when the category could not be scored.
        var score: Double?
        /// 0...1.
        var confidence: Double?
        /// Raw value of `MeasurementStatus`.
        var storedMeasurementStatus: String = "unavailable"
        var summary: String?

        /// Inverse is declared on `BiomechanicsAnalysis.categoryScores`.
        var analysis: BiomechanicsAnalysis?

        init(
            id: UUID = UUID(),
            category: AnalysisCategory,
            score: Double? = nil,
            confidence: Double? = nil,
            measurementStatus: MeasurementStatus = .unavailable,
            summary: String? = nil
        ) {
            self.id = id
            self.storedCategory = category.storedValue
            self.score = score
            self.confidence = confidence
            self.storedMeasurementStatus = measurementStatus.storedValue
            self.summary = summary
        }
    }
}
