import Foundation
import SwiftData

// Step 12G: KickLab schema V3 copy of `BiomechanicsAnalysis`. V1 (`BiomechanicsAnalysis.swift`) and V2
// (`SchemaV2/BiomechanicsAnalysisV2.swift`) stay frozen for migration; the app uses this version through
// the typealias in `KickLabSchemaV3.swift`. Computed accessors live in extensions on the
// typealias, so they apply to this version.
extension KickLabSchemaV3 {
    /// One run of the biomechanics engine over a kick's video(s).
    ///
    /// A kick keeps its full analysis history: re-running with a newer engine creates
    /// a new record and never edits an old one. Exactly one completed analysis per kick
    /// is normally `isCurrent`; `AnalysisService` (step 5) flips it in a single save.
    ///
    /// Bulk output (pose time-series, intermediate CV data, overlays) is stored as files
    /// referenced by `artifactsRelativePath`, never in SwiftData.
    @Model
    final class BiomechanicsAnalysis {
        #Index<BiomechanicsAnalysis>([\.isCurrent])

        var id: UUID = UUID()
        /// Engine version that produced this analysis, e.g. "2.1.0".
        var analysisVersion: String = ""
        /// Shape of the stored results, for readers of older records.
        var resultsFormatVersion: Int = 1
        var createdAt: Date = Date.now
        var completedAt: Date?
        /// Raw value of `ProcessingStatus`.
        var storedProcessingStatus: String = "queued"
        /// Overall confidence, 0...1.
        var confidence: Double?
        var overallScore: Double?
        var isCurrent: Bool = false
        var failureReason: String?
        /// Relative path of the file-backed artifacts for this analysis.
        var artifactsRelativePath: String?

        /// Inverse is declared on `Kick.analyses`.
        var kick: Kick?

        /// Videos used as input. Every one must belong to `kick`
        /// (enforced by `attachInputVideo(_:)` and `AnalysisIntegrityValidator`).
        @Relationship(deleteRule: .nullify, inverse: \VideoAsset.analyses)
        var inputVideos: [VideoAsset]? = []

        @Relationship(deleteRule: .cascade, inverse: \BiomechanicalMetric.analysis)
        var metrics: [BiomechanicalMetric]? = []

        @Relationship(deleteRule: .cascade, inverse: \CategoryScore.analysis)
        var categoryScores: [CategoryScore]? = []

        @Relationship(deleteRule: .cascade, inverse: \CoachingObservation.analysis)
        var observations: [CoachingObservation]? = []

        init(
            id: UUID = UUID(),
            analysisVersion: String = "",
            processingStatus: ProcessingStatus = .queued,
            createdAt: Date = .now
        ) {
            self.id = id
            self.analysisVersion = analysisVersion
            self.storedProcessingStatus = processingStatus.storedValue
            self.createdAt = createdAt
        }
    }
}
