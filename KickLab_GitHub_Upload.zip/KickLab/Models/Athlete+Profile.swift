import Foundation
import SwiftData

/// Step 12F: typed access to the V2 profile fields.
extension Athlete {
    var primaryRole: AthleteRole? {
        get { AthleteRole(optionalStoredValue: storedPrimaryRole) }
        set { storedPrimaryRole = newValue?.storedValue }
    }

    var experienceLevel: ExperienceLevel? {
        get { ExperienceLevel(optionalStoredValue: storedExperienceLevel) }
        set { storedExperienceLevel = newValue?.storedValue }
    }

    var preferredBallType: FootballType? {
        get { FootballType(optionalStoredValue: storedPreferredBallType) }
        set { storedPreferredBallType = newValue?.storedValue }
    }

    /// Nickname when set, otherwise the full name.
    var displayName: String {
        if let nickname, !nickname.trimmingCharacters(in: .whitespaces).isEmpty { return nickname }
        return fullName.isEmpty ? "Athlete" : fullName
    }

    /// The year of birth from the date of birth, or the entered birth year.
    var effectiveBirthYear: Int? {
        if let dateOfBirth { return Calendar(identifier: .gregorian).component(.year, from: dateOfBirth) }
        return birthYear
    }
}

/// Step 12F: typed access to the V2 entered kick details.
extension Kick {
    var ballType: FootballType? {
        get { FootballType(optionalStoredValue: storedBallType) }
        set { storedBallType = newValue?.storedValue }
    }

    var kickSetup: KickSetup? {
        get { KickSetup(optionalStoredValue: storedKickSetup) }
        set { storedKickSetup = newValue?.storedValue }
    }

    var kickDirection: KickDirection? {
        get { KickDirection(optionalStoredValue: storedKickDirection) }
        set { storedKickDirection = newValue?.storedValue }
    }

    var puntResult: PuntResult? {
        get { PuntResult(optionalStoredValue: storedPuntResult) }
        set { storedPuntResult = newValue?.storedValue }
    }
}
