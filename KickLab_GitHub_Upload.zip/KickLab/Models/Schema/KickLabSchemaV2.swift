import Foundation
import SwiftData

/// Version 2 of the KickLab persistent schema (Step 12F).
///
/// Purely ADDITIVE over V1 — every new stored property is optional, nothing is renamed,
/// removed or retyped — so V1 stores upgrade with a lightweight migration and keep every
/// athlete, session, kick, video and analysis:
/// - `Athlete`: `nickname`, `photoData` (external storage), `birthYear`,
///   `storedPrimaryRole`, `storedExperienceLevel`, `goals`, `storedPreferredBallType`.
/// - `Kick`: `storedBallType`, `storedKickSetup`, `conditionsNote`,
///   `storedKickDirection`, `puntInsideTwenty`, `storedPuntResult`.
/// The other six models are unchanged copies of V1.
///
/// The same CloudKit-compatibility rules as V1 apply (no unique attributes, every stored
/// property optional or defaulted, to-many relationships optional).
enum KickLabSchemaV2: VersionedSchema {
    static var versionIdentifier: Schema.Version { Schema.Version(2, 0, 0) }

    static var models: [any PersistentModel.Type] {
        [
            Athlete.self,
            KickingSession.self,
            Kick.self,
            VideoAsset.self,
            BiomechanicsAnalysis.self,
            BiomechanicalMetric.self,
            CategoryScore.self,
            CoachingObservation.self,
        ]
    }
}

// The rest of the app refers to the current schema's models by these names.
typealias Athlete = KickLabSchemaV2.Athlete
typealias KickingSession = KickLabSchemaV2.KickingSession
typealias Kick = KickLabSchemaV2.Kick
typealias VideoAsset = KickLabSchemaV2.VideoAsset
typealias BiomechanicsAnalysis = KickLabSchemaV2.BiomechanicsAnalysis
typealias BiomechanicalMetric = KickLabSchemaV2.BiomechanicalMetric
typealias CategoryScore = KickLabSchemaV2.CategoryScore
typealias CoachingObservation = KickLabSchemaV2.CoachingObservation
