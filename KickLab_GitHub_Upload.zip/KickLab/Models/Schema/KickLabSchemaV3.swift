import Foundation
import SwiftData

/// Version 3 of the KickLab persistent schema (Step 12G).
///
/// Purely ADDITIVE over V2: `VideoAsset.verificationData: Data?` (the user's verified
/// plant frame, first ball movement and ball location, encoded `VideoVerification`).
/// The other seven models are unchanged copies of V2, so V2 stores upgrade with a
/// lightweight migration and keep every record.
enum KickLabSchemaV3: VersionedSchema {
    static var versionIdentifier: Schema.Version { Schema.Version(3, 0, 0) }

    static var models: [any PersistentModel.Type] {
        [
            Athlete.self,
            KickingSession.self,
            Kick.self,
            VideoAsset.self,
            BiomechanicsAnalysis.self,
            BiomechanicalMetric.self,
            CategoryScore.self,
            CoachingObservation.self,
        ]
    }
}

// The rest of the app refers to the current schema's models by these names.
typealias Athlete = KickLabSchemaV3.Athlete
typealias KickingSession = KickLabSchemaV3.KickingSession
typealias Kick = KickLabSchemaV3.Kick
typealias VideoAsset = KickLabSchemaV3.VideoAsset
typealias BiomechanicsAnalysis = KickLabSchemaV3.BiomechanicsAnalysis
typealias BiomechanicalMetric = KickLabSchemaV3.BiomechanicalMetric
typealias CategoryScore = KickLabSchemaV3.CategoryScore
typealias CoachingObservation = KickLabSchemaV3.CoachingObservation
