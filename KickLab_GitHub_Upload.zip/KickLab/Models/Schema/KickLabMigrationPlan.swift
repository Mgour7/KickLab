import Foundation
import SwiftData

/// The only path by which the KickLab schema may change (invariant G2).
///
/// To evolve the schema:
/// 1. Copy the current models into a new `KickLabSchemaV2` namespace and change them there.
/// 2. Append `KickLabSchemaV2.self` to `schemas`.
/// 3. Add a stage: `.lightweight(fromVersion: KickLabSchemaV1.self, toVersion: KickLabSchemaV2.self)`
///    for additive changes (new optional columns), or `.custom(...)` when data must be transformed.
/// 4. Repoint the typealiases in the schema file.
enum KickLabMigrationPlan: SchemaMigrationPlan {
    static var schemas: [any VersionedSchema.Type] {
        [KickLabSchemaV1.self]
    }

    static var stages: [MigrationStage] {
        []
    }
}
