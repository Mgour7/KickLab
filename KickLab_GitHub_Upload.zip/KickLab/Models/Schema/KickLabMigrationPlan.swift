import Foundation
import SwiftData

/// The only path by which the KickLab schema may change (invariant G2).
///
/// To evolve the schema:
/// 1. Copy the current models into a new `KickLabSchemaV2` namespace and change them there.
/// 2. Append `KickLabSchemaV2.self` to `schemas`.
/// 3. Add a stage: `.lightweight(fromVersion: KickLabSchemaV1.self, toVersion: KickLabSchemaV2.self)`
///    for additive changes (new optional columns), or `.custom(...)` when data must be transformed.
/// 4. Repoint the typealiases in the schema file.
enum KickLabMigrationPlan: SchemaMigrationPlan {
    static var schemas: [any VersionedSchema.Type] {
        [KickLabSchemaV1.self, KickLabSchemaV2.self, KickLabSchemaV3.self]
    }

    static var stages: [MigrationStage] {
        // Step 12F: V1 → V2 adds optional columns only (see `KickLabSchemaV2`), so
        // SwiftData migrates in place with no data transformation; existing rows get nil.
        // Step 12G: V2 → V3 adds `VideoAsset.verificationData` only (lightweight).
        [
            .lightweight(fromVersion: KickLabSchemaV1.self, toVersion: KickLabSchemaV2.self),
            .lightweight(fromVersion: KickLabSchemaV2.self, toVersion: KickLabSchemaV3.self),
        ]
    }
}
