import Foundation
import SwiftData

/// Version 1 of the KickLab persistent schema.
///
/// Every `@Model` class is declared inside this namespace (in its own file, via
/// `extension KickLabSchemaV1`). When V2 arrives, these definitions stay frozen
/// here, V2 gets its own namespace, and `KickLabMigrationPlan` gains a stage.
///
/// SwiftData entity names are the bare class names ("Kick", "Athlete"...), so the
/// namespace does not leak into the store.
///
/// CloudKit-compatibility rules followed by every model:
/// - no `@Attribute(.unique)`;
/// - every stored property is optional or has a default;
/// - to-many relationships are optional arrays.
enum KickLabSchemaV1: VersionedSchema {
    static var versionIdentifier: Schema.Version { Schema.Version(1, 0, 0) }

    static var models: [any PersistentModel.Type] {
        [
            Athlete.self,
            KickingSession.self,
            Kick.self,
            VideoAsset.self,
            BiomechanicsAnalysis.self,
            BiomechanicalMetric.self,
            CategoryScore.self,
            CoachingObservation.self,
        ]
    }
}

// The rest of the app refers to the current schema's models by these names.
// When V2 ships, these aliases move to point at KickLabSchemaV2.
typealias Athlete = KickLabSchemaV1.Athlete
typealias KickingSession = KickLabSchemaV1.KickingSession
typealias Kick = KickLabSchemaV1.Kick
typealias VideoAsset = KickLabSchemaV1.VideoAsset
typealias BiomechanicsAnalysis = KickLabSchemaV1.BiomechanicsAnalysis
typealias BiomechanicalMetric = KickLabSchemaV1.BiomechanicalMetric
typealias CategoryScore = KickLabSchemaV1.CategoryScore
typealias CoachingObservation = KickLabSchemaV1.CoachingObservation
