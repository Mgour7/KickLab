import Foundation
import SwiftData

/// Version 1 of the KickLab persistent schema.
///
/// Every `@Model` class is declared inside this namespace (in its own file, via
/// `extension KickLabSchemaV1`). When V2 arrives, these definitions stay frozen
/// here, V2 gets its own namespace, and `KickLabMigrationPlan` gains a stage.
///
/// SwiftData entity names are the bare class names ("Kick", "Athlete"...), so the
/// namespace does not leak into the store.
///
/// CloudKit-compatibility rules followed by every model:
/// - no `@Attribute(.unique)`;
/// - every stored property is optional or has a default;
/// - to-many relationships are optional arrays.
enum KickLabSchemaV1: VersionedSchema {
    static var versionIdentifier: Schema.Version { Schema.Version(1, 0, 0) }

    static var models: [any PersistentModel.Type] {
        [
            Athlete.self,
            KickingSession.self,
            Kick.self,
            VideoAsset.self,
            BiomechanicsAnalysis.self,
            BiomechanicalMetric.self,
            CategoryScore.self,
            CoachingObservation.self,
        ]
    }
}

// Step 12F: the app now uses KickLabSchemaV2 (typealiases in KickLabSchemaV2.swift).
// These V1 definitions are frozen: they describe stores written by builds up to 12E and
// are only used by `KickLabMigrationPlan` to migrate them.
