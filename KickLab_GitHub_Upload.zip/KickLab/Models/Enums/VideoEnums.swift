import Foundation

/// Camera position relative to the kicker. Persisted as `VideoAsset.storedAngleType`.
enum VideoAngleType: String, PersistedStringEnum {
    case side = "side"
    case rear = "rear"
    case front = "front"
    case behindGoal = "behindGoal"
    case unknown = "unknown"

    static let fallback: VideoAngleType = .unknown

    var displayName: String {
        switch self {
        case .side: "Side"
        case .rear: "Rear"
        case .front: "Front"
        case .behindGoal: "Behind Goal"
        case .unknown: "Unknown"
        }
    }
}

/// How a video entered the app. Persisted as `VideoAsset.storedSourceType`.
enum VideoSourceType: String, PersistedStringEnum {
    case captured = "captured"
    case photosImport = "photosImport"
    case filesImport = "filesImport"
    case unknown = "unknown"

    static let fallback: VideoSourceType = .unknown

    var displayName: String {
        switch self {
        case .captured: "Recorded in KickLab"
        case .photosImport: "Imported from Photos"
        case .filesImport: "Imported from Files"
        case .unknown: "Unknown"
        }
    }
}

/// Where the video's bytes currently live. Persisted as `VideoAsset.storedStorageStatus`.
/// Video bytes are never stored in SwiftData.
enum VideoStorageStatus: String, PersistedStringEnum {
    /// File exists in app-managed storage (`Application Support/KickLab/Media/`).
    case local = "local"
    /// Only a Photos library reference exists.
    case photosLibrary = "photosLibrary"
    /// Moved off-device (future cloud media storage).
    case offloaded = "offloaded"
    /// The file could not be found. Metadata and analyses remain valid.
    case missing = "missing"

    static let fallback: VideoStorageStatus = .missing

    var displayName: String {
        switch self {
        case .local: "On device"
        case .photosLibrary: "In Photos"
        case .offloaded: "Offloaded"
        case .missing: "Missing"
        }
    }
}

/// How a video's contact moment was determined. Persisted as `VideoAsset.storedContactTimeSource`.
enum ContactTimeSource: String, PersistedStringEnum {
    case manual = "manual"
    case detected = "detected"
    case unknown = "unknown"

    static let fallback: ContactTimeSource = .unknown

    var displayName: String {
        switch self {
        case .manual: "Marked manually"
        case .detected: "Detected automatically"
        case .unknown: "Unknown"
        }
    }
}
