import Foundation

/// The athlete's kicking foot. Persisted as `Athlete.storedKickingFoot`.
enum KickingFoot: String, PersistedStringEnum {
    case right = "right"
    case left = "left"

    static let fallback: KickingFoot = .right

    var displayName: String {
        switch self {
        case .right: "Right"
        case .left: "Left"
        }
    }
}
