import Foundation

/// Where an outcome measurement (distance, accuracy, landing, hang time) came from.
///
/// This lets the UI distinguish "65 yards — manually entered" from
/// "65.2 yards — video measured, 94% confidence".
///
/// Persisted on `Kick` as `storedDistanceSource`, `storedAccuracySource`,
/// `storedLandingSource` and `storedHangTimeSource`.
///
/// ## Scope: kind of provenance, not the exact video
/// `primaryVideo`, `secondaryVideo` and `multiVideo` describe the **kind** of
/// provenance only. They do not identify which `VideoAsset`(s) produced a value:
/// "primaryVideo" means "the kick's primary video at measurement time", and a video
/// can later be replaced or re-designated as primary.
///
/// Extension path: when video-analysis work begins, each measured group will gain
/// exact source-video identifiers (or relationships) so a measurement can be traced
/// to the actual `VideoAsset`(s) used. That is an additive, lightweight migration;
/// this enum keeps its meaning and its frozen raw values.
enum OutcomeMeasurementSource: String, PersistedStringEnum {
    case manual = "manual"
    case primaryVideo = "primaryVideo"
    case secondaryVideo = "secondaryVideo"
    case multiVideo = "multiVideo"
    case imported = "imported"
    case unknown = "unknown"

    static let fallback: OutcomeMeasurementSource = .unknown

    var displayName: String {
        switch self {
        case .manual: "Manually entered"
        case .primaryVideo: "Measured from primary video"
        case .secondaryVideo: "Measured from secondary video"
        case .multiVideo: "Derived from multiple videos"
        case .imported: "Imported"
        case .unknown: "Unknown source"
        }
    }

    /// True when the value was produced by video measurement.
    var isVideoDerived: Bool {
        switch self {
        case .primaryVideo, .secondaryVideo, .multiVideo: true
        case .manual, .imported, .unknown: false
        }
    }

    /// Manual entries never carry a confidence value: a person typing a number
    /// is not a statistical measurement, and inventing one would overstate precision.
    var allowsConfidence: Bool { self != .manual }
}
