import Foundation

/// Step 12F: what the athlete mainly does. Persisted as `Athlete.storedPrimaryRole`.
enum AthleteRole: String, PersistedStringEnum {
    case kicker = "kicker"
    case punter = "punter"
    case both = "both"
    case unknown = "unknown"

    static let fallback: AthleteRole = .unknown
    static var selectableCases: [AthleteRole] { [.kicker, .punter, .both] }

    var displayName: String {
        switch self {
        case .kicker: "Kicker"
        case .punter: "Punter"
        case .both: "Kicker & punter"
        case .unknown: "Not set"
        }
    }
}

/// Step 12F: the athlete's kicking experience (separate from level of play).
/// Persisted as `Athlete.storedExperienceLevel`.
enum ExperienceLevel: String, PersistedStringEnum {
    case beginner = "beginner"
    case developing = "developing"
    case experienced = "experienced"
    case advanced = "advanced"
    case unknown = "unknown"

    static let fallback: ExperienceLevel = .unknown
    static var selectableCases: [ExperienceLevel] { [.beginner, .developing, .experienced, .advanced] }

    var displayName: String {
        switch self {
        case .beginner: "Beginner (under 1 year)"
        case .developing: "Developing (1–2 years)"
        case .experienced: "Experienced (3–4 years)"
        case .advanced: "Advanced (5+ years)"
        case .unknown: "Not set"
        }
    }
}

/// Step 12F: the football used. Persisted as `Athlete.storedPreferredBallType` and
/// `Kick.storedBallType`.
enum FootballType: String, PersistedStringEnum {
    case youth = "youth"
    case highSchool = "highSchool"
    case college = "college"
    case professional = "professional"
    case other = "other"
    case unknown = "unknown"

    static let fallback: FootballType = .unknown
    static var selectableCases: [FootballType] { [.youth, .highSchool, .college, .professional, .other] }

    var displayName: String {
        switch self {
        case .youth: "Youth ball"
        case .highSchool: "High school ball"
        case .college: "College ball"
        case .professional: "Pro ball"
        case .other: "Other"
        case .unknown: "Unknown"
        }
    }
}

/// Step 12F: how the ball was set up. Persisted as `Kick.storedKickSetup`.
enum KickSetup: String, PersistedStringEnum {
    case tee = "tee"
    case block = "block"
    case holder = "holder"
    case ground = "ground"
    case drop = "drop"
    case unknown = "unknown"

    static let fallback: KickSetup = .unknown
    static var selectableCases: [KickSetup] { [.tee, .block, .holder, .ground, .drop] }

    var displayName: String {
        switch self {
        case .tee: "Tee"
        case .block: "Block"
        case .holder: "Holder"
        case .ground: "Off the ground"
        case .drop: "Dropped (punt)"
        case .unknown: "Unknown"
        }
    }
}

/// Step 12F: where a kickoff or punt went, from the kicker's perspective (entered).
/// Persisted as `Kick.storedKickDirection`.
enum KickDirection: String, PersistedStringEnum {
    case left = "left"
    case middle = "middle"
    case right = "right"
    case unknown = "unknown"

    static let fallback: KickDirection = .unknown
    static var selectableCases: [KickDirection] { [.left, .middle, .right] }

    var displayName: String {
        switch self {
        case .left: "Left"
        case .middle: "Middle"
        case .right: "Right"
        case .unknown: "Unknown"
        }
    }
}

/// Step 12F: how a punt ended (entered). Persisted as `Kick.storedPuntResult`.
enum PuntResult: String, PersistedStringEnum {
    case fairCatch = "fairCatch"
    case returned = "returned"
    case downed = "downed"
    case outOfBounds = "outOfBounds"
    case touchback = "touchback"
    case blocked = "blocked"
    case unknown = "unknown"

    static let fallback: PuntResult = .unknown
    static var selectableCases: [PuntResult] { [.fairCatch, .returned, .downed, .outOfBounds, .touchback, .blocked] }

    var displayName: String {
        switch self {
        case .fairCatch: "Fair catch"
        case .returned: "Returned"
        case .downed: "Downed"
        case .outOfBounds: "Out of bounds"
        case .touchback: "Touchback"
        case .blocked: "Blocked"
        case .unknown: "Unknown"
        }
    }
}
