import Foundation

/// The type of a kicking session. Persisted as `KickingSession.storedSessionType`.
enum KickingSessionType: String, PersistedStringEnum {
    case training = "training"
    case game = "game"
    case camp = "camp"
    case competition = "competition"
    case warmup = "warmup"

    static let fallback: KickingSessionType = .training

    var displayName: String {
        switch self {
        case .training: "Training"
        case .game: "Game"
        case .camp: "Camp"
        case .competition: "Competition"
        case .warmup: "Warmup"
        }
    }

    /// The context a new kick in this session gets by default (overridable per kick).
    var defaultKickContext: KickContext {
        switch self {
        case .training: .training
        case .game: .game
        case .camp: .camp
        case .competition: .competition
        case .warmup: .warmup
        }
    }
}
