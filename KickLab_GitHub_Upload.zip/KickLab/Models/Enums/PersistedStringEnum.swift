import Foundation

/// The contract every enum persisted in SwiftData must follow.
///
/// SwiftData never stores these enums directly. Each model stores the enum's
/// `rawValue` in a plain `String` column (named `storedX`) and exposes a typed
/// computed accessor. This keeps columns indexable and usable in `#Predicate`,
/// and it means a renamed Swift case can never corrupt existing data.
///
/// Rules (enforced by `EnumRawValueTests`):
/// 1. Raw values are explicit string literals, never derived from case names.
/// 2. A raw value, once shipped, is never renamed, removed or reused.
/// 3. An unrecognized stored string (for example, written by a newer app
///    version) decodes to `fallback` instead of crashing.
protocol PersistedStringEnum: RawRepresentable, CaseIterable, Codable, Hashable, Sendable
where RawValue == String {
    /// The value used when a stored string is not recognized.
    static var fallback: Self { get }

    /// The cases a person may pick in the UI. Excludes read-only sentinels such as `unknown`.
    static var selectableCases: [Self] { get }

    /// Human-readable label for display.
    var displayName: String { get }
}

extension PersistedStringEnum {
    static var selectableCases: [Self] { Array(allCases) }

    /// Decodes a stored, non-optional column. Never fails.
    init(storedValue: String) {
        self = Self(rawValue: storedValue) ?? Self.fallback
    }

    /// Decodes a stored, optional column. `nil` stays `nil`; unrecognized strings become `fallback`.
    init?(optionalStoredValue: String?) {
        guard let optionalStoredValue else { return nil }
        self.init(storedValue: optionalStoredValue)
    }

    /// The string written to the database.
    var storedValue: String { rawValue }

    /// Whether a stored string matches a known case exactly.
    static func isRecognized(_ storedValue: String) -> Bool {
        Self(rawValue: storedValue) != nil
    }
}
