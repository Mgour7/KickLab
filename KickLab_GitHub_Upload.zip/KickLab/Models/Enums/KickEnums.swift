import Foundation

/// The kind of kick. Persisted as `Kick.storedKickType`.
enum KickType: String, PersistedStringEnum {
    case fieldGoal = "fieldGoal"
    case pat = "pat"
    case kickoff = "kickoff"
    case punt = "punt"
    /// Read-only sentinel for a type written by a newer app version.
    /// It is never selectable and `KickValidator` refuses to write it.
    case unknown = "unknown"

    static let fallback: KickType = .unknown
    static var selectableCases: [KickType] { [.fieldGoal, .pat, .kickoff, .punt] }

    var displayName: String {
        switch self {
        case .fieldGoal: "Field Goal"
        case .pat: "PAT"
        case .kickoff: "Kickoff"
        case .punt: "Punt"
        case .unknown: "Unknown"
        }
    }

    /// Field goals and PATs share the goalpost outcome (result + accuracy).
    var usesGoalpostOutcome: Bool { self == .fieldGoal || self == .pat }
}

/// Where the kick happened. Persisted as `Kick.storedContext`.
enum KickContext: String, PersistedStringEnum {
    case training = "training"
    case game = "game"
    case camp = "camp"
    case competition = "competition"
    case warmup = "warmup"

    static let fallback: KickContext = .training

    var displayName: String {
        switch self {
        case .training: "Training"
        case .game: "Game"
        case .camp: "Camp"
        case .competition: "Competition"
        case .warmup: "Warmup"
        }
    }
}

/// Where the ball was spotted laterally. Persisted as `Kick.storedHashLocation`.
enum HashLocation: String, PersistedStringEnum {
    case left = "left"
    case center = "center"
    case right = "right"
    case notApplicable = "notApplicable"

    static let fallback: HashLocation = .notApplicable

    var displayName: String {
        switch self {
        case .left: "Left Hash"
        case .center: "Middle"
        case .right: "Right Hash"
        case .notApplicable: "N/A"
        }
    }
}

/// Result of a field goal or PAT. Persisted as `Kick.storedResult`.
/// "Left" and "right" are always from the kicker's perspective, facing the goal.
enum KickResult: String, PersistedStringEnum {
    case made = "made"
    case missedLeft = "missedLeft"
    case missedRight = "missedRight"
    case short = "short"
    case blocked = "blocked"
    /// Step 12F: a miss that isn't left, right or short (e.g. hit the upright and fell back).
    case missedOther = "missedOther"
    case unknown = "unknown"

    static let fallback: KickResult = .unknown

    var displayName: String {
        switch self {
        case .made: "Made"
        case .missedLeft: "Missed Left"
        case .missedRight: "Missed Right"
        case .short: "Short"
        case .blocked: "Blocked"
        case .missedOther: "Missed (other)"
        case .unknown: "Unknown"
        }
    }

    var isMake: Bool { self == .made }
}

/// Lateral zone where a kickoff landed, from the kicking team's perspective.
/// Persisted as `Kick.storedLandingZone`.
enum LandingZone: String, PersistedStringEnum {
    case left = "left"
    case middle = "middle"
    case right = "right"
    /// Read-only sentinel for a zone written by a newer app version.
    case unknown = "unknown"

    static let fallback: LandingZone = .unknown
    static var selectableCases: [LandingZone] { [.left, .middle, .right] }

    var displayName: String {
        switch self {
        case .left: "Left"
        case .middle: "Middle"
        case .right: "Right"
        case .unknown: "Unknown"
        }
    }
}

/// The level of play. Persisted as `Athlete.storedCurrentPlayingLevel`
/// and snapshotted onto `Kick.storedPlayingLevelAtKick`.
/// Deliberately does not encode NCAA division.
enum PlayingLevel: String, PersistedStringEnum {
    case youth = "youth"
    case middleSchool = "middleSchool"
    case highSchool = "highSchool"
    case college = "college"
    case professional = "professional"
    case other = "other"

    static let fallback: PlayingLevel = .other

    var displayName: String {
        switch self {
        case .youth: "Youth"
        case .middleSchool: "Middle School"
        case .highSchool: "High School"
        case .college: "College"
        case .professional: "Professional"
        case .other: "Other"
        }
    }
}
