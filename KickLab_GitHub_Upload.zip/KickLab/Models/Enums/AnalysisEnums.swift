import Foundation

/// Lifecycle of a `BiomechanicsAnalysis`. Persisted as `storedProcessingStatus`.
enum ProcessingStatus: String, PersistedStringEnum {
    case queued = "queued"
    case processing = "processing"
    case completed = "completed"
    case failed = "failed"
    case cancelled = "cancelled"
    /// Read-only sentinel for a status written by a newer app version.
    case unknown = "unknown"

    static let fallback: ProcessingStatus = .unknown
    static var selectableCases: [ProcessingStatus] { [.queued, .processing, .completed, .failed, .cancelled] }

    var displayName: String {
        switch self {
        case .queued: "Queued"
        case .processing: "Processing"
        case .completed: "Completed"
        case .failed: "Failed"
        case .cancelled: "Cancelled"
        case .unknown: "Unknown"
        }
    }

    /// Only a completed analysis may ever be marked current.
    var canBecomeCurrent: Bool { self == .completed }
}

/// How trustworthy a metric's value is. Persisted as `storedMeasurementStatus`.
/// An `unavailable` metric must have a `nil` value: the engine must never
/// pretend an unreliable measurement is precise.
enum MeasurementStatus: String, PersistedStringEnum {
    case measured = "measured"
    case estimated = "estimated"
    case unavailable = "unavailable"

    static let fallback: MeasurementStatus = .unavailable

    var displayName: String {
        switch self {
        case .measured: "Measured"
        case .estimated: "Estimated"
        case .unavailable: "Unavailable"
        }
    }
}

/// Mechanics category used by scores and coaching observations.
enum AnalysisCategory: String, PersistedStringEnum {
    case setup = "setup"
    case approach = "approach"
    case plant = "plant"
    case swing = "swing"
    case contact = "contact"
    case followThrough = "followThrough"
    case overall = "overall"
    case unknown = "unknown"

    static let fallback: AnalysisCategory = .unknown
    static var selectableCases: [AnalysisCategory] {
        [.setup, .approach, .plant, .swing, .contact, .followThrough, .overall]
    }

    var displayName: String {
        switch self {
        case .setup: "Setup"
        case .approach: "Approach"
        case .plant: "Plant"
        case .swing: "Swing"
        case .contact: "Contact"
        case .followThrough: "Follow-Through"
        case .overall: "Overall"
        case .unknown: "Unknown"
        }
    }
}

/// Phase of the kicking motion in which a metric was measured.
enum MechanicsPhase: String, PersistedStringEnum {
    case setup = "setup"
    case approach = "approach"
    case plant = "plant"
    case swing = "swing"
    case contact = "contact"
    case followThrough = "followThrough"
    case overall = "overall"
    case unknown = "unknown"

    static let fallback: MechanicsPhase = .unknown

    var displayName: String {
        switch self {
        case .setup: "Setup"
        case .approach: "Approach"
        case .plant: "Plant"
        case .swing: "Swing"
        case .contact: "Contact"
        case .followThrough: "Follow-Through"
        case .overall: "Overall"
        case .unknown: "Unknown"
        }
    }
}

/// Unit of a `BiomechanicalMetric` value.
enum MetricUnit: String, PersistedStringEnum {
    case unitless = "unitless"
    case inches = "inches"
    case centimeters = "centimeters"
    case meters = "meters"
    case yards = "yards"
    case degrees = "degrees"
    case degreesPerSecond = "degreesPerSecond"
    case metersPerSecond = "metersPerSecond"
    case milesPerHour = "milesPerHour"
    case seconds = "seconds"
    case milliseconds = "milliseconds"
    case ratio = "ratio"
    case percent = "percent"
    /// Multiples of the athlete's torso length in the same video (single-camera size unit).
    case bodyLengths = "bodyLengths"
    /// Torso lengths per second (single-camera speed unit).
    case bodyLengthsPerSecond = "bodyLengthsPerSecond"
    case unknown = "unknown"

    static let fallback: MetricUnit = .unknown

    var displayName: String {
        switch self {
        case .unitless: ""
        case .inches: "in"
        case .centimeters: "cm"
        case .meters: "m"
        case .yards: "yd"
        case .degrees: "°"
        case .degreesPerSecond: "°/s"
        case .metersPerSecond: "m/s"
        case .milesPerHour: "mph"
        case .seconds: "s"
        case .milliseconds: "ms"
        case .ratio: "ratio"
        case .percent: "%"
        case .bodyLengths: "torso lengths"
        case .bodyLengthsPerSecond: "torso lengths/s"
        case .unknown: "?"
        }
    }
}

/// KEEP / IMPROVE / CUE. Persisted as `CoachingObservation.storedKind`.
enum ObservationKind: String, PersistedStringEnum {
    /// A strength to preserve, e.g. "Excellent knee-through sequencing."
    case keep = "keep"
    /// A problem to address, e.g. "Plant is averaging farther outside than on successful kicks."
    case improve = "improve"
    /// A short actionable instruction, e.g. "Get the plant underneath you."
    case cue = "cue"
    /// Read-only sentinel for a kind written by a newer app version. Never written.
    case unknown = "unknown"

    static let fallback: ObservationKind = .unknown
    static var selectableCases: [ObservationKind] { [.keep, .improve, .cue] }

    var displayName: String {
        switch self {
        case .keep: "Keep"
        case .improve: "Improve"
        case .cue: "Cue"
        case .unknown: "Unknown"
        }
    }
}

/// Severity of an IMPROVE observation. Not meaningful for KEEP or CUE.
enum CoachingSeverity: String, PersistedStringEnum {
    case info = "info"
    case low = "low"
    case moderate = "moderate"
    case high = "high"

    static let fallback: CoachingSeverity = .info

    var displayName: String {
        switch self {
        case .info: "Info"
        case .low: "Low"
        case .moderate: "Moderate"
        case .high: "High"
        }
    }
}

/// What an observation is compared against.
enum ComparisonBasis: String, PersistedStringEnum {
    case absolute = "absolute"
    case personalMakes = "personalMakes"
    case personalBest = "personalBest"
    case referenceGroup = "referenceGroup"
    case unknown = "unknown"

    static let fallback: ComparisonBasis = .unknown

    var displayName: String {
        switch self {
        case .absolute: "Absolute"
        case .personalMakes: "Your successful kicks"
        case .personalBest: "Your best kicks"
        case .referenceGroup: "Reference group"
        case .unknown: "Unknown"
        }
    }
}

/// Who produced an observation.
enum ObservationSource: String, PersistedStringEnum {
    case engine = "engine"
    case coach = "coach"
    case athlete = "athlete"
    case unknown = "unknown"

    static let fallback: ObservationSource = .unknown

    var displayName: String {
        switch self {
        case .engine: "KickLab analysis"
        case .coach: "Coach"
        case .athlete: "Athlete"
        case .unknown: "Unknown"
        }
    }
}
