import Foundation
import SwiftData

extension KickLabSchemaV1 {
    /// Metadata and a file reference for one video of a kick.
    ///
    /// Video bytes are never stored in SwiftData. The file lives in app-managed
    /// storage under `Application Support/KickLab/Media/`, referenced by a path
    /// relative to that root (the app container's absolute path changes across
    /// reinstalls and restores). `VideoStorageService` (step 6) resolves and manages files.
    ///
    /// `kick` is optional at the schema level for persistence/CloudKit compatibility,
    /// but a persisted, operational VideoAsset without a kick is invalid: services
    /// treat it as orphaned (see `isOrphaned`).
    @Model
    final class VideoAsset {
        var id: UUID = UUID()
        var createdAt: Date = Date.now
        /// Capture time from the file's metadata, when known.
        var recordedAt: Date?

        /// Raw value of `VideoAngleType`.
        var storedAngleType: String = "unknown"
        /// At most one primary video per kick (enforced by the service layer).
        var isPrimary: Bool = false
        var sortOrder: Int = 0
        /// Raw value of `VideoSourceType`.
        var storedSourceType: String = "unknown"
        /// Raw value of `VideoStorageStatus`.
        var storedStorageStatus: String = "missing"

        /// Relative to `Application Support/KickLab/Media/`. Never an absolute path.
        var relativeFilePath: String?
        var thumbnailRelativePath: String?
        /// Photos library reference, if the video came from Photos.
        var photosLocalIdentifier: String?
        var originalFilename: String?
        var fileSizeBytes: Int64?

        var durationSeconds: Double?
        /// Nominal capture frame rate (e.g. 240 for slow motion).
        var frameRate: Double?
        var pixelWidth: Int?
        var pixelHeight: Int?
        var hasAudio: Bool?

        /// Offset in seconds relative to the kick's primary video, for multi-angle sync.
        var syncOffsetSeconds: Double?
        /// Time of foot-ball contact within this video, in seconds.
        var contactTimeSeconds: Double?
        /// Raw value of `ContactTimeSource`.
        var storedContactTimeSource: String?

        /// Small, versioned capture metadata only — an encoded `VideoTechnicalMetadata`
        /// (codec, device, lens, orientation, exposure). Capped at a few kilobytes.
        /// Frames, pose arrays, overlays, tensors and analysis output never go here;
        /// they belong in file-backed analysis artifacts.
        var technicalMetadata: Data?

        /// Inverse is declared on `Kick.videos`.
        var kick: Kick?

        /// Analyses that used this video as input. Inverse is declared on
        /// `BiomechanicsAnalysis.inputVideos`.
        var analyses: [BiomechanicsAnalysis]? = []

        init(
            id: UUID = UUID(),
            angleType: VideoAngleType = .unknown,
            isPrimary: Bool = false,
            sourceType: VideoSourceType = .unknown,
            storageStatus: VideoStorageStatus = .missing,
            relativeFilePath: String? = nil
        ) {
            self.id = id
            self.storedAngleType = angleType.storedValue
            self.isPrimary = isPrimary
            self.storedSourceType = sourceType.storedValue
            self.storedStorageStatus = storageStatus.storedValue
            self.relativeFilePath = relativeFilePath
            self.createdAt = .now
        }
    }
}

extension VideoAsset {
    var angleType: VideoAngleType {
        get { VideoAngleType(storedValue: storedAngleType) }
        set { storedAngleType = newValue.storedValue }
    }

    var sourceType: VideoSourceType {
        get { VideoSourceType(storedValue: storedSourceType) }
        set { storedSourceType = newValue.storedValue }
    }

    var storageStatus: VideoStorageStatus {
        get { VideoStorageStatus(storedValue: storedStorageStatus) }
        set { storedStorageStatus = newValue.storedValue }
    }

    var contactTimeSource: ContactTimeSource? {
        get { ContactTimeSource(optionalStoredValue: storedContactTimeSource) }
        set { storedContactTimeSource = newValue?.storedValue }
    }

    /// A video with no kick is invalid in operation and is treated as orphaned.
    var isOrphaned: Bool { kick == nil }

    /// Decoded capture metadata, or nil when absent or unreadable.
    var decodedTechnicalMetadata: VideoTechnicalMetadata? {
        technicalMetadata.flatMap(VideoTechnicalMetadata.decode)
    }

    /// Encodes and stores capture metadata, enforcing the size cap.
    func setTechnicalMetadata(_ metadata: VideoTechnicalMetadata?) throws {
        technicalMetadata = try metadata?.encoded()
    }
}
